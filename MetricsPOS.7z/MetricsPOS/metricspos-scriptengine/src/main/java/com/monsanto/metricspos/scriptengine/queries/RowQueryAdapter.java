package com.monsanto.metricspos.scriptengine.queries;

import com.monsanto.metricspos.core.DataTableServices;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataFile;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.beans.factory.annotation.Configurable;

import java.util.List;

/**
 * Transforms a query string to a logical data table into a query string for a
 * physical data table.
 * User: PPERA
 */
@Configurable
public class RowQueryAdapter {
    private static final String FROM = "from";
    private static final String ORDER_BY = "order by";
    private static final String HAVING = "having";
    private static final String GROUP_BY = "group by";
    private static final String WHERE = "where";
    private static final String ALIAS = "r";

    private String selectClause;
    private String fromClause;
    private String whereClause;
    private String groupByClause;
    private String havingClause;
    private String orderByClause;
    private ServiceCenter serviceCenter;
    private Campaign campaign;
    private DataTable dataTable;

    private DataTableServices tableServices;
    private List<String> columnNames;

    public RowQueryAdapter(String rowQuery, ServiceCenter serviceCenter, Campaign campaign, DataTableServices tableServices) {
        this.tableServices = tableServices;
        this.serviceCenter = serviceCenter;
        this.campaign = campaign;

        dataTable = this.getQueriedDataTable(rowQuery);
        columnNames = dataTable.getColumnNames();

        selectClause = this.extractSelectPart(rowQuery);
        fromClause = this.extractFromPart(rowQuery);
        whereClause = this.extractWherePart(rowQuery);

        groupByClause = this.extractGroupByPart(rowQuery);
        havingClause = this.extractHavingPart(rowQuery);
        orderByClause = this.extractOrderByPart(rowQuery);
    }

    private DataTable getQueriedDataTable(String rowQuery) {
        String trimmedRowQuery = rowQuery.trim();
        int fromClauseEndIndex = lastIndexOfFromClause(trimmedRowQuery);
        String fClause = trimmedRowQuery.substring(trimmedRowQuery.toLowerCase().indexOf(FROM), fromClauseEndIndex).trim();
        return this.tableServices.findDataTableByCampaignAndName(this.campaign, this.getTableNameToken(fClause));
    }

    private String addAliasesToColumnNames(String selectClause, String alias) {
        String back = selectClause;
        for (String columnName : columnNames) {
            back = back
                    .replaceAll("[\\(](" + columnName + ")", "(" + alias + "." + columnName)
                    .replaceAll("[,](" + columnName + ")", "," + alias + "." + columnName)
                    .replaceAll("[\\s](" + columnName + ")", " " + alias + "." + columnName);
        }

        return back;
    }

    private String extractOrderByPart(String rowQuery) {
        String trimmedRowQuery = rowQuery.trim();
        if (trimmedRowQuery.toLowerCase().indexOf(ORDER_BY) > 0) {
            int orderByClauseEndIndex = lastIndexOfOrderByClause(trimmedRowQuery);
            String oByClause = trimmedRowQuery.substring(trimmedRowQuery.toLowerCase().indexOf(ORDER_BY), orderByClauseEndIndex).trim();
            return addAliasesToColumnNames(oByClause, "r");
        }

        return "";
    }

    private String extractHavingPart(String rowQuery) {
        String trimmedRowQuery = rowQuery.trim();
        if (trimmedRowQuery.toLowerCase().indexOf(HAVING) > 0) {
            int havingClauseEndIndex = lastIndexOfHavingByClause(trimmedRowQuery);
            String hClause = trimmedRowQuery.substring(trimmedRowQuery.toLowerCase().indexOf(HAVING), havingClauseEndIndex).trim();
            return addAliasesToColumnNames(hClause, "r");
        }

        return "";
    }

    private String extractGroupByPart(String rowQuery) {
        String trimmedRowQuery = rowQuery.trim();
        if (trimmedRowQuery.toLowerCase().indexOf(GROUP_BY) > 0) {
            int groupByClauseEndIndex = lastIndexOfGroupByClause(trimmedRowQuery);
            String gByClause = trimmedRowQuery.substring(trimmedRowQuery.toLowerCase().indexOf(GROUP_BY), groupByClauseEndIndex).trim();
            return addAliasesToColumnNames(gByClause, "r");
        }

        return "";
    }

    private int lastIndexOfOrderByClause(String trimmedRowQuery) {
        int orderByClauseEndIndex = -1;

        if (orderByClauseEndIndex < 0) {
            orderByClauseEndIndex = trimmedRowQuery.length();
        }

        return orderByClauseEndIndex;
    }

    private int lastIndexOfGroupByClause(String trimmedRowQuery) {
        int groupByClauseEndIndex = -1;
        if (groupByClauseEndIndex < 0) {
            groupByClauseEndIndex = trimmedRowQuery.toLowerCase().indexOf(HAVING);
        }
        if (groupByClauseEndIndex < 0) {
            groupByClauseEndIndex = trimmedRowQuery.toLowerCase().indexOf(ORDER_BY);
        }
        if (groupByClauseEndIndex < 0) {
            groupByClauseEndIndex = trimmedRowQuery.length();
        }

        return groupByClauseEndIndex;
    }

    private int lastIndexOfHavingByClause(String trimmedRowQuery) {
        int havingClauseEndIndex = -1;

        if (havingClauseEndIndex < 0) {
            havingClauseEndIndex = trimmedRowQuery.toLowerCase().indexOf(ORDER_BY);
        }
        if (havingClauseEndIndex < 0) {
            havingClauseEndIndex = trimmedRowQuery.length();
        }

        return havingClauseEndIndex;
    }

    private String extractWherePart(String rowQuery) {
        String trimmedRowQuery = rowQuery.trim();
        if (trimmedRowQuery.toLowerCase().indexOf(WHERE) > 0) {
            int whereClauseEndIndex = lastIndexOfWhereClause(trimmedRowQuery);
            String wClause = trimmedRowQuery.substring(trimmedRowQuery.toLowerCase().indexOf(WHERE), whereClauseEndIndex).trim();
            wClause = addAliasesToColumnNames(wClause, "r");
            return wClause;
        }

        return "";
    }

    private int lastIndexOfWhereClause(String trimmedRowQuery) {
        int whereClauseEndIndex = -1;
        if (whereClauseEndIndex < 0) {
            whereClauseEndIndex = trimmedRowQuery.toLowerCase().indexOf(GROUP_BY);
        }
        if (whereClauseEndIndex < 0) {
            whereClauseEndIndex = trimmedRowQuery.toLowerCase().indexOf(HAVING);
        }
        if (whereClauseEndIndex < 0) {
            whereClauseEndIndex = trimmedRowQuery.toLowerCase().indexOf(ORDER_BY);
        }
        if (whereClauseEndIndex < 0) {
            whereClauseEndIndex = trimmedRowQuery.length();
        }

        return whereClauseEndIndex;
    }

    private String extractFromPart(String rowQuery) {
        String trimmedRowQuery = rowQuery.trim();
        int fromClauseEndIndex = lastIndexOfFromClause(trimmedRowQuery);
        String fClause = trimmedRowQuery.substring(trimmedRowQuery.toLowerCase().indexOf(FROM), fromClauseEndIndex).trim();
        return fClause.replaceFirst(this.getTableNameToken(fClause), "(SELECT " + this.getTableColumnNamesSeparatedByComas() + " FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = " + this.campaign.getId() + " AND rows.CUIT = '" + this.serviceCenter.getCuit() + "' AND tables.NAME = '" + this.getTableNameToken(fClause) + "' AND rows.DELETED = 0) as r");
    }

    private String getTableColumnNamesSeparatedByComas() {
        StringBuilder stringBuilder = new StringBuilder();
        for (DataColumn column : dataTable.getColumns()) {
            if (column.getDataType().getInternalType().equals(ServiceCenter.class)) {
                stringBuilder.append(",")
                        .append("rows.")
                        .append("CUIT")
                        .append(" as ")
                        .append(column.getName());
            } else if (column.getDataType().getInternalType().equals(PointOfSale.class)) {
                stringBuilder.append(",")
                        .append("rows.")
                        .append("POINT_OF_SALE_ID_SAP")
                        .append(" as ")
                        .append(column.getName());
            } else if (column.getDataType().getInternalType().equals(DataFile.class)) {
                stringBuilder.append(",")
                        .append("rows.")
                        .append("FILE_NAME")
                        .append(" as ")
                        .append(column.getName());
            } else {
                stringBuilder.append(",")
                        .append("rows.")
                        .append(column.getActualColumnName())
                        .append(" as ")
                        .append(column.getName());
            }
        }
        return stringBuilder.toString().substring(1);
    }

    private String getTableNameToken(String fromClause) {
        return fromClause.substring(FROM.length()).trim();
    }

    private int lastIndexOfFromClause(String trimmedRowQuery) {
        int fromClauseEndIndex = trimmedRowQuery.toLowerCase().indexOf(WHERE);
        if (fromClauseEndIndex < 0) {
            fromClauseEndIndex = trimmedRowQuery.toLowerCase().indexOf(GROUP_BY);
        }
        if (fromClauseEndIndex < 0) {
            fromClauseEndIndex = trimmedRowQuery.toLowerCase().indexOf(HAVING);
        }
        if (fromClauseEndIndex < 0) {
            fromClauseEndIndex = trimmedRowQuery.toLowerCase().indexOf(ORDER_BY);
        }
        if (fromClauseEndIndex < 0) {
            fromClauseEndIndex = trimmedRowQuery.length();
        }
        return fromClauseEndIndex;
    }

    private String extractSelectPart(String rowQuery) {
        String trimmedRowQuery = rowQuery.trim();
        String sClause = trimmedRowQuery.substring(0, trimmedRowQuery.toLowerCase().indexOf(FROM)).trim();
        return addAliasesToColumnNames(sClause, ALIAS);
    }

    public String getSqlQuery() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(selectClause)
                .append(" ")
                .append(fromClause);

        if (whereClause != null && !whereClause.isEmpty()) {
            stringBuilder.append(" ")
                    .append(whereClause);
        }

        if (groupByClause != null && !groupByClause.isEmpty()) {
            stringBuilder.append(" ")
                    .append(groupByClause);
        }

        if (havingClause != null && !havingClause.isEmpty()) {
            stringBuilder.append(" ")
                    .append(havingClause);
        }

        if (orderByClause != null && !orderByClause.isEmpty()) {
            stringBuilder.append(" ")
                    .append(orderByClause);
        }

        return stringBuilder.toString().trim();
    }
}
