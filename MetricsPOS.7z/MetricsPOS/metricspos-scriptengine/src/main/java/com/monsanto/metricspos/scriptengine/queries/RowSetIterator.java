package com.monsanto.metricspos.scriptengine.queries;

import org.springframework.jdbc.support.rowset.SqlRowSet;

import java.util.Iterator;

/**
 * Iterator to cycle through an SqlRowSet
 * User: PPERA
 */
public class RowSetIterator implements Iterator<SqlRowSet>, Iterable<SqlRowSet> {
    private SqlRowSet sqlRowSet;

    public RowSetIterator(SqlRowSet sqlRowSet) {
        // Ensures we are before the first row
        sqlRowSet.beforeFirst();

        this.sqlRowSet = sqlRowSet;
    }

    @Override
    public boolean hasNext() {
        return !sqlRowSet.isLast() && !sqlRowSet.isAfterLast();
    }

    @Override
    public SqlRowSet next() {
        sqlRowSet.next();
        return sqlRowSet;
    }

    @Override
    public void remove() {
        throw new UnsupportedOperationException("Cannot remove from this iterator");
    }

    @Override
    public Iterator<SqlRowSet> iterator() {
        return this;
    }
}
