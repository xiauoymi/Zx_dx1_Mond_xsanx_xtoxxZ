package com.monsanto.metricspos.scriptengine;

import com.monsanto.metricspos.scriptengine.exceptions.ScriptSyntaxException;
import org.apache.commons.jexl2.JexlContext;
import org.apache.commons.jexl2.JexlEngine;
import org.apache.commons.jexl2.JexlException;
import org.apache.commons.jexl2.Script;
import org.apache.commons.jexl2.parser.ParseException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Mockito.*;

/**
 * Test the ScriptEngine class
 *
 * @author cafau
 */
public class ScriptEngine_UT {

    private ScriptEngine instance;
    private JexlEngine engine;

    @Before
    public void setUp() throws Exception {

        engine = mock(JexlEngine.class);
    }

    @Test
    public void testGivenACorrectScript_WhenCreate_ThenCreateTheEngine() throws Exception {
        // given
        String scriptSource = "ok";

        Script script = mock(Script.class);

        when(engine.createScript(scriptSource)).thenReturn(script);

        // when
        instance = new ScriptEngine(engine, scriptSource);

        // Then
        verify( engine, times(1)).createScript(scriptSource);

    }

    @Test
    public void testGivenIncorrectScript_WhenCreate_ThenThrowException() throws Exception {
        // given
        String scriptSource = "line1-of-3\r\nline2-of-2\r\nline3-of-3";

        ParseException parseException = mock(ParseException.class);
        JexlException.Parsing runtimeException = new JexlException.Parsing(null, scriptSource, parseException);

        when(engine.createScript(scriptSource)).thenThrow(runtimeException);
        when(parseException.getLine()).thenReturn(1);
        when(parseException.getColumn()).thenReturn(5);

        try {
            // when
            instance = new ScriptEngine(engine, scriptSource);
            fail();
        } catch (Exception e) {
            // then
            verify(engine, times(1)).createScript(scriptSource);
            assertThat(e).isInstanceOf(ScriptSyntaxException.class);
        }

    }

    @Test
    public void testGivenACorrectScript_WhenExecute_ThenComputeTheScript() throws Exception {
        // given
        String scriptSource = "ok";
        String expectedResult = "some value";

        Script script = mock(Script.class);

        when(engine.createScript(scriptSource)).thenReturn(script);
        instance = new ScriptEngine(engine, scriptSource);

        when( script.execute(Matchers.<JexlContext>any())).thenReturn( expectedResult );
        // when
        Object result = instance.execute(null);

        // Then
        verify(engine, times(1)).createScript(scriptSource);
        assertThat(result).isEqualTo(expectedResult);
    }
}
