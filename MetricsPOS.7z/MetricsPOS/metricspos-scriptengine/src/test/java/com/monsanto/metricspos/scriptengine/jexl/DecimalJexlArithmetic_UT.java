package com.monsanto.metricspos.scriptengine.jexl;

import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.math.MathContext;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Test new methods in DecimalJexlArithmetic class
 *
 * @author cafau
 */
public class DecimalJexlArithmetic_UT {
    private DecimalJexlArithmetic instance;

    @Before
    public void setUp() throws Exception {
        MathContext mathContext = new MathContext(10);

        instance = new DecimalJexlArithmetic(false, mathContext, 2);
    }


    // Integer division --> Integer
    @Test
    public void testGivenArithmeticWithTwoDecimals_WhenDivideWithOneDecimal_ThenResultHasTwoDecimals() throws Exception {
        // given divisor, dividend
        Number dividend = BigDecimal.valueOf( 7 );
        Number divisor = BigDecimal.valueOf( 14 );
        Number expected = BigDecimal.valueOf(50, 2);

        // when
        Object result = instance.divide( dividend, divisor );

        // then
        assertThat(result).as("Result should have 2 decimals").isInstanceOf(expected.getClass()).isEqualTo(expected);
    }
}
