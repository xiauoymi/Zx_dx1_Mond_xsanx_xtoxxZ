package com.monsanto.metricspos.scriptengine.jexl;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.scriptengine.jexl.accessors.DataRowAccessorFactory;
import com.monsanto.metricspos.scriptengine.jexl.accessors.DataRowFieldAccessor;
import com.monsanto.metricspos.scriptengine.jexl.accessors.RowSetAccessorFactory;
import org.apache.commons.jexl2.JexlInfo;
import org.apache.commons.jexl2.introspection.JexlPropertyGet;
import org.apache.commons.jexl2.introspection.Uberspect;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Test the ExtensibleUberspectImpl class
 *
 * @author cafau
 */
public class ExtensibleUberspectImpl_UT {

    private Uberspect instance;
    private JexlInfo info;

    @Before
    public void setUp() throws Exception {
        ExtensibleUberspectImpl eus = new ExtensibleUberspectImpl();

        List<FieldAccessorFactory> accessorFactories = Lists.newArrayList(
                new DataRowAccessorFactory(),
                new RowSetAccessorFactory()
        );

        eus.setAccessorFactories(accessorFactories);

        instance = eus;

        info = mock(JexlInfo.class);
    }

    @Test
    public void testWhenGetterRequiredForDataRowObject_ThenDataRowFieldGetterSetterReturned() throws Exception {
        // Given
        DataRow dataRow = mock( DataRow.class );

        DataTable dataTable = mock( DataTable.class );

        when( dataRow.getDataTable() ).thenReturn( dataTable );
        when( dataTable.getName() ).thenReturn( "Table1" );

        // When request Getter
        JexlPropertyGet getter = instance.getPropertyGet( dataRow, "field1", info );

        // Then
        assertThat( getter ).isInstanceOf( DataRowFieldAccessor.class );
    }

    // Same table, different fields, different accessor
    @Test
    public void testGivenTableWithTwoFields_WhenGetterRequired_ThenDifferentGettersReturned() throws Exception {
        // Given
        DataRow dataRow1 = mock( DataRow.class );

        DataTable dataTable1 = mock( DataTable.class );

        when( dataRow1.getDataTable() ).thenReturn( dataTable1 );
        when( dataTable1.getName() ).thenReturn( "Table1" );

        // When request Getter
        JexlPropertyGet getter1 = instance.getPropertyGet( dataRow1, "field1", info );
        JexlPropertyGet getter2 = instance.getPropertyGet( dataRow1, "field2", info );

        // Then
        assertThat( getter1 ).isNotEqualTo( getter2 );
    }

    // Different tables, different accessors
    @Test
    public void testGivenTwoTablesWithSameNameField_WhenGetterRequired_ThenDifferentGettersReturned() throws Exception {
        // Given
        DataRow dataRow1 = mock( DataRow.class );

        DataTable dataTable1 = mock( DataTable.class );

        when( dataRow1.getDataTable() ).thenReturn( dataTable1 );
        when( dataTable1.getName() ).thenReturn( "Table1" );

        DataRow dataRow2 = mock( DataRow.class );

        DataTable dataTable2 = mock( DataTable.class );

        when( dataRow2.getDataTable() ).thenReturn( dataTable2 );
        when( dataTable2.getName() ).thenReturn( "Table2" );

        // When request Getter
        JexlPropertyGet getter1 = instance.getPropertyGet( dataRow1, "field1", info );
        JexlPropertyGet getter2 = instance.getPropertyGet( dataRow2, "field1", info );

        // Then
        assertThat( getter1 ).isNotEqualTo( getter2 );
    }

    // Same field in same table, same accessor
    // Same table, different fields, different accessor
    @Test()
    @Ignore("This version does not cache the accessor.")
    public void testGivenTableWithField_WhenGetterRequiredManyTimes_ThenSameGetterReturned() throws Exception {
        // Given
        DataRow dataRow1 = mock( DataRow.class );

        DataTable dataTable1 = mock( DataTable.class );

        when( dataRow1.getDataTable() ).thenReturn( dataTable1 );
        when( dataTable1.getName() ).thenReturn( "Table1" );

        // When request Getter
        JexlPropertyGet getter1 = instance.getPropertyGet( dataRow1, "field1", info );
        JexlPropertyGet getter2 = instance.getPropertyGet( dataRow1, "field1", info );

        // Then
        assertThat( getter1 ).isSameAs( getter2 );
    }

}
