package com.monsanto.metricspos.scriptengine.jexl;

import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.math.MathContext;

/**
 * Test null and exception cases in NarrowerJexlArithmetic
 *
 * @author cafau
 */
public class NarrowerJexlArithmetic_SpecialCases_UT {

    private NarrowerJexlArithmetic instance;

    @Before
    public void setUp() throws Exception {
        MathContext mathContext = new MathContext(10);

        instance = new NarrowerJexlArithmetic(mathContext);
    }

    @Test(expected = ArithmeticException.class)
    public void testGivenNullOperands_WhenDivide_ThenThrowException() throws Exception {
        // given
        Object dividend = null;
        Object divisor = null;

        // when
        instance.divide(dividend, divisor);
    }

    @Test(expected = ArithmeticException.class)
    public void testGivenZeroDivisor_WhenDivide_ThenThrowException() throws Exception {
        // given
        Object dividend = BigDecimal.valueOf(120);
        Object divisor = BigDecimal.ZERO;

        // when
        instance.divide(dividend, divisor);
    }


}
