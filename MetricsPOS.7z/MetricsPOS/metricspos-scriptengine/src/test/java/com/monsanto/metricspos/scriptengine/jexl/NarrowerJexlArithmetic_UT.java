package com.monsanto.metricspos.scriptengine.jexl;

import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Collection;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Test new methods in NarrowerJexlArithmetic class
 *
 * @author cafau
 */
@RunWith(Parameterized.class)
public class NarrowerJexlArithmetic_UT {
    private static final int DIVISOR = 7;
    private static final long LONG_DIVISOR = 70000000000L;

    private NarrowerJexlArithmetic instance;

    private Number divisor;
    private Number dividend;
    private Number expected;

    @Parameterized.Parameters
    public static Collection data() {
        return Lists.newArrayList(new Object[][]
             {  {9 * DIVISOR, DIVISOR, 9}
             ,  {9 * LONG_DIVISOR, LONG_DIVISOR, 9}
             ,  {9 * LONG_DIVISOR, (long) DIVISOR, 9 * (LONG_DIVISOR / DIVISOR)}
             ,  {7, 14,              BigDecimal.valueOf(50, 2) }
             ,  {7 * LONG_DIVISOR, 14 * LONG_DIVISOR, BigDecimal.valueOf(50, 2) }
             ,  {7.0, 14.0, 0.5}
             ,  {7.0f, 14.0f, (double) 0.5f}
             ,  { BigDecimal.valueOf( 7 ),          BigDecimal.valueOf( 14 ),         BigDecimal.valueOf(5, 1) }
             });
    }

    @Before
    public void setUp() throws Exception {
        MathContext mathContext = new MathContext(10);

        instance = new NarrowerJexlArithmetic(mathContext);
    }


    public NarrowerJexlArithmetic_UT(Number dividend, Number divisor, Number expected) {
        this.divisor = divisor;
        this.dividend = dividend;
        this.expected = expected;
    }

    // Integer division --> Integer
    @Test
    public void testGivenAnDividendAndDivisor_WhenDivide_ThenExpectedResult() throws Exception {
        // given divisor, dividend

        // when
        Object result = instance.divide( dividend, divisor );

        // then
        String description = typeName(dividend) + " / " + typeName(divisor) + " = " + typeName(expected);
        assertThat(result).as(description).isInstanceOf( expected.getClass() ).isEqualTo(expected);
    }

    private String typeName(Object object) {
        return object == null ? "NULL" : object.getClass().getSimpleName();
    }


}
