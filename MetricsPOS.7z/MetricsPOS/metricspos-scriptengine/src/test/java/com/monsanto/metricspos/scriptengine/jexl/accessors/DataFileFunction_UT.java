package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.externaldata.DataFile;
import com.monsanto.metricspos.scriptengine.jexl.functions.DataFileFunction;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class DataFileFunction_UT {

    private DataFileFunction dataFileFunction;

    @Test
    public void testLoadCreatesNewDataFileWithNameFile1_WhenLoadingAFileWithNameFile1() {
        // @Given a filename File1
        String fileName = "File1";
        byte[] fileData = "anything".getBytes();
        this.dataFileFunction = new DataFileFunction();

        // @When loading a file with that name
        DataFile dataFile = dataFileFunction.load(fileName, fileData);

        // @Then a dataFile with that name is returned
        assertThat(dataFile.getFileName()).isEqualTo(fileName);
        assertThat(dataFile.getFileData()).isEqualTo(fileData);
    }

    @Test
    public void testLoadCreatesNewDataFileWithNameCharly_WhenLoadingAFileWithNameCharly() {
        // @Given a filename File1
        String fileName = "Charly";
        byte[] fileData = "something".getBytes();
        this.dataFileFunction = new DataFileFunction();

        // @When loading a file with that name
        DataFile dataFile = dataFileFunction.load(fileName, fileData);

        // @Then a dataFile with that name is returned
        assertThat(dataFile.getFileName()).isEqualTo(fileName);
        assertThat(dataFile.getFileData()).isEqualTo(fileData);
    }
}
