package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import org.junit.Before;
import org.junit.Test;

import javax.sql.RowSet;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;

/**
 * Test the DataRowAccessorFactory class
 *
 * @author cafau
 */
public class DataRowAccessorFactory_UT {

    private DataRowAccessorFactory instance;

    @Before
    public void setUp() throws Exception {
        instance = new DataRowAccessorFactory();
    }

    @Test
    public void testGivenRowSetObject_WhenAskForAccessor_ThenReturnAccessor() throws Exception {
        // @Given
        DataRow object = mock(DataRow.class);

        // @When
        FieldAccessor accessor = instance.accessorFor(object, "theName");

        // @Then
        assertThat(accessor).isNotNull().isInstanceOf(DataRowFieldAccessor.class);
    }

    @Test
    public void testGivenRowSetObject_WhenAccess_ThenAnswerTrue() throws Exception {
        // @Given
        Object object = mock(DataRow.class);

        // @When
        boolean result = instance.access(object);

        // @Then
        assertThat(result).isTrue();
    }

    @Test
    public void testGivenNoRowSetObject_WhenAccess_ThenAnswerFalse() throws Exception {
        // @Given
        Object object = mock(RowSet.class);

        // @When
        boolean result = instance.access(object);

        // @Then
        assertThat(result).isFalse();
    }

}
