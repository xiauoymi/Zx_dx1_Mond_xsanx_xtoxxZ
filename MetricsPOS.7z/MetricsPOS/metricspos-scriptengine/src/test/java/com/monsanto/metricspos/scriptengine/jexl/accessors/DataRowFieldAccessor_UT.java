package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.MissingColumnException;
import org.junit.Before;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.*;

/**
 * Test the DataRowFieldAccessor class
 *
 * @author cafau
 */
public class DataRowFieldAccessor_UT {

    private static final String DATA_TABLE_NAME = "dataTableName";
    private static final String FIELD_NAME = "field1";

    private DataRowFieldAccessor instance;

    private DataRow dataRow;

    @Before
    public void setUp() throws Exception {
        instance = new DataRowFieldAccessor(FIELD_NAME, Integer.class);

        DataTable dataTable = mock(DataTable.class);
        dataRow = mock(DataRow.class);

        when(dataTable.getName()).thenReturn(DATA_TABLE_NAME);
        when(dataRow.getDataTable()).thenReturn(dataTable);
    }

    @Test
    public void testInvokeGetWithValue() throws Exception {
        // Given
        when(dataRow.get(FIELD_NAME)).thenReturn(12);

        // when
        Object result = instance.invoke( dataRow );

        // then
        assertThat( result ).isInstanceOf(Integer.class).isEqualTo(12);
    }

    @Test
    public void testInvokeGetWithNullValue() throws Exception {
        // Given
        when(dataRow.get(FIELD_NAME)).thenReturn(null);

        // when
        Object result = instance.invoke( dataRow );

        // then
        assertThat( result ).isNull();
    }

    @Test
    public void testTryInvokeGetWithValueOnCorrectField() throws Exception {
        // Given
        when(dataRow.get(FIELD_NAME)).thenReturn(12);

        // when
        Object result = instance.tryInvoke(dataRow, FIELD_NAME);

        // then
        assertThat( result ).isInstanceOf(Integer.class).isEqualTo( 12 );
    }

    @Test
    public void testTryInvokeGetWithValueOnIncorrectField() throws Exception {
        // Given a data row getter setter for field "field1"
        when(dataRow.get(FIELD_NAME)).thenReturn(12);

        // when try invoke with different field name
        Object result = instance.tryInvoke( dataRow, "OtherField" );

        // then the try fails
        assertThat( instance.tryFailed(result) ).isTrue();

    }

    @Test
    public void testInvokeSetWithCorrectValue() throws Exception {
        // Given DataRowFieldAccessor for field field1

        // when
        Integer value = 49;
        instance.tryInvoke(dataRow, FIELD_NAME, value);

        // then
        verify( dataRow ).set( FIELD_NAME, value );
    }

    @Test
    public void testIsCacheable() throws Exception {
        assertThat( instance.isCacheable() ).isTrue();
    }

    @Test
    public void testGivenMissingFieldName_WhenGetField_ThenReturnFailed() throws Exception {
        // @Given
        when(dataRow.get(FIELD_NAME)).thenThrow(new MissingColumnException());

        // when
        Object result = instance.tryInvoke(dataRow, FIELD_NAME);

        // then
        assertThat( instance.tryFailed(result) ).isTrue();
    }

    @Test
    public void testGivenMissingFieldName_WhenSetField_ThenReturnFailed() throws Exception {
        // @Given
        doThrow(new MissingColumnException()).when(dataRow).set(eq(FIELD_NAME), any());

        // when
        Object result = instance.tryInvoke(dataRow, FIELD_NAME, 10);

        // then
        assertThat( instance.tryFailed(result) ).isTrue();
    }

}
