package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import org.junit.Test;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;


/**
 * User: PPERA
 */
public class EmployeeFieldAccessorFactory_UT {

    private EmployeeFieldAccessorFactory employeeFieldAccessorFactory;

    @Test
    public void testEmployeeFieldAccessorFactory() {
        employeeFieldAccessorFactory = new EmployeeFieldAccessorFactory();

        FieldAccessor f = employeeFieldAccessorFactory.accessorFor(mock(Employee.class), "test");
        assertNotNull(f);

        assertTrue(employeeFieldAccessorFactory.access(mock(Employee.class)));

        assertFalse(employeeFieldAccessorFactory.access(mock(Object.class)));
    }

}
