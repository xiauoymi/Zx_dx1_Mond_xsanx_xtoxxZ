package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.junit.Before;
import org.junit.Test;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class GenericBeanFieldAccessor_UT {

    private GenericBeanFieldAccessor instance;
    private PointOfSale pointOfSale;


    @Before
    public void setUp() throws Exception {
        Campaign campaign = new Campaign("name", newDate(2015, 4, 8), newDate(2016, 2, 3));
        this.instance = new GenericBeanFieldAccessor("idSap", campaign, PointOfSale.class);
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        this.pointOfSale = new PointOfSale();
        this.pointOfSale.setIdSap(12l);
                                                     }

    @Test
    public void testInvokeGetWithValue() throws Exception {
        // Given

        // when
        Object result = instance.invoke(this.pointOfSale);

        // then
        assertThat(result).isInstanceOf(Long.class).isEqualTo(12l);
    }

    @Test
    public void testInvokeGetWithNullValue() throws Exception {
        // Given
        this.pointOfSale.setIdSap(null);

        // when
        Object result = instance.invoke(this.pointOfSale);

        // then
        assertThat(result).isNull();
    }

    @Test
    public void testTryInvokeGetWithValueOnCorrectField() throws Exception {
        // Given

        // when
        Object result = instance.tryInvoke(this.pointOfSale, "idSap");

        // then
        assertThat(result).isInstanceOf(Long.class).isEqualTo(12l);
    }

    @Test
    public void testIsNotCacheable() throws Exception {
        assertThat(instance.isCacheable()).isFalse();
    }

    @Test
    public void testGivenMissingFieldName_WhenGetField_ThenReturnFailed() throws Exception {
        // @Given

        // when
        Object result = instance.tryInvoke(this.pointOfSale, "missingField");

        // then
        assertThat(instance.tryFailed(result)).isTrue();
    }

    @Test
    public void testInvokeWithWritableObjectValue() throws Exception {
        // when
        Object result = instance.invoke(this.pointOfSale, 425L);

        // then
        assertThat(result).isInstanceOf(Long.class).isEqualTo(425L);
    }

    @Test
    public void testTryInvokeWithWritableObjectValue() throws Exception {
        // when
        Object result = instance.tryInvoke(this.pointOfSale, "address", "Boedo");

        // then
        assertThat(result).isInstanceOf(String.class).isEqualTo("Boedo");
    }

}
