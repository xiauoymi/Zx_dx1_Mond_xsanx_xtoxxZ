package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import org.junit.Before;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class PointOfSaleFieldAccessorFactory_UT {
    private PointOfSaleFieldAccessorFactory instance;
    private PointOfSale pointOfSale;

    @Before
    public void setUp() throws Exception {
        this.instance = new PointOfSaleFieldAccessorFactory();
        this.pointOfSale = new PointOfSale();
    }

    @Test
    public void testGivenPointOfSaleObject_WhenAskForAccessor_ThenReturnAccessor() throws Exception {
        // @Given

        // @When
        FieldAccessor accessor = instance.accessorFor(this.pointOfSale, "idSap");

        // @Then
        assertThat(accessor).isNotNull().isInstanceOf(GenericBeanFieldAccessor.class);
    }

    @Test
    public void testGivenPointOfSaleObject_WhenAccess_ThenAnswerTrue() throws Exception {
        // @Given

        // @When
        boolean result = instance.access(this.pointOfSale);

        // @Then
        assertThat(result).isTrue();
    }

    @Test
    public void testGivenNoResultSetWrappingPointOfSaleObject_WhenAccess_ThenAnswerFalse() throws Exception {
        // @Given
        Object object = "pepe"; // String

        // @When
        boolean result = instance.access(object);

        // @Then
        assertThat(result).isFalse();
    }
}
