package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.externaldata.MissingColumnException;
import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSet;

import javax.naming.OperationNotSupportedException;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: PPERA
 */
public class ResultSetWrappingSqlRowSetAccesor_UT {

    private static final String FIELD_NAME = "field1";

    private ResultSetWrappingSqlRowSetAccessor instance;

    private ResultSetWrappingSqlRowSet rowSet;

    @Before
    public void setUp() throws Exception {
        instance = new ResultSetWrappingSqlRowSetAccessor(FIELD_NAME);

        ResultSet resultSet = mock(ResultSet.class);
        ResultSetMetaData metaData = mock(ResultSetMetaData.class);
        when(resultSet.getMetaData()).thenReturn(metaData);
        rowSet = new ResultSetWrappingSqlRowSet(resultSet);

    }

    @Test
    public void testInvokeGetWithValue() throws Exception {
        // Given
        when(rowSet.getObject(FIELD_NAME)).thenReturn(12);

        // when
        Object result = instance.invoke(rowSet);

        // then
        assertThat(result).isInstanceOf(Integer.class).isEqualTo(12);
    }

    @Test
    public void testInvokeGetWithNullValue() throws Exception {
        // Given
        when(rowSet.getObject(FIELD_NAME)).thenReturn(null);

        // when
        Object result = instance.invoke(rowSet);

        // then
        assertThat(result).isNull();
    }

    @Test
    public void testTryInvokeGetWithValueOnCorrectField() throws Exception {
        // Given
        when(rowSet.getObject(FIELD_NAME)).thenReturn(12);

        // when
        Object result = instance.tryInvoke(rowSet, FIELD_NAME);

        // then
        assertThat(result).isInstanceOf(Integer.class).isEqualTo(12);
    }

    @Test
    public void testTryInvokeGetWithValueOnIncorrectField() throws Exception {
        // Given a data row getter setter for field "field1"
        when(rowSet.getObject(FIELD_NAME)).thenReturn(12);

        // when try invoke with different field name
        Object result = instance.tryInvoke(rowSet, "OtherField");

        // then the try fails
        assertThat(instance.tryFailed(result)).isTrue();

    }

    @Test
    public void testGivenCorrectValue_WhenInvokeTrySet_ThenFail() throws Exception {
        // Given DataRowFieldAccessor for field field1

        // when
        Integer value = 49;
        Object result = instance.tryInvoke(rowSet, FIELD_NAME, value);

        // then Always Fail in Set
        assertThat(instance.tryFailed(result)).isTrue();
    }

    @Test(expected = OperationNotSupportedException.class)
    public void testGivenCorrectValue_WhenInvokeSet_ThenFail() throws Exception {
        // Given DataRowFieldAccessor for field field1

        // when
        Integer value = 49;
        instance.invoke(rowSet, value);

        // then Always Fail in Set
    }

    @Test
    public void testIsCacheable() throws Exception {
        assertThat(instance.isCacheable()).isTrue();
    }

    @Test
    public void testGivenMissingFieldName_WhenGetField_ThenReturnFailed() throws Exception {
        // @Given
        when(rowSet.getObject(FIELD_NAME)).thenThrow(new MissingColumnException());

        // when
        Object result = instance.tryInvoke(rowSet, FIELD_NAME);

        // then
        assertThat(instance.tryFailed(result)).isTrue();
    }
}
