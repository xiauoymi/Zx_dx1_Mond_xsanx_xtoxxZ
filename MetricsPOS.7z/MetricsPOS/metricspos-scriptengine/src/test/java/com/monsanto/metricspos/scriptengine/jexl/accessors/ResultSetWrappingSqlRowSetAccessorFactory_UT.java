package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.scriptengine.jexl.FieldAccessor;
import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.support.rowset.ResultSetWrappingSqlRowSet;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;

/**
 * User: PPERA
 */
public class ResultSetWrappingSqlRowSetAccessorFactory_UT {
    private ResultSetWrappingSqlRowSetAccessorFactory instance;

    @Before
    public void setUp() throws Exception {
        instance = new ResultSetWrappingSqlRowSetAccessorFactory();
    }

    @Test
    public void testGivenResultSetWrappingSqlRowSetObject_WhenAskForAccessor_ThenReturnAccessor() throws Exception {
        // @Given
        Object object = mock(ResultSetWrappingSqlRowSet.class);

        // @When
        FieldAccessor accessor = instance.accessorFor(object, "theName");

        // @Then
        assertThat(accessor).isNotNull().isInstanceOf(ResultSetWrappingSqlRowSetAccessor.class);
    }

    @Test
    public void testGivenResultSetWrappingSqlRowSetObject_WhenAccess_ThenAnswerTrue() throws Exception {
        // @Given
        Object object = mock(ResultSetWrappingSqlRowSet.class);

        // @When
        boolean result = instance.access(object);

        // @Then
        assertThat(result).isTrue();
    }

    @Test
    public void testGivenNoResultSetWrappingSqlRowSetObject_WhenAccess_ThenAnswerFalse() throws Exception {
        // @Given
        Object object = "pepe"; // String

        // @When
        boolean result = instance.access(object);

        // @Then
        assertThat(result).isFalse();
    }

}
