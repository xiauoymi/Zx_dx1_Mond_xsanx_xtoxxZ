package com.monsanto.metricspos.scriptengine.jexl.accessors;

import com.monsanto.metricspos.core.externaldata.MissingColumnException;
import org.junit.Before;
import org.junit.Test;

import javax.naming.OperationNotSupportedException;
import javax.sql.RowSet;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Test the RowSetAccessor class
 *
 * @author cafau
 */
public class RowSetAccessor_UT {

    private static final String FIELD_NAME = "field1";

    private RowSetAccessor instance;

    private RowSet rowSet;

    @Before
    public void setUp() throws Exception {
        instance = new RowSetAccessor(FIELD_NAME);

        rowSet = mock(RowSet.class);
    }

    @Test
    public void testInvokeGetWithValue() throws Exception {
        // Given
        when(rowSet.getObject(FIELD_NAME)).thenReturn(12);

        // when
        Object result = instance.invoke(rowSet);

        // then
        assertThat( result ).isInstanceOf(Integer.class).isEqualTo(12);
    }

    @Test
    public void testInvokeGetWithNullValue() throws Exception {
        // Given
        when(rowSet.getObject(FIELD_NAME)).thenReturn(null);

        // when
        Object result = instance.invoke(rowSet);

        // then
        assertThat( result ).isNull();
    }

    @Test
    public void testTryInvokeGetWithValueOnCorrectField() throws Exception {
        // Given
        when(rowSet.getObject(FIELD_NAME)).thenReturn(12);

        // when
        Object result = instance.tryInvoke(rowSet, FIELD_NAME);

        // then
        assertThat( result ).isInstanceOf(Integer.class).isEqualTo( 12 );
    }

    @Test
    public void testTryInvokeGetWithValueOnIncorrectField() throws Exception {
        // Given a data row getter setter for field "field1"
        when(rowSet.getObject(FIELD_NAME)).thenReturn(12);

        // when try invoke with different field name
        Object result = instance.tryInvoke(rowSet, "OtherField" );

        // then the try fails
        assertThat( instance.tryFailed(result) ).isTrue();

    }

    @Test
    public void testGivenCorrectValue_WhenInvokeTrySet_ThenFail() throws Exception {
        // Given DataRowFieldAccessor for field field1

        // when
        Integer value = 49;
        Object result = instance.tryInvoke(rowSet, FIELD_NAME, value);

        // then Always Fail in Set
        assertThat(instance.tryFailed(result)).isTrue();
    }

    @Test(expected = OperationNotSupportedException.class)
    public void testGivenCorrectValue_WhenInvokeSet_ThenFail() throws Exception {
        // Given DataRowFieldAccessor for field field1

        // when
        Integer value = 49;
        instance.invoke(rowSet, value);

        // then Always Fail in Set
    }

    @Test
    public void testIsCacheable() throws Exception {
        assertThat( instance.isCacheable() ).isTrue();
    }

    @Test
    public void testGivenMissingFieldName_WhenGetField_ThenReturnFailed() throws Exception {
        // @Given
        when(rowSet.getObject(FIELD_NAME)).thenThrow(new MissingColumnException());

        // when
        Object result = instance.tryInvoke(rowSet, FIELD_NAME);

        // then
        assertThat( instance.tryFailed(result) ).isTrue();
    }

    @Test
    public void testGivenMissingFieldName_WhenSetField_ThenReturnFailed() throws Exception {
        // @Given
        doThrow(new MissingColumnException()).when(rowSet).setObject(eq(FIELD_NAME), any());

        // when
        Object result = instance.tryInvoke(rowSet, FIELD_NAME, 10);

        // then
        assertThat( instance.tryFailed(result) ).isTrue();
    }

}
