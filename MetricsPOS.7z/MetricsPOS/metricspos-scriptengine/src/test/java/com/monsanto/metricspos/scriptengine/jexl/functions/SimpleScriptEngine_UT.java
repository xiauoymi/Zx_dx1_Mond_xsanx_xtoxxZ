package com.monsanto.metricspos.scriptengine.jexl.functions;

import com.monsanto.metricspos.scriptengine.ScriptEngine;
import com.monsanto.metricspos.scriptengine.jexl.SimpleScriptEngineFactory;
import org.apache.commons.jexl2.JexlEngine;
import org.junit.Test;
import static org.mockito.Mockito.*;
import static org.junit.Assert.*;

/**
 *
 * @author shelg
 */
public class SimpleScriptEngine_UT {


    @Test
    public void testSimpleScriptEngine() throws Exception {
        SimpleScriptEngineFactory instance = new SimpleScriptEngineFactory();
        instance.setEngine(mock(JexlEngine.class));
        ScriptEngine result = instance.buildFor("Select * from table");
        assertNotNull(result);
    }
}
