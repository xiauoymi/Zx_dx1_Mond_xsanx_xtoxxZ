package com.monsanto.metricspos.scriptengine.managers;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.metrics.Score;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.scriptengine.ScriptEngine;
import com.monsanto.metricspos.scriptengine.exceptions.MetricComputeException;
import com.monsanto.metricspos.scriptengine.jexl.SimpleScriptEngineFactory;
import org.apache.commons.jexl2.JexlEngine;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;
import org.mockito.Mockito;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Mockito.*;

/**
 * Test the ScriptedComputeManager class
 *
 * @author cafau
 */
public class ScriptedComputeManager_UT {

    private ScoreServices scoreServices;
    private SimpleScriptEngineFactory scriptEngineFactory;

    private ScriptedComputeManager instance;
    private Metric metric;
    private Campaign campaign;

    @Before
    public void setUp() throws Exception {

        scoreServices = mock(ScoreServices.class);
        scriptEngineFactory = mock(SimpleScriptEngineFactory.class);

        instance = new ScriptedComputeManager();

        // Inject dependencies
        instance.setScoreServices(scoreServices);
        instance.setScriptEngineFactory(scriptEngineFactory);

        campaign = new Campaign("campaign", newDate(1, 1, 1), newDate(2, 1, 1));
        campaign.setId(1);
        metric = new Metric(campaign, "Test metric");

/*        when(scoreServices.newMetricScore(any(Metric.class), Matchers.<ServiceCenter>any(ServiceCenter.class)))
                .thenAnswer( new Answer<MetricScore>() {
                    @Override
                    public MetricScore answer(InvocationOnMock invocation) throws Throwable {
                        Metric metric = (Metric) invocation.getArguments()[0];
                        ServiceCenter serviceCenter = (ServiceCenter) invocation.getArguments()[1];
                        return new MetricScore(metric, serviceCenter);
                    }
                });*/
    }


    @Test
    public void testGivenNoServiceCenters_WhenExecute_ThenNoScoresComputed() throws Exception {
        // given
        Set<MetricScore> scores = Collections.EMPTY_SET;

        metric.setScores(scores);
        metric.setFormula("something");

        // then
        long computations = instance.compute(metric);

        // then
        assertThat(computations).isEqualTo(0);
    }

    @Test(expected = MetricComputeException.class)
    public void testGivenNullScript_WhenExecute_ThenThrowException() throws Exception {
        // given
        metric.setFormula(null);

        // then
        instance.compute(metric);

        // then throw
    }

    @Test
    public void testGivenAServiceCenterWithoutScore_WhenExecute_ThenCreateNewScore() throws Exception {
        Set<MetricScore> scores = Collections.EMPTY_SET;

        ServiceCenter serviceCenter = newServiceCenter("10", "A service center");
        serviceCenter.setCampaign(campaign);

        List<ServiceCenter> serviceCenters = Lists.newArrayList(serviceCenter);

        MetricScore metricScore = new MetricScore(metric, serviceCenter);
        when(scoreServices.newMetricScore(metric, serviceCenter)).thenReturn(metricScore);

        campaign.setServiceCenters(serviceCenters);
        metric.setScores(scores);
        metric.setMaxPoints(500);
        metric.setFormula("something");

        ScriptEngine engine = mock(ScriptEngine.class);
        when(scriptEngineFactory.buildFor("something")).thenReturn(engine);

        // then
        long computations = instance.compute(metric);

        // then
        assertThat(computations).isEqualTo(1);
        verify(engine, times(1)).execute(anyMap());
    }

    @Test
    public void testGivenAServiceCenterWithDirtyScore_WhenExecute_ThenComputeScoreAndSetPoints() throws Exception {

        ServiceCenter serviceCenter = newServiceCenter("10", "A service center");
        serviceCenter.setCampaign(campaign);
        MetricScore score = new MetricScore(metric, serviceCenter);

        score.setPoints(BigDecimal.valueOf(12));
        score.setDirty(true);

        Set<MetricScore> scores = Sets.newHashSet(score);

        List<ServiceCenter> serviceCenters = Lists.newArrayList(serviceCenter);

        MetricScore metricScore = new MetricScore(metric, serviceCenter);
        when(scoreServices.newMetricScore(metric, serviceCenter)).thenReturn(metricScore);

        campaign.setServiceCenters(serviceCenters);
        metric.setScores(scores);
        metric.setFormula("something");
        metric.setMaxPoints(500);

        ScriptEngine engine = new ScriptEngineStub(1, 34, 12, 25);

        when(scriptEngineFactory.buildFor("something")).thenReturn(engine);

        // then
        long computations = instance.compute(metric);

        // then
        assertThat(computations).isEqualTo(1);
        assertThat(score.isDirty()).isFalse();
        assertThat(score.getPoints()).isEqualTo(BigDecimal.valueOf(34));
        assertThat(score.getPenalty()).isEqualTo(BigDecimal.valueOf(12));
        assertThat(score.getPenaltyFactor()).isEqualTo(BigDecimal.valueOf(25));
    }

    @Test
    @Ignore
    public void testGivenAServiceCenterWithNotDirtyScore_WhenExecute_ThenNoCompute() throws Exception {
        // given
        ServiceCenter serviceCenter = newServiceCenter("10", "A service center");
        MetricScore score = new MetricScore(metric, serviceCenter);

        score.setPoints(BigDecimal.valueOf(12));
        score.setDirty(false);

        Set<MetricScore> scores = Sets.newHashSet(score);

        List<ServiceCenter> serviceCenters = Lists.newArrayList(serviceCenter);

        MetricScore metricScore = new MetricScore(metric, serviceCenter);
        when(scoreServices.newMetricScore(metric, serviceCenter)).thenReturn(metricScore);

        campaign.setServiceCenters(serviceCenters);
        metric.setScores(scores);
        metric.setFormula("something");

        ScriptEngine engine = mock(ScriptEngine.class);
        when(scriptEngineFactory.buildFor("something")).thenReturn(engine);

        // then
        long computations = instance.compute(metric);

        // then
        assertThat(computations).isEqualTo(0);
        verify(engine, never()).execute(anyMap());
    }

    private static ServiceCenter newServiceCenter(String cuit, String name) {
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setName(name);
        serviceCenter.setCuit(cuit);
        return serviceCenter;
    }

    private static class ScriptEngineStub extends ScriptEngine {
        int calls = 0;

        int times;
        int points;
        int penalty;
        int penaltyFactor;

        public ScriptEngineStub(int times, int points, int penalty, int penaltyFactor) {
            super(Mockito.mock(JexlEngine.class), null);
            this.times = times;
            this.points = points;
            this.penalty = penalty;
            this.penaltyFactor = penaltyFactor;
        }

        @Override
        public Object execute(Map<String, Object> arguments) {

            if (++calls > times) {
                fail("Only " + times + " time(s) should be called");
            }

            Score score = (Score) arguments.get(ScriptedComputeManager.SCORE_VARIABLE_NAME);

            if (score == null) {
                fail("Score should be provided by manager");
            }

            score.setPoints(BigDecimal.valueOf(points));
            score.setPenalty(BigDecimal.valueOf(penalty));
            score.setPenaltyFactor(BigDecimal.valueOf(penaltyFactor));

            return "OK";
        }
    }

    @Test
    public void testComputeCampaignRatingBuildsAnEngineForTheRatingFormula_WhenComputingRatings() {
        // @Given a campaign with a rating formula
        String script = "Hello";
        campaign.setRatingFormula(script);
        ScriptEngine scriptEngine = mock(ScriptEngine.class);
        when(scriptEngineFactory.buildFor(script)).thenReturn(scriptEngine);
        ScoreSummaryCampaignNode summary = mock(ScoreSummaryCampaignNode.class);

        // @When computing the ratings
        this.instance.compute(campaign, summary);

        // @Then a script engine is created for that formula
        verify(scriptEngineFactory, times(1)).buildFor(script);
    }

    @Test
    public void testComputeCampaignRatingBuildsAnEngineForTheRatingFormulaAndExecuteItWithPointsAsArguments_WhenComputingRatings() {
        // @Given a campaign with a rating formula
        String script = "Hello";
        campaign.setRatingFormula(script);
        ScriptEngine scriptEngine = mock(ScriptEngine.class);
        when(scriptEngineFactory.buildFor(script)).thenReturn(scriptEngine);
        Map<String, Object> arguments = Maps.newHashMap();
        final BigDecimal points = BigDecimal.valueOf(10);
        arguments.put("totalPoints", points);
        ScoreSummaryCampaignNode summary = mock(ScoreSummaryCampaignNode.class);
        when(summary.getPoints()).thenReturn(points);
        arguments.put("summary", summary);

        // @When computing the ratings
        this.instance.compute(campaign, summary);

        // @Then a script engine is created for that formula
        verify(scriptEngine, times(1)).execute(Mockito.argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return ((Map<String, Object>) argument).get("totalPoints").equals(points);
            }
        }));
    }

    @Test
    public void testComputeModuleFormula() throws Exception {
        ScriptEngine engine = mock(ScriptEngine.class);
        ScoreSummaryCampaignNode summary = mock(ScoreSummaryCampaignNode.class);
        ScoreSummaryNode moduleNode = mock(ScoreSummaryNode.class);
        metric.setFormula("return 107;");

        when(scriptEngineFactory.buildFor(metric.getFormula())).thenReturn(engine);
        when(moduleNode.getMetric()).thenReturn(metric);

        ServiceCenter serviceCenter = newServiceCenter("10", "A service center");
        serviceCenter.setCampaign(campaign);

        this.instance.computeModuleFormula(moduleNode);
        verify(engine, times(1)).execute(Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testComputeMetricTypeFormula() throws Exception {
        // given
        ServiceCenter serviceCenter = newServiceCenter("10", "A service center");
        MetricScore score = new MetricScore(metric, serviceCenter);
        score.setPoints(BigDecimal.valueOf(12));
        score.setDirty(false);
        Set<MetricScore> scores = Sets.newHashSet(score);
        List<ServiceCenter> serviceCenters = Lists.newArrayList(serviceCenter);
        MetricScore metricScore = new MetricScore(metric, serviceCenter);
        when(scoreServices.newMetricScore(metric, serviceCenter)).thenReturn(metricScore);

        campaign.setServiceCenters(serviceCenters);
        metric.setScores(scores);
        metric.setType(1);
        metric.setFormula("return metricType");

        ScriptEngine engine = mock(ScriptEngine.class);
        when(scriptEngineFactory.buildFor(metric.getFormula())).thenReturn(engine);
        // then
        long computations = instance.compute(metric);
        // then
        assertThat(computations).isEqualTo(1);
        verify(engine, never()).execute(anyMap());
    }

}
