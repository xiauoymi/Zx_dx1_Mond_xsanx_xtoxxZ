package com.monsanto.metricspos.scriptengine.managers;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.TableAdapter;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.scriptengine.ExternalDataQueryExecutor;
import com.monsanto.metricspos.scriptengine.ScriptEngine;
import com.monsanto.metricspos.scriptengine.ScriptEngineFactory;
import com.monsanto.metricspos.scriptengine.exceptions.CannotLoadTable;
import org.apache.commons.jexl2.JexlEngine;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.Map;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Test the ScriptedLoadManager class
 *
 * @author cafau
 */
public class ScriptedLoadManager_UT {

    private ScriptedLoadManager instance;


    @Before
    public void setUp() throws Exception {
        instance = new ScriptedLoadManager();
    }

    @Test
    public void testGivenSourceWithNoRecord_WhenExecuteLoad_ThenTheScriptIsNotProcessed() throws Exception {
        // given
        DataProvider provider = new DataProvider();
        String sql ="an sql";
        String script ="an script";

        TableAdapter<String> tableAdapter = buildTableAdapter(provider, sql, script);

        ExternalDataQueryExecutor executor = mock(ExternalDataQueryExecutor.class);
        ScriptEngineFactory scriptEngineFactory = mock(ScriptEngineFactory.class);

        initializeInstance(executor, scriptEngineFactory);

        // when
        instance.load( tableAdapter );

        // then
        verify(tableAdapter, times(1)).markAllRecordsAsNotLoaded();
        verify(executor, times(1)).execute(any(DataProvider.class), anyString());
        verify(scriptEngineFactory, never()).buildFor(anyString());
        verify(tableAdapter, times(1)).removeAllUnloadedRecords();
    }

    @Test
    public void testGivenSourceWithOneRecord_WhenExecuteLoad_ThenTheScriptIsExecutedOnce() throws Exception {
        // given
        DataProvider provider = new DataProvider();
        String sql ="an sql";
        String script="do something";

        TableAdapter<String> tableAdapter = buildTableAdapter(provider, sql, script);

        ExternalDataQueryExecutor executor = mock(ExternalDataQueryExecutor.class);

        Iterable recordsIterator = Lists.newArrayList("One");

        when(executor.execute(provider, sql)).thenReturn( recordsIterator );

        ScriptEngineFactory scriptEngineFactory = mock(ScriptEngineFactory.class);
        ScriptEngine scriptEngine = mock(ScriptEngine.class);

        when(scriptEngineFactory.buildFor(script)).thenReturn(scriptEngine);
        when(scriptEngine.execute(anyMap() )).thenReturn( "The result" );

        initializeInstance(executor, scriptEngineFactory);

        // when
        long processed = instance.load( tableAdapter );

        // then
        assertThat( processed ).isEqualTo(1);

        verify(tableAdapter, times(1)).markAllRecordsAsNotLoaded();
        verify(executor, times(1)).execute(any(DataProvider.class), anyString());
        verify(scriptEngineFactory, times(1)).buildFor(script);
        verify(scriptEngine, times(1)).execute(anyMap());
        verify(tableAdapter, times(1)).markAsLoaded("The result");
    }

    @Test
    public void testGivenSourceWithOneRecordSkipable_WhenExecuteLoad_ThenTheScriptIsExecutedButNotPersisted() throws Exception {
        // given
        DataProvider provider = new DataProvider();
        String sql ="an sql";
        String script="do something";

        TableAdapter<String> tableAdapter = buildTableAdapter(provider, sql, script);

        ExternalDataQueryExecutor executor = mock(ExternalDataQueryExecutor.class);

        Iterable recordsIterator = Lists.newArrayList("One");

        when(executor.execute(provider, sql)).thenReturn( recordsIterator );

        ScriptEngineFactory scriptEngineFactory = mock(ScriptEngineFactory.class);
        JexlEngine engine = mock(JexlEngine.class);

        ScriptEngine scriptEngine = new ScriptEngine(engine, script){
            @Override
            public Object execute(Map<String, Object> arguments) {
                return arguments.get(ScriptedLoadManager.SKIP);
            }
        };

        when(scriptEngineFactory.buildFor(script)).thenReturn(scriptEngine);

        initializeInstance(executor, scriptEngineFactory);

        // when
        long processed = instance.load( tableAdapter );

        // then
        assertThat( processed ).isEqualTo(0);

        verify(tableAdapter, times(1)).markAllRecordsAsNotLoaded();
        verify(executor, times(1)).execute(any(DataProvider.class), anyString());
        verify(scriptEngineFactory, times(1)).buildFor(script);
        verify(tableAdapter, never()).markAsLoaded(Matchers.<String>any());
    }

    @Test
    public void testGivenSourceWithThreeRecords_WhenExecuteLoad_ThenTheScriptIsExecutedThreeTimes() throws Exception {
        // given
        DataProvider provider = new DataProvider();
        String sql ="an sql";
        String script="do something";

        TableAdapter<String> tableAdapter = buildTableAdapter(provider, sql, script);

        ExternalDataQueryExecutor executor = mock(ExternalDataQueryExecutor.class);

        Iterable recordsIterator = Lists.newArrayList("One", "Two", "Three");

        when(executor.execute(provider, sql)).thenReturn( recordsIterator );

        ScriptEngineFactory scriptEngineFactory = mock(ScriptEngineFactory.class);
        ScriptEngine scriptEngine = mock(ScriptEngine.class);

        when(scriptEngineFactory.buildFor(script)).thenReturn(scriptEngine);
        when(scriptEngine.execute(anyMap() )).thenReturn( "The result" );

        initializeInstance(executor, scriptEngineFactory);

        // when
        long processed = instance.load( tableAdapter );

        // then
        assertThat( processed ).isEqualTo(3);

        verify(tableAdapter, times(1)).markAllRecordsAsNotLoaded();
        verify(executor, times(1)).execute(any(DataProvider.class), anyString());
        verify(scriptEngineFactory, times(1)).buildFor(script);
        verify(scriptEngine, times(3)).execute(anyMap());
        verify(tableAdapter, times(3)).markAsLoaded("The result");
    }


    @Test(expected = CannotLoadTable.class)
    public void testGivenTableEmptySQL_WhenExecute_TheThrowException() throws Exception {
        // given
        DataProvider provider = new DataProvider();
        String sql = "    ";    // Empty SQL
        String script="do something";

        TableAdapter<String> tableAdapter = buildTableAdapter(provider, sql, script);

        ExternalDataQueryExecutor executor = mock(ExternalDataQueryExecutor.class);

        ScriptEngineFactory scriptEngineFactory = mock(ScriptEngineFactory.class);

        initializeInstance(executor, scriptEngineFactory);

        // when
        instance.load( tableAdapter );

        // @Then an exception is thrown
    }

    @Test(expected = CannotLoadTable.class)
    public void testGivenTableNullSQL_WhenExecute_TheThrowException() throws Exception {
        // given
        DataProvider provider = new DataProvider();
        String sql = null;
        String script="do something";

        TableAdapter<String> tableAdapter = buildTableAdapter(provider, sql, script);

        ExternalDataQueryExecutor executor = mock(ExternalDataQueryExecutor.class);

        ScriptEngineFactory scriptEngineFactory = mock(ScriptEngineFactory.class);

        initializeInstance(executor, scriptEngineFactory);

        // when
        instance.load( tableAdapter );

    }

    @Test(expected = CannotLoadTable.class)
    public void testGivenTableEmptyScript_WhenExecute_TheThrowException() throws Exception {
        // given
        DataProvider provider = new DataProvider();
        String sql = "an SQL";
        String script="    ";       // Empty Script

        TableAdapter<String> tableAdapter = buildTableAdapter(provider, sql, script);

        ExternalDataQueryExecutor executor = mock(ExternalDataQueryExecutor.class);

        ScriptEngineFactory scriptEngineFactory = mock(ScriptEngineFactory.class);

        initializeInstance(executor, scriptEngineFactory);

        // when
        instance.load( tableAdapter );

    }

    @Test(expected = CannotLoadTable.class)
    public void testGivenTableNullScript_WhenExecute_TheThrowException() throws Exception {
        // given
        DataProvider provider = new DataProvider();
        String sql = "an SQL";
        String script= null;

        TableAdapter<String> tableAdapter = buildTableAdapter(provider, sql, script);

        ExternalDataQueryExecutor executor = mock(ExternalDataQueryExecutor.class);

        ScriptEngineFactory scriptEngineFactory = mock(ScriptEngineFactory.class);

        initializeInstance(executor, scriptEngineFactory);

        // when
        instance.load( tableAdapter );

    }

    private void initializeInstance(ExternalDataQueryExecutor executor, ScriptEngineFactory scriptEngineFactory) {
        field("queryExecutor").ofType(ExternalDataQueryExecutor.class).in(instance).set(executor);
        field("scriptEngineFactory").ofType(ScriptEngineFactory.class).in(instance).set(scriptEngineFactory);
    }

    private TableAdapter<String> buildTableAdapter(DataProvider provider, String sql, String script) {
        TableAdapter<String> tableAdapter = mock(TableAdapter.class);
        when(tableAdapter.getProvider()).thenReturn(provider);
        when(tableAdapter.getLoadSql()).thenReturn(sql);
        when(tableAdapter.getLoadScript()).thenReturn(script);
        return tableAdapter;
    }
}
