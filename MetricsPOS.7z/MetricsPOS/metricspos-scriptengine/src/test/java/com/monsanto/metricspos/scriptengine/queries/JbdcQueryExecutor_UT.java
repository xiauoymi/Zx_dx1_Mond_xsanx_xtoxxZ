package com.monsanto.metricspos.scriptengine.queries;

import com.google.common.base.Function;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import org.junit.Before;
import org.junit.Test;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import javax.sql.DataSource;
import java.sql.SQLException;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Test the JdbcQueryExecutor class
 *
 * @author cafau
 */
public class JbdcQueryExecutor_UT {

    private static final String VALID_QUERY = "select x from YY ";
    private static final String IN_VALID_QUERY = "this is invalid SQL";

    private JdbcQueryExecutor instance;

    private DataProvider validProvider;
    private JdbcTemplate jdbcTemplate;

    @Before
    public void setUp() throws Exception {
        jdbcTemplate = mock(JdbcTemplate.class);

        instance = new JdbcQueryExecutor() {
            @Override
            protected JdbcTemplate newJdbcTemplate(DataProvider provider) {
                super.newJdbcTemplate(provider);    // To cover lines !!
                return jdbcTemplate;
            }
        };

        DataSource dataSource = mock(DataSource.class);

        validProvider = new DataProvider();
        validProvider.setCode( "XXX");
        validProvider.setName("The provider");
        validProvider.setDataSource(dataSource);
    }

    @Test
    public void testGivenValidProvider_WhenExecute_ThenReturnIteratorWithAllValues() throws Exception {
        // given
        List<Integer> elements = Lists.newArrayList(10, 20, 30);
        SqlRowSet sqlRowSet = new SqlRowsSetStub(elements);

        when(jdbcTemplate.queryForRowSet(VALID_QUERY)).thenReturn(sqlRowSet);

        // when
        Iterable<SqlRowSet> results = instance.execute(validProvider, VALID_QUERY);

        // then
        assertThat(results).isNotNull();

        Iterable<Object> values = Iterables.transform(results, new Function<SqlRowSet, Object>() {
            @Override
            public Object apply(SqlRowSet sqlRowSet) {
                return sqlRowSet.getObject("any");
            }
        });

        assertThat(values).containsOnly(10, 20, 30);
    }


    @Test
    public void testGivenInvalidQuery_WhenExecute_ThenThrowBadSqlGrammarException() throws Exception {
        // given
        when(jdbcTemplate.queryForRowSet(IN_VALID_QUERY)).thenThrow(newInvalidException());

        try {
            // when
            instance.execute(validProvider, IN_VALID_QUERY);
            fail();
        } catch (BadSqlGrammarException e) {
            // then
            // nothing to verify
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testGivenValidQuery_WhenCallRemove_ThenThrowMethodNotAllowed() throws Exception {
        // given
        List<Integer> elements = Lists.newArrayList(10, 20, 30);
        SqlRowSet sqlRowSet = new SqlRowsSetStub(elements);

        when(jdbcTemplate.queryForRowSet(VALID_QUERY)).thenReturn(sqlRowSet);

        Iterable<SqlRowSet> results = instance.execute(validProvider, VALID_QUERY);

        // when
        results.iterator().remove();

        // @Then
    }

    @Test(expected = IllegalArgumentException.class)
    public void testGivenProviderWithoutDataSource_WhenExecute_ThenThrowException() throws Exception {
        // given
        List<Integer> elements = Lists.newArrayList(10, 20, 30);
        SqlRowSet sqlRowSet = new SqlRowsSetStub(elements);

        when(jdbcTemplate.queryForRowSet(VALID_QUERY)).thenReturn(sqlRowSet);

        DataProvider invalidProvider = new DataProvider();
        invalidProvider.setCode( "XXX");
        invalidProvider.setName("The provider");
        invalidProvider.setDataSource(null);

        // when
        instance.execute(invalidProvider, VALID_QUERY);

        // @Then

    }

    private BadSqlGrammarException newInvalidException() {
        return new BadSqlGrammarException("test", IN_VALID_QUERY, new SQLException("invalid query"));
    }

}
