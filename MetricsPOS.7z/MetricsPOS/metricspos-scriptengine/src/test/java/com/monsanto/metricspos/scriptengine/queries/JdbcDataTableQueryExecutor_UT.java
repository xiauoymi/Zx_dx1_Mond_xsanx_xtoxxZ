package com.monsanto.metricspos.scriptengine.queries;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.DataTableServices;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class JdbcDataTableQueryExecutor_UT {

    private ServiceCenter serviceCenter;
    private Campaign campaign;
    private JdbcDataTableQueryExecutor executor;
    private JdbcTemplate jdbcTemplate;
    private DataTableServices tableServices;

    @Before
    public void setUp() {
        this.campaign = new Campaign("Name", newDate(2011, 1, 1), newDate(2012, 2, 2));
        this.campaign.setId(1);
        this.serviceCenter = new ServiceCenter();
        this.serviceCenter.setCuit("100");
        this.serviceCenter.setCampaign(this.campaign);
        this.tableServices = mock(DataTableServices.class);
        DataColumn column = new DataColumn("column1", stringDataType());
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("Name", Lists.<DataColumn>newArrayList(column), dataRowPersistorFactory);
        when(tableServices.findDataTableByCampaignAndName(campaign, "Table")).thenReturn(dataTable);
        this.executor = new JdbcDataTableQueryExecutor(serviceCenter, campaign, tableServices, jdbcTemplate);
        this.jdbcTemplate = mock(JdbcTemplate.class);
        field("jdbcTemplate").ofType(JdbcTemplate.class).in(executor).set(this.jdbcTemplate);
    }

    @Test
    public void testQueryCallsJdbcTemplateQueryForRowSet_WhenExecutingAQuery() {
        // @Given a user query
        String query = "Select column1 from Table where column1 > 3";
        SqlRowSet sqlRowSet = mock(SqlRowSet.class);
        when(this.jdbcTemplate.queryForRowSet(anyString())).thenReturn(sqlRowSet);

        // @When executing the query
        this.executor.query(query);

        // @Then a SQL query is executed by the JDBC template
        verify(this.jdbcTemplate, times(1)).queryForRowSet(anyString());
    }

    @Test
    public void testQueryCallsJdbcTemplateQueryForRowSetWithA_WhenExecutingAQuery() {
        // @Given a user query and a DataTable that has a column1 that holds numbers
        String query = "Select column1 from Table where column1 > 3";
        SqlRowSet sqlRowSet = mock(SqlRowSet.class);
        when(this.jdbcTemplate.queryForRowSet(anyString())).thenReturn(sqlRowSet);
        String expected = new RowQueryAdapter(query, serviceCenter, campaign, tableServices).getSqlQuery();

        // @When executing the query
        this.executor.query(query);

        // @Then a SQL query is executed by the JDBC template that returns the info queried from the data table
        verify(this.jdbcTemplate, times(1)).queryForRowSet(expected);
    }

    @Test
    public void testCountQueryCallsJdbcTemplateQueryForLong_WhenExecutingAQuery() {
        // @Given a user query
        String query = "Select count(*) from Table where column1 > 3";
        when(this.jdbcTemplate.queryForLong(anyString())).thenReturn(2l);

        // @When executing the query
        this.executor.countQuery(query);

        // @Then a SQL query is executed by the JDBC template
        verify(this.jdbcTemplate, times(1)).queryForLong(anyString());
    }

    @Test
    public void testCountQueryCallsJdbcTemplateQueryForRowSetWithA_WhenExecutingAQuery() {
        // @Given a user query and a DataTable that has a column1 that holds numbers
        String query = "Select column1 from Table where column1 > 3";
        when(this.jdbcTemplate.queryForLong(anyString())).thenReturn(1l);
        String expected = new RowQueryAdapter(query, serviceCenter, campaign, tableServices).getSqlQuery();

        // @When executing the query
        this.executor.countQuery(query);

        // @Then a SQL query is executed by the JDBC template that returns the info queried from the data table
        verify(this.jdbcTemplate, times(1)).queryForLong(expected);
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        dataType.setCode("String");
        dataType.setName("String");
        dataType.setInternalType(String.class);
        return dataType;
    }
}
