package com.monsanto.metricspos.scriptengine.queries;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.DataTableServices;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataFile;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.math.BigDecimal;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: PPERA
 */
public class RowQueryAdapter_UT {

    private Campaign campaign;
    private ServiceCenter serviceCenter;
    private DataTableServices tableServices;

    @Before
    public void setUp() {
        this.serviceCenter = new ServiceCenter();
        this.serviceCenter.setCuit("100");
        this.campaign = new Campaign("name", newDate(2008, 1, 2), newDate(2009, 4, 4));
        this.campaign.setId(1);
        this.tableServices = mock(DataTableServices.class);
        DataColumn column = new DataColumn("column1", numberDataType());
        column.setActualColumnName("number1");
        DataColumn column2 = new DataColumn("included", numberDataType());
        column2.setActualColumnName("number2");
        DataColumn column3 = new DataColumn("includesincluded", numberDataType());
        column3.setActualColumnName("number3");
        DataColumn column4 = new DataColumn("column4", serviceCenterDataType());
        column4.setActualColumnName("serviceCenter");
        DataColumn column5 = new DataColumn("column5", pointOfSaleDataType());
        column5.setActualColumnName("pointOfSale");
        DataColumn column6 = new DataColumn("column6", dataFileDataType());
        column6.setActualColumnName("dataFile");
        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        DataTable dataTable = new DataTable("Name", Lists.<DataColumn>newArrayList(column, column2, column3, column4, column5, column6), dataRowPersistorFactory);
        when(tableServices.findDataTableByCampaignAndName(campaign, "table")).thenReturn(dataTable);
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlQueryWithAMatchingSelectAndAMatchingFrom_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFrom() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select column1 from table";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select r.column1 from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlQueryWithAMatchingSelectFromAndWhereClause_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFromAndAWhere() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select column1 from table where column1 > 3";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select r.column1 from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r where r.column1 > 3");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlQueryWithAMatchingSelectWithServiceCenterFromAndWhereClause_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFromAndAWhere() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select column4 from table where column1 > 3";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select r.column4 from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r where r.column1 > 3");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlQueryWithAMatchingSelectWithPointOfSaleFromAndWhereClause_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFromAndAWhere() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select column5 from table where column1 > 3";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select r.column5 from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r where r.column1 > 3");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlQueryWithAMatchingSelectWithDataFileFromAndWhereClause_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFromAndAWhere() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select column6 from table where column1 > 3";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select r.column6 from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r where r.column1 > 3");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlCountQueryWithAMatchingSelectFromAndWhereClause_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFromAndAWhere() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select count(*) from table where column1 > 3";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select count(*) from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r where r.column1 > 3");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlCountQueryWithAMatchingSelectFromAndGroupByClause_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFromAndAGroupBy() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select count(*) from table group by column1";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select count(*) from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r group by r.column1");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlCountQueryWithAMatchingSelectFromGroupByAndHavingClause_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFromGroupByAndHaving() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select count(*) from table group by column1 having count(column1) > 1";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select count(*) from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r group by r.column1 having count(r.column1) > 1");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlCountQueryWithAMatchingSelectFromAndOrderByClause_WhenGettingAnSqlQueryFromARowQueryWithASelectFromAndOrderBy() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select count(*) from table order by column1 asc";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select count(*) from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r order by r.column1 asc");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlQueryWithAMatchingSelectAndAMatchingFrom_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFromAndColumnIncludesIncluded() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select includesincluded from table";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select r.includesincluded from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlQueryWithAMatchingSelectAndAMatchingFrom_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFromAndColumnIncludesIncludedInFunction() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select sum(includesincluded) from table";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select sum(r.includesincluded) from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r");
    }

    @Test
    public void testGetSqlQueryReturnsAnSqlQueryWithAMatchingSelectAndAMatchingFrom_WhenGettingAnSqlQueryFromARowQueryWithASelectAndAFromAndColumnIncludesIncludedAfterComma() {
        // @Given a rowQuery with a select clause and a from clause that refers to a table (with one number column) by its name
        String rowQuery = "Select sum(included,includesincluded) from table";
        RowQueryAdapter queryAdapter = new RowQueryAdapter(rowQuery, serviceCenter, campaign, this.tableServices);

        // @When getting the Sql Query for that rowQuery
        String sqlQuery = queryAdapter.getSqlQuery();

        // @Then a matching Sql query is returned
        assertThat(sqlQuery).isEqualTo("Select sum(r.included,r.includesincluded) from (SELECT rows.number1 as column1,rows.number2 as included,rows.number3 as includesincluded,rows.CUIT as column4,rows.POINT_OF_SALE_ID_SAP as column5,rows.FILE_NAME as column6 FROM MPS.MPS_MULTITABLE_ROW rows JOIN MPS.MPS_DATA_TABLE tables on tables.id = rows.DATA_TABLE_ID WHERE rows.SC_CAMPAIGN_ID = 1 AND rows.CUIT = '100' AND tables.NAME = 'table' AND rows.DELETED = 0) as r");
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        dataType.setCode("String");
        dataType.setName("String");
        dataType.setInternalType(String.class);
        return dataType;
    }

    private DataType numberDataType() {
        DataType dataType = new DataType();
        dataType.setCode("Number");
        dataType.setName("Number");
        dataType.setInternalType(BigDecimal.class);
        return dataType;
    }

    private DataType dataFileDataType() {
        DataType dataType = new DataType();
        dataType.setCode("File");
        dataType.setName("File");
        dataType.setInternalType(DataFile.class);
        return dataType;
    }

    private DataType pointOfSaleDataType() {
        DataType dataType = new DataType();
        dataType.setCode("POS");
        dataType.setName("POS");
        dataType.setInternalType(PointOfSale.class);
        return dataType;
    }

    private DataType serviceCenterDataType() {
        DataType dataType = new DataType();
        dataType.setCode("SC");
        dataType.setName("SC");
        dataType.setInternalType(ServiceCenter.class);
        return dataType;
    }
}
