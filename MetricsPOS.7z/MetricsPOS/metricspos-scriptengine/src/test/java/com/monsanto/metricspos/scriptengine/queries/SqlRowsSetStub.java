package com.monsanto.metricspos.scriptengine.queries;

import org.springframework.jdbc.InvalidResultSetAccessException;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.jdbc.support.rowset.SqlRowSetMetaData;

import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

/**
 * Complete please !!
 *
 * @author cafau
 */
public class SqlRowsSetStub implements SqlRowSet {

    private List<?> elements;
    private int position;
    
    public SqlRowsSetStub(List<?> elements) {
        this.elements = elements;
        position = -1;
    }

    @Override
    public SqlRowSetMetaData getMetaData() {
        return null;
    }

    @Override
    public int findColumn(String columnLabel) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public BigDecimal getBigDecimal(int columnIndex) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public BigDecimal getBigDecimal(String columnLabel) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public boolean getBoolean(int columnIndex) throws InvalidResultSetAccessException {
        return false;
    }

    @Override
    public boolean getBoolean(String columnLabel) throws InvalidResultSetAccessException {
        return false;
    }

    @Override
    public byte getByte(int columnIndex) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public byte getByte(String columnLabel) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public Date getDate(int columnIndex, Calendar cal) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Date getDate(int columnIndex) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Date getDate(String columnLabel, Calendar cal) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Date getDate(String columnLabel) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public double getDouble(int columnIndex) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public double getDouble(String columnLabel) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public float getFloat(int columnIndex) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public float getFloat(String columnLabel) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public int getInt(int columnIndex) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public int getInt(String columnLabel) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public long getLong(int columnIndex) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public long getLong(String columnLabel) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public Object getObject(int columnIndex, Map<String, Class<?>> map) throws InvalidResultSetAccessException {
        return elements.get(position);
    }

    @Override
    public Object getObject(int columnIndex) throws InvalidResultSetAccessException {
        return elements.get(position);
    }

    @Override
    public Object getObject(String columnLabel, Map<String, Class<?>> map) throws InvalidResultSetAccessException {
        return elements.get(position);
    }

    @Override
    public Object getObject(String columnLabel) throws InvalidResultSetAccessException {
        return elements.get(position);
    }

    @Override
    public short getShort(int columnIndex) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public short getShort(String columnLabel) throws InvalidResultSetAccessException {
        return 0;
    }

    @Override
    public String getString(int columnIndex) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public String getString(String columnLabel) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Time getTime(int columnIndex, Calendar cal) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Time getTime(int columnIndex) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Time getTime(String columnLabel, Calendar cal) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Time getTime(String columnLabel) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Timestamp getTimestamp(int columnIndex, Calendar cal) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Timestamp getTimestamp(int columnIndex) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Timestamp getTimestamp(String columnLabel, Calendar cal) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public Timestamp getTimestamp(String columnLabel) throws InvalidResultSetAccessException {
        return null;
    }

    @Override
    public boolean absolute(int row) throws InvalidResultSetAccessException {
        position = row;
        return position >= 0 && position < elements.size() ;
    }

    @Override
    public void afterLast() throws InvalidResultSetAccessException {
        absolute( elements.size() );
    }

    @Override
    public void beforeFirst() throws InvalidResultSetAccessException {
        absolute(-1);
    }

    @Override
    public boolean first() throws InvalidResultSetAccessException {
        return position == 0;
    }

    @Override
    public int getRow() throws InvalidResultSetAccessException {
        return position;
    }

    @Override
    public boolean isAfterLast() throws InvalidResultSetAccessException {
        return position >= elements.size();
    }

    @Override
    public boolean isBeforeFirst() throws InvalidResultSetAccessException {
        return position < 0;
    }

    @Override
    public boolean isFirst() throws InvalidResultSetAccessException {
        return position == 0;
    }

    @Override
    public boolean isLast() throws InvalidResultSetAccessException {
        return position + 1 == elements.size();
    }

    @Override
    public boolean last() throws InvalidResultSetAccessException {
        return absolute(elements.size() - 1);
    }

    @Override
    public boolean next() throws InvalidResultSetAccessException {
        return absolute(position + 1);
    }

    @Override
    public boolean previous() throws InvalidResultSetAccessException {
        return absolute( position - 1);
    }

    @Override
    public boolean relative(int rows) throws InvalidResultSetAccessException {
        return absolute(position + rows);
    }

    @Override
    public boolean wasNull() throws InvalidResultSetAccessException {
        return false;
    }
}
