package com.monsanto.metricspos.services.excel;

import com.monsanto.metricspos.core.application.vo.MetricScoreVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.utils.BigDecimalUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import java.math.BigDecimal;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 14/02/14
 * Time: 13:09
 * To change this template use File | Settings | File Templates.
 */
public class ColumnSettings {

    private Map<Integer, Integer> settings;

    private ColumnSettings(){
        settings = new HashMap<Integer, Integer>();
    }

    public ColumnSettings(DataTable dataTable, List<DataRow> data){
        this();
        for (DataColumn column : dataTable.getColumns()) {
            int maxSize = 0;
            for (DataRow dataRow : data) {
                Object value = dataRow.get(column.getName());
                int actualSize = getSize(column, value);
                if(actualSize > maxSize){
                    maxSize = actualSize;
                }
            }
            maxSize = determinateMaxSize(column.getName(), column.getLabel(), maxSize);

            settings.put(dataTable.getColumns().indexOf(column),maxSize);
        }
    }

    public ColumnSettings(List<MetricPOSXlsBuilder.ColModel> metadata, List<MetricScoreVO> data){
        this();
        for (MetricPOSXlsBuilder.ColModel colModel : metadata) {
            int maxSize = 0;
            for (MetricScoreVO entity : data) {
                BeanWrapper bw = new BeanWrapperImpl(entity);
                Object value = null;
                if ("ASSIGNED".equals(colModel.getType())) {
                    // if colmodel type is assigned, the value has been passed as the name attribute.
                    // This is needed for some reports with fixed cell values no matter the row data.
                    value = colModel.getName();
                } else {
                    // get the value by inspecting the object using colModel.getName() as a path.
                    value = bw.getPropertyValue(colModel.getName());
                }
                int actualSize = value.toString().length();
                if(actualSize > maxSize){
                    maxSize = actualSize;
                }
            }
            maxSize = determinateMaxSize(colModel.getName(), colModel.getLabel(), maxSize);

            settings.put(metadata.indexOf(colModel), maxSize);
        }

    }

    private int determinateMaxSize(String nameColumn, String labelColumn, int dataSize){
        int max = labelColumn != null ? labelColumn.length() : nameColumn.length();
        if(dataSize < max + 1 ){
            return max + 1;
        }else{
            return dataSize;
        }
    }


    private Integer getSize(DataColumn column, Object value) {
        if (value == null) {
            return 0;
        }
        int result = 0;
        Class<?> internalType = column.getDataType().getInternalType();

        if (Date.class.equals(internalType)) {
            result = value.toString().trim().length();
        } else if (ServiceCenter.class.equals(internalType)) {
            result = (((ServiceCenter) value).getName()).trim().length();
        } else if (PointOfSale.class.equals(internalType)) {
            result = (MetricPOSXlsBuilder.getPointOfSaleName((PointOfSale) value)).trim().length();
        } else if (BigDecimal.class.equals(internalType)) {
            BigDecimal val = (BigDecimal) value;
            //HSSFRichTextString richText = new HSSFRichTextString(BigDecimalUtils.getInstance().getValueWithSignificantDecimals(val).toString());
            result = BigDecimalUtils.getInstance().getValueWithSignificantDecimals(val).toString().trim().length();
        } else {
            result = value.toString().length();
        }
        int columnLength = column.getName().length();
        return columnLength >= result ? columnLength : result;
    }

    public Set<Map.Entry<Integer,Integer>> keySet(){
        return settings.entrySet();
    }

    public Integer get(Integer key){
        return settings.get(key);

    }
}
