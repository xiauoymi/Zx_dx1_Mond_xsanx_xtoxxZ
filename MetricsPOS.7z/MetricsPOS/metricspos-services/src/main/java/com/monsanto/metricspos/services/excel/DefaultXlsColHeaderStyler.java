package com.monsanto.metricspos.services.excel;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.util.HSSFColor;
import org.springframework.util.Assert;

public class DefaultXlsColHeaderStyler extends XlsAbstractStyler
{

	public HSSFCellStyle getCellStyle(boolean isEvenRow){
		Assert.notNull(this.getWorkbook(), "Workbook should not be null");
		
		HSSFCellStyle cellStyle = this.getWorkbook().createCellStyle();
		
		HSSFPalette palette = this.getWorkbook().getCustomPalette();
		palette.setColorAtIndex(HSSFColor.GREEN.index,
				(byte) 0, //RGB red
				(byte) 128, //RGB green
				(byte) 0 //RGB blue
				);
		cellStyle.setFillForegroundColor(HSSFColor.GREEN.index);
		cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

		HSSFFont font = this.getWorkbook().createFont();
		font.setColor(HSSFColor.WHITE.index);
		font.setFontName("Arial");
		font.setFontHeightInPoints((short)9);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		cellStyle.setFont(font);
		
		cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		cellStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		return cellStyle;
	}

	@Override
	public short getRowHeight() {
		return 20;
	}

}
