package com.monsanto.metricspos.services.excel;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.util.HSSFColor;
import org.springframework.util.Assert;

public class DefaultXlsRowStyler extends XlsAbstractStyler
{

	public HSSFCellStyle getCellStyle(boolean isEvenRow){
		Assert.notNull(this.getWorkbook(), "Workbook should not be null");

		HSSFCellStyle cellStyle = this.getWorkbook().createCellStyle();

		if(isEvenRow){
			HSSFPalette palette = this.getWorkbook().getCustomPalette();
			palette.setColorAtIndex(HSSFColor.LIGHT_GREEN.index,
					(byte) 204, //RGB red
					(byte) 255, //RGB green
					(byte) 204 //RGB blue
					);
			cellStyle.setFillForegroundColor(HSSFColor.LIGHT_GREEN.index);
			cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		}

		HSSFFont font = this.getWorkbook().createFont();
		font.setFontHeightInPoints((short)8);
		font.setFontName("Tahoma");
		cellStyle.setFont(font);

		cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		cellStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);

		cellStyle.setBorderBottom(HSSFCellStyle.BORDER_THIN);
		cellStyle.setBottomBorderColor(HSSFColor.GREY_40_PERCENT.index);
		cellStyle.setBorderLeft(HSSFCellStyle.BORDER_THIN);
		cellStyle.setLeftBorderColor(HSSFColor.GREY_40_PERCENT.index);
		cellStyle.setBorderRight(HSSFCellStyle.BORDER_THIN);
		cellStyle.setRightBorderColor(HSSFColor.GREY_40_PERCENT.index);
		cellStyle.setBorderTop(HSSFCellStyle.BORDER_THIN);
		cellStyle.setTopBorderColor(HSSFColor.GREY_40_PERCENT.index);

		return cellStyle;
	}

	@Override
	public short getRowHeight() {
		return 14;
	}

}
