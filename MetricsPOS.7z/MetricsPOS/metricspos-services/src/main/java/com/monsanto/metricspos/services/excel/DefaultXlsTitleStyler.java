package com.monsanto.metricspos.services.excel;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.springframework.util.Assert;

public class DefaultXlsTitleStyler extends XlsAbstractStyler
{
	
	public HSSFCellStyle getCellStyle(boolean isEvenRow){
		Assert.notNull(this.getWorkbook(), "Workbook should not be null");
		
		HSSFCellStyle cellStyle = this.getWorkbook().createCellStyle();
		
		cellStyle.setAlignment(HSSFCellStyle.ALIGN_LEFT);
		cellStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_BOTTOM);

		HSSFFont font = this.getWorkbook().createFont();
		font.setFontHeightInPoints((short)12);
		font.setFontName("Arial");
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		cellStyle.setFont(font);
		
		return cellStyle;
	}

	
	@Override
	public short getRowHeight() {
		return 32;
	}
}
