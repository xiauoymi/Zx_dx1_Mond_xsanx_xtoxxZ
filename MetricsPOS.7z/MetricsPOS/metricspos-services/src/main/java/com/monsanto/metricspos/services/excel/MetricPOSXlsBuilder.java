package com.monsanto.metricspos.services.excel;

import com.monsanto.metricspos.core.application.vo.MetricScoreVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.utils.BigDecimalUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

import java.math.BigDecimal;
import java.util.*;

/**
 * Renders the data data into XLS sheets
 */
public class MetricPOSXlsBuilder {

    private final static short SHEET_TITLE_ROW = 0;
    private final static short COL_HEADERS_ROW = 2;
    private final static short FIRST_DATA_ROW = 3;
    protected final static short FIRST_COL = 0;

    private HSSFWorkbook workbook;
    private XlsAbstractStyler titleStyler;
    private XlsAbstractStyler rowStyler;
    private XlsAbstractStyler colHeaderStyler;

    public MetricPOSXlsBuilder(HSSFWorkbook workbook) {
        this.workbook = workbook;
    }

    public HSSFWorkbook getWorkbook() {
        return workbook;
    }

    public void setWorkbook(HSSFWorkbook workbook) {
        this.workbook = workbook;
    }

    public <T> HSSFWorkbook buildWith(ScoreSummaryCampaignNode summary) {
        Campaign campaign = summary.getCampaign();
        for (DataTable dataTable : campaign.getDataTables()) {
            // only include the table data if requested.
            HSSFSheet sheet = null;
            List<DataRow> data = new ArrayList<DataRow>();
            if (dataTable.getIncludeData()) {
                String tableName = dataTable.getName();
                sheet = this.workbook.createSheet(tableName);
                 data = dataTable.findRowsByServiceCenter(summary.getServiceCenter());

                doCommon(sheet, dataTable, data);
            }
            this.autoSizeColumns(
                    new ColumnSettings(dataTable,data),
                    sheet);
        }

        return this.workbook;
    }

    public <T> HSSFWorkbook buildWith(List<MetricScoreVO> scoreVOs) {
        List<ColModel> metadata = getScoreExportMetadata();

        HSSFSheet sheet = this.workbook.createSheet("scores");

        this.mapTitle(sheet, "Puntajes");
        this.mapColsHeader(sheet, metadata);
        this.mapRows(sheet, metadata, scoreVOs);

        //this.autosizeColumns(metadata.size(), sheet);
        this.autoSizeColumns(
                new ColumnSettings(metadata,scoreVOs),
                sheet);
        return this.workbook;
    }

    public <T> HSSFWorkbook buildWith(DataTable dataTable, List<DataRow> data) {

        String tableName = dataTable.getName();
        HSSFSheet sheet = this.workbook.createSheet(tableName);
        doCommon(sheet, dataTable, data);

        //this.autosizeColumns(dataTable.getColumns().size(), sheet);
        this.autoSizeColumns(
                new ColumnSettings(dataTable, data),
                sheet);
        return this.workbook;
    }

    private void doCommon(HSSFSheet sheet, DataTable dataTable, List<DataRow> data) {
        this.mapTitle(sheet, dataTable.getName());
        this.mapColsHeader(sheet, dataTable);
        this.mapRows(sheet, dataTable, data);

        this.autoSizeColumns(dataTable.getColumns().size(), sheet);
    }

    private void autoSizeColumns(int columns, HSSFSheet sheet) {
        for (int i = 0; i < columns; i++) {
            sheet.autoSizeColumn((short) i);
        }
    }

    private void autoSizeColumns(ColumnSettings settings, HSSFSheet sheet){

        for(Map.Entry<Integer, Integer> entry : settings.keySet()) {
            Integer column = entry.getKey();
            Integer width = entry.getValue();

            sheet.setColumnWidth(column, width * 256);
        }
    }

    protected void mapTitle(HSSFSheet worksheet, String submetricName) {
        short rowIdx = SHEET_TITLE_ROW;
        HSSFRow row = worksheet.createRow(rowIdx);
        int colIdx = FIRST_COL;
        HSSFCell cell = row.createCell(colIdx);
        cell.setCellValue(new HSSFRichTextString(submetricName));
        this.setTitleStyle(row, cell);
    }


    private void setTitleStyle(HSSFRow row, HSSFCell cell) {
        if (titleStyler != null) {
            row.setHeightInPoints(titleStyler.getRowHeight());
            cell.setCellStyle(titleStyler.getCellStyle(false));
        }
    }

    private void mapColsHeader(HSSFSheet worksheet, DataTable dataTable) {
        short rowIdx = COL_HEADERS_ROW;
        HSSFRow row = worksheet.createRow(rowIdx);

        short colIdx = FIRST_COL;

        HSSFCellStyle cellStyle = colHeaderStyler == null ? null : colHeaderStyler.getCellStyle(false);

        for (DataColumn column : dataTable.getColumns()) {
            HSSFCell cell = row.createCell(colIdx);
            cell.setCellValue(new HSSFRichTextString(column.getLabel()));
            this.setHeaderStyle(row, cellStyle, cell);
            colIdx++;
        }
    }

    private void mapColsHeader(HSSFSheet worksheet, List<ColModel> metadata) {
        short rowIdx = COL_HEADERS_ROW;
        HSSFRow row = worksheet.createRow(rowIdx);

        int colIdx = FIRST_COL;

        HSSFCellStyle cellStyle = colHeaderStyler == null ? null : colHeaderStyler.getCellStyle(false);

        for (ColModel colModel : metadata) {
            HSSFCell cell = row.createCell(colIdx);
            cell.setCellValue(new HSSFRichTextString(colModel.getLabel()));
            if (colHeaderStyler != null) {
                row.setHeightInPoints(colHeaderStyler.getRowHeight());
                cell.setCellStyle(cellStyle);
            }
            colIdx++;
        }
    }

    protected void setHeaderStyle(HSSFRow row, HSSFCellStyle cellStyle, HSSFCell cell) {
        if (colHeaderStyler != null) {
            row.setHeightInPoints(colHeaderStyler.getRowHeight());
            cell.setCellStyle(cellStyle);
        }
    }

    private void mapRows(HSSFSheet worksheet, DataTable dataTable, List<DataRow> data) {
        short rowIdx = FIRST_DATA_ROW;

        HSSFCellStyle oddCellStyle = null;
        HSSFCellStyle evenCellStyle = null;
        HSSFCellStyle oddCellDateStyle = null;
        HSSFCellStyle evenCellDateStyle = null;

        CreationHelper createHelper = workbook.getCreationHelper();

        if (rowStyler != null) {
            oddCellStyle = rowStyler.getCellStyle(false);
            evenCellStyle = rowStyler.getCellStyle(true);
            oddCellDateStyle = rowStyler.getCellStyle(false);
            oddCellDateStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
            evenCellDateStyle = rowStyler.getCellStyle(true);
            evenCellDateStyle.setDataFormat(createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
        }

        for (DataRow dataRow : data) {
            HSSFRow row = worksheet.createRow(rowIdx);

            int colIdx = FIRST_COL;
            for (DataColumn column : dataTable.getColumns()) {
                HSSFCell cell = row.createCell(colIdx);

                Object value = dataRow.get(column.getName());

                this.setCellValue(column, cell, value);
                this.setRowStyle(rowIdx, oddCellStyle, evenCellStyle, oddCellDateStyle, evenCellDateStyle, row, column, cell);

                colIdx++;
            }
            rowIdx++;
        }
    }

    private void mapRows(HSSFSheet worksheet, List<ColModel> metadata, List<MetricScoreVO> data) {
        short rowIdx = FIRST_DATA_ROW;

        for (MetricScoreVO entity : data) {
            BeanWrapper bw = new BeanWrapperImpl(entity);
            HSSFRow row = worksheet.createRow(rowIdx);

            int colIdx = FIRST_COL;
            for (ColModel colModel : metadata) {
                HSSFCell cell = row.createCell(colIdx);
                Object value = null;
                if ("ASSIGNED".equals(colModel.getType())) {
                    // if colmodel type is assigned, the value has been passed as the name attribute.
                    // This is needed for some reports with fixed cell values no matter the row data.
                    value = colModel.getName();
                } else {
                    // get the value by inspecting the object using colModel.getName() as a path.
                    value = bw.getPropertyValue(colModel.getName());
                }

                // set the cell value according to the colModel metadata.
                setCellValue(colModel, cell, value);

                // increment the column index
                colIdx++;
            }
            // increment the row index
            rowIdx++;
        }
    }

    private void setRowStyle(short rowIdx, HSSFCellStyle oddCellStyle, HSSFCellStyle evenCellStyle, HSSFCellStyle oddCellDateStyle, HSSFCellStyle evenCellDateStyle, HSSFRow row, DataColumn column, HSSFCell cell) {
        if (rowStyler == null) {
            return;
        }
        row.setHeightInPoints(rowStyler.getRowHeight());

        if (Date.class.equals(column.getDataType().getInternalType())) {
            cell.setCellStyle(rowIdx % 2 == 0 ? evenCellDateStyle : oddCellDateStyle);
        } else {
            cell.setCellStyle(rowIdx % 2 == 0 ? evenCellStyle : oddCellStyle);
        }

    }

    protected void setCellValue(DataColumn column, HSSFCell cell, Object value) {
        if (value == null) {
            return;
        }
        Class<?> internalType = null;
        if(column!=null){
            internalType = column.getDataType().getInternalType();
        }else{
            internalType = value.getClass();
        }

        if (Date.class.equals(internalType)) {
            cell.setCellValue((Date) value);
        } else if (ServiceCenter.class.equals(internalType)) {
            cell.setCellValue(((ServiceCenter) value).getName());
        } else if (PointOfSale.class.equals(internalType)) {
            cell.setCellValue(MetricPOSXlsBuilder.getPointOfSaleName((PointOfSale) value));
        } else if (BigDecimal.class.equals(internalType)) {
            BigDecimal val = (BigDecimal) value;
            //HSSFRichTextString richText = new HSSFRichTextString(BigDecimalUtils.getInstance().getValueWithSignificantDecimals(val).toString());
            cell.setCellValue(BigDecimalUtils.getInstance().getValueWithSignificantDecimals(val).doubleValue());
        } else {
            HSSFRichTextString richText = new HSSFRichTextString(value.toString());
            cell.setCellValue(richText);
        }
    }

    public static String getPointOfSaleName(PointOfSale value) {
        String locality = value.getLocality() != null ? value.getLocality() : "Localidad desconocida";
        String address = value.getAddress() != null ? value.getAddress() : "Dirección desconocida";
        return locality + " - " + address;
    }

    public MetricPOSXlsBuilder setTitleStyle(XlsAbstractStyler titleStyler) {
        titleStyler.setWorkbook(this.workbook);
        this.titleStyler = titleStyler;
        return this;
    }


    public MetricPOSXlsBuilder setRowStyle(XlsAbstractStyler rowStyler) {
        rowStyler.setWorkbook(this.workbook);
        this.rowStyler = rowStyler;
        return this;
    }


    public MetricPOSXlsBuilder setColHeaderStyle(XlsAbstractStyler colHeaderStyler) {
        colHeaderStyler.setWorkbook(this.workbook);
        this.colHeaderStyler = colHeaderStyler;
        return this;
    }


    private void setCellValue(ColModel colModel, HSSFCell cell, Object value) {
        if (value != null) {
            if ("DATE".equals(colModel.getType())) {
                CreationHelper createHelper = workbook.getCreationHelper();
                cell.setCellValue(new Date(((Date) value).getTime()));
                HSSFCellStyle style = this.workbook.createCellStyle();
                style.setDataFormat(createHelper.createDataFormat().getFormat("dd/mm/yyyy"));
                cell.setCellStyle(style);

            } else if ("BOOLEAN".equals(colModel.getType())) {
                HSSFRichTextString richText = new HSSFRichTextString(((Boolean) value) ? "Si" : "No");
                cell.setCellValue(richText);

            } else if ("NUMBER".equals(colModel.getType())) {
                HSSFCellStyle style = this.workbook.createCellStyle();
                HSSFDataFormat format = this.workbook.createDataFormat();
                style.setDataFormat(format.getFormat("#,##0"));
                if (value instanceof Double) {
                    cell.setCellValue((Double) value);
                } else {
                    HSSFRichTextString richText = new HSSFRichTextString(value.toString());
                    cell.setCellValue(richText);
                }
                cell.setCellStyle(style);

            } else if ("DOLLAR".equals(colModel.getType())) {
                HSSFCellStyle style = this.workbook.createCellStyle();
                style.setDataFormat((short) 8); //($#,##0.00_);[Red]($#,##0.00)
                cell.setCellValue((Double) value);
                cell.setCellStyle(style);

            } else if ("PERCENTAGE".equals(colModel.getType())) {
                HSSFCellStyle style = this.workbook.createCellStyle();
                style.setDataFormat((short) 0xa); // 0.00%	0xa
                cell.setCellValue((Double) value);
                cell.setCellStyle(style);

            } else if ("CUIT".equals(colModel.getType())) {
                HSSFCellStyle style = this.workbook.createCellStyle();
                cell.setCellValue(Double.valueOf((String)value));
                cell.setCellStyle(style);

            } else {
                HSSFRichTextString richText = new HSSFRichTextString(value.toString());
                cell.setCellValue(richText);
            }
        }
    }

    public XlsAbstractStyler getRowStyler() {
        return rowStyler;
    }

    public XlsAbstractStyler getColHeaderStyler() {
        return colHeaderStyler;
    }

    private List<ColModel> getScoreExportMetadata() {
        List<ColModel> metadata = new LinkedList<ColModel>();
        metadata.add(new ColModel("moduleName", "Modulo"));
        metadata.add(new ColModel("metricName", "Metrica"));
        metadata.add(new ColModel("submetricName", "Submetrica"));
        metadata.add(new ColModel("serviceCenterCuit", "Cuit", "CUIT"));
        metadata.add(new ColModel("serviceCenterName", "Centro de Servicio"));
        metadata.add(new ColModel("points", "Puntaje", "NUMBER"));
        metadata.add(new ColModel("penalty", "Penalidades", "NUMBER"));

        metadata.add(new ColModel("penaltyFactor", "Factor de penalidad", "NUMBER"));
        metadata.add(new ColModel("noData", "Sin datos", "BOOLEAN"));
        metadata.add(new ColModel("dirty", "Recalcular", "BOOLEAN"));
        metadata.add(new ColModel("lastUpdated", "Ultima Actualizacion", "DATE"));
        return metadata;
    }

    public static class ColModel {

        private String name;
        private String label;
        private String type;

        public ColModel(String name, String label) {
            this(name, label, null);
        }

        public ColModel(String name, String label, String type) {
            this.name = name;
            this.label = label;
            this.type = type;
        }

        public String getName() {
            return name;
        }

        public String getLabel() {
            return label != null ? label : name;
        }

        public String getType() {
            return type;
        }

    }
}
