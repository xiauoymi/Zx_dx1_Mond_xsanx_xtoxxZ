package com.monsanto.metricspos.services.excel;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public abstract class XlsAbstractStyler {

	private HSSFWorkbook workbook;
	
	public abstract HSSFCellStyle getCellStyle(boolean isEvenRow);
	
	public abstract short getRowHeight();
	
	public void setWorkbook(HSSFWorkbook workbook) {
		this.workbook = workbook;
	}
	
	public HSSFWorkbook getWorkbook() {
		return workbook;
	}
	
}
