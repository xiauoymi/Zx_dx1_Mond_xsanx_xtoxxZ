package com.monsanto.metricspos.services.excel;

import com.monsanto.metricspos.core.ExportServices;
import com.monsanto.metricspos.core.application.vo.MetricScoreVO;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.services.excel.exceptions.ExportException;
import com.monsanto.metricspos.services.excel.serviceCenter.ServiceCenterXlsBuilder;
import com.monsanto.metricspos.services.excel.serviceCenter.ServiceCenterXlsColHeaderStyler;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

public class XlsExportServiceImpl implements ExportServices {


    @Override
    public <T> void export(OutputStream outputStream, ScoreSummaryCampaignNode summary) throws IOException {
        HSSFWorkbook workbook = new HSSFWorkbook();

        new MetricPOSXlsBuilder(workbook)
                .setTitleStyle(new DefaultXlsTitleStyler())
                .setColHeaderStyle(new DefaultXlsColHeaderStyler())
                .setRowStyle(new DefaultXlsRowStyler())
                .buildWith(summary);

        workbook.write(outputStream);
        outputStream.flush();
        outputStream.close();
    }

    @Override
    public <T> void export(OutputStream outputStream, DataTable dataTable, List<DataRow> data) throws IOException {
        HSSFWorkbook workbook = new HSSFWorkbook();

        new MetricPOSXlsBuilder(workbook)
                .setTitleStyle(new DefaultXlsTitleStyler())
                .setColHeaderStyle(new DefaultXlsColHeaderStyler())
                .setRowStyle(new DefaultXlsRowStyler())
                .buildWith(dataTable, data);

        workbook.write(outputStream);
        outputStream.flush();
        outputStream.close();
    }

    @Override
    public <T> void export(OutputStream outputStream, List<MetricScoreVO> scoreVOs) throws IOException {
        HSSFWorkbook workbook = new HSSFWorkbook();

        new MetricPOSXlsBuilder(workbook)
                .setTitleStyle(new DefaultXlsTitleStyler())
                .setColHeaderStyle(new DefaultXlsColHeaderStyler())
                .setRowStyle(new DefaultXlsRowStyler())
                .buildWith(scoreVOs);

        workbook.write(outputStream);
        outputStream.flush();
        outputStream.close();
    }

    @Override
    public <T> void export(List<ScoreSummaryCampaignNode> scores, OutputStream outputStream) throws Exception {
        HSSFWorkbook workbook = new HSSFWorkbook();

        new ServiceCenterXlsBuilder(workbook, scores)
                .setRowStyler(new DefaultXlsRowStyler())
                .setColHeaderStyler(new ServiceCenterXlsColHeaderStyler())
                .buildWith();

        workbook.write(outputStream);
        outputStream.flush();
        outputStream.close();
    }

    @Override
    public <T> void export(List<ServiceCenter> servicesCenters, OutputStream outputStream, int campaingId) throws ExportException {
        HSSFWorkbook workbook = new HSSFWorkbook();
        try {
            new ServiceCenterXlsBuilder(servicesCenters, workbook)
                .setRowStyler(new DefaultXlsRowStyler())
                .setColHeaderStyler(new ServiceCenterXlsColHeaderStyler())
                .buildWith();

            workbook.write(outputStream);
            outputStream.flush();
            outputStream.close();
        }catch (Exception e){
            throw new ExportException("Export error", e);
        }
    }

}
