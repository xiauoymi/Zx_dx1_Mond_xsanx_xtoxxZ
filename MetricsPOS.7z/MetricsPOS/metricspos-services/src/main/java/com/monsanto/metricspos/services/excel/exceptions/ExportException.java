package com.monsanto.metricspos.services.excel.exceptions;

/**
 * User: SHELG
 */
public class ExportException extends RuntimeException {
    public ExportException(String message, Exception e) {
        super(message, e);
    }

    public ExportException(String message) {
        super(message);
    }
}
