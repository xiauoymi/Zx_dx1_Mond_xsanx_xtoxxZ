package com.monsanto.metricspos.services.excel.serviceCenter;

import com.monsanto.metricspos.core.externaldata.comparator.ScoreServiceCenterComparator;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.services.excel.MetricPOSXlsBuilder;
import com.monsanto.metricspos.services.excel.XlsAbstractStyler;
import com.monsanto.metricspos.services.excel.exceptions.ExportException;
import com.monsanto.utils.ExcelUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.springframework.util.CollectionUtils;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 06/03/14
 * Time: 12:19
 * To change this template use File | Settings | File Templates.
 */
public class ServiceCenterXlsBuilder extends MetricPOSXlsBuilder {

    private List<ScoreSummaryCampaignNode> scores;
    private List<ServiceCenter> serviceCenters;

    public ServiceCenterXlsBuilder(HSSFWorkbook workbook, List<ScoreSummaryCampaignNode> scores) {
        super(workbook);
        this.scores = scores;
    }

    public ServiceCenterXlsBuilder(List<ServiceCenter> serviceCenters, HSSFWorkbook workbook) {
        super(workbook);
        this.serviceCenters = serviceCenters;
    }

    public ServiceCenterXlsBuilder setColHeaderStyler(XlsAbstractStyler colHeaderStyler){
        colHeaderStyler.setWorkbook(getWorkbook());
        setColHeaderStyle(colHeaderStyler);
        return this;
    }


    public ServiceCenterXlsBuilder setRowStyler(XlsAbstractStyler rowStyler) {
        rowStyler.setWorkbook(getWorkbook());
        setRowStyle(rowStyler);
        return this;
    }

    public <T> HSSFWorkbook buildWith() throws ExportException {
        HSSFSheet sheet = getWorkbook().createSheet("General");

        doCommon(sheet);

        return getWorkbook();
    }

    private void doCommon(HSSFSheet sheet){
        if(!CollectionUtils.isEmpty(this.serviceCenters)){
            this.createHeaderForRanking(sheet);
            this.createBodyForRanking(sheet);
            this.autoSizeColumns(sheet);
        } else {
            this.createHeader(sheet);
            this.createBody(sheet);
            this.autoSizeColumns(sheet);
        }
    }

    private void createHeader(HSSFSheet sheet){
        HSSFRow rowHeader = sheet.createRow(0);

        if(this.scores.size()==0){
            throw new ExportException("ScoreSummary not contains data");
        }

        ScoreSummaryCampaignNode campaignNode = this.scores.get(0);

        int colNum = 2;
        for (ScoreSummaryNode moduleNode : campaignNode.getChildren()){
            HSSFCell header = rowHeader.createCell(colNum);
            header.setCellValue(moduleNode.getMetric().getName());
            String range = ExcelUtils.getInstance().calculateRangeColumns(colNum, moduleNode.getQuantityChildren() + 2, 1);
            sheet.addMergedRegion(CellRangeAddress.valueOf(range));
            colNum = colNum + moduleNode.getQuantityChildren() + 3;
            setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),header);
        }

        HSSFRow rowSubHeader = sheet.createRow(1);
        colNum = 0;

        HSSFCell serviceCenterHeader = rowSubHeader.createCell(colNum++);
        serviceCenterHeader.setCellValue("CENTRO DE SERVICIO");
        setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),serviceCenterHeader);

        HSSFCell cuitHeader = rowSubHeader.createCell(colNum++);
        cuitHeader.setCellValue("CUIT");
        setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),cuitHeader);

        for(ScoreSummaryNode moduleNode : campaignNode.getChildren()){
            for(ScoreSummaryNode metricNode : moduleNode.getChildren()){
                for(ScoreSummaryNode submetricNode : metricNode.getChildren()){
                    HSSFCell subMetricHeader = rowSubHeader.createCell(colNum++);
                    subMetricHeader.setCellValue(submetricNode.getMetric().getName());
                    setHeaderStyle(rowSubHeader, getColHeaderStyler().getCellStyle(false),subMetricHeader);
                }
                HSSFCell metricHeader = rowSubHeader.createCell(colNum++);
                metricHeader.setCellValue(metricNode.getMetric().getName());
                setHeaderStyle(rowSubHeader, getColHeaderStyler().getCellStyle(false),metricHeader);
            }
            HSSFCell puntajeHeader = rowSubHeader.createCell(colNum++);
            puntajeHeader.setCellValue("PUNTAJE");
            setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),puntajeHeader);
            HSSFCell catHeader = rowSubHeader.createCell(colNum++);
            catHeader.setCellValue("CAT.");
            setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),catHeader);
            HSSFCell incentivoHeader = rowSubHeader.createCell(colNum++);
            incentivoHeader.setCellValue("INCENTIVO");
            setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),incentivoHeader);
        }

        HSSFCell totalHeader = rowSubHeader.createCell(colNum++);
        totalHeader.setCellValue("PUNTAJE TOTAL");
        setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),totalHeader);

        HSSFCell categoryHeader = rowSubHeader.createCell(colNum++);
        categoryHeader.setCellValue("CATEGORIA FINAL");
        setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),categoryHeader);

        HSSFCell rtvHeader = rowSubHeader.createCell(colNum++);
        rtvHeader.setCellValue("RTV");
        setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),rtvHeader);

        HSSFCell gHeader = rowSubHeader.createCell(colNum++);
        gHeader.setCellValue("GERENCIA");
        setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),gHeader);
    }

    private void createHeaderForRanking(HSSFSheet sheet){
        HSSFRow rowHeader = sheet.createRow(0);

        if(CollectionUtils.isEmpty(this.serviceCenters)){
            throw new ExportException("ScoreSummary not contains data");
        }

        int colNum = 0;

        HSSFCell positionHeader = rowHeader.createCell(colNum++);
        positionHeader.setCellValue("Posición");
        setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),positionHeader);

        HSSFCell totalHeader = rowHeader.createCell(colNum++);
        totalHeader.setCellValue("Puntaje");
        setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),totalHeader);

        HSSFCell servicesCenterHeader = rowHeader.createCell(colNum++);
        servicesCenterHeader.setCellValue("Centro de Servicio");
        setHeaderStyle(rowHeader, getColHeaderStyler().getCellStyle(false),servicesCenterHeader);

    }

    private void createBodyForRanking(HSSFSheet sheet){

        int rowNum = 1;

        Collections.sort(this.serviceCenters, new ScoreServiceCenterComparator());

        for(ServiceCenter node : this.serviceCenters){

            List<MetricScore> scoresList = node.getScores();
            BigDecimal points = BigDecimal.ZERO;

            for (MetricScore score : scoresList) {
                if (score.getMetric().getWeighting() == null || !(score.getMetric().getWeighting())) {
                    points = points.add(score.getPoints());
                }
            }
            
            int columnNum = 0;
            HSSFRow row = sheet.createRow(rowNum);

            HSSFCell cellPosition = row.createCell(columnNum++);
            cellPosition.setCellValue(rowNum);
            setCellValue(null, cellPosition, rowNum);

            HSSFCell cellTotal = row.createCell(columnNum++);
            setCellValue(null, cellTotal, points);

            HSSFCell cellServiceSenter = row.createCell(columnNum++);
            setCellValue(null, cellServiceSenter, node.getName());

            rowNum++;
        }
    }

    private void createBody(HSSFSheet sheet){

        int rowNum = 2;

        for(ScoreSummaryCampaignNode node : this.scores){

            int columnNum = 0;
            HSSFRow row = sheet.createRow(rowNum);

            HSSFCell cellName = row.createCell(columnNum++);
            cellName.setCellValue(node.getServiceCenter().getName());

            HSSFCell cellCuit = row.createCell(columnNum++);
            cellCuit.setCellValue(node.getServiceCenter().getCuit());

            for(ScoreSummaryNode module : node.getChildren()){
                for(ScoreSummaryNode metric : module.getChildren()){
                    for(ScoreSummaryNode subMetric : metric.getChildren()){
                        HSSFCell cellSubMetric = row.createCell(columnNum++);
                        //cellSubMetric.setCellValue( subMetric.getPoints().toString());
                        setCellValue(null,cellSubMetric,subMetric.getPoints());
                    }
                    HSSFCell cellMetric = row.createCell(columnNum++);
                    //cellMetric.setCellValue(metric.getPoints().toString());
                    setCellValue(null,cellMetric,metric.getPoints());
                }
                HSSFCell puntajeModule = row.createCell(columnNum++);
                //puntajeModule.setCellValue(module.getPoints().toString());
                setCellValue(null,puntajeModule,module.getPoints());

                HSSFCell catModule = row.createCell(columnNum++);
                //catModule.setCellValue(module.getCategory());
                setCellValue(null,catModule,module.getCategory());

                HSSFCell incentiveModule = row.createCell(columnNum++);
                //incentiveModule.setCellValue(module.getPercentageIncent());
                setCellValue(null,incentiveModule,module.getPercentageIncent());
            }

            //Campaign point here
            HSSFCell totalCell = row.createCell(columnNum++);
            totalCell.setCellValue(node.getPoints().toString());
            setCellValue(null,totalCell,node.getPoints());

            HSSFCell categoryCell = row.createCell(columnNum++);
            setCellValue(null,categoryCell,node.getRating());

            HSSFCell rtvCell = row.createCell(columnNum++);
            //rtvCell.setCellValue(node.getServiceCenter().getRtv());
            setCellValue(null,rtvCell,node.getServiceCenter().getRtv());

            HSSFCell gCell = row.createCell(columnNum++);
            //gCell.setCellValue(node.getServiceCenter().getManagement());
            setCellValue(null,gCell,node.getServiceCenter().getManagement());

            rowNum++;
        }
    }

    private void autoSizeColumns(HSSFSheet sheet){
        int maxColumns = sheet.getRow(2).getLastCellNum();
        for(int i = 0; i < maxColumns; i++){
            sheet.autoSizeColumn(i);
        }
    }
}
