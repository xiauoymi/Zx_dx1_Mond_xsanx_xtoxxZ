package com.monsanto.metricspos.services.excel.serviceCenter;

import com.monsanto.metricspos.services.excel.XlsAbstractStyler;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFPalette;
import org.apache.poi.hssf.util.HSSFColor;
import org.springframework.util.Assert;

public class ServiceCenterXlsColHeaderStyler extends XlsAbstractStyler
{

	public HSSFCellStyle getCellStyle(boolean isEvenRow){
		Assert.notNull(this.getWorkbook(), "Workbook should not be null");
		
		HSSFCellStyle cellStyle = this.getWorkbook().createCellStyle();
		
		HSSFPalette palette = this.getWorkbook().getCustomPalette();
		palette.setColorAtIndex(HSSFColor.GREEN.index,
				(byte) 55, //RGB red
				(byte) 96, //RGB green
				(byte) 145 //RGB blue
				);
		cellStyle.setFillForegroundColor(HSSFColor.GREEN.index);
		cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

		HSSFFont font = this.getWorkbook().createFont();
		font.setColor(HSSFColor.WHITE.index);
		font.setFontName("Arial");
		font.setFontHeightInPoints((short)9);
		font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		cellStyle.setFont(font);
        cellStyle.setBorderBottom((short) 2);
        cellStyle.setBorderLeft((short) 2);
        cellStyle.setBorderRight((short) 2);
        cellStyle.setBorderTop((short) 2);

		
		cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		cellStyle.setVerticalAlignment(HSSFCellStyle.VERTICAL_CENTER);
		return cellStyle;
	}

	@Override
	public short getRowHeight() {
		return 20;
	}

}
