package com.monsanto.metricspos.services.mails;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.ExportServices;
import com.monsanto.metricspos.core.MailServices;
import com.monsanto.metricspos.core.PdfSummaryWriter;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.springframework.core.io.*;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.ByteArrayOutputStream;

import java.util.Collections;
import java.util.List;

/**
 * ItemProcessor used for generating reports mail for a service center
 *
 * @author Martin Gorostegui
 */
public class SummaryMailSender implements MailServices<ScoreSummaryCampaignNode> {

    private ExportServices xlsExporter;

    private PdfSummaryWriter pdfSummaryWriter;

    private JavaMailSender mailSender;

    private String from;
    private String overrideTo;
    private String subject;
    private String text;
    private String xlsName;
    private String pdfName;
    private static final String SERVICE_CENTER_NAME_PLACEHOLDER = "<%CDS%>";

    public void setXlsExporter(ExportServices xlsExporter) {
        this.xlsExporter = xlsExporter;
    }

    public void setPdfSummaryWriter(PdfSummaryWriter pdfSummaryWriter) {
        this.pdfSummaryWriter = pdfSummaryWriter;
    }

    public void setMailSender(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public void setOverrideTo(String overrideTo) {
        this.overrideTo = overrideTo;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setXlsName(String xlsName) {
        this.xlsName = xlsName;
    }

    public void setPdfName(String pdfName) {
        this.pdfName = pdfName;
    }

    @Override
    public void sendSummary(ScoreSummaryCampaignNode summary) throws Exception {
        MimeMessage mimeMessage = this.newMail(summary);
        mailSender.send(mimeMessage);
    }

    @Override
    public MimeMessage newMail(ScoreSummaryCampaignNode summary) throws Exception {

        ByteArrayOutputStream xlsBaos = new ByteArrayOutputStream();
        xlsExporter.export(xlsBaos, summary);

        ByteArrayOutputStream pdfBaos = new ByteArrayOutputStream();
        pdfSummaryWriter.export(pdfBaos, summary.getCampaign(), summary.getServiceCenter(), summary);

        return createMimeMessage(xlsBaos.toByteArray(), pdfBaos.toByteArray(), summary.getServiceCenter());
    }

    private MimeMessage createMimeMessage(byte[] xlsAttachment, byte[] pdfAttachment, ServiceCenter sc) throws MessagingException {
        MimeMessage message = mailSender.createMimeMessage();

        MimeMessageHelper helper = new MimeMessageHelper(message, true,"UTF-8");

        helper.addAttachment(xlsName + ".xls", new ByteArrayResource(xlsAttachment), "application/vnd.ms-excel");
        helper.addAttachment(pdfName + ".pdf", new ByteArrayResource(pdfAttachment), "application/pdf");

        helper.setFrom(from);
        String[] addresses;
        String[] addressesCC;

        if (this.overrideTo != null && !this.overrideTo.isEmpty()) {
            addresses = this.overrideTo.split(",");
            addressesCC = new String[]{};
        } else {
            List<String> mailAddressesList = Lists.newArrayList();

            for (PointOfSale pos : sc.getPointsOfSale()) {
                if (pos.getMail() != null) {
                    String[] split = pos.getMail().split(",");
                    Collections.addAll(mailAddressesList, split);
                }
            }

            addresses = mailAddressesList.toArray(new String[mailAddressesList.size()]);
            addressesCC = sc.getMail().split(",");
        }

        for (String address : addresses) {
            helper.addTo(address.trim());
        }

        for (String address : addressesCC) {
            helper.addCc(address.trim());
        }

        helper.setSubject(subject.replace(SERVICE_CENTER_NAME_PLACEHOLDER, sc.getName()));

        String textReplaced = text.replace(SERVICE_CENTER_NAME_PLACEHOLDER, sc.getName());

        String htmlText = "<p> <pre style=\"font-family:Calibri;font-size:11pt;\">" + textReplaced + "</pre></p>";

        helper.setText(htmlText, true);

        return message;
    }
}
