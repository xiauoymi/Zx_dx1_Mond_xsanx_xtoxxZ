package com.monsanto.metricspos.services.pdf;

import com.itextpdf.text.*;
import com.itextpdf.text.Font.FontStyle;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.monsanto.metricspos.core.PdfSummaryWriter;
import com.monsanto.metricspos.core.externaldata.comparator.ScoreServiceCenterComparator;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;

import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.services.pdf.exceptions.ExportException;
import com.monsanto.utils.Validate;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

/**
 * Writes a PDF with the submetric summary for a given Service Center.
 * <p/>
 * The columns to show are:
 * <ul>
 * <li>Module name</li>
 * <li>Metric name</li>
 * <li>ForSubmetric name</li>
 * <li>ForSubmetric max points</li>
 * <li>ForSubmetric points (percent)</li>
 * <li>Total of point for the metric</li>
 * <li>Total of point for the module</li>
 * <li>Total of point for the Service Center</li>
 * </ul>
 *
 * @author fez
 */
public class PdfSummaryWriterImpl implements PdfSummaryWriter, InitializingBean {

   //private String pointsPercentFormat;
    private String percentSymbol;
    private String notYetCalculated;
    private String[] colHeaders;
    private String[] colHeadersServicesCenter;
    private float titleFontSize;
    private float textFontSize;
    private float summaryTableHeaderFontSize;
    private float summaryCenterServiceTableHeaderFontSize;
    private float summaryCenterServiceTableFontSize;
    private float subTextFontSize;
    private int maxPositionRankSc;
    private String greetings;
    private String points;
    private String weightingText;
    private String subtext;
    private Resource logoLeft;
    private Resource logoRight;
    private Resource categoriasImg;

    private static final BaseColor TABLE_BORDER_COLOR = BaseColor.WHITE;
    private static final BaseColor FONT_BASE_COLOR_WHITE = BaseColor.WHITE;
    private static final BaseColor FONT_BASE_COLOR_BLUE = new BaseColor(49,85,130);

    private static final float TWENTY = 20;
    private static final float EIGHTEEN = 18;
    private static final float TEN = 10;
    private static final int ZERO = 0;


    /**
     * Export the submetrics summary into a pdf report
     */
    @Override
    public void export(OutputStream outputStream, Campaign campaign,
                       ServiceCenter serviceCenter, ScoreSummaryCampaignNode summary) {


        Document document = new Document(PageSize.A4.rotate(), TWENTY, TWENTY, EIGHTEEN, EIGHTEEN);

        try {
            PdfWriter.getInstance(document, outputStream);
            //document.setMargins(5f,5f,10f,10f);
            document.open();

            // REQUIREMENT (2597 - UC) -- SHELG:
            // Requirement 1:
            PdfPTable titleTable = createTitleTable(campaign);
            document.add(titleTable);

            // a. Delete the first page that contains an image
            //document.add(createImgTable());
            //document.newPage();
            //document.add(titleTable);

            //PdfPTable headerTable = createHeaderTable(serviceCenter, campaign, summary);
            PdfPTable headerTable = createHeaderTable(serviceCenter, summary);
            document.add(headerTable);

            PdfPTable table = new PdfPTable(new float[]{5, 0.2f, 4});
            table.setWidthPercentage(100f);

            PdfPTable summaryTable = createSummaryTable(summary);
            PdfPCell summaryTableCell = new PdfPCell(summaryTable);
            summaryTableCell.setBorder(ZERO);
            summaryTableCell.setVerticalAlignment(Element.ALIGN_TOP);
            summaryTableCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(summaryTableCell);

            PdfPCell emptyCell = new PdfPCell();
            emptyCell.setBorder(ZERO);
            table.addCell(emptyCell);

            PdfPTable servicesCenterTable = createServicesCenterTable(summary);
            PdfPCell servicesCenterTableCell = new PdfPCell(servicesCenterTable);
            servicesCenterTableCell.setBorder(ZERO);
            servicesCenterTableCell.setVerticalAlignment(Element.ALIGN_TOP);
            servicesCenterTableCell.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(servicesCenterTableCell);

            document.add(table);

            PdfPTable footerTable = createFooterTable();
            document.add(footerTable);

        } catch (DocumentException e) {
            throw new ExportException("Exporting for service center " + serviceCenter.getCuit(), e);
        } catch (IOException e) {
            throw new ExportException("Exporting for service center " + serviceCenter.getCuit(), e);
        } finally {
            document.close();
        }

    }

    /*private PdfPTable createImgTable() throws IOException, BadElementException  {
        PdfPTable table = new PdfPTable(new float[]{1});
        table.setWidthPercentage(100f);

        Image image = Image.getInstance(categoriasImg.getURL());
        image.scaleToFit(1200, 450);
        PdfPCell imageLeft = new PdfPCell(image);
        imageLeft.setBorder(ZERO);
        imageLeft.setBorderWidthBottom(2f);
        imageLeft.setVerticalAlignment(Element.ALIGN_MIDDLE);
        imageLeft.setHorizontalAlignment(Element.ALIGN_CENTER);
        imageLeft.setPaddingBottom(TEN);
        table.addCell(imageLeft);

        return table;
    }*/

    /**
     * Create the PdfTable object for the report title
     *
     * @param campaign
     * @return
     */
    private PdfPTable createTitleTable(Campaign campaign) throws IOException, BadElementException {
        PdfPTable table = new PdfPTable(new float[]{1, 3, 1});
        table.setWidthPercentage(100f);

        // REQUIREMENT (2597 - UC) -- SHELG:
        // Requirement 1:
        // b. Update the second page with the next items:
        // 1. Modify header, updating the logo, and the main title using the name of the campaign.

        Image image = Image.getInstance(logoLeft.getURL());
        image.scaleToFit(150, 60);
        PdfPCell imageLeft = new PdfPCell(image);
        imageLeft.setBorder(ZERO);
        imageLeft.setBorderWidthBottom(2f);
        imageLeft.setVerticalAlignment(Element.ALIGN_MIDDLE);
        imageLeft.setHorizontalAlignment(Element.ALIGN_LEFT);
        imageLeft.setPaddingBottom(TEN);
        table.addCell(imageLeft);

        //Phrase titleText = new Phrase(TITLE + campaign.getName() );
        Phrase titleText = new Phrase(campaign.getName() );
        titleText.getFont().setSize(this.titleFontSize);
        titleText.getFont().setStyle(FontStyle.BOLD.ordinal());
        PdfPCell title = new PdfPCell(titleText);
        title.setBorder(ZERO);
        title.setBorderWidthBottom(2f);
        title.setVerticalAlignment(Element.ALIGN_MIDDLE);
        title.setHorizontalAlignment(Element.ALIGN_CENTER);
        title.setPaddingBottom(TEN);
        table.addCell(title);

        image = Image.getInstance(logoRight.getURL());
        image.scaleToFit(150, 60);
        PdfPCell imageRight = new PdfPCell(image);
        imageRight.setBorder(ZERO);
        imageRight.setBorderWidthBottom(2f);
        imageRight.setVerticalAlignment(Element.ALIGN_MIDDLE);
        imageRight.setHorizontalAlignment(Element.ALIGN_RIGHT);
        imageRight.setPaddingBottom(TEN);
        table.addCell(imageRight);

        return table;
    }

    /**
     * Create the PdfTable object for the report header
     *
     * @param serviceCenter
     * @return
     */
    private PdfPTable createHeaderTable(ServiceCenter serviceCenter, ScoreSummaryCampaignNode summary) {
        PdfPTable table = new PdfPTable(1);
        table.setWidthPercentage(100f);

        String greet =  serviceCenter.getName().toUpperCase() + " (" + serviceCenter.getCuit() + ")";
        createPhraseAndAddInTable(table, this.greetings, greet, 0, Element.ALIGN_MIDDLE, Element.ALIGN_LEFT, 2f);

        // REQUIREMENT (2597 - UC) -- SHELG:
        // Requirement 1:
        // b. Update the second page with the next items:
        // 3. Remove the category “General Obtenida”.
        //String rating = campaign.computeRating(summary);
        //createPhraseAndAddInTable(table, RATING, rating, 0, Element.ALIGN_MIDDLE, Element.ALIGN_LEFT, 2f);
        //String premium = campaign.getRatingPremiumCategory();
        //createPhraseAndAddInTable(table, PREMIUM, premium, 0, Element.ALIGN_MIDDLE, Element.ALIGN_LEFT, 2f);

        BigDecimal point = discountDeductions(summary.getPoints(),summary.getDeductions());

        //5. Remove the “Puntaje Máximo” program shown next to the “puntaje obtenido”, and next to each “Métrica y Módulo”.
        //String labelPoints = formatPoints(points) + " / " + summary.getMaxPoints();
        String labelPoints = formatPoints(point);
        createPhraseAndAddInTable(table, this.points , labelPoints, 0, Element.ALIGN_MIDDLE, Element.ALIGN_LEFT, 10f);

        return table;
    }

    /**
     * Create a Phrase object with custom properties and add it in the PDftable object.
     * @param table
     * @param text
     * @param border
     * @param vAlignment
     * @param hAlignment
     * @param paddingBottom
     */
    private void createPhraseAndAddInTable(PdfPTable table, String header, String text, int border, int vAlignment, int hAlignment, float paddingBottom){
        Chunk headerChunk = new Chunk(header, FontFactory.getFont("", this.textFontSize ));
        String label = text != null && !text.isEmpty() ? text : "";
        Chunk textChunk = new Chunk(label, FontFactory.getFont("", this.textFontSize + 1, Font.BOLD));
        Phrase phrase = new Phrase();
        phrase.add(0,headerChunk);
        phrase.add(1,textChunk);
        this.createCellAndAddInTable (table, phrase, border, vAlignment, hAlignment, paddingBottom);
    }

    /**
     * Create a Cell Object and add it in the PDftable object.
     * @param table
     * @param phrase
     * @param border
     * @param vAlignment
     * @param hAlignment
     * @param paddingBottom
     */
    private void createCellAndAddInTable (PdfPTable table, Phrase phrase, int border, int vAlignment, int hAlignment, float paddingBottom){
        PdfPCell cell = new PdfPCell(phrase);
        cell.setBorder(border);
        cell.setVerticalAlignment(vAlignment);
        cell.setHorizontalAlignment(hAlignment);
        cell.setPaddingBottom(paddingBottom);
        table.addCell(cell);
    }

    /**
     * Create the PdfTable object for the report footer
     *
     * @return
     */
    private PdfPTable createFooterTable() throws IOException, DocumentException {

        PdfPTable table = new PdfPTable(1);
        table.setWidthPercentage(100f);

        Phrase textTop = new Phrase(this.subtext);
        textTop.getFont().setSize(this.subTextFontSize);
        textTop.getFont().setStyle(FontStyle.BOLD.ordinal());
        createCellAndAddInTable(table,textTop, 0, Element.ALIGN_MIDDLE, Element.ALIGN_LEFT, 10f);

        return table;
    }


    /**
     * Create the PdfTable object based on the summary of the calculated submetric values
     *
     * @param summary
     * @return
     * @throws DocumentException
     */
    private PdfPTable createSummaryTable(ScoreSummaryCampaignNode summary) {
        //Relative width for the nine columns
        //PdfPTable table = new PdfPTable(new float[]{3, 1.7f, 1.8f, 2.3f, 4.5f, 1.8f, 1.8f, 6});
        PdfPTable table = new PdfPTable(new float[]{3, 1.7f, 1.8f, 6});
        table.setWidthPercentage(60f);
        table.setHorizontalAlignment(Element.ALIGN_LEFT);

        this.createColumnHeaders(table, this.colHeaders, this.summaryTableHeaderFontSize);

        for (ScoreSummaryNode moduleNode : summary.getChildren()) {
            if(moduleNode.getMetric().addToSend()) {
                fillModuleData(table, moduleNode);
            }
        }

        // Filling with blank cells to prevent the last cell to expand
        addCellBlank(table, 4);

        return table;
    }

    /**
     * Create the PdfTable object based on the summary of the calculated order of serviceCenter
     *
     * @param summary
     * @return
     * @throws DocumentException
     */
    private PdfPTable createServicesCenterTable(ScoreSummaryCampaignNode summary) {
        // REQUIREMENT (2597 - UC) -- SHELG:
        // Requirement 1:
        PdfPTable table = new PdfPTable(new float[]{1.5f, 1.5f, 3});
        table.setWidthPercentage(40f);
        table.setHorizontalAlignment(Element.ALIGN_RIGHT);

        this.createColumnHeaders(table, this.colHeadersServicesCenter, this.summaryCenterServiceTableHeaderFontSize);

        ServiceCenter currentServicesCenter = summary.getServiceCenter();
        List<ServiceCenter> listServicesCenter = summary.getCampaign().getServiceCenters();
        if(!CollectionUtils.isEmpty(listServicesCenter)) {
            Collections.sort(listServicesCenter, new ScoreServiceCenterComparator());

            int position = 0;
            boolean isCurrentServiceCenterPrint = false;
            for (ServiceCenter servicesCenter : listServicesCenter) {
                position++;

                isCurrentServiceCenterPrint = addCellServicesCenter(table, currentServicesCenter, position, isCurrentServiceCenterPrint, servicesCenter);
            }
            // Filling with blank cells to prevent the last cell to expand
            addCellBlank(table, 3);
        }
        return table;
    }

    private boolean addCellServicesCenter(PdfPTable table, ServiceCenter currentServicesCenter, int position, boolean isCurrentServiceCenterPrint, ServiceCenter servicesCenter) {
        boolean result = isCurrentServiceCenterPrint;
        List<MetricScore> scores = servicesCenter.getScores();
        BigDecimal point = BigDecimal.ZERO;
        if(!CollectionUtils.isEmpty(scores)) {
            for (MetricScore score : scores) {
                if (score.getMetric().getWeighting() == null || !(score.getMetric().getWeighting())) {
                    point = point.add(score.getPoints());
                }
            }
        }
        boolean isNameSC = currentServicesCenter.getName().equalsIgnoreCase(servicesCenter.getName());

        int switchCell = switchCellServicesCenter(position, result, isNameSC);

        switch (switchCell) {
            case 1:
                result = true;
                addCellBorder(table, "" + position, "", 1, BaseColor.WHITE, Element.ALIGN_CENTER, BaseColor.RED);
                addCellBorder(table, formatPoints(point), "", 1, BaseColor.WHITE, Element.ALIGN_CENTER, BaseColor.RED);
                addCellBorder(table, currentServicesCenter.getName(), "", 1, BaseColor.WHITE, Element.ALIGN_CENTER, BaseColor.RED);
                break;
            case 2:
                addCellBorder(table, "", "" + position, 1, BaseColor.WHITE, Element.ALIGN_CENTER, BaseColor.BLACK);
                addCellBorder(table, "", formatPoints(point), 1, BaseColor.WHITE, Element.ALIGN_CENTER, BaseColor.BLACK);
                addCellBorder(table, "", "", 1, BaseColor.WHITE, Element.ALIGN_CENTER, BaseColor.BLACK);
                break;
            case 3:
                for (int i = 0; i < 3; i++) {
                    addCellBorder(table, "", "...", 1, BaseColor.WHITE, Element.ALIGN_CENTER, BaseColor.BLACK);
                }
                break;
            default:
                break;
        }
        return result;
    }

    private int switchCellServicesCenter(int position, boolean isCurrentServiceCenterPrint, boolean isNameSC) {
        int switchCell;
        if (position < this.maxPositionRankSc) {
            if (isNameSC) {
                switchCell = 1;
            } else {
                switchCell = 2;
            }
        } else {
            switchCell = 0;
            if (position == this.maxPositionRankSc && !isCurrentServiceCenterPrint) {
                switchCell = 3;
            }
            if (!isCurrentServiceCenterPrint && isNameSC) {
                switchCell = 1;
            }
        }
        return switchCell;
    }

    /**
     * Fill with blank cells in table by the number of columns submitted for parameter
     *
     * @param table
     * @param rows
     */
    private void addCellBlank(PdfPTable table, int rows) {
        Phrase phrase = new Phrase("");
        PdfPCell cell = new PdfPCell(phrase);
        cell.setBorder(PdfPCell.NO_BORDER);
        for (int i = 0; i < rows; i++) {
            table.addCell(cell);
        }
    }

    private void fillModuleData(PdfPTable table, ScoreSummaryNode moduleNode) {

        ColorSpinner colorSpinner = new ColorSpinner();
        BaseColor color = colorSpinner.getColorModule();

        // REQUIREMENT (2597 - UC) -- SHELG:
        // Requirement 1:
        // b. Update the second page with the next items:
        // 5. Remove the “Puntaje Máximo” program shown next to the “puntaje obtenido”, and next to each “Métrica y Módulo”.
        //addCell(table, moduleNode.getMetric().getName(), "\n(" + moduleNode.getMaxPoints().toString() + " puntos)", moduleNode.getNumberOfLeaves(), color, Element.ALIGN_CENTER, FONT_BASE_COLOR_WHITE);
        addCell(table, moduleNode.getMetric().getName(), "", moduleNode.getNumberOfLeaves(), color, Element.ALIGN_CENTER, FONT_BASE_COLOR_WHITE);
        //addCell(table, moduleNode.getMaxPoints().toString(), moduleNode.getNumberOfLeaves(), color);
        BigDecimal deductions = discountDeductions(moduleNode.getPoints(), moduleNode.getDeductions());
        addCell(table, formatPoints(deductions), moduleNode.getNumberOfLeaves(), color);
        moduleNode.getMetric().computeModuleFormula(moduleNode);
		//addCell(table, moduleNode.getCategory(), moduleNode.getNumberOfLeaves(), color);
        //addCell(table, moduleNode.getPercentageIncent(), moduleNode.getNumberOfLeaves(), color);

        if (moduleNode.getChildren() == null || moduleNode.getChildren().isEmpty()) {
            addCell(table, "NO METRIC", 1, color);
            addCell(table, "-", 1, color);
            addCell(table, "-", 1, color);
            addCell(table, "-", 1, color);

            addCell(table, "NO SUBMETRIC", 1, color);
            addCell(table, "-", 1, color);
            addCell(table, "-", 1, color);
            addCell(table, "-", 1, color);
        } else {

            for (ScoreSummaryNode metricNode : moduleNode.getChildren()) {
                if(metricNode.getMetric().addToSend()) {
                    fillMetricData(table, metricNode, colorSpinner);
                }

            }
        }

    }

    /**
     * Discount deductions over points.
     * @return this discount.
     */
    private BigDecimal discountDeductions(BigDecimal points, BigDecimal deductions){
        return points.subtract(deductions);
    }

    private void fillMetricData(PdfPTable table, ScoreSummaryNode metricNode, ColorSpinner colorSpinner) {
        BaseColor backgroundColor = colorSpinner.getColorMetric();
        // REQUIREMENT (2597 - UC) -- SHELG:
        // Requirement 1:
        // b. Update the second page with the next items:
        // 5. Remove the “Puntaje Máximo” program shown next to the “puntaje obtenido”, and next to each “Métrica y Módulo”.
        //addCell(table, metricNode.getMetric().getName(), " (" + metricNode.getMaxPoints().toString() + " puntos)", metricNode.getNumberOfLeaves(), backgroundColor, Element.ALIGN_RIGHT, FONT_BASE_COLOR_BLUE);
       // addCell(table, metricNode.getMetric().getName(), "", metricNode.getNumberOfLeaves(), backgroundColor, Element.ALIGN_RIGHT, FONT_BASE_COLOR_BLUE);
        //addCell(table, metricNode.getMaxPoints().toString(), metricNode.getNumberOfLeaves(), color);
       // addCell(table, formatPoints(metricNode.getPoints()), metricNode.getNumberOfLeaves(), backgroundColor);

        if (metricNode.getChildren() == null || metricNode.getChildren().isEmpty()) {
            addCell(table, "NO SUBMETRIC", metricNode.getNumberOfLeaves(), backgroundColor);
            addCell(table, "-", metricNode.getNumberOfLeaves(), backgroundColor);
            addCell(table, "-", metricNode.getNumberOfLeaves(), backgroundColor);
            addCell(table, "-", metricNode.getNumberOfLeaves(), backgroundColor);
        } else {

            for (ScoreSummaryNode submetricNode : metricNode.getChildren()) {
                if(submetricNode.getMetric().addToSend()) {
                    fillSubMetricData(table, submetricNode, colorSpinner);
                }
            }
        }
    }

    private void fillSubMetricData(PdfPTable table, ScoreSummaryNode submetricNode, ColorSpinner colorSpinner) {
        BaseColor color = colorSpinner.getColorSubMetric();

        String value = submetricNode.isNoComputed() ? this.notYetCalculated : formatPoints(submetricNode.getPoints());
        String percent = "";
        String text = "";
        // REQUIREMENT (2597 - UC) -- SHELG:
        // Requirement 1:
        // b. Update the second page with the next items:
        // 5. Remove the “Puntaje Máximo” program shown next to the “puntaje obtenido”, and next to each “Métrica y Módulo”.
        if(submetricNode.getMetric().getWeighting()== null || !(submetricNode.getMetric().getWeighting())){
            //text = " (" + submetricNode.getMaxPoints().toString() + " puntos)";
            text = "";
        }else{
            text = " (" + this.weightingText + ")";
            percent = this.percentSymbol;
        }
        addCell(table, value + percent, 1, color);
        addCell(table, submetricNode.getMetric().getName(), text,  1, color , Element.ALIGN_LEFT, FONT_BASE_COLOR_BLUE);
        //addCell(table, String.valueOf(submetricNode.getMaxPoints()), 1, color);

        //String format = new DecimalFormat(this.pointsPercentFormat).format(submetricNode.getPointsPercent().doubleValue());
        //addCell(table, format + PERCENT_SYMBOL, 1, color);
    }


    /**
     * Add the column headers to the table
     *
     * @param table
     */
    private void createColumnHeaders(PdfPTable table, String[] colHeaders, float fontSize) {
        PdfPCell cell = null;
        for (String COL_HEADER : colHeaders) {
            Phrase phrase = new Phrase(COL_HEADER);
            Font font = phrase.getFont();
            font.setStyle(FontStyle.BOLD.ordinal());
            font.setSize(fontSize);
            font.setColor(FONT_BASE_COLOR_BLUE);
            cell = new PdfPCell(phrase);

            if(COL_HEADER.isEmpty()){
                cell.setBackgroundColor(BaseColor.WHITE);
                cell.setBorder(Rectangle.NO_BORDER);
            }else{
                cell.setBackgroundColor(BaseColor.LIGHT_GRAY);
            }

            cell.setPaddingBottom(5f);
            setSummaryCommonStyle(cell, Element.ALIGN_CENTER);
            table.addCell(cell);
        }
    }

    /**
     * Add a new cell to the table
     *
     * @param table
     * @param string
     * @param rowSpan
     * @param backgroundColor
     */
    private void addCell(PdfPTable table, String string, int rowSpan, BaseColor backgroundColor) {
        String cellText = (StringUtils.hasText(string))? string: "";
        addCell(table, "", cellText, rowSpan, backgroundColor, Element.ALIGN_CENTER, FONT_BASE_COLOR_BLUE);
    }

    private void addCell(PdfPTable table, String withB, String withoutB, int rowSpan, BaseColor backgroundColor, int vAlignment, BaseColor fontBaseColor) {
        String withBold = (withB != null) ? withB : "";
        String withoutBold = (withoutB != null) ? withoutB : "";
        Chunk headerChunk = new Chunk(withBold, FontFactory.getFont("", this.textFontSize, Font.BOLD, fontBaseColor ));
        Chunk textChunk = new Chunk(withoutBold, FontFactory.getFont("", this.textFontSize, fontBaseColor ));
        Phrase phrase = new Phrase();
        phrase.add(0,headerChunk);
        phrase.add(1,textChunk);
        Font font = phrase.getFont();
        //font.setSize(SUMMARY_TABLE_FONT_SIZE);
        font.setColor(BaseColor.WHITE);
        //FontSelector selector = new FontSelector();
        PdfPCell cell = new PdfPCell(phrase);
        cell.setRowspan(rowSpan);
        cell.setColspan(1); //All cells has colSpan=1
        cell.setBackgroundColor(backgroundColor);
        cell.setPaddingTop(5);
        cell.setPaddingBottom(5);
        setSummaryCommonStyle(cell, vAlignment);
        table.addCell(cell);
    }

    /**
     * Set a common style on a summary table cell
     *
     * @param cell
     */
    private void setSummaryCommonStyle(PdfPCell cell, int hAlignment) {
        cell.setBorderColor(TABLE_BORDER_COLOR);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setHorizontalAlignment(hAlignment);
    }

    private void addCellBorder(PdfPTable table, String withB, String withoutB, int rowSpan, BaseColor backgroundColor, int vAlignment, BaseColor fontBaseColor) {

        String withBold = (withB != null) ? withB : "";
        String withoutBold = (withoutB != null) ? withoutB : "";
        Chunk headerChunk = new Chunk(withBold, FontFactory.getFont("", this.summaryCenterServiceTableFontSize, Font.BOLD, fontBaseColor ));
        Chunk textChunk = new Chunk(withoutBold, FontFactory.getFont("", this.summaryCenterServiceTableFontSize, fontBaseColor ));
        Phrase phrase = new Phrase();
        phrase.add(0,headerChunk);
        phrase.add(1,textChunk);
        PdfPCell cell = new PdfPCell(phrase);
        cell.setRowspan(rowSpan);
        cell.setColspan(1); //All cells has colSpan=1
        cell.setBackgroundColor(backgroundColor);
        cell.setPadding(2);
        cell.setUseAscender(true);
        cell.setUseDescender(true);
        //cell.setPaddingTop(2);
        //cell.setPaddingBottom(2);
        cell.setBorder(PdfPCell.RECTANGLE);
        cell.setBorderColor(new BaseColor(149, 179, 215));
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        cell.setHorizontalAlignment(vAlignment);
        table.addCell(cell);
    }

    @Override
    public void afterPropertiesSet(){
        Validate.notNull(logoLeft, "Left logo should be provided");
        Validate.notNull(logoRight, "Right logo should be provided");
    }

    /**
     * Helper inner class to select the module rows color
     *
     * @author cfau
     */
    private class ColorSpinner {
        //private BaseColor LIGHT_ORANGE = new BaseColor(255, 207, 55);
        private BaseColor blue = new BaseColor(149, 179, 215);
        private BaseColor light_blue = new BaseColor(184, 204, 228);
        private BaseColor grey = new BaseColor(216, 216, 216);
        private BaseColor[] colorOptions = { blue, light_blue, grey};

        private int currentColor = 0;

        //Spin color until the last, then repeat the last
        public BaseColor getNextColor() {
            BaseColor color = colorOptions[currentColor];
            if (currentColor == 0) {
                currentColor++;
            }else{
                currentColor = 0;
            }
            return color;
        }

        public BaseColor getColorModule(){
            return blue;
        }

        public BaseColor getColorMetric(){
            return light_blue;
        }

        public BaseColor getColorSubMetric(){
            return grey;
        }
    }

    public Resource getCategoriasImg() {
        return categoriasImg;
    }

    public void setCategoriasImg(Resource categoriasImg) {
        this.categoriasImg = categoriasImg;
    }

    private String formatPoints(BigDecimal value){
        return value.setScale(2, BigDecimal.ROUND_HALF_UP).toString();
    }

    /**
     * Sets subTextFontSize
     * @param subTextFontSize
     */
    public void setSubTextFontSize(float subTextFontSize) {
        this.subTextFontSize = subTextFontSize;
    }
    /**
     * Sets summaryTableHeaderFontSize
     * @param summaryTableHeaderFontSize
     */
    public void setSummaryTableHeaderFontSize(float summaryTableHeaderFontSize) {
        this.summaryTableHeaderFontSize = summaryTableHeaderFontSize;
    }
    /**
     * Sets textFontSize
     * @param textFontSize
     */
    public void setTextFontSize(float textFontSize) {
        this.textFontSize = textFontSize;
    }
    /**
     * Sets titleFontSize
     * @param titleFontSize
     */
    public void setTitleFontSize(float titleFontSize) {
        this.titleFontSize = titleFontSize;
    }
    /**
     * Sets colHeadersServicesCenter
     * @param colHeadersServicesCenter
     */
    public void setColHeadersServicesCenter(String[] colHeadersServicesCenter) {
        this.colHeadersServicesCenter = colHeadersServicesCenter;
    }
    /**
     * Sets notYetCalculated
     * @param notYetCalculated
     */
    public void setNotYetCalculated(String notYetCalculated) {
        this.notYetCalculated = notYetCalculated;
    }
    /**
     * Sets percentSymbol
     * @param percentSymbol
     */
    public void setPercentSymbol(String percentSymbol) {
        this.percentSymbol = percentSymbol;
    }
    /**
     * Sets colHeaders
     * @param colHeaders
     */
    public void setColHeaders(String[] colHeaders) {
        this.colHeaders = colHeaders;
    }
    /**
     * Sets pointsPercentFormat
     * @param pointsPercentFormat
     */
    //public void setPointsPercentFormat(String pointsPercentFormat) {
    //    this.pointsPercentFormat = pointsPercentFormat;
    //}

    /**
     * Sets summaryCenterServiceTableFontSize
     * @param summaryCenterServiceTableFontSize
     */
    public void setSummaryCenterServiceTableFontSize(float summaryCenterServiceTableFontSize) {
        this.summaryCenterServiceTableFontSize = summaryCenterServiceTableFontSize;
    }

    /**
     * Sets summaryCenterServiceTableHeaderFontSize
     * @param summaryCenterServiceTableHeaderFontSize
     */
    public void setSummaryCenterServiceTableHeaderFontSize(float summaryCenterServiceTableHeaderFontSize) {
        this.summaryCenterServiceTableHeaderFontSize = summaryCenterServiceTableHeaderFontSize;
    }

    /**
     * Sets maxPositionRankSc
     * @param maxPositionRankSc
     */
    public void setMaxPositionRankSc(int maxPositionRankSc) {
        this.maxPositionRankSc = maxPositionRankSc;
    }

    /**
     * Sets greetings
     * @param greetings
     */
    public void setGreetings(String greetings) {
        this.greetings = greetings;
    }

    /**
     * Sets points
     * @param points
     */
    public void setPoints(String points) {
        this.points = points;
    }

    /**
     * Sets subtext
     * @param subtext
     */
    public void setSubtext(String subtext) {
        this.subtext = subtext;
    }

    /**
     * Sets weightingText
     * @param weightingText
     */
    public void setWeightingText(String weightingText) {
        this.weightingText = weightingText;
    }

    /**
     * Sets the image to use in header at the left
     *
     * @param logoLeft
     */
    public void setLogoLeft(Resource logoLeft) {
        this.logoLeft = logoLeft;
    }

    /**
     * Sets the image to use in header at the right
     *
     * @param logoRight
     */
    public void setLogoRight(Resource logoRight) {
        this.logoRight = logoRight;
    }
}

