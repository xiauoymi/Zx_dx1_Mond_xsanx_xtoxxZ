package com.monsanto.metricspos.services.pdf.exceptions;

/**
 * User: PPERA
 */
public class ExportException extends RuntimeException {
    public ExportException(String message, Exception e) {
        super(message, e);
    }
}
