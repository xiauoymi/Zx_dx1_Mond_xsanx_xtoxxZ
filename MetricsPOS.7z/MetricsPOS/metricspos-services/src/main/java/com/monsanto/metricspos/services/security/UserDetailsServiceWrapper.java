package com.monsanto.metricspos.services.security;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.monsanto.metricspos.core.AdminUserServices;
import com.monsanto.metricspos.core.EmployeeServices;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.Authority;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.services.security.impl.UserWrapperImpl;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.userdetails.UserDetails;
import org.springframework.security.userdetails.UserDetailsService;
import org.springframework.security.userdetails.UsernameNotFoundException;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.List;
import java.util.Set;

/**
 * Wraps the standard UserDao for Spring Security
 *
 * @author CAFAU
 */
public class UserDetailsServiceWrapper implements UserDetailsService {
    private static final Logger LOG = Logger.getLogger(UserDetailsServiceWrapper.class);
    private static final String METRIC_PLACEHOLDDER = "@@@METRIC@@@";
    private static final String SERVICE_CENTER_PLACEHOLDER = "@@@SERVICE_CENTER@@@";
    private static final String CAMPAIGN_PLACEHOLDER = "@@@CAMPAIGN@@@";
    private static final String TABLE_PLACEHOLDER = "@@@TABLE@@@";

    @Autowired
    private AdminUserServices adminUserServices;
    @Autowired
    private EmployeeServices employeeServices;

    @Override
    @Transactional
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
        AdminUser adminUser = adminUserServices.findAdminUserByUserName(userName);

        if (adminUser != null) {
            Collection<String> authorities = Lists.newArrayList(Authority.ADMINISTRATOR_ROLE);
            return new UserWrapperImpl(adminUser, authorities);
        }

        List<Employee> employees = employeeServices.findEmployeesByUsername(userName);

        if (employees == null || employees.isEmpty()) {
            String msg = "User with name '" + userName + "' not found";
            LOG.warn(msg);  // Log required for ISO (Information Security Office)
            throw new UsernameNotFoundException(msg);
        }

        Collection<String> authorities = this.makeAuthorities(employees);

        return new UserWrapperImpl(employees.get(0), employees, authorities);
    }

    private Collection<String> makeAuthorities(List<Employee> employees) {
        Set<String> roleNames = Sets.newHashSet();

        for (Employee employee : employees) {
            roleNames.addAll(extractEmployeeRoles(employee));
        }

        return roleNames;
    }

    private Set<String> extractEmployeeRoles(Employee employee) {
        Set<String> roleNames = Sets.newHashSet();

        if (employee.getGroups() != null) {
            Set<String> roleNamesWithReplacedPlaceHolders = this.processPlaceHolders(employee, this.extractAllAuthorities(employee));
            roleNames = this.replaceCampaignPlaceHolder(employee, roleNamesWithReplacedPlaceHolders);
            roleNames.add(Authority.APPLICATION_ACCESS);
        }

        return roleNames;
    }

    /**
     * Authorities can be metric-specific, sc-specific o neither. This algorithm contemplates the possibility
     * of having authorities that are both metric and sc specific.
     * All authorities of an employee al limited to the campaigns the employee belongs to therefore a suffix
     * indicating the campaign of the employee is appended to every authority.
     *
     * @param employee
     * @param authorities
     * @return
     */
    private Set<String> processPlaceHolders(Employee employee, Set<Authority> authorities) {
        Set<String> campaignRoleNames = Sets.newHashSet();

        for (Authority authority : authorities) {
            if (authority.getRoleName().contains(METRIC_PLACEHOLDDER)) {
                campaignRoleNames.addAll(extractMetricRoles(employee, authority.getRoleName()));
            } else if (authority.getRoleName().contains(TABLE_PLACEHOLDER)) {
                campaignRoleNames.addAll(extractTableRoles(employee, authority.getRoleName()));
            } else if (authority.getRoleName().contains(SERVICE_CENTER_PLACEHOLDER)) {
                campaignRoleNames.addAll(extractServiceCenterRoles(employee, authority.getRoleName()));
            } else {
                campaignRoleNames.add(authority.getRoleName());
            }
        }

        return campaignRoleNames;
    }

    private Set<String> extractTableRoles(Employee employee, String roleName) {
        Set<String> roles = Sets.newHashSet();

        Set<Integer> tableIds = extractTableIds(employee);

        for (Integer tableId : tableIds) {
            String roleWithTablePlaceHolder = replaceTablePlaceHolder(roleName, tableId);
            roles.add(roleWithTablePlaceHolder);
        }

        return roles;
    }

    private Set<String> extractMetricRoles(Employee employee, String roleName) {
        Set<String> roles = Sets.newHashSet();

        if (employee.getMetrics() != null) {
            for (Metric metric : employee.getMetrics()) {
                String roleWithMetric = replaceMetricPlaceHolder(roleName, metric);
                roles.add(roleWithMetric);
            }
        }

        return roles;
    }

    private Set<String> extractServiceCenterRoles(Employee employee, String role) {
        Set<String> roles = Sets.newHashSet();

        if (employee.getServiceCenters() != null) {
            for (ServiceCenter serviceCenter : employee.getServiceCenters()) {
                roles.add(replaceServiceCenterPlaceHolder(role, serviceCenter));
            }
        }

        return roles;
    }

    private Set<String> replaceCampaignPlaceHolder(Employee employee, Set<String> campaignRoleNames) {
        Set<String> result = Sets.newHashSet();

        for (String role : campaignRoleNames) {
            result.add(role.replace(CAMPAIGN_PLACEHOLDER, employee.getCampaign().getId().toString()));
        }

        return result;
    }

    private Set<Authority> extractAllAuthorities(Employee employee) {
        Set<Authority> authorities = Sets.newHashSet();

        for (Group group : employee.getGroups()) {
            authorities.addAll(group.getAuthorities());
        }

        return authorities;
    }

    private String replaceMetricPlaceHolder(String role, Metric metric) {
        return role.replace(METRIC_PLACEHOLDDER, metric.getId().toString());
    }

    private String replaceTablePlaceHolder(String roleName, Integer tableId) {
        return roleName.replace(TABLE_PLACEHOLDER, tableId.toString());
    }

    private String replaceServiceCenterPlaceHolder(String role, ServiceCenter serviceCenter) {
        return role.replace(SERVICE_CENTER_PLACEHOLDER, serviceCenter.getCuit());
    }

    private Set<Integer> extractTableIds(Employee employee) {
        Set<Integer> tableIds = Sets.newHashSet();

        if (employee.getMetrics() != null) {
            for (Metric metric : employee.getMetrics()) {
                if (metric.getTables() != null) {
                    for (DataTable table : metric.getTables()) {
                        tableIds.add(table.getId());
                    }
                }
            }
        }
        return tableIds;
    }
}
