package com.monsanto.metricspos.services.security.impl;

import com.monsanto.metricspos.core.security.EnvironmentContext;
import com.monsanto.metricspos.core.security.SecurityHolderStrategy;
import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.security.UserWrapper;
import org.springframework.security.Authentication;
import org.springframework.security.GrantedAuthority;
import org.springframework.security.context.SecurityContext;
import org.springframework.security.context.SecurityContextHolder;

/**
 * Provides access to the security data (user) via the SpringContextHolder
 *
 * @author CAFAU
 */
public class SecuritySupport implements SecurityHolderStrategy, EnvironmentContext {

    private static final String DEVELOPMENT_ENVIRONMENT = "dev";
    private static final String LOCAL_ENVIRONMENT = "win";

    /**
     * The environment name where the application is running.
     * <br/>
     * This can be: "win, dev, qc, prod".
     */
    private String environment;

    public SecuritySupport() {
    }

    @Override
    public User getCurrentUser() {
        Authentication authentication = getAuthentication();

        if (authentication != null) {
            Object o = authentication.getPrincipal();

            if (o instanceof UserWrapper) {
                return ((UserWrapper) o).getUser();
            }
        }
        return null;
    }

    private Authentication getAuthentication() {
        return getContext().getAuthentication();
    }

    public boolean hasUserPermission(String permission) {
        Authentication authentication = getAuthentication();

        if (authentication != null) {
            GrantedAuthority[] authorities = authentication.getAuthorities();

            if (authorities != null) {
                for (GrantedAuthority grantedAuthority : authorities) {
                    if (permission.equals(grantedAuthority.getAuthority())) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    @Override
    public boolean isLocalEnvironment() {
        return LOCAL_ENVIRONMENT.equals(environment);
    }

    @Override
    public boolean isDevEnvironment() {
        return DEVELOPMENT_ENVIRONMENT.equals(environment);
    }

    protected SecurityContext getContext() {
        return SecurityContextHolder.getContext();
    }

    @Override
    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public void setCurrentUser(Integer campaignId){
        Object o = getContext().getAuthentication().getPrincipal();
        ((UserWrapper) o).setCurrentUser(campaignId);
    }

}
