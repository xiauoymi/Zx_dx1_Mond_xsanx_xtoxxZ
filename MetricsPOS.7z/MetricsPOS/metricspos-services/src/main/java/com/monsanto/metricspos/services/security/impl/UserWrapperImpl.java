package com.monsanto.metricspos.services.security.impl;

import com.monsanto.metricspos.core.security.User;
import com.monsanto.metricspos.core.security.UserWrapper;
import com.monsanto.metricspos.core.structure.Employee;
import org.springframework.security.GrantedAuthority;
import org.springframework.security.GrantedAuthorityImpl;
import org.springframework.security.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Wraps the User entity to provide user information to the
 * Spring Security framework
 *
 * @author CAFAU
 */
public class UserWrapperImpl implements UserDetails, UserWrapper {

    private User user;
    private List<Employee> available = new ArrayList<Employee>();
    private GrantedAuthority[] authorities;

    public UserWrapperImpl(User user, Collection<String> authorities) {
        this.user = user;
        this.authorities = makeGrantedAuthorities(authorities);
    }

    public UserWrapperImpl(User user, List<Employee> available, Collection<String> authorities){
        this(user, authorities);
        this.available = available;
    }

    /**
     * Convert the list of roles (as string) to an array of GrantedAuthorities
     * TODO Move to util class
     *
     * @param roles The given roles
     * @return an array of GrantedAuthorities
     */
    private static GrantedAuthority[] makeGrantedAuthorities(Collection<String> roles) {
        if (roles == null) {
            return null;
        }

        GrantedAuthority[] grantedAuthorities = new GrantedAuthority[roles.size()];

        int i = 0;
        for (String authority : roles) {
            grantedAuthorities[i++] = new GrantedAuthorityImpl(authority);
        }

        return grantedAuthorities;
    }

    @Override
    public GrantedAuthority[] getAuthorities() {
        return authorities;
    }

    /**
     * WAN has no password
     *
     * @return
     */
    @Override
    public String getPassword() {
        return "";
    }

    @Override
    public String getUsername() {
        return user.getUsername();
    }

    /**
     * WAN credentials never expired
     *
     * @return true
     */
    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;  //To change body of implemented methods use File | Settings | File Templates.
    }

    /**
     * WAN credentials never expired.
     *
     * @return true
     */
    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return user.isEnabled();
    }


    @Override
    public User getUser() {
        return user;
    }

    private Employee findEmployeeByUserIdAndCampaignId(Integer campaignId) {
        for(Employee emp : available){
            if(emp.getCampaign().getId().equals(campaignId)){
                return emp;
            }
        }
        return null;
    }

    @Override
    public void setCurrentUser(Integer campaignId) {
        if(this.user.isAdmin()){
            return;
        }
        Employee emp = findEmployeeByUserIdAndCampaignId(campaignId);
        this.user = (emp != null ? emp : this.user);
    }
}
