package com.monsanto.metricspos.services.excel;

import com.monsanto.metricspos.services.excel.MetricPOSXlsBuilder.ColModel;
import com.monsanto.utils.GetterAndSetterTester;
import org.junit.Ignore;
import org.junit.Test;

/**
 * User: PPERA
 */
public class MetricPOSXlsBuilder_UT {
    @Test
    @Ignore
    public void testClassInstance() {
        GetterAndSetterTester tester = new GetterAndSetterTester();
        ColModel instance = new ColModel("name", "label", "type");
        tester.testInstance(instance);
    }
}
