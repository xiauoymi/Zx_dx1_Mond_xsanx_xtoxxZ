package com.monsanto.metricspos.services.excel;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.application.vo.MetricScoreVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricFactory;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.RowValuesServices;
import com.monsanto.metricspos.services.excel.exceptions.ExportException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: PPERA
 */
public class XlsExportServiceImpl_UT {
    private ScoreServices scoreServices;
    private ServiceCenter serviceCenter;
    private ComputeManager computeManager;
    private DataRowPersistor dataRowPersistor;

    private DataTable dataTable1;
    private DataRow dataRow;
    private List<MetricScoreVO> metricScoreVOs;
    private List<ServiceCenter> serviceCenters;

    @Before
    public void setUp() {
        Campaign campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 3, 3));
        this.computeManager = mock(ComputeManager.class);
        campaign.setComputeManager(computeManager);
        campaign.setId(1);
        MetricFactory factory = new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                Metric metric = new Metric(campaign, name);
                metric.setMaxPoints(maxPoints);
                metric.setComputeManager(computeManager);
                return metric;
            }
        };

        campaign.setFactory(factory);

        DataColumn dataColumn = newDataColumn("colName1", stringDataType());
        dataColumn.setActualColumnName("text1");
        dataColumn.setPrimaryKey(true);
        DataColumn dataColumn2 = newDataColumn("colName2", pointOfSaleDataType());
        dataColumn2.setActualColumnName("pointOfSale");
        dataColumn2.setPrimaryKey(true);
        DataColumn dataColumn3 = newDataColumn("colName3", numberDataType());
        dataColumn3.setActualColumnName("number1");
        dataColumn3.setPrimaryKey(true);
        DataColumn dataColumn4 = newDataColumn("colName4", serviceCenterDataType());
        dataColumn4.setActualColumnName("serviceCenter");
        dataColumn4.setPrimaryKey(true);

        DataRowPersistorFactory dataRowPersistorFactory = mock(DataRowPersistorFactory.class);
        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);

        dataRowPersistor = mock(DataRowPersistor.class);

        RowValuesServices rowValuesServices = mock(RowValuesServices.class);

        when(dataRowPersistorFactory.buildDataRowPersistor(Matchers.<DataTable>any())).thenReturn(dataRowPersistor);
        dataTable1 = new DataTable("name", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable1.setRowValuesServices(rowValuesServices);
        dataTable1.setId(1);

        DataTable dataTable2 = new DataTable("name2", Lists.newArrayList(dataColumn, dataColumn2), dataRowPersistorFactory);
        dataTable2.setRowValuesServices(rowValuesServices);
        dataTable2.setId(2);

        campaign.setDataTables(Lists.<DataTable>newArrayList(dataTable1, dataTable2));

        serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit("10");
        serviceCenter.setName("Hello!");

        Object rowValues = new Object();
        dataRow = new DataRow(dataTable1, rowValues);
        when(rowValuesServices.findRowsByTableAndServiceCenter(dataTable1, serviceCenter)).thenReturn(Lists.<DataRow>newArrayList(dataRow));
        when(dataRowPersistor.get(rowValues, "colName1")).thenReturn("A");
        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setAddress("Hola 123");
        when(dataRowPersistor.get(rowValues, "colName2")).thenReturn(pointOfSale);

        Metric module1 = campaign.addMetricDefinition("module1", 450);

        Metric metric1 = module1.addMetricDefinition("metric1", 200);
        Metric submetric11 = metric1.addMetricDefinition("submetric11", 200);
        MetricScore metricScore11 = new MetricScore(submetric11, this.serviceCenter);
        metricScore11.setPoints(BigDecimal.valueOf(120));

        Metric metric2 = module1.addMetricDefinition("metric2", 250);
        Metric submetric21 = metric2.addMetricDefinition("submetric21", 50);
        MetricScore metricScore21 = new MetricScore(submetric21, this.serviceCenter);
        metricScore21.setPoints(BigDecimal.valueOf(40.050));
        Metric submetric22 = metric2.addMetricDefinition("submetric22", 50);
        MetricScore metricScore22 = new MetricScore(submetric22, this.serviceCenter);
        metricScore22.setPoints(BigDecimal.valueOf(30.52));
        Metric submetric23 = metric2.addMetricDefinition("submetric23", 150);
        MetricScore metricScore23 = new MetricScore(submetric23, this.serviceCenter);
        metricScore23.setPoints(BigDecimal.valueOf(120));

        Metric module2 = campaign.addMetricDefinition("module2", 450);
        Metric metric3 = module2.addMetricDefinition("metric3", 100);
        Metric submetric31 = metric3.addMetricDefinition("submetric31", 25);
        MetricScore metricScore31 = new MetricScore(submetric31, this.serviceCenter);
        metricScore31.setPoints(BigDecimal.valueOf(10));
        Metric submetric32 = metric3.addMetricDefinition("submetric32", 75);
        MetricScore metricScore32 = new MetricScore(submetric32, this.serviceCenter);
        metricScore32.setPoints(BigDecimal.valueOf(10));

        Metric metric4 = module2.addMetricDefinition("metric4", 350);
        Metric submetric41 = metric4.addMetricDefinition("submetric41", 350);
        MetricScore metricScore41 = new MetricScore(submetric41, this.serviceCenter);
        metricScore41.setPoints(BigDecimal.valueOf(120.01));

        this.scoreServices = mock(ScoreServices.class);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric11, serviceCenter)).thenReturn(metricScore11);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric21, serviceCenter)).thenReturn(metricScore21);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric22, serviceCenter)).thenReturn(metricScore22);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric23, serviceCenter)).thenReturn(metricScore23);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric31, serviceCenter)).thenReturn(metricScore31);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric32, serviceCenter)).thenReturn(metricScore32);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric41, serviceCenter)).thenReturn(metricScore41);
        List<MetricScore> scores = Lists.newArrayList(
                metricScore11,
                metricScore21,
                metricScore22,
                metricScore23,
                metricScore31,
                metricScore32,
                metricScore41
        );

        serviceCenter.setScores(scores);

        ServiceCenter serviceCenter2 = new ServiceCenter();
        serviceCenter2.setCampaign(campaign);
        serviceCenter2.setCuit("11");
        serviceCenter2.setName("Hello2!");
        serviceCenter2.setScores(scores);

        serviceCenters = Lists.<ServiceCenter>newArrayList(serviceCenter, serviceCenter2);

        metricScoreVOs = MetricScoreVO.makeMetricScoreVOs(scores);
        when(this.scoreServices.findAllScoresByCampaign(
                eq(campaign),
                Matchers.<String>any(),
                Matchers.<String>any(),
                Matchers.<Map<String, Object>>any()
        )).thenReturn(
                scores
        );
    }

    @Test
    public void testExport() throws Exception {
        //OutputStream bos = new FileOutputStream("C:\\summary.xls");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(serviceCenter.getCampaign(), serviceCenter, this.scoreServices);
        new XlsExportServiceImpl().export(bos, scoreSummaryCampaignNode);

        assertNotNull(bos);
    }

    @Test
    public void testExportTable() throws Exception {
        List<DataRow> data = new ArrayList<DataRow>();
        data.add(dataRow);
        //OutputStream bos = new FileOutputStream("C:\\summary.xls");
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        new XlsExportServiceImpl().export(bos, dataTable1, data);

        assertNotNull(bos);
    }

    @Test
    public void testExportAllScores() throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        //OutputStream bos = new FileOutputStream("C:\\summary.xls");
        new XlsExportServiceImpl().export(bos, metricScoreVOs);

        //byte[] bytes = bos.toByteArray();
        assertNotNull(bos);
    }

    @Test
    public void testExportRanking() throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        //OutputStream bos = new FileOutputStream("C:\\serviceCenterRanking.xls");
        new XlsExportServiceImpl().export(serviceCenters, bos, 1);

        //byte[] bytes = bos.toByteArray();
        assertNotNull(bos);
    }

    @Test(expected = ExportException.class)
    public void testExportRankingWinthNotSc() throws Exception {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        new XlsExportServiceImpl().export(null, bos, 1);
    }

    @Test(expected = ExportException.class)
    public void testExportExceptionWithException() {
        try {
            throw new Exception();
        } catch (Exception e) {
            throw new ExportException("PDF Test", e);
        }
    }

    @Test(expected = ExportException.class)
    public void testExportException() {
        try {
            throw new Exception();
        } catch (Exception e) {
            throw new ExportException("PDF Test");
        }
    }

    private DataType stringDataType() {
        DataType dataType = new DataType();
        field("code").ofType(String.class).in(dataType).set("string");
        field("internalType").ofType(Class.class).in(dataType).set(String.class);
        return dataType;
    }

    private DataType pointOfSaleDataType() {
        DataType dataType = new DataType();
        dataType.setCode("POS");
        dataType.setInternalType(PointOfSale.class);
        return dataType;
    }

    private DataType numberDataType() {
        DataType dataType = new DataType();
        dataType.setCode("NUMBER");
        dataType.setInternalType(BigDecimal.class);
        return dataType;
    }

    private DataType serviceCenterDataType() {
        DataType dataType = new DataType();
        dataType.setCode("SC");
        dataType.setInternalType(ServiceCenter.class);
        return dataType;
    }

    private DataColumn newDataColumn(String columnName, DataType dataType) {
        return new DataColumn(columnName, dataType);
    }
}
