package com.monsanto.metricspos.services.mails;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.PdfSummaryWriter;
import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricFactory;
import com.monsanto.metricspos.core.metrics.MetricScore;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.services.excel.XlsExportServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.springframework.mail.javamail.JavaMailSender;

import javax.mail.internet.MimeMessage;
import java.io.OutputStream;
import java.math.BigDecimal;

import static com.monsanto.utils.DateUtils.newDate;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class SummaryMailSender_UT {
    private Campaign campaign;
    private ScoreServices scoreServices;
    private ServiceCenter serviceCenter;
    private ComputeManager computeManager;
    private SummaryMailSender summaryMailSender;
    private XlsExportServiceImpl xlsExportService;
    private PdfSummaryWriter pdfExportService;
    private JavaMailSender mailSender;
    private MimeMessage mimeMessage;

    @Before
    public void setUp() {
        this.campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 3, 3));
        this.computeManager = mock(ComputeManager.class);
        this.campaign.setComputeManager(computeManager);
        MetricFactory factory = new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                Metric metric = new Metric(campaign, name);
                metric.setMaxPoints(maxPoints);
                metric.setComputeManager(computeManager);
                return metric;
            }
        };

        this.campaign.setFactory(factory);

        serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit("10");
        serviceCenter.setName("Hello!");

        PointOfSale pointOfSale = new PointOfSale();
        pointOfSale.setMail("HELLO@goodbye.com");
        serviceCenter.setPointsOfSale(Lists.<PointOfSale>newArrayList(pointOfSale));
        serviceCenter.setMail("user@domain.com");

        Metric module1 = this.campaign.addMetricDefinition("module1", 450);

        Metric metric1 = module1.addMetricDefinition("metric1", 200);
        Metric submetric11 = metric1.addMetricDefinition("submetric11", 200);
        MetricScore metricScore11 = new MetricScore(submetric11, this.serviceCenter);
        metricScore11.setPoints(BigDecimal.valueOf(120));

        Metric metric2 = module1.addMetricDefinition("metric2", 250);
        Metric submetric21 = metric2.addMetricDefinition("submetric21", 50);
        MetricScore metricScore21 = new MetricScore(submetric21, this.serviceCenter);
        metricScore21.setPoints(BigDecimal.valueOf(40));
        Metric submetric22 = metric2.addMetricDefinition("submetric22", 50);
        MetricScore metricScore22 = new MetricScore(submetric22, this.serviceCenter);
        metricScore22.setPoints(BigDecimal.valueOf(30));
        Metric submetric23 = metric2.addMetricDefinition("submetric23", 150);
        MetricScore metricScore23 = new MetricScore(submetric23, this.serviceCenter);
        metricScore23.setPoints(BigDecimal.valueOf(120));

        Metric module2 = this.campaign.addMetricDefinition("module2", 450);
        Metric metric3 = module2.addMetricDefinition("metric3", 100);
        Metric submetric31 = metric3.addMetricDefinition("submetric31", 25);
        MetricScore metricScore31 = new MetricScore(submetric31, this.serviceCenter);
        metricScore31.setPoints(BigDecimal.valueOf(10));
        Metric submetric32 = metric3.addMetricDefinition("submetric32", 75);
        MetricScore metricScore32 = new MetricScore(submetric32, this.serviceCenter);
        metricScore32.setPoints(BigDecimal.valueOf(10));

        Metric metric4 = module2.addMetricDefinition("metric4", 350);
        Metric submetric41 = metric4.addMetricDefinition("submetric41", 350);
        MetricScore metricScore41 = new MetricScore(submetric41, this.serviceCenter);
        metricScore41.setPoints(BigDecimal.valueOf(120));

        this.scoreServices = mock(ScoreServices.class);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric11, serviceCenter)).thenReturn(metricScore11);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric21, serviceCenter)).thenReturn(metricScore21);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric22, serviceCenter)).thenReturn(metricScore22);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric23, serviceCenter)).thenReturn(metricScore23);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric31, serviceCenter)).thenReturn(metricScore31);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric32, serviceCenter)).thenReturn(metricScore32);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric41, serviceCenter)).thenReturn(metricScore41);

        this.summaryMailSender = new SummaryMailSender();
        this.xlsExportService = mock(XlsExportServiceImpl.class);
        this.summaryMailSender.setXlsExporter(this.xlsExportService);
        this.pdfExportService = mock(PdfSummaryWriter.class);
        this.summaryMailSender.setPdfSummaryWriter(this.pdfExportService);
        this.mailSender = mock(JavaMailSender.class);
        this.summaryMailSender.setMailSender(this.mailSender);

        mimeMessage = mock(MimeMessage.class);
        when(this.mailSender.createMimeMessage()).thenReturn(mimeMessage);

        this.summaryMailSender.setPdfName("pdfName");
        this.summaryMailSender.setFrom("me@me.com");
        this.summaryMailSender.setOverrideTo("me@me.com");
        this.summaryMailSender.setSubject("Hi");
        this.summaryMailSender.setText("Hihello!");
        this.summaryMailSender.setXlsName("xlsName");
    }

    @Test
    public void testNewMailCallsXlsExporterExportWithASummaryOfCampaignOne_WhenSendingSummary() throws Exception {
        // @Given a summary
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(serviceCenter.getCampaign(), serviceCenter, this.scoreServices);

        // @When sending the summary
        summaryMailSender.sendSummary(scoreSummaryCampaignNode);

        // @Then xlsExporter.export is called
        verify(xlsExportService, times(1)).export(Matchers.<OutputStream>any(), same(scoreSummaryCampaignNode));
    }

    @Test
    public void testNewMailCallsPdfExporterExportWithASummaryOfCampaignOne_WhenSendingSummary() throws Exception {
        // @Given a summary
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(serviceCenter.getCampaign(), serviceCenter, this.scoreServices);

        // @When sending the summary
        summaryMailSender.sendSummary(scoreSummaryCampaignNode);

        // @Then xlsExporter.export is called
        verify(pdfExportService, times(1)).export(Matchers.<OutputStream>any(), same(this.campaign), same(this.serviceCenter), same(scoreSummaryCampaignNode));
    }

    @Test
    public void testSendSummaryCallsMailSenderSendWithMimeMessage_WhenSendingSummary() throws Exception {
        // @Given a summary
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(serviceCenter.getCampaign(), serviceCenter, this.scoreServices);
        when(mailSender.createMimeMessage()).thenReturn(mimeMessage);

        // @When sending the summary
        summaryMailSender.sendSummary(scoreSummaryCampaignNode);

        // @Then xlsExporter.export is called
        verify(mailSender, times(1)).createMimeMessage();
        verify(mailSender, times(1)).send(mimeMessage);
    }

    @Test
    public void testSendSummarySendsMailToSCMail_WhenSendingSummaryWithEmptyOverrideTo() throws Exception {
        // @Given a summary
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(serviceCenter.getCampaign(), serviceCenter, this.scoreServices);
        summaryMailSender.setOverrideTo("");
        when(mailSender.createMimeMessage()).thenReturn(mimeMessage);

        // @When sending the summary
        summaryMailSender.sendSummary(scoreSummaryCampaignNode);

        // @Then xlsExporter.export is called
        verify(mailSender, times(1)).createMimeMessage();
        verify(mailSender, times(1)).send(mimeMessage);
    }
}
