package com.monsanto.metricspos.services.pdf;

import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.metrics.*;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryNode;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.services.pdf.exceptions.ExportException;
import org.junit.Before;
import org.junit.Test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import java.io.FileOutputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static com.monsanto.utils.DateUtils.newDate;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class PdfSummaryWriterImpl_UT {
    private Campaign campaign;
    private ScoreServices scoreServices;
    private ServiceCenter serviceCenter;
    private ComputeManager computeManager;


    @Before
    public void setUp() {
        this.campaign = new Campaign("name", newDate(2011, 1, 1), newDate(2012, 3, 3));
        this.computeManager = mock(ComputeManager.class);
        this.campaign.setComputeManager(computeManager);
        MetricFactory factory = new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                Metric metric = new Metric(campaign, name);
                metric.setMaxPoints(maxPoints);
                metric.setComputeManager(computeManager);
                return metric;
            }
        };

        this.campaign.setFactory(factory);

        serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit("20123456789");
        serviceCenter.setName("SCTEST");

        Metric module1 = this.campaign.addMetricDefinition("module1", 450);

        Metric metric1 = module1.addMetricDefinition("metric1", 200);
        Metric submetric11 = metric1.addMetricDefinition("submetric11", 200);
        MetricScore metricScore11 = new MetricScore(submetric11, this.serviceCenter);
        metricScore11.setPoints(BigDecimal.valueOf(120));

        Metric metric2 = module1.addMetricDefinition("metric2", 250);
        Metric submetric21 = metric2.addMetricDefinition("submetric21", 50);
        MetricScore metricScore21 = new MetricScore(submetric21, this.serviceCenter);
        metricScore21.setPoints(BigDecimal.valueOf(40));
        Metric submetric22 = metric2.addMetricDefinition("submetric22", 50);
        MetricScore metricScore22 = new MetricScore(submetric22, this.serviceCenter);
        metricScore22.setPoints(BigDecimal.valueOf(30));
        Metric submetric23 = metric2.addMetricDefinition("submetric23", 150);
        MetricScore metricScore23 = new MetricScore(submetric23, this.serviceCenter);
        metricScore23.setPoints(BigDecimal.valueOf(120));

        Metric module2 = this.campaign.addMetricDefinition("module2", 450);
        Metric metric3 = module2.addMetricDefinition("metric3", 100);
        Metric submetric31 = metric3.addMetricDefinition("submetric31", 25);
        MetricScore metricScore31 = new MetricScore(submetric31, this.serviceCenter);
        metricScore31.setPoints(BigDecimal.valueOf(10.005));
        Metric submetric32 = metric3.addMetricDefinition("submetric32", 75);
        MetricScore metricScore32 = new MetricScore(submetric32, this.serviceCenter);
        metricScore32.setPoints(BigDecimal.valueOf(10.5));

        Metric metric4 = module2.addMetricDefinition("metric4", 350);
        Metric submetric41 = metric4.addMetricDefinition("submetric41", 350);
        MetricScore metricScore41 = new MetricScore(submetric41, this.serviceCenter);
        metricScore41.setPoints(BigDecimal.valueOf(120.11111));

        Metric module3 = this.campaign.addMetricDefinition("module3", 450);
        Metric metric5 = module3.addMetricDefinition("metric5", 150);
        Metric submetric51 = metric5.addMetricDefinition("submetric51", 350);
        MetricScore metricScore51 = new MetricScore(submetric51, this.serviceCenter);
        metricScore51.setPoints(BigDecimal.valueOf(10));


        Metric module4 = this.campaign.addMetricDefinition("module4", 450);
        Metric metric6 = module4.addMetricDefinition("metric6", 350);
        Metric submetric61 = metric6.addMetricDefinition("ponderador61", 350);
        submetric61.setWeighting(true);
        MetricScore metricScore61 = new MetricScore(submetric61, this.serviceCenter);
        metricScore61.setPoints(BigDecimal.valueOf(10));

        Metric submetric62 = metric6.addMetricDefinition("submetric62", 100);
        MetricScore metricScore62 = new MetricScore(submetric62, this.serviceCenter);
        metricScore62.setPoints(BigDecimal.valueOf(20.01));


        this.scoreServices = mock(ScoreServices.class);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric11, serviceCenter)).thenReturn(metricScore11);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric21, serviceCenter)).thenReturn(metricScore21);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric22, serviceCenter)).thenReturn(metricScore22);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric23, serviceCenter)).thenReturn(metricScore23);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric31, serviceCenter)).thenReturn(metricScore31);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric32, serviceCenter)).thenReturn(metricScore32);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric41, serviceCenter)).thenReturn(metricScore41);
        when(this.scoreServices.findScoreByMetricAndServiceCenter(submetric61, serviceCenter)).thenReturn(metricScore61);


        ServiceCenter serviceCenter2 = new ServiceCenter();
        serviceCenter2.setCampaign(campaign);
        serviceCenter2.setCuit("20123456782");
        serviceCenter2.setName("SCTEST2");

        Metric module02 = this.campaign.addMetricDefinition("module02", 450);

        Metric metric02 = module02.addMetricDefinition("metric02", 200);
        Metric submetric021 = metric02.addMetricDefinition("submetric021", 200);
        MetricScore metricScore021 = new MetricScore(submetric021, serviceCenter2);
        metricScore021.setPoints(BigDecimal.valueOf(120));

        Metric metric03 = module02.addMetricDefinition("metric03", 250);
        Metric submetric031 = metric03.addMetricDefinition("submetric031", 50);
        MetricScore metricScore031 = new MetricScore(submetric031, this.serviceCenter);
        metricScore031.setPoints(BigDecimal.valueOf(40));
        Metric submetric032 = metric03.addMetricDefinition("submetric032", 50);
        MetricScore metricScore032 = new MetricScore(submetric032, this.serviceCenter);
        metricScore032.setPoints(BigDecimal.valueOf(30));
        Metric submetric033 = metric03.addMetricDefinition("submetric033", 150);
        MetricScore metricScore033 = new MetricScore(submetric033, this.serviceCenter);
        metricScore033.setPoints(BigDecimal.valueOf(120));

        List<ServiceCenter> listSC = new ArrayList<ServiceCenter>();
        listSC.add(this.serviceCenter);
        listSC.add(serviceCenter2);

        campaign.setServiceCenters(listSC);

    }

    @Test
    public void testExport() {

        ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"spring/metricspos-services.appctx.xml"});

        // OutputStream fos = new FileOutputStream("C:\\summary.pdf");
        // new ByteArrayOutputStream();
        OutputStream fos = mock(FileOutputStream.class);

        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(serviceCenter.getCampaign(), serviceCenter, this.scoreServices);

        PdfSummaryWriterImpl pdfSubmetricSummaryWriter = (PdfSummaryWriterImpl) context.getBean("pdfSummaryWriter");

        pdfSubmetricSummaryWriter.setLogoLeft(new ClassPathResource("/images/SoyMagnun.png"));
        pdfSubmetricSummaryWriter.setLogoRight(new ClassPathResource("/images/Monsanto.gif"));
        pdfSubmetricSummaryWriter.setCategoriasImg(new ClassPathResource("/images/categorias.gif"));

        pdfSubmetricSummaryWriter.export(fos, campaign, serviceCenter, scoreSummaryCampaignNode);

    }

    @Test
    public void testExportModuleWithoutChildren() {

        ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"spring/metricspos-services.appctx.xml"});

        OutputStream fos = mock(FileOutputStream.class);
        //OutputStream fos = new FileOutputStream("C:\\Projects\\MetricsPOS\\summary.pdf");
        // new ByteArrayOutputStream();

        ScoreSummaryCampaignNode scoreSummaryCampaignNode = new ScoreSummaryCampaignNode(serviceCenter.getCampaign(), serviceCenter, this.scoreServices);

        PdfSummaryWriterImpl pdfSubmetricSummaryWriter = (PdfSummaryWriterImpl) context.getBean("pdfSummaryWriter");

        pdfSubmetricSummaryWriter.setLogoLeft(new ClassPathResource("/images/SoyMagnun.png"));
        pdfSubmetricSummaryWriter.setLogoRight(new ClassPathResource("/images/Monsanto.gif"));
        pdfSubmetricSummaryWriter.setCategoriasImg(new ClassPathResource("/images/categorias.gif"));

        ScoreSummaryNode moduleNode = scoreSummaryCampaignNode.getChildren().get(0);
        moduleNode.getChildren().clear();

        pdfSubmetricSummaryWriter.export(fos, campaign, serviceCenter, scoreSummaryCampaignNode);

    }

    @Test(expected = ExportException.class)
    public void testExportException() {
        try {
            throw new Exception();
        } catch (Exception e) {
            throw new ExportException("PDF Test", e);
        }
    }


}
