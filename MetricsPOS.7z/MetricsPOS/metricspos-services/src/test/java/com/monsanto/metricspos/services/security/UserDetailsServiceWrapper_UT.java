package com.monsanto.metricspos.services.security;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.AdminUserServices;
import com.monsanto.metricspos.core.EmployeeServices;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.Authority;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.userdetails.UserDetails;
import org.springframework.security.userdetails.UsernameNotFoundException;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * User: PPERA
 */
public class UserDetailsServiceWrapper_UT {

    private UserDetailsServiceWrapper userDetailsServiceWrapper;

    @Before
    public void setUp() {
        userDetailsServiceWrapper = new UserDetailsServiceWrapper();
        AdminUserServices adminUserServices = mock(AdminUserServices.class);
        EmployeeServices employeeServices = mock(EmployeeServices.class);
        field("adminUserServices").ofType(AdminUserServices.class).in(this.userDetailsServiceWrapper).set(adminUserServices);
        field("employeeServices").ofType(EmployeeServices.class).in(this.userDetailsServiceWrapper).set(employeeServices);

        AdminUser adminUser = new AdminUser();
        adminUser.setId(1);
        adminUser.setUsername("ppera");
        adminUser.setEnabled(true);

        when(adminUserServices.findAdminUserByUserName(adminUser.getUsername())).thenReturn(adminUser);

        Authority viewAllMetricsAuthority = new Authority();
        viewAllMetricsAuthority.setId(1);
        viewAllMetricsAuthority.setRoleName("VIEW_ALL_METRICS_@@@CAMPAIGN@@@");
        viewAllMetricsAuthority.setName("View all metrics");
        viewAllMetricsAuthority.setDescription("Authority to see the details of any metric");

        Authority viewAssignedServiceCentersAuthority = new Authority();
        viewAssignedServiceCentersAuthority.setId(1);
        viewAssignedServiceCentersAuthority.setRoleName("VIEW_SERVICE_CENTER_@@@SERVICE_CENTER@@@_@@@CAMPAIGN@@@");
        viewAssignedServiceCentersAuthority.setName("View assigned service centers");
        viewAssignedServiceCentersAuthority.setDescription("Authority to see the details of assigned service centers");

        Authority viewAssignedMetricsAuthority = new Authority();
        viewAssignedMetricsAuthority.setId(1);
        viewAssignedMetricsAuthority.setRoleName("VIEW_METRIC_@@@METRIC@@@_@@@CAMPAIGN@@@");
        viewAssignedMetricsAuthority.setName("View all metrics");
        viewAssignedMetricsAuthority.setDescription("Authority to see the details of the assigned metrics");

        Authority viewAllServiceCentersAuthority = new Authority();
        viewAllServiceCentersAuthority.setId(1);
        viewAllServiceCentersAuthority.setRoleName("VIEW_ALL_SERVICE_CENTERS_@@@CAMPAIGN@@@");
        viewAllServiceCentersAuthority.setName("View all service centers");
        viewAllServiceCentersAuthority.setDescription("Authority to see the details of any service center");

        Authority viewAssignedTableAuthority = new Authority();
        viewAssignedTableAuthority.setId(1);
        viewAssignedTableAuthority.setRoleName("VIEW_TABLE_@@@TABLE@@@");
        viewAssignedTableAuthority.setName("View all service centers");
        viewAssignedTableAuthority.setDescription("Authority to see the details of any service center");

        Group salesGroup = new Group();
        salesGroup.setName("Sales Group");
        salesGroup.setEnabled(true);
        salesGroup.setAuthorities(Lists.<Authority>newArrayList(viewAllMetricsAuthority, viewAssignedServiceCentersAuthority, viewAssignedTableAuthority));

        Group businessGroup = new Group();
        businessGroup.setName("Sales Group");
        businessGroup.setEnabled(true);
        businessGroup.setAuthorities(Lists.<Authority>newArrayList(viewAssignedMetricsAuthority, viewAllServiceCentersAuthority));

        Campaign campaign1 = new Campaign("campaign1", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign1.setId(1);
        Campaign campaign2 = new Campaign("campaign2", newDate(2012, 1, 2), newDate(2013, 1, 1));
        campaign2.setId(2);

        ServiceCenter serviceCenter1 = new ServiceCenter();
        serviceCenter1.setCuit("123");
        ServiceCenter serviceCenter2 = new ServiceCenter();
        serviceCenter2.setCuit("456");
        ServiceCenter serviceCenter3 = new ServiceCenter();
        serviceCenter3.setCuit("789");
        campaign2.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter1, serviceCenter2, serviceCenter3));
        Metric metric1 = new Metric(campaign1, "metric1");
        metric1.setId(1);
        Metric metric2 = new Metric(campaign1, "metric2");
        metric2.setId(2);

        Employee businessEmployee = new Employee();
        businessEmployee.setId(1l);
        businessEmployee.setName("Business User");
        businessEmployee.setUsername("business");
        businessEmployee.setCampaign(campaign1);
        businessEmployee.setLoaded(true);
        businessEmployee.setGroups(Lists.<Group>newArrayList(businessGroup));
        businessEmployee.setMetrics(Lists.<Metric>newArrayList(metric1, metric2));
        businessEmployee.setServiceCenters(Lists.<ServiceCenter>newArrayList());
        businessEmployee.setEnabled(true);
        businessGroup.setMembers(Lists.<Employee>newArrayList(businessEmployee));

        Employee rtvEmployee = new Employee();
        rtvEmployee.setId(2l);
        rtvEmployee.setName("Sales User");
        rtvEmployee.setUsername("rtv");
        rtvEmployee.setCampaign(campaign2);
        rtvEmployee.setLoaded(true);
        rtvEmployee.setGroups(Lists.<Group>newArrayList(salesGroup));
        rtvEmployee.setMetrics(Lists.<Metric>newArrayList());
        rtvEmployee.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter1, serviceCenter2));
        rtvEmployee.setEnabled(true);
        salesGroup.setMembers(Lists.<Employee>newArrayList(rtvEmployee));

        Employee multiCampaignEmployee1 = new Employee();
        multiCampaignEmployee1.setId(3l);
        multiCampaignEmployee1.setName("Multi User");
        multiCampaignEmployee1.setUsername("multiCampaignEmployee");
        multiCampaignEmployee1.setCampaign(campaign1);
        multiCampaignEmployee1.setLoaded(true);
        multiCampaignEmployee1.setGroups(Lists.<Group>newArrayList(businessGroup));
        multiCampaignEmployee1.setMetrics(Lists.<Metric>newArrayList(metric2));
        multiCampaignEmployee1.setServiceCenters(Lists.<ServiceCenter>newArrayList());
        multiCampaignEmployee1.setEnabled(true);
        businessGroup.getMembers().add(multiCampaignEmployee1);

        Employee multiCampaignEmployee2 = new Employee();
        multiCampaignEmployee2.setId(4l);
        multiCampaignEmployee2.setName("Multi User");
        multiCampaignEmployee2.setUsername("multiCampaignEmployee");
        multiCampaignEmployee2.setCampaign(campaign2);
        multiCampaignEmployee2.setLoaded(true);
        multiCampaignEmployee2.setGroups(Lists.<Group>newArrayList(salesGroup));
        multiCampaignEmployee2.setMetrics(Lists.<Metric>newArrayList());
        multiCampaignEmployee2.setServiceCenters(Lists.<ServiceCenter>newArrayList(serviceCenter1, serviceCenter3));
        multiCampaignEmployee2.setEnabled(true);
        salesGroup.getMembers().add(multiCampaignEmployee2);

        when(employeeServices.findEmployeesByUsername(rtvEmployee.getUsername())).thenReturn(Lists.<Employee>newArrayList(rtvEmployee));
        when(employeeServices.findEmployeesByUsername(businessEmployee.getUsername())).thenReturn(Lists.<Employee>newArrayList(businessEmployee));
        when(employeeServices.findEmployeesByUsername("multiCampaignEmployee")).thenReturn(Lists.<Employee>newArrayList(multiCampaignEmployee1, multiCampaignEmployee2));
    }

    @Test
    public void testLoadUserByUsernameReturnsAUserWrapperWithTheSystemAdministratorRole_WhenLoadingWithTheUsernameOfAnAdministrator() {
        // @Given an existing admin username
        String username = "ppera";

        // @When loading the user
        UserDetails userDetails = this.userDetailsServiceWrapper.loadUserByUsername(username);

        // @Then the username is the input and the authority is SYSTEM_ADMINISTRATOR
        assertThat(userDetails.getUsername()).isEqualTo(username);
        assertThat(userDetails.getAuthorities()).onProperty("authority").contains(Authority.ADMINISTRATOR_ROLE);
    }

    @Test
    public void testLoadUserByUsernameReturnsAUserWrapperWithSalesRoles_WhenLoadingWithTheUsernameOfASalesRepresentative() {
        // @Given an existing admin username
        String username = "rtv";

        // @When loading the user
        UserDetails userDetails = this.userDetailsServiceWrapper.loadUserByUsername(username);

        // @Then the username is the input and the authorities are view all metrics of campaign 2 and view sc 123 and 456 of campaign 2
        assertThat(userDetails.getUsername()).isEqualTo(username);
        assertThat(userDetails.getAuthorities()).onProperty("authority").contains("VIEW_ALL_METRICS_2", "VIEW_SERVICE_CENTER_123_2", "VIEW_SERVICE_CENTER_456_2");
    }

    @Test
    public void testLoadUserByUsernameReturnsAUserWrapperWithBusinessRoles_WhenLoadingWithTheUsernameOfABusinessAnnalist() {
        // @Given an existing admin username
        String username = "business";

        // @When loading the user
        UserDetails userDetails = this.userDetailsServiceWrapper.loadUserByUsername(username);

        // @Then the username is the input and the authorities are view all metrics of campaign 2 and view sc 123 and 456 of campaign 2
        assertThat(userDetails.getUsername()).isEqualTo(username);
        assertThat(userDetails.getAuthorities()).onProperty("authority").contains("VIEW_METRIC_1_1", "VIEW_METRIC_2_1", "VIEW_ALL_SERVICE_CENTERS_1");
    }

    @Test
    public void testLoadUserByUsernameReturnsAUserWrapperWithBusinessRolesForCampaign1AndSalesRolesForCampaign2_WhenLoadingWithTheUsernameOfAMultiCampaignUserWithDifferentRolesInBothCampaigns() {
        // @Given an existing admin username
        String username = "multiCampaignEmployee";

        // @When loading the user
        UserDetails userDetails = this.userDetailsServiceWrapper.loadUserByUsername(username);

        // @Then the username is the input and the authorities are view all metrics of campaign 2 and view sc 123 and 456 of campaign 2
        assertThat(userDetails.getUsername()).isEqualTo(username);
        assertThat(userDetails.getAuthorities()).onProperty("authority").contains("VIEW_METRIC_2_1", "VIEW_ALL_SERVICE_CENTERS_1", "VIEW_ALL_METRICS_2", "VIEW_SERVICE_CENTER_123_2", "VIEW_SERVICE_CENTER_789_2");
    }

    @Test
    public void testLoadUserByUsernameThrowsException_WhenUsernameDoesNotExist() {
        // @Given an existing admin username
        String username = "userNotExistant";

        // @When loading the user

        try {
            UserDetails userDetails = this.userDetailsServiceWrapper.loadUserByUsername(username);
            fail();
        } catch (UsernameNotFoundException e) {
            assertThat(e.getMessage()).startsWith("User with name");
        } catch (Throwable t) {
            fail();
        }


    }
}
