package com.monsanto.metricspos.services.security.impl;

import org.junit.Before;
import org.junit.Test;
import org.springframework.security.Authentication;
import org.springframework.security.GrantedAuthority;
import org.springframework.security.GrantedAuthorityImpl;
import org.springframework.security.context.SecurityContext;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: PPERA
 */
public class SecuritySupport_UT {
    private SecurityContext context;

    private static class SecuritySupportForTest extends SecuritySupport {
        private SecurityContext context;

        private SecuritySupportForTest(SecurityContext context) {
            this.context = context;
        }

        @Override
        protected SecurityContext getContext() {
            return context;
        }
    }

    private SecuritySupport instance;
    private Authentication authentication;
    private GrantedAuthority[] authorities2;

    @Before
    public void setUp() {
        authentication = mock(Authentication.class);
        context = mock(SecurityContext.class);

        instance = new SecuritySupportForTest(context);

        List<GrantedAuthority> authorities = Arrays.asList(newGrantedAuthority("RoleA"), newGrantedAuthority("RoleB"));

        authorities2 = new GrantedAuthority[authorities.size()];
        authorities.toArray(authorities2);
    }

    private GrantedAuthority newGrantedAuthority(String role) {
        return new GrantedAuthorityImpl(role);
    }


    @Test
    public void testHasUserPermission() throws Exception {

        when(context.getAuthentication()).thenReturn(authentication);
        when(authentication.getAuthorities()).thenReturn(authorities2);

        assertTrue("This role should exists", instance.hasUserPermission("RoleA"));
        assertFalse("This role should NOTexists", instance.hasUserPermission("RoleX"));
    }
}
