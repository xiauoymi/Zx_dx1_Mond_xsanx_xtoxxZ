package com.monsanto.metricspos.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * Classes implementing this interface offers a Generic DAO to
 * access certain entity.
 * <br/>
 * See Spring Data JPA
 *
 * @author Carlos Fau
 *
 */
public interface JpaRepository<T,ID extends Serializable> {

    <X> X persist(X t);

    T save(T t);

    T findOne(ID id);

    boolean exists(ID id);

    long count();

    void delete(ID id);

    void delete(T t);

    void delete(java.lang.Iterable<? extends T> iterable);

    void deleteAll();

    Page<T> findAll(Pageable pageable);
    //
    List<T> findAll();

    List<T> findAll(Sort sort);

    List<T> save(Iterable<? extends T> entities);

    void flush();
    T saveAndFlush(T entity);

    /**
     * Return all entity that satisfies the filter
     * @param pageable
     * @param filter
     * @return
     */
    Page<T> findByFilter(Pageable pageable, Map<String, String> filter);
}
