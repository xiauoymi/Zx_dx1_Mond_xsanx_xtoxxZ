package com.monsanto.metricspos.dao;

/**
 * Interface for page information objects
 *
 * @author Carlos Fau
 */
public interface Pageable {
    /**
     * The number of the page to request (0 based)
     * @return
     */
    int getPageNumber();

    /**
     * The number of elements in the page
     * @return
     */
    int getPageSize();

    /**
     * The first element that belongs to the page
     * @return
     */
    int getOffset();

    /**
     * The sort order
     * @return
     */
    Sort getSort();
}
