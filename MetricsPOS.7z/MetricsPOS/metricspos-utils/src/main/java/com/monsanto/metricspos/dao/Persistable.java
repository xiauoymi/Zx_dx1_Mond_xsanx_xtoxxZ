package com.monsanto.metricspos.dao;

import java.io.Serializable;

/**
 * Mark an instance as a persistable entity.
 * <br/>
 * This is an interface to simplify the generic DAO.
 * <br/>
 * Note: upgrade to JPA 2
 */
public interface Persistable<ID extends Serializable> extends Serializable {

    /**
     * @return The id of this entity.
     */
	ID getId();

    /**
     * Tells if this entity is already persisted or if it a new (fresh) entity.
     *
     * @return true if it is new, false if already persisted
     */
	boolean isNew();
}
