package com.monsanto.metricspos.dao.support;

import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Pageable;
import com.monsanto.metricspos.dao.Sort;
import org.springframework.util.Assert;

import javax.annotation.Nullable;
import java.util.Iterator;
import java.util.List;

/**
 * A simple implementation of the Page interface
 *
 * @author CAFAU
 */
public class SimplePage<T> implements Page<T> {

    private final Pageable pageable;
    private final List<T> elements;
    private final long totalElements;

    public SimplePage(List<T> elements) {
        this(null, elements, elements == null ? 0 : elements.size() );
    }

    public SimplePage(@Nullable Pageable pageable, List<T> elements, long totalElements) {
        Assert.notNull( elements, "Elements should be provided");
        this.pageable = pageable;
        this.elements = elements;
        this.totalElements = totalElements;
    }

    @Override
    public int getNumber() {
        return pageable == null ? 0 : pageable.getPageNumber();
    }

    @Override
    public int getSize() {
        return pageable == null ? 0 : pageable.getPageSize();
    }

    @Override
    public int getTotalPages() {
        return getSize() == 0 || totalElements == 0 ? 0 : (int) ((totalElements - 1) / pageable.getPageSize() + 1);
    }

    @Override
    public int getNumberOfElements() {
        return elements.size();
    }

    @Override
    public long getTotalElements() {
        return totalElements;
    }

    @Override
    public boolean hasPreviousPage() {
        return getNumber() > 0;
    }

    @Override
    public boolean isFirstPage() {
        return getNumber() == 0;
    }

    @Override
    public boolean hasNextPage() {
        return getNumber() + 1 < getTotalPages();
    }

    @Override
    public boolean isLastPage() {
        return totalElements <= (getNumber() + 1L) * getSize();
    }

    @SuppressWarnings({"unchecked"})
    @Override
    public Iterator iterator() {
        return elements.iterator();
    }

    @Override
    public List<T> getContent() {
        return elements;
    }

    @Override
    public boolean hasContent() {
        return ! elements.isEmpty();
    }

    @Override
    public Sort getSort() {
        return pageable.getSort();
    }
}
