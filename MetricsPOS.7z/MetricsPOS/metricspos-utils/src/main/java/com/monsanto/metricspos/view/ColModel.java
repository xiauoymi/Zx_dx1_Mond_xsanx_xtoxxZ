package com.monsanto.metricspos.view;

/**
 * Basic metadata information for a grid data column
 * 
 * @author cfau
 *
 */
public interface ColModel {

	String getPath();

	String getType();
	
	String getLabel();
}
