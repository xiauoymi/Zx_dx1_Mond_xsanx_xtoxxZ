package com.monsanto.metricspos.view;

import com.google.common.base.Predicate;
import com.google.common.collect.Iterables;

import javax.annotation.Nullable;

/**
 * Utility method to manage ColModel collections
 * @author ppera
 */
public final class ColModelUtil {

    private ColModelUtil() {
        // Static class only
    }

    /**
     * Note: This method is not thread safe on metadata.
     *
     *
     * @param metadata
     * @param path
     * @return
     */
    public static <T extends ColModel> int indexOf( Iterable<T> metadata, final String path ) {
        if ( metadata == null || path == null ) {
            return -1;
        }

        return Iterables.indexOf( metadata, new Predicate<T>() {
            @Override
            public boolean apply(@Nullable ColModel o) {
                return path.equals( o.getPath() );
            }
        });
    }
}
