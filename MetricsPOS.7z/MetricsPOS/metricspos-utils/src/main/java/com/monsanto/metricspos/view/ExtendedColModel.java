package com.monsanto.metricspos.view;

/**
 * Extends the basic color model to allow for some decorations
 *
 * @author CAFAU
 */
public interface ExtendedColModel extends ColModel {
    boolean isSearchable();
    boolean isColored();
}
