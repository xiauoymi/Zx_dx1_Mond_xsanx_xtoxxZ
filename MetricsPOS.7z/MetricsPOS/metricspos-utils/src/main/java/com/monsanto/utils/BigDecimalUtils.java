package com.monsanto.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Utils for BigDecimal Objects
 * User: BSBUON
 * Date: 04/02/14
 */
public final class BigDecimalUtils {

    private static BigDecimalUtils instance;

    private BigDecimalUtils() {

    }

    /**
     * singleton
     *
     * @return this instance
     */
    public static BigDecimalUtils getInstance() {
        if (instance == null) {
            instance = new BigDecimalUtils();
        }
        return instance;
    }

    /**
     * get quantity of significant Decimals of BigDecimal object
     *
     * @param value
     * @return int
     */
    private int getSignificantDecimals(BigDecimal value) {
        BigDecimal d = value;
        BigDecimal decimals = d.subtract(d.setScale(0, RoundingMode.FLOOR));
        BigDecimal result = decimals.movePointRight(d.scale());
        if (result.compareTo(BigDecimal.ZERO) == 0) {
            return 0;
        } else {
            String plain = decimals.toPlainString();
            return plain.substring(plain.indexOf('.') + 1).length();
        }
    }

    public BigDecimal getValueWithSignificantDecimals(BigDecimal value) {
        return value.setScale(getSignificantDecimals(value));
    }
}
