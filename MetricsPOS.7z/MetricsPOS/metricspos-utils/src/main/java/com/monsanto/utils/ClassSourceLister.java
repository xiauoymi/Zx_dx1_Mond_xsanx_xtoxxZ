package com.monsanto.utils;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.SmartLifecycle;

import java.net.URL;
import java.util.List;

/**
 * Logs the origin of the classes to assist in class loader debugging issues
 *                                                                            BeanClassLoaderAware
 * @author CAFAU
 */
public class ClassSourceLister implements SmartLifecycle, InitializingBean {

    private static Logger log = Logger.getLogger( ClassSourceLister.class );

    private List<String> classNames;

    private boolean running = false;

    public ClassSourceLister() {
        log.info( "Creating this class ClassSourceLister");
    }

    @Override
    public boolean isAutoStartup() {
        return false;
    }

    @Override
    public void stop(Runnable callback) {
        stop();
        callback.run();
    }

    @Override
    public void start() {
        running = true;
    }

    @Override
    public void stop() {
        running = false;
    }

    @Override
    public boolean isRunning() {
        return running;
    }

    @Override
    public int getPhase() {
        // This bean should be in the first group of beans to run
        return Integer.MIN_VALUE;
    }

    public void setClassNames(List<String> classNames) {
        this.classNames = classNames;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        if ( classNames == null ) {
            log.warn("No classes name list to scan.");
        } else {
            // Informs the origin of all provided classes
            if ( log.isDebugEnabled() ) {
                log.debug("Classes to scan: " + classNames.toString() );
            }
            for (String className : classNames) {
                try {
                    Class<?> clazz = Class.forName( className );
                    String name = clazz.getName().replace( '.', '/' ) + ".class";

                    ClassLoader classLoader = clazz.getClassLoader();

                    if ( classLoader == null ) {
                        log.info( String.format( "Class %s from bootstrap", name) );
                    }   else {
                        URL resource = classLoader.getResource(name);
                        if ( resource == null ) {
                            log.info( String.format( "Cannot find resource for Class %s", name) );
                        } else {
                            String source = resource.toString();
                            log.info( String.format( "Class %s from %s", name, source) );
                        }
                    }

                } catch (ClassNotFoundException e ) {
                    log.error("Cannot find class " + className);
                }
            }
        }
    }
}
