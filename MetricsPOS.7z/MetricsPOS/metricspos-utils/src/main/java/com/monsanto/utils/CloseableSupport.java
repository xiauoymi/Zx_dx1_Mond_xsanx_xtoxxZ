package com.monsanto.utils;

import java.io.Closeable;
import java.sql.Connection;

/**
 * Comment the class purpose
 *
 * @author CAFAU
 */
public final class CloseableSupport {

    /**
     * Static class
     */
    private CloseableSupport() {
    }

    public static void closeSilently(Closeable c) {
        if (c != null) {
            try {
                c.close();
            } catch (Exception e) {
            }
        }
    }

    public static void closeSilently(Connection c) {
        if (c != null) {
            try {
                c.close();
            } catch (Exception e) {
            }
        }
    }
}
