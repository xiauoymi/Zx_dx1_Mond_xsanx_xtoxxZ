package com.monsanto.utils;

import java.util.Calendar;
import java.util.Date;

/**
 * Comment the class purpose
 *
 * @author CAFAU
 */
public final class DateUtils {
    private DateUtils() {
    }

    /**
     * Clears the time part from date
     * @param date
     * @return
     */
    public static Date clearTimePart(Date date) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
/*
        c.clear(Calendar.HOUR_OF_DAY);
        c.clear(Calendar.MINUTE);
        c.clear(Calendar.SECOND);
        c.clear(Calendar.MILLISECOND);

        return c.getTime();
*/
        return newDate(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    /**
     * Costruct a Date with the given date part without time part
     * @param year  the number of the year (4 digits)
     * @param month the month number (january = 1)
     * @param day  the day of the month (1-31)
     * @return a Date
     */
    public static Date newDate(int year, int month, int day) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month - 1, day);

        return c.getTime();
    }
}
