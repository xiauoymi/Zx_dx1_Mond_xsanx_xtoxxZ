package com.monsanto.utils;

import org.apache.poi.ss.usermodel.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.*;


/**
 * User: LOSICL
 */
public class ExcelReader {

    private Workbook wb;
    private int titleRowIndex = 0;

    public ExcelReader(InputStream is) throws Exception {
        this.wb = WorkbookFactory.create(is);
    }

    public ExcelReader(byte[] data) throws Exception {
        this(new ByteArrayInputStream(data));
    }

    public List<String> getTitles() {
        return getTitles(0, 0);
    }

    public List<String> getTitles(int sheetNumber, int titleRowIndex) {
        Sheet sheet1 = wb.getSheetAt(sheetNumber);
        this.titleRowIndex = titleRowIndex;
        Row header = sheet1.getRow(this.titleRowIndex);
        List<String> headers = new LinkedList<String>();
        for (Cell cell : header) {
            headers.add(cell.getRichStringCellValue().getString());
        }
        return headers;
    }

    public List<Map<String, Object>> getDataMap(int sheetNumber) {
        Sheet sheet1 = wb.getSheetAt(sheetNumber);
        int startRow = this.titleRowIndex + 1;
        List<Map<String, Object>> data = new ArrayList<Map<String, Object>>();
        int lastRow = sheet1.getLastRowNum();
        List<String> headers = this.getTitles(sheetNumber, this.titleRowIndex);
        for (int i = startRow; i <= lastRow; i++) {
            Row row = sheet1.getRow(i);
            data.add(createMap(headers, row));
        }
        return data;
    }

    private Map<String, Object> createMap(List<String> headers, Row row) {
        Map<String, Object> aRow = new HashMap<String, Object>();

        for (int i = 0; i < headers.size(); i++) {
            String colName = headers.get(i);
            Cell cell = row.getCell(i);
            Object value = null;
            if (cell != null) {
                switch (cell.getCellType()) {
                    case Cell.CELL_TYPE_STRING:
                        value = cell.getRichStringCellValue().getString();
                        break;
                    case Cell.CELL_TYPE_NUMERIC:
                        if (DateUtil.isCellDateFormatted(cell)) {
                            value = cell.getDateCellValue();
                        } else {
                            value = cell.getNumericCellValue();
                        }
                        break;
                    case Cell.CELL_TYPE_BOOLEAN:
                        value = cell.getBooleanCellValue();
                        break;
                    case Cell.CELL_TYPE_FORMULA:
                        try {
                            value = cell.getNumericCellValue();
                        }
                        catch(Exception e){
                            value = cell.getRichStringCellValue().getString();
                        }
                        break;
                    default:
                        break;
                }
            }
            aRow.put(colName, value);
        }
        return aRow;
    }
}
