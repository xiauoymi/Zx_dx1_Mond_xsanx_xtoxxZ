package com.monsanto.utils;

/**
 * Utils for Xls builders.
 * User: BSBUON
 */
public final class ExcelUtils {

    public static final int ASCII_A = 65;
    public static final int ASCII_Z = 90;

    private static ExcelUtils instance;

    private ExcelUtils(){

    }

    /**
     * singleton
     * @return
     */
    public static ExcelUtils getInstance(){
        if(instance==null){
            instance = new ExcelUtils();
        }
        return instance;
    }


    public String calculateRangeColumns(int init, int columns, int row){
        int initColumn = ASCII_A + init;
        RangeChar first = new RangeChar(initColumn);
        RangeChar last = new RangeChar(initColumn + columns);


        return first.getPrefix() + first.getChar() + row + ":" + last.getPrefix() + last.getChar() + row;
    }

    /**
     * Contains Range of char index.
     */
    private final class RangeChar {

        private int column = 0;
        private int range = 0;
        private String prefix = "";

        private RangeChar(int column) {
            this.column = this.calculateChar(column);
        }

        private int calculateChar(int input){
            if(input <= ASCII_Z){
                return input;
            }else{
                range++;
                return calculateChar(input-ASCII_Z);
            }
        }

        public int getColumn() {
            return column;
        }

        public int getRange() {
            return range;
        }

        public String getChar(){
            int index = column;
            if(range > 0){
                index = ASCII_A - 1 + index;
            }
            return Character.toString((char) index);
        }

        public String getPrefix(){
            if(range > 0){
                prefix = Character.toString ((char) ((char) ASCII_A - 1 + range));
            }
            return prefix;
        }
    }
}
