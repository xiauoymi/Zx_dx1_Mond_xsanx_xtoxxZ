package com.monsanto.utils;

import org.springframework.util.StringUtils;

/**
 * Validation (assertion) utility class that assists in validating arguments.
 * Useful for identifying programmer errors early and clearly at runtime.
 * Based on org.springframework.util.Assert class but with more message formatting options
 *
 * @author CAFAU
 */
public final class Validate {

    private Validate(){
    }

    /**
     * Assert that an object is not <code>null</code> .
     * <pre class="code">Assert.notNull(clazz, "The class must not be null");</pre>
     * @param object the object to check
     * @param message the exception message to use if the assertion fails
     * @param args  Arguments to fill message placeholders.
     *
     * @throws IllegalArgumentException if the object is <code>null</code>
     */
    public static void notNull(Object object, String message, Object ... args) {
        if (object == null) {
            throw new IllegalArgumentException(format(message, args));
        }
    }

    /**
     * Assert that the given String has valid text content; that is, it must not
     * be <code>null</code> and must contain at least one non-whitespace character.
     * <pre class="code">Assert.hasText(name, "'name' must not be empty");</pre>
     * @param text the String to check
     * @param message the exception message to use if the assertion fails
     * @see org.springframework.util.StringUtils#hasText
     */
    public static void hasText(String text, String message, Object ... args) {
        if (!StringUtils.hasText(text)) {
            throw new IllegalArgumentException(format(message, args));
        }
    }

    private static String format(String message, Object... args) {
        return String.format( message, args);
    }
}
