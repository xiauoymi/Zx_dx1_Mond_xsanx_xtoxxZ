package com.monsanto.metricspos.dao;

import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

/**
 *
 * @author PPERA
 */
public class Sort_UT {

    private Sort sort;
    private String property = "aProperty";

    @Before
    public void setUp(){
        property = "aProperty";
        sort = new Sort(Sort.Direction.DESC, property);
    }

    @Test
    public void testGetOrderFor_orderFind(){
        Sort.Order order = sort.getOrderFor(property);
        assertEquals(order.getDirection(), Sort.Direction.DESC);

    }

    @Test
    public void testGetOrderFor_invalidProperty(){
        Sort.Order order = sort.getOrderFor("notAProperty");
        assertNull(order);
    }

    @Test
    public void testNewSort_VarargsOrder(){
        Sort.Order o = new Sort.Order(Sort.Direction.DESC, property);
        Sort.Order o2 = new Sort.Order(Sort.Direction.DESC, property);
        Sort.Order o3 = new Sort.Order(Sort.Direction.DESC, property);
        Sort s = new Sort(o, o2, o3);
        Sort ss = new Sort(o, o2, o3);
        assertNotNull(ss);
        assertNotNull(s);
        assertNotNull(s.toString());
        assertNotNull(s.hashCode());
        assertTrue(o.equals(o));
        assertTrue(s.equals(ss));
        assertFalse(o.equals(s));
        assertFalse(s.equals(o));
    }

    @Test
    public void testNewSort_VarargsProperties(){
        Sort s = new Sort(property, "test", "test2");
        assertNotNull(s);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNewSort_nullValue(){
        List p = null;
        Sort s = new Sort(Sort.Direction.DESC, p);
        assertNull(s);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testDirection_nullValue(){
        Sort.Direction d = Sort.Direction.fromString(null);
        assertNull(d);
    }

    @Test
    public void testDirection_StringValue(){
        Sort.Direction d = Sort.Direction.fromString("DESC");
        assertNotNull(d);
    }


}
