package com.monsanto.metricspos.dao.support;

import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Pageable;
import com.monsanto.metricspos.dao.Sort;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import static org.junit.Assert.*;

/**
 * Comment the class purpose
 *
 * @author CAFAU
 */
public class SimplePage_UT {

    private Page<String> instance;
    private List<String> elements;
    private Pageable pageable;
    private Sort    sort;

    private void makePage( int page, Integer size, int totalElementCount, long totalElements ) {
        if ( totalElementCount < 0 )
            elements = null;
        else {
            elements = new ArrayList<String>(totalElementCount);

            for ( int i = 1; i <= totalElementCount; i++ )
                elements.add( "Element " + i );
        }

        if ( size == null )
            instance = new SimplePage<String>( elements );
        else {
            sort = new Sort( Sort.Direction.ASC, "fieldName");
            pageable = new PageRequest(page, size, sort);

            instance = new SimplePage<String>( pageable, elements, totalElements);
        }
    }


    @Test(expected = IllegalArgumentException.class)
    public void testNullElementList() throws Exception {
        elements = null;
        instance = new SimplePage<String>(elements);
    }


    @Test(expected = IllegalArgumentException.class)
    public void testNullListWithPageable() throws Exception {
        elements = null;
        instance = new SimplePage<String>(pageable, elements, 123456L);
    }

    @Test
    public void testGetNumber() throws Exception {
        // No pageable, no elements
        makePage( 0, null, 0, 0);
        assertEquals( 0, instance.getNumber());

        // No pageable, elements
        makePage( 0, null, 18, 0);
        assertEquals( 0, instance.getNumber());

        // Pageable, no elements
        makePage( 12, 10, 0, 0);
        assertEquals( 12, instance.getNumber());

        // Pageable, elements
        makePage( 17, 10, 45, 0);
        assertEquals(17, instance.getNumber());
    }

    @Test
    public void testGetSize() throws Exception {
        // No pageable, no elements
        makePage( 0, null, 0, 0);
        assertEquals( 0, instance.getSize());

        // No pageable, elements
        makePage( 0, null, 18, 0);
        assertEquals( 0, instance.getSize());

        // Pageable, no elements
        makePage( 12, 10, 0, 0);
        assertEquals( 10, instance.getSize());

        // Pageable, elements
        makePage( 79, 37, 45, 0);
        assertEquals( 37, instance.getSize());
    }

    @Test
    public void testGetTotalPages() throws Exception {
        // No pageable, no elements
        makePage( 0, null, 0, 0);
        assertEquals( 0, instance.getNumber());

        // No pageable, elements
        makePage( 0, null, 18, 0);
        assertEquals( 0, instance.getNumber());

        // Pageable, no elements
        makePage( 12, 10, 0, 0);
        assertEquals( 0, instance.getTotalPages());

        // Pageable, one elements
        makePage( 79, 37, 1, 1);
        assertEquals( 1, instance.getTotalPages());

        // Pageable, almost one page elements
        makePage( 79, 43, 2, 42);
        assertEquals( 1, instance.getTotalPages());

        // Pageable, one page elements
        makePage( 79, 14, 4, 14);
        assertEquals( 1, instance.getTotalPages());

        // Pageable, a litle more than one page elements
        makePage( 79, 7, 7, 8);
        assertEquals( 2, instance.getTotalPages());

        // Pageable, Several pages
        makePage( 79, 7, 7, 50);
        assertEquals( 8, instance.getTotalPages());
    }


    @Test
    public void testGetNumberOfElements() throws Exception {
        // No pageable, no elements
        makePage( 0, null, 0, 0);
        assertEquals( 0, instance.getNumberOfElements());

        // No pageable, no elements
        makePage( 0, null, 18, 0);
        assertEquals( 18, instance.getNumberOfElements());

        // Pageable, no elements
        makePage( 12, 10, 0, 0);
        assertEquals( 0, instance.getNumberOfElements());

        // Pageable, elements
        makePage( 12, 10, 45, 0);
        assertEquals( 45, instance.getNumberOfElements());
    }

    @Test
    public void testGetTotalElements() throws Exception {
        // No pageable, no elements
        makePage( 0, null, 0, 0);
        assertEquals( 0, instance.getTotalElements());

        // No pageable, no elements
        makePage( 0, null, 18, 0);
        assertEquals( 18, instance.getTotalElements());

        // Pageable, no elements
        makePage( 12, 10, 0, 456);
        assertEquals( 456, instance.getTotalElements());

        // Pageable, elements
        makePage( 12, 10, 10, 245);
        assertEquals( 245, instance.getTotalElements());
    }

    @Test
    public void testHasPreviousPage() throws Exception {
        // Pageable, no elements
        makePage( 0, 10, 0, 0);
        assertFalse(instance.hasPreviousPage());

        // Pageable, one elements
        makePage( 0, 37, 1, 1);
        assertFalse(instance.hasPreviousPage());

        // Pageable, almost one page elements
        makePage( 0, 43, 2, 42);
        assertFalse(instance.hasPreviousPage());

        // Pageable, one page elements
        makePage( 0, 14, 4, 14);
        assertFalse(instance.hasPreviousPage());

        // Pageable, a litle more than one page elements
        makePage( 0, 7, 7, 8);
        assertFalse(instance.hasPreviousPage());

        // Pageable, a litle more than one page elements
        makePage( 1, 7, 7, 8);
        assertTrue(instance.hasPreviousPage());

        // Pageable, Several pages
        makePage( 0, 7, 7, 50);
        assertFalse(instance.hasPreviousPage());

        // Pageable, Several pages
        makePage( 1, 7, 7, 50);
        assertTrue(instance.hasPreviousPage());
    }

    @Test
    public void testIsFirstPage() throws Exception {
        // Pageable, no elements
        makePage( 0, 10, 0, 0);
        assertTrue(instance.isFirstPage());

        // Pageable, one elements
        makePage( 0, 37, 1, 1);
        assertTrue(instance.isFirstPage());

        // Pageable, other page
        makePage( 14, 10, 0, 425);
        assertFalse(instance.isFirstPage());
    }

    @Test
    public void testHasNextPage() throws Exception {
        // Pageable, no elements
        makePage( 0, 10, 0, 0);
        assertFalse(instance.hasNextPage());

        // Pageable, one elements
        makePage( 0, 37, 1, 1);
        assertFalse(instance.hasNextPage());

        // Pageable, almost one page elements
        makePage( 0, 43, 2, 42);
        assertFalse(instance.hasNextPage());

        // Pageable, one page elements
        makePage( 0, 14, 4, 14);
        assertFalse(instance.hasNextPage());

        // Pageable, a litle more than one page elements
        makePage( 0, 7, 7, 8);
        assertTrue(instance.hasNextPage());

        // Pageable, a litle more than one page elements
        makePage( 1, 7, 7, 8);
        assertFalse(instance.hasNextPage());

        // Pageable, Several pages
        makePage( 0, 7, 7, 50);
        assertTrue(instance.hasNextPage());

        // Pageable, Several pages
        makePage( 6, 7, 7, 50);
        assertTrue(instance.hasNextPage());

        // Pageable, Several pages
        makePage( 7, 7, 7, 50);
        assertFalse(instance.hasNextPage());
    }

    @Test
    public void testIsLastPage() throws Exception {
        // Pageable, Several pages
        makePage( 6, 7, 7, 50);
        assertEquals( 8, instance.getTotalPages() );
        assertFalse(instance.isLastPage());

        // Pageable, Several pages
        makePage( 7, 7, 7, 50);
        assertTrue(instance.isLastPage());
    }

    @Test
    public void testIterator() throws Exception {
        makePage( 8, 7, 7, 50);

        Iterator<String> iterator = instance.iterator();

        List<String> copy = new ArrayList<String>();

        while ( iterator.hasNext() )
            copy.add(iterator.next());

        assertEquals( elements, copy );
    }

    @Test
    public void testGetContent() throws Exception {
        makePage( 5, 7, 14, 50);

        assertEquals( elements,  instance.getContent() );
    }

    @Test
    public void testHasContent() throws Exception {
        makePage( 3, 12, 12, 50);

        assertTrue( instance.hasContent() );

        // Empty
        makePage( 3, 12, 0, 50);

        assertFalse( instance.hasContent() );
    }

    @Test
    public void testGetSort() throws Exception {
        makePage( 3, 12, 12, 50);
        assertEquals( sort, instance.getSort() );
    }
}
