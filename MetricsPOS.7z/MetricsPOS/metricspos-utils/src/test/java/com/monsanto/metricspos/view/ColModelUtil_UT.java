package com.monsanto.metricspos.view;

import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * @author PPERA
 */
public class ColModelUtil_UT {
    private List<ColModel> colModels;


    private static ColModel col1;

    @Before
    public void setUp() throws Exception {

        col1 = mock(ColModel.class);
        ColModel col2 = mock(ColModel.class);
        ColModel col3 = mock(ColModel.class);

        when( col1.getPath() ).thenReturn( "one" );
        when( col2.getPath() ).thenReturn( "two" );
        when( col3.getPath() ).thenReturn( "three" );

        colModels = Arrays.asList( col1, col2, col3);

    }

    @Test
    public void testIndexOf_FindOneElement() throws Exception {
        assertEquals( 0, ColModelUtil.indexOf( Arrays.asList( col1 ), "one"));
    }

    @Test
    public void testIndexOf_FindManyElements() throws Exception {
        assertEquals( 0, ColModelUtil.indexOf( colModels, "one"));
        assertEquals( 2, ColModelUtil.indexOf( colModels, "three"));
        assertEquals( 1, ColModelUtil.indexOf( colModels, "two"));
    }

    @Test
    public void testIndexOf_NotFound() throws Exception {
        assertEquals( -1, ColModelUtil.indexOf( colModels, "five"));
    }

    @Test
    public void testIndexOf_EmptyList() throws Exception {

        assertEquals( -1, ColModelUtil.indexOf( null, "Something"));
        assertEquals( -1, ColModelUtil.indexOf(Collections.<ColModel>emptyList(), "Something"));
    }

    @Test
    public void testIndexOf_EmptyPath() throws Exception {
        assertEquals( -1, ColModelUtil.indexOf( colModels, null));
    }
}
