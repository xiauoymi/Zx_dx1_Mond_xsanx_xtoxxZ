package com.monsanto.utils;

import org.junit.Test;

import java.math.BigDecimal;
import static org.junit.Assert.assertEquals;

/**
 * Test for BigDecimal Utils Class
 * User: BSBUON
 * Date: 04/02/14
 */
public class BigDecimalUtils_UT {

    @Test
    public void testSignificantDecimals(){

        BigDecimal b1 = new BigDecimal(0.01012);

        BigDecimal got = BigDecimalUtils.getInstance().getValueWithSignificantDecimals(b1);
        BigDecimal expected = new BigDecimal(0.01012);

        assertEquals(got, expected);

        BigDecimal b2 = new BigDecimal(1.00000);

        BigDecimal got2 = BigDecimalUtils.getInstance().getValueWithSignificantDecimals(b2);
        BigDecimal expected2 = new BigDecimal(1);

        assertEquals(got2, expected2);

        BigDecimal b3 = new BigDecimal(1.001000);

        BigDecimal got3 = BigDecimalUtils.getInstance().getValueWithSignificantDecimals(b3);
        BigDecimal expected3 = new BigDecimal(1.001);

        assertEquals(got3, expected3);
    }
}
