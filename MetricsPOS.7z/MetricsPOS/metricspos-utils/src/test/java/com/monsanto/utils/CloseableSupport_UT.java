package com.monsanto.utils;

import org.junit.Test;
import static org.mockito.Mockito.*;
import java.io.Closeable;
import java.sql.Connection;

/**
 * @author SHELG
 */
public class CloseableSupport_UT {

    @Test
    public void testCloseableCloseable() {
        CloseableSupport.closeSilently(mock(Closeable.class));
    }

    @Test
    public void testCloseableConnection() {
        CloseableSupport.closeSilently(mock(Connection.class));
    }

}
