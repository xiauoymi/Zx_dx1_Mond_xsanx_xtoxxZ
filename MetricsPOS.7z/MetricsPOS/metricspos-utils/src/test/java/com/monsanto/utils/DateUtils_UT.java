package com.monsanto.utils;

import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

import static org.junit.Assert.assertEquals;

/**
 * Comment the class purpose
 *
 * @author CAFAU
 */
public class DateUtils_UT {
    @Test
    public void testClearTimePart() throws Exception {
        Calendar c1 = Calendar.getInstance();

        c1.set(1991, 10, 12, 20, 24,56 );
        c1.set(Calendar.MILLISECOND, 125);

        Calendar c2 = Calendar.getInstance();
        c2.set(1991, 10, 12, 0, 0,0 );
        c2.set(Calendar.MILLISECOND, 0);

        assertEquals(c2.getTime(), DateUtils.clearTimePart(c1.getTime()));
    }

    @Test
    public void testNewDate() throws Exception {
        Date date = DateUtils.newDate(1963, 11, 29);
        Calendar c = Calendar.getInstance();
        c.clear();
        c.setTime(date);

        assertEquals( 1963, c.get(Calendar.YEAR) );
        assertEquals( 11, c.get(Calendar.MONTH) + 1 );
        assertEquals( 29, c.get(Calendar.DAY_OF_MONTH) );
        assertEquals( 0, c.get(Calendar.HOUR_OF_DAY) );
        assertEquals( 0, c.get(Calendar.MINUTE) );
        assertEquals( 0, c.get(Calendar.SECOND) );
        assertEquals( 0, c.get(Calendar.MILLISECOND) );
    }
}
