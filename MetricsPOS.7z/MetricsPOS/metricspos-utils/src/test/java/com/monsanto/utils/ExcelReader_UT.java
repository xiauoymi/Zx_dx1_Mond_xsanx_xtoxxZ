package com.monsanto.utils;

import org.junit.Before;
import org.junit.Test;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import static junit.framework.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: LOSICL
 * Date: 11/14/12
 * Time: 12:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class ExcelReader_UT {

    private static final String EXCEL_FILE_NAME = "/test.xlsx";

    private ExcelReader reader = null;

    @Before
    public void init(){
        try{
            reader = new ExcelReader(readFile());
        }
        catch (Exception e){

        }
    }

    @Test
    public void testDataByteNotValid_throwsException() throws Exception {
        byte[] dummy = new byte[1];
        ExcelReader reader = null;
        try{
            reader = new ExcelReader(dummy);
            fail();
        }
        catch (Exception e){
            assertNull(reader);
        }
    }

    @Test
    public void testInputStreamNotValid_throwsException() throws Exception {
        InputStream is = new ByteArrayInputStream(new byte[1]);
        ExcelReader reader = null;
        try{
            reader = new ExcelReader(is);
            fail();
        }
        catch (Exception e){
            assertNull(reader);
        }
    }

    @Test
    public void readTitleRow_success() throws Exception {
        List<String> header;
        try{
            reader = new ExcelReader(readFile());
            header = reader.getTitles();
            assertNotNull(header);
            assertEquals(header.size(), 4);
        }
        catch (Exception e){
            fail();
        }
    }

    @Test
    public void getData_success() throws Exception {
        List<Map<String, Object>> data;
        try{
            data = reader.getDataMap(0);
            assertNotNull(data);
            assertEquals(data.size(), 2);
        }
        catch (Exception e){
            fail();
        }
    }


    private InputStream readFile(){
        InputStream is = null;
        try{
            is = getClass().getResourceAsStream(EXCEL_FILE_NAME);
            assertNotNull("File cannot be null", is);
        }
        catch (Exception e){
            fail(e.getMessage());
        }

        return is;
    }

}
