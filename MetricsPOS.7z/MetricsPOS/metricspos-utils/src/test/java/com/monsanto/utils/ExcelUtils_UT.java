package com.monsanto.utils;

import junit.framework.Assert;
import org.junit.Test;

/**
 * Test for  range column Excel creation.
 * User: BSBUON
 * Date: 13/02/14
 */

public class ExcelUtils_UT {

    @Test
    public void testCreateColumns(){
        String range = ExcelUtils.getInstance().calculateRangeColumns(0,2,2);
        String expected = "A2:C2";
        Assert.assertEquals(expected,range);
    }

    @Test
    public void testCreateColumns2(){
        String range = ExcelUtils.getInstance().calculateRangeColumns(26,5,5);
        String expected = "AA5:AF5";
        Assert.assertEquals(expected,range);
    }

    @Test
    public void testCreateColumns3(){
        String range = ExcelUtils.getInstance().calculateRangeColumns(24,5,4);
        String expected = "Y4:AD4";
        Assert.assertEquals(expected,range);
    }
}
