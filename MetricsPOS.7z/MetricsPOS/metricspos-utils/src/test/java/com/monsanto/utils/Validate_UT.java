package com.monsanto.utils;

import org.junit.Test;

/**
 * @author PPERA
 */
public class Validate_UT {

    @Test
    public void notNull_notNull() {
        Object object = new Object();
        Validate.notNull(object, "The object can't be null");
    }

    @Test(expected = java.lang.IllegalArgumentException.class)
    public void notNull_null() {
        Object object = null;
        Validate.notNull(object, "The object can't be null");
    }

    @Test
    public void hasText_hasText() {
        Validate.hasText("text", "There must be a text");
    }

    @Test(expected = java.lang.IllegalArgumentException.class)
    public void hasText_noText() {
        Validate.hasText("", "The object must have text");
    }
}
