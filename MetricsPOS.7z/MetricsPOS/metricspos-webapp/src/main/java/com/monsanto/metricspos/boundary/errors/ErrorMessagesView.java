package com.monsanto.metricspos.boundary.errors;

import com.google.common.collect.Lists;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.View;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * User: PPERA
 */
public class ErrorMessagesView implements View {
    private static final String DEFAULT_JSON_CONTENT_TYPE = "application/json";
    private static final String DEFAULT_JAVASCRIPT_TYPE = "text/javascript";

    @Autowired
    private ObjectMapper objectMapper;

    public ObjectMapper getObjectMapper() {
        return objectMapper;
    }

    public void setObjectMapper(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public String getContentType() {
        return DEFAULT_JSON_CONTENT_TYPE;
    }

    public void render(Map model, HttpServletRequest request,
                       HttpServletResponse response) throws Exception {

        String callback = request.getParameter("callback");
        boolean scriptTag = callback != null;

        if (scriptTag) {
            response.setContentType(DEFAULT_JAVASCRIPT_TYPE);
        } else {
            response.setContentType(DEFAULT_JSON_CONTENT_TYPE);
        }

        boolean omitSpringElements = true;
        if (omitSpringElements) {
            removeSpringElements(model);
        }

        Integer status = (Integer) model.get("status");
        Exception exception = (Exception) model.get("exception");

        PrintWriter out = response.getWriter();

        if (scriptTag) {
            out.write(callback + "(");
        }

        response.setStatus(status);

        List<ErrorMessage> errorMessageList = this.makeErrorMessageList(exception);

        out.write(objectMapper.writeValueAsString(errorMessageList));

        if (scriptTag) {
            out.write(");");
        }
    }

    private List<ErrorMessage> makeErrorMessageList(Exception exception) {
        ErrorMessage errorMessage = new ErrorMessage();
        errorMessage.setMessage(exception.getMessage());
        return Lists.newArrayList(errorMessage);
    }

    /**
     * Remove model elements added by internal spring validation system
     *
     * @param model
     */
    private void removeSpringElements(Map model) {
        for (Iterator i = model.keySet().iterator(); i.hasNext(); ) {
            Object oKey = i.next();

            if (oKey.toString().startsWith("org.springframework.")) {
                i.remove();
            }
        }
    }
}
