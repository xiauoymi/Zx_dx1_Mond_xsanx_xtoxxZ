package com.monsanto.metricspos.boundary.errors;

import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.AbstractHandlerExceptionResolver;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * User: PPERA
 */
public class MetricPosHandlerExceptionResolver extends AbstractHandlerExceptionResolver {
    private static final Logger LOG = Logger.getLogger(MetricPosHandlerExceptionResolver.class);

    @Autowired
    @Qualifier("auditLog")
    private Logger auditLog;

    @Override
    protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        if (LOG.isDebugEnabled()) {
            LOG.debug("Non-cached error", ex);
        }

        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("errorMessages");
        ModelMap modelMap = modelAndView.getModelMap();
        modelMap.addAttribute("exception", ex);
        if (ex instanceof BusinessException) {
            modelMap.addAttribute("errorMessage", ((BusinessException) ex).getErrorMessage());
        } else {
            modelMap.addAttribute("errorMessage", ex.getMessage());
        }

        auditLog.debug("An error ocurred: [" + ex.getMessage()+ "]");
        modelMap.addAttribute("status", status(ex));

        return modelAndView;
    }

    private int status(Exception ex) {
        if (ex instanceof BusinessException) {
            return ((BusinessException) ex).getErrorCode();
        }
        return 500;
    }
}
