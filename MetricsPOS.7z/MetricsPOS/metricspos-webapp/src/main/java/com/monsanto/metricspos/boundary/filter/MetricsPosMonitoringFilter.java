package com.monsanto.metricspos.boundary.filter;

import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.UserWrapper;
import net.bull.javamelody.MonitoringFilter;
import org.springframework.security.context.SecurityContextHolder;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

/**
 * Created by SHELG on 10/14/2014.
 */
public class MetricsPosMonitoringFilter extends MonitoringFilter {


    /**
     *
     * @return
     */
    private boolean loggedUserCanToggleMonitoring() {

        boolean isAdminUser = false;

        if (SecurityContextHolder.getContext().getAuthentication() != null) {
            UserWrapper user = (UserWrapper)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if (user.getUser() instanceof AdminUser) {
                isAdminUser = true;
            }
        }
        return isAdminUser;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {

        if (loggedUserCanToggleMonitoring()) {
            super.doFilter(request, response, chain);
        } else {
            chain.doFilter(request, response);
        }
    }
}