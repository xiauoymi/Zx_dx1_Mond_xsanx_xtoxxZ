package com.monsanto.metricspos.boundary.security;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import org.springframework.aop.framework.ReflectiveMethodInvocation;
import org.springframework.security.*;
import org.springframework.security.vote.AbstractAccessDecisionManager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * User: PPERA
 */
public class CustomAccessDecisionManager extends AbstractAccessDecisionManager {

    private AccessDecisionManager accessDecisionManagerDelegate;

    @Override
    public void decide(Authentication authentication, Object object, ConfigAttributeDefinition config) throws AccessDeniedException, InsufficientAuthenticationException {
        ConfigAttributeDefinition configAttributeDefinition = new ConfigAttributeDefinition(transformAttributes(config, object));
        accessDecisionManagerDelegate.decide(authentication, object, configAttributeDefinition);
    }

    private List transformAttributes(ConfigAttributeDefinition config, final Object object) {
        Collection configAttributes = config.getConfigAttributes();

        Collection transformedCollection = Collections2.transform(configAttributes, new Function<Object, Object>() {
            @Override
            public Object apply(Object input) {
                if (input instanceof SecurityConfig) {
                    String attribute = ((SecurityConfig) input).getAttribute();
                    Object[] arguments = ((ReflectiveMethodInvocation) object).getArguments();
                    return new SecurityConfig(replaceArgumentsPlaceHolders(attribute, arguments));
                }
                return input;
            }
        });

        return new ArrayList(transformedCollection);
    }

    private String replaceArgumentsPlaceHolders(String attribute, Object[] arguments) {
        String back = attribute;
        for (int i = 0; i < arguments.length; i++) {
            back = back.replace("(" + i + ")", arguments[i].toString());
        }

        return back;
    }

    public void setAccessDecisionManagerDelegate(AccessDecisionManager accessDecisionManagerDelegate) {
        this.accessDecisionManagerDelegate = accessDecisionManagerDelegate;
    }
}
