package com.monsanto.metricspos.boundary.security;

import com.monsanto.metricspos.core.security.EnvironmentContext;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.ui.preauth.AbstractPreAuthenticatedProcessingFilter;
import weblogic.security.Security;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.Set;

/**
 * This AbstractPreAuthenticatedProcessingFilter
 * provides the user name in a pre authenticated environment inside WebLogic with WAM security
 * infrastructure.
 *
 * @author Carlos Fau
 */
public class WebLogicAuthenticatedProcessingFilter extends AbstractPreAuthenticatedProcessingFilter {

    private static Logger log = Logger.getLogger(WebLogicAuthenticatedProcessingFilter.class);

    @Autowired
    private EnvironmentContext environmentContext;

    /**
     * The user name used in case we are in an local (win) environment.
     * <br/>
     * This is used ONLY in development to bypass the integrated authentication infrastructure
     */
    private String localUser;

    /**
     * Returns the authenticated user provided by WAM.
     * <br/>
     * If running in local environment, the localUser is returned.
     *
     * @return The authenticated user or null if none.
     */
    public String getLoggedInUser() {
        if (environmentContext.isLocalEnvironment()) {
            log.warn("Using local user. Application should be running in local environment: " + localUser);
            return localUser;
        }

        log.debug("Attempting to get logged in user ID...");

        String userName = "";

        Set<Principal> principals = Security.getCurrentSubject().getPrincipals();

        if (principals != null && !principals.isEmpty()) {
            // Getting first principal as user name
            userName = principals.iterator().next().getName();
            if (userName != null) {
                log.debug("Obtained user ID for logging purposes ..." + userName);
            } else {
                log.warn("UserWrapperImpl name unavailable ...");
            }
        } else {
            log.warn("Principals object was null or empty, using anonymous user");
        }
        return userName;
    }

    @Override
    protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
        return getLoggedInUser();
    }

    /**
     * For J2EE container-based authentication there is no generic way to
     * retrieve the credentials, as such this method returns a fixed dummy
     * value.
     */

    protected Object getPreAuthenticatedCredentials(HttpServletRequest httpRequest) {
        return "N/A";
    }

    public int getOrder() {
        return 0;
    }

    public String getLocalUser() {
        return localUser;
    }

    public void setLocalUser(String localUser) {
        this.localUser = localUser;
    }
}
