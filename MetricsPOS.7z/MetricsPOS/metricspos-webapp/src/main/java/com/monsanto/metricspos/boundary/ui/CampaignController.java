package com.monsanto.metricspos.boundary.ui;

import com.monsanto.metricspos.boundary.ui.utils.ControllerUtils;
import com.monsanto.metricspos.core.DataLoader;
import com.monsanto.metricspos.core.ExportServices;
import com.monsanto.metricspos.core.MetricsApplication;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.application.vo.PointOfSaleVO;
import com.monsanto.metricspos.core.application.vo.ScoreSummaryVO;
import com.monsanto.metricspos.core.application.vo.ServiceCenterVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.CampaignParameter;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.security.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.util.*;

/**
 * TBD
 *
 * @author CAFAU
 */
@Controller
@RequestMapping("/campaigns")
public class CampaignController {

    private static final String DEFAULT_XLS_CONTENT_TYPE = "application/octet-stream";

    @Autowired
    private MetricsApplication application;

    @Autowired
    private DataLoader dataLoader;

    @Autowired
    @Qualifier("auditLog")
    private Logger auditLog;

    @Autowired
    @Qualifier("actionLog")
    private Logger actionLog;

    @Autowired
    private ExportServices exportServices;

    public CampaignController() {
    }

    @RequestMapping(value = "", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_LIST", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public List<CampaignVO> list() {
        List<Campaign> campaigns = this.application.listAllCampaigns();

        auditLog.trace("Listed all campaigns");
        actionLog.trace("Listing all campaigns");
        return CampaignVO.makeCampaignVOs(campaigns);
    }

    @RequestMapping(value = "/{campaignId}", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_VIEW_(0)", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public CampaignVO view(@PathVariable int campaignId, @RequestParam(required = false, defaultValue = "false") boolean withChildren) {
        this.application.changePrivileges(campaignId);
        Campaign campaign = this.application.findCampaignById(campaignId, withChildren);
        auditLog.trace("View campaign [" + campaign + "]");
        actionLog.trace("View campaign [" + campaign + "]");
        return new CampaignVO(campaign, withChildren);
    }

    @RequestMapping(value = "", method = RequestMethod.POST, consumes = {"application/json", "application/x-www-form-urlencoded"}, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public CampaignVO create(@RequestBody CampaignVO campaignVO) {
        if (campaignVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        Campaign campaign = this.application.newCampaign(campaignVO);
        auditLog.info("Created campaign [" + campaign + "]");
        actionLog.info("Created campaign [" + campaign + "]");
        return new CampaignVO(campaign, false);
    }

    @RequestMapping(value = "/{campaignId}", method = RequestMethod.PUT)
    @Secured({"CAMPAIGN_UPDATE_(0)", "SYSTEM_ADMINISTRATOR"})
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void update(@PathVariable int campaignId, @RequestBody CampaignVO campaignVO) {
        if (campaignVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        campaignVO.setId(campaignId);
        Campaign campaign = application.updateCampaign(campaignVO);
        auditLog.info("Updated campaign [" + campaign + "]");
        actionLog.info("Updated campaign [" + campaign + "]");
    }

    @RequestMapping(value = "/{campaignId}/serviceCenters", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_LIST_SERVICE_CENTERS", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public List<ServiceCenterVO> listServiceCenters(@PathVariable int campaignId) {
        auditLog.trace("Listing all service centers of campaign [" + campaignId + "]");
        actionLog.trace("Listing all service centers of campaign [" + campaignId + "]");
        List<ServiceCenter> serviceCenters = this.application.listServiceCenters(campaignId);
        return ServiceCenterVO.makeServiceCenterVOs(serviceCenters);
    }

    @RequestMapping(value = "/{campaignId}/serviceCenters/export", method = RequestMethod.GET, produces = "application/octet-stream")
    @Secured({"CAMPAIGN_(0)_LIST_SERVICE_CENTERS", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public void export(@PathVariable int campaignId, WebRequest webRequest, HttpServletResponse response){
        List<ServiceCenter> serviceCenters = this.application.listServiceCenters(campaignId);
        List<ScoreSummaryCampaignNode> scores = new ArrayList<ScoreSummaryCampaignNode>();
        for(ServiceCenter sc : serviceCenters){
            scores.add(this.application.generateScoreSummary(campaignId, sc.getCuit()));
        }

        response.setContentType(DEFAULT_XLS_CONTENT_TYPE);
        response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s.xls\"", "serviceCenters"));
        response.setHeader("Set-Cookie", "fileDownload=true; path=/");

        try {
            OutputStream os = response.getOutputStream();
            exportServices.export(scores, os);
            auditLog.info("Exported ServiceCenters of Campaign [" + campaignId + "]");
            actionLog.info("Exported ServiceCenters of Campaign [" + campaignId + "]");
        }catch (Exception ex){
            throw new BusinessException(BusinessException.ERROR_IN_PROCESS, 501, ex);
        }
    }

    @RequestMapping(value = "/{campaignId}/serviceCenters/exportRanking", method = RequestMethod.GET, produces = "application/octet-stream")
    @Secured({"SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public void exportRanking(@PathVariable int campaignId, WebRequest webRequest, HttpServletResponse response) {

        List<ServiceCenter> serviceCenters = this.application.listServiceCenters(campaignId, true);

        response.setContentType(DEFAULT_XLS_CONTENT_TYPE);
        response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s.xls\"", "serviceCentersRanking"));
        response.setHeader("Set-Cookie", "fileDownload=true; path=/");
        try {
            OutputStream os = response.getOutputStream();
            exportServices.export(serviceCenters, os, campaignId);

            auditLog.info("Exported ServiceCentersRanking of Campaign [" + campaignId + "]");
            actionLog.info("Exported ServiceCentersRanking of Campaign [" + campaignId + "]");
        }catch (Exception ex){
            throw new BusinessException(BusinessException.ERROR_IN_PROCESS, 501, ex);
        }

    }

    @RequestMapping(value = "/{campaignId}/serviceCenters/grid", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_LIST_SERVICE_CENTERS", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public Page<ServiceCenterVO> listServiceCentersForGrid(@PathVariable int campaignId,
                                                           @RequestParam(value = "page", required = false) Integer page,
                                                           @RequestParam(value = "rows", required = false) Integer rows,
                                                           @RequestParam(value = "sidx", required = false) String sort,
                                                           @RequestParam(value = "sord", required = false) String direction,
                                                           WebRequest webRequest

    ) {
        String sortParam = ((sort != null && !sort.isEmpty()) ? sort : ServiceCenterVO.CUIT_COLUMN);
        auditLog.trace("Listing service centers of campaign [" + campaignId + "]");
        actionLog.trace("Listing service centers of campaign [" + campaignId + "]");
        return this.application.listServiceCentersByPage(campaignId, new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sortParam)), ControllerUtils.extractFilter(webRequest));
    }

    @RequestMapping(value = "/{campaignId}/pointsOfSale/grid", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_LIST_POINTS_OF_SALE", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public Page<PointOfSaleVO> listPointOfSalesForGrid(@PathVariable int campaignId,
                                                       @RequestParam(value = "page", required = false) Integer page,
                                                       @RequestParam(value = "rows", required = false) Integer rows,
                                                       @RequestParam(value = "sidx", required = false) String sort,
                                                       @RequestParam(value = "sord", required = false) String direction,
                                                       WebRequest webRequest

    ) {
        String sortParam = ((sort != null && !sort.isEmpty()) ? sort : PointOfSaleVO.ID_SAP_COLUMN);
        auditLog.trace("Listing points of sale of campaign [" + campaignId + "]");
        actionLog.trace("Listing points of sale of campaign [" + campaignId + "]");
        return this.application.listPointsOfSaleByPage(campaignId, new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sortParam)), ControllerUtils.extractFilter(webRequest));
    }

    @RequestMapping(value = "/{campaignId}/serviceCenters/{cuit}/pointsOfSale", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_SERVICE_CENTER_(1)_LIST_POINTS_OF_SALE", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public List<PointOfSaleVO> listPointsOfSaleForServiceCenter(@PathVariable int campaignId, @PathVariable String cuit) {
        auditLog.trace("Listing all points of sale of service center [" + cuit + "] campaign [" + campaignId + "]");
        actionLog.trace("Listing all points of sale of service center [" + cuit + "] campaign [" + campaignId + "]");
        List<PointOfSale> pointOfSales = this.application.findPointsOfSaleByCampaignIdAndCuit(campaignId, cuit);
        return PointOfSaleVO.makePointOfSaleVOs(pointOfSales);
    }

    @RequestMapping(value = "/{campaignId}/pointsOfSale", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_LIST_POINTS_OF_SALE", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public List<PointOfSaleVO> listPointsOfSaleForCampaign(@PathVariable int campaignId) {
        auditLog.trace("Listing all points of sale of campaign [" + campaignId + "]");
        actionLog.trace("Listing all points of sale of campaign [" + campaignId + "]");
        List<PointOfSale> pointOfSales = this.application.findPointsOfSaleByCampaignId(campaignId);
        return PointOfSaleVO.makePointOfSaleVOs(pointOfSales);
    }

    @RequestMapping(value = "/{campaignId}/serviceCenters/load", method = RequestMethod.POST, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void saveAndExecuteServiceCenterLoad(@PathVariable int campaignId, @RequestBody CampaignVO campaignVO) {
        if (campaignVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        campaignVO.setId(campaignId);
        this.dataLoader.saveAndExecuteServiceCenterLoad(campaignVO);
        auditLog.info("Executed service center load for campaign [" + campaignId + "]");
        actionLog.info("Executed service center load for campaign [" + campaignId + "]");
    }

    @RequestMapping(value = "/{campaignId}/pointsOfSale/load", method = RequestMethod.POST, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void saveAndExecutePointOfSaleLoad(@PathVariable int campaignId, @RequestBody CampaignVO campaignVO) {
        if (campaignVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        campaignVO.setId(campaignId);
        this.dataLoader.saveAndExecutePointOfSaleLoad(campaignVO);
        auditLog.info("Executed point of sale load for campaign [" + campaignId + "]");
        actionLog.info("Executed service point of sale load for campaign [" + campaignId + "]");
    }

    @RequestMapping(value = "/{campaignId}/employees/load", method = RequestMethod.POST, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void saveAndExecuteEmployeeLoad(@PathVariable int campaignId, @RequestBody CampaignVO campaignVO) {
        if (campaignVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        campaignVO.setId(campaignId);
        this.dataLoader.saveAndExecuteEmployeeLoad(campaignVO);
        auditLog.info("Executed employee load for campaign [" + campaignId + "]");
        actionLog.info("Executed employee load for campaign [" + campaignId + "]");
    }

    @RequestMapping(value = "/{campaignId}/serviceCenters/{cuit}", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_VIEW_SERVICE_CENTER_(1)", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public ServiceCenterVO viewServiceCenter(@PathVariable int campaignId, @PathVariable String cuit) {
        auditLog.trace("Viewing service center [" + cuit + "] of campaign [" + campaignId + "]");
        actionLog.trace("Viewing service center [" + cuit + "] of campaign [" + campaignId + "]");
        ServiceCenter serviceCenter = this.application.findServiceCenterByCampaignIdAndCuit(campaignId, cuit);
        return new ServiceCenterVO(serviceCenter, false);
    }

    @RequestMapping(value = "/{campaignId}", method = RequestMethod.DELETE, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void remove(@PathVariable int campaignId) {
        this.application.removeCampaign(campaignId);
        auditLog.info("Deleted campaign [" + campaignId + "]");
        actionLog.info("Deleted campaign [" + campaignId + "]");
    }

    @RequestMapping(value = "/{campaignId}/summary/{cuit}", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_VIEW_SERVICE_CENTER_SUMMARY_(1)", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public ScoreSummaryVO scoreSummary(@PathVariable int campaignId, @PathVariable String cuit) {
        ScoreSummaryCampaignNode scoreSummaryCampaignNode = this.application.generateScoreSummary(campaignId, cuit);
        auditLog.trace("Viewing score summary campaign [" + campaignId + "] cuit [" + cuit + "]");
        actionLog.trace("Viewing score summary campaign [" + campaignId + "] cuit [" + cuit + "]");
        return new ScoreSummaryVO(scoreSummaryCampaignNode);
    }

    @RequestMapping(value = "/{campaignId}/summary/{cuit}/send", method = RequestMethod.GET, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void sendSummary(@PathVariable int campaignId, @PathVariable String cuit) {
        try {
            this.application.sendSummary(campaignId, cuit);
        }catch (Exception ex){
            throw new BusinessException(BusinessException.ERROR_IN_PROCESS, 501, ex);
        }
        auditLog.info("Sent score summary campaign [" + campaignId + "] cuit [" + cuit + "]");
        actionLog.info("Sent score summary campaign [" + campaignId + "] cuit [" + cuit + "]");
    }

    @RequestMapping(value = "/{campaignId}/summary/send", method = RequestMethod.GET, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void sendAllSummaries(@PathVariable int campaignId) {
        this.application.sendAllSummaries(campaignId);
        auditLog.info("Sent all score summaries campaign [" + campaignId + "]");
        actionLog.info("Sent all score summaries campaign [" + campaignId + "]");
    }

    @RequestMapping(value = "/{campaignId}/scores/compute", method = RequestMethod.GET, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void computeAllScores(@PathVariable int campaignId) {
        this.application.executeBatchMetricScoreCompute(campaignId);
        auditLog.info("Compute all scores of campaign [" + campaignId + "]");
        actionLog.info("Compute all scores of campaign [" + campaignId + "]");
    }

    @RequestMapping(value = "/{campaignId}/tables/reload", method = RequestMethod.GET, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void reloadAllTables(@PathVariable int campaignId) {
        this.dataLoader.executeAllTablesLoad(campaignId);
        auditLog.info("Reloading all tables of campaign [" + campaignId + "]");
        actionLog.info("Reloading all tables of campaign [" + campaignId + "]");
    }

    @RequestMapping(value = "/parameters", method = RequestMethod.GET, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public Page<CampaignParameter> viewParametersPage(@RequestParam(value = "page", required = false) Integer page,
                                                      @RequestParam(value = "rows", required = false) Integer rows,
                                                      @RequestParam(value = "sidx", required = false) String sort,
                                                      @RequestParam(value = "sord", required = false) String direction,
                                                      WebRequest webRequest

    ) {
        auditLog.trace("Viewing campaign parameters");
        actionLog.trace("Viewing campaign parameters");

        return this.application.findCampaignParametersByPage(new PageRequest(page, rows, new Sort(Sort.getDirection(direction), ControllerUtils.IfNull(sort, CampaignParameter.ID))), ControllerUtils.extractFilter(webRequest));
    }

    @RequestMapping(value = "/parameters/edit", method = RequestMethod.PUT, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void updateParameter(@RequestBody CampaignParameter parameter) {
        if (parameter == null) {
            throw new BusinessException(BusinessException.ERROR_PARAMETER_CANNOT_BE_NULL, 400);
        }
        if (parameter.getId() == null) {
            throw new BusinessException(BusinessException.ERROR_PARAMETER_ID_CANNOT_BE_NULL, 400);
        }

        this.application.updateCampaignParameter(parameter);
        auditLog.info("Updated parameter [" + parameter + "]");
        actionLog.info("Updated parameter [" + parameter + "]");
    }
}