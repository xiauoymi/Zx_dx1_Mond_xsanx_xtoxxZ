package com.monsanto.metricspos.boundary.ui;

import com.monsanto.metricspos.boundary.ui.utils.ControllerUtils;
import com.monsanto.metricspos.core.ExportServices;
import com.monsanto.metricspos.core.MetricsApplication;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.MetricScoreVO;
import com.monsanto.metricspos.core.application.vo.MetricVO;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.security.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;

import javax.servlet.http.HttpServletResponse;
import java.io.OutputStream;
import java.util.List;

/**
 * @author PPERA
 */
@Controller
@RequestMapping("/campaigns/{campaignId}/metrics")
public class MetricController {

    private static final String DEFAULT_XLS_CONTENT_TYPE = "application/xls";

    @Autowired
    private MetricsApplication application;

    @Autowired
    private ExportServices exportServices;

    @Autowired
    @Qualifier("auditLog")
    private Logger auditLog;

    @Autowired
    @Qualifier("actionLog")
    private Logger actionLog;

    @RequestMapping(value = "/append", method = RequestMethod.POST, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public MetricVO appendMetric(@PathVariable int campaignId, @RequestBody MetricVO metricVO) {
        if (metricVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        Metric metric = this.application.addMetricToCampaign(campaignId, metricVO);
        auditLog.info("Created metric [" + metric + "]");
        actionLog.info("Created metric [" + metric + "]");
        return new MetricVO(metric, true);
    }

    @RequestMapping(value = "", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_LIST_METRICS", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public List<MetricVO> listMetricsForCampaign(@PathVariable int campaignId) {
        List<Metric> metrics = this.application.listSubmetricsForCampaign(campaignId);
        auditLog.trace("listing metrics for campaign [" + campaignId + "]");
        actionLog.trace("listing metrics for campaign [" + campaignId + "]");
        return MetricVO.makeMetricVOs(metrics, false);
    }


    @RequestMapping(value = "/{metricId}", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_VIEW_METRIC_(1)", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public MetricVO view(@PathVariable int campaignId, @PathVariable int metricId, @RequestParam(required = false, defaultValue = "false") boolean withChildren) {
        Metric metric = this.application.findMetricById(metricId);
        auditLog.trace("Viewing metric [" + metric + "]");
        actionLog.trace("Viewing metric [" + metric + "]");
        return new MetricVO(metric, withChildren, true);
    }

    /**
     * Receives the data modifications in the form of a MetricVO and carries them to the model
     *
     * @param metricId The id of the metric to update
     * @param metricVO Te VO with the updated data
     * @return The updated data of the metric
     */
    @RequestMapping(value = "/{metricId}", method = RequestMethod.PUT, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_UPDATE_METRIC_(1)", "SYSTEM_ADMINISTRATOR"})
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void update(@PathVariable int campaignId, @PathVariable int metricId, @RequestBody MetricVO metricVO) {
        if (metricVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        metricVO.setId(metricId);
        this.application.updateMetric(metricVO);
        auditLog.info("Updated metric [" + metricVO + "]");
        actionLog.info("Updated metric [" + metricVO + "]");
    }

    /**
     * Deletes the metric with the given metricId
     *
     * @param metricId the Id of the metric to be deleted
     * @return an empty metricVO
     */
    @RequestMapping(value = "/{metricId}", method = RequestMethod.DELETE)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void delete(@PathVariable int campaignId, @PathVariable int metricId) {
        this.application.delete(metricId);
        auditLog.info("Deleted metric [" + metricId + "]");
        actionLog.info("Deleted metric [" + metricId + "]");
    }


    /**
     * If the metricToMoveId corresponds to a submetric:
     * - If the metricId is another submetric, the first one is placed after it under the same metric
     * - If the metricId is a MetricScore, the first one is placed under it, in the last position
     * If the metricToMoveId corresponds to a MetricScore:
     * - If the metricId is another MetricScore, the first one is placed after it under the same module
     * - If the metricId is a Module, the first one is placed under it, in the last position
     * If the metricToMoveId corresponds to a Module:
     * - If the metricId is another Module, the first one is placed after it under the same Campaign
     *
     * @param metricId the id of the parent metric
     * @param metricVO the data of the child metric to be appended
     * @return The data of the child metric that was just appended
     */
    @RequestMapping(value = "/{metricId}/append", method = RequestMethod.POST)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public MetricVO append(@PathVariable int metricId, @RequestBody MetricVO metricVO) {
        if (metricVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        Metric metric = this.application.addMetricToMetric(metricId, metricVO);
        auditLog.info("Added metric [" + metric + "] to metric [" + metricId + "]");
        actionLog.info("Added metric [" + metric + "] to metric [" + metricId + "]");
        return new MetricVO(metric, true);
    }

    @RequestMapping(value = "/{metricId}/disable", method = RequestMethod.PUT)
    @Secured({"CAMPAIGN_(0)_UPDATE_METRIC_(1)", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public MetricVO disable(@PathVariable int campaignId, @PathVariable int metricId) {
        Metric metric = this.application.disable(metricId);
        auditLog.info("Disabled metric [" + metric + "]");
        actionLog.info("Disabled metric [" + metric + "]");
        return new MetricVO(metric, false);
    }

    @RequestMapping(value = "/{metricId}/enable", method = RequestMethod.PUT)
    @Secured({"CAMPAIGN_(0)_UPDATE_METRIC_(1)", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public MetricVO enable(@PathVariable int campaignId, @PathVariable int metricId) {
        Metric metric = this.application.enable(metricId);
        auditLog.info("Enabled metric [" + metric + "]");
        actionLog.info("Enabled metric [" + metric + "]");
        return new MetricVO(metric, false);
    }

    @RequestMapping(value = "/{metricId}/saveAndCompute", method = RequestMethod.PUT)
    @Secured({"CAMPAIGN_(0)_COMPUTE_METRIC_(1)", "SYSTEM_ADMINISTRATOR"})//TODO I should have added a different permission for this. It's too late now
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void saveAndCompute(@PathVariable int campaignId, @PathVariable int metricId, @RequestBody MetricVO metricVO) {
        if (metricVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        metricVO.setId(metricId);
        this.application.saveAndCalculateMetricScore(metricVO);
        auditLog.info("Updated and calculated score of metric [" + metricVO + "]");
        actionLog.info("Updated and calculated score of metric [" + metricVO + "]");
    }

    @RequestMapping(value = "/{metricId}/compute", method = RequestMethod.PUT)
    @Secured({"CAMPAIGN_(0)_COMPUTE_METRIC_(1)", "SYSTEM_ADMINISTRATOR"})
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void compute(@PathVariable int campaignId, @PathVariable int metricId) {
        this.application.calculateMetricScore(metricId);
        auditLog.info("Calculated score of metric [" + metricId + "]");
        actionLog.info("Calculated score of metric [" + metricId + "]");
    }

    @RequestMapping(value = "/{metricId}/scores", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_METRIC_(1)_VIEW_SCORES", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public Page<MetricScoreVO> viewScoresPage(@PathVariable int campaignId,
                                              @PathVariable int metricId,
                                              @RequestParam(value = "page", required = false) Integer page,
                                              @RequestParam(value = "rows", required = false) Integer rows,
                                              @RequestParam(value = "sidx", required = false) String sort,
                                              @RequestParam(value = "sord", required = false) String direction,
                                              WebRequest webRequest

    ) {
        return this.application.findScoresByMetricIdAndPage(metricId, new PageRequest(page, rows, new Sort(Sort.getDirection(direction), ControllerUtils.IfNull(sort, MetricScoreVO.SERVICE_CENTER_COLUMN))), ControllerUtils.extractFilter(webRequest));
    }


    @RequestMapping(value = "/scores", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_VIEW_ALL_SCORES_GRID","SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public Page<MetricScoreVO> viewAllScoresPage(@PathVariable int campaignId,
                                              @RequestParam(value = "page", required = false) Integer page,
                                              @RequestParam(value = "rows", required = false) Integer rows,
                                              @RequestParam(value = "sidx", required = false) String sort,
                                              @RequestParam(value = "sord", required = false) String direction,
                                              WebRequest webRequest

    ) {
        return this.application.findScoresByCampaignIdAndPage(campaignId, new PageRequest(page, rows, new Sort(Sort.getDirection(direction), ControllerUtils.IfNull(sort, MetricScoreVO.SERVICE_CENTER_COLUMN))), ControllerUtils.extractFilter(webRequest));
    }


    @RequestMapping(value = "/scores/export", method = RequestMethod.GET)
    @Secured({"CAMPAIGN_(0)_VIEW_ALL_SCORES_GRID", "SYSTEM_ADMINISTRATOR"})
    public void exportScores(@PathVariable int campaignId,
                             @RequestParam(value = "sidx", required = false) String sort,
                             @RequestParam(value = "sord", required = false) String direction,
                             WebRequest webRequest,
                             HttpServletResponse response

    ) throws Exception {
        response.setContentType(DEFAULT_XLS_CONTENT_TYPE);
        response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s.xls\"", "scores"));

        List<MetricScoreVO> data = this.application.findAllScoresByCampaignId(campaignId, new Sort(Sort.getDirection(direction), ControllerUtils.IfNull(sort, MetricScoreVO.SERVICE_CENTER_COLUMN)), ControllerUtils.extractFilter(webRequest));
        OutputStream os = response.getOutputStream();

        exportServices.export(os, data);

    }

    @RequestMapping(value = "/{metricId}/checkSend/{sendValue}", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void checkSend(@PathVariable int campaignId, @PathVariable int metricId, @PathVariable Boolean sendValue) {
        this.application.setSendFlag(metricId, sendValue);
        auditLog.info("Metric send flag updated. MetricID: ["+metricId+"] , send value: [" + sendValue + "]");
        actionLog.info("Metric send flag updated. MetricID: ["+metricId+"] , send value: [" + sendValue + "]");
    }

    @RequestMapping(value = "/{metricId}/checkSend", method = RequestMethod.GET)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void checkSend(@PathVariable int campaignId, @PathVariable int metricId) {
        this.application.setSendFlag(metricId, false);
    }
}
