package com.monsanto.metricspos.boundary.ui;

import com.google.common.collect.Maps;
import com.monsanto.metricspos.boundary.ui.utils.ControllerUtils;
import com.monsanto.metricspos.core.SecurityApplication;
import com.monsanto.metricspos.core.application.vo.EmployeeVO;
import com.monsanto.metricspos.core.application.vo.GroupVO;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.Authority;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.security.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;

import java.util.List;
import java.util.Map;

/**
 * User: PPERA
 */
@Controller
@RequestMapping("/security")
public class SecurityController {

    public static final String LOG_DATE_COLUMN = "date";
    @Autowired
    private SecurityApplication securityApplication;

    @Autowired
    @Qualifier("auditLog")
    private Logger auditLog;

    @Autowired
    @Qualifier("actionLog")
    private Logger actionLog;

    @RequestMapping(value = "/groups", method = RequestMethod.GET)
    @ResponseBody
    public List<GroupVO> listGroups() {
        List<Group> groups = this.securityApplication.listGroups();
        auditLog.trace("Listing groups");
        actionLog.trace("Listing groups");
        return GroupVO.makeGroupVOs(groups);
    }

    @RequestMapping(value = "/groups", method = RequestMethod.POST)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public GroupVO createGroup(@RequestBody GroupVO groupVO) {
        Group group = this.securityApplication.createGroup(groupVO);
        auditLog.info("Created group [" + group + "]");
        actionLog.info("Created group [" + group + "]");
        return new GroupVO(group);
    }

    @RequestMapping(value = "/groups/{groupId}", method = RequestMethod.GET)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public GroupVO viewGroup(@PathVariable int groupId) {
        Group group = this.securityApplication.findGroupById(groupId);
        auditLog.trace("Viewing group [" + group.getName() + "]");
        actionLog.info("Created group [" + group.getName() + "]");
        return new GroupVO(group);
    }

    @RequestMapping(value = "/groups/{groupId}", method = RequestMethod.PUT)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void updateGroup(@PathVariable int groupId, @RequestBody GroupVO groupVO) {
        groupVO.setId(groupId);
        this.securityApplication.updateGroup(groupVO);
        auditLog.info("Updated group [" + groupVO + "]");
        actionLog.info("Updated group [" + groupVO + "]");
    }

    @RequestMapping(value = "/groups/{groupId}", method = RequestMethod.DELETE)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void deleteGroup(@PathVariable int groupId) {
        this.securityApplication.deleteGroup(groupId);
        auditLog.info("Deleted group [" + groupId + "]");
        actionLog.info("Deleted group [" + groupId + "]");
    }

    @RequestMapping(value = "/authorities", method = RequestMethod.GET)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public List<Authority> listAuthorities() {
        auditLog.trace("Listing authorities");
        actionLog.trace("Listing authorities");
        return this.securityApplication.listAuthorities();
    }

    @RequestMapping(value = "/admins", method = RequestMethod.GET)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public List<AdminUser> listAdminUsers() {
        auditLog.trace("Listing admin users");
        actionLog.trace("Listing admin users");
        return this.securityApplication.listAdminUsers();
    }

    @RequestMapping(value = "/admins", method = RequestMethod.POST)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public AdminUser createAdminUser(@RequestBody AdminUser adminUser) {
        auditLog.info("Created admin user [" + adminUser + "]");
        actionLog.info("Created admin user [" + adminUser + "]");
        return this.securityApplication.createAdminUser(adminUser);
    }

    @RequestMapping(value = "/admins/{adminUserId}", method = RequestMethod.DELETE)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void deleteAdminUser(@PathVariable int adminUserId) {
        this.securityApplication.deleteAdminUser(adminUserId);
        auditLog.info("Deleted admin user [" + adminUserId + "]");
        actionLog.info("Deleted admin user [" + adminUserId + "]");
    }

    @RequestMapping(value = "/campaign/{campaignId}/employees", method = RequestMethod.GET)
    @Secured({"CAMPAIGN_(0)_LIST_EMPLOYEES", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public List<EmployeeVO> listEmployees(@PathVariable int campaignId) {
        List<Employee> employees = this.securityApplication.listEmployees(campaignId);
        auditLog.trace("Listing employees of campaign [" + campaignId + "]");
        actionLog.trace("Listing employees of campaign [" + campaignId + "]");
        return EmployeeVO.makeEmployeeVOs(employees);
    }

    @RequestMapping(value = "/campaign/{campaignId}/employees/{employeeId}", method = RequestMethod.GET)
    @Secured({"CAMPAIGN_(0)_VIEW_EMPLOYEE_ALL", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public EmployeeVO findEmployeeByCampaignIdAndEmployeeId(@PathVariable int campaignId, @PathVariable long employeeId) {
        Employee employee = this.securityApplication.findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId);
        auditLog.info("Viewing employee [" + employee + "]");
        actionLog.info("Viewing employee [" + employee + "]");
        return new EmployeeVO(employee);
    }

    @RequestMapping(value = "/campaign/{campaignId}/employees", method = RequestMethod.POST)
    @Secured({"CAMPAIGN_(0)_ADD_EMPLOYEE", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public EmployeeVO createEmployee(@PathVariable int campaignId, @RequestBody EmployeeVO employeeVO) {
        employeeVO.setCampaignId(campaignId);
        Employee employee = this.securityApplication.createEmployee(employeeVO);
        auditLog.info("Created employee [" + employee + "]");
        actionLog.info("Created employee [" + employee + "]");
        return new EmployeeVO(employee);
    }

    @RequestMapping(value = "/campaign/{campaignId}/employees/{employeeId}", method = RequestMethod.PUT)
    @Secured({"CAMPAIGN_(0)_UPDATE_EMPLOYEE", "SYSTEM_ADMINISTRATOR"})
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void updateEmployee(@PathVariable int campaignId, @PathVariable long employeeId, @RequestBody EmployeeVO employeeVO) {
        employeeVO.setId(employeeId);
        this.securityApplication.updateEmployee(campaignId, employeeVO);
        auditLog.info("Updated employee [" + employeeVO + "]");
        actionLog.info("Updated employee [" + employeeVO + "]");
    }

    @RequestMapping(value = "/campaigns/{campaignId}/employees/groups", method = RequestMethod.GET)
    @Secured({"CAMPAIGN_(0)_VIEW_EMPLOYEE_GROUPS", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public Page<Map<String, Object>> viewEmployeeGroups(@PathVariable int campaignId,
                                                        @RequestParam(value = "page", required = false) Integer page,
                                                        @RequestParam(value = "rows", required = false) Integer rows,
                                                        @RequestParam(value = "sidx", required = false) String sort,
                                                        @RequestParam(value = "sord", required = false) String direction,
                                                        WebRequest webRequest) {
        String sortParam = ((sort != null && !sort.isEmpty()) ? sort : "name");
        auditLog.trace("Viewing employee groups for campaign [" + campaignId + "]");
        actionLog.trace("Viewing employee groups for campaign [" + campaignId + "]");
        return this.securityApplication.findEmployeeGroupsByPage(campaignId, new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sortParam)), ControllerUtils.extractFilter(webRequest));
    }

    @RequestMapping(value = "/campaigns/{campaignId}/employees/groups", method = RequestMethod.PUT)
    @Secured({"CAMPAIGN_(0)_UPDATE_EMPLOYEE_GROUPS", "SYSTEM_ADMINISTRATOR"})
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void updateEmployeeGroups(@PathVariable int campaignId, @RequestBody Map<String, Object> employeeGroups) {
        this.securityApplication.updateEmployeeGroups(campaignId, fixUnderscores(employeeGroups));
        auditLog.info("Updating employee groups of employee [" + employeeGroups.get("id") + "] for campaign [" + campaignId + "]");
        actionLog.info("Updating employee groups of employee [" + employeeGroups.get("id") + "] for campaign [" + campaignId + "]");
    }

    @RequestMapping(value = "/logs/audit", method = RequestMethod.GET)
    @Secured({"AUDITOR", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public Page<Map<String, Object>> viewAuditLogsPage(@RequestParam(value = "page", required = false) Integer page,
                                                       @RequestParam(value = "rows", required = false) Integer rows,
                                                       @RequestParam(value = "sidx", required = false) String sort,
                                                       @RequestParam(value = "sord", required = false) String direction,
                                                       WebRequest webRequest) {
        return this.securityApplication.findAuditLogsByPage(new PageRequest(page, rows, new Sort(Sort.getDirection(ControllerUtils.IfNull(direction, "desc")), ControllerUtils.IfNull(sort, LOG_DATE_COLUMN))), ControllerUtils.extractFilter(webRequest));
    }

    @RequestMapping(value = "/logs/action", method = RequestMethod.GET)
    @Secured({"AUDITOR", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public Page<Map<String, Object>> viewActionLogsPage(@RequestParam(value = "page", required = false) Integer page,
                                                        @RequestParam(value = "rows", required = false) Integer rows,
                                                        @RequestParam(value = "sidx", required = false) String sort,
                                                        @RequestParam(value = "sord", required = false) String direction,
                                                        WebRequest webRequest) {
        return this.securityApplication.findActionLogsByPage(new PageRequest(page, rows, new Sort(Sort.getDirection(ControllerUtils.IfNull(direction, "desc")), ControllerUtils.IfNull(sort, LOG_DATE_COLUMN))), ControllerUtils.extractFilter(webRequest));
    }

    private Map<String, Object> fixUnderscores(Map<String, Object> employeeGroups) {
        Map<String, Object> employeeGroupsWithSpaces = Maps.newHashMap();

        for (String key : employeeGroups.keySet()) {
            employeeGroupsWithSpaces.put(key.replaceAll("_", " "), employeeGroups.get(key));
        }
        return employeeGroupsWithSpaces;
    }
}
