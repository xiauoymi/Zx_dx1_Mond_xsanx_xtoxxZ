package com.monsanto.metricspos.boundary.ui;

import com.google.common.collect.Lists;
import com.monsanto.metricspos.boundary.ui.utils.ControllerUtils;
import com.monsanto.metricspos.core.DataLoader;
import com.monsanto.metricspos.core.ExportServices;
import com.monsanto.metricspos.core.TablesApplication;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.application.vo.DataRowVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataFile;
import com.monsanto.metricspos.core.externaldata.DataRow;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.dao.Page;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import com.monsanto.utils.ExcelReader;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.security.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * User: PPERA
 */
@Controller
@RequestMapping("/campaigns/{campaignId}/tables")
public class TableController {

    private static final String DEFAULT_XLS_CONTENT_TYPE = "application/xls";
    private static final String APPLICATION_OCTET_STREAM = "application/octet-stream";
    public static final String ERROR_ROW_ID_COULD_NOT_BE_RESOLVED = "Row internal id could not be resolved";

    @Autowired
    private TablesApplication application;

    @Autowired
    private DataLoader dataLoader;

    @Autowired
    private ExportServices exportServices;

    @Autowired
    @Qualifier("auditLog")
    private Logger auditLog;

    @Autowired
    @Qualifier("actionLog")
    private Logger actionLog;

    @RequestMapping(value = "", method = RequestMethod.POST)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void createDataTable(@PathVariable int campaignId, @RequestBody DataTableVO dataTableVO) {
        this.application.newDataTable(dataTableVO);
        auditLog.info("Created data table [" + dataTableVO + "]");
        actionLog.info("Created data table [" + dataTableVO + "]");
    }

    @RequestMapping(value = "/{tableId}", method = RequestMethod.GET)
    @Secured({"CAMPAIGN_(0)_TABLE_(1)_VIEW", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public DataTableVO view(@PathVariable int campaignId, @PathVariable int tableId) {
        DataTable dataTable = this.application.findDataTableById(tableId);
        auditLog.trace("Viewing data table [" + dataTable + "]");
        actionLog.trace("Viewing data table [" + dataTable + "]");
        return new DataTableVO(dataTable, true);
    }

    @RequestMapping(value = "/{tableId}", method = RequestMethod.PUT)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void update(@PathVariable int campaignId, @PathVariable int tableId, @RequestBody DataTableVO dataTableVO) {
        dataTableVO.setId(tableId);
        this.application.updateDataTable(dataTableVO);
        auditLog.info("Updated data table [" + dataTableVO + "]");
        actionLog.info("Updated data table [" + dataTableVO + "]");
    }

    @RequestMapping(value = "/{tableId}", method = RequestMethod.DELETE, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void delete(@PathVariable int campaignId, @PathVariable int tableId) {
        this.application.removeDataTable(tableId);
        auditLog.info("Deleted data table [" + tableId + "]");
        actionLog.info("Deleted data table [" + tableId + "]");
    }

    @RequestMapping(value = "/{tableId}/metadata", method = RequestMethod.GET)
    @Secured({"CAMPAIGN_(0)_TABLE_(1)_VIEW", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public List<DataColumnVO> viewMetadata(@PathVariable int campaignId, @PathVariable int tableId) {
        List<DataColumn> columns = this.application.findMetadataByDataTableId(tableId);
        auditLog.trace("Viewing data table columns [" + tableId + "]");
        actionLog.trace("Viewing data table column [" + tableId + "]");
        return DataColumnVO.makeDataColumnVOs(columns);
    }

    @RequestMapping(value = "/{tableId}/metadata", method = RequestMethod.PUT)
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public List<DataColumnVO> updateMetadata(@PathVariable int campaignId, @PathVariable int tableId, @RequestBody DataColumnVO[] columnsArray) {
        List<DataColumnVO> columns = Lists.newArrayList(columnsArray);
        List<DataColumn> dataColumns = this.application.updateMetadata(tableId, columns);
        auditLog.info("Updated data table columns [" + tableId + "]");
        actionLog.info("Updated data table column [" + tableId + "]");
        return DataColumnVO.makeDataColumnVOs(dataColumns);
    }

    @RequestMapping(value = "/{tableId}/rows", method = RequestMethod.POST, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_TABLE_(1)_ADD_ROW", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public List<DataRowVO> createRows(@PathVariable int campaignId, @PathVariable int tableId, @RequestBody Map<String, Object>[] row) {
        List<DataRow> dataRows = this.application.createRows(tableId, row);
        auditLog.info("Updated data table columns [" + tableId + "]");
        actionLog.info("Updated data table column [" + tableId + "]");
        return DataRowVO.makeDataRowVOs(dataRows);
    }

    @RequestMapping(value = "/{tableId}/rows", method = RequestMethod.GET, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_TABLE_(1)_VIEW_ROW", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public Page<DataRowVO> viewRowsPage(@PathVariable int campaignId, @PathVariable int tableId,
                                        @RequestParam(value = "page", required = false) Integer page,
                                        @RequestParam(value = "rows", required = false) Integer rows,
                                        @RequestParam(value = "sidx", required = false) String sort,
                                        @RequestParam(value = "sord", required = false) String direction,
                                        WebRequest webRequest

    ) {
        String sortParam = ((sort != null && !sort.isEmpty()) ? sort : "serviceCenter");
        auditLog.trace("Viewing rows of table [" + tableId + "]");
        actionLog.trace("Viewing rows of table [" + tableId + "]");
        return this.application.findRowsByDataTableIdAndPage(tableId, new PageRequest(page, rows, new Sort(Sort.getDirection(direction), sortParam)), ControllerUtils.extractFilter(webRequest));
    }

    @RequestMapping(value = "/{tableId}/rows", method = RequestMethod.PUT, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_TABLE_(1)_UPDATE_ROW", "SYSTEM_ADMINISTRATOR"})
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void updateRow(@PathVariable int campaignId, @PathVariable int tableId, @RequestBody Map<String, Object> row) {
        if (row.get(DataRowVO.ROW_ID_KEY) == null) {
            throw new BusinessException(ERROR_ROW_ID_COULD_NOT_BE_RESOLVED, 422);
        }

        this.application.updateRow(tableId, row);

        auditLog.info("Updated manually row of table [" + tableId + "]");
        actionLog.info("Updated mannually rows of table [" + tableId + "]");
    }

    @RequestMapping(value = "/{tableId}/rows", method = RequestMethod.DELETE, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void deleteRows(@PathVariable int campaignId, @PathVariable int tableId, @RequestBody Integer[] rowId) {
        this.application.deleteRows(tableId, Lists.newArrayList(rowId));
        auditLog.info("Deleted rows of table [" + tableId + "]");
        actionLog.info("Deleted rows of table [" + tableId + "]");
    }

    @RequestMapping(value = "/{tableId}/rows/deleteAll", method = RequestMethod.DELETE, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void deleteAllRows(@PathVariable int campaignId, @PathVariable int tableId) {
        this.application.deleteAllRows(tableId);
        auditLog.info("Deleted all rows of table [" + tableId + "]");
        actionLog.info("Deleted all rows of table [" + tableId + "]");
    }

    @RequestMapping(value = "/{tableId}/rows/import", method = RequestMethod.POST, produces = "application/json")
    @Secured({"CAMPAIGN_(0)_TABLE_(1)_ADD_ROW", "SYSTEM_ADMINISTRATOR"})
    @ResponseBody
    public Map importData(@PathVariable int campaignId, @PathVariable int tableId, MultipartFile file) {
        Map res = new HashMap();
        try {
            ExcelReader reader = new ExcelReader(file.getBytes());
            List<Map<String, Object>> data = reader.getDataMap(0);
            Map<String, Object>[] rows = new Map[data.size()];

            List<DataRow> dataRows = this.application.createRows(tableId, data.toArray(rows));

            List<DataRowVO> result = DataRowVO.makeDataRowVOs(dataRows);
            res.put("result", "OK");
            res.put("message", result.size() + " rows inserted.");
        } catch (Exception e) {
            res.put("result", "NG");
            actionLog.warn(e);
            String men = (e.getMessage() != null) ? e.getMessage() : e.toString();
            res.put("message", men);
        }

        auditLog.info("Imported rows of table [" + tableId + "]");
        actionLog.info("Imported rows of table [" + tableId + "]");
        return res;
    }

    @RequestMapping(value = "/{tableId}/rows/export", method = RequestMethod.GET)
    @Secured({"CAMPAIGN_(0)_TABLE_(1)_VIEW_ROW", "SYSTEM_ADMINISTRATOR"})
    public void exportData(@PathVariable int campaignId,
                           @PathVariable int tableId,
                           @RequestParam(value = "page", required = false) Integer page,
                           @RequestParam(value = "rows", required = false) Integer rows,
                           @RequestParam(value = "sidx", required = false) String sort,
                           @RequestParam(value = "sord", required = false) String direction,
                           WebRequest webRequest,
                           HttpServletResponse response

    ) {
        DataTable dataTable = this.application.findDataTableById(tableId);
        response.setContentType(DEFAULT_XLS_CONTENT_TYPE);
        response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s.xls\"", dataTable.getName()));

        List<DataRow> data = this.application.findRowsByDataTable(dataTable, new Sort(Sort.getDirection(direction), ControllerUtils.IfNull(sort, "serviceCenter")), ControllerUtils.extractFilter(webRequest));
        try {
            OutputStream os = response.getOutputStream();

            exportServices.export(os, dataTable, data);
            auditLog.info("Exported rows of table [" + tableId + "]");
            actionLog.info("Exported rows of table [" + tableId + "]");
        }catch (Exception ex){
            throw new BusinessException(BusinessException.ERROR_IN_PROCESS, 501, ex);
        }
    }

    @RequestMapping(value = "/{tableId}/rows/load", method = RequestMethod.POST, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void saveAndExecuteLoad(@PathVariable int campaignId, @PathVariable int tableId, @RequestBody DataTableVO dataTableVO){
        if (dataTableVO == null) {
            throw new BusinessException(BusinessException.ERROR_VO_CANNOT_BE_NULL, 400);
        }

        dataTableVO.setId(tableId);
        try{
            this.dataLoader.saveAndExecuteTableLoad(dataTableVO);
        }catch (Exception ex){
            throw new BusinessException(BusinessException.ERROR_IN_PROCESS, 501, ex);
        }
        auditLog.info("Manually executed load of table [" + tableId + "]");
        actionLog.info("Manually executed load of table [" + tableId + "]");
    }

    @RequestMapping(value = "/{tableId}/rows/download/{mpsInternalId}", method = RequestMethod.GET)
    @Secured({"CAMPAIGN_(0)_TABLE_(1)_VIEW_ROW", "SYSTEM_ADMINISTRATOR"})
    public void downloadFile(@PathVariable int campaignId,
                             @PathVariable int tableId,
                             @PathVariable int mpsInternalId,
                             HttpServletResponse response
    ) {
        DataFile dataFile = this.application.findRowDataFile(tableId, mpsInternalId);

        if (dataFile != null && dataFile.getFileData() != null) {
            response.setContentType(APPLICATION_OCTET_STREAM);
            response.setHeader("Content-Disposition", String.format("attachment; filename=\"%s\"", dataFile.getFileName()));
            OutputStream os;
            try {
                os = response.getOutputStream();
                os.write(dataFile.getFileData());
                os.flush();
                os.close();
            } catch (IOException e) {
                throw new BusinessException(BusinessException.ERROR_IN_PROCESS, 501, e);
            }
        }

        auditLog.trace("Downloaded file of row [" + mpsInternalId + "]");
        actionLog.trace("Downloaded file of row [" + mpsInternalId + "]");
    }
}
