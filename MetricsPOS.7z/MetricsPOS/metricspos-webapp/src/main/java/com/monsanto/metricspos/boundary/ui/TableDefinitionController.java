package com.monsanto.metricspos.boundary.ui;

import com.monsanto.metricspos.core.TablesApplication;
import com.monsanto.metricspos.core.application.vo.DataProviderVO;
import com.monsanto.metricspos.core.externaldata.DataType;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * User: PPERA
 */
@Controller
@RequestMapping("/tables")
public class TableDefinitionController {

    @Autowired
    private TablesApplication application;

    @Autowired
    @Qualifier("auditLog")
    private Logger auditLog;

    @Autowired
    @Qualifier("actionLog")
    private Logger actionLog;

    @RequestMapping(value = "/dataTypes", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public List<DataType> listDataTypes() {
        auditLog.trace("Listing data types");
        actionLog.info("Listing data types");
        return this.application.listDataTypes();
    }

    @RequestMapping(value = "/providers", method = RequestMethod.GET, produces = "application/json")
    @Secured("SYSTEM_ADMINISTRATOR")
    @ResponseBody
    public List<DataProviderVO> listProviders() {
        auditLog.trace("Listing providers");
        actionLog.info("Listing providers");
        return DataProviderVO.makeDataProviderVOs(this.application.listProviders());
    }
}
