package com.monsanto.metricspos.boundary.ui.utils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.springframework.web.context.request.WebRequest;

import java.util.List;
import java.util.Map;

/**
 * User: PPERA
 */
public final class ControllerUtils {

    private ControllerUtils() {
    }

    public static Map<String, Object> extractFilter(WebRequest webRequest) {
        Map<String, Object> filter = Maps.newHashMap();

        if (webRequest != null && webRequest.getParameterNames() != null) {
            List<String> parameters = Lists.newArrayList(webRequest.getParameterNames());
            for (String parameter : parameters) {
                filter.put(parameter, webRequest.getParameter(parameter));
            }
        }

        return filter;
    }


    public static String IfNull(String sort, String defaultSort) {
        return ((sort != null && !sort.isEmpty()) ? sort : defaultSort);
    }
}
