var $$messages =
{ "title":"Monsanto - Programa Excelencia Magnum"
    , "back.to.home": "Volver al comienzo"

    , "user.welcome": "Bienvenido "
    , "user.working.on": "Trabajando en Campaña"

    , "detail": "Detalle"
    , "tables": "Tablas"
    , "table": "Tabla"
    , "columns": "Columnas"
    , "metrics": "Métricas"
    , "serviceCenters": "Centros de servicio"
    , "pointsOfSale": "Puntos de venta"
    , "employees": "Empleados"
    , "structure": "Distribuidores"

    , "menu.campaign": "Menu de campaña"
    , "menu.campaign.detail": "Ver detalle"
    , "menu.campaign.edit": "Editar ..."
    , "menu.campaign.new": "Nueva campaña ..."
    , "menu.campaign.list": "Listado de campañas"
    , "menu.campaign.parameters": "Parámetros"
    , "menu.campaign.dataLoad": "Carga de datos"

    , "menu.security.campaign": "Seguridad de campaña"
    , "menu.security.application": "Seguridad de applicación"

    , "campaign.none": "No existen campañas cargadas."
    , "campaign.create.one": "Si desea crear una haga click aquí."
    , "campaign.id": "Id"
    , "campaign.name":"Campaña"
    , "campaign.since": "Desde"
    , "campaign.until": "Hasta"
    , "campaign.state": "Estado"
    , "campaign.ratingFormula": "Formula de calificación"
    , "campaign.ratingPremiumCategory": "Requisitos Categoría Premium"

    , "campaign.editing": "Editando la campaña"
    , "campaign.viewing": "Detalles de la campaña"
    , "campaign.viewing.tables": "Tablas de la campaña"
    , "campaign.action": "Acción"
    , "campaign.no.metrics": "La campaña no tiene métricas aún"
    , "campaign.button.send": "Enviar informes a centros de servicio"
    , "campaign.scores.calculate": "Recalcular todos los puntajes"
    , "campaign.tables.reload": "Recargar tablas"
    , "campaign.scores.view.all": "Ver todos los puntajes"
    , "campaign.serviceCenter.report": "Reporte de Centro de Servicios"
    , "campaign.serviceCenter.export.ranking": "Exportar Ranking"

    , "campaign.state.CREATED":"Creada"
    , "campaign.state.open":"Abierta"
    , "campaign.state.closed":"Cerrada"
    , "campaign.state.pending":"Pendiente"

    , "campaign.no.tables": "La campaña no tiene tablas aún. Haga clic para agregar la primera."

    , "campaign.dataLoad":"Editar los procesos de carga de datos para la campaña"
    , "campaign.dataLoad.serviceCenters.editing":"Carga de datos de centros de servicio de la campaña"
    , "campaign.dataLoad.pointsOfSale.editing":"Carga de datos puntos de venta de la campaña"
    , "campaign.dataLoad.employees.editing":"Carga de datos puntos de venta de la campaña"
    , "campaign.dataLoad.sql":"SQL de obtención de datos"
    , "campaign.dataLoad.script":"Script de procesamiento de datos"
    , "campaign.dataLoad.schedule":"Programar campaña para carga en lotes"

    , "campaign.serviceCenters.view.title": "Centros de servicio"
    , "campaign.pointsOfSale.view.title": "Puntos de venta"
    , "campaign.parameters": "Parametros de la campaña"

    , "metric.id": "Id"
    , "metric.name": "Nombre"
    , "metric.enabled": "Habilitada"
    , "metric.campaign": "Campaña"
    , "metric.formula": "Fórmula de cálculo"
    , "metric.owner": "Responsable"
    , "metric.maxPoints": "Puntaje maximo"
    , "metric.scheduled": "Programar metrica para calculo de scores en lotes"
    , "metric.send": "Enviar"
    , "metric.type": "Tipo"

    , "metric.edit": "Editar la definición de la Métrica"

    , "metric.editing": "Editando la métrica"
    , "metric.viewing": "Viendo el detalle de la (sub) métrica"
    , "metric.add": "Agregar nueva métrica"
    , "metric.tables.used": "Seleccione las tablas usadas en la formula"
    , "metric.compute.scores": "Calcular los puntajes de esta metrica"

    , "module.edit": "Editar la definición del Módulo"
    , "module.editing": "Editando el Módulo "

    , "submetric.editing": "Editando la (Sub)métrica"
    , "submetric.explanation" : "Explicación"
    , "submetric.weighting" : "Es Ponderador"

    , "serviceCenter.attributes": "Atributos de un centro de servicio"
    , "pointOfSale.attributes": "Atributos de un punto de venta"
    , "employee.attributes": "Atributos de un Employee"

    , "serviceCenters.view": "Ver listado de centros de servicio"
    , "pointsOfSale.view": "Ver listado de puntos de venta"
    , "employees.view": "Ver listado de empleados"

    , "table.id": "Id"
    , "table.name": "Nombre"
    , "table.description": "Descripción"
    , "table.provider": "Proveedor"
    , "table.campaign": "Campaña"
    , "table.rowCount": "Filas"
    , "table.allowRecordCreation": "Permite agregar datos"
    , "table.allowRecordCreation.true": "Sí"
    , "table.allowRecordCreation.false": "No"

    , "table.add": "Agregar tabla"
	, "table.clear": "Vaciar tabla"
    , "table.editing": "Editando la tabla"
    , "table.edit": "Editar tabla"
    , "table.viewing": "Viendo el detalle de la tabla"
    , "table.columns.list": "Columnas de la tabla"

    , "table.no.columns": "La tabla no tiene columnas aún. Haga click aquí para agregar la primera."
    , "table.no.metrics": "La tabla no está siendo usada por ninguna métrica."

    , "table.view": "Ver el detalle de la tabla de datos"
    , "table.edit": "Modificar el detalle de la tabla de datos"
    , "table.delete": "¿Desea eliminar la tabla y las definiciones de sus columnas?"
    , "table.edit.columns": "Editar las columnas de la tabla"
    , "table.view.rows": "Ver datos de la tabla"

    , "table.add.rows": "Agregar datos a la tabla"
    , "table.add.column": "Agregar Columna"
    , "table.save.rows": "Guardar"
    , "table.delete.rows": "Eliminar las filas seleccionadas."

    , "table.dataLoad":"Editar los procesos de carga de datos para la tabla"
    , "table.dataLoad.editing":"Carga de datos de la tabla"
    , "table.dataLoad.sql":"SQL de obtención de datos"
    , "table.dataLoad.script":"Script de procesamiento de datos"
    , "table.dataLoad.schedule":"Programar tabla para carga en lotes"
    , "table.dataLoad.lastUpdate":"Ultima actualización"
    , "table.dataLoad.lastRunSucceed":"Actualización\nexitosa"
    , "table.dataLoad.lastRunSucceed.true":"Sí"
    , "table.dataLoad.lastRunSucceed.false":"No"
    , "table.dataLoad.schedule.title":"Carga de datos \nProgramada"
    , "table.dataLoad.schedule.true":"Sí"
    , "table.dataLoad.schedule.false":"No"
    , "table.include.data": "Incluir tabla en resumen"

    , "column.name": "Nombre"
    , "column.label": "Etiqueta"
    , "column.type": "Tipo"
    , "column.size": "Largo"
    , "column.minSize": "Largo Mínimo"
    , "column.precision": "Decimales"
    , "column.attributes": "Atributos"
    , "column.description": "Descripción"
    , "column.options": "Opciones"
    , "column.option.list": "Ingrese la opciones de la columna. Separe la opciones con ','."

    , "column.edit": "Editar las columnas de la tabla"
    , "column.current": "En la fila seleccionada"
    , "column.delete": "Quitar esta columna de la tabla"
    , "column.required": "Indica si la columna es requerida o es opcional"
    , "column.sortable": "Indica si se puede ordenar por la columna"
    , "column.filterable": "Indica si se puede filtrar por la columna"
    , "column.editable": "Indica si el campo es editable"
    , "column.hidden": "Indica si la columna es visible o se encuentra oculta por defecto"
    , "column.primaryKey": "Indica si la el campo identifica el dato (es campo clave)"
    , "column.manual": "Indica que es un campo que se carga manualmente y no se vera afectado por la actualizacion por batch (util para marcar filas exceptuadas de calculo)"
    , "module": "Módulo"
    , "metric": "Métrica"
    , "submetric": "Sub-metrica"

    , "module.add": "Agregar módulo"
    , "module.delete": "Eliminar módulo"
    , "module.toggle": "Habilitar/Deshabilitar módulo"
    , "metric.delete": "Eliminar métrica"
    , "metric.toggle": "Habilitar/Deshabilitar métrica"
    , "submetric.add": "Agregar sub-métrica"
    , "submetric.delete": "Eliminar la sub-métrica"
    , "submetric.edit": "Editar la definición de la sub-métrica"
    , "submetric.toggle": "Habilitar/Deshabilitar sub-métrica"
    , "metric.view.scores": "Ver puntajes de la sub-métrica"
    , "metric.scores.view.title": "Puntajes de la métrica"
    , "all.metric.scores.view.title": "Puntajes de la Campaña"
    , "points": "Puntaje"
    , "percentage": "Porcentaje Alcanzado"

    , "summary.campaign": "Resumen de campaña"
    , "summary.serviceCenter": "Resumen de centro de servicio"
    , "summary.campaign.rating": "Calificación"
    , "summary.campaign.premiumCategory": "Requisitos Categoría Premium"
    , "summary.campaign.points": "Puntaje obtenido"
    , "summary.button.send": "Enviar resumen a centro de servicio"
    , "summary.lastSent": "Ultimo envio a centro de servicio"

    , "group.id": "Id de grupo"
    , "group.name": "Nombre"
    , "group.authorities": "Permisos"
    , "group.action": "Acciones"
    , "group.editing": "Editando el grupo"
    , "group.list": "Listado de grupos"
    , "group.add": "Agregar nuevo grupo"
    , "group.none": "Aun no existe ningun grupo"
    , "group.authorities.assigned": "Permisos asignados"
    , "group.authorities.unassigned": "Permisos no asignados"

    , "security.menu.groups": "Grupos"
    , "security.menu.admins": "Administradores"
    , "security.menu.employees": "Usuarios de la campaña"
    , "security.menu.employees.groups": "Grupos por usuario"
    , "security.menu.logs.audit": "Logs de auditoría"
    , "security.menu.logs.action": "Logs de acciones"

    , "admin.list": "Listado de administradores"
    , "admin.username": "Username"
    , "admin.action": "Accion"
    , "admin.add": "Agregar un nuevo administrador"

    , "employee.list": "Lista de empleados"
    , "employee.none": "Aún no hay usuarios de campaña cargados."
    , "employee.add": "Crear nuevo usuario de campaña"
    , "employee.action": "Accion"
    , "employee.tab.details": "Detalles de usuario"
    , "employee.tab.metrics": "Metricas"
    , "employee.tab.serviceCenters": "Centros de servicio"
    , "employee.editing": "Editando usuario"
    , "employee.id": "Id"
    , "employee.name": "Nombre"
    , "employee.username": "Nombre de usuario"
    , "employee.enabled": "Habilitado"
    , "employee.metrics.assigned": "Metricas asignadas"
    , "employee.metrics.unassigned": "Metricas no asignadas"
    , "employee.metrics.loading": "Cargando listado de metricas..."
    , "employee.serviceCenters.assigned": "Centros de servicio asignados"
    , "employee.serviceCenters.unassigned": "Centros de servicio no asignados"
    , "employee.serviceCenters.loading": "Cargando centros de servicio"
    , "employee.state": "Estado"
    , "employee.state.enabled": "Habilitado"
    , "employee.state.disabled": "Deshabilitado"

    , "actions": "Acciones"
    , "new": "Nueva"
    , "save": "Guardar"
    , "saveexecute": "Guardar y ejecutar"
    , "savereturn": "Guardar y volver"
    , "cancel": "Cancelar"
    , "delete": "Borrar"
    , "saveAndComputeScore.test": "Probar calculo de score"

    , "enter.name": "Ingrese el nombre"
    , "badPeriod": ": La fecha inicial debe ser anterior a la final"
    , "minlength": "es muy corto"
    , "required": "es obligatorio"
    , "min": "el valor es inferior al mínimo permitido"
    , "max": "el valor es superior al máximo permitido"
    , "minSizeLESize": "el tamaño mínimo debe ser menor o igual la longitud máxima del campo"
    , "precisionLTSize": "la cantidad de decimales deber ser menor a la longitud del campo"

    , "hide.show.columns": "Mostrar/Ocultar Columnas"
    , "logs.audit": "Logs de auditoria"
    , "logs.action": "Logs de acciones"

    , "help.script": "Ayuda"

    , "help.script.introduction": "Los scripts de carga de datos se ejecutan usando un motor con una sintaxis especifica la cual se encuentra en esta misma sección." +
    " Algunos scripts tienen variables pre-definidas para poder hacer uso de información externa. A continuación se describirán los particulares de cada caso."
    , "help.script.campaignDataLoad.title": "Script de carga de datos estructurales de campaña:"
    , "help.script.campaignDataLoad": "En este set de scripts el resultado del sql se encuentra en la variable \"input\" y" +
    " el resultado deseado se escribe en la variable pre-definida \"output\"." +
    " Para acceder a las diferentes columnas de \"input\" escriba el nombre de estas luego de un punto (ej:input.id). Tenga en cuenta que el sistema diferencia las mayúsculas" +
    " de las minúsculas. Para escribir la variable de resultado \"output\" debe asignar valores a los atributos correspondientes. Estos se encuentran detallados en la pantalla" +
    " de edición del script. Asigne a output los valores de sus diferentes atributos (ej1: output.id = 1;, ej2: output.id = input.id;). Recuerde terminar todas las sentencias" +
    " con punto y coma (;). NO OLVIDE QUE al final del script debe colocar la sentencia: \"return output;\" para indicarle al sistema que escriba el resultado. El script se" +
    " ejecutará una vez por cada registro traído por la query ejecutada."
    , "help.script.tableDataLoad.title": "Script de carga de tablas de datos:"
    , "help.script.tableDataLoad": "En este set de scripts el resultado del sql se encuentra en la variable \"input\" y " +
    "el resultado deseado se escribe en la variable pre-definida \"output\"." +
    " Para acceder a las diferentes columnas de \"input\" escriba el nombre de estas luego de un punto (ej:input.id). Tenga en cuenta que el sistema diferencia las mayúsculas" +
    " de las minúsculas. Para escribir la variable de resultado \"output\" debe asignar valores a los atributos correspondientes. Estos se encuentran detallados en la pantalla" +
    " de edición del script. Asigne a output los valores de sus diferentes atributos (ej1: output.id = 1;, ej2: output.id = input.id;). Recuerde terminar todas las sentencias" +
    " con punto y coma (;). NO OLVIDE QUE al final del script debe colocar la sentencia: \"return output;\" para indicarle al sistema que escriba el resultado. El script se" +
    " ejecutará una vez por cada registro traído por la query ejecutada."
    , "help.script.ratingFormula.title": "Script de calificación de puntaje:"
    , "help.script.ratingFormula": "Este script se utiliza para asignar una calificación a un centro de servicio de acuerdo a su desempeño." +
    " Las calificaciones consisten en un texto cualquiera como ser \"A\" o \"De primera categoría\". Para tomar la decisión de que calificación asignar se puede utilizar" +
    " la variable predefinida \"totalPoints\" que contiene el puntaje actual del centro de servicio analizado, o la variable \"summary\" que es el nodo raiz del arbol" +
    " de puntajes. \"summary\" contiene los puntos totales (summary.points), los puntos máximos (summary.maxPoints) y los hijos de la campaña. Estos últimos son como summaries" +
    " relativos a los modulos los cuales a su vez contienen como hijos a las métricas que por ultimo tienen a sus submétricas hijas. La estructura es compleja pero puede" +
    " recorrerse para obtener el puntaje de un modulo, métrica o submétrica en particular si es que eso afecta a la calificación. La calificación se debe retornas usando" +
    " \"return\"."
    , "help.script.scoreFormula.title": "Script de computo de puntaje:"
    , "help.script.scoreFormula": "Este script permite obtener el puntaje de una métrica valindose de la información necesaria de un centro" +
    " de servicio y los datos de las tablas definidas dinámicamente. Los resultados se asignan a la variable \"score\" usando score.setPoints(), score.setPenalty() y" +
    " score.setPenaltyFactor(). Para indicar el fin del script se debe retornar una de las siguientes variables predefinidas: \"return HAS_DATA\" si el score debe ser persistido" +
    " porque el calculo de puntos tuvo lugar y \"return NO_DATA\" si no había datos para realizar el calculo. No es lo mismo que un puntaje sea 0 por falta de datos que" +
    " por un mal desempeño. Para acceder al puntaje de la métrica se puede utilizar la variable predefinida \"maxPoints\". Para acceder a los datos de las tablas se utiliza" +
    " la variable predefinida \"database\" a la que se le pueden realizar consultas como \"database.query('Select AGE from TEST_TABLE');\". Este ejemplo obtiene la columna" +
    " \"AGE\" de la tabla \"TEST_TABLE\". Retornara un vector con los datos correspondientes en forma de registros. Para acceder al valor de las columnas se deberá utilizar" +
    " el punto (.) y el nombre o alias de la columna en particular."

    ,"help.script.tableDataLoad.file.load.title": "Columnas tipo Archivo (FILE)"
    ,"help.script.tableDataLoad.file.load": "La carga de columnas con contenido binario (archivos) se puede realizar mediante la función prefefinida \"file.load\". " +
    "El resultado de esta función debe ser asignado a una columna del tipo \"FILE\"." +
    " La función acepta 2 parámetros: " +
    "p1) Nombre del archivo (incluyendo extensión) - p2) Nombre de la columna del CRM que contiene los datos del archivo (binario). " +
    "Ejemplo: output.PDF = file.load(input.fileName, input.fileData);"

    ,"error.computeError": "Ha ocurrido un error computando la métrica"
    ,"error.not.computed": "La métrica aún no se ha computado"
};