var CampaignListController;

/**
 * http://docs.angularjs.org/guide/module
 *   A service module, for service declaration
 *   A directive module, for directive declaration
 *   A filter module, for filter declaration
 *   And an application level module which depends on the above modules, and which has initialization code.
 */

var applicationModule = angular.module('application', ['ui', 'ngResource','SharedServices'], function($routeProvider, $locationProvider) {
    // TODO Check if controller should be set here or in page
    $routeProvider
        .when('/campaign/list', {
            templateUrl: 'campaign/list.jsp'
        })
        .when('/index.jsp', {
            redirectTo: '/campaign/list'
        })
        .when('/campaign/new', {
            templateUrl: 'campaign/edit.jsp'
        })
        .when('/campaign/:campaignId/edit', {
            templateUrl: 'campaign/edit.jsp'
        })
        .when('/campaign/:campaignId/tables', {
            templateUrl: 'campaign/detail.jsp'
        })
        .when('/campaign/:campaignId/tablesList', {
            templateUrl: 'campaign/tables.jsp'
        })
        .when('/campaign/parameters', {
            templateUrl: 'campaign/parameters.jsp'
        })
        .when('/campaign/:campaignId/serviceCenters', {
            templateUrl: 'campaign/serviceCenters.jsp'
        })
        .when('/campaign/:campaignId/pointsOfSale', {
            templateUrl: 'campaign/pointsOfSale.jsp'
        })
        .when('/campaign/:campaignId/serviceCenter/:cuit/summary', {
            templateUrl: 'serviceCenter/summary.jsp'
        })
        .when('/campaign/:campaignId', {
            templateUrl: 'campaign/detail.jsp'
        })
        .when('/campaign/:campaignId/dataLoad', {
            templateUrl: 'campaign/dataLoad.jsp'
        })
        .when('/campaign/:campaignId/module/:metricId/edit', {
            templateUrl: 'module/edit.jsp'
        })
        .when('/campaign/:campaignId/metric/:metricId/edit', {
            templateUrl: 'metric/edit.jsp'
        })
        .when('/campaign/:campaignId/submetric/:metricId/edit', {
            templateUrl: 'submetric/edit.jsp'
        })
        .when('/campaign/:campaignId/metric/:metricId/scores', {
            templateUrl: 'metric/scores.jsp'
        })
        .when('/campaign/:campaignId/metric/scores', {
            templateUrl: 'campaign/scores.jsp'
        })
        .when('/campaign/:campaignId/table/new', {
            templateUrl: 'table/edit.jsp'
        })
        .when('/campaign/:campaignId/table/:tableId/edit', {
            templateUrl: 'table/edit.jsp'
        })
        .when('/campaign/:campaignId/table/:tableId/metadata', {
            templateUrl: 'table/metadata.jsp'
        })
        .when('/campaign/:campaignId/table/:tableId', {
            templateUrl: 'table/view.jsp'
        })
        .when('/campaign/:campaignId/table/:tableId/rows', {
            templateUrl: 'table/rows.jsp'
        })
        .when('/campaign/:campaignId/table/:tableId/dataLoad', {
            templateUrl: 'table/dataLoad.jsp'
        })
        .when('/security/group/list', {
            templateUrl: 'security/group/list.jsp'
        })
        .when('/security/group/new', {
            templateUrl: 'security/group/edit.jsp'
        })
        .when('/security/group/:groupId/edit', {
            templateUrl: 'security/group/edit.jsp'
        })
        .when('/security/admin/list', {
            templateUrl: 'security/admin/list.jsp'
        })
        .when('/security/campaign/:campaignId/employees/groups', {
            templateUrl: 'security/employee/employeeGroups.jsp'
        })
        .when('/security/campaign/:campaignId/employees', {
            templateUrl: 'security/employee/list.jsp'
        })
        .when('/security/campaign/:campaignId/employee/:employeeId/edit', {
            templateUrl: 'security/employee/edit.jsp'
        })
        .when('/security/campaign/:campaignId/employee/edit', {
            templateUrl: 'security/employee/edit.jsp'
        })
        .when('/security/log/audit', {
            templateUrl: 'security/audit/auditLogs.jsp'
        })
        .when('/security/log/action', {
            templateUrl: 'security/audit/actionLogs.jsp'
        })
        .when('/', {
            redirectTo: '/campaign/list'
        })
        .when('/script/help', {
            templateUrl: 'scriptHelp.jsp'
        })
        .otherwise({
            template: '<p>Invalid URL !!</p>',
            controller: RouteErrorController
        });

    $locationProvider.html5Mode(false).hashPrefix('');


});

/**
 * Service to convert a message key to a language specific translation
 */
applicationModule.service('messageConverter', function() {
    /**
     * @param {string} key The key of the message
     * @param {mixed} arg[] Arguments to replace in message (TODO)
     * @returns the language specific message with wildcards replaced by arguments
     */
    this.format = function(key) {
        return $$messages.hasOwnProperty(key) ? $$messages[key] : '!!' + key + '!!';
    };

    /**
     * Pattern contains expressions beginning with '$'
     * @param pattern
     */
    this.applyFormat = function(pattern) {
        // TODO Use a RegEx to replace al $algo.algo !!
        return angular.isString(pattern) && pattern.charAt(0) == '$' ? this.format(pattern.substr(1)) : pattern;
    }
});

/**
 * message filter - Convert a message key to proper language
 * @param {string} key The key of the message
 * @param {mixed} arg[] Arguments to replace in message (TODO)
 * @returns the language specific message with wildcards replaced by arguments
 */
applicationModule.filter('message', function($http, messageConverter) {
    return function(key) {
        return messageConverter.format(key);
    };
});

//
var MainController = function($scope) {
    $scope.currentCampaign = null;
    $scope.angularVersion = angular.version;

    $scope.$on('campaign.change', function(event, campaign) {
        $scope.currentCampaign = campaign;
    });

    $scope.$on('campaign.clear', function(event, campaign) {
        $scope.currentCampaign = null;
    });
}