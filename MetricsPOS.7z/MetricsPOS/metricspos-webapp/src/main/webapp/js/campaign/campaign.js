/**
 * Definitions for the Campaign entity
 * (Should be a module???)
 */

applicationModule.factory('CampaignModule', function($resource) {
    return $resource(DATA_BASE + '/campaigns/:campaignId/metrics/append');
});

applicationModule.factory('Campaigns', function($resource, $rootScope, CampaignModule, msMessageService) {

    var campaignRes = $resource(DATA_BASE + '/campaigns/:campaignId', { campaignId: '@id'},
        {
            'update': {method:'PUT'},
            'remove': {method:'DELETE'} ,
            'serviceCenters': {method:'GET', subPath: '/serviceCenters', isArray: true} ,
            'serviceCenter': {method:'GET', subPath: '/serviceCenters/:cuit'} ,
            'serviceCenterReport': {method:'GET', subPath: '/serviceCenters/export'} ,
            'serviceCenterReportRanking': {method:'GET', subPath: '/serviceCenters/exportRanking'} ,
            'serviceCenterPointsOfSale': {method:'GET', subPath: '/serviceCenters/:cuit/pointsOfSale', isArray: true} ,
            'pointsOfSale': {method:'GET', subPath: '/pointsOfSale', isArray: true} ,
            'serviceCenterDataLoad': {method:'POST', subPath: '/serviceCenters/load'} ,
            'pointOfSaleDataLoad': {method:'POST', subPath: '/pointsOfSale/load'}  ,
            'employeeDataLoad': {method:'POST', subPath: '/employees/load'},
            'serviceCenterSummary': {method:'GET', subPath: '/summary/:cuit'},
            'sendSummary': {method:'GET', subPath: '/summary/:cuit/send'},
            'sendAllSummaries': {method:'GET', subPath: '/summary/send'},
            'computeAllScores': {method:'GET', subPath: '/scores/compute'},
            'reloadAllTables': {method:'GET', subPath: '/tables/reload'}
        }
    );

    campaignRes.prototype.addModule = function(data, success, error) {
        return CampaignModule.save({campaignId: this.id}, data, success, error);
    };

    campaignRes.goTo = function(campaignId, withChildren, success, error) {
        if (angular.isFunction(withChildren)) {
            // withChildren parameter was omitted
            error = success;
            success = withChildren;
            withChildren = false;
        }

        return this.get({campaignId: campaignId, withChildren: withChildren || false }, function(campaign) {
            $rootScope.$broadcast('campaign.change', campaign);

            if (success) {
                success(campaign);
            }
        }, error);
    };

    campaignRes.clearCampaign = function() {
        $rootScope.$broadcast('campaign.clear');
    };

    return campaignRes;
});


//---------- Controllers
CampaignListController = function($scope, $http, $location, Campaigns, dialogs) {
    $scope.campaigns = Campaigns.query();

    Campaigns.clearCampaign();

    $scope.edit = function(campaign) {
        $location.path('/campaign/' + campaign.id + '/edit');
    }

    $scope.dataLoad = function(campaign) {
        $location.path('/campaign/' + campaign.id + '/dataLoad');
    }

    $scope.remove = function(campaign) {
        dialogs.confirm("Campaña " + campaign.name, "¿Desea eliminarla junto a todos sus datos (NO se puede deshacer)?", function() {
            dialogs.confirm({title: "Campaña " + campaign.name, message: "¿Desea cancelar la eliminación?", ok: "Sí", cancel: "No, elimínela", onCancel: function() {
                campaign.$remove(function() {
                    $scope.campaigns = Campaigns.query();
                });
            }});
        });
    }
};

CampaignController = function($scope, $http, $routeParams, $rootScope, $location, Campaigns, Metrics, Tables, dialogs, msMessageService, $q) {

    $scope.defaultTab = $location.path().indexOf("/campaign/" + $routeParams.campaignId + "/tables") >= 0 ? 1 : 0;

    $scope.campaigns = Campaigns.goTo($routeParams.campaignId, true, function(data, status) {

//        addMetricBehaviour(data, 1);
        $scope.campaign = data;
        $scope.status = status;
    });

    $scope.reportServiceCenters = function(){
        spinnerService.showSpinner();
        $.fileDownload(DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/serviceCenters/export', {
            successCallback: function (url) {
                spinnerService.hideSpinner();
            },
            failCallback: function (html, url) {
                spinnerService.hideSpinner();
            }
        });
    }

    $scope.enabledStyle = function(metric) {
        return  metric.enabled ? 'enabled' : 'disabled';
    };

    $scope.sendAllSummaries = function () {
        // REQUIREMENT (2597 - UC) -- SHELG:
        // Requirement 4: Add a a confirmation Modal Window(confirmation window)
        dialogs.confirm({title: "Enviar informes a CDS", message: "¿Esta seguro que desea enviar el reporte a todos los Centros de Servicio?", ok: "Sí", cancel: "No", onOk: function () {
            Campaigns.sendAllSummaries({campaignId: $routeParams.campaignId}, function () {
                msMessageService.showInfo('Se han enviado los resumenes por correo a los centros de servicio');
            });
        }});
    }

    $scope.exportRanking = function () {
        // REQUIREMENT (2597 - UC) -- SHELG:
        spinnerService.showSpinner();
        $.fileDownload(DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/serviceCenters/exportRanking', {
            successCallback: function (url) {
                spinnerService.hideSpinner();
            },
            failCallback: function (html, url) {
                spinnerService.hideSpinner();
            }
        });
    }

    $scope.computeAllScores = function() {
        Campaigns.computeAllScores({campaignId: $routeParams.campaignId}, function() {
            msMessageService.showInfo('Se han recalculado todos los scores de la campaña');
        });
    }

    $scope.reloadAllTables = function() {
        Campaigns.reloadAllTables({campaignId: $routeParams.campaignId}, function() {
            $scope.campaigns = Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
                $scope.campaign = data;
                $scope.status = status;
                msMessageService.showInfo('Se han recargado todas las tablas de la campaña');
            });
        });
    }


    $scope.toggleEnabled = function(metric) {
        var action = metric.enabled ? "disable" : "enable";
        Metrics[action]({campaignId:$routeParams.campaignId, id: metric.id}, function(updatedMetric) {
                // Updates new data
                metric.enabled = updatedMetric.enabled;
            }, function (error) {
                e = error;
            }
        ); // NOTE: id es body not params !!
    };

    /**
     * Ask for new metric and add to given campaign
     * @param campaign
     */
    $scope.newModule = function(campaign) {
        dialogs.prompt("Nuevo módulo", "Nombre:", '', function(name, maxPoints) {
            if (name) {
                var metric = { name: name, enabled: true };

                campaign.addModule(metric, function(result) {
                    if (campaign.metrics == null)
                        campaign.metrics = [];

                    campaign.metrics.push(result);
                });
            }
        });
    };

    $scope.newMetric = function(parent) {
        dialogs.prompt("Nueva métrica", "Nombre:", '', function(name) {
            if (name) {
                var metric = { name: name, enabled: true };

                Metrics.addMetric({campaignId: $scope.campaign.id, metricId: parent.id }, metric, function(metric) {
                    if (parent.metrics == null)
                        parent.metrics = [];

                    parent.metrics.push(metric);
                });
            }
        });

    };

    $scope.editModule = function(module){
        $location.path("/campaign/" + module.campaignId + "/module/" + module.id + "/edit");
    };

    $scope.editMetric = function(metric){
        $location.path("/campaign/" + metric.campaignId + "/metric/" + metric.id + "/edit");
    };

    $scope.editName = function(metric) {
        var name = dialogs.prompt("Metric/submetric ", "New name:", metric.name, function(name) {
            if (name && name != metric.name) {
                metric.name = name;
                Metrics.update(metric);
            }
        });
    };

    $scope.removeMetric = function(metric, parent) {
        dialogs.confirm("Métrica " + metric.name, "¿Desea eliminarla?", function() {
            var index = parent.metrics.indexOf(metric);

            if (index >= 0) {
                Metrics.remove({campaignId: metric.campaignId, metricId: metric.id}, function() {
                    parent.metrics.splice(index, 1);
                });
            }
        });
    };

    $scope.editSubmetric = function(metricToEdit) {
        $location.path("/campaign/" + metricToEdit.campaignId + "/submetric/" + metricToEdit.id + "/edit");
    };

    $scope.computeSubmetricScore = function(metric) {
        Metrics.compute({campaignId: metric.campaignId, id: metric.id}, function() {
            msMessageService.showInfo('Se han recalculado con éxito los puntajes de la submetrica ' + metric.name);
        });
    }

    $scope.viewSubmetricScore = function(metric) {
        $location.path("/campaign/" + metric.campaignId + "/metric/" + metric.id + "/scores");
    };

    $scope.viewAllMetricScore = function(campaign) {
        $location.path("/campaign/" + campaign.id + "/metric/scores");
    };

    $scope.removeTable = function(table) {
        dialogs.confirm("Tabla " + table.name, "¿Desea eliminarla junto a todos sus datos (NO se puede deshacer)?", function() {
            dialogs.confirm({title: "Tabla " + table.name, message: "¿Desea cancelar la eliminación?", ok: "Sí", cancel: "No, elimínela", onCancel: function() {
                Tables.remove({campaignId: $routeParams.campaignId, tableId : table.id}, function() {
                    $scope.campaigns = Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
                        $scope.campaign = data;
                        $scope.status = status;
                    });
                });
            }});
        });
    }

    $scope.checkSendMetric = function(metric, campaign) {
        this.processMetricsChain(metric.send, metric);
        this.verifyCampaignMetrics(campaign);
    }

    $scope.processMetricsChain = function(checkValue, metric) {
        metric.send = checkValue;
        Metrics.checkSendMetric(metric.campaignId, metric.id, metric.send);
        angular.forEach(metric.metrics, function(oneMetric) {
            $scope.processMetricsChain(checkValue, oneMetric);
        });
    }

    $scope.verifyCampaignMetrics = function(campaign) {
        angular.forEach(campaign.metrics, function(oneMetric) {
            $scope.verifyParentMetrics(oneMetric);
        });
    }

    $scope.verifyParentMetrics = function(metric) {
        var unCheckParent = true;
        var hasChildren = false;
        angular.forEach(metric.metrics, function(oneMetric) {
            hasChildren = true;
            if(oneMetric.send){
                unCheckParent = false;
            }
            $scope.verifyParentMetrics(oneMetric);
        });
        if (hasChildren && unCheckParent) {
            metric.send = false;
            Metrics.checkSendMetric(metric.campaignId, metric.id, metric.send);
        }
    }

};