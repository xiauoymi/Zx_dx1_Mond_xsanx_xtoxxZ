/**
 *
 * @param $scope
 * @param $http
 * @param $routeParams
 * @param $rootScope
 * @param $location
 */
var CampaignDataLoadController = function($scope, $http, $rootScope, $routeParams, $location, Campaigns, msMessageService) {

    $scope.refreshCodeMirror = function() {
        setTimeout(function() {
            var cm = $('#code-mirror1')[0].nextSibling.CodeMirror;
            cm.refresh();
            var cm2 = $('#code-mirror2')[0].nextSibling.CodeMirror;
            cm2.refresh();
        }, 500);
    };
    $scope.refreshCodeMirror2 = function() {
        setTimeout(function() {
            var cm = $('#code-mirror3')[0].nextSibling.CodeMirror;
            cm.refresh();
            var cm2 = $('#code-mirror4')[0].nextSibling.CodeMirror;
            cm2.refresh();
        }, 500);
    };
    $scope.refreshCodeMirror3 = function() {
        setTimeout(function() {
            var cm = $('#code-mirror5')[0].nextSibling.CodeMirror;
            cm.refresh();
            var cm2 = $('#code-mirror6')[0].nextSibling.CodeMirror;
            cm2.refresh();
        }, 500);
    };

    $scope.refreshCodeMirrorAll = function() {
        setTimeout(function() {
            var cm = $('#code-mirror1')[0].nextSibling.CodeMirror;
            cm.refresh();
            var cm2 = $('#code-mirror2')[0].nextSibling.CodeMirror;
            cm2.refresh();
            var cm3 = $('#code-mirror3')[0].nextSibling.CodeMirror;
            cm3.refresh();
            var cm4 = $('#code-mirror4')[0].nextSibling.CodeMirror;
            cm4.refresh();
            var cm5 = $('#code-mirror5')[0].nextSibling.CodeMirror;
            cm5.refresh();
            var cm6 = $('#code-mirror6')[0].nextSibling.CodeMirror;
            cm6.refresh();
        }, 500);
    };


    if ($routeParams.campaignId) {
        // Edit campaign
        Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
            $scope.campaign = data;
            $scope.refreshCodeMirrorAll()
        });

        $scope.save = function() {
            $scope.campaign.$update(function(campaign) {
                msMessageService.showInfo('Se han guardado los datos de la campaña');
            });

        };

        $scope.executeServiceCenterLoad = function() {
            $scope.campaign.$serviceCenterDataLoad(function(campaign) {
                msMessageService.showInfo('Se ejecuto el proceso de carga de centros de servicio');
            });
        };

        $scope.executePointOfSaleLoad = function() {
            $scope.campaign.$pointOfSaleDataLoad(function(campaign) {
                msMessageService.showInfo('Se ejecuto el proceso de carga de puntos de venta');
            });
        };

        $scope.executeEmployeeLoad = function() {
            $scope.campaign.$employeeDataLoad(function(campaign) {
                msMessageService.showInfo('Se ejecuto el proceso de carga de empleados');
            });
        };

    } else {
        $scope.campaign = { name: '', since: newDateFromNow(0), until: newDateFromNow(1)};

        $scope.save = function() {
            Campaigns.save($scope.campaign, function(campaign) {
                $location.path('/campaign/' + campaign.id);
            });
        };
    }


}