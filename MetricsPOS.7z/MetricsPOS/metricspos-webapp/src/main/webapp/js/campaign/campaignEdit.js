/**
 *
 * @param $scope
 * @param $http
 * @param $routeParams
 * @param $rootScope
 * @param $location
 */
var CampaignEditController = function($scope, $http, $rootScope, $routeParams, $location, Campaigns, $$dateService) {

    var campaignId = $routeParams.campaignId;

    if (campaignId) {
        // Edit campaign
        Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
            $scope.campaign = data;
        });

        $scope.save = function() {
            $scope.campaign.$update(function(campaign) {
                $location.path('/campaign/' + campaign.id);
            });

        };

    } else {
        $scope.campaign = { name: '', since: newDateFromNow(0), until: newDateFromNow(1)};

        $scope.save = function() {
            Campaigns.save($scope.campaign, function(campaign) {
                $location.path('/campaign/' + campaign.id);
            });
        };
    }

    function isPeriodOk(since, until) {
        if (! since || ! until) {
            return false;
        }
        var dSince = since instanceof Date ? since : $$dateService.jsonStringToDate(since);
        var dUntil = until instanceof Date ? until : $$dateService.jsonStringToDate(until);

        return dSince.getTime() < dUntil.getTime();
    }

    $scope.isValidPeriod = function() {
        return $scope.campaign && isPeriodOk($scope.campaign.since, $scope.campaign.until);
    }

    $scope.cancel = function() {
        $location.path('/campaign/list');
    }
}

//CampaignEditController.$inject = ['$scope', '$http', '$routeParams', '$location', 'Campaigns', '$$dateService'];
