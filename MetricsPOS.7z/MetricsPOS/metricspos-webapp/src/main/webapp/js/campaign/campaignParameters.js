/**
 * Logic for viewing campaign parameters
 */
var CampaignParametersController = function($scope, $http, $rootScope, $location, $routeParams, Campaigns) {
    Campaigns.clearCampaign();

    $scope.columnModel = getColumnModel();
    $scope.columnNames = getColumnNames();

    $scope.jqGridParametersOptions = {
        datatype: 'json',
        mtype: 'GET',
        url: DATA_BASE + '/campaigns/parameters',
        ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
        colNames: $scope.columnNames,
        colModel: $scope.columnModel,
        multiselect: false,
        width: ($(window).width() - 420),
        height:'80%',
        viewrecords: true,
        pager: '#gridpager',
        rowNum: 25, // number of rows per page.
        jsonReader : {
            root:"content", // json element which contains the data.
            page: "number",  // number of page
            total: "totalPages", // total number of pages
            records: "totalElements",  // total number of rows.
            repeatitems: false,
            id: "id"
        },
        loadComplete : function (data) {
            $scope.jsonData = data;
        },
        loadError: function(xhr, status, error) {
            var e = error;
        },
        onSelectRow: function(id, status, e) {
        }
    };

    $scope.accordionOptions = { autoHeight: false, collapsible: true, active: 2, clearStyle: false };

    $scope.grid = function() {
        if (! this.theGrid) {
            this.theGrid = angular.element('#paramsTable');
        }
        return this.theGrid;
    };

    $scope.hideShow = function(column) {
        this.grid().jqGrid((column.hidden ? 'hideCol' : 'showCol'), column.name);
    };

    $scope.initToolbars = function() {
        this.grid().jqGrid('navGrid', '#gridpager', {add:false, edit:true, del:false, search:false},
             /* edit options*/
            {
                mtype: 'PUT',
                closeAfterEdit: true
            },
            {},
            {}
        );

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Mostrar/Ocultar busqueda", title:"Mostrar/Ocultar busqueda", buttonicon :'ui-icon-pin-s',
                onClickButton:function() {
                    $scope.grid()[0].toggleToolbar();
                }
            });

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Limpiar", title:"Limpiar filtro de busqueda", buttonicon :'ui-icon-refresh',
                onClickButton:function() {
                    $scope.grid()[0].clearToolbar();
                    //clearCustomSearchColumns();
                }
            });

        this.grid().jqGrid('filterToolbar', { searchOnEnter: true});
        $scope.grid()[0].toggleToolbar();


        $.extend($.jgrid.edit, {
            datatype: 'json',
            width: 600,
            url : DATA_BASE + '/campaigns/parameters/edit',
            ajaxEditOptions: { contentType: "application/json" },
            serializeEditData: function(postData) {
                var json;
                if (postData.oper == "edit" ){
                    // edit
                    var data = new Object();
                    data.id = postData.id;
                    data.value = postData.value;
                    data.name = postData.name;
                    data.description = postData.description;
                    json = JSON.stringify(data);
                }
                return json;
            }
        });
    };


    function getColumnModel() {
        return [
            {name:'id', label: 'ID', width:20, align: 'center', search: false, key: true},
            {name:'name', label: 'Nombre', width:200, align: 'center', search: true, editable: true},
            {name:'value', label: 'Valor', width:150, align: 'left', search: true, edittype:'textarea', editable: true, editoptions: {rows:'4',cols:'70'}},
            {name:'description', label: 'Descripcion', width:200, align: 'right', edittype:'textarea', editable: true, editoptions: {rows:'4',cols:'70'}}
        ];
    }

    function getColumnNames() {
        return ['ID', 'Nombre', 'Valor', 'Descripci&oacute;n'];
    }

}
