/**
 * Logic for viewing service centers
 */
var CampaignPointsOfSaleController = function($scope, $http, $location, $routeParams, Campaigns) {
    var campaignId = $routeParams.campaignId;

    if (campaignId) {
        Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
            $scope.campaign = data;
        });
        $scope.serviceCenters = Campaigns.serviceCenters({campaignId: $routeParams.campaignId}, function(serviceCenters) {
            $scope.serviceCenters = serviceCenters;
            $scope.pointsOfSale = Campaigns.pointsOfSale({campaignId: $routeParams.campaignId}, function(pointsOfSale) {
                $scope.pointsOfSale = pointsOfSale;
                $scope.columnModel = getColumnModel();
                $scope.columnNames = getColumnNames();

                $scope.jqGridScoreOptions = {
                    datatype: 'json',
                    mtype: 'GET',
                    url: DATA_BASE + '/campaigns/' + campaignId + '/pointsOfSale/grid',
                    ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
                    colNames: $scope.columnNames,
                    colModel: $scope.columnModel,
                    multiselect: false,
                    width: ($(window).width() - 420),
                    height:'80%',
                    viewrecords: true,
                    pager: '#gridpager',
                    rowNum: 25, // number of rows per page.
                    jsonReader : {
                        root:"content", // json element which contains the data.
                        page: "number",  // number of page
                        total: "totalPages", // total number of pages
                        records: "totalElements",  // total number of rows.
                        repeatitems: false,
                        id: "mpsInternalId"
                    },
                    loadComplete : function (data) {
                        $scope.jsonData = data;
                    },
                    loadError: function(xhr, status, error) {
                        var e = error;
                    },
                    onSelectRow: function(id, status, e) {
                    }
                };
            });

        });
    }

    $scope.accordionOptions = { autoHeight: false, collapsible: true, active: 2, clearStyle: false };

    $scope.grid = function() {
        if (! this.theGrid) {
            this.theGrid = angular.element('#pointsOfSaleTable');
        }
        return this.theGrid;
    };

    $scope.hideShow = function(column) {
        this.grid().jqGrid((column.hidden ? 'hideCol' : 'showCol'), column.name);
    };

    $scope.initToolbars = function() {
        this.grid().jqGrid('navGrid', '#gridpager', {add:false, edit:false, del:false, search:false},
            {},
            {},
            {}
        );

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Mostrar/Ocultar busqueda", title:"Mostrar/Ocultar busqueda", buttonicon :'ui-icon-pin-s',
                onClickButton:function() {
                    $scope.grid()[0].toggleToolbar();
                }
            });

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Limpiar", title:"Limpiar filtro de busqueda", buttonicon :'ui-icon-refresh',
                onClickButton:function() {
                    $scope.grid()[0].clearToolbar();
                    //clearCustomSearchColumns();
                }
            });

        this.grid().jqGrid('filterToolbar', { searchOnEnter: true});
        $scope.grid()[0].toggleToolbar();
    };


    function getColumnModel() {
        var defaultOption = "---";
        var oName = new Object();
        var searchValuesName = new Object();
        searchValuesName[''] = defaultOption;

        for (var j = 0; j < $scope.serviceCenters.length; j++) {
            oName[$scope.serviceCenters[j].cuit] = $scope.serviceCenters[j].name;
            searchValuesName[$scope.serviceCenters[j].cuit] = $scope.serviceCenters[j].name;
        }

        return [
            {name:'idSap',          label: 'Id Sap',                jsonmap: 'idSap',width:50, align: 'center', search: true},
            {name:'salesGroup',     label: 'Sales Group',           jsonmap: 'salesGroup',width:50, align: 'center', search: true},
            {name:'region',         label: 'Region',                jsonmap: 'region',width:50, align: 'center', search: true},
            {name:'type',           label: 'Type',                  jsonmap: 'type',width:50, align: 'center', search: true},
            {name:'tsrcId',         label: 'Id del Representante',  jsonmap: 'tsrcId',width:50, align: 'center', search: true},
            {name:'customer',       label: 'Customer',              jsonmap: 'customer',width:50, align: 'center', search: true},
            {name:'locality',       label: 'Locality',              jsonmap: 'locality',width:50, align: 'center', search: true},
            {name:'county',         label: 'County',                jsonmap: 'county',width:50, align: 'center', search: true},
            {name:'state',          label: 'State',                 jsonmap: 'state',width:50, align: 'center', search: true},
            {name:'address',        label: 'Address',               jsonmap: 'address',width:50, align: 'center', search: true},
            {name:'phone',          label: 'Phone',                 jsonmap: 'phone',width:50, align: 'center', search: true},
            {name:'mail',           label: 'Mail',                  jsonmap: 'mail',width:50, align: 'center', search: true},
            {name:'serviceCenter',  label: 'Centro de Servicio',    jsonmap: 'serviceCenter',width:50, align: 'center', search: true, searchoptions: { value: searchValuesName,
                dataInit:function(el) {
                    var defOption = $("option:contains(" + defaultOption + ")", el);
                    defOption.attr("selected", "selected");
                }}, stype: 'select', editoptions: {value: oName}}
        ];
    }

    function getColumnNames() {
        return ['Id Sap', 'Sales Group', 'Region', 'Type', 'Id del Representante', 'Customer', 'Locality', 'County', 'State', 'Address', 'Phone', 'Mail', 'Centro de Servicio'  ];
    }
}
