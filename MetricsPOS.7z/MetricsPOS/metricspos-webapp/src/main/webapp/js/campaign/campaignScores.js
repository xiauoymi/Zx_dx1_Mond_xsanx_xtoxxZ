/**
 * Logic for viewing all scores of a campaign
 */
var CampaignScoresController = function($scope, $http, $location, $routeParams, Metrics, Campaigns) {
    var campaignId = $routeParams.campaignId;

    if (campaignId) {
        $scope.serviceCenters = Campaigns.serviceCenters({campaignId: campaignId}, function(serviceCenters) {
            $scope.serviceCenters = serviceCenters;
            Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
                $scope.campaign = data;
            });
            $scope.columnModel = getColumnModel();
            $scope.columnNames = getColumnNames();

            $scope.jqGridScoreOptions = {
                datatype: 'json',
                mtype: 'GET',
                url: DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/metrics/scores',
                ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
                colNames: $scope.columnNames,
                colModel: $scope.columnModel,
                multiselect: false,
                width: ($(window).width() - 300),
                height:'80%',
                viewrecords: true,
                pager: '#gridpager',
                rowNum: 25, // number of rows per page.
                jsonReader : {
                    root:"content", // json element which contains the data.
                    page: "number",  // number of page
                    total: "totalPages", // total number of pages
                    records: "totalElements",  // total number of rows.
                    repeatitems: false,
                    id: "mpsInternalId"
                },
                loadComplete : function (data) {
                    $scope.jsonData = data;
                },
                loadError: function(xhr, status, error) {
                    var e = error;
                },
                onSelectRow: function(id, status, e) {
                }
            };
        });
    }

    $scope.accordionOptions = { autoHeight: false, collapsible: true, active: 2, clearStyle: false };

    $scope.exportUrl = DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/metrics/scores/export';

    $scope.grid = function() {
        if (! this.theGrid) {
            this.theGrid = angular.element('#scoresTable');
        }
        return this.theGrid;
    };

    $scope.hideShow = function(column) {
        this.grid().jqGrid((column.hidden ? 'hideCol' : 'showCol'), column.name);
    };

    $scope.initToolbars = function() {
        this.grid().jqGrid('navGrid', '#gridpager', {add:false, edit:false, del:false, search:false},
            {},
            {},
            {}
        );

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Mostrar/Ocultar busqueda", title:"Mostrar/Ocultar busqueda", buttonicon :'ui-icon-pin-s',
                onClickButton:function() {
                    $scope.grid()[0].toggleToolbar();
                }
            });

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Limpiar", title:"Limpiar filtro de busqueda", buttonicon :'ui-icon-refresh',
                onClickButton:function() {
                    $scope.grid()[0].clearToolbar();
                    //clearCustomSearchColumns();
                }
            });


        // add custom button to export the data to excel
        this.grid().jqGrid('navButtonAdd', '#gridpager', {
            caption:"Exportar a Excel",
            onClickButton : function () {
                exportToExcel();
            }
        });

        this.grid().jqGrid('filterToolbar', { searchOnEnter: true});
        $scope.grid()[0].toggleToolbar();
    };


    function getColumnModel() {
        var defaultOption = "---";
        var o = new Object();
        var searchValues = new Object();
        searchValues[''] = defaultOption;

        for (var j = 0; j < $scope.serviceCenters.length; j++) {
            o[$scope.serviceCenters[j].cuit] = $scope.serviceCenters[j].name;
            searchValues[$scope.serviceCenters[j].cuit] = $scope.serviceCenters[j].name;
        }

        initDate = function (elem) {
            $(elem).datepicker({
                dateFormat: 'dd-mm-yy',
                autoSize: true,
                changeYear: true,
                changeMonth: true,
                showButtonPanel: true,
                showWeek: false
            });
            $('.ui-datepicker').css({'font-size':'75%'});
            $('.ui-datepicker').css({'z-index':'1000'});
        };

        dateTemplate = {width: 80, align: 'center', sorttype: 'date', srcformat: 'yy-mm-dd',
            newformat: 'dd-mm-yy', editoptions: { dataInit: initDate }};


        return [
            {name:'module', label: 'Modulo', jsonmap: 'module.name',width:40, align: 'center', search: true},
            {name:'metric', label: 'Metrica', jsonmap: 'metric.name',width:40, align: 'center', search: true},
            {name:'submetric', label: 'Submetrica', jsonmap: 'submetric.name',width:40, align: 'center', search: true},
            {name:'cuit', label: 'CUIT', jsonmap: 'serviceCenter.cuit',width:40, align: 'center', search: true},
            {name:'serviceCenter', label: 'Centro de Servicio', jsonmap: 'serviceCenter.name',width:100, align: 'center', searchoptions: { value: searchValues,
                dataInit:function(el) {
                    var defOption = $("option:contains(" + defaultOption + ")", el);
                    defOption.attr("selected", "selected");
                }}, stype: 'select', editoptions: {value: o}},
            {name:'points', label: 'Puntaje', width:30, align: 'right', formatter: 'integer', formatoptions: {defaultValue: 'N/A'}},
            {name:'penalty', label: 'Penalidades', width:30, align: 'right', formatter: 'number', formatoptions: {defaultValue: 'N/A'}},
            {name:'penaltyFactor', label: 'Factor de penalidad', width:30, align: 'right', formatter: 'number', formatoptions: {decimalPlaces: 2, defaultValue: 'N/A'}},
            {name:'noData', label: 'Sin datos', width:20, align: 'center', formatter: 'checkbox',  formatoptions: {disabled: true}, editoptions: {value:"true:false"}, searchoptions: {value: {'':'---','true':'Si','false':'No'}}, stype: 'select'},
            {name:'dirty', label: 'Recalcular', width:20, align: 'center', formatter: 'checkbox',  formatoptions: {disabled: true}, editoptions: {value:"true:false"}, searchoptions: {value: {'':'---','true':'Si','false':'No'}}, stype: 'select'},
            {name:'lastUpdated', label: 'Ultima actualizaci�n', width:50, align: 'center', formatter: 'date', template: dateTemplate, editrules: {date:false, searchoptions: { dataInit: initDate }}, searchoptions: { dataInit: initDate }}

        ];
    }

    function getColumnNames() {
        return ['M&oacute;dulo', 'M&eacute;trica', 'Subm&eacute;trica', 'CUIT', 'Centro de Servicio', 'Puntaje', 'Penalidades', 'Factor de penalidad', 'Sin datos', 'Recalcular', 'Ultima actualizaci&oacute;n'];
    }

    function exportToExcel() {
        $scope.grid().jqGrid('excelExport', {url: $scope.exportUrl});
    }

}
