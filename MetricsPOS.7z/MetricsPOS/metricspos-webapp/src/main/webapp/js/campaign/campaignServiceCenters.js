/**
 * Logic for viewing service centers
 */
var CampaignServiceCentersController = function($scope, $http, $location, $routeParams, Campaigns) {
    var campaignId = $routeParams.campaignId;

    if (campaignId) {
        Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
            $scope.campaign = data;
        });
        // Edit ser
        $scope.serviceCenters = Campaigns.serviceCenters({campaignId: $routeParams.campaignId}, function(serviceCenters) {
            $scope.serviceCenters = serviceCenters;
            $scope.columnModel = getColumnModel();
            $scope.columnNames = getColumnNames();

            $scope.jqGridScoreOptions = {
                datatype: 'json',
                mtype: 'GET',
                url: DATA_BASE + '/campaigns/' + campaignId + '/serviceCenters/grid',
                ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
                colNames: $scope.columnNames,
                colModel: $scope.columnModel,
                multiselect: false,
                width: ($(window).width() - 420),
                height:'80%',
                viewrecords: true,
                pager: '#gridpager',
                rowNum: 25, // number of rows per page.
                jsonReader : {
                    root:"content", // json element which contains the data.
                    page: "number",  // number of page
                    total: "totalPages", // total number of pages
                    records: "totalElements",  // total number of rows.
                    repeatitems: false,
                    id: "mpsInternalId"
                },
                loadComplete : function (data) {
                    $scope.jsonData = data;
                },
                loadError: function(xhr, status, error) {
                    var e = error;
                },
                onSelectRow: function(id, status, e) {
                }
            };
        });

    }

    $scope.accordionOptions = { autoHeight: false, collapsible: true, active: 2, clearStyle: false };

    $scope.grid = function() {
        if (! this.theGrid) {
            this.theGrid = angular.element('#serviceCentersTable');
        }
        return this.theGrid;
    };

    $scope.hideShow = function(column) {
        this.grid().jqGrid((column.hidden ? 'hideCol' : 'showCol'), column.name);
    };

    $scope.initToolbars = function() {
        this.grid().jqGrid('navGrid', '#gridpager', {add:false, edit:false, del:false, search:false},
            {},
            {},
            {}
        );

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Mostrar/Ocultar busqueda", title:"Mostrar/Ocultar busqueda", buttonicon :'ui-icon-pin-s',
                onClickButton:function() {
                    $scope.grid()[0].toggleToolbar();
                }
            });

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Limpiar", title:"Limpiar filtro de busqueda", buttonicon :'ui-icon-refresh',
                onClickButton:function() {
                    $scope.grid()[0].clearToolbar();
                    //clearCustomSearchColumns();
                }
            });

        this.grid().jqGrid('filterToolbar', { searchOnEnter: true});
        $scope.grid()[0].toggleToolbar();
    };


    function getColumnModel() {
        var defaultOption = "---";
        var oName = new Object();
        var searchValuesName = new Object();
        searchValuesName[''] = defaultOption;

        for (var j = 0; j < $scope.serviceCenters.length; j++) {
            oName[$scope.serviceCenters[j].name] = $scope.serviceCenters[j].name;
            searchValuesName[$scope.serviceCenters[j].name] = $scope.serviceCenters[j].name;
        }

        var defaultOption = "---";
        var oCuit = new Object();
        var searchValuesCuit = new Object();
        searchValuesCuit[''] = defaultOption;

        for (var j = 0; j < $scope.serviceCenters.length; j++) {
            oCuit[$scope.serviceCenters[j].cuit] = $scope.serviceCenters[j].cuit;
            searchValuesCuit[$scope.serviceCenters[j].cuit] = $scope.serviceCenters[j].cuit;
        }

        initDate = function (elem) {
            $(elem).datepicker({
                dateFormat: 'dd-mm-yy',
                autoSize: true,
                changeYear: true,
                changeMonth: true,
                showButtonPanel: true,
                showWeek: false
            });
            $('.ui-datepicker').css({'font-size':'75%'});
            $('.ui-datepicker').css({'z-index':'1000'});
        };

        dateTemplate = {width: 80, align: 'center', sorttype: 'date', srcformat: 'yy-mm-dd',
            newformat: 'dd-mm-yy', editoptions: { dataInit: initDate }};

        return [
            {name:'cuit', label: 'CUIT', jsonmap: 'cuit',width:50, align: 'center', search: true, searchoptions: { value: searchValuesCuit,
                dataInit:function(el) {
                    var defOption = $("option:contains(" + defaultOption + ")", el);
                    defOption.attr("selected", "selected");
                }}, stype: 'select', editoptions: {value: oCuit}},
            {name:'name', label: 'Nombre', jsonmap: 'name',width:50, align: 'center', search: true, searchoptions: { value: searchValuesName,
                dataInit:function(el) {
                    var defOption = $("option:contains(" + defaultOption + ")", el);
                    defOption.attr("selected", "selected");
                }}, stype: 'select', editoptions: {value: oName}},
            {name:'mail', label: 'Mail', jsonmap: 'mail',width:50, align: 'center', search: true},
            {name:'Acciones', label: 'Acciones', width:50, formatter: actionFormatter},
            {name:'lastTimeSent', label: 'Ultima fecha de envio', width:50, formatter:'date', formatoptions: {srcformat: 'Y-m-d H:i:s', newformat: 'd-m-Y H:i:s'}}
        ];
    }

    function getColumnNames() {
        return ['CUIT', 'Nombre', 'Mail', 'Acciones', 'Ultima fecha de envio'];
    }

    function actionFormatter(cellvalue, options, rowObject) {
        return "<a style='text-decoration:underline;' href='" + "#/campaign/" + rowObject.campaign + "/serviceCenter/" + rowObject.cuit + "/summary'>Summary</a>";
    }
}
