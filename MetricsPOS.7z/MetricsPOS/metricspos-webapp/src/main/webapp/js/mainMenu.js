/**
 *
 */







var MainMenuCtrl = ['$scope', '$http', function($scope, $http) {
	 $http.get('data/mainMenu2.json').success(function(data) {
		 $scope.node = { items: data };
	 });
}];
