/**
 * Metric logic
 */

applicationModule.factory('MetricsMetrics', function($resource) {
    return $resource(DATA_BASE + '/campaigns/:campaignId/metrics/:metricId/append');
});

applicationModule.factory('Metrics', function($resource, MetricsMetrics) {
    var metricRes = $resource(DATA_BASE + '/campaigns/:campaignId/metrics/:metricId', { campaignId: '@campaignId', metricId: '@id'},
        { 'internalUpdate': {method:'PUT'}
            , 'remove': {method:'DELETE'}
            , 'enable' : {method: 'PUT', subPath: '/enable'}
            , 'disable' : {method: 'PUT', subPath: '/disable'}
            , 'saveAndCompute' : {method: 'PUT', subPath: '/saveAndCompute'}
            , 'compute' : {method: 'PUT', subPath: '/compute'}
            , 'scores' : {method: 'GET', subPath: '/scores'}
            , 'checkSend': {method:'GET', subPath: '/checkSend/:sendValue'}
        }
    );

    /**
     * This method does the update without parent, nor children metrics.
     * @param metric    The metric to update
     * @param success   Callback to execute in case of success
     * @param error     Callback to execute in case of failure
     */
    metricRes.update = function(metric, success, error) {
        var toUpdate = angular.extend({}, metric);
        delete toUpdate.parent;
        delete toUpdate.metrics;

        return this.internalUpdate({}, toUpdate, success, error);
    };

    metricRes.addMetric = function(params, data, success, error) {
        return MetricsMetrics.save(params, data, success, error);
    };

    metricRes.prototype.addMetric = function(data, success, error) {
        return MetricsMetrics.save({campaignId: this.campaignId, metricId: this.id}, data, success, error);
    };

    metricRes.checkSendMetric = function(campaignId, metricId, sendValue){
        return this.checkSend({campaignId: campaignId, metricId: metricId, sendValue: sendValue});
    }

    return metricRes;
});

function Submetric_submetricsCount() {
    return 1;
}

function Metric_height() {
    var count = this.submetricsCount();

    return count == 0 ? 1 : count;
}

function Metric_submetricsCount() {
    var n = 0;
    if (this.metrics) {
        $.each(this.metrics, function(index, metric) {
            n += metric.submetricsCount();
        });
    }

    return n;
}


function addMetricBehaviour(metric, parent, level) {

    metric.level = level;
    metric.parent = parent;

    metric.submetricsCount = level <= 2 ? Metric_submetricsCount : Submetric_submetricsCount;
    metric.height = Metric_height;

    level = level + 1;
    if (metric.metrics) {
        parent = metric;
        $.each(metric.metrics, function(index, metric) {
            addMetricBehaviour(metric, parent, level);
        });
    } else {
        metric.metrics = [];
    }

}