/**
 *
 */
var MetricEditController = function($scope, $http, $location, $routeParams, Metrics, Campaigns, msMessageService) {
    var metricId = $routeParams.metricId;
    $scope.accordionOptions = { autoHeight: false, collapsible: true, active: 2, clearStyle: false };

    $scope.typeOptions = [{name: 'BASE', value: 0 }, { name: 'DIFERENCIADORA', value: 1 }];


    if (metricId) {
        // Edit metric
        $scope.metric = Metrics.get({campaignId: $routeParams.campaignId, metricId: $routeParams.metricId}, function(metric) {
            Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
                $scope.campaign = data;
            });
        });

    } else {
        // New metric
        $scope.metric = { name: 'NEW METRIC', enabled: true, campaignId: $scope.$eval('currentCampaign.id')};
    }

    $scope.getCampaignId = function() {
        return $scope.metric.campaign ? $scope.metric.campaign.id : $scope.$eval('currentCampaign.id');
    };

    $scope.save = function() {
        Metrics.update($scope.metric, function() {
            msMessageService.showInfo('Se han guardado con éxito los cambios');
        })
    };

    $scope.cancel = function() {
        $location.path('/campaign/' + $scope.getCampaignId());
    }

    $scope.saveAndComputeScore = function() {

        spinnerService.showSpinner();

        Metrics.saveAndCompute($scope.metric, function() {
            spinnerService.hideSpinner();
            $location.path('/campaign/' + $routeParams.campaignId + '/metric/' + $routeParams.metricId + '/scores');
        });
    }

    $scope.isUsed = function(table) {
        for (var i = 0; i < $scope.metric.tables.length; i++) {
            if ($scope.metric.tables[i].id == table.id) {
                return true
            }
        }

        return false;
    }

    $scope.addTable = function(table) {
        $scope.metric.tables.push(table);
    }

    $scope.removeTable = function(table) {
        var index = -1;
        for (var i = 0; i < $scope.metric.tables.length; i++) {
            if ($scope.metric.tables[i].id == table.id) {
                index = i;
            }
        }

        $scope.metric.tables.splice(index, 1);
    }
};
