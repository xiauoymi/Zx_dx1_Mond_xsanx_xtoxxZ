/**
 * Logic for viewing metric scores
 */
var MetricScoresController = function($scope, $http, $location, $routeParams, Metrics, Campaigns) {
    var metricId = $routeParams.metricId;

    if (metricId) {
        // Edit metric
        $scope.metric = Metrics.get({campaignId: $routeParams.campaignId, metricId: $routeParams.metricId}, function(metric) {
            $scope.serviceCenters = Campaigns.serviceCenters({campaignId: metric.campaignId}, function(serviceCenters) {
                $scope.serviceCenters = serviceCenters;
                Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
                    $scope.campaign = data;
                });
                $scope.columnModel = getColumnModel();
                $scope.columnNames = getColumnNames();

                $scope.jqGridScoreOptions = {
                    datatype: 'json',
                    mtype: 'GET',
                    url: DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/metrics/' + metricId + '/scores',
                    ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
                    colNames: $scope.columnNames,
                    colModel: $scope.columnModel,
                    multiselect: false,
                    width: ($(window).width() - 420),
                    height:'80%',
                    viewrecords: true,
                    pager: '#gridpager',
                    rowNum: 25, // number of rows per page.
                    jsonReader : {
                        root:"content", // json element which contains the data.
                        page: "number",  // number of page
                        total: "totalPages", // total number of pages
                        records: "totalElements",  // total number of rows.
                        repeatitems: false,
                        id: "mpsInternalId"
                    },
                    loadComplete : function (data) {
                        $scope.jsonData = data;
                    },
                    loadError: function(xhr, status, error) {
                        var e = error;
                    },
                    onSelectRow: function(id, status, e) {
                    }
                };
            });

        });
    }

    $scope.accordionOptions = { autoHeight: false, collapsible: true, active: 2, clearStyle: false };

    $scope.grid = function() {
        if (! this.theGrid) {
            this.theGrid = angular.element('#scoresTable');
        }
        return this.theGrid;
    };

    $scope.hideShow = function(column) {
        this.grid().jqGrid((column.hidden ? 'hideCol' : 'showCol'), column.name);
    };

    $scope.initToolbars = function() {
        this.grid().jqGrid('navGrid', '#gridpager', {add:false, edit:false, del:false, search:false},
            {},
            {},
            {}
        );

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Mostrar/Ocultar busqueda", title:"Mostrar/Ocultar busqueda", buttonicon :'ui-icon-pin-s',
                onClickButton:function() {
                    $scope.grid()[0].toggleToolbar();
                }
            });

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Limpiar", title:"Limpiar filtro de busqueda", buttonicon :'ui-icon-refresh',
                onClickButton:function() {
                    $scope.grid()[0].clearToolbar();
                    //clearCustomSearchColumns();
                }
            });

        this.grid().jqGrid('filterToolbar', { searchOnEnter: true});
        $scope.grid()[0].toggleToolbar();
    };


    function getColumnModel() {
        var defaultOption = "---";
        var o = new Object();
        var searchValues = new Object();
        searchValues[''] = defaultOption;

        for (var j = 0; j < $scope.serviceCenters.length; j++) {
            o[$scope.serviceCenters[j].cuit] = $scope.serviceCenters[j].name;
            searchValues[$scope.serviceCenters[j].cuit] = $scope.serviceCenters[j].name;
        }

        initDate = function (elem) {
            $(elem).datepicker({
                dateFormat: 'dd-mm-yy',
                autoSize: true,
                changeYear: true,
                changeMonth: true,
                showButtonPanel: true,
                showWeek: false
            });
            $('.ui-datepicker').css({'font-size':'75%'});
            $('.ui-datepicker').css({'z-index':'1000'});
        };

        dateTemplate = {width: 80, align: 'center', sorttype: 'date', srcformat: 'yy-mm-dd',
            newformat: 'dd-mm-yy', editoptions: { dataInit: initDate }};


        return [
            {name:'cuit', label: 'CUIT', jsonmap: 'serviceCenter.cuit',width:40, align: 'center', search: false},
            {name:'serviceCenter', label: 'Centro de Servicio', jsonmap: 'serviceCenter.name',width:100, align: 'center', searchoptions: { value: searchValues,
                dataInit:function(el) {
                    var defOption = $("option:contains(" + defaultOption + ")", el);
                    defOption.attr("selected", "selected");
                }}, stype: 'select', editoptions: {value: o}},
            {name:'points', label: 'Puntaje', width:30, align: 'right', formatter: 'integer', formatoptions: {defaultValue: 'N/A'}},
            {name:'penalty', label: 'Penalidades', width:30, align: 'right', formatter: 'number', formatoptions: {defaultValue: 'N/A'}},
            {name:'penaltyFactor', label: 'Factor de penalidad', width:30, align: 'right', formatter: 'number', formatoptions: {decimalPlaces: 2, defaultValue: 'N/A'}},
            {name:'noData', label: 'Sin datos', width:20, align: 'center', formatter: 'checkbox',  formatoptions: {disabled: true}, editoptions: {value:"true:false"}, searchoptions: {value: {'':'---','true':'Si','false':'No'}}, stype: 'select'},
            {name:'dirty', label: 'Recalcular', width:20, align: 'center', formatter: 'checkbox',  formatoptions: {disabled: true}, editoptions: {value:"true:false"}, searchoptions: {value: {'':'---','true':'Si','false':'No'}}, stype: 'select'},
            {name:'lastUpdated', label: 'Última actualización', width:50, align: 'center', formatter: 'date', template: dateTemplate, editrules: {date:false, searchoptions: { dataInit: initDate }}, searchoptions: { dataInit: initDate }}

        ];
    }

    function getColumnNames() {
        return ['CUIT', 'Centro de Servicio', 'Puntaje', 'Penalidades', 'Factor de penalidad', 'Sin datos', 'Recalcular', 'Última actualización'];
    }

}
