/**
 *  Service offering custom dialogs for common operations
 */
// Popup
// (@see http://jsfiddle.net/jamey777/tJSPt/)
//  Service returns constructor function. Factory returns object already constructed
//

/**
 * dialogs service, provides services to intercat with user through modal dialogs.
 */
applicationModule.service('dialogs', function(messageConverter) {
    /**
     * Ask the user for confirmation
     * @param {string | object } title  The title of the dialog. If it is an object, the value is used as a
     *                                  configuration object, its properties are used for function parameters:
     *                                  title, message, scope, ok (first button label), cancel (second button label),
     *                                  onOk, onCancel
     * @param {String} message      The question to ask
     * @param {Scope} $scope        An scope to execute the functions onOk and onCancel. It could be skipped
     * @param {function} onOk       A function to execute if user press first button (Ok)
     * @param {function} onCancel   A function to execute if user press second button (Cancel)
     */
    this.confirm = function( title, message, $scope, onOk, onCancel ) {
        var options;
        if ( angular.isObject( title ) ) {
            options = title;
        } else {
            if ( angular.isFunction($scope) ) {
                // Scope argument not provided
                onCancel = onOk;
                onOk = $scope;
                $scope = null;
            }

            options = { title: title, message: message, scope: $scope, onOk: onOk, onCancel: onCancel };
        }


        var buttons = {};

        buttons[options.ok || 'Ok'] = function() {
            if (angular.isFunction(options.onOk) ) {
                if ( options.scope ) {
                    options.scope.$apply( options.onOk );
                } else {
                    options.onOk();
                }
            }
            $( this ).dialog( "close" );
        };

        buttons[options.cancel || 'Cancel'] = function() {
            if (angular.isFunction(options.onCancel) ) {
                if ( options.scope ) {
                    options.scope.$apply( options.onCancel );
                } else {
                    options.onCancel();
                }
            }
            $( this ).dialog( "close" );
        };

        var $dlg = $('<div id="dlg-confirm" title="' + messageConverter.applyFormat(options.title || 'Confirm') + '">' + messageConverter.applyFormat(options.message || '?') + '</div>');

        $dlg.dialog({
            minHeight: 200,
            width: 350,
            modal: true,
            resizable: false,
            show: "fade",
            hide: "fade",
            buttons: buttons,
            close: function() {
                $( this ).remove();
            }
        });
    };

    /**
     * Prompts the user for a value in a modal popup window
     * @param title
     * @param message
     * @param value
     * @param callback  function to call with the input value. Only call if press "ok"
     */
    this.prompt= function( title, message, value, callback ) {
        if ( ! value ) {
            value = '';
        }

        var $dlg = $('<div id="dlg-prompt" title="' + messageConverter.applyFormat(title) + '">'
            + '<form><label for="value">' + messageConverter.applyFormat(message) + '</label>'
            + '<input type="text" name="value" id="dlg-prompt-value" class="text ui-widget-content ui-corner-all" value="' + value + '"/>'
            + '</form></div>');

        $dlg.children().submit(function(){
            $dlg.parent().find('.ui-dialog-buttonpane button:first').click();
            return false;
        });

        $dlg.dialog({
            minHeight: 200,
            width: 350,
            modal: true,
            resizable: false,
            show: "fade",
            hide: "fade",

            buttons: {
                Ok: function() {
                    var $value = $('#dlg-prompt-value');
                    callback( $value.val() );
                    $( this ).dialog( "close" );
                },
                Cancel: function() {
                    $( this ).dialog( "close" );
                }
            },

            close: function() {
                $( this ).remove();
            }

        });
    };
});

// Tables: http://jsfiddle.net/zdam/pb9ba/


/**
 *
 */
angular.module('drag', []).directive('draggable', function($document) {
    var startX = 0, startY = 0, x = 0, y = 0;
    return function(scope, element, attr) {
        element.css({ position: 'relative', border: '1px solid red', backgroundColor: 'lightgrey', cursor: 'pointer' });
        element.bind('mousedown', function(event) {
            startX = event.screenX - x;
            startY = event.screenY - y;
            $document.bind('mousemove', mousemove);
            $document.bind('mouseup', mouseup);
        });

        function mousemove(event) {
            y = event.screenY - startY;
            x = event.screenX - startX;
            element.css({
                top: y + 'px',
                    left:  x + 'px'
            });
        }

        function mouseup() {
            $document.unbind('mousemove', mousemove);
            $document.unbind('mouseup', mouseup);
        }
    }
});


// Utils
function newDateFromNow( daysOffset ) {
    var now = new Date();
    var today = new Date( now.getFullYear(), now.getMonth(), now.getDate() + daysOffset, 0, 0, 0, 0, 0);

    return today;
}



//---
//  var miresult = transform( theData, function(e) {
//     return { cacho: e.algo };
//  });
function transform( elements, action ) {
    var result = [];

    var n = elements.length;

    for ( var i = 0; i < n; n++ ) {
        result.push( action(elements[i]) );
    }

    return result;
}

