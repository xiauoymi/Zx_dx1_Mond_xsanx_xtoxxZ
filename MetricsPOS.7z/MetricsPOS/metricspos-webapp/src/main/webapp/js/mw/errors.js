/**
 * http://docs.angularjs.org/guide/directive
 *
 * Use: <>
 * Classes used: "error-list-box" and "<baseClass>Off"
 */
applicationModule.directive('mwFormErrors', function(messageConverter) {
    return {
        restrict: 'EACM',
        require: '^form',
        replace: true,
        template: '<div class="error-list-box" ng-show="form.$invalid">' +
                '<div ng-repeat="(errorType, fields) in form.$error">'+
                '<p ng-repeat="field in fields">{{errorPrefix(field)}} {{errorType | message}}</p>'+
                '</div></div>',

        // TODO Agregar: fieldErrorPattern and formErrorPattern --> También podría ser un filter !!!!
        // The linking function will add behavior to the template
        // The fourth parameter is a FormController (http://docs.angularjs.org/api/ng.directive:form.FormController)
        link: function(scope, element, attrs, formController) {
            var prefix = attrs.mwPrefix || '';

            scope.form = formController;
            scope.errorPrefix= function( field ) {
                var name = field.$name;

                if ( ! name ) {
                    return '';
                }

                if ( name.charAt(0) == '*' ) {
                    return name.substr(1);
                }

                return messageConverter.format( prefix + name);
            }
        }
    }
});

/**
 * Service to show global errors on page
 */
applicationModule.service('msMessageService', function($rootScope) {
    var infoType  = {clazz: 'ui-state-highlight', icon: 'ui-icon-info'};
    var warnType  = {clazz: 'ui-state-highlight', icon: 'ui-icon-alert'};
    var errorType = {clazz: 'ui-state-error',     icon: 'ui-icon-alert'};

    /**
     * Shows an informational message
     * @param message   the message to show
     */
    this.showInfo = function( message ) {
        $rootScope.$broadcast(applicationModule.ADD, { message: message, type: infoType });
    };

    /**
     * Shows a warning message
     * @param message   the message to show
     */
    this.showWarn = function( message ) {
        $rootScope.$broadcast(applicationModule.ADD, { message: message, type: warnType});
    };

    /**
     * Shows an error message
     * @param message   the message to show
     */
    this.showError = function( message ) {
        $rootScope.$broadcast(applicationModule.ADD, { message: message, type: errorType});
    };

    /**
     * Shows a message. If it is a string, an error message is shown.
     * If the message has a type property, it is used as the error level.
     * @param {string | object } message   the message to show
     */
    this.showMessage = function( message ) {
        spinnerService.hideSpinner();
        if ( ! angular.isObject( message ) ) {
            this.showError( message );
        } else if ( 'info' === message.type ) {
            this.showInfo( message.message );
        } else if ( 'warn' === message.type ) {
            this.showWarn( message.message );
        } else {
            this.showError( message.message );
        }
    };

    /**
     * Shows a list of messages
     * @param {string | object | array } errorList the list of messages to show
     */
    this.show = function( errorList ) {
        if ( angular.isArray( errorList) ) {
            angular.forEach( errorList, this.showMessage, this );
        } else {
            this.showMessage( errorList );
        }
    };

    /**
     * Clears the messages already shown
     */
    this.clear = function() {
        $rootScope.$broadcast(applicationModule.CLEAR_ALL);
    }
});

applicationModule.CLEAR_ALL = 'errors.clear';
applicationModule.ADD       = 'errors.add';

/**
 *             <div id="errors" class="error-list-box">
                <p ng-repeat="error in errors" ng-class="error.type">{{error.message }}</p>
            </div>
 */
applicationModule.directive('mwErrors', function(messageConverter, msMessageService) {
    return {
        restrict: 'EACM',
        replace: true,
        template: '<div class="error-list-box" ng-show="errors">' +
                  '<div ng-repeat="error in errors" class="ui-corner-all" ng-class="error.type.clazz" style="margin-top: 20px; padding: 0 .7em;">' +
                  '<p><span class="ui-icon" ng-class="error.type.icon" style="float: left; margin-right: .3em;"></span>{{error.message}}</p>' +
                  '</div></div>',

        // The linking function will add behavior to the template
        // The fourth parameter is a FormController (http://docs.angularjs.org/api/ng.directive:form.FormController)
        link: function($scope, element, attrs) {
            $scope.$on(applicationModule.ADD, function(event, errors) {
                if ( ! $scope.errors ) {
                    $scope.errors = [];
                }

                if ( angular.isArray(errors) ) {
                    // Add all error list
                    $scope.errors = $scope.errors.concat( errors );
                } else {
                    // Add single error
                    $scope.errors.push( errors );
                }

                $scope.$apply();

            });

            $scope.$on(applicationModule.CLEAR_ALL, function() {
                $scope.errors = null;
            });
        }
    };
});

applicationModule.directive('mwMessageInfo', function(messageConverter, msMessageService) {
    return {
        restrict: 'EAC',
        transclude: true,
        template: '<div class="error-list-box">' +
                  '<div class="ui-corner-all ui-state-highlight" style="margin-top: 20px; padding: 0 .7em;">' +
                  '<p><span class="ui-icon ui-icon-info" style="float: left; margin-right: .3em;"></span><div ng-transclude=""></div></p>' +
                  '</div></div>'
    };
});

//
var RouteErrorController = function($location, msMessageService) {
    msMessageService.showError( 'Location does not exists ' + $location.url() );
};
