/**
 * directive to upload a file into the application.
 */
applicationModule.directive('fileUpload', function ($rootScope){
		return {
			restrict: 'E',
			replace: true,
			template:
					'<form id="fileUploadForm" enctype="multipart/form-data" method="POST"> ' +
                    '<fieldset>  ' +
                    ' <label for="file">Archivo</label> ' +
                    '    <input type="file" name="file" id="file" class="text ui-widget-content ui-corner-all" /> ' +
                    '    <button id="fileUpload">Importar</button> ' +
                    '</fieldset> ' +
					'</form> ',

			link: function(scope, element, attrs) {
				var form = angular.element('#fileUploadForm');
				form.ajaxForm({
                // dataType identifies the expected content type of the server response
                    dataType:  'json',
                    // before submit start show spinner
                    beforeSubmit: function() {
                        spinnerService.showSpinner();
                    } ,
                    // success identifies the function to invoke when the server response
                    // has been received
                    success:   function(data) {
                        // response end hide spinner
                        spinnerService.hideSpinner();
                        if (data.result == "OK"){
                            $rootScope.$broadcast('file.uploaded.ok', data.message);
                        }
                        else if (data.result == "NG"){
                            $rootScope.$broadcast('file.uploaded.error', data.message);
                        }
                    }

                });

			}
		}
	});