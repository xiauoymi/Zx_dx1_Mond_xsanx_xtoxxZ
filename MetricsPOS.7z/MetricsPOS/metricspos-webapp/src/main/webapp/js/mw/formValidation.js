/**
 * Use: <form mw-validate="{ passwordMatch: 'password1 == password2' }" mw-name="form" >...</form>
 * mg-validate: Object with form validations. object key y used as error key. Value is an expression evaluated
 * for true or false. mw-name (or mw-name-exp) is used as control name.
 * If name starts with "&" it is used as a compound "message key". The value is added to the prefix defined in
 * mw-form-errors directive (attribute mw-prefix).
 */
applicationModule.directive('mwValidate', function() {
    var noop = function() {};

    var nullFormCtrl = {
        $addControl: noop,
        $removeControl: noop,
        $setValidity: noop,
        $setDirty: noop
    };

    return {
        restrict: 'A',
        require: '^form', // Looks on parent also

        // The linking function will add behavior to the template
        // The fourth parameter is a NgModelController (http://docs.angularjs.org/api/ng.directive:ngModel.NgModelController)
        link: function(scope, element, attrs, parentFormCtrl) {
            var modelCtrl = { $name: attrs.name || attrs.mwName },
                nameExp = attrs.mwNameExp,
                validateExpr = attrs.mwValidate;
            var $error = this.$error = {}; // keep invalid keys here

            validateExpr = scope.$eval(validateExpr);

            if ( ! validateExpr) {
              return;
            }

            if (angular.isFunction(validateExpr)) {
              validateExpr = { validator: validateExpr };
            }

            parentFormCtrl.$addControl(modelCtrl);

            element.bind('$destroy', function() {
                parentFormCtrl.$removeControl(modelCtrl);
            });

            if ( nameExp ) {
                scope.$watch( nameExp, function( newValue ) {
                    modelCtrl.$name = newValue;
                })
            }

            // Register watches
            angular.forEach(validateExpr, function(validExp, validationErrorKey) {
                // Check for change in "boolean" value (true or false)
                scope.$watch( '(' + validExp + ') && true', function(newIsValid, oldIsValid) {
                    if ($error[validationErrorKey] === !newIsValid) return;

                    $error[validationErrorKey] = !newIsValid;

                    parentFormCtrl.$setValidity(validationErrorKey, newIsValid, modelCtrl);

                });
            });

        }
    }
});
