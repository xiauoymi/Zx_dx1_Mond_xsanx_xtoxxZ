/**
 * http://docs.angularjs.org/guide/directive
 *
 * Use: <toggle ng-model="{string}"
        [name="{string}"]
        [ng-base-class= "{string}"]
        [ng-change= "{string}"]>
 * Classes used: "<baseClass>On" and "<baseClass>Off"
 */
applicationModule.directive('mwToggle', function() {
    return {
        restrict: 'E',
        require: '?ngModel',
        replace: true,
        template: '<span class="mw-toggle"></span>',

        // The linking function will add behavior to the template
        // The fourth parameter is a NgModelController (http://docs.angularjs.org/api/ng.directive:ngModel.NgModelController)
        link: function(scope, element, attrs, ctrl) {
            var onClass  = attrs.ngBaseClass + '-on';
            var offClass = attrs.ngBaseClass + '-off';

            element.bind('click', function() {
                scope.$apply(function() {
                    var isOn = ! ctrl.$modelValue;
                    ctrl.$setViewValue(isOn);
                    element.removeClass(isOn ? offClass : onClass);
                    element.addClass(isOn ? onClass : offClass);
                });
            });

            // watch the expression, and update the UI on change.
//            scope.$watch(attrs.ngModel, function(value) {
//            });

            ctrl.$render = function() {
                var isOn = ctrl.$modelValue;
                element.removeClass(isOn ? offClass : onClass);
                element.addClass(isOn ? onClass : offClass);
            };

        }
    }
});
