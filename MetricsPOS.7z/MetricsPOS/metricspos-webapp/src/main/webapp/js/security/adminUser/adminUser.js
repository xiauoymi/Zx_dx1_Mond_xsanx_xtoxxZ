applicationModule.factory('AdminUsers', function($resource, $rootScope, msMessageService) {

    var adminRes = $resource(DATA_BASE + '/security/admins/:adminId', { adminId: '@id'},
        {
            'update': {method:'PUT'},
            'remove': {method:'DELETE'}
        }
    );

    return adminRes;
});


//---------- Controllers
AdminUserListController = function($scope, $http, $location, AdminUsers, Campaigns, dialogs) {
    Campaigns.clearCampaign();
    $scope.admins = AdminUsers.query();

    $scope.remove = function(admin) {
        dialogs.confirm("Usuario administrador " + admin.name, "¿Desea eliminarlo junto a todos sus datos (NO se puede deshacer)?", function() {
            dialogs.confirm({title: "Usuario administrador " + admin.name, message: "¿Desea cancelar la eliminación?", ok: "Sí", cancel: "No, elimínelo", onCancel: function() {
                admin.$remove(function() {
                    $scope.admins = AdminUsers.query();
                });
            }});
        });
    }

    $scope.newAdminUser = function() {
        dialogs.prompt("Nuevo usuario administrador", "Nombre:", '', function(username) {
            if (username) {
                var admin = { username: username, enabled: true };

                AdminUsers.save(admin, function(){
                    $scope.admins = AdminUsers.query();
                });
            }
        });
    };
};