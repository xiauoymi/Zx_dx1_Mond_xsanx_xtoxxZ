var AuditLogsController = function($scope, $http, $location, $routeParams, Campaigns) {
    Campaigns.clearCampaign();
    $scope.columnModel = getColumnModel();
    $scope.columnNames = getColumnNames();

    $scope.jqGridOptions = {
        datatype: 'json',
        mtype: 'GET',
        url: DATA_BASE + '/security/logs/audit',
        ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
        colNames: $scope.columnNames,
        colModel: $scope.columnModel,
        multiselect: false,
        width: ($(window).width() - 420),
        height:'80%',
        viewrecords: true,
        pager: '#gridpager',
        rowNum: 25, // number of rows per page.
        jsonReader : {
            root:"content", // json element which contains the data.
            page: "number",  // number of page
            total: "totalPages", // total number of pages
            records: "totalElements",  // total number of rows.
            repeatitems: false,
            id: "mpsInternalId"
        },
        loadComplete : function (data) {
            $scope.jsonData = data;
        },
        loadError: function(xhr, status, error) {
            var e = error;
        },
        onSelectRow: function(id, status, e) {
        }
    };

    $scope.accordionOptions = { autoHeight: false, collapsible: true, active: 2, clearStyle: false };

    $scope.grid = function() {
        if (! this.theGrid) {
            this.theGrid = angular.element('#auditLogsTable');
        }
        return this.theGrid;
    };

    $scope.hideShow = function(column) {
        this.grid().jqGrid((column.hidden ? 'hideCol' : 'showCol'), column.name);
    };

    $scope.initToolbars = function() {
        this.grid().jqGrid('navGrid', '#gridpager', {add:false, edit:false, del:false, search:false},
            {},
            {},
            {}
        );

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Mostrar/Ocultar busqueda", title:"Mostrar/Ocultar busqueda", buttonicon :'ui-icon-pin-s',
                onClickButton:function() {
                    $scope.grid()[0].toggleToolbar();
                }
            });

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Limpiar", title:"Limpiar filtro de busqueda", buttonicon :'ui-icon-refresh',
                onClickButton:function() {
                    $scope.grid()[0].clearToolbar();
                    //clearCustomSearchColumns();
                }
            });

        this.grid().jqGrid('filterToolbar', { searchOnEnter: true});
        $scope.grid()[0].toggleToolbar();
    };


    function getColumnModel() {
        initDate = function (elem) {
            $(elem).datepicker({
                dateFormat: 'dd-mm-yy',
                autoSize: true,
                changeYear: true,
                changeMonth: true,
                showButtonPanel: true,
                showWeek: false
            });
            $('.ui-datepicker').css({'font-size':'75%'});
            $('.ui-datepicker').css({'z-index':'1000'});
        };

        dateTemplate = {width: 80, align: 'center', sorttype: 'datetime', srcformat: 'Y-m-d H:i:s',
            newformat: 'hh:mm:ss', editoptions: { dataInit: initDate }};


        return [
            {name:'id', label: 'Id', jsonmap: 'id',width:40, align: 'center', search: true, hidden: true},
            {name:'context', label: 'Contexto', jsonmap: 'context', width:30, align: 'right', search: true, hidden: true},
            {name:'date', label: 'Fecha', jsonmap: 'date', width:50, align: 'center', formatter:'date', formatoptions: {srcformat: 'Y-m-d H:i:s', newformat: 'd-m-Y H:i:s'}, searchoptions: { dataInit: initDate }},
            {name:'qualifier', label: 'Etiqueta', jsonmap: 'qualifier', width:30, align: 'right', search: true, hidden: true},
            {name:'priority', label: 'Prioridad', jsonmap: 'priority', width:30, align: 'right', search: true, hidden: true},
            {name:'message', label: 'Mensaje', jsonmap: 'message', width:30, align: 'right', search: true},
            {name:'username', label: 'Nombre de Usuario', jsonmap: 'username', width:30, align: 'right', search: true}

        ];
    }

    function getColumnNames() {
        return ['Id', 'Contexto', 'Fecha', 'Etiqueta', 'Prioridad', 'Mensaje', 'Nombre de usuario'];
    }

}