applicationModule.factory('Authorities', function($resource, $rootScope, msMessageService) {

    var authorityRes = $resource(DATA_BASE + '/security/authorities/:authorityId', { authorityId: '@id'},
        {
            'update': {method:'PUT'},
            'remove': {method:'DELETE'}
        }
    );

    return authorityRes;
});