applicationModule.factory('Employees', function($resource, $rootScope, msMessageService) {

    var employeeRes = $resource(DATA_BASE + '/security/campaign/:campaignId/employees/:employeeId', { campaignId: '@campaignId', employeeId:'@id'},
        {
            'update': {method:'PUT'},
            'remove': {method:'DELETE'}
        }
    );

    return employeeRes;
});
