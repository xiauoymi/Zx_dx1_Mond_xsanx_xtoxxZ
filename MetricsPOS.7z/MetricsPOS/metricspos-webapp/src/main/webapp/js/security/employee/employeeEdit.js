EmployeeEditController = function($scope, $http, $location, $routeParams, Employees, Campaigns, Metrics, dialogs, msMessageService) {
    if ($routeParams.employeeId) {
        loadCampaignMetricsServiceCentersAndEmployee();

        $scope.save = function() {
            $scope.employee.$update(function() {
                msMessageService.showInfo('Se han guardado los cambios con exito');
            });
        }
    } else {
        $scope.employee = {
            campaignId: $routeParams.campaignId,
            name: '',
            username: '',
            enabled: true,
            groups: [],
            metrics: [],
            serviceCenters: []
        };

        loadCampaignMetricsServiceCenters();

        $scope.save = function() {
            Employees.save($scope.employee, function(employee) {
                $location.path('/security/campaign/' + employee.campaignId + '/employee/' + employee.id + '/edit');
            });
        }
    }


    $scope.cancel = function() {
        $location.path('/security/campaign/' + $routeParams.campaignId + '/employees');
    }

    $scope.removeMetric = function(metric) {
        var index = -1;
        for (var i = 0; i < $scope.employee.metrics.length; i++) {
            if ($scope.employee.metrics[i].id == metric.id) {
                index = i;
            }
        }
        $scope.employee.metrics.splice(index, 1);
    }

    $scope.removeAllMetrics = function(metric) {
        $scope.employee.metrics.splice(0, $scope.employee.metrics.length);
    }

    $scope.addMetric = function(metric) {
        $scope.employee.metrics.push(metric);
    }

    $scope.addAllMetrics = function() {
        if ($scope.metrics) {
            for (var i = 0; i < $scope.metrics.length; i++) {
                if (!$scope.employeeContainsMetric($scope.metrics[i])) {
                    $scope.employee.metrics.push($scope.metrics[i]);
                }
            }
        }
    }

    $scope.addAllServiceCenters = function() {
        if ($scope.serviceCenters) {
            for (var i = 0; i < $scope.serviceCenters.length; i++) {
                if (!$scope.employeeContainsServiceCenter($scope.serviceCenters[i])) {
                    $scope.employee.serviceCenters.push($scope.serviceCenters[i]);
                }
            }
        }
    }

    $scope.removeServiceCenter = function(serviceCenter) {
        var index = -1;
        for (var i = 0; i < $scope.employee.serviceCenters.length; i++) {
            if ($scope.employee.serviceCenters[i].cuit == serviceCenter.cuit) {
                index = i;
            }
        }
        $scope.employee.serviceCenters.splice(index, 1);
    }

    $scope.removeAllServiceCenters = function(serviceCenter) {
        $scope.employee.serviceCenters.splice(0, $scope.employee.serviceCenters.length);
    }

    $scope.addServiceCenter = function(serviceCenter) {
        $scope.employee.serviceCenters.push(serviceCenter);
    }

    $scope.employeeContainsMetric = function(metric) {
        if ($scope.employee && $scope.employee.metrics) {
            for (var i = 0; i < $scope.employee.metrics.length; i++) {
                if ($scope.employee.metrics[i].id == metric.id) {
                    return true;
                }
            }
        }

        return false;
    }

    //Because all metrics list might be limited by permissions
    $scope.employeeMetricIsInAllMetricsList = function(metric) {
        if ($scope.metrics) {
            for (var i = 0; i < $scope.metrics.length; i++) {
                if ($scope.metrics[i].id == metric.id) {
                    return true;
                }
            }
        }

        return false;
    }

    //Because all service centers list might be limited by permissions
    $scope.employeeServiceCenterIsInAllServiceCentersList = function(serviceCenter) {
        if ($scope.serviceCenters) {
            for (var i = 0; i < $scope.serviceCenters.length; i++) {
                if ($scope.serviceCenters[i].id == serviceCenter.id) {
                    return true;
                }
            }
        }

        return false;
    }

    $scope.employeeContainsServiceCenter = function(serviceCenter) {
        if ($scope.employee && $scope.employee.serviceCenters) {
            for (var i = 0; i < $scope.employee.serviceCenters.length; i++) {
                if ($scope.employee.serviceCenters[i].cuit == serviceCenter.cuit) {
                    return true;
                }
            }
        }

        return false;
    }

    function loadCampaignMetricsServiceCentersAndEmployee() {
        Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
            $scope.campaign = data;
            Campaigns.serviceCenters({campaignId: $routeParams.campaignId}, function(serviceCenters) {
                $scope.serviceCenters = serviceCenters;
                Metrics.query({campaignId: $routeParams.campaignId}, function(metrics) {
                    $scope.metrics = metrics;
                    Employees.get({campaignId : $routeParams.campaignId, employeeId : $routeParams.employeeId}, function(employee) {
                        $scope.employee = employee;
                    });
                });
            });
        })
    }

    function loadCampaignMetricsServiceCenters() {
        Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
            $scope.campaign = data;
            Campaigns.serviceCenters({campaignId: $routeParams.campaignId}, function(serviceCenters) {
                $scope.serviceCenters = serviceCenters;
                Metrics.query({campaignId: $routeParams.campaignId}, function(metrics) {
                    $scope.metrics = metrics;
                });
            });
        })
    }
};