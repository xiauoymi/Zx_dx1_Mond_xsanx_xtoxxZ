var EmployeeGroupsController = function($scope, $http, $routeParams, $location, dialogs, msMessageService, Campaigns, Groups) {

    var EMPLOYEE_ID_COLUMN_NAME = "Id";
    var EMPLOYEE_USERNAME_COLUMN_NAME = "Username";
    var EMPLOYEE_NAME_COLUMN_NAME = "Nombre";

    $scope.campaign = Campaigns.get({campaignId: $routeParams.campaignId});

    $scope.accordionOptions = { autoHeight: false, collapsible: true, active: 2, clearStyle: false };

    $scope.grid = function() {
        if (! this.theGrid) {
            this.theGrid = angular.element('#employeeGroupsTable');
        }
        return this.theGrid;
    };

    $scope.hideShow = function(column) {
        this.grid().jqGrid((column.hidden ? 'hideCol' : 'showCol'), column.name);
    };

    Groups.query({campaignId : $routeParams.campaignId}, function(groups) {
        $scope.groups = groups;
        Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
            $scope.campaign = data;
        });
        loadGrid(groups);
    });

    $scope.initToolbars = function() {
        this.grid().jqGrid('navGrid', '#gridpager', {add:true, edit:true, del:false, search:false},
            /* edit options*/
            {
                mtype: 'PUT',
                closeAfterEdit: true
            }
        );

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Mostrar/Ocultar busqueda", title:"Mostrar/Ocultar busqueda", buttonicon :'ui-icon-pin-s',
                onClickButton:function() {
                    $scope.grid()[0].toggleToolbar();
                }
            });

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Limpiar", title:"Limpiar filtro de busqueda", buttonicon :'ui-icon-refresh',
                onClickButton:function() {
                    $scope.grid()[0].clearToolbar();
                }
            });

        this.grid().jqGrid('filterToolbar', { searchOnEnter: true});
        $scope.grid()[0].toggleToolbar();
    };

    $.extend($.jgrid.edit, {
        datatype: 'json',
        url : DATA_BASE + '/security/campaigns/' + $routeParams.campaignId + '/employees/groups',
        ajaxEditOptions: { contentType: "application/json" },
        serializeEditData: function(postData) {
            var json;
            if (postData.oper == "add") {
                json = JSON.stringify(new Array(postData));
            }
            else {
                // edit
                json = JSON.stringify(postData);
            }
            return json;
        }
    });

    function reloadGrid() {
        $scope.grid().jqGrid('setGridParam', {datatype: 'json'}).trigger('reloadGrid');
    }

    function loadGrid(data) {
        $scope.columnNames = getColumnNames(data);
        $scope.columnModel = getColumnModel(data);

        // set the grid options.
        $scope.jqGridOptions = {
            datatype: 'json',
            mtype: 'GET',
            url: DATA_BASE + '/security/campaigns/' + $routeParams.campaignId + '/employees/groups',
            editurl: DATA_BASE + '/security/campaigns/' + $routeParams.campaignId + '/employees/groups',
            ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
            colNames: $scope.columnNames,
            colModel: $scope.columnModel,
            multiselect: false,
            width: ($(window).width() - 280),
            height:'80%',
            viewrecords: true,
            pager: '#gridpager',
            rowNum: 25, // number of rows per page.
            jsonReader : {
                root:"content", // json element which contains the data.
                page: "number",  // number of page
                total: "totalPages", // total number of pages
                records: "totalElements",  // total number of rows.
                repeatitems: false,
                id: "mpsInternalId"
            },
            loadComplete : function (data) {
                $scope.jsonData = data;
            },
            loadError: function(xhr, status, error) {
                var e = error;
            }
        }
    }

    /**
     * Process the metadata to get the list of column names.
     * @param data
     */
    function getColumnNames(data) {
        var c = new Array();
        // add the default column name for ID column.
        c.push(EMPLOYEE_ID_COLUMN_NAME);
        c.push(EMPLOYEE_USERNAME_COLUMN_NAME);
        c.push(EMPLOYEE_NAME_COLUMN_NAME);

        for (var i = 0; i < data.length; i++) {
            c.push(data[i].name);
        }
        return c;
    }

    /**
     * Process the metadata to get the column model of each column.
     * @param data
     */
    function getColumnModel(data) {
        var c = new Array();
        var defaultOption = "---";
        c.push(getDefaultColumnModelForIdColumn());
        c.push(getDefaultColumnModelForUsernameColumn());
        c.push(getDefaultColumnModelForNameColumn());
        var aColModel;
        for (var i = 0; i < data.length; i++) {
            aColModel = new Object();
            aColModel.name = replaceAll(data[i].name, " ", "_");
            aColModel.index = data[i].name;
            aColModel.label = data[i].name;
            aColModel.key = false;
            aColModel.search = true;
            aColModel.editable = true;
            aColModel.hidden = false;
            aColModel.sortable = false;
            aColModel.edittype = 'checkbox';
            aColModel.editoptions = {value:"true:false"};
            aColModel.stype = 'select';
            aColModel.align = "center";
            aColModel.formatter = 'checkbox';
            aColModel.formatoptions = {disabled: true};
            aColModel.editrules = {required: false};
            aColModel.searchoptions = {value: {'':'---','true':'Si','false':'No'}};
            c.push(aColModel);
        }
        return c;
    }

    function getBoolean(data) {
        return (data == "true" || data == true) ? true : false;
    }

    function getDefaultColumnModelForIdColumn() {
        var aColModel = new Object();
        aColModel.name = "id";
        aColModel.index = "id";
        aColModel.label = "Id";
        aColModel.key = true;
        aColModel.search = true;
        aColModel.editable = false;
        aColModel.hidden = false;
        aColModel.sortable = true;
        return aColModel;
    }

    function getDefaultColumnModelForUsernameColumn() {
        var aColModel = new Object();
        aColModel.name = "username";
        aColModel.index = "username";
        aColModel.label = "Username";
        aColModel.key = false;
        aColModel.search = true;
        aColModel.editable = false;
        aColModel.hidden = false;
        aColModel.sortable = true;
        return aColModel;
    }

    function getDefaultColumnModelForNameColumn() {
        var aColModel = new Object();
        aColModel.name = "name";
        aColModel.index = "name";
        aColModel.label = "Nombre";
        aColModel.key = false;
        aColModel.search = true;
        aColModel.editable = false;
        aColModel.hidden = false;
        aColModel.sortable = true;
        return aColModel;
    }

    function replaceAll(txt, replace, with_this) {
        return txt.replace(new RegExp(replace, 'g'), with_this);
    }
}