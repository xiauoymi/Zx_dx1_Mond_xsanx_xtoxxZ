//---------- Controllers
EmployeeListController = function($scope, $http, $location, $routeParams, Employees, Campaigns, dialogs) {
    $scope.employees = Employees.query({campaignId: $routeParams.campaignId}, function(employees) {
        Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
            $scope.campaign = data;
        });
    });

    $scope.edit = function(employee) {
        $location.path('/security/campaign/' + employee.campaignId + '/employee/' + employee.id + '/edit');
    }

    $scope.newEmployee = function() {
        $location.path('/security/campaign/' + $routeParams.campaignId + '/employee/edit');
    };
};
