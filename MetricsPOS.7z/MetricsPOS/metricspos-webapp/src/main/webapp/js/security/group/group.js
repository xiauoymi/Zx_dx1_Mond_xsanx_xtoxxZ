applicationModule.factory('Groups', function($resource, $rootScope, msMessageService) {

    var groupRes = $resource(DATA_BASE + '/security/groups/:groupId', { groupId: '@id'},
        {
            'update': {method:'PUT'},
            'remove': {method:'DELETE'}
        }
    );

    return groupRes;
});


//---------- Controllers
GroupListController = function($scope, $http, $location, Groups, Campaigns, dialogs) {
    $scope.groups = Groups.query();
    Campaigns.clearCampaign();

    $scope.edit = function(group) {
        $location.path('/security/group/' + group.id + '/edit');
    }

    $scope.remove = function(group) {
        dialogs.confirm("Grupo " + group.name, "¿Desea eliminarlo junto a todos sus datos (NO se puede deshacer)?", function() {
            dialogs.confirm({title: "Grupo " + group.name, message: "¿Desea cancelar la eliminación?", ok: "Sí", cancel: "No, elimínelo", onCancel: function() {
                group.$remove(function() {
                    $scope.groups = Groups.query();
                });
            }});
        });
    }

    $scope.newGroup = function() {
        dialogs.prompt("Nuevo grupo", "Nombre:", '', function(name) {
            if (name) {
                var group = { name: name, enabled: true };

                Groups.save(group, function(){
                    $scope.groups = Groups.query();
                });
            }
        });
    };
};