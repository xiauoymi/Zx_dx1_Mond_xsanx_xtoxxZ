//---------- Controllers
GroupEditController = function($scope, $http, $location, $routeParams, Groups, Authorities, Campaigns, dialogs, msMessageService) {
    Campaigns.clearCampaign();
    $scope.authorities = Authorities.query();

    if ($routeParams.groupId) {
        $scope.group = Groups.get({groupId: $routeParams.groupId});
    }

    $scope.groupContains = function(authority) {
        if ($scope.group.authorities) {
            for (var i = 0; i < $scope.group.authorities.length; i++) {
                if ($scope.group.authorities[i].id == authority.id) {
                    return true;
                }
            }
        }

        return false;
    }

    $scope.addAuthorityToGroup = function(authority) {
        $scope.group.authorities.push(authority);
    }

    $scope.addAllAuthorityToGroup = function(authority) {
        if ($scope.group.authorities) {
            for (var i = 0; i < $scope.authorities.length; i++) {
                if(!$scope.groupContains($scope.authorities[i])) {
                    $scope.group.authorities.push($scope.authorities[i])
                }
            }
        }
    }

    $scope.removeAllAuthorityFromGroup = function(authority) {
        $scope.group.authorities.splice(0, $scope.group.authorities.length);
    }

    $scope.removeAuthorityFromGroup = function(authority) {
        var index = -1;
        for (var i = 0; i < $scope.group.authorities.length; i++) {
            if ($scope.group.authorities[i].id == authority.id) {
                index = i;
            }
        }
        $scope.group.authorities.splice(index, 1);
    }

    $scope.save = function() {
        $scope.group.$update(function() {
            msMessageService.showInfo('Se han guardado los cambios con exito');
        });
    }

    $scope.cancel = function() {
        $location.path('/security/group/list');
    }
}
