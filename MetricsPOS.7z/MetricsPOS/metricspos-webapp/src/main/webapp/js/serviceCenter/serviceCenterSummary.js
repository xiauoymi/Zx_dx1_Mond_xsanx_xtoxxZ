/**
 * Logic for viewing service centers
 */
var ServiceCenterSummaryController = function($scope, $http, $location, $routeParams, Campaigns, msMessageService) {
    var campaignId = $routeParams.campaignId;
    var cuit = $routeParams.cuit;

    //quantity of decimals to show.
    $scope.decimals = 2;

    if (campaignId && cuit) {
        Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
            $scope.campaign = data;
            $scope.summary = Campaigns.serviceCenterSummary({campaignId: $routeParams.campaignId, cuit: $routeParams.cuit});
        });
    }

    if (cuit) {
        Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
            $scope.campaign = data;
            $scope.serviceCenter = Campaigns.serviceCenter({campaignId: $routeParams.campaignId, cuit: $routeParams.cuit});
        });
    }

    $scope.send = function() {
        Campaigns.sendSummary({campaignId: $routeParams.campaignId, cuit: $routeParams.cuit}, function() {
            msMessageService.showInfo('Se ha enviado el resumen por correo a ' + $scope.serviceCenter.mail);
            $scope.summary = Campaigns.serviceCenterSummary({campaignId: $routeParams.campaignId, cuit: $routeParams.cuit});
        }, function() {
            msMessageService.showError('Ocurrio un error enviando el resumen a ' + $scope.serviceCenter.mail);
        });
    }
}
