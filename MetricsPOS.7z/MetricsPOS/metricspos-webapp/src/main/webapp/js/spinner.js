
var HTTP_CODES = {
    '200': {description:'OK',hide:true,info:true },
    '201': {description:'Created',hide:true,info:true },
    '202': {description:'Accepted',hide:true,info:true },
    '203': {description:'Partial Information',info:true },
    '204': {description:'No Content',info:true },
    '205': {description:'Reset Content',info:true },
    '206': {description:'Partial Content',info:true },
    '300': {description:'Multiple Choices',info:true },
    '301': {description:'Moved Permanently',info:true },
    '302': {description:'Moved Temporarily',info:true },
    '303': {description:'See Other',info:true },
    '304': {description:'Not Modified',info:true },
    '305': {description:'Use Proxy',info:true },
    '400': {description:'Bad Request' },
    '401': {description:'Unauthorized' },
    '402': {description:'Payment Required' },
    '403': {description:'Forbidden' },
    '404': {description:'Not Found' },
    '405': {description:'Method Not Allowed' },
    '406': {description:'Not Acceptable' },
    '407': {description:'Proxy Authentication Required' },
    '408': {description:'Request Time-Out' },
    '409': {description:'Conflict ' },
    '410': {description:'Gone' },
    '411': {description:'Length Required' },
    '412': {description:'Precondition Failed' },
    '413': {description:'Request Entity Too Large' },
    '414': {description:'Request-URL Too Large' },
    '415': {description:'Unsupported Media Type' },
    '500': {description:'Server Error' },
    '501': {description:'Not Implemented' },
    '502': {description:'Bad Gateway ' },
    '503': {description:'Out of Resources' },
    '504': {description:'Gateway Time-Out' },
    '505': {description:'HTTP Version not supported' },
    '0': {description:'Server is not available', hide: true}
};
/*This module intercepts every angular ajax HTTP call*/

function handleErrorResponse(response, msMessageService) {
    var status = response.status.toString();

    var message = HTTP_CODES[status];

    if ( ! message ) {
        message = { code: status, description: 'Unknown error code'};
    }

    var text = (message.hide && response.data)
        ?  response.data
        : status + ': ' + message.description + '. ' + response.data[0].message;

     msMessageService[message.info ? 'showInfo' : 'showError'](text);
}

var spinnerService = new (function () {
    // Becomes this.options
    var defaults = {
        bgColor 		: '#ffffff',
        duration		: 300,
        opacity			: 0.7,
        classOverride 	: false
    };

    var pendingCalls = 0;

    //this.options 	= angular.extend(defaults, options);
    this.options = defaults;

    this.init = function( $element, $log, msMessageService) {
        this.container = $element;
        this.log = $log;
        this.msMessageService = msMessageService;
    };

    this.hideSpinner = function() {
        if ( --pendingCalls <= 0 ) {
//            this.log.info('Start removing spinner @' + pendingCalls );
            this.remove();
        }
    };

    this.showSpinner = function () {
        if ( pendingCalls++ <= 0 ) {
//            this.log.info('Start adding spinner @' + pendingCalls );
            this.add();
            /** Clear all error messages */
            this.msMessageService.clear();
        }
   };

    function createOverlay(container, options) {
        var height;
        if(container[0]){
            height = container[0].scrollHeight;
        }else{
            height = container.height();
        }
        var overlay = $('<DIV></DIV>').css({
            'background-color': options.bgColor,
            'opacity':options.opacity,
            'width':container.width(),
            'height':height,
            'position':'absolute',
            'top':'0px',
            'left':'0px',
            'z-index':99999
        }).addClass('ajax_overlay');
        // add an overriding class name to set new loader style
        if (options.classOverride) {
            overlay.addClass(options.classOverride);
        }
        // insert overlay and loader into DOM
        container.append(overlay.append($('<DIV></DIV>').addClass('ajax_loader')));
        return overlay;
    }

    this.add = function() {
        var container = this.container;

        if ( ! container ) {
            // not yet initialized
            return;
        }

        // Reuse overlay if one exists
        var overlay = this.overlay;
        if ( ! overlay ) {
            // Create a new overlay
            overlay = createOverlay(container, this.options);
            this.overlay = overlay;
        } else {
            // Stop current animations
            overlay.stop();
        }
        // Show overlay
        overlay.fadeIn(this.options.duration);
    };

    this.remove = function(){
        var overlay = this.overlay;

        if (overlay && overlay.length) {
            var self = this;
            overlay.fadeOut(this.options.duration, function() {
//                self.log.info('End removing spinner @' + pendingCalls );
                overlay.remove();
                delete self.overlay;
            });
        }
    }
})();


angular.module('SharedServices', [])
// register the interceptor as a service, intercepts ALL angular ajax http calls
    .run( function( $log, msMessageService ) {
        spinnerService.init( angular.element('body'), $log, msMessageService);
    })
    .config(function ($httpProvider) {
            $httpProvider.responseInterceptors.push('httpErrorsInterceptor');
        var spinnerFunction = function (data, headersGetter) {
            spinnerService.showSpinner();
            return data;
        };

/*
        if ( navigator.appName == 'Microsoft Internet Explorer' ) {
            $httpProvider.defaults.transformRequest.push(function() {
                // Add NOT CACHE filter so IE does not cache AJAX GETs
                if (method == 'GET') {
                    // Fix URL adding parameter so IE does not cache it !!
                    url = url + (url.indexOf('?') == -1 ? '?' : '&') + 'cafTime=' + (new Date()).getTime();
                }
            });
        }
*/


        $httpProvider.defaults.transformRequest.push(spinnerFunction);
    })
    .factory('httpErrorsInterceptor', function ($q, $window, msMessageService) {
        return function (promise) {
            return promise.then(function (response) {
                spinnerService.hideSpinner();
                 return response;
            }, function (response) {
                spinnerService.hideSpinner();
                handleErrorResponse(response, msMessageService);
                return $q.reject(response);
            });
        };
    })
    ;
