var TableRowsController = function($scope, $http, $routeParams, $location, Tables, dialogs, msMessageService, Campaigns) {
    var ID_COLUMN_NAME = "mpsInternalId";
    var tableId = $routeParams.tableId;
    var customSearchColumnNames = new Array();

    Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
        $scope.campaign = data;
    });

    $scope.importUrl = DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/tables/' + tableId + '/rows/import';
    $scope.exportUrl = DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/tables/' + tableId + '/rows/export';

    $scope.accordionOptions = { autoHeight: false, collapsible: true, active: 2, clearStyle: false };

    $scope.grid = function() {
        if (! this.theGrid) {
            this.theGrid = angular.element('#rowsTable');
        }
        return this.theGrid;
    };

    $scope.$on('file.uploaded.ok', function(event, message) {
        msMessageService.showInfo(message);
        reloadGrid();
    });

    $scope.$on('file.uploaded.error', function(event, message) {
        msMessageService.showError(message);
    });


    $scope.hideShow = function(column) {
        this.grid().jqGrid((column.hidden ? 'hideCol' : 'showCol'), column.name);
    };

    $http.get(DATA_BASE + '/tables/dataTypes').success(function(data) {
        $scope.dataTypes = data;
        Tables.get({campaignId: $routeParams.campaignId, tableId: tableId}, function(table) {
            $scope.table = table;

            // We need first the data types before populating the columns
            $scope.metadata = Tables.metadata({campaignId: $routeParams.campaignId, tableId: tableId}, function(data) {
                $scope.metadata = data;

                var campaignId = $routeParams.campaignId;
                // We also need the service centers
                $scope.serviceCenters = Campaigns.serviceCenters({campaignId: $routeParams.campaignId}, function(serviceCenters) {
                    $scope.serviceCenters = serviceCenters;

                    $scope.pointsOfSale = Campaigns.pointsOfSale({campaignId: $routeParams.campaignId}, function(pointsOfSale) {
                        $scope.pointsOfSale = pointsOfSale;
                        loadGrid($scope.metadata);
                    });
                });

            });
        });
    });


    $scope.initToolbars = function() {
        var addAllowed = $scope.table.allowRecordCreation;

        this.grid().jqGrid('navGrid', '#gridpager', {add:addAllowed, edit:true, del:addAllowed, search:false},
            /* edit options*/
            {
                mtype: 'PUT',
                closeAfterEdit: true
            },
            /* add options*/
            {
                mtype: 'POST',
                closeAfterAdd: true
            },
            /* delete options*/
            {
                mtype: 'DELETE'
            }
        );

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Mostrar/Ocultar busqueda", title:"Mostrar/Ocultar busqueda", buttonicon :'ui-icon-pin-s',
                onClickButton:function() {
                    $scope.grid()[0].toggleToolbar();
                }
            });

        this.grid().jqGrid('navButtonAdd', "#gridpager",
            { caption:"Limpiar", title:"Limpiar filtro de busqueda", buttonicon :'ui-icon-refresh',
                onClickButton:function() {
                    $scope.grid()[0].clearToolbar();
                    clearCustomSearchColumns();
                }
            });

        // add custom button to export the data to excel
        this.grid().jqGrid('navButtonAdd', '#gridpager', {
            caption:"Exportar a Excel",
            onClickButton : function () {
                exportToExcel();
            }
        });


        this.grid().jqGrid('filterToolbar', { searchOnEnter: true});
        $scope.grid()[0].toggleToolbar();

        $.extend($.jgrid.edit, {
            datatype: 'json',
            url : DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/tables/' + tableId + '/rows',
            ajaxEditOptions: { contentType: "application/json" },
            serializeEditData: function(postData) {
                var json;
                if (postData.oper == "add") {
                    postData.mpsInternalId = "";
                    json = JSON.stringify(new Array(postData));
                }
                else {
                    // edit
                    postData.mpsInternalId = postData.id;
                    json = JSON.stringify(postData);
                }
                return json;
            }
        });

        $.extend($.jgrid.del, {
            mtype: 'DELETE',
            datatype: 'json',
            url : DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/tables/' + tableId + '/rows',
            ajaxDelOptions: { contentType: "application/json" },
            serializeDelData: function(postData) {
                // ids are separated by comma
                var json = JSON.stringify(postData.id.split(","));
                return json;
            }
        });
    };

    $scope.rowSelected = function (rowid, status, e) {
        $scope.beforeEdit = getRowData(rowid);
        //setPointOfSaleSelectOptions(rowid);

        updateSelectOfPointOfSaleColumn(rowid, $scope.beforeEdit);
    };

    function updateSelectOfPointOfSaleColumn(rowid, row) {
        if ($scope.pointOfSaleColumnName) {
            setPointOfSaleSelectOptions(rowid, row[$scope.pointOfSaleColumnName]);
        }
    }

    function reloadGrid() {
        $scope.grid().jqGrid('setGridParam', {datatype: 'json'}).trigger('reloadGrid');
    }

    function loadGrid(data) {
        $scope.columnNames = getColumnNames(data);
        $scope.columnModel = getColumnModel(data);

        $scope.lastsel;
        // set the grid options.
        $scope.jqGridOptions = {
            datatype: 'json',
            mtype: 'GET',
            url: DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/tables/' + tableId + '/rows',
            editurl: DATA_BASE + '/tables/' + tableId + '/rows',
            ajaxGridOptions: { contentType: 'application/json; charset=utf-8' },
            colNames: $scope.columnNames,
            colModel: $scope.columnModel,
            multiselect: false,
            width: ($(window).width() - 300),
            height:'80%',
            viewrecords: true,
            pager: '#gridpager',
            rowNum: 25, // number of rows per page.
            jsonReader : {
                root:"content", // json element which contains the data.
                page: "number",  // number of page
                total: "totalPages", // total number of pages
                records: "totalElements",  // total number of rows.
                repeatitems: false,
                id: "mpsInternalId"
            },
            loadComplete : function (data) {
                $scope.jsonData = data;
                initPointOfSalesCells(data);
            },
            loadError: function(xhr, status, error) {
                var e = error;
            },
            onSelectRow: function(id, status, e) {
                $scope.rowSelected(id, status, e);
            }
        }
    }

    function initPointOfSalesCells(data) {
        if ($scope.pointOfSaleColumnName) {
            for (var i = 0; i < data.content.length; i++) {
                setPointOfSaleSelectOptions(data.content[i].mpsInternalId, data.content[i][$scope.pointOfSaleColumnName]);
            }
        }
    }

    function isEditable(rowid) {
        // look into the datarow to see if the row has the
        var found = false;
        var data = $scope.jsonData.content;
        for (var i = 0; i < data.length; i++) {
            if (data[i].mpsInternalId == rowid) {
                found = true;
                if (data[i].manual == true || hasEditableColumns()) {
                    return true;
                }
            }
        }

        return !found;// If the row was't found then it's a new row and therefore editable
    }

    function hasEditableColumns() {
        for (var i = 0; i < $scope.columnNames.length; i++) {
            if ($scope.grid().jqGrid('getColProp', $scope.columnNames[i]).editable === true) {
                return true
            }
        }
        return false;
    }

    /**
     * Returns true if the row is in editing mode.
     * @param rowid
     */
    function isEditing(rowid) {
        return (jQuery($scope.grid().jqGrid('getInd', rowid, true)).attr("editable") === "1");
    }

    function getRowData(rowid) {
        if (isEditing(rowid)) {
            // first we have to save the row locally to avoid getting text input instead of cell values.
            $scope.grid().jqGrid('saveRow', rowid, false, 'clientArray');
        }
        // get the row data.
        return $scope.grid().jqGrid('getRowData', rowid);
    }

    function isPk(columnName) {
        return $scope.grid().jqGrid('getColProp', columnName).key === true;
    }


    /**
     * Process the metadata to get the list of column names.
     * @param data
     */
    function getColumnNames(data) {
        var c = new Array();
        // add the default column name for ID column.
        c.push(ID_COLUMN_NAME);
        for (var i = 0; i < data.length; i++) {
            c.push(data[i].label);
        }
        return c;
    }

    /**
     * Process the metadata to get the column model of each column.
     * @param data
     */
    function getColumnModel(data) {
        var c = new Array();
        var defaultOption = "---";
        c.push(getDefaultColumnModelForIdColumn());
        var aColModel;
        for (var i = 0; i < data.length; i++) {
            aColModel = new Object();
            aColModel.name = data[i].name;
            aColModel.index = data[i].name;
            aColModel.key = getBoolean(data[i].primaryKey);
            aColModel.search = getBoolean(data[i].filterable);
            aColModel.editable = getBoolean(data[i].editable) || $scope.table.allowRecordCreation;
            aColModel.hidden = getBoolean(data[i].hidden);
            aColModel.sortable = getBoolean(data[i].sortable);

            if (aColModel.name == ID_COLUMN_NAME)
                aColModel.hidden = true;

            if ("TEXT" == data[i].type) {
                aColModel.edittype = "text";
                aColModel.editoptions = {size: data[i].minSize, maxLength: data[i].size};
                aColModel.editrules = {required: getBoolean(data[i].required)};
            }
            if ("BOOLEAN" == data[i].type) {
                aColModel.edittype = 'checkbox';
                aColModel.editoptions = {value:"true:false"};
                aColModel.stype = 'select';
                aColModel.align = "center";
                aColModel.formatter = 'checkbox';
                aColModel.formatoptions = {disabled: true};
                aColModel.editrules = {required: getBoolean(data[i].required)};
                aColModel.searchoptions = {value: {'':'---','true':'Si','false':'No'}};
            }
            if ("DATE" == data[i].type) {
                initDate = function (elem) {
                    $(elem).datepicker({
                        dateFormat: 'dd-mm-yy',
                        autoSize: true,
                        changeYear: true,
                        changeMonth: true,
                        showButtonPanel: true,
                        showWeek: false
                    });
                    $('.ui-datepicker').css({'font-size':'75%'});
                    $('.ui-datepicker').css({'z-index':'1000'});
                };

                dateTemplate = {width: 80, align: 'center', sorttype: 'date', srcformat: 'yy-mm-dd',
                    newformat: 'dd-mm-yy', editoptions: { dataInit: initDate }};

                aColModel.formatter = 'date';
                aColModel.template = dateTemplate;
                aColModel.editrules = {date:false, required: getBoolean(data[i].required)};
                aColModel.searchoptions = { dataInit: initDate };
            }
            if ("ENUM" == data[i].type) {
                var o = new Object();
                var searchValues = new Object();
                searchValues[''] = defaultOption;
                for (var j = 0; j < data[i].options.length; j++) {
                    o[data[i].options[j]] = data[i].options[j];
                    searchValues[data[i].options[j]] = data[i].options[j];
                }
                aColModel.edittype = "select";
                aColModel.editoptions = { value: o};
                aColModel.align = "center";
                aColModel.formatter = 'select';
                aColModel.stype = 'select';
                aColModel.editrules = {required: getBoolean(data[i].required)};

                aColModel.searchoptions = { value: searchValues};
            }
            if ("SC" == data[i].type) {
                $scope.serviceCenterColumnName = data[i].name;
                var o = new Object();
                var searchValues = new Object();
                searchValues[''] = defaultOption;

                $scope.serviceCenters.sort(function(a, b) {
                    return a.name < b.name ? -1 : (a.name == b.name ? 0 : 1);
                });

                for (var j = 0; j < $scope.serviceCenters.length; j++) {
                    o[$scope.serviceCenters[j].cuit] = $scope.serviceCenters[j].name;
                    searchValues[$scope.serviceCenters[j].cuit] = $scope.serviceCenters[j].name;
                }

                aColModel.edittype = "select";
                aColModel.editoptions = {
                    value: o,
                    dataEvents: [
                        {
                            type: 'change',
                            fn: function(e) {
                                var selectedCuit = e.currentTarget.value;
                                setPointOfSaleSelectOptionsByCuit(selectedCuit);
                            }
                        }
                    ]
                };
                aColModel.align = "center";
                aColModel.formatter = 'select';
                aColModel.stype = 'select';
                aColModel.editrules = {required: getBoolean(data[i].required)};

                aColModel.searchoptions = { value: searchValues,
                    dataInit:function(el) {
                        var defOption = $("option:contains(" + defaultOption + ")", el);
                        defOption.attr("selected", "selected");
                    }};
                customSearchColumnNames.push(data[i].name);
            }
            if ("POS" == data[i].type) {
                $scope.pointOfSaleColumnName = data[i].name;
                aColModel.edittype = "select";
                var o = new Object();
                var searchValues = new Object();

                aColModel.editoptions = { value: o};
                aColModel.align = "center";
                aColModel.formatter = 'select';
                aColModel.stype = 'select';

                aColModel.editrules = {required: getBoolean(data[i].required)};
                searchValues[''] = defaultOption;

                $scope.pointsOfSale.sort(function(a, b) {
                    var aString = a.locality + " - " + a.address;
                    var bString = b.locality + " - " + b.address;
                    return aString < bString ? -1 : (aString == bString ? 0 : 1);
                });

                for (var j = 0; j < $scope.pointsOfSale.length; j++) {
                    o[$scope.pointsOfSale[j].idSap] = $scope.pointsOfSale[j].locality + " - " + $scope.pointsOfSale[j].address;
                    searchValues[$scope.pointsOfSale[j].idSap] = $scope.pointsOfSale[j].locality + " " + $scope.pointsOfSale[j].address;
                }

                aColModel.editoptions = { value: o};
                aColModel.searchoptions = { value: searchValues,
                    dataInit:function(el) {
                        var defOption = $("option:contains(" + defaultOption + ")", el);
                        defOption.attr("selected", "selected");
                    }};
                customSearchColumnNames.push(data[i].name);
            }
            if ("NUMBER" == data[i].type) {
                aColModel.editrules = {number: true, required: getBoolean(data[i].required)};
            }
            if ("FILE" == data[i].type ) {
                aColModel.search = false;
                aColModel.editable = false;
                aColModel.sortable = false;
                aColModel.align = "center";
                aColModel.formatter = showDownloadLink;
            }

            if ("LINK" == data[i].type){
                aColModel.search = false;
                //aColModel.editable = getBoolean(data[i].required);
                aColModel.sortable = false;
                aColModel.align = 'center';
                aColModel.formatter = showLink;
                aColModel.edittype = 'custom';
                aColModel.cellattr = getToolTip;
                aColModel.editrules = {required: getBoolean(data[i].required)};
                //aColModel.editoptions = showValue;
                //aColModel.formatoptions = {baseLinkUrl: 'www.google.com.ar', target: '_blank', addParam: '', idName:'', id: ''};
                aColModel.editoptions = {size: "30", custom_element: createInputUrl, custom_value: editValue};
                //aColModel.editrules = {custom: true, custom_func : showValue}

            }

            c.push(aColModel);
        }
        return c;
    }

    function getToolTip(rowId, val, rawObject){
        return val!=null && val != "" ? 'title ="' + getUrlValue(val) + '"' : '';
    }

    function editValue(elem, operation, value){
        if(operation === 'get') {
            return $(elem).val();
        }else if(operation === 'set') {
            //Show the value of href in the <a> tag
            if(value != null && value != ""){
                $('#URL').val( getUrlValue(value) );
            }

        }
    }

    function getUrlValue(aTag){
        var str = aTag;
        var array = str.split('"');
        if(!array.length>1){
            array = str.split("'");
        }
        return array[1];
    }

    function createInputUrl(value, options){
        var el = document.createElement("input");
        el.type="text";
        el.value = value != null && value != "" ? getUrlValue(value) : "";
        return el;
    }

    function showLink(cellValue, options, rowdata, action){
        return cellValue !=null ? "<a href='"+ cellValue + "' target='_blank' >LINK</a>" : "";
    }

    function showDownloadLink(cellValue, options, rowdata, action){
        var text = "";
        if (cellValue){
		    text = "<a href='" + DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/tables/' + tableId + '/rows/download/' + rowdata.mpsInternalId + "'>" + cellValue + "</a>"
        }
		return text;
	}

    function setPointOfSaleSelectOptionsByCuit(cuit) {
        setPointOfSaleSelectedOptions($scope.pointOfSaleColumnName, cuit, null);
    }

    function setPointOfSaleSelectOptions(rowId, selectedPOS) {
        var cuit = getCuit(rowId, $scope);
        var selectElementId = rowId + "_" + $scope.pointOfSaleColumnName;
        setPointOfSaleSelectedOptions(selectElementId, cuit, selectedPOS);
    }

    function setPointOfSaleSelectedOptions(selectElementId, cuit, selectedPOS) {
        Campaigns.serviceCenterPointsOfSale({campaignId: $scope.table.campaignId, cuit:cuit}, function(pointsOfSale) {
            selectHTML = "<select>"

            var isSelected = (selectedPOS == undefined || selectedPOS == null );
            selectHTML += "<option value='' " + (isSelected ? "selected='selected'" : "") + ">----</option>";

            for (var j = 0; j < pointsOfSale.length; j++) {
                var isSelected = (selectedPOS == pointsOfSale[j].idSap);
                selectHTML += "<option value='" + pointsOfSale[j].idSap + "' " + (isSelected ? "selected='selected'" : "") + ">" + pointsOfSale[j].idSap + "</option>";
            }
            selectHTML += "</select>"

            if ($('#' + selectElementId).length > 0) {
                $('#' + selectElementId).html(selectHTML);
            }
        });

    }

    function getCuit(rowId, $scope) {
        var data = $scope.grid().getRowData(rowId);
        return data[$scope.serviceCenterColumnName];
    }

    function getDefaultColumnModelForIdColumn() {
        var aColModel = new Object();
        aColModel.name = "mpsInternalId";
        aColModel.index = "mpsInternalId";
        aColModel.key = true;
        aColModel.search = false;
        aColModel.editable = false;
        aColModel.hidden = true;
        aColModel.sortable = false;
        return aColModel;
    }

    function getBoolean(data) {
        return (data == "true" || data == true) ? true : false;
    }

    function clearCustomSearchColumns() {
        var defaultOption = '---';
        for (var i = 0; i < customSearchColumnNames.length; i++) {
            var defOption = $("option:contains(" + defaultOption + ")", $("#gs_" + customSearchColumnNames[i]));
            defOption.attr("selected", "selected");
        }
    }

    function exportToExcel() {
        $scope.grid().jqGrid('excelExport', {url: $scope.exportUrl});
    }
};
