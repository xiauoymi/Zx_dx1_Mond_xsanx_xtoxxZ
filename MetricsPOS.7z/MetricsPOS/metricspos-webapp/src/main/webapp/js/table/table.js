/**
 * Logic for the data table Entity
 */

applicationModule.factory('Tables', function($resource){

    var tableRes = $resource(DATA_BASE + '/campaigns/:campaignId/tables/:tableId', {campaignId: '@campaignId', tableId: '@id'},
        { 'update': {method:'PUT'}
        , 'remove': {method:'DELETE'}
        , 'removeAll' : {method:'DELETE' , subPath: '/rows/deleteAll'}
        , 'metadata': {method:'GET', subPath: '/metadata', isArray: true}
        , 'dataLoad': {method:'POST', subPath: '/rows/load'}
        }
    );

    return tableRes;
});


var TableController = function( $scope, $http, $routeParams, $location, Campaigns, Tables, $$dateService) {
    var tableId = $routeParams.tableId;

    $scope.table = Tables.get( {campaignId: $routeParams.campaignId, tableId: tableId}, function(table) {
        $scope.campaign = Campaigns.goTo( table.campaignId, true);
    });

    $scope.metadata = Tables.metadata({campaignId: $routeParams.campaignId, tableId: tableId});
};
