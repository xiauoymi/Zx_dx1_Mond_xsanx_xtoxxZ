var TableDataLoadController = function($scope, $http, $routeParams, $location, Campaigns, Tables, $$dateService, dialogs, messageConverter, msMessageService) {

    var tableId = $routeParams.tableId;

        $scope.refreshCodeMirrorAll = function() {
        setTimeout(function() {
            var cm = $('#code-mirror1')[0].nextSibling.CodeMirror;
            cm.refresh();
            var cm2 = $('#code-mirror2')[0].nextSibling.CodeMirror;
            cm2.refresh();
        }, 500);
    };

    $http.get(DATA_BASE + '/tables/dataTypes').success(function(data) {
        $scope.dataTypes = data;
    });

    $scope.metadata = Tables.metadata({campaignId: $routeParams.campaignId, tableId: tableId}, function(data) {
        if (! angular.isArray(data) || data.length == 0) {
            $scope.metadata = [];
            $scope.addColumn();
        } else {
            $scope.metadata = data;
        }
    });

    $scope.accordionOptions = { autoHeight: false, collapsible: true, active: 2, clearStyle: false };

    function goToCampaign(table) {  // TODO Add confirmation message (message types)
        $location.path('/campaign/' + $scope.campaign.id + '/tables');
    }

    if ($routeParams.tableId) {
        // Edit table
        Tables.get({campaignId: $routeParams.campaignId, tableId: $routeParams.tableId}, function(table) {
            $scope.table = table;
            $scope.campaign = Campaigns.goTo(table.campaignId);
            $scope.hasTable = true;
            $scope.refreshCodeMirrorAll();
        });

        $scope.save = function() {
            $scope.table.$update(function() {
                msMessageService.showInfo('Se han guardado los cambios en el proceso de carga de la tabla');
            });
        };

        $scope.execute = function() {
            $scope.table.$dataLoad(function() {
                msMessageService.showInfo('Se ejecuto el proceso de carga de datos de la tabla');
            });
        };

        $scope.clearTable = function() {
            dialogs.confirm('Vaciar tabla', 'Desea borrar todos los registros de la tabla? ', function() {
                Tables.removeAll({campaignId: $routeParams.campaignId, tableId: tableId}, function(){
                    msMessageService.showInfo('Se han eliminado los registros.');
                });
            });
        };

    } else {
        var campaignId = $routeParams.campaignId;
        // TODO check for missing or invalid !!
        $scope.campaign = Campaigns.get({campaignId: campaignId});

        $scope.table = { campaignId: campaignId };

        $scope.hasTable = true;
        $scope.save = function() {
            Tables.save($scope.table, goToCampaign);
        };
    }

    $scope.cancel = goToCampaign;

}