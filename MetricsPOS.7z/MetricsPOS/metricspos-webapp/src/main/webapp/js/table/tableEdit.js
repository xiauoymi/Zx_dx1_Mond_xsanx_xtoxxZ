/**
 * Logic for editing a Data table
 */
var TableEditController = function( $scope, $http, $routeParams, $location, Campaigns, Tables, $$dateService, dialogs, messageConverter, msMessageService) {

    var tableId = $routeParams.tableId;

    $http.get(DATA_BASE + '/tables/providers').success(function(data) {
        $scope.providers = data;
    });

    function goToCampaign(table) {  // TODO Add confirmation message (message types)
        $location.path('/campaign/' + $scope.campaign.id + '/tables');
    }

    if ( tableId ) {
        // Edit table
        $scope.table = Tables.get( {campaignId: $routeParams.campaignId, tableId: tableId}, function(table) {
            $scope.campaign = Campaigns.goTo( table.campaignId );
            $scope.hasTable = true;
        });

        $scope.save = function() {
            $scope.table.$update(function(){
                msMessageService.showInfo('Se han guardado con éxito los cambios');
            });
        };

        $scope.remove = function() {
                // TODO Mensaje i18n !!
            dialogs.confirm('Tabla ' + $scope.table.name, '$table.delete', function() {
                $scope.table.$remove(goToCampaign);
            });
        }

    } else {
        var campaignId = $routeParams.campaignId;
        // TODO check for missing or invalid !!
        $scope.campaign = Campaigns.get( {campaignId: campaignId} );

        $scope.table = { campaignId: campaignId };

        $scope.hasTable = true;
        $scope.save = function() {
            Tables.save( $scope.table, goToCampaign );
        };
    }

    $scope.cancel = goToCampaign;
}
