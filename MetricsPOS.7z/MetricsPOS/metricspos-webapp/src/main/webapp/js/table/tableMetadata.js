var TableMetadataController = function($scope, $http, $routeParams, $location, Tables, Campaigns, dialogs, msMessageService) {
    var tableId = $routeParams.tableId;

    Campaigns.goTo($routeParams.campaignId, true, function(data, status) {
        $scope.campaign = data;
        $scope.table = Tables.get({campaignId: $routeParams.campaignId, tableId: tableId});
    });


    $http.get(DATA_BASE + '/tables/dataTypes').success(function(data) {
        $scope.dataTypes = data;
        $scope.dataTypesNoSC = new Array($scope.dataTypes.length - 1);

        var j = 0;
        for (var i = 0; i < $scope.dataTypes.length; i++) {
            if (!('SC' === $scope.dataTypes[i].code)) {
                $scope.dataTypesNoSC[j] = $scope.dataTypes[i];
                j++;
            }
        }

        // We need first the data types before populating the columns
        $scope.metadata = Tables.metadata({campaignId: $routeParams.campaignId, tableId: tableId}, function(data) {
            if (! angular.isArray(data) || data.length == 0) {
                $scope.metadata = [];
                $scope.addColumn();
            } else {
                $scope.metadata = data;
            }
        });
    });

    /**
     * Find the data type of the column
     * @param column
     */
    $scope.dataTypeOf = function(column) {
        var typeCode = column.type;

        var length = $scope.dataTypes.length;
        for (var i = 0; i < length; i++) {
            if (typeCode === $scope.dataTypes[i].code) {
                return $scope.dataTypes[i];
            }
        }

        return $scope.dataTypes[ 0 ];   // TODO throw exception?
    };

    /**
     * Add a new column
     */
    $scope.addColumn = function() {
        $scope.metadata.push({ name: "new", type: $scope.dataTypes[0].code,
            size: 1, minSize: 0, precision: 0, required: false, hidden: false, sortable: true, filterable: true });
    }

    /**
     * Remove an existing column
     */
    $scope.removeColumn = function(column) {
        $scope.disableCurrentEditing();

        dialogs.confirm("Columna " + column.name, "¿Desea eliminarla? (Se perderán todos los datos existentes de dicha columna)",
            $scope, function() {
                var index = $scope.metadata.indexOf(column);

                if (index >= 0) {
                    $scope.metadata.splice(index, 1);
                }
            });
    };

    $scope.save = function(success) {
        $http.put(DATA_BASE + '/campaigns/' + $routeParams.campaignId + '/tables/' + tableId + '/metadata', $scope.metadata).success(function(data) {
            msMessageService.showInfo('Se guardó la tabla ' + $scope.table.name);
            if (success) {
                success(data);
            }
        });
    };

    $scope.saveAndReturn = function() {
        $scope.save($scope.cancel);
    };

    $scope.cancel = function() {
        $location.path('/campaign/' + $routeParams.campaignId + '/table/' + tableId);
    };

    var focusedRowScope = null;

    $scope.disableCurrentEditing = function() {
        if (focusedRowScope) {
            // Disable current editing
            focusedRowScope.editing = false;
        }

    };

    /**
     * If argument set, change the current row scope.
     * Returns the current row scope (after change)
     * @param newScope
     */
    $scope.focusedRowScope = function(newScope) {
        if (newScope) {
            focusedRowScope = newScope;
        }

        return focusedRowScope;
    };

    $scope.swapColumnWithNext = function(column) {
        var index = $scope.metadata.indexOf(column);
        if (index < $scope.metadata.length - 1) {
            var aux = $scope.metadata[index + 1];
            $scope.metadata[index + 1] = column;
            $scope.metadata[index] = aux;
        }
    }

    $scope.swapColumnWithPrevious = function(column) {
        var index = $scope.metadata.indexOf(column);
        if (index > 0) {
            var aux = $scope.metadata[index - 1];
            $scope.metadata[index - 1] = column;
            $scope.metadata[index] = aux;
        }
    }

    $scope.isLast = function(column) {
        return $scope.metadata.indexOf(column) >= $scope.metadata.length - 1;
    }

    $scope.isFirst = function(column) {
        return $scope.metadata.indexOf(column) <= 0;
    }
}

/**
 * Called in child (row) scopes to change the editing status of the row
 */
TableMetadataController.edit = function() {
    var rowScope = this.rowScope();
    var focusedRowScope = this.focusedRowScope();

    if (focusedRowScope != rowScope) {
        // Finish editing other row
        this.disableCurrentEditing();

        // Change focus row
        focusedRowScope = this.focusedRowScope(rowScope);
    }

    // toggle editing
    focusedRowScope.editing = ! focusedRowScope.editing;
};

var MetadataRowController = function($scope) {
    $scope.dataType = $scope.$parent.dataTypeOf($scope.column);

    $scope.edit = TableMetadataController.edit;

    /**
     * Returns the row level scope.
     * Needed for widgets that can reside on child scopes
     */
    $scope.rowScope = function() {
        return $scope;
    }

    if (! $scope.column.id) {
        // If adding a column, go to edit mode
        $scope.edit();
    }
}

applicationModule.directive('mwNoSpaces', function() {
        return {
            restrict: 'A', // supports using directive as element, attribute and class
            link: function($scope, element, attrs) {
                element.keypress(function (e) {
                    if (e.which > 0 && // check that key code exists
                        e.which != 8 && // allow backspace
                        !(e.which >= 48 && e.which <= 57) && // allow 0-9
                        !(e.which >= 65 && e.which <= 91) && // allow A-Z
                        !(e.which >= 97 && e.which <= 122)   // allow a-z
                        ) {
                        // If I'm here then a character that's not allowed was pressed so I won't do a thing
                        e.preventDefault();
                    }
                    else {
                        // Everything is allright so I'll allow the writing to continue
                    }
                });
            }}
    }
);