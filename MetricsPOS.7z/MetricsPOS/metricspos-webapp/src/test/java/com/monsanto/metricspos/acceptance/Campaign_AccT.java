package com.monsanto.metricspos.acceptance;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.MapAssert.entry;

/**
 * User: PPERA
 */
public class Campaign_AccT {
    private static final Logger log = Logger.getLogger(Campaign_AccT.class);

    private static final TypeReference MAP_TYPE = new TypeReference<Map<String, Object>>() {
    };
    private static final TypeReference LIST_OF_MAP_TYPE = new TypeReference<List<Map<String, Object>>>() {
    };

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    public void testCreateCampaign() throws IOException {
        // @Given No existing campaigns

        // @When a new campaign is created
        String message = JsonBuilder.object().property("name", "charly").property("since", "2011-08-24T00:00:00.000Z").property("until", "2012-08-24T00:00:00.000Z").toString();

        log.debug(message);

        // Set the Content-Type header
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(new MediaType("application", "json"));
        HttpEntity<String> requestEntity = new HttpEntity<String>(message, requestHeaders);

        log.debug(requestEntity);
        log.debug(requestHeaders);

        RestTemplate restTemplate = new RestTemplate();

        restTemplate.postForEntity("http://localhost:9090/metricspos/app/campaigns", requestEntity, String.class).getBody();
        String responseBody = restTemplate.getForEntity("http://localhost:9090/metricspos/app/campaigns", String.class).getBody();
        log.debug(responseBody);
        List<Map<String, Object>> results = objectMapper.readValue(responseBody, LIST_OF_MAP_TYPE);

        // @Then the campaign was created
        assertThat(results).isNotEmpty();

        List<Map<String,Object>> filtered = Lists.newArrayList(Collections2.filter(results, new Predicate<Map<String, Object>>() {
            @Override
            public boolean apply(Map<String, Object> input) {
                return input.get("name") != null && input.get("name").equals("charly");
            }
        }));

        assertThat(filtered.get(0)).includes(entry("name", "charly"), entry("since", "2011-08-24T00:00:00Z"), entry("until", "2012-08-24T00:00:00Z"));
    }

    @Test
    public void testCreateAModule() throws IOException {
        String message = JsonBuilder.object().property("name", "firstModule").property("enabled", "true").property("maxPoints","200").toString();

        // Set the Content-Type header
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(new MediaType("application", "json"));
        HttpEntity<String> requestEntity = new HttpEntity<String>(message, requestHeaders);

        RestTemplate restTemplate = new RestTemplate();

        restTemplate.postForEntity("http://localhost:9090/metricspos/app/campaigns/1/metrics", requestEntity, String.class).getBody();
        String responseBody = restTemplate.getForEntity("http://localhost:9090/metricspos/app/metrics", String.class).getBody();
        log.debug(responseBody);
        List<Map<String, Object>> results = objectMapper.readValue(responseBody, LIST_OF_MAP_TYPE);

        // @Then the campaign was created
        assertThat(results).isNotEmpty();

        List<Map<String,Object>> filtered = Lists.newArrayList(Collections2.filter(results, new Predicate<Map<String, Object>>() {
            @Override
            public boolean apply(Map<String, Object> input) {
                return input.get("name") != null && input.get("name").equals("firstModule");
            }
        }));

        // @Then the metric was created
        assertThat(filtered.get(0).get("id")).isNotNull();
        assertThat(filtered.get(0)).includes(entry("name", "firstModule"), entry("enabled", true));
    }

    @Test
    public void testFindAServiceCenter() throws IOException {
        // Set the Content-Type header
        HttpHeaders requestHeaders = new HttpHeaders();
        requestHeaders.setContentType(new MediaType("application", "json"));

        RestTemplate restTemplate = new RestTemplate();

        String responseBody = restTemplate.getForEntity("http://localhost:9090/metricspos/app/campaigns/1/serviceCenters/101010101", String.class).getBody();
        log.debug(responseBody);
        Map<String, Object> results = objectMapper.readValue(responseBody, MAP_TYPE);

        log.debug(responseBody);

        // @Then the metric was created
        assertThat(results.get("cuit")).isNotNull();
        assertThat(results.get("cuit")).isEqualTo("101010101");
    }
}
