package com.monsanto.metricspos.acceptance;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.List;
import java.util.Map;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.MapAssert.entry;

/**
 * User: PPERA
 */
public class EnvironmentAvailable_AccT {
    private static final Logger log = Logger.getLogger(EnvironmentAvailable_AccT.class);

    private static final TypeReference LIST_OF_MAP_TYPE = new TypeReference<List<Map<String, Object>>>() { };

    private final ObjectMapper objectMapper = new ObjectMapper();


    // The WebContainer is available

    @Test
    public void testTheContainerIsAvailable() throws Exception {
        URL url = new URL("http", "localhost", 9090, "/metricspos/index.jsp");

        String page = this.getPageContent(url);

        log.debug(page);

        assertThat(page).isNotEmpty().contains("<html>");
    }

    private String getPageContent(URL url) throws IOException {
        InputStream inputStream = url.openStream();

        BufferedReader input = new BufferedReader(new InputStreamReader(inputStream));

        String line;
        StringBuilder sb = new StringBuilder();
        while ((line = input.readLine()) != null) {
            sb.append(line);
        }

        return sb.toString();
    }

    @Test
    public void testTheDatabaseIsAvailable() throws Exception {
        URL url = new URL("http", "localhost", 9090, "/metricspos/app/campaigns");
        String page = this.getPageContent(url);
        log.debug(page);

        assertThat(page).isNotEmpty();
    }

    @Test
    public void testDatesAreSerializedAsJsonDates() throws Exception {
        URL url = new URL("http", "localhost", 9090, "/metricspos/app/campaigns");

        // When
        String page = this.getPageContent(url);

        // Then
        log.debug(page);

        // 2011-04-01
        // 2012-03-31

        List<Map<String, Object>> actualResults = objectMapper.readValue(page, LIST_OF_MAP_TYPE);

        Map<String, Object> firstResult = actualResults.get(0);
        assertThat(firstResult).includes(
                entry("since", "2011-04-01T00:00:00Z"),
                entry("until", "2012-03-31T00:00:00Z"));

    }
}
