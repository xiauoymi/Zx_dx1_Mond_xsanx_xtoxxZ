package com.monsanto.metricspos.acceptance;

import com.google.common.collect.Maps;

import java.util.Map;

/**
 * User: PPERA
 */
public class JsonBuilder {
    private final Map<String, String> properties;

    private JsonBuilder() {
        this.properties = Maps.newHashMap();
    }

    public static JsonBuilder object(){
        return new JsonBuilder();
    }

    public JsonBuilder property(String name, String cacho) {
        this.properties.put(name, cacho);
        return this;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        boolean firstComma = true;

        sb.append('{');
        for(String key: properties.keySet()){
            if( firstComma){
                firstComma = false;
            }else{
                sb.append(',');
            }

            sb.append('"').append(key).append("\":\"").append(properties.get(key)).append('"');
        }

        sb.append('}');
        return sb.toString();
    }
}
