package com.monsanto.metricspos.acceptance;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.junit.Test;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.MapAssert.entry;

/**
 * User: PPERA
 */
public class Table_AccT {
    private static final Logger log = Logger.getLogger(Table_AccT.class);

    private static final TypeReference MAP_TYPE = new TypeReference<Map<String, Object>>() {
    };
    private static final TypeReference LIST_OF_MAP_TYPE = new TypeReference<List<Map<String, Object>>>() {
    };

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Test
    public void testViewTable() throws IOException {
        // @Given an existing table

        // @When the table is viewed
        RestTemplate restTemplate = new RestTemplate();

        String responseBody = restTemplate.getForEntity("http://localhost:9090/metricspos/app/tables/1", String.class).getBody();
        log.debug(responseBody);
        Map<String, Object> results = objectMapper.readValue(responseBody, MAP_TYPE);

        // @Then table returns
        assertThat(results.get("id")).isNotNull();

        assertThat(results).includes(entry("name", "TEST_TABLE"));
    }

    @Test
    public void testViewMetadata() throws IOException {
        // @Given an existing table

        // @When viewing the metadata
        RestTemplate restTemplate = new RestTemplate();

        String responseBody = restTemplate.getForEntity("http://localhost:9090/metricspos/app/tables/1/metadata", String.class).getBody();
        log.debug(responseBody);
        List<Map<String, Object>> results = objectMapper.readValue(responseBody, LIST_OF_MAP_TYPE);

        // @Then the table's columns are returned
        assertThat(results).hasSize(8);

        Map<String, Object> result = results.get(0);

        assertThat(result.get("id")).isNotNull();
        assertThat(result).includes(entry("name", "SERVICECENTER"));
    }

    @Test
    public void testListProviders() throws IOException {
        // @Given an existing table

        // @When viewing the metadata
        RestTemplate restTemplate = new RestTemplate();

        String responseBody = restTemplate.getForEntity("http://localhost:9090/metricspos/app/tables/providers", String.class).getBody();
        log.debug(responseBody);
        List<Map<String, Object>> results = objectMapper.readValue(responseBody, LIST_OF_MAP_TYPE);

        // @Then the table's columns are returned
        assertThat(results).hasSize(2);

        log.debug(results);

        Map<String, Object> result = results.get(0);

        assertThat(result.get("code")).isNotNull();
        assertThat(result).includes(entry("code", "CRM"));
    }
}
