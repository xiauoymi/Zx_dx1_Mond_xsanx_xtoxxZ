package com.monsanto.metricspos.boundary.errors;

import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.ui.ModelMap;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class ErrorMessagesView_UT {

    @Test
    public void testRender() throws Exception {
        // @Given an exception ocurred in the application
        ModelMap model = new ModelMap();

        RuntimeException ex = new RuntimeException("The All is lost moment!");

        model.addAttribute("exception", ex);
        model.addAttribute("status", 500);

        ObjectMapper objectMapper = new ObjectMapper();
        ErrorMessagesView errorMessagesView = new ErrorMessagesView();
        errorMessagesView.setObjectMapper(objectMapper);

        // @When rendering the view
        MockHttpServletResponse response = new MockHttpServletResponse();
        errorMessagesView.render(model, new MockHttpServletRequest(), response);

        // @Then the errors were written in the response and the status was set
        assertThat(response.getStatus()).isEqualTo(500);
        assertThat(response.getContentAsString()).contains(ex.getMessage());
    }
}
