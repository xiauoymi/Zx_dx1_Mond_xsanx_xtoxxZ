package com.monsanto.metricspos.boundary.errors;

import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import org.apache.log4j.Logger;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;

/**
 * User: PPERA
 */
public class MetricPosHandlerExceptionResolver_UT {

    @Test
    public void testDoResolveException() {
        // @Given the handler intercepted an exception
        RuntimeException e = new RuntimeException("Don't hesitate, this is only for a Unit Test");

        // @When the exception is resolved
        MetricPosHandlerExceptionResolver metricPosHandlerExceptionResolver = new MetricPosHandlerExceptionResolver();

        Logger auditLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(metricPosHandlerExceptionResolver).set(auditLog);

        Object handler = new Object();
        MockHttpServletResponse response = new MockHttpServletResponse();
        ModelAndView modelAndView = metricPosHandlerExceptionResolver.doResolveException(new MockHttpServletRequest(), response, handler, e);

        // @Then the view returned is errorMessages and the exception and the status are in the model
        assertThat(modelAndView.getViewName()).isEqualTo("errorMessages");
        assertThat(modelAndView.getModelMap().get("exception")).isEqualTo(e);
        // assertThat(modelAndView.getModelMap().get("status")).isEqualTo(500);
    }

    @Test
    public void testDoResolveException_WhenBusinessException() {
        // @Given the handler intercepted an exception
        BusinessException e = new BusinessException("Don't hesitate, this is only for a Unit Test", 418);

        // @When the exception is resolved
        MetricPosHandlerExceptionResolver metricPosHandlerExceptionResolver = new MetricPosHandlerExceptionResolver();
        Logger auditLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(metricPosHandlerExceptionResolver).set(auditLog);
        Object handler = new Object();
        MockHttpServletResponse response = new MockHttpServletResponse();
        ModelAndView modelAndView = metricPosHandlerExceptionResolver.doResolveException(new MockHttpServletRequest(), response, handler, e);

        // @Then the view returned is errorMessages and the exception and the status are in the model
        assertThat(modelAndView.getViewName()).isEqualTo("errorMessages");
        assertThat(modelAndView.getModelMap().get("exception")).isEqualTo(e);
        assertThat(modelAndView.getModelMap().get("status")).isEqualTo(e.getErrorCode());
    }

    @Test
    public void testDoResolveException_WhenBusinessExceptionInRunTime() {
        // @Given the handler intercepted an exception
        BusinessException e = new BusinessException("Don't hesitate, this is only for a Unit Test", 418, new Exception());

        // @When the exception is resolved
        MetricPosHandlerExceptionResolver metricPosHandlerExceptionResolver = new MetricPosHandlerExceptionResolver();
        Logger auditLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(metricPosHandlerExceptionResolver).set(auditLog);
        Object handler = new Object();
        MockHttpServletResponse response = new MockHttpServletResponse();
        ModelAndView modelAndView = metricPosHandlerExceptionResolver.doResolveException(new MockHttpServletRequest(), response, handler, e);

        // @Then the view returned is errorMessages and the exception and the status are in the model
        assertThat(modelAndView.getViewName()).isEqualTo("errorMessages");
        assertThat(modelAndView.getModelMap().get("exception")).isEqualTo(e);
        assertThat(modelAndView.getModelMap().get("status")).isEqualTo(e.getErrorCode());
    }
}
