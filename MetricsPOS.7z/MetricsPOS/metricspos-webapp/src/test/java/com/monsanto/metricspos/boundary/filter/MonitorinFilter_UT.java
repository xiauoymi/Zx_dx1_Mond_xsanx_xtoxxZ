package com.monsanto.metricspos.boundary.filter;

import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.services.security.impl.UserWrapperImpl;
import net.bull.javamelody.Parameter;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import org.springframework.security.Authentication;
import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.providers.UsernamePasswordAuthenticationToken;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.*;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * User: SHELG
 */
public class MonitorinFilter_UT {

    private FilterConfig config;
    private MetricsPosMonitoringFilter monitoringFilter;

    static final String PART_PARAMETER = "part";
    static final String PROCESSES_PART = "processes";
    static final String SESSIONS_PART = "sessions";

    /**
     * Initialisation.
     */
    @Before
    public void setUp() throws ServletException {
        config = mock(FilterConfig.class);
        ServletContext context = mock(ServletContext.class);
        when(config.getServletContext()).thenReturn(context);
        // anyTimes sur getInitParameter car TestJdbcDriver a pu fixer la propriÃ©tÃ© systÃ¨me Ã  false
        when(context.getInitParameter("javamelody."
                        + Parameter.DISABLED.getCode())).thenReturn(null);
        when(config.getInitParameter(Parameter.DISABLED.getCode())).thenReturn(null);
        when(context.getMajorVersion()).thenReturn(2);
        when(context.getMinorVersion()).thenReturn(5);
        when(context.getServerInfo()).thenReturn("Mockito");
        when(context.getContextPath()).thenReturn("/test");

        monitoringFilter = new MetricsPosMonitoringFilter();

        monitoringFilter.init(config);
    }

    @Test
    public void testAccessMonitoring() throws Exception {
        AdminUser user = new AdminUser();
        Authentication auth = new UsernamePasswordAuthenticationToken(new UserWrapperImpl(user, null),null);
        SecurityContextHolder.getContext().setAuthentication(auth);

        final Map<String, String> parameters = new HashMap<String, String>();
        parameters.put("format", "application/json");
        monitoring(parameters);
        parameters.put(PART_PARAMETER, SESSIONS_PART);
        monitoring(parameters);
        parameters.put(PART_PARAMETER, PROCESSES_PART);

        monitoring(parameters);

        assertNotNull(monitoringFilter);
    }



    private void monitoring(Map<String, String> parameters) throws IOException, ServletException {
        setUp();

        try {
            final HttpServletRequest request = mock(HttpServletRequest.class);
            when(request.getRequestURI()).thenReturn("/test/monitoring");
            when(request.getContextPath()).thenReturn("/test");
            final Random random = new Random();
            if (random.nextBoolean()) {
                when(request.getHeaders("Accept-Encoding")).thenReturn(
                        Collections.enumeration(Arrays.asList("application/gzip")));
            } else {
                when(request.getHeaders("Accept-Encoding")).thenReturn(
                        Collections.enumeration(Arrays.asList("text/html")));
            }
            for (final Map.Entry<String, String> entry : parameters.entrySet()) {
                when(request.getParameter(entry.getKey())).thenReturn(entry.getValue());
            }
            final HttpServletResponse response = mock(HttpServletResponse.class);
            final ByteArrayOutputStream output = new ByteArrayOutputStream();
            final StringWriter stringWriter = new StringWriter();
            when(response.getWriter()).thenReturn(new PrintWriter(stringWriter));
            final FilterChain chain = mock(FilterChain.class);

            monitoringFilter.init(config);
            monitoringFilter.doFilter(request, response, chain);

        }  finally {
            monitoringFilter.destroy();
        }
    }


}
