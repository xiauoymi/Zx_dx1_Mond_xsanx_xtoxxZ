package com.monsanto.metricspos.boundary.helpers;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.application.vo.MetricVO;
import com.monsanto.metricspos.core.externaldata.DataColumn;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.externaldata.DataTable;
import com.monsanto.metricspos.core.externaldata.DataType;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.CampaignState;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;

import java.util.Date;
import java.util.List;

/**
 * User: PPERA
 */
public class WebAppTestsHelper {

    private DataProvider dataProvider;
    private Campaign campaign;
    private DataRowPersistorFactory dataRowPersistorFactory;

    public WebAppTestsHelper(DataProvider dataProvider, Campaign campaign, DataRowPersistorFactory dataRowPersistorFactory) {
        this.dataProvider = dataProvider;
        this.campaign = campaign;
        this.dataRowPersistorFactory = dataRowPersistorFactory;
    }

    public Metric newMetric(String name) {
        return new Metric(this.campaign, name);
    }

    public MetricVO newMetricVO(String name) {
        MetricVO metricVO = new MetricVO();
        metricVO.setName(name);
        return metricVO;
    }

    public MetricVO newMetricVO(Integer id, String name, Integer maxPoints) {
        MetricVO metricVO = new MetricVO();
        metricVO.setId(id);
        metricVO.setName(name);
        metricVO.setMaxPoints(maxPoints);
        return metricVO;
    }

    public Campaign newCampaign(String name, Date since, Date until) {
        return new Campaign(name, since, until);
    }

    public CampaignVO newCampaignVO(String name, Date since, Date until, CampaignState created) {
        CampaignVO campaignVO = new CampaignVO();
        campaignVO.setName(name);
        campaignVO.setSince(since);
        campaignVO.setUntil(until);
        campaignVO.setState(created);
        campaignVO.setMetrics(Lists.transform(campaign.getMetrics(), new Function<Metric, MetricVO>() {
            @Override
            public MetricVO apply(Metric input) {
                return newMetricVO(input.getName());
            }
        }));
        return campaignVO;
    }

    public CampaignVO newCampaignVO(int id, String name, Date since, Date until, CampaignState created) {
        CampaignVO campaignVO = newCampaignVO(name, since, until, created);
        campaignVO.setId(id);

        return campaignVO;
    }

    public DataTable newDataTable(int id, String tableName, String description, List<DataColumn> columns) {
        DataTable dataTable = new DataTable(tableName, columns, dataRowPersistorFactory);
        dataTable.setId(id);
        dataTable.setDescription(description);
        dataTable.setCampaign(campaign);
        dataTable.setDataProvider(dataProvider);
        return dataTable;
    }

    public DataTableVO newDataTableVO(String name, String description) {
        DataTableVO dataTableVO = new DataTableVO();
        dataTableVO.setName(name);
        dataTableVO.setDescription(description);
        dataTableVO.setProvider(dataProvider.getCode());
        dataTableVO.setCampaignId(campaign.getId());

        return dataTableVO;
    }

    public DataTableVO newDataTableVO(Integer id, String name, String description) {
        DataTableVO dataTableVO = newDataTableVO(name, description);
        dataTableVO.setId(id);
        return dataTableVO;
    }

    public DataColumn newDataColumn(String columnName) {
        return new DataColumn(columnName, stringDataType());
    }

    public DataColumnVO newDataColumnVO(String nameColumnName, String dataTypeCode, String columnDescription, int size, int minSize, int precision, boolean required, boolean sortable, boolean editable, boolean filterable) {
        DataColumnVO nameColumn = new DataColumnVO();
        nameColumn.setName(nameColumnName);
        nameColumn.setType(dataTypeCode);
        nameColumn.setDescription(columnDescription);
        nameColumn.setSize(size);
        nameColumn.setMinSize(minSize);
        nameColumn.setPrecision(precision);
        nameColumn.setRequired(required);
        nameColumn.setSortable(sortable);
        nameColumn.setEditable(editable);
        nameColumn.setFilterable(filterable);
        return nameColumn;
    }

    public ServiceCenter newServiceCenter(String cuit) {
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCampaign(campaign);
        serviceCenter.setCuit(cuit);
        campaign.add(serviceCenter);
        return serviceCenter;
    }

    public DataProvider newDataProvider(String code, String name) {
        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode(code);
        dataProvider.setName(name);
        return dataProvider;
    }

    public DataType stringDataType() {
        DataType dataType = new DataType();
        dataType.setCode("string");
        dataType.setName("Text");
        dataType.setFilterable(true);
        dataType.setHasMinSize(true);
        dataType.setHasOptions(true);
        dataType.setHasPrecision(true);
        dataType.setHasSize(true);
        dataType.setSortable(true);
        dataType.setInternalType(String.class);
        return dataType;
    }
}
