package com.monsanto.metricspos.boundary.security;

import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.springframework.aop.framework.ReflectiveMethodInvocation;
import org.springframework.security.AccessDecisionManager;
import org.springframework.security.Authentication;
import org.springframework.security.ConfigAttributeDefinition;

import java.lang.reflect.Method;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class CustomAccessDecisionManager_UT {

    private CustomAccessDecisionManager customAccessDecisionManager;
    private ConfigAttributeDefinition configAttributeDefinition;
    private AccessDecisionManager accessDecisionManager;

    @Before
    public void setUp() {
        String[] attributes = {"CONFIG_(0)", "CONFIG_(1)_HELLO", "CONFIG_(1)_(0)"};
        this.customAccessDecisionManager = new CustomAccessDecisionManager();
        this.configAttributeDefinition = new ConfigAttributeDefinition(attributes);
        this.accessDecisionManager = mock(AccessDecisionManager.class);
        this.customAccessDecisionManager.setAccessDecisionManagerDelegate(this.accessDecisionManager);
    }

    @Test
    public void testDecide() {
        // @Given an authentication, a reflective method invocation and a ConfigAttributte definition
        Authentication authentication = mock(Authentication.class);
        String[] methodArguments = {"ARG0", "ARG1"};
        Object proxy = null;
        List<Object> interceptorsAndDynamicMethodMatchers = null;
        Class targetClass = null;
        Method method = null;
        Object target = null;
        ReflectiveMethodInvocation reflectiveMethodInvocation = new ReflectiveMethodInvocationStub(proxy, target, method, methodArguments, targetClass, interceptorsAndDynamicMethodMatchers);

        // @When deciding whether to grant access to the authorized principal
        this.customAccessDecisionManager.decide(authentication, reflectiveMethodInvocation, configAttributeDefinition);

        // @Then the accessDecisionManagerDelegate.decide method is called with the same authorization and ReflectiveMethodInvocation
        verify(this.accessDecisionManager, times(1)).decide(eq(authentication), eq(reflectiveMethodInvocation), argThat(new ArgumentMatcher<ConfigAttributeDefinition>() {
            @Override
            public boolean matches(Object argument) {
                assertThat(((ConfigAttributeDefinition) argument).getConfigAttributes()).onProperty("attribute").contains("CONFIG_ARG0", "CONFIG_ARG1_HELLO", "CONFIG_ARG1_ARG0");
                return true;
            }
        }));
    }

    public class ReflectiveMethodInvocationStub extends ReflectiveMethodInvocation{

        /**
         * Construct a new ReflectiveMethodInvocation with the given arguments.
         *
         * @param proxy       the proxy object that the invocation was made on
         * @param target      the target object to invoke
         * @param method      the method to invoke
         * @param arguments   the arguments to invoke the method with
         * @param targetClass the target class, for MethodMatcher invocations
         * @param interceptorsAndDynamicMethodMatchers
         *                    interceptors that should be applied,
         *                    along with any InterceptorAndDynamicMethodMatchers that need evaluation at runtime.
         *                    MethodMatchers included in this struct must already have been found to have matched
         *                    as far as was possibly statically. Passing an array might be about 10% faster,
         *                    but would complicate the code. And it would work only for static pointcuts.
         */
        protected ReflectiveMethodInvocationStub(Object proxy, Object target, Method method, Object[] arguments, Class targetClass, List<Object> interceptorsAndDynamicMethodMatchers) {
            super(proxy, target, method, arguments, targetClass, interceptorsAndDynamicMethodMatchers);
        }
    }
}
