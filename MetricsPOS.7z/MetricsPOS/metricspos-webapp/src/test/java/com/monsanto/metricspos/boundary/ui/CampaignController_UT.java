package com.monsanto.metricspos.boundary.ui;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.boundary.helpers.WebAppTestsHelper;
import com.monsanto.metricspos.core.ComputeManager;
import com.monsanto.metricspos.core.DataLoader;
import com.monsanto.metricspos.core.MetricsApplication;
import com.monsanto.metricspos.core.ScoreServices;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.CampaignVO;
import com.monsanto.metricspos.core.application.vo.PointOfSaleVO;
import com.monsanto.metricspos.core.application.vo.ServiceCenterVO;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.metrics.*;
import com.monsanto.metricspos.core.metrics.summary.ScoreSummaryCampaignNode;
import com.monsanto.metricspos.core.structure.PointOfSale;
import com.monsanto.metricspos.core.structure.ServiceCenter;
import com.monsanto.metricspos.dao.support.PageRequest;
import com.monsanto.metricspos.persistence.ReflectiveDataRowPersistorFactory;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;
import org.springframework.web.context.request.WebRequest;

import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * Unit test the CampaignController class
 *
 * @author CAFAU
 */
public class CampaignController_UT {

    private MetricsApplication metricsApplication;
    private CampaignController campaignController;
    private WebAppTestsHelper webAppTestsHelper;
    private Campaign campaign;
    private DataLoader dataLoader;

    @Before
    public void setUp() {
        // @Given an empty campaign list
        this.campaignController = new CampaignController();
        this.metricsApplication = mock(MetricsApplication.class);
        this.dataLoader = mock(DataLoader.class);

        Logger auditLog = mock(Logger.class);
        Logger actionLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(this.campaignController).set(auditLog);
        field("actionLog").ofType(Logger.class).in(this.campaignController).set(actionLog);

        MetricFactory factory = new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                return new Metric(campaign, name);
            }
        };

        field("application").ofType(MetricsApplication.class).in(this.campaignController).set(this.metricsApplication);
        field("dataLoader").ofType(DataLoader.class).in(this.campaignController).set(this.dataLoader);
        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("CRM");
        dataProvider.setName("Client Relationship Manager");

        ReflectiveDataRowPersistorFactory dataRowPersistorFactory = new ReflectiveDataRowPersistorFactory();
        ComputeManager computeManager = mock(ComputeManager.class);
        campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign.setId(1);
        campaign.setFactory(factory);
        campaign.setComputeManager(computeManager);
        campaign.setMetrics(Lists.<Metric>newArrayList());

        webAppTestsHelper = new WebAppTestsHelper(dataProvider, campaign, dataRowPersistorFactory);
    }

    /* List campaigns */

    @Test
    public void testListCallsApplicationsListAllCampaigns_WhenListingCampaigns() throws Exception {
        // Given a campaign controller with a configured application

        // @When campaigns are listed
        campaignController.list();

        // @Then empty campaign list is provided
        verify(this.metricsApplication, times(1)).listAllCampaigns();
    }

    @Test
    public void testListReturnsMatchingCampaignList_WhenListingCampaigns() throws Exception {
        // Given a campaign controller with a configured application

        // @When campaigns are listed
        campaignController.list();

        // @Then empty campaign list is provided
        verify(this.metricsApplication, times(1)).listAllCampaigns();
    }

    @Test
    public void testListReturnsFourCampaigns_WhenApplicationReturnsThoseFourCampaigns() throws Exception {
        // @Given a campaign list not empty
        List<Campaign> campaigns = Lists.newArrayList(
                webAppTestsHelper.newCampaign("campaign1", newDate(2011, 1, 1), newDate(2011, 1, 11)),
                webAppTestsHelper.newCampaign("campaign2", newDate(2012, 2, 2), newDate(2012, 2, 12)),
                webAppTestsHelper.newCampaign("campaign3", newDate(2013, 3, 3), newDate(2013, 3, 13)),
                webAppTestsHelper.newCampaign("campaign4", newDate(2014, 4, 4), newDate(2014, 4, 14))
        );
        when(this.metricsApplication.listAllCampaigns()).thenReturn(campaigns);

        // @When campaigns are listed
        List<CampaignVO> resultCampaigns = campaignController.list();

        // @Then campaignVO list is provided
        assertThat(resultCampaigns).onProperty("name").containsExactly(campaigns.get(0).getName(), campaigns.get(1).getName(), campaigns.get(2).getName(), campaigns.get(3).getName());
        assertThat(resultCampaigns).onProperty("since").containsExactly(campaigns.get(0).getSince(), campaigns.get(1).getSince(), campaigns.get(2).getSince(), campaigns.get(3).getSince());
        assertThat(resultCampaigns).onProperty("until").containsExactly(campaigns.get(0).getUntil(), campaigns.get(1).getUntil(), campaigns.get(2).getUntil(), campaigns.get(3).getUntil());
    }

    @Test
    public void testListReturnsEmptyList_WhenApplicationListingAllCampaignsReturnsEmptyList() throws Exception {
        // @Given a campaign list not empty
        List<Campaign> campaigns = Lists.newArrayList();
        when(this.metricsApplication.listAllCampaigns()).thenReturn(campaigns);

        // @When campaigns are listed
        List<CampaignVO> resultCampaigns = campaignController.list();

        // @Then campaignVO list is provided
        assertThat(resultCampaigns).isEmpty();
    }

    /* View a campaign */
    @Test
    public void testViewCallsApplicationsFindCampaignByIdWithIdOne_WhenViewingCampaignWithIdOne() {
        // @Given an existing campaign with Id 1
        int campaignId = 1;
        when(this.metricsApplication.findCampaignById(campaignId, false)).thenReturn(this.campaign);

        // @When campaign is viewed
        campaignController.view(campaignId, false);

        // @Then findCamapaignById is called with the Id 1
        verify(this.metricsApplication, times(1)).findCampaignById(eq(campaignId), eq(false));
    }

    @Test
    public void testViewCallsApplicationsFindCampaignByIdWithIdTwo_WhenViewingCampaignWithIdTwo() {
        // @Given an existing campaign with Id 2
        int campaignId = 2;
        when(this.metricsApplication.findCampaignById(campaignId, false)).thenReturn(this.campaign);

        // @When campaign is viewed
        campaignController.view(campaignId, false);

        // @Then findCampaignById is called with the Id 2
        verify(this.metricsApplication, times(1)).findCampaignById(campaignId, false);
    }

    @Test
    public void testViewReturnsTheCampaignReturnedByTheApplication_WhenViewingExistingCampaign() {
        // @Given an existing campaign
        when(this.metricsApplication.findCampaignById(this.campaign.getId(), false)).thenReturn(this.campaign);

        // @When campaign is viewed
        CampaignVO campaignVO = campaignController.view(this.campaign.getId(), false);

        // @Then the campaignVO matches the campaign
        assertThat(campaignVO.getId()).isEqualTo(campaign.getId());
        assertThat(campaignVO.getState()).isEqualTo(campaign.getState());
        assertThat(campaignVO.getSince()).isEqualTo(campaign.getSince());
        assertThat(campaignVO.getUntil()).isEqualTo(campaign.getUntil());
        assertThat(campaignVO.getName()).isEqualTo(campaign.getName());
    }

    @Test
    public void testViewCallsApplicationsFindByIdWithWithChildrenAsTrue_WhenWithChildrenIsTrue() {
        // @Given an existing Campaign with children
        when(this.metricsApplication.findCampaignById(campaign.getId(), true)).thenReturn(campaign);

        // @When campaign is viewed
        campaignController.view(campaign.getId(), true);

        // @Then the method findCampaignById is called with the "withChildren" parameter set to true
        verify(this.metricsApplication, times(1)).findCampaignById(campaign.getId(), true);
    }

    @Test
    public void testCreateCallsApplicationsNewCampaignWithInputVOsData_WhenCreatingANewCampaign() {
        // @Given a campaignVO with no id of a campaignToBeCreated
        CampaignVO campaignVO = webAppTestsHelper.newCampaignVO(campaign.getName(), campaign.getSince(), campaign.getUntil(), CampaignState.CREATED);
        when(this.metricsApplication.newCampaign(campaignVO)).thenReturn(campaign);

        // @When the campaign is created
        campaignController.create(campaignVO);

        // @Then the campaign is persisted
        verify(this.metricsApplication, times(1)).newCampaign(campaignVO);
    }

    @Test
    public void testCreateThrowsException_WhenInputIsNull() {
        // @Given a null campaignVO
        CampaignVO campaignVO = null;

        // @When the campaign is created
        try {
            campaignController.create(campaignVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        }
    }

    /* Update/Edit a campaign */
    @Test
    public void testUpdateCallsUpdateCampaignWithInputVO_WhenUpdatingExistingCampaign() {
        // @Given an existing Campaign
        CampaignVO campaignVO = webAppTestsHelper.newCampaignVO(campaign.getId(), campaign.getName(), campaign.getSince(), campaign.getUntil(), CampaignState.CREATED);

        // @When updating the Campaign
        this.campaignController.update(campaign.getId(), campaignVO);

        // @Then
        verify(this.metricsApplication, times(1)).updateCampaign(campaignVO);
    }

    @Test
    public void testUpdateThrowsException_WhenUpdatingNullVO() {
        // @Given an existing Campaign
        CampaignVO campaignVO = null;

        // @When updating the Campaign
        try {
            this.campaignController.update(campaign.getId(), campaignVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        }
    }

    @Test
    public void testDeleteCallsApplicationsFindCampaignByIdWithIdOne_WhenDeletingAnExistingCampaignWithIdOne() {
        // @Given a campaign with Id One
        int campaignId = 1;

        // @When deleting the campaign
        this.campaignController.remove(campaignId);

        // @Then application.delete is called for id One
        verify(this.metricsApplication, times(1)).removeCampaign(campaignId);
    }

    @Test
    public void testDeleteCallsApplicationsFindCampaignByIdWithIdEleven_WhenDeletingAnExistingCampaignWithIdEleven() {
        // @Given a campaign with Id One
        int campaignId = 11;

        // @When deleting the campaign
        this.campaignController.remove(campaignId);

        // @Then application.delete is called for id One
        verify(this.metricsApplication, times(1)).removeCampaign(campaignId);
    }

    @Test
    public void testViewServiceCenterCallsApplicationsFindServiceCenterByCampaignIdAndIdWithSCIdOneAndCampaignIdOne_WhenViewingAServiceCenterWithIdOneAndCampaignOne() {
        // @Given an existing service center of a campaign
        ServiceCenter serviceCenter = webAppTestsHelper.newServiceCenter("1");
        when(this.metricsApplication.findServiceCenterByCampaignIdAndCuit(serviceCenter.getCampaign().getId(), serviceCenter.getCuit())).thenReturn(serviceCenter);

        // @When viewing the service center
        this.campaignController.viewServiceCenter(serviceCenter.getCampaign().getId(), serviceCenter.getCuit());

        // @Then the service center is returned
        verify(this.metricsApplication, times(1)).findServiceCenterByCampaignIdAndCuit(serviceCenter.getCampaign().getId(), serviceCenter.getCuit());
    }

    @Test
    public void testViewServiceCenterCallsApplicationsFindServiceCenterByCampaignIdAndIdWithSCIdAAndCampaignIdOne_WhenViewingAServiceCenterWithIdAAndCampaignOne() {
        // @Given an existing service center of a campaign
        ServiceCenter serviceCenter = webAppTestsHelper.newServiceCenter("A");
        serviceCenter.getCampaign().setId(30);
        when(this.metricsApplication.findServiceCenterByCampaignIdAndCuit(serviceCenter.getCampaign().getId(), serviceCenter.getCuit())).thenReturn(serviceCenter);

        // @When viewing the service center
        this.campaignController.viewServiceCenter(serviceCenter.getCampaign().getId(), serviceCenter.getCuit());

        // @Then the service center is returned
        verify(this.metricsApplication, times(1)).findServiceCenterByCampaignIdAndCuit(serviceCenter.getCampaign().getId(), serviceCenter.getCuit());
    }

    @Test
    public void testViewServiceCenter() {
        // @Given an existing service center of a campaign
        ServiceCenter serviceCenter = webAppTestsHelper.newServiceCenter("1");
        when(this.metricsApplication.findServiceCenterByCampaignIdAndCuit(serviceCenter.getCampaign().getId(), serviceCenter.getCuit())).thenReturn(serviceCenter);

        // @When viewing the service center
        ServiceCenterVO serviceCenterResponse = this.campaignController.viewServiceCenter(serviceCenter.getCampaign().getId(), serviceCenter.getCuit());

        // @Then the service center returned by the application is returned as a VO
        assertThat(serviceCenterResponse).isNotNull();
        assertThat(serviceCenterResponse.getCuit()).isEqualTo(serviceCenter.getCuit());
        assertThat(serviceCenter.getCampaign().getId()).isEqualTo(serviceCenter.getCampaign().getId());
    }

    @Test
    public void testListServiceCentersCallsApplicationListServiceCenters() {
        // @Given an existing campaign with service centers
        when(this.metricsApplication.listServiceCenters(campaign.getId())).thenReturn(Lists.<ServiceCenter>newArrayList(new ServiceCenter()));

        // @When listing the service centers
        this.campaignController.listServiceCenters(campaign.getId());

        // @The service centers are returned
        verify(this.metricsApplication, times(1)).listServiceCenters(campaign.getId());
    }

    @Test
    public void testListServiceCentersReturnsOneServiceCenterWithCuitTen_WhenApplicationReturnsOneServiceCenterWithCuitTen() {
        // @Given an existing campaign with service centers
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("10");
        serviceCenter.setCampaign(campaign);

        when(this.metricsApplication.listServiceCenters(campaign.getId())).thenReturn(Lists.<ServiceCenter>newArrayList(serviceCenter));

        // @When listing the service centers
        List<ServiceCenterVO> serviceCenterVOs = this.campaignController.listServiceCenters(campaign.getId());

        // @The service centers are returned
        assertThat(serviceCenterVOs).onProperty("cuit").contains("10");
    }

    @Test
    public void testListServiceCentersReturnsTwoServiceCenterWithCuitOneAndTwo_WhenApplicationReturnsTwoServiceCentersWithCuitOneAndTwo() {
        // @Given an existing campaign with service centers
        ServiceCenter serviceCenter1 = new ServiceCenter();
        serviceCenter1.setCuit("1");
        serviceCenter1.setCampaign(campaign);
        ServiceCenter serviceCenter2 = new ServiceCenter();
        serviceCenter2.setCuit("2");
        serviceCenter2.setCampaign(campaign);

        when(this.metricsApplication.listServiceCenters(campaign.getId())).thenReturn(Lists.<ServiceCenter>newArrayList(serviceCenter1, serviceCenter2));

        // @When listing the service centers
        List<ServiceCenterVO> serviceCenterVOs = this.campaignController.listServiceCenters(campaign.getId());

        // @The service centers are returned
        assertThat(serviceCenterVOs).onProperty("cuit").contains("1", "2");
    }

    @Test
    public void testSaveAndExecuteServiceCenterLoadCallsApplicationsSaveAndExecuteServiceCenterLoadWithIdOneAndSameVO_WhenSavingAndExecutingServiceCenterLoad() {
        // @Given a campaign id and a campaignVO
        int campaignId = 1;
        CampaignVO campaignVO = new CampaignVO();

        // @When saving and executing the corresponding campaign
        this.campaignController.saveAndExecuteServiceCenterLoad(campaignId, campaignVO);

        // @Then application.saveAndExecuteServiceCenterLoad is called with that id and the VO
        verify(this.dataLoader, times(1)).saveAndExecuteServiceCenterLoad(campaignVO);
        assertThat(campaignVO.getId()).isEqualTo(campaignId);
    }

    @Test
    public void testSaveAndExecuteServiceCenterLoadCallsApplicationsSaveAndExecuteServiceCenterLoadWithIdTwoAndSameVO_WhenSavingAndExecutingServiceCenterLoad() {
        // @Given a campaign id and a campaignVO
        int campaignId = 2;
        CampaignVO campaignVO = new CampaignVO();

        // @When saving and executing the corresponding campaign
        this.campaignController.saveAndExecuteServiceCenterLoad(campaignId, campaignVO);

        // @Then application.saveAndExecuteServiceCenterLoad is called with that id and the VO
        verify(this.dataLoader, times(1)).saveAndExecuteServiceCenterLoad(campaignVO);
        assertThat(campaignVO.getId()).isEqualTo(campaignId);
    }

    @Test
    public void testSaveAndExecuteServiceCenterLoadThrowsException_WhenSavingAndExecutingServiceCenterLoadWithNullVO() {
        // @Given a campaign id and a campaignVO
        int campaignId = 2;
        CampaignVO campaignVO = null;

        // @When saving and executing the corresponding campaign
        try {
            // @Then an exception is thrown
            this.campaignController.saveAndExecuteServiceCenterLoad(campaignId, campaignVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        }
    }

    @Test
    public void testSaveAndExecutePointOfSaleLoadCallsApplicationsSaveAndExecutePointOfSaleLoadWithIdOneAndSameVO_WhenSavingAndExecutingPointOfSaleLoad() {
        // @Given a campaign id and a campaignVO
        int campaignId = 1;
        CampaignVO campaignVO = new CampaignVO();

        // @When saving and executing the corresponding campaign
        this.campaignController.saveAndExecutePointOfSaleLoad(campaignId, campaignVO);

        // @Then application.saveAndExecutePointOfSaleLoad is called with that id and the VO
        verify(this.dataLoader, times(1)).saveAndExecutePointOfSaleLoad(campaignVO);
        assertThat(campaignVO.getId()).isEqualTo(campaignId);
    }

    @Test
    public void testSaveAndExecutePointOfSaleLoadCallsApplicationsSaveAndExecutePointOfSaleLoadWithIdTwoAndSameVO_WhenSavingAndExecutingPointOfSaleLoad() {
        // @Given a campaign id and a campaignVO
        int campaignId = 2;
        CampaignVO campaignVO = new CampaignVO();

        // @When saving and executing the corresponding campaign
        this.campaignController.saveAndExecutePointOfSaleLoad(campaignId, campaignVO);

        // @Then application.saveAndExecutePointOfSaleLoad is called with that id and the VO
        verify(this.dataLoader, times(1)).saveAndExecutePointOfSaleLoad(campaignVO);
        assertThat(campaignVO.getId()).isEqualTo(campaignId);
    }

    @Test
    public void testSaveAndExecutePointOfSaleThrowsException_WhenSavingAndExecutingPointOfSaleLoadWithNullVO() {
        // @Given a campaign id and a campaignVO
        int campaignId = 2;
        CampaignVO campaignVO = null;

        // @When saving and executing the corresponding campaign
        try {
            this.campaignController.saveAndExecutePointOfSaleLoad(campaignId, campaignVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        }
    }

    @Test
    public void testSaveAndExecuteEmployeeLoadCallsApplicationsSaveAndExecuteEmployeeLoadWithIdOneAndSameVO_WhenSavingAndExecutingEmployeeLoad() {
        // @Given a campaign id and a campaignVO
        int campaignId = 1;
        CampaignVO campaignVO = new CampaignVO();

        // @When saving and executing the corresponding campaign
        this.campaignController.saveAndExecuteEmployeeLoad(campaignId, campaignVO);

        // @Then application.saveAndExecuteEmployeeLoad is called with that id and the VO
        verify(this.dataLoader, times(1)).saveAndExecuteEmployeeLoad(campaignVO);
        assertThat(campaignVO.getId()).isEqualTo(campaignId);
    }

    @Test
    public void testSaveAndExecuteEmployeeLoadCallsApplicationsSaveAndExecuteEmployeeLoadWithIdTwoAndSameVO_WhenSavingAndExecutingEmployeeLoad() {
        // @Given a campaign id and a campaignVO
        int campaignId = 2;
        CampaignVO campaignVO = new CampaignVO();

        // @When saving and executing the corresponding campaign
        this.campaignController.saveAndExecuteEmployeeLoad(campaignId, campaignVO);

        // @Then application.saveAndExecuteEmployeeLoad is called with that id and the VO
        verify(this.dataLoader, times(1)).saveAndExecuteEmployeeLoad(campaignVO);
        assertThat(campaignVO.getId()).isEqualTo(campaignId);
    }

    @Test
    public void testSaveAndExecuteEmployeeLoadThrowsException_WhenSavingAndExecutingEmployeeLoadWithNullVO() {
        // @Given a campaign id and a campaignVO
        int campaignId = 2;
        CampaignVO campaignVO = null;

        // @When saving and executing the corresponding campaign
        try {
            this.campaignController.saveAndExecuteEmployeeLoad(campaignId, campaignVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        }
    }

    @Test
    public void testListPointOfSalesForServiceCenterCallsApplicationFindServiceCentersByCampaignIdOneAndCuitTwo_WhenListingPOSOfCampaignOneAndSCTwo() {
        // @Given a campaign id 1 and a SC cuit "Two"
        int campaignId = 1;
        String cuit = "Two";

        // @When listing the POS matching that SC
        this.campaignController.listPointsOfSaleForServiceCenter(campaignId, cuit);

        // @Then Application.findPointsOfSaleByCampaignIdAndCuit is called with 1 and "Two"
        verify(this.metricsApplication, times(1)).findPointsOfSaleByCampaignIdAndCuit(campaignId, cuit);
    }

    @Test
    public void testListPointOfSalesForServiceCenterCallsApplicationFindServiceCentersByCampaignId30AndCuit2000_WhenListingPOSOfCampaign30AndSC2000() {
        // @Given a campaign id 30 and a SC cuit "2000"
        int campaignId = 30;
        String cuit = "2000";

        // @When listing the POS matching that SC
        this.campaignController.listPointsOfSaleForServiceCenter(campaignId, cuit);

        // @Then Application.findPointsOfSaleByCampaignIdAndCuit is called with 30 and "2000"
        verify(this.metricsApplication, times(1)).findPointsOfSaleByCampaignIdAndCuit(campaignId, cuit);
    }

    @Test
    public void testListPointOfSalesForServiceCenterReturns2MatchingVOs_WhenApplicationReturns2PointsOfSale() {
        // @Given a campaign id 1 and a SC cuit "Two"
        int campaignId = 1;
        String cuit = "Two";
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("papapa");
        PointOfSale pointOfSale1 = new PointOfSale();
        pointOfSale1.setIdSap(22l);

        pointOfSale1.setServiceCenter(serviceCenter);
        PointOfSale pointOfSale2 = new PointOfSale();
        pointOfSale2.setServiceCenter(serviceCenter);
        pointOfSale2.setIdSap(28345l);
        when(this.metricsApplication.findPointsOfSaleByCampaignIdAndCuit(campaignId, cuit)).thenReturn(Lists.<PointOfSale>newArrayList(pointOfSale1, pointOfSale2));

        // @When listing the POS matching that SC
        List<PointOfSaleVO> pointOfSaleVOs = this.campaignController.listPointsOfSaleForServiceCenter(campaignId, cuit);

        // @Then a list of VOS matching the POS returned by the application is returned by the controller
        assertThat(pointOfSaleVOs).hasSize(2);
        assertThat(pointOfSaleVOs).onProperty("idSap").containsOnly(pointOfSale1.getIdSap(), pointOfSale2.getIdSap());
    }

    @Test
    public void testListPointOfSalesForServiceCenterReturns4MatchingVOs_WhenApplicationReturns4PointsOfSale() {
        // @Given a campaign id 1 and a SC cuit "Two"
        int campaignId = 1;
        String cuit = "Two";
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("papapa");
        PointOfSale pointOfSale1 = new PointOfSale();
        pointOfSale1.setIdSap(21672l);
        pointOfSale1.setServiceCenter(serviceCenter);
        PointOfSale pointOfSale2 = new PointOfSale();
        pointOfSale2.setIdSap(28345l);
        pointOfSale2.setServiceCenter(serviceCenter);
        PointOfSale pointOfSale3 = new PointOfSale();
        pointOfSale3.setIdSap(7854l);
        pointOfSale3.setServiceCenter(serviceCenter);
        PointOfSale pointOfSale4 = new PointOfSale();
        pointOfSale4.setIdSap(295l);
        pointOfSale4.setServiceCenter(serviceCenter);
        when(this.metricsApplication.findPointsOfSaleByCampaignIdAndCuit(campaignId, cuit)).thenReturn(Lists.<PointOfSale>newArrayList(pointOfSale1, pointOfSale2, pointOfSale3, pointOfSale4));

        // @When listing the POS matching that SC
        List<PointOfSaleVO> pointOfSaleVOs = this.campaignController.listPointsOfSaleForServiceCenter(campaignId, cuit);

        // @Then a list of VOS matching the POS returned by the application is returned by the controller
        assertThat(pointOfSaleVOs).hasSize(4);
        assertThat(pointOfSaleVOs).onProperty("idSap").containsOnly(pointOfSale1.getIdSap(), pointOfSale2.getIdSap(), pointOfSale3.getIdSap(), pointOfSale4.getIdSap());
    }

    @Test
    public void testListPointsOfSaleForCampaign() {
        // @Given an existing campaign with service centers
        when(this.metricsApplication.findPointsOfSaleByCampaignId(campaign.getId())).thenReturn(Lists.<PointOfSale>newArrayList(new PointOfSale()));

        // @When listing the service centers
        this.campaignController.listPointsOfSaleForCampaign(campaign.getId());

        // @The service centers are returned
        verify(this.metricsApplication, times(1)).findPointsOfSaleByCampaignId(campaign.getId());
    }

    @Test
    public void testListPointOfSalesForCampaignReturns2MatchingVOs_WhenApplicationReturns2PointsOfSale() {
        // @Given a campaign id 1 and a SC cuit "Two"
        int campaignId = 1;
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("papapa");
        PointOfSale pointOfSale1 = new PointOfSale();
        pointOfSale1.setIdSap(22l);

        pointOfSale1.setServiceCenter(serviceCenter);
        PointOfSale pointOfSale2 = new PointOfSale();
        pointOfSale2.setServiceCenter(serviceCenter);
        pointOfSale2.setIdSap(28345l);
        when(this.metricsApplication.findPointsOfSaleByCampaignId(campaignId)).thenReturn(Lists.<PointOfSale>newArrayList(pointOfSale1, pointOfSale2));

        // @When listing the POS matching that SC
        List<PointOfSaleVO> pointOfSaleVOs = this.campaignController.listPointsOfSaleForCampaign(campaignId);

        // @Then a list of VOS matching the POS returned by the application is returned by the controller
        assertThat(pointOfSaleVOs).hasSize(2);
        assertThat(pointOfSaleVOs).onProperty("idSap").containsOnly(pointOfSale1.getIdSap(), pointOfSale2.getIdSap());
    }

    @Test
    public void testListPointOfSalesForCampaignReturns4MatchingVOs_WhenApplicationReturns4PointsOfSale() {
        // @Given a campaign id 1 and a SC cuit "Two"
        int campaignId = 1;
        ServiceCenter serviceCenter = new ServiceCenter();
        serviceCenter.setCuit("papapa");
        PointOfSale pointOfSale1 = new PointOfSale();
        pointOfSale1.setIdSap(21672l);
        pointOfSale1.setServiceCenter(serviceCenter);
        PointOfSale pointOfSale2 = new PointOfSale();
        pointOfSale2.setIdSap(28345l);
        pointOfSale2.setServiceCenter(serviceCenter);
        PointOfSale pointOfSale3 = new PointOfSale();
        pointOfSale3.setIdSap(7854l);
        pointOfSale3.setServiceCenter(serviceCenter);
        PointOfSale pointOfSale4 = new PointOfSale();
        pointOfSale4.setIdSap(295l);
        pointOfSale4.setServiceCenter(serviceCenter);
        when(this.metricsApplication.findPointsOfSaleByCampaignId(campaignId)).thenReturn(Lists.<PointOfSale>newArrayList(pointOfSale1, pointOfSale2, pointOfSale3, pointOfSale4));

        // @When listing the POS matching that SC
        List<PointOfSaleVO> pointOfSaleVOs = this.campaignController.listPointsOfSaleForCampaign(campaignId);

        // @Then a list of VOS matching the POS returned by the application is returned by the controller
        assertThat(pointOfSaleVOs).hasSize(4);
        assertThat(pointOfSaleVOs).onProperty("idSap").containsOnly(pointOfSale1.getIdSap(), pointOfSale2.getIdSap(), pointOfSale3.getIdSap(), pointOfSale4.getIdSap());
    }

    @Test
    public void testSummaryCallsApplicationGenerateScoreSummaryWithCampaign1AndSCTen_WhenGettingTheScoresSummaryForCampaign1AndSCTen() {
        // @Given a campaign 1 and a serviceCenter Ten
        String cuit = "Ten";
        int campaignId = 1;
        ServiceCenter serviceCenter = new ServiceCenter();
        ScoreServices scoreServices = mock(ScoreServices.class);
        ScoreSummaryCampaignNode campaignNode = new ScoreSummaryCampaignNode(campaign, serviceCenter, scoreServices);
        when(this.metricsApplication.generateScoreSummary(campaignId, cuit)).thenReturn(campaignNode);

        // @When viewing the summary
        this.campaignController.scoreSummary(campaignId, cuit);

        // @Then applications generateScoreSummary is invoked
        verify(this.metricsApplication, times(1)).generateScoreSummary(campaignId, cuit);
    }

    @Test
    public void testListServiceCentersForGridCallsApplicationListServiceCentersByPageWithCampaignIdOne_WhenListingServiceCenterPageForCampaignOne() {
        // @Given a metric with Id One
        int campaignId = 1;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page
        this.campaignController.listServiceCentersForGrid(campaignId, 1, 20, "cuit", "asc", webRequest);

        // @Then application.listServiceCentersByPage is called with Id one
        verify(this.metricsApplication, times(1)).listServiceCentersByPage(eq(campaignId), Matchers.<PageRequest>any(), eq(filter));
    }

    @Test
    public void testListServiceCentersForGridCallsApplicationListServiceCentersByPageWithCampaignIdSeven_WhenListingServiceCenterPageForCampaignSeven() {
        // @Given a metric with Id seven
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page
        this.campaignController.listServiceCentersForGrid(campaignId, 1, 20, "name", "asc", webRequest);

        // @Then application.listServiceCentersByPage is called with Id seven
        verify(this.metricsApplication, times(1)).listServiceCentersByPage(eq(campaignId), Matchers.<PageRequest>any(), eq(filter));
    }

    @Test
    public void testListServiceCentersForGridCallsApplicationListServiceCentersByPageWithPageOneAndRows20_WhenViewingPageOneOfTwentyServiceCenters() {
        // @Given a metric
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(1,20)
        this.campaignController.listServiceCentersForGrid(campaignId, 1, 20, "mail", "asc", webRequest);

        // @Then application.listServiceCentersByPage is called with page 1 and rows 20
        verify(this.metricsApplication, times(1)).listServiceCentersByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == 1 && ((PageRequest) argument).getPageSize() == 20;
            }
        }), eq(filter));
    }

    @Test
    public void testListServiceCentersForGridCallsApplicationListServiceCentersByPageWithPage3AndRows26_WhenViewingPage3Of26ServiceCenters() {
        // @Given a metric
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.campaignController.listServiceCentersForGrid(campaignId, 3, 26, "", "asc", webRequest);

        // @Then application.listServiceCentersByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).listServiceCentersByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == 3 && ((PageRequest) argument).getPageSize() == 26;
            }
        }), eq(filter));
    }

    @Test
    public void testListServiceCentersForGridCallsApplicationListServiceCentersByPageWithSortName_WhenViewingPageOfServiceCentersSortedByName() {
        // @Given a metric
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.campaignController.listServiceCentersForGrid(campaignId, 3, 26, "name", "asc", webRequest);

        // @Then application.listServiceCentersByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).listServiceCentersByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("name").isAscending();
            }
        }), eq(filter));
    }

    @Test
    public void testListServiceCentersForGridCallsApplicationListServiceCentersByPageWithSortCuit_WhenViewingPageOfServiceCentersSortedByCuit() {
        // @Given a metric
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.campaignController.listServiceCentersForGrid(campaignId, 3, 26, "cuit", "asc", webRequest);

        // @Then application.listServiceCentersByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).listServiceCentersByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("cuit").isAscending();
            }
        }), eq(filter));
    }

    @Test
    public void testListServiceCentersForGridCallsApplicationListServiceCentersByPageWithCuitFilter_WhenViewingPageOfServiceCentersWithFilterByCuit() {
        // @Given a metric
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        when(webRequest.getParameterNames()).thenReturn(Lists.newArrayList("cuit").iterator());
        when(webRequest.getParameter("cuit")).thenReturn("101010101");

        // @When viewing it's scores by page(3,26)
        this.campaignController.listServiceCentersForGrid(campaignId, 3, 26, "cuit", "asc", webRequest);

        // @Then application.listServiceCentersByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).listServiceCentersByPage(eq(campaignId), Matchers.<PageRequest>any(), argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return ((Map<String, Object>) argument).containsKey("cuit") && ((Map<String, Object>) argument).get("cuit").equals("101010101");
            }
        }));
    }

    @Test
    public void testSendSummaryCallsApplicationSendSummayWithCampaignId1AndCuit10_WhenSendingSummaryOfCampaign1OfServiceCenter10() throws Exception {
        // @Given a campaign id 1 and a service center 10
        int campaignId = 1;
        String cuit = "10";

        // @When sending summary
        this.campaignController.sendSummary(campaignId, cuit);

        // @Then Application.sendSummary is called
        this.metricsApplication.sendSummary(campaignId, cuit);
    }

    @Test
    public void testSendSummaryCallsApplicationSendSummayWithCampaignId2AndCuit324_WhenSendingSummaryOfCampaign2OfServiceCenter324() throws Exception {
        // @Given a campaign id 1 and a service center 10
        int campaignId = 2;
        String cuit = "324";

        // @When sending summary
        this.campaignController.sendSummary(campaignId, cuit);

        // @Then Application.sendSummary is called
        verify(this.metricsApplication, times(1)).sendSummary(campaignId, cuit);
    }

    @Test
    public void testListPointOfSalesForGridCallsApplicationListPointsOfSaleByPageWithCampaignIdOne_WhenListingPointOfSalePageForCampaignOne() {
        // @Given a metric with Id One
        int campaignId = 1;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page
        this.campaignController.listPointOfSalesForGrid(campaignId, 1, 20, "cuit", "asc", webRequest);

        // @Then application.listPointsOfSaleByPage is called with Id one
        verify(this.metricsApplication, times(1)).listPointsOfSaleByPage(eq(campaignId), Matchers.<PageRequest>any(), eq(filter));
    }

    @Test
    public void testListPointOfSalesForGridCallsApplicationListPointsOfSaleByPageWithCampaignIdSeven_WhenListingPointOfSalePageForCampaignSeven() {
        // @Given a metric with Id seven
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page
        this.campaignController.listPointOfSalesForGrid(campaignId, 1, 20, "name", "asc", webRequest);

        // @Then application.listPointsOfSaleByPage is called with Id seven
        verify(this.metricsApplication, times(1)).listPointsOfSaleByPage(eq(campaignId), Matchers.<PageRequest>any(), eq(filter));
    }

    @Test
    public void testListPointOfSalesForGridCallsApplicationListPointsOfSaleByPageWithPageOneAndRows20_WhenViewingPageOneOfTwentyPointsOfSale() {
        // @Given a metric
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(1,20)
        this.campaignController.listPointOfSalesForGrid(campaignId, 1, 20, "mail", "asc", webRequest);

        // @Then application.listPointsOfSaleByPage is called with page 1 and rows 20
        verify(this.metricsApplication, times(1)).listPointsOfSaleByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == 1 && ((PageRequest) argument).getPageSize() == 20;
            }
        }), eq(filter));
    }

    @Test
    public void testListPointOfSalesForGridCallsApplicationListPointsOfSaleByPageWithPage3AndRows26_WhenViewingPage3Of26PointsOfSale() {
        // @Given a metric
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.campaignController.listPointOfSalesForGrid(campaignId, 3, 26, "", "asc", webRequest);

        // @Then application.listPointsOfSaleByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).listPointsOfSaleByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == 3 && ((PageRequest) argument).getPageSize() == 26;
            }
        }), eq(filter));
    }

    @Test
    public void testListPointOfSalesForGridCallsApplicationListPointsOfSaleByPageWithSortName_WhenViewingPageOfPointsOfSaleSortedByName() {
        // @Given a metric
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.campaignController.listPointOfSalesForGrid(campaignId, 3, 26, "name", "asc", webRequest);

        // @Then application.listPointsOfSaleByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).listPointsOfSaleByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("name").isAscending();
            }
        }), eq(filter));
    }

    @Test
    public void testListPointOfSalesForGridCallsApplicationListPointsOfSaleByPageWithSortCuit_WhenViewingPageOfPointsOfSaleSortedByCuit() {
        // @Given a metric
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.campaignController.listPointOfSalesForGrid(campaignId, 3, 26, "cuit", "asc", webRequest);

        // @Then application.listPointsOfSaleByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).listPointsOfSaleByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("cuit").isAscending();
            }
        }), eq(filter));
    }

    @Test
    public void testListPointOfSalesForGridCallsApplicationListPointsOfSaleByPageWithCuitFilter_WhenViewingPageOfPointsOfSaleWithFilterByCuit() {
        // @Given a metric
        int campaignId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        when(webRequest.getParameterNames()).thenReturn(Lists.newArrayList("cuit").iterator());
        when(webRequest.getParameter("cuit")).thenReturn("101010101");

        // @When viewing it's scores by page(3,26)
        this.campaignController.listPointOfSalesForGrid(campaignId, 3, 26, "cuit", "asc", webRequest);

        // @Then application.listPointsOfSaleByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).listPointsOfSaleByPage(eq(campaignId), Matchers.<PageRequest>any(), argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return ((Map<String, Object>) argument).containsKey("cuit") && ((Map<String, Object>) argument).get("cuit").equals("101010101");
            }
        }));
    }

    @Test
    public void testSendAllSummariesCallsApplicationSendAllSumariesForCampaign1_WhenSendingAllSummariesOfCampaign1() throws Exception {
        // @Given a campaign id 1
        int campaignId = 2;

        // @When sending all summaries
        this.campaignController.sendAllSummaries(campaignId);

        // @Then Application.sendAllSumaries is called
        verify(this.metricsApplication, times(1)).sendAllSummaries(campaignId);
    }

    @Test
    public void testSendAllSummariesCallsApplicationSendAllSumariesForCampaign2_WhenSendingAllSummariesOfCampaign2() throws Exception {
        // @Given a campaign id 1
        int campaignId = 1;

        // @When sending all summaries
        this.campaignController.sendAllSummaries(campaignId);

        // @Then Application.sendAllSumaries is called
        verify(this.metricsApplication, times(1)).sendAllSummaries(campaignId);
    }

    @Test
    public void testViewParametersPageCallsApplicationListPointsOfSaleByPageWithEmptyFilter_WhenListingPointOfSalePageWithNoFilter() {
        // @Given a metric with Id One
        int campaignId = 1;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page
        this.campaignController.viewParametersPage(1, 20, "cuit", "asc", webRequest);

        // @Then application.findCampaignParametersByPage is called with Id one
        verify(this.metricsApplication, times(1)).findCampaignParametersByPage(Matchers.<PageRequest>any(), eq(filter));
    }

    @Test
    public void testViewParametersPageCallsApplicationListPointsOfSaleByPageWithPageOneAndRows20_WhenViewingPageOneOfTwentyPointsOfSale() {
        // @Given a metric
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(1,20)
        this.campaignController.viewParametersPage(1, 20, "mail", "asc", webRequest);

        // @Then application.findCampaignParametersByPage is called with page 1 and rows 20
        verify(this.metricsApplication, times(1)).findCampaignParametersByPage(argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == 1 && ((PageRequest) argument).getPageSize() == 20;
            }
        }), eq(filter));
    }

    @Test
    public void testViewParametersPageCallsApplicationListPointsOfSaleByPageWithPage3AndRows26_WhenViewingPage3Of26PointsOfSale() {
        // @Given a metric
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.campaignController.viewParametersPage(3, 26, "", "asc", webRequest);

        // @Then application.findCampaignParametersByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).findCampaignParametersByPage(argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == 3 && ((PageRequest) argument).getPageSize() == 26;
            }
        }), eq(filter));
    }

    @Test
    public void testViewParametersPageCallsApplicationListPointsOfSaleByPageWithSortName_WhenViewingPageOfPointsOfSaleSortedByName() {
        // @Given a metric
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.campaignController.viewParametersPage(3, 26, "name", "asc", webRequest);

        // @Then application.findCampaignParametersByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).findCampaignParametersByPage(argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("name").isAscending();
            }
        }), eq(filter));
    }

    @Test
    public void testViewParametersPageCallsApplicationListPointsOfSaleByPageWithSortCuit_WhenViewingPageOfPointsOfSaleSortedByCuit() {
        // @Given a metric
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.campaignController.viewParametersPage(3, 26, "cuit", "asc", webRequest);

        // @Then application.findCampaignParametersByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).findCampaignParametersByPage(argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("cuit").isAscending();
            }
        }), eq(filter));
    }

    @Test
    public void testViewParametersPageCallsApplicationListPointsOfSaleByPageWithCuitFilter_WhenViewingPageOfPointsOfSaleWithFilterByCuit() {
        // @Given a metric
        WebRequest webRequest = mock(WebRequest.class);
        when(webRequest.getParameterNames()).thenReturn(Lists.newArrayList("cuit").iterator());
        when(webRequest.getParameter("cuit")).thenReturn("101010101");

        // @When viewing it's scores by page(3,26)
        this.campaignController.viewParametersPage( 3, 26, "cuit", "asc", webRequest);

        // @Then application.findCampaignParametersByPage is called with page 3 and rows 26
        verify(this.metricsApplication, times(1)).findCampaignParametersByPage(Matchers.<PageRequest>any(), argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return ((Map<String, Object>) argument).containsKey("cuit") && ((Map<String, Object>) argument).get("cuit").equals("101010101");
            }
        }));
    }

    @Test
    public void testUpdateParameterCallsApplicationUpdateCampaignParameterWithParameter_WhenUpdatingParameter() {
        // @Given a campaignParameter
        CampaignParameter parameter = new CampaignParameter();
        parameter.setId(1);

        // @When updating it
        this.campaignController.updateParameter(parameter);

        // @Then application.updateParameter is called
        verify(this.metricsApplication, times(1)).updateCampaignParameter(parameter);
    }

    @Test
    public void testUpdateParameterThrowsException_WhenParameterIsNull() {
        // @Given
        // @When updating a parameter with null as input
        try {
            this.campaignController.updateParameter(null);
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_PARAMETER_CANNOT_BE_NULL);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testUpdateParameterThrowsException_WhenParameterIdIsNull() {
        // @Given a parameter with no id
        CampaignParameter parameter = new CampaignParameter();

        // @When updating a parameter with null as input
        try {
            this.campaignController.updateParameter(parameter);
        } catch (BusinessException e) {
            // @Then an exception is thrown
            assertThat(e).hasMessage(BusinessException.ERROR_PARAMETER_ID_CANNOT_BE_NULL);
        } catch (Throwable t) {
            fail();
        }
    }

    @Test
    public void testComputeAllScoresCallsApplicationExecuteBatchMetricScoreComputeWithCampaignId1_WhenCalculatingAllScoresForCampaign1() {
        // @Given a campaignId 1
        int campaignId = 1;

        // @When calculating all scores for that campaign
        this.campaignController.computeAllScores(campaignId);

        // @Then application.executeBatchMetricScoreCompute(campaignId 1)
        verify(this.metricsApplication, times(1)).executeBatchMetricScoreCompute(campaignId);
    }

    @Test
    public void testComputeAllScoresCallsApplicationExecuteBatchMetricScoreComputeWithCampaignId5_WhenCalculatingAllScoresForCampaign5() {
        // @Given a campaignId 5
        int campaignId = 5;

        // @When calculating all scores for that campaign
        this.campaignController.computeAllScores(campaignId);

        // @Then application.executeBatchMetricScoreCompute(campaignId 5)
        verify(this.metricsApplication, times(1)).executeBatchMetricScoreCompute(campaignId);
    }

    @Test
    public void testReloadAllTablesCallsApplicationExecuteAllTablesLoadWithCampaignId1_WhenReloadingAllTablesFromCampaign1(){
        // @Given a campaignId 1
        int campaignId = 1;

        // @When Reloading all tables from campaign
        this.campaignController.reloadAllTables(campaignId);

        // @Then application.executeAllTablesLoadWithCampaignId
        verify(this.dataLoader, times(1)).executeAllTablesLoad(campaignId);
    }

    @Test
    public void testReloadAllTablesCallsApplicationExecuteAllTablesLoadWithCampaignId8_WhenReloadingAllTablesFromCampaign8(){
        // @Given a campaignId 8
        int campaignId = 8;

        // @When Reloading all tables from campaign
        this.campaignController.reloadAllTables(campaignId);

        // @Then application.executeAllTablesLoadWithCampaignId
        verify(this.dataLoader, times(1)).executeAllTablesLoad(campaignId);
    }
}