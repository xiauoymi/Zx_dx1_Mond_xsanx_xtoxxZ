package com.monsanto.metricspos.boundary.ui;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.boundary.helpers.WebAppTestsHelper;
import com.monsanto.metricspos.core.CampaignServices;
import com.monsanto.metricspos.core.ExportServices;
import com.monsanto.metricspos.core.MetricsApplication;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.MetricVO;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.metrics.Metric;
import com.monsanto.metricspos.core.metrics.MetricFactory;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.ReflectiveDataRowPersistorFactory;
import com.monsanto.metricspos.services.excel.XlsExportServiceImpl;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.context.request.WebRequest;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * @author PPERA
 */
public class MetricController_UT {
    private MetricController metricController;
    private MetricsApplication metricApplication;
    private Campaign campaign;
    private WebAppTestsHelper webAppTestsHelper;

    @Before
    public void setUp() {
        metricController = new MetricController();
        this.metricApplication = mock(MetricsApplication.class);
        ExportServices exportServices = mock(XlsExportServiceImpl.class);
        CampaignServices campaignServices = mock(CampaignServices.class);

        Logger auditLog = mock(Logger.class);
        Logger actionLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(this.metricController).set(auditLog);
        field("actionLog").ofType(Logger.class).in(this.metricController).set(actionLog);
        field("exportServices").ofType(ExportServices.class).in(this.metricController).set(exportServices);

        field("application").ofType(MetricsApplication.class).in(this.metricController)
                .set(this.metricApplication);

        MetricFactory metricFactory = new MetricFactory() {
            @Override
            public Metric newMetricDefinition(Campaign campaign, String name, Integer maxPoints) {
                return webAppTestsHelper.newMetric(name);
            }
        };

        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("CRM");
        dataProvider.setName("Client Relationship Manager");

        DataRowPersistorFactory dataRowPersistorFactory = new ReflectiveDataRowPersistorFactory();

        campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign.setFactory(metricFactory);
        campaign.setId(1);
        when(campaignServices.findCampaignById(1)).thenReturn(campaign);

        webAppTestsHelper = new WebAppTestsHelper(dataProvider, campaign, dataRowPersistorFactory);

    }

    /* View a metric */
    @Test
    public void testViewCallsApplicationsFindMetricByIdWithIdOne_WhenFindingTheMetricWithIdOne() {
        //@ Given metrics and a MetricController
        Metric metric = campaign.addMetricDefinition("aMetric", 400);
        int metricId = 1;
        int campaignId = 1;
        when(this.metricApplication.findMetricById(metricId)).thenReturn(metric);

        //@ When Requesting for details of metric 1
        this.metricController.view(campaignId, metricId, false);

        //@ Then the metric 1 is returned
        verify(this.metricApplication, times(1)).findMetricById(metricId);
    }

    @Test
    public void testViewCallsApplicationsFindMetricByIdWithIdTwo_WhenFindingTheMetricWithIdTwo() {
        //@ Given metrics and a MetricController
        Metric metric = campaign.addMetricDefinition("aMetric", 400);
        int metricId = 2;
        int campaignId = 2;
        when(this.metricApplication.findMetricById(metricId)).thenReturn(metric);

        //@ When Requesting for details of metric 1
        this.metricController.view(campaignId, metricId, false);

        //@ Then the metric 1 is returned
        verify(this.metricApplication, times(1)).findMetricById(metricId);
    }

    /* Update/Edit a metric */
    @Test
    public void testUpdateCallsApplicationsUpdateMetricWithVO_WhenUpdatingAnExistingMetric() {
        // Given an existent metric that is to be updated
        MetricVO metricVO = webAppTestsHelper.newMetricVO(1, "Pinto Portugal", 200);
        int campaignId = 1;

        // When
        this.metricController.update(campaignId, metricVO.getId(), metricVO);

        // Then
        verify(this.metricApplication, times(1)).updateMetric(metricVO);
    }

    @Test
    public void testUpdateThrowsException_WhenVOIsNull() {
        // Given an existent metric that is to be updated
        MetricVO metricVO = null;

        // When
        try {
            // @Then
            this.metricController.update(1, 1, metricVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        }
    }

    @Test
    public void testListMetricsForCampaignCallsApplicationListMetricsForCampaign1_WhenListingMetricsForCampaign1() {
        // @Given a campaignId 1
        int campaignId = 1;

        // @When listingMetricsForCampaign
        this.metricController.listMetricsForCampaign(campaignId);

        // @Then application.listSubmetricsForCampaign is called
        verify(this.metricApplication, times(1)).listSubmetricsForCampaign(campaignId);
    }

    @Test
    public void testListMetricsForCampaignCallsApplicationListMetricsForCampaign2_WhenListingMetricsForCampaign2() {
        // @Given a campaignId 2
        int campaignId = 2;

        // @When listingMetricsForCampaign
        this.metricController.listMetricsForCampaign(campaignId);

        // @Then application.listSubmetricsForCampaign is called
        verify(this.metricApplication, times(1)).listSubmetricsForCampaign(campaignId);
    }

    @Test
    public void testListMetricsForCampaignReturnsApplicationResult_WhenListingMetricsForCampaign() {
        // @Given a campaignId 1
        int campaignId = 1;
        Metric metric = new Metric(this.campaign, "name");
        List<Metric> expected = Lists.newArrayList(metric);
        when(this.metricApplication.listSubmetricsForCampaign(campaignId)).thenReturn(expected);

        // @When listingMetricsForCampaign
        List<MetricVO> metricVOs = this.metricController.listMetricsForCampaign(campaignId);

        // @Then returns application result as VOs
        assertThat(metricVOs).onProperty("name").contains(metric.getName());
    }

    /* Append a metric to a campaign */
    @Test
    public void testAppendMetricCallsApplicationsAddMetricToCampaignWithVOData_WhenAppendingAMetricToAnExistingCampaign() {
        // @Given an existing campaign and a new Metric
        MetricVO metricVO = webAppTestsHelper.newMetricVO("aName");
        Metric metric = new Metric(this.campaign, "name");
        when(this.metricApplication.addMetricToCampaign(this.campaign.getId(), metricVO)).thenReturn(metric);

        // @When the metric is appended to the campaign
        this.metricController.appendMetric(this.campaign.getId(), metricVO);

        // @Then the metric is created as requested
        verify(this.metricApplication, times(1)).addMetricToCampaign(this.campaign.getId(), metricVO);
    }

    @Test
    public void testAppendMetricThrowsException_WhenInptVOIsNull() {
        // @Given an existing campaign and a new Metric
        MetricVO metricVO = null;

        // @When the metric is appended to the campaign
        try {
            this.metricController.appendMetric(this.campaign.getId(), metricVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        }
    }

    @Test
    public void testAppendCallsApplicationsAppendMetricToMetricWithMetricIdOneAndProvidedVO_WhenAppendingAMetricToMetricWithIdOne() {
        // @Given an existing metric
        MetricVO metricVO = webAppTestsHelper.newMetricVO(1, "metric 1", 200);
        Metric metric = new Metric(this.campaign, "name");
        when(this.metricApplication.addMetricToMetric(metricVO.getId(), metricVO)).thenReturn(metric);

        // @When a new metric is appended
        this.metricController.append(metricVO.getId(), metricVO);

        // @Then the previously existing metric is saved containing the new metric
        /*The campaign was saved after a metric was added to it*/
        verify(this.metricApplication, times(1)).addMetricToMetric(metricVO.getId(), metricVO);
    }

    @Test
    public void testAppendCallsApplicationsAppendMetricToMetricWithMetricIdTwoAndProvidedVO_WhenAppendingAMetricToMetricWithIdTwo() {
        // @Given an existing metric
        MetricVO metricVO = webAppTestsHelper.newMetricVO(2, "metric 1", 200);
        Metric metric = new Metric(this.campaign, "name");
        when(this.metricApplication.addMetricToMetric(metricVO.getId(), metricVO)).thenReturn(metric);

        // @When a new metric is appended
        this.metricController.append(metricVO.getId(), metricVO);

        // @Then the previously existing metric is saved containing the new metric
        /*The campaign was saved after a metric was added to it*/
        verify(this.metricApplication, times(1)).addMetricToMetric(metricVO.getId(), metricVO);
    }

    @Test
    public void testAppendThrowsException_WhenInputVOIsNull() {
        // @Given an existing metric
        MetricVO metricVO = null;

        // @When a new metric is appended
        try {
            this.metricController.append(54, metricVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        }
    }

    /* Delete a metric */
    @Test
    public void testDeleteCallsApplicationsDeleteWithIdOne_WhenDeletingMetricWithIdOne() {
        // @Given an existing metric
        int metricId = 1;

        // @When the metric is deleted
        this.metricController.delete(1, metricId);

        // @Then the delete method of the application has been called
        verify(this.metricApplication, times(1)).delete(metricId);
    }

    @Test
    public void testDeleteCallsApplicationsDeleteWithIdThree_WhenDeletingMetricWithIdThree() {
        // @Given an existing metric
        int metricId = 3;

        // @When the metric is deleted
        this.metricController.delete(1, metricId);

        // @Then the delete method of the application has been called
        verify(this.metricApplication, times(1)).delete(metricId);
    }

    @Test
    public void testDisable_CallsApplicationsDisableWithIdOne_WhenDisablingAMetricWithIdOne() {
        // @Given a metric that is enabled
        int metricId = 1;
        Metric metric = new Metric(this.campaign, "name");
        when(this.metricApplication.disable(metricId)).thenReturn(metric);

        // @When disabling
        this.metricController.disable(1, metricId);

        // @Then the metric is disabled
        verify(this.metricApplication, times(1)).disable(metricId);
    }

    @Test
    public void testDisable_CallsApplicationsDisableWithIdFive_WhenDisablingAMetricWithIdFive() {
        // @Given a metric that is enabled
        int metricId = 5;
        Metric metric = new Metric(this.campaign, "name");
        when(this.metricApplication.disable(metricId)).thenReturn(metric);

        // @When disabling
        this.metricController.disable(1, metricId);

        // @Then the metric is disabled
        verify(this.metricApplication, times(1)).disable(metricId);
    }

    @Test
    public void testEnableCallsApplicationsEnableWithIdOne_WhenEnablingAMetricWithIdOne() {
        // @Given a metric that is disabled
        int metricId = 1;
        Metric metric = new Metric(this.campaign, "name");
        when(this.metricApplication.enable(metricId)).thenReturn(metric);

        // @When disabling
        this.metricController.enable(1, metricId);

        // @Then the metric is disabled
        verify(this.metricApplication, times(1)).enable(metricId);
    }

    @Test
    public void testEnableCallsApplicationsEnableWithIdSeven_WhenEnablingAMetricWithIdSeven() {
        // @Given a metric that is disabled
        int metricId = 7;
        Metric metric = new Metric(this.campaign, "name");
        when(this.metricApplication.enable(metricId)).thenReturn(metric);

        // @When disabling
        this.metricController.enable(1, metricId);

        // @Then the metric is disabled
        verify(this.metricApplication, times(1)).enable(metricId);
    }

    @Test
    public void testCalculateCallsApplicationCalculateMetricScoreForIdOne_WhenCalculatingScoreOfMetricWithIdOne() {
        // @Given a metric with a formula and id 1
        final int metricId = 1;
        MetricVO metricVO = new MetricVO();

        // @When calculating the score
        this.metricController.saveAndCompute(1, metricId, metricVO);

        // @Then applications.saveAndCalculateMetricScore is called with id 1
        verify(this.metricApplication, times(1)).saveAndCalculateMetricScore(argThat(new ArgumentMatcher<MetricVO>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof MetricVO && ((MetricVO) argument).getId().equals(metricId);
            }
        }));
    }


    @Test
    public void testCalculateCallsApplicationCalculateMetricScoreForId123_WhenCalculatingScoreOfMetricWithId123() {
        // @Given a metric with a formula and id 1
        final int metricId = 123;
        MetricVO metricVO = new MetricVO();
        int campaignId = 1;

        // @When calculating the score
        this.metricController.saveAndCompute(campaignId, metricId, metricVO);

        // @Then applications.saveAndCalculateMetricScore is called with id 1
        verify(this.metricApplication, times(1)).saveAndCalculateMetricScore(argThat(new ArgumentMatcher<MetricVO>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof MetricVO && ((MetricVO) argument).getId().equals(metricId);
            }
        }));
    }

    @Test
    public void testCalculateCallsApplicationCalculateMetricScoreForAMetricVO_WhenCalculatingScoreOfMetricRepresentedWithThatVO() {
        // @Given a metric with a formula and id 1
        int metricId = 10;
        MetricVO metricVO = new MetricVO();

        // @When calculating the score
        this.metricController.saveAndCompute(1, metricId, metricVO);

        // @Then applications.saveAndCalculateMetricScore is called with id 1
        verify(this.metricApplication, times(1)).saveAndCalculateMetricScore(metricVO);
    }

    @Test
    public void testCalculateThrowsException_WhenInputVOIsNull() {
        // @Given a metric with a formula and id 1
        int metricId = 10;
        MetricVO metricVO = null;

        // @When calculating the score
        try {
            this.metricController.saveAndCompute(1, metricId, metricVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        }
    }

    @Test
    public void testComputeCallsApplicationCalculateMetricScoreWithMetricId1_WhenCalculatingScoreOfMetric1() {
        // @Given a metric with a formula and id 1
        int metricId = 1;

        // @When calculating the score
        this.metricController.compute(1, metricId);

        // @Then applications.saveAndCalculateMetricScore is called with id 1
        verify(this.metricApplication, times(1)).calculateMetricScore(metricId);
    }

    @Test
    public void testComputeCallsApplicationCalculateMetricScoreWithMetricId6_WhenCalculatingScoreOfMetric6() {
        // @Given a metric with a formula and id 1
        int metricId = 6;

        // @When calculating the score
        this.metricController.compute(1, metricId);

        // @Then applications.saveAndCalculateMetricScore is called with id 1
        verify(this.metricApplication, times(1)).calculateMetricScore(metricId);
    }

    @Test
    public void testViewScoresPageCallsApplicationFindScoresByMetricIdAndPageWithMetricIdOne_WhenViewingScoresOfMetricOne() {
        // @Given a metric with Id One
        int metricId = 1;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page
        this.metricController.viewScoresPage(1, metricId, 1, 20, "points", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with Id one
        verify(this.metricApplication, times(1)).findScoresByMetricIdAndPage(eq(metricId), Matchers.<PageRequest>any(), eq(filter));
    }

    @Test
    public void testViewScoresPageCallsApplicationFindScoresByMetricIdAndPageWithMetricIdSeven_WhenViewingScoresOfMetricSeven() {
        // @Given a metric with Id seven
        int metricId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page
        this.metricController.viewScoresPage(1, metricId, 1, 20, "points", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with Id seven
        verify(this.metricApplication, times(1)).findScoresByMetricIdAndPage(eq(metricId), Matchers.<PageRequest>any(), eq(filter));
    }

    @Test
    public void testViewScoresPageCallsApplicationFindScoresByMetricIdAndPageWithPageOneAndRows20_WhenViewingPageOneOfTwentyScores() {
        // @Given a metric
        int metricId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(1,20)
        this.metricController.viewScoresPage(1, metricId, 1, 20, "points", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with page 1 and rows 20
        verify(this.metricApplication, times(1)).findScoresByMetricIdAndPage(eq(metricId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == 1 && ((PageRequest) argument).getPageSize() == 20;
            }
        }), eq(filter));
    }

    @Test
    public void testViewScoresPageCallsApplicationFindScoresByMetricIdAndPageWithPage3AndRows26_WhenViewingPage3Of26Scores() {
        // @Given a metric
        int metricId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.metricController.viewScoresPage(1, metricId, 3, 26, "", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with page 3 and rows 26
        verify(this.metricApplication, times(1)).findScoresByMetricIdAndPage(eq(metricId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == 3 && ((PageRequest) argument).getPageSize() == 26;
            }
        }), eq(filter));
    }

    @Test
    public void testViewScoresPageCallsApplicationFindScoresByMetricIdAndPageWithSortPoints_WhenViewingPageOfScoresSortedByPoints() {
        // @Given a metric
        int metricId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.metricController.viewScoresPage(1, metricId, 3, 26, "points", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with page 3 and rows 26
        verify(this.metricApplication, times(1)).findScoresByMetricIdAndPage(eq(metricId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("points").isAscending();
            }
        }), eq(filter));
    }

    @Test
    public void testViewScoresPageCallsApplicationFindScoresByMetricIdAndPageWithSortServiceCenter_WhenViewingPageOfScoresSortedByServiceCenter() {
        // @Given a metric
        int metricId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.metricController.viewScoresPage(1, metricId, 3, 26, "serviceCenter", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with page 3 and rows 26
        verify(this.metricApplication, times(1)).findScoresByMetricIdAndPage(eq(metricId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("serviceCenter").isAscending();
            }
        }), eq(filter));
    }

    @Test
    public void testViewScoresPageCallsApplicationFindScoresByMetricIdAndPageWithServiceCenterFilter_WhenViewingPageOfScoresFilteredByServiceCenter() {
        // @Given a metric
        int metricId = 7;
        WebRequest webRequest = mock(WebRequest.class);
        when(webRequest.getParameterNames()).thenReturn(Lists.newArrayList("serviceCenter").iterator());
        when(webRequest.getParameter("serviceCenter")).thenReturn("101010101");

        // @When viewing it's scores by page(3,26)
        this.metricController.viewScoresPage(1, metricId, 3, 26, "serviceCenter", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with page 3 and rows 26
        verify(this.metricApplication, times(1)).findScoresByMetricIdAndPage(eq(metricId), Matchers.<PageRequest>any(), argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return ((Map<String, Object>) argument).containsKey("serviceCenter") && ((Map<String, Object>) argument).get("serviceCenter").equals("101010101");
            }
        }));
    }

    @Test
    public void testViewAllScoresPageCallsApplicationFindScoresByCampaignIdAndPageWithPageOneAndRows20_WhenViewingPageOneOfTwentyScores() {
        // @Given a metric
        int campaignId = 1;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(1,20)
        this.metricController.viewAllScoresPage(campaignId, 1, 20, "points", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with page 1 and rows 20
        verify(this.metricApplication, times(1)).findScoresByCampaignIdAndPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == 1 && ((PageRequest) argument).getPageSize() == 20;
            }
        }), eq(filter));
    }

    @Test
    public void testViewAllScoresPageCallsApplicationFindScoresByCampaignIdAndPageWithPage3AndRows26_WhenViewingPage3Of26Scores() {
        // @Given a metric
        int campaignId = 1;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.metricController.viewAllScoresPage(campaignId, 3, 26, "", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with page 3 and rows 26
        verify(this.metricApplication, times(1)).findScoresByCampaignIdAndPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == 3 && ((PageRequest) argument).getPageSize() == 26;
            }
        }), eq(filter));
    }

    @Test
    public void testViewAllScoresPageCallsApplicationFindScoresByCampaignIdAndPageWithSortPoints_WhenViewingPageOfScoresSortedByPoints() {
        // @Given a metric
        int campaignId = 1;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.metricController.viewAllScoresPage(campaignId, 3, 26, "points", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with page 3 and rows 26
        verify(this.metricApplication, times(1)).findScoresByCampaignIdAndPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("points").isAscending();
            }
        }), eq(filter));
    }

    @Test
    public void testViewAllScoresPageCallsApplicationFindScoresByCampaignIdAndPageWithSortServiceCenter_WhenViewingPageOfScoresSortedByServiceCenter() {
        // @Given a metric
        int campaignId = 1;
        WebRequest webRequest = mock(WebRequest.class);
        Map<String, Object> filter = Maps.newHashMap();

        // @When viewing it's scores by page(3,26)
        this.metricController.viewAllScoresPage(campaignId, 3, 26, "serviceCenter", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with page 3 and rows 26
        verify(this.metricApplication, times(1)).findScoresByCampaignIdAndPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("serviceCenter").isAscending();
            }
        }), eq(filter));
    }

    @Test
    public void testViewAllScoresPageCallsApplicationFindScoresByCampaignIdAndPageWithServiceCenterFilter_WhenViewingPageOfScoresFilteredByServiceCenter() {
        // @Given a metric
        int campaignId = 1;
        WebRequest webRequest = mock(WebRequest.class);
        when(webRequest.getParameterNames()).thenReturn(Lists.newArrayList("serviceCenter").iterator());
        when(webRequest.getParameter("serviceCenter")).thenReturn("101010101");

        // @When viewing it's scores by page(3,26)
        this.metricController.viewAllScoresPage(campaignId, 3, 26, "serviceCenter", "asc", webRequest);

        // @Then application.findScoresByMetricIdAndPage is called with page 3 and rows 26
        verify(this.metricApplication, times(1)).findScoresByCampaignIdAndPage(eq(campaignId), Matchers.<PageRequest>any(), argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return ((Map<String, Object>) argument).containsKey("serviceCenter") && ((Map<String, Object>) argument).get("serviceCenter").equals("101010101");
            }
        }));
    }

    @Test
    public void testExportDataCallsApplicationFindAllScoresByCampaignId1_WhenExportingScoresOfCampaign1() throws Exception {
        // @Given a campaignId
        int campaignId = 1;
        int page = 2;
        int rows = 25;
        String property = "";
        String direction = "";
        WebRequest webRequest = mock(WebRequest.class);
        HttpServletResponse response = new MockHttpServletResponse();

        // @When
        this.metricController.exportScores(campaignId, property, direction, webRequest, response);

        // @Then
        verify(this.metricApplication, times(1)).findAllScoresByCampaignId(eq(campaignId), Matchers.<Sort>any(), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testExportDataCallsApplicationFindAllScoresByCampaignId2_WhenExportingScoresOfCampaign2() throws Exception {
        // @Given a campaignId
        int campaignId = 2;
        String property = "";
        String direction = "";
        WebRequest webRequest = mock(WebRequest.class);
        HttpServletResponse response = new MockHttpServletResponse();

        // @When
        this.metricController.exportScores(campaignId, property, direction, webRequest, response);

        // @Then
        verify(this.metricApplication, times(1)).findAllScoresByCampaignId(eq(campaignId), Matchers.<Sort>any(), Matchers.<Map<String, Object>>any());
    }


    @Test
    public void testCheckSendCallsSetSendFlagInTrue() {
        int campaignId = 1;
        Boolean sendFlag = true;
        int metricId = 1;

        // @When
        this.metricController.checkSend(campaignId, metricId, sendFlag);

        // @Then
        verify(this.metricApplication, times(1)).setSendFlag(metricId, sendFlag);

    }

    @Test
    public void testCheckSendCallsSetSendFlagInFalse() {
        int campaignId = 1;
        int metricId = 1;

        // @When
        this.metricController.checkSend(campaignId, metricId);

        // @Then
        verify(this.metricApplication, times(1)).setSendFlag(metricId, false);

    }

}
