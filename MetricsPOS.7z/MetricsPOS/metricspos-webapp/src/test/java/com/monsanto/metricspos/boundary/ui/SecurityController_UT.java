package com.monsanto.metricspos.boundary.ui;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.core.SecurityApplication;
import com.monsanto.metricspos.core.application.vo.EmployeeVO;
import com.monsanto.metricspos.core.application.vo.GroupVO;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.core.security.AdminUser;
import com.monsanto.metricspos.core.security.Authority;
import com.monsanto.metricspos.core.security.Group;
import com.monsanto.metricspos.core.structure.Employee;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;
import org.springframework.web.context.request.WebRequest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class SecurityController_UT {
    private SecurityController securityController;
    private SecurityApplication securityApplication;

    @Before
    public void setUp() {
        this.securityController = new SecurityController();
        this.securityApplication = mock(SecurityApplication.class);

        Logger auditLog = mock(Logger.class);
        Logger actionLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(this.securityController).set(auditLog);
        field("actionLog").ofType(Logger.class).in(this.securityController).set(actionLog);
        field("securityApplication").ofType(SecurityApplication.class).in(this.securityController).set(this.securityApplication);
    }

    @Test
    public void testListGroupsCallsApplicationListGroups_WhenListingGroups() {
        // @When listing groups
        this.securityController.listGroups();

        // @Then application.listGroups is called
        verify(this.securityApplication, times(1)).listGroups();
    }

    @Test
    public void testListGroupsReturns2VOsWithId1And2_WhenApplicationReturnsTwoGroupsWithId1And2() {
        // @Given 2 groups
        Group group1 = new Group();
        group1.setId(1);
        Group group2 = new Group();
        group2.setId(2);
        when(this.securityApplication.listGroups()).thenReturn(Lists.<Group>newArrayList(group1, group2));

        // @When listing groups
        List<GroupVO> groupVOs = this.securityController.listGroups();

        // @Then application.listGroups is called
        assertThat(groupVOs).hasSize(2);
        assertThat(groupVOs).onProperty("id").contains(1, 2);
    }

    @Test
    public void testListGroupsReturns2VOsWithId5And23_WhenApplicationReturnsTwoGroupsWithId5And23() {
        // @Given 2 groups
        Group group1 = new Group();
        group1.setId(5);
        Group group2 = new Group();
        group2.setId(23);
        when(this.securityApplication.listGroups()).thenReturn(Lists.<Group>newArrayList(group1, group2));

        // @When listing groups
        List<GroupVO> groupVOs = this.securityController.listGroups();

        // @Then application.listGroups is called
        assertThat(groupVOs).hasSize(2);
        assertThat(groupVOs).onProperty("id").contains(5, 23);
    }

    @Test
    public void testListAuthoritiesCallsApplicationListAuthorities_WhenListingAuthorities() {
        // @When listing authorities
        this.securityController.listAuthorities();

        // @Then application.listAuthorities is called
        verify(this.securityApplication, times(1)).listAuthorities();
    }

    @Test
    public void testListAuthoritiesReturnsApplicationListAuthoritiesResult_WhenListingAuthorities() {
        // @Given an authorities list
        Authority authority = new Authority();
        authority.setName("Hi");
        ArrayList<Authority> authorities = Lists.newArrayList(authority);
        when(this.securityApplication.listAuthorities()).thenReturn(authorities);

        // @When listing authorities
        List<Authority> authoritiesResult = this.securityController.listAuthorities();

        // @Then application.listAuthorities is called
        assertThat(authoritiesResult).isSameAs(authorities);
    }

    @Test
    public void testCreateGroupCallsApplicationCreateGroupWithVOWithNameCharly_WhenCreatingGroupNamedCharly() {
        // @Given a GroupVO named Charly
        GroupVO groupVO = new GroupVO();
        groupVO.setName("Charly");
        Group newGroup = new Group();
        newGroup.setName(groupVO.getName());
        newGroup.setId(1);
        when(this.securityApplication.createGroup(groupVO)).thenReturn(newGroup);

        // @When creating a group with that name
        this.securityController.createGroup(groupVO);

        // @Then application.createGroup is called with that VO
        verify(this.securityApplication, times(1)).createGroup(groupVO);
    }

    @Test
    public void testCreateGroupReturnsCreatedGroupVO_WhenCreatingGroupNamedCharly() {
        // @Given a GroupVO named Charly
        GroupVO groupVO = new GroupVO();
        groupVO.setName("Charly");
        Group newGroup = new Group();
        newGroup.setName(groupVO.getName());
        newGroup.setId(1);
        when(this.securityApplication.createGroup(groupVO)).thenReturn(newGroup);

        // @When creating a group with that name
        GroupVO created = this.securityController.createGroup(groupVO);

        // @Then application.createGroup is called with that VO
        assertThat(created.getId()).isEqualTo(newGroup.getId());
        assertThat(created.getName()).isEqualTo(newGroup.getName());
    }

    @Test
    public void testViewGroupCallsApplicationFindGroupById1_WhenFindingGroup1() {
        // @Given a group id 1
        int groupId = 1;
        Group group = new Group();
        group.setId(groupId);
        when(this.securityApplication.findGroupById(group.getId())).thenReturn(group);

        // @When finding that group
        this.securityController.viewGroup(groupId);

        // @Then application.findGroupById is called
        verify(this.securityApplication, times(1)).findGroupById(groupId);
    }

    @Test
    public void testViewGroupCallsApplicationFindGroupById23_WhenFindingGroup23() {
        // @Given a group id 1
        int groupId = 23;
        Group group = new Group();
        group.setId(groupId);
        when(this.securityApplication.findGroupById(group.getId())).thenReturn(group);

        // @When finding that group
        this.securityController.viewGroup(groupId);

        // @Then application.findGroupById is called
        verify(this.securityApplication, times(1)).findGroupById(groupId);
    }

    @Test
    public void testViewGroupReturnsGroupFoundByApplication_WhenFindingGroup() {
        // @Given a group id 1
        Group group = new Group();
        group.setId(1);
        when(this.securityApplication.findGroupById(group.getId())).thenReturn(group);

        // @When finding that group
        GroupVO groupVO = this.securityController.viewGroup(1);

        // @Then application.findGroupById is called
        assertThat(groupVO.getId()).isEqualTo(group.getId());
    }

    @Test
    public void testUpdateGroupCallsApplicationUpdateGroup1WithInputVO_WhenUpdatingGroup1() {
        // @Given a vo and an id 1
        final int groupId = 1;
        GroupVO groupVO = new GroupVO();

        // @When updating group with that vo
        this.securityController.updateGroup(groupId, groupVO);

        // @Then that vo is passed to application.updateGroup with id 1
        verify(this.securityApplication, times(1)).updateGroup(argThat(new ArgumentMatcher<GroupVO>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof GroupVO && ((GroupVO) argument).getId().equals(groupId);
            }
        }));
    }

    @Test
    public void testUpdateGroupCallsApplicationUpdateGroup32WithInputVO_WhenUpdatingGroup32() {
        // @Given a vo and an id 1
        final int groupId = 32;
        GroupVO groupVO = new GroupVO();

        // @When updating group with that vo
        this.securityController.updateGroup(groupId, groupVO);

        // @Then that vo is passed to application.updateGroup with id 1
        verify(this.securityApplication, times(1)).updateGroup(argThat(new ArgumentMatcher<GroupVO>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof GroupVO && ((GroupVO) argument).getId().equals(groupId);
            }
        }));
    }

    @Test
    public void testListAdminUsersCallsApplicationListAdminUsers_WhenListingAdminUsers() {
        // @When listing admin users
        this.securityController.listAdminUsers();

        // @Then application.listAdminUsers is called
        verify(this.securityApplication, times(1)).listAdminUsers();
    }

    @Test
    public void testListAdminUsersReturnsApplicationResult_WhenListingAdminUsers() {
        ArrayList<AdminUser> adminUsers = Lists.newArrayList(new AdminUser());
        when(this.securityApplication.listAdminUsers()).thenReturn(adminUsers);

        // @When listing admin users
        List<AdminUser> adminUserList = this.securityController.listAdminUsers();

        // @Then application.listAdminUsers is called
        assertThat(adminUserList).isSameAs(adminUsers);
    }

    @Test
    public void testCreateAdminUserCallsApplicationCreateAdminUserWithInput_WhenCreatingNewAdminUser() {
        // @Given new admin user info input
        AdminUser adminUser = new AdminUser();
        adminUser.setEnabled(true);
        adminUser.setUsername("lfirst");

        // @When creating that admin user
        this.securityController.createAdminUser(adminUser);

        // @Then application createAdminUser is called
        verify(this.securityApplication, times(1)).createAdminUser(adminUser);
    }

    @Test
    public void testCreateAdminUserReturnsCreatedAdminUser_WhenCreatingNewAdminUser() {
        // @Given new admin user info input
        AdminUser adminUser = new AdminUser();
        adminUser.setEnabled(true);
        adminUser.setUsername("lfirst");
        AdminUser createdAdminUser = new AdminUser();
        when(this.securityApplication.createAdminUser(adminUser)).thenReturn(createdAdminUser);

        // @When creating that admin user
        AdminUser user = this.securityController.createAdminUser(adminUser);

        // @Then application createAdminUser is called
        assertThat(user).isSameAs(createdAdminUser);
    }

    @Test
    public void testViewEmployeeGroupsPageCallsApplicationFindEmployeeGroupsByPageWithCampaignId1_WhenViewingEmployeeGroupsOfCampaign1() {
        // @Given a campaignId 1
        int campaignId = 1;
        WebRequest webRequest = mock(WebRequest.class);

        // @When viewing employee groups for that campaign
        this.securityController.viewEmployeeGroups(campaignId, 1, 25, "", "asc", webRequest);

        // @Then application.findEmployeeGroupsByPage is called with that campaign Id
        verify(this.securityApplication, times(1)).findEmployeeGroupsByPage(eq(campaignId), Matchers.<PageRequest>any(), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testViewEmployeeGroupsPageCallsApplicationFindEmployeeGroupsByPageWithCampaignId5_WhenViewingEmployeeGroupsOfCampaign5() {
        // @Given a campaignId 1
        int campaignId = 5;
        WebRequest webRequest = mock(WebRequest.class);

        // @When viewing employee groups for that campaign
        this.securityController.viewEmployeeGroups(campaignId, 1, 25, "", "asc", webRequest);

        // @Then application.findEmployeeGroupsByPage is called with that campaign Id
        verify(this.securityApplication, times(1)).findEmployeeGroupsByPage(eq(campaignId), Matchers.<PageRequest>any(), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testViewEmployeeGroupsPageCallsApplicationFindEmployeeGroupsByPage1_WhenViewingEmployeeGroupsPage1() {
        // @Given a campaignId 1
        int campaignId = 5;
        final int page = 1;
        int rows = 25;
        String sort = "";
        String direction = "asc";
        WebRequest webRequest = mock(WebRequest.class);

        // @When viewing employee groups for that campaign
        this.securityController.viewEmployeeGroups(campaignId, page, rows, sort, direction, webRequest);

        // @Then application.findEmployeeGroupsByPage is called with that campaign Id
        verify(this.securityApplication, times(1)).findEmployeeGroupsByPage(
                eq(campaignId),
                argThat(new ArgumentMatcher<PageRequest>() {
                    @Override
                    public boolean matches(Object argument) {
                        return argument instanceof PageRequest && page == ((PageRequest) argument).getPageNumber();
                    }
                }),
                Matchers.<Map<String, Object>>anyObject()
        );
    }

    @Test
    public void testViewEmployeeGroupsPageCallsApplicationFindEmployeeGroupsByPage7_WhenViewingEmployeeGroupsPage7() {
        // @Given a campaignId 1
        int campaignId = 5;
        final int page = 7;
        int rows = 25;
        String sort = "";
        String direction = "asc";
        WebRequest webRequest = mock(WebRequest.class);

        // @When viewing employee groups for that campaign
        this.securityController.viewEmployeeGroups(campaignId, page, rows, sort, direction, webRequest);

        // @Then application.findEmployeeGroupsByPage is called with that campaign Id
        verify(this.securityApplication, times(1)).findEmployeeGroupsByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == page;
            }
        }), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testViewEmployeeGroupsPageCallsApplicationFindEmployeeGroupsByPageWithSize25_WhenViewingEmployeeGroupsPageWithSize25() {
        // @Given a campaignId 1
        int campaignId = 5;
        final int page = 7;
        final int rows = 25;
        String sort = "";
        String direction = "asc";
        WebRequest webRequest = mock(WebRequest.class);

        // @When viewing employee groups for that campaign
        this.securityController.viewEmployeeGroups(campaignId, page, rows, sort, direction, webRequest);

        // @Then application.findEmployeeGroupsByPage is called with that campaign Id
        verify(this.securityApplication, times(1)).findEmployeeGroupsByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageSize() == rows;
            }
        }), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testViewEmployeeGroupsPageCallsApplicationFindEmployeeGroupsByPageWithSize52_WhenViewingEmployeeGroupsPageWithSize52() {
        // @Given a campaignId 1
        int campaignId = 5;
        final int page = 7;
        final int rows = 52;
        String sort = "";
        String direction = "asc";
        WebRequest webRequest = mock(WebRequest.class);

        // @When viewing employee groups for that campaign
        this.securityController.viewEmployeeGroups(campaignId, page, rows, sort, direction, webRequest);

        // @Then application.findEmployeeGroupsByPage is called with that campaign Id
        verify(this.securityApplication, times(1)).findEmployeeGroupsByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageSize() == rows;
            }
        }), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testViewEmployeeGroupsPageCallsApplicationFindEmployeeGroupsByPageWithSortName_WhenViewingEmployeeGroupsPageWithSortEmpty() {
        // @Given a campaignId 1
        int campaignId = 5;
        final int page = 7;
        final int rows = 52;
        String sort = "";
        String direction = "asc";
        WebRequest webRequest = mock(WebRequest.class);

        // @When viewing employee groups for that campaign
        this.securityController.viewEmployeeGroups(campaignId, page, rows, sort, direction, webRequest);

        // @Then application.findEmployeeGroupsByPage is called with that campaign Id
        verify(this.securityApplication, times(1)).findEmployeeGroupsByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("name") != null;
            }
        }), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testViewEmployeeGroupsPageCallsApplicationFindEmployeeGroupsByPageWithSortUsername_WhenViewingEmployeeGroupsPageWithSortUsername() {
        // @Given a campaignId 1
        int campaignId = 5;
        final int page = 7;
        final int rows = 52;
        String sort = "username";
        String direction = "asc";
        WebRequest webRequest = mock(WebRequest.class);

        // @When viewing employee groups for that campaign
        this.securityController.viewEmployeeGroups(campaignId, page, rows, sort, direction, webRequest);

        // @Then application.findEmployeeGroupsByPage is called with that campaign Id
        verify(this.securityApplication, times(1)).findEmployeeGroupsByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("username") != null;
            }
        }), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testViewEmployeeGroupsPageCallsApplicationFindEmployeeGroupsByPageWithSortDirectionAsc_WhenViewingEmployeeGroupsPageWithSortedAsc() {
        // @Given a campaignId 1
        int campaignId = 5;
        final int page = 7;
        final int rows = 52;
        String sort = "username";
        String direction = "asc";
        WebRequest webRequest = mock(WebRequest.class);

        // @When viewing employee groups for that campaign
        this.securityController.viewEmployeeGroups(campaignId, page, rows, sort, direction, webRequest);

        // @Then application.findEmployeeGroupsByPage is called with that campaign Id
        verify(this.securityApplication, times(1)).findEmployeeGroupsByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("username").getDirection().equals(Sort.Direction.ASC);
            }
        }), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testViewEmployeeGroupsPageCallsApplicationFindEmployeeGroupsByPageWithSortDirectionDesc_WhenViewingEmployeeGroupsPageWithSortedDesc() {
        // @Given a campaignId 1
        int campaignId = 5;
        final int page = 7;
        final int rows = 52;
        String sort = "username";
        String direction = "desc";
        WebRequest webRequest = mock(WebRequest.class);

        // @When viewing employee groups for that campaign
        this.securityController.viewEmployeeGroups(campaignId, page, rows, sort, direction, webRequest);

        // @Then application.findEmployeeGroupsByPage is called with that campaign Id
        verify(this.securityApplication, times(1)).findEmployeeGroupsByPage(eq(campaignId), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("username").getDirection().equals(Sort.Direction.DESC);
            }
        }), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testListEmployeesCallsApplicationListEmployeesWithCampaignId1_WhenListingEmployeesForCampaign1() {
        // @Given a campaign id 1
        int campaignId = 1;

        // @When listing it's employees
        this.securityController.listEmployees(campaignId);

        // @Then application.listEmployees is called with id 1
        verify(this.securityApplication, times(1)).listEmployees(campaignId);
    }

    @Test
    public void testListEmployeesCallsApplicationListEmployeesWithCampaignId2_WhenListingEmployeesForCampaign2() {
        // @Given a campaign id 2
        int campaignId = 2;

        // @When listing it's employees
        this.securityController.listEmployees(campaignId);

        // @Then application.listEmployees is called with id 1
        verify(this.securityApplication, times(1)).listEmployees(campaignId);
    }

    @Test
    public void testListEmployeesReturnsApplicationResultAsVos_WhenListingEmployeesForACampaign() {
        // @Given a campaign
        int campaignId = 1;
        Employee employee = new Employee();
        Campaign campaign = new Campaign("kakak", new Date(), new Date());
        campaign.setId(campaignId);
        employee.setCampaign(campaign);

        employee.setName("Leroy Jenkins");
        when(this.securityApplication.listEmployees(campaignId)).thenReturn(Lists.<Employee>newArrayList(employee));

        // @When listing it's employees
        List<EmployeeVO> employeeVOs = this.securityController.listEmployees(campaignId);

        // @Then returns application result as Vos
        assertThat(employeeVOs).onProperty("name").contains(employee.getName());
    }

    @Test
    public void testFindEmployeeByCampaignIdAndEmployeeIdCallsApplicationFindEmployeeByCampaignId1AndEmployeeId1_WhenFindingEmployee1InCampaign1() {
        // @Given an employee Id and a campaign Id
        int campaignId = 1;
        long employeeId = 1l;
        Campaign campaign = new Campaign("hi", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign.setId(campaignId);
        Employee employee = new Employee();
        employee.setId(employeeId);
        employee.setCampaign(campaign);
        when(this.securityApplication.findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId)).thenReturn(employee);

        // @When finding a matching employee
        this.securityController.findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId);

        // @Then application findEmployeeByCampaignIdAndEmployeeId is called
        verify(this.securityApplication, times(1)).findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId);
    }

    @Test
    public void testFindEmployeeByCampaignIdAndEmployeeIdCallsApplicationFindEmployeeByCampaignId4AndEmployeeId6_WhenFindingEmployee6InCampaign4() {
        // @Given an employee Id and a campaign Id
        int campaignId = 4;
        long employeeId = 6l;
        Campaign campaign = new Campaign("hi", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign.setId(campaignId);
        Employee employee = new Employee();
        employee.setId(employeeId);
        employee.setCampaign(campaign);
        when(this.securityApplication.findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId)).thenReturn(employee);

        // @When finding a matching employee
        this.securityController.findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId);

        // @Then application findEmployeeByCampaignIdAndEmployeeId is called
        verify(this.securityApplication, times(1)).findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId);
    }

    @Test
    public void testFindEmployeeByCampaignIdAndEmployeeIdReturnsEmployeeVoMatchingApplicationResult_WhenFindingEmployeeInCampaign() {
        // @Given an employee Id and a campaign Id
        int campaignId = 1;
        long employeeId = 2l;
        Campaign campaign = new Campaign("hi", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign.setId(campaignId);
        Employee employee = new Employee();
        employee.setId(employeeId);
        employee.setCampaign(campaign);
        when(this.securityApplication.findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId)).thenReturn(employee);

        // @When finding a matching employee
        EmployeeVO employeeVO = this.securityController.findEmployeeByCampaignIdAndEmployeeId(campaignId, employeeId);

        // @Then application findEmployeeByCampaignIdAndEmployeeId is called
        assertThat(employeeVO.getId()).isEqualTo(employee.getId());
    }

    @Test
    public void testUpdateEmployeeGroupsCallsApplicationUpdateEmployeeGroupsWithCampaignId1AndInputGroups_WhenUpdatingCampaign1GroupsWithInput() {
        // @Given a map indicating an employeeId and which groups it belongs to and a campaignId
        int campaignId = 1;
        Map<String, Object> employeeGroups = Maps.newHashMap();
        employeeGroups.put("GroupName", Boolean.TRUE);

        // @When updating the groups
        this.securityController.updateEmployeeGroups(campaignId, employeeGroups);

        // @Then application update groups is called
        verify(this.securityApplication, times(1)).updateEmployeeGroups(campaignId, employeeGroups);
    }

    @Test
    public void testUpdateEmployeeGroupsCallsApplicationUpdateEmployeeGroupsWithCampaignId2AndInputGroups_WhenUpdatingCampaign2GroupsWithInput() {
        // @Given a map indicating an employeeId and which groups it belongs to and a campaignId
        int campaignId = 2;
        Map<String, Object> employeeGroups = Maps.newHashMap();

        // @When updating the groups
        this.securityController.updateEmployeeGroups(campaignId, employeeGroups);

        // @Then application update groups is called
        verify(this.securityApplication, times(1)).updateEmployeeGroups(campaignId, employeeGroups);
    }

    @Test
    public void testCreateEmployeeCallsApplicationCreateEmployeeForCampaign1WithInputVO_WhenCreatingANewEmployeeForCampaign1() {
        // @Given a campaign id and an input VO
        final int campaignId = 1;
        long employeeId = 1;
        final EmployeeVO employeeVO = new EmployeeVO();
        employeeVO.setId(employeeId);
        Employee expected = new Employee();
        expected.setName(employeeVO.getName());
        Campaign campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2012, 2, 2));
        campaign.setId(campaignId);
        expected.setCampaign(campaign);
        when(this.securityApplication.createEmployee(employeeVO)).thenReturn(expected);

        // @When creating a matching employee for the campaign
        this.securityController.createEmployee(campaignId, employeeVO);

        // @Then application.createEmployee(campaignId, inputVO) is called
        verify(this.securityApplication, times(1)).createEmployee(argThat(new ArgumentMatcher<EmployeeVO>() {
            @Override
            public boolean matches(Object argument) {
                return argument == employeeVO && ((EmployeeVO) argument).getCampaignId() == campaignId;
            }
        }));
    }

    @Test
    public void testCreateEmployeeCallsApplicationCreateEmployeeForCampaign4WithInputVO_WhenCreatingANewEmployeeForCampaign4() {
        // @Given a campaign id and an input VO
        final int campaignId = 4;
        final EmployeeVO employeeVO = new EmployeeVO();
        Employee expected = new Employee();
        expected.setName(employeeVO.getName());
        Campaign campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2012, 2, 2));
        campaign.setId(campaignId);
        expected.setCampaign(campaign);
        when(this.securityApplication.createEmployee(employeeVO)).thenReturn(expected);

        // @When creating a matching employee for the campaign
        this.securityController.createEmployee(campaignId, employeeVO);

        // @Then application.createEmployee(campaignId, inputVO) is called
        verify(this.securityApplication, times(1)).createEmployee(argThat(new ArgumentMatcher<EmployeeVO>() {
            @Override
            public boolean matches(Object argument) {
                return argument == employeeVO && ((EmployeeVO) argument).getCampaignId() == campaignId;
            }
        }));
    }

    @Test
    public void testCreateEmployeeReturnsApplicationResult_WhenCreatingANewEmployeeForCampaign4() {
        // @Given a campaign id and an input VO
        int campaignId = 4;
        EmployeeVO employeeVO = new EmployeeVO();
        employeeVO.setName("Hi");

        Employee expected = new Employee();
        expected.setName(employeeVO.getName());
        Campaign campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2012, 2, 2));
        campaign.setId(campaignId);
        expected.setCampaign(campaign);
        when(this.securityApplication.createEmployee(employeeVO)).thenReturn(expected);

        // @When creating a matching employee for the campaign
        EmployeeVO result = this.securityController.createEmployee(campaignId, employeeVO);

        // @Then applications result is returned as a vo
        assertThat(result.getCampaignId()).isEqualTo(campaignId);
        assertThat(result.getName()).isEqualTo(employeeVO.getName());
    }

    @Test
    public void testUpdateEmployeeCallsApplicationUpdateEmployee1forCampaign1_WhenUpdatingEmployee1forCampaign1() {
        // @Given a campaign Id 1, an employeeId 1 and an employeeVO
        int campaignId = 1;
        final long employeeId = 1l;
        EmployeeVO employeeVO = new EmployeeVO();

        // @When updating employee 1 of campaign 1 with employeeVO
        this.securityController.updateEmployee(campaignId, employeeId, employeeVO);

        // @Then applications update employee is called and campaign id is 1 and employeeVO id is 1
        verify(this.securityApplication, times(1)).updateEmployee(eq(campaignId), argThat(new ArgumentMatcher<EmployeeVO>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof EmployeeVO && ((EmployeeVO) argument).getId().equals(employeeId);
            }
        }));
    }

    @Test
    public void testUpdateEmployeeCallsApplicationUpdateEmployee3forCampaign5_WhenUpdatingEmployee3forCampaign5() {
        // @Given a campaign Id 5, an employeeId 3 and an employeeVO
        int campaignId = 5;
        final long employeeId = 3l;
        EmployeeVO employeeVO = new EmployeeVO();

        // @When updating employee 3 of campaign 5 with employeeVO
        this.securityController.updateEmployee(campaignId, employeeId, employeeVO);

        // @Then applications update employee is called and campaign id is 5 and employeeVO id is 3
        verify(this.securityApplication, times(1)).updateEmployee(eq(campaignId), argThat(new ArgumentMatcher<EmployeeVO>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof EmployeeVO && ((EmployeeVO) argument).getId().equals(employeeId);
            }
        }));
    }

    @Test
    public void testDeleteAdminUserCallsApplicationDeleteAdminUser1_WhenDeletingAdminUser1() {
        // @Given and admin user id 1
        int adminUserId = 1;

        // @When deleting admin user 1
        this.securityController.deleteAdminUser(adminUserId);

        // @Then applicationDeleteAdminUser 1 is called
        verify(this.securityApplication, times(1)).deleteAdminUser(adminUserId);
    }

    @Test
    public void testDeleteAdminUserCallsApplicationDeleteAdminUser2_WhenDeletingAdminUser1() {
        // @Given and admin user id 2
        int adminUserId = 2;

        // @When deleting admin user 2
        this.securityController.deleteAdminUser(adminUserId);

        // @Then applicationDeleteAdminUser 2 is called
        verify(this.securityApplication, times(1)).deleteAdminUser(adminUserId);
    }

    @Test
    public void testViewAuditLogsPageCallsApplicationsAuditLogsByPageWithPageOnePageRowsTenDataTableIdOne_WhenViewingPageOneWithTenRowsPerPage() {
        // @Given an existing row
        int pageNumber = 1;
        int pageRows = 10;
        String sort = "aColumn";
        String direction = "asc";
        final PageRequest pageRequest = new PageRequest(pageNumber, pageRows, new Sort(Sort.getDirection(direction), sort));

        WebRequest wr = mock(WebRequest.class);

        // @When seeing the first page of rows
        this.securityController.viewAuditLogsPage(pageNumber, pageRows, sort, direction, wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.securityApplication, times(1)).findAuditLogsByPage(argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == pageRequest.getPageNumber() && ((PageRequest) argument).getPageSize() == pageRequest.getPageSize();
            }
        }), eq(Maps.<String, Object>newHashMap()));
    }

    @Test
    public void testViewAuditLogsPageCallsApplicationsAuditLogsByPageWithSortById_WhenSortIsNotSpecified() {
        // @Given an existing row
        int pageNumber = 1;
        int pageRows = 10;
        String sort = "";
        String direction = "";

        WebRequest wr = mock(WebRequest.class);

        // @When seeing the first page of rows
        this.securityController.viewAuditLogsPage(pageNumber, pageRows, sort, direction, wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.securityApplication, times(1)).findAuditLogsByPage(argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && !((PageRequest) argument).getSort().getOrderFor("date").isAscending();
            }
        }), eq(Maps.<String, Object>newHashMap()));
    }

    @Test
    public void testViewAuditLogsPageCallsApplicationsAuditLogsByPageWithFilterColumnAEqualsOne_WhenViewingPageOneWithFilterColumnAEqualsOne() {
        // @Given an existing row
        int pageNumber = 2;
        int pageRows = 25;
        String sort = "column";
        String direction = "desc";

        WebRequest wr = mock(WebRequest.class);
        when(wr.getParameterNames()).thenReturn(Lists.newArrayList("A").iterator());
        when(wr.getParameter("A")).thenReturn("One");

        // @When seeing the first page of rows
        this.securityController.viewAuditLogsPage(pageNumber, pageRows, sort, direction, wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.securityApplication, times(1)).findAuditLogsByPage(Matchers.<PageRequest>any(), argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof Map && ((Map) argument).containsKey("A") && ((Map) argument).get("A").equals("One");
            }
        }));
    }

    @Test
    public void testViewAuditLogsPageCallsApplicationsAuditLogsByPageWithDefaultSort_WhenViewingLogsWithNoSpecificSort() {
        // @Given an existing row
        WebRequest wr = mock(WebRequest.class);

        // @When seeing the first page of rows
        this.securityController.viewAuditLogsPage(3, 20, null, "", wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.securityApplication, times(1)).findAuditLogsByPage(argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                if (argument instanceof PageRequest) {
                    PageRequest pageRequest = (PageRequest) argument;
                    Sort.Order order = pageRequest.getSort().getOrderFor("date");
                    return order != null && !order.isAscending();
                }
                return false;
            }
        }), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testViewActionLogsPageCallsApplicationsAuditLogsByPageWithPageOnePageRowsTenDataTableIdOne_WhenViewingPageOneWithTenRowsPerPage() {
        // @Given an existing row
        int pageNumber = 1;
        int pageRows = 10;
        String sort = "aColumn";
        String direction = "asc";
        final PageRequest pageRequest = new PageRequest(pageNumber, pageRows, new Sort(Sort.getDirection(direction), sort));

        WebRequest wr = mock(WebRequest.class);

        // @When seeing the first page of rows
        this.securityController.viewActionLogsPage(pageNumber, pageRows, sort, direction, wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.securityApplication, times(1)).findActionLogsByPage(argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == pageRequest.getPageNumber() && ((PageRequest) argument).getPageSize() == pageRequest.getPageSize();
            }
        }), eq(Maps.<String, Object>newHashMap()));
    }

    @Test
    public void testViewActionLogsPageCallsApplicationsActionLogsByPageWithSortById_WhenSortIsNotSpecified() {
        // @Given an existing row
        int pageNumber = 1;
        int pageRows = 10;
        String sort = "";
        String direction = "";

        WebRequest wr = mock(WebRequest.class);

        // @When seeing the first page of rows
        this.securityController.viewActionLogsPage(pageNumber, pageRows, sort, direction, wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.securityApplication, times(1)).findActionLogsByPage(argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && !((PageRequest) argument).getSort().getOrderFor("date").isAscending();
            }
        }), eq(Maps.<String, Object>newHashMap()));
    }

    @Test
    public void testViewActionLogsPageCallsApplicationsActionLogsByPageWithFilterColumnAEqualsOne_WhenViewingPageOneWithFilterColumnAEqualsOne() {
        // @Given an existing row
        int pageNumber = 2;
        int pageRows = 25;
        String sort = "column";
        String direction = "desc";

        WebRequest wr = mock(WebRequest.class);
        when(wr.getParameterNames()).thenReturn(Lists.newArrayList("A").iterator());
        when(wr.getParameter("A")).thenReturn("One");

        // @When seeing the first page of rows
        this.securityController.viewActionLogsPage(pageNumber, pageRows, sort, direction, wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.securityApplication, times(1)).findActionLogsByPage(Matchers.<PageRequest>any(), argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof Map && ((Map) argument).containsKey("A") && ((Map) argument).get("A").equals("One");
            }
        }));
    }

    @Test
    public void testViewActionLogsPageCallsApplicationsActionLogsByPageWithDefaultSort_WhenViewingLogsWithNoSpecificSort() {
        // @Given an existing row
        WebRequest wr = mock(WebRequest.class);

        // @When seeing the first page of rows
        this.securityController.viewActionLogsPage(3, 20, null, "", wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.securityApplication, times(1)).findActionLogsByPage(argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                if (argument instanceof PageRequest) {
                    PageRequest pageRequest = (PageRequest) argument;
                    Sort.Order order = pageRequest.getSort().getOrderFor("date");
                    return order != null && !order.isAscending();
                }
                return false;
            }
        }), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testDeleteGroupCallsApplicationDeleteGroup1_WhenDeletingGroup1() {
        // @Given a group id 1
        int groupId = 1;

        // @When deleting the group
        this.securityController.deleteGroup(groupId);

        // @Then application.deleteGroup(1) is called
        verify(this.securityApplication, times(1)).deleteGroup(groupId);
    }

    @Test
    public void testDeleteGroupCallsApplicationDeleteGroup7_WhenDeletingGroup7() {
        // @Given a group id 7
        int groupId = 7;

        // @When deleting the group
        this.securityController.deleteGroup(groupId);

        // @Then application.deleteGroup(1) is called
        verify(this.securityApplication, times(1)).deleteGroup(groupId);
    }

}
