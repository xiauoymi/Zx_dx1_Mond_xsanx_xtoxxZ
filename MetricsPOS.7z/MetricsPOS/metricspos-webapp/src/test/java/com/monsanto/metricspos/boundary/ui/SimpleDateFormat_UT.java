package com.monsanto.metricspos.boundary.ui;

import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import static org.fest.assertions.Assertions.assertThat;

/**
 * Tests for SimpleDateFormat. Converter an 'Z' usage issue
 * User: PPERA
 */
public class SimpleDateFormat_UT {

    @Test
    public void testParse_ISO_8106_UTC_Date() throws Exception {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

        String dateStr = "2012-08-24T00:00:00.000Z";
        Date date = df.parse(dateStr);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);

        // @Then
        assertThat(calendar.get(Calendar.YEAR)).isEqualTo( 2012 );
        assertThat(calendar.get(Calendar.MONTH)).isEqualTo( 8 - 1 );
        assertThat(calendar.get(Calendar.DAY_OF_MONTH)).isEqualTo( 24 );
        assertThat(calendar.get(Calendar.HOUR_OF_DAY)).isEqualTo( 0 );
        assertThat(calendar.get(Calendar.MINUTE)).isEqualTo( 0 );
        assertThat(calendar.get(Calendar.SECOND)).isEqualTo( 0 );
        assertThat(calendar.get(Calendar.MILLISECOND)).isEqualTo( 0 );
    }


}
