package com.monsanto.metricspos.boundary.ui;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.boundary.helpers.WebAppTestsHelper;
import com.monsanto.metricspos.core.DataLoader;
import com.monsanto.metricspos.core.ExportServices;
import com.monsanto.metricspos.core.TablesApplication;
import com.monsanto.metricspos.core.application.exceptions.BusinessException;
import com.monsanto.metricspos.core.application.vo.DataColumnVO;
import com.monsanto.metricspos.core.application.vo.DataRowVO;
import com.monsanto.metricspos.core.application.vo.DataTableVO;
import com.monsanto.metricspos.core.externaldata.*;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.dao.Sort;
import com.monsanto.metricspos.dao.support.PageRequest;
import com.monsanto.metricspos.persistence.DataRowPersistor;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.ReflectiveDataRowPersistorFactory;
import com.monsanto.metricspos.persistence.RowValues;
import com.monsanto.metricspos.services.excel.XlsExportServiceImpl;
import junit.framework.Assert;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Matchers;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.*;

import static com.monsanto.utils.DateUtils.newDate;
import static junit.framework.Assert.assertNotNull;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class TableController_UT {
    private static final String EXCEL_FILE_NAME = "/test.xlsx";

    private TablesApplication tablesApplication;
    private TableController tableController;

    private WebAppTestsHelper webAppTestsHelper;
    private DataLoader dataLoader;
    private ExportServices exportServices;

    @Before
    public void setUp() {

        this.tableController = new TableController();
        this.tablesApplication = mock(TablesApplication.class);
        this.dataLoader = mock(DataLoader.class);
        this.exportServices = mock(XlsExportServiceImpl.class);

        Logger auditLog = mock(Logger.class);
        Logger actionLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(this.tableController).set(auditLog);
        field("actionLog").ofType(Logger.class).in(this.tableController).set(actionLog);

        field("application").ofType(TablesApplication.class).in(this.tableController).set(this.tablesApplication);
        field("dataLoader").ofType(DataLoader.class).in(this.tableController).set(this.dataLoader);
        field("exportServices").ofType(ExportServices.class).in(this.tableController).set(this.exportServices);

        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("CRM");
        dataProvider.setName("Client Relationship Manager");

        DataRowPersistorFactory dataRowPersistorFactory = new ReflectiveDataRowPersistorFactory();

        Map<Class, String> classXprefix = Maps.newHashMap();
        classXprefix.put(String.class, RowValues.TEXT_COLUMN_PREFIX);
        classXprefix.put(Integer.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Long.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(BigDecimal.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Number.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Date.class, RowValues.DATE_COLUMN_PREFIX);

        field("classToPrefixMap").ofType(Map.class).in(dataRowPersistorFactory).set(classXprefix);

        Campaign campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign.setId(1);

        webAppTestsHelper = new WebAppTestsHelper(dataProvider, campaign, dataRowPersistorFactory);

        HashMap<String, DataType> dataTypeMap = Maps.newHashMap();
        dataTypeMap.put("string", webAppTestsHelper.stringDataType());
    }

    @Test
    public void testViewCallsFindTableByIdWithIdEqualsOne_WhenViewingTableWithIdEqualsOne() {
        // @Given an existing DataTable
        int DATA_TABLE_1 = 1;
        DataTable dataTable = webAppTestsHelper.newDataTable(DATA_TABLE_1, "tableName", "description", Lists.newArrayList(webAppTestsHelper.newDataColumn("columnName")));
        when(this.tablesApplication.findDataTableById(DATA_TABLE_1)).thenReturn(dataTable);

        // @When the table is viewed
        this.tableController.view(1, DATA_TABLE_1);

        // @Then the table data is returned
        verify(this.tablesApplication, times(1)).findDataTableById(DATA_TABLE_1);
    }

    @Test
    public void testViewReturnsMatchingDataTable_WhenTableIdEqualsTwo() {
        // @Given an existing DataTable with Id = 2
        DataTable dataTable1 = webAppTestsHelper.newDataTable(1, "table1", "description", Lists.<DataColumn>newArrayList());
        DataTable dataTable2 = webAppTestsHelper.newDataTable(2, "table2", "description", Lists.<DataColumn>newArrayList());
        when(this.tablesApplication.findDataTableById(dataTable1.getId())).thenReturn(dataTable1);
        when(this.tablesApplication.findDataTableById(dataTable2.getId())).thenReturn(dataTable2);

        // @When viewing the table
        DataTableVO dataTableVO = this.tableController.view(1, dataTable2.getId());

        // @Then the matching DataTableVO is returned
        assertThat(dataTableVO.getId()).isEqualTo(dataTable2.getId());
        assertThat(dataTableVO.getName()).isEqualTo(dataTable2.getName());
    }

    @Test
    public void testUpdateUsesPassedDataTableVO_WhenCallingUpdateDataTable() {
        // @Given an existing table
        DataTableVO dataTableVO = webAppTestsHelper.newDataTableVO(1, "a new Name", "a new description");

        // @When updating the table
        this.tableController.update(1, dataTableVO.getId(), dataTableVO);

        // @Then the table is updated
        verify(this.tablesApplication, times(1)).updateDataTable(dataTableVO);
    }

    @Test
    public void testUpdateCallUpdateDataTableWithAVOWithIdOne_WhenCallingUpdateWithIdOne() {
        // @Given an existing table
        final DataTableVO dataTableVO = webAppTestsHelper.newDataTableVO(1, "a new Name", "a new description");

        // @When updating the table
        this.tableController.update(1, dataTableVO.getId(), dataTableVO);

        // @Then the table is updated
        verify(this.tablesApplication, times(1)).updateDataTable(argThat(new ArgumentMatcher<DataTableVO>() {

            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableVO && ((DataTableVO) argument).getId().equals(dataTableVO.getId());
            }
        }));
    }

    @Test
    public void testUpdateCallUpdateDataTableWithAVOWithIdTwo_WhenCallingUpdateWithIdTwo() {
        // @Given an existing table
        final DataTableVO dataTableVO = webAppTestsHelper.newDataTableVO(2, "a new Name", "a new description");

        // @When updating the table
        this.tableController.update(1, dataTableVO.getId(), dataTableVO);

        // @Then the table is updated
        verify(this.tablesApplication, times(1)).updateDataTable(argThat(new ArgumentMatcher<DataTableVO>() {

            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableVO && ((DataTableVO) argument).getId().equals(dataTableVO.getId());
            }
        }));
    }

    @Test
    public void testViewMetadataCallsFindDataTableByIdWithIdOne_WhenViewingTheMetadataOfTableOne() {
        // @Given an existing table
        int tableId = 1;

        // @When viewing the metadata
        this.tableController.viewMetadata(1, tableId);

        // @Then the table's columns are returned
        verify(this.tablesApplication, times(1)).findMetadataByDataTableId(tableId);
    }

    @Test
    public void testViewMetadataCallsFindDataTableByIdWithIdTwo_WhenViewingTheMetadataOfTableTwo() {
        // @Given an existing table
        int tableId = 2;

        // @When viewing the metadata
        this.tableController.viewMetadata(1, tableId);

        // @Then the table's columns are returned
        verify(this.tablesApplication, times(1)).findMetadataByDataTableId(tableId);
    }

    @Test
    public void testViewMetadataReturnsOneDataColumnWithIdOne_WhenApplicationFindsOneColumnWithIdOne() {
        // @Given an existing table
        int tableId = 2;
        DataColumn column = new DataColumn();
        column.setId(1);
        DataType dataType = new DataType();
        dataType.setCode("hi");
        column.setDataType(dataType);
        when(this.tablesApplication.findMetadataByDataTableId(tableId)).thenReturn(Lists.<DataColumn>newArrayList(column));

        // @When viewing the metadata
        List<DataColumnVO> dataColumnVOs = this.tableController.viewMetadata(1, tableId);

        // @Then the table's columns are returned
        assertThat(dataColumnVOs).onProperty("id").contains(1);
    }

    @Test
    public void testViewMetadataReturnsTwoDataColumnsWithIdTwoAndThree_WhenApplicationFindsTwoColumnsWithIdTwoAndThree() {
        // @Given an existing table
        int tableId = 2;
        DataColumn column2 = new DataColumn();
        column2.setId(2);
        DataType dataType = new DataType();
        dataType.setCode("hi");
        column2.setDataType(dataType);
        DataColumn column3 = new DataColumn();
        column3.setId(3);
        column3.setDataType(dataType);
        when(this.tablesApplication.findMetadataByDataTableId(tableId)).thenReturn(Lists.<DataColumn>newArrayList(column2, column3));

        // @When viewing the metadata
        List<DataColumnVO> dataColumnVOs = this.tableController.viewMetadata(1, tableId);

        // @Then the table's columns are returned
        assertThat(dataColumnVOs).onProperty("id").contains(2, 3);
    }

    @Test
    public void testRemoveDataTableCallsApplicationsRemoveDataTableWithIdOne_WhenRemovingTableOne() {
        // @Given an existing data table
        int tableId = 1;

        // @When removing the data table
        this.tableController.delete(1, tableId);

        // @The application removes the table an returns the removed table VO
        verify(this.tablesApplication, times(1)).removeDataTable(tableId);
    }

    @Test
    public void testRemoveDataTableCallsApplicationsRemoveDataTableWithIdTwo_WhenRemovingTableTwo() {
        // @Given an existing data table
        int tableId = 2;

        // @When removing the data table
        this.tableController.delete(1, tableId);

        // @The application removes the table an returns the removed table VO
        verify(this.tablesApplication, times(1)).removeDataTable(tableId);
    }


    @Test
    public void testCreateDataTableCallsApplicationsNewDataTableWithInputVO_WhenCreatingADataTableFromTheVO() {
        // @Given an existing campaign
        DataTableVO dataTableVO = webAppTestsHelper.newDataTableVO("tableName", "description");

        // @When creating a data table for that campaign
        this.tableController.createDataTable(1, dataTableVO);

        // @The data table is created and it's returned
        verify(this.tablesApplication, times(1)).newDataTable(dataTableVO);
    }


    @Test
    public void testUpdateMetadataCallsApplicationsUpdateMetadata_WhenUpdatingAnExistingTableMetadata() {
        // @Given an existing data table with two columns
        int tableId = 1;
        DataColumnVO[] dataColumnVOs = {
                webAppTestsHelper.newDataColumnVO("updatedOne", "string", "the column to be updated", 10, 9, 10, true, true, true, false),
                webAppTestsHelper.newDataColumnVO("newOne", "string", "the column to be created", 11, 12, 13, false, false, false, false)
        };

        // @When Updating the metadata by removing a column, updating another and adding a new one
        this.tableController.updateMetadata(1, tableId, dataColumnVOs);

        // @Then the metadata is now formed by the updates column and the new one
        verify(this.tablesApplication, times(1)).updateMetadata(tableId, Lists.<DataColumnVO>newArrayList(dataColumnVOs));
    }

    @Test
    public void testViewRowsPageCallsApplicationsFindRowsByDataTableIdAndPageWithPageOnePageRowsTenDataTableIdOne_WhenViewingPageOneWithTenRowsPerPageForTableIdOne() {
        // @Given an existing row
        DataTable dataTable = webAppTestsHelper.newDataTable(1, "tableName", "description", Lists.<DataColumn>newArrayList(webAppTestsHelper.newDataColumn("aColumn")));
        int pageNumber = 1;
        int pageRows = 10;
        String sort = "aColumn";
        String direction = "asc";
        final PageRequest pageRequest = new PageRequest(pageNumber, pageRows, new Sort(Sort.getDirection(direction), sort));

        WebRequest wr = mock(WebRequest.class);

        // @When seeing the first page of rows
        this.tableController.viewRowsPage(1, dataTable.getId(), pageNumber, pageRows, sort, direction, wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.tablesApplication, times(1)).findRowsByDataTableIdAndPage(eq(dataTable.getId()), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getPageNumber() == pageRequest.getPageNumber() && ((PageRequest) argument).getPageSize() == pageRequest.getPageSize();
            }
        }), eq(Maps.<String, Object>newHashMap()));
    }

    @Test
    public void testViewRowsPageCallsApplicationsFindRowsByDataTableIdAndPageWithSortById_WhenSortIsNotSpecified() {
        // @Given an existing row
        DataTable dataTable = webAppTestsHelper.newDataTable(1, "tableName", "description", Lists.<DataColumn>newArrayList(webAppTestsHelper.newDataColumn("aColumn")));
        int pageNumber = 1;
        int pageRows = 10;
        String sort = "";
        String direction = "asc";

        WebRequest wr = mock(WebRequest.class);

        // @When seeing the first page of rows
        this.tableController.viewRowsPage(1, dataTable.getId(), pageNumber, pageRows, sort, direction, wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.tablesApplication, times(1)).findRowsByDataTableIdAndPage(eq(dataTable.getId()), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof PageRequest && ((PageRequest) argument).getSort().getOrderFor("serviceCenter").isAscending();
            }
        }), eq(Maps.<String, Object>newHashMap()));
    }

    @Test
    public void testViewRowsPageCallsApplicationsFindRowsByDataTableIdAndPageWithFilterColumnAEqualsOne_WhenViewingPageOneWithFilterColumnAEqualsOne() {
        // @Given an existing row
        DataTable dataTable = webAppTestsHelper.newDataTable(1, "tableName", "description", Lists.<DataColumn>newArrayList(webAppTestsHelper.newDataColumn("aColumn")));
        int pageNumber = 2;
        int pageRows = 25;
        String sort = "column";
        String direction = "desc";

        WebRequest wr = mock(WebRequest.class);
        when(wr.getParameterNames()).thenReturn(Lists.newArrayList("A").iterator());
        when(wr.getParameter("A")).thenReturn("One");

        // @When seeing the first page of rows
        this.tableController.viewRowsPage(1, dataTable.getId(), pageNumber, pageRows, sort, direction, wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.tablesApplication, times(1)).findRowsByDataTableIdAndPage(eq(dataTable.getId()), Matchers.<PageRequest>any(), argThat(new ArgumentMatcher<Map<String, Object>>() {
            @Override
            public boolean matches(Object argument) {
                return argument instanceof Map && ((Map) argument).containsKey("A") && ((Map) argument).get("A").equals("One");
            }
        }));
    }

    @Test
    public void testViewRowsPageCallsApplicationsFindRowsByDataTableIdAndPageWithDefaultSort_WhenViewingRowsWithNoSpecificSort() {
        // @Given an existing row
        DataTable dataTable = webAppTestsHelper.newDataTable(1, "tableName", "description", Lists.<DataColumn>newArrayList(webAppTestsHelper.newDataColumn("aColumn")));
        WebRequest wr = mock(WebRequest.class);

        // @When seeing the first page of rows
        this.tableController.viewRowsPage(1, dataTable.getId(), 3, 20, null, "", wr);

        // @Then findRowsByDataTableAndPage with the corresponding parameters
        verify(this.tablesApplication, times(1)).findRowsByDataTableIdAndPage(eq(dataTable.getId()), argThat(new ArgumentMatcher<PageRequest>() {
            @Override
            public boolean matches(Object argument) {
                if (argument instanceof PageRequest) {
                    PageRequest pageRequest = (PageRequest) argument;
                    Sort.Order order = pageRequest.getSort().getOrderFor("serviceCenter");
                    return order != null && order.isAscending();
                }
                return false;
            }
        }), Matchers.<Map<String, Object>>any());
    }

    @Test
    public void testUpdateRowCallsApplicationUpdateRowWithIdOneAndRowData_WhenUpdatingRowOfTableOneWithRowData() {
        // @Given an existing data table and an existing row
        int tableId = 1;
        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(DataRowVO.ROW_ID_KEY, 1);

        // @When updating a row
        this.tableController.updateRow(1, tableId, rowData);

        // @Then tablesApplication.updateRow is called with the same parameters
        verify(this.tablesApplication, times(1)).updateRow(tableId, rowData);
    }

    @Test
    public void testUpdateRowCallsApplicationUpdateRowWithIdTwoAndRowData_WhenUpdatingRowOfTableTwoWithRowData() {
        // @Given an existing data table and an existing row
        int tableId = 2;
        Map<String, Object> rowData = Maps.newHashMap();
        rowData.put(DataRowVO.ROW_ID_KEY, 70);

        // @When updating a row
        this.tableController.updateRow(1, tableId, rowData);

        // @Then tablesApplication.updateRow is called with the same parameters
        verify(this.tablesApplication, times(1)).updateRow(tableId, rowData);
    }

    @Test
    public void testUpdateRowThrowsException_WhenRowIdIsNotProvided() {
        // @Given an existing data table and row data with no id
        int tableId = 1;
        Map<String, Object> rowData = Maps.newHashMap();

        // @When updating a row
        try {
            this.tableController.updateRow(1, tableId, rowData);
            fail();
        } catch (Exception e) {
            // @Then an exception is thrown
            assertThat(e).hasMessage(TableController.ERROR_ROW_ID_COULD_NOT_BE_RESOLVED);
        }
    }

    @Test
    public void testCreateRowCallsApplicationsCreateRowWithTableIdOneAndRowData_WhenCreatingARowInTableOneWithThatData() {
        // @Given an existing data table and data to create a row
        int tableId = 1;
        Map<String, Object> rowData = Maps.newHashMap();
        DataTable dataTable = mock(DataTable.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataTable.getDataRowPersistor()).thenReturn(dataRowPersistor);
        when(dataRowPersistor.getInternalId(Matchers.<DataRow>any())).thenReturn(1);

        Map<String, Object>[] rowDatas = new Map[]{rowData};

        // @When creating the row
        this.tableController.createRows(1, tableId, rowDatas);

        // @Then createRows is called
        verify(this.tablesApplication, times(1)).createRows(tableId, rowDatas);
    }

    @Test
    public void testCreateRowsReturnsOneRow_WhenApplicationCreatesOneRow() {
        // @Given an existing data table and data to create a row
        int tableId = 1;
        Map<String, Object> rowData = Maps.newHashMap();
        DataTable dataTable = mock(DataTable.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataTable.getDataRowPersistor()).thenReturn(dataRowPersistor);
        when(dataRowPersistor.getInternalId(Matchers.<DataRow>any())).thenReturn(1);

        Map<String, Object>[] rowDatas = new Map[]{rowData};
        DataRow dataRow = new DataRow(dataTable, new RowValues());
        when(this.tablesApplication.createRows(tableId, rowDatas)).thenReturn(Lists.<DataRow>newArrayList(dataRow));

        // @When creating the row
        List<DataRowVO> rows = this.tableController.createRows(1, tableId, rowDatas);

        // @Then 1 row is returned
        assertThat(rows).hasSize(1);
    }

    @Test
    public void testCreateRowsReturnsTwoRows_WhenApplicationCreatesOneRow() {
        // @Given an existing data table and data to create a row
        int tableId = 1;
        Map<String, Object> rowData1 = Maps.newHashMap();
        Map<String, Object> rowData2 = Maps.newHashMap();
        Map<String, Object> rowData3 = Maps.newHashMap();
        DataTable dataTable = mock(DataTable.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataTable.getDataRowPersistor()).thenReturn(dataRowPersistor);
        when(dataRowPersistor.getInternalId(Matchers.<DataRow>any())).thenReturn(1);

        Map<String, Object>[] rowDatas = new Map[]{rowData1, rowData2, rowData3};
        DataRow dataRow1 = new DataRow(dataTable, new RowValues());
        DataRow dataRow2 = new DataRow(dataTable, new RowValues());
        DataRow dataRow3 = new DataRow(dataTable, new RowValues());
        when(this.tablesApplication.createRows(tableId, rowDatas)).thenReturn(Lists.<DataRow>newArrayList(dataRow1, dataRow2, dataRow3));

        // @When creating the row
        List<DataRowVO> rows = this.tableController.createRows(1, tableId, rowDatas);

        // @Then 1 row is returned
        assertThat(rows).hasSize(3);
    }

    @Test
    public void testCreateRowCallsApplicationsCreateRowWithTableIdTwoAndRowData_WhenCreatingARowInTableTwoWithThatData() {
        // @Given an existing data table and data to create a row
        int tableId = 2;
        Map<String, Object> rowData = Maps.newHashMap();
        DataTable dataTable = mock(DataTable.class);
        DataRowPersistor dataRowPersistor = mock(DataRowPersistor.class);
        when(dataTable.getDataRowPersistor()).thenReturn(dataRowPersistor);
        when(dataRowPersistor.getInternalId(Matchers.<DataRow>any())).thenReturn(1);

        Map<String, Object>[] rowDatas = new Map[]{rowData};

        // @When creating the row
        this.tableController.createRows(1, tableId, rowDatas);

        // @Then createRows is called
        verify(this.tablesApplication, times(1)).createRows(tableId, rowDatas);
    }

    @Test
    public void testDeleteRowsCallsApplicationsDeleteRowsWithTableIdTwo_WhenDeletingRowsInTableTwo() {
        // @Given an existing table with Id 2 and an existing row with id 1
        int tableId = 2;
        Integer[] rowIds = {1};

        // @When deleting row 1 from table 2
        this.tableController.deleteRows(1, tableId, rowIds);

        // @Then application.deleteRows is called for table 2 and row 1
        verify(this.tablesApplication, times(1)).deleteRows(tableId, Lists.newArrayList(rowIds));
    }

    @Test
    public void testDeleteRowsCallsApplicationsDeleteRowsWithTableIdOne_WhenDeletingRowsInTableOne() {
        // @Given an existing table with Id 1 and an existing row with id 324
        int tableId = 1;
        Integer[] rowIds = {324};

        // @When deleting row 324 from table 1
        this.tableController.deleteRows(1, tableId, rowIds);

        // @Then application.deleteRows is called for table 1 and row 324
        verify(this.tablesApplication, times(1)).deleteRows(tableId, Lists.newArrayList(rowIds));
    }

    @Test
    public void testSaveAndExecuteLoadUsesPassedDataTableVO_WhenCallingSaveAndExecuteLoad() throws Exception {
        // @Given an existing table
        DataTableVO dataTableVO = webAppTestsHelper.newDataTableVO(1, "a new Name", "a new description");

        // @When updating the table
        this.tableController.saveAndExecuteLoad(1, dataTableVO.getId(), dataTableVO);

        // @Then the table is updated
        verify(this.dataLoader, times(1)).saveAndExecuteTableLoad(dataTableVO);
    }

    @Test
    public void testSaveAndExecuteLoadCallsSaveAndExecuteTableLoadWithAVOWithIdOne_WhenCallingUpdateWithIdOne() throws Exception {
        // @Given an existing table
        final DataTableVO dataTableVO = webAppTestsHelper.newDataTableVO(1, "a new Name", "a new description");

        // @When updating the table
        this.tableController.saveAndExecuteLoad(1, dataTableVO.getId(), dataTableVO);

        // @Then the table is updated
        verify(this.dataLoader, times(1)).saveAndExecuteTableLoad(argThat(new ArgumentMatcher<DataTableVO>() {

            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableVO && ((DataTableVO) argument).getId().equals(dataTableVO.getId());
            }
        }));
    }

    @Test
    public void testSaveAndExecuteLoadCallsSaveAndExecuteTableLoadWithAVOWithIdTwo_WhenCallingUpdateWithIdTwo() throws Exception {
        // @Given an existing table
        final DataTableVO dataTableVO = webAppTestsHelper.newDataTableVO(2, "a new Name", "a new description");

        // @When updating the table
        this.tableController.saveAndExecuteLoad(1, dataTableVO.getId(), dataTableVO);

        // @Then the table is updated
        verify(this.dataLoader, times(1)).saveAndExecuteTableLoad(argThat(new ArgumentMatcher<DataTableVO>() {

            @Override
            public boolean matches(Object argument) {
                return argument instanceof DataTableVO && ((DataTableVO) argument).getId().equals(dataTableVO.getId());
            }
        }));
    }

    @Test
    public void testSaveAndExecuteLoadThrowsException_WhenInputVOIsNull() throws Exception {
        // @Given an existing table
        final DataTableVO dataTableVO = null;

        // @When updating the table
        try {
            this.tableController.saveAndExecuteLoad(1, 1, dataTableVO);
            fail();
        } catch (BusinessException e) {
            assertThat(e.getErrorMessage()).isEqualTo(BusinessException.ERROR_VO_CANNOT_BE_NULL);
        }
    }

    @Test
    public void testImportDataCallsCreateRowsForTable1_WhenImportingDataInTable1() throws IOException {
        // @Given a tableId 1
        int tableId = 1;
        MultipartFile multipartFile = mock(MultipartFile.class);
        InputStream inputStream = readFile();
        byte[] fileData = new byte[inputStream.available()];
        inputStream.read(fileData);
        when(multipartFile.getBytes()).thenReturn(fileData);

        // @When importing data
        this.tableController.importData(1, tableId, multipartFile);

        // @Then createrRows is called for table 1
        verify(this.tablesApplication, times(1)).createRows(eq(tableId), Matchers.<Map<String, Object>[]>any());
    }

    @Test
    public void testImportDataReturnsOKAsAResult_WhenImportingDataInTable1() throws IOException {
        // @Given a tableId 1
        int tableId = 1;
        MultipartFile multipartFile = mock(MultipartFile.class);
        InputStream inputStream = readFile();
        byte[] fileData = new byte[inputStream.available()];
        inputStream.read(fileData);
        when(multipartFile.getBytes()).thenReturn(fileData);

        // @When importing data
        Map map = this.tableController.importData(1, tableId, multipartFile);

        // @Then createrRows is called for table 1
        assertThat(map.get("result")).isEqualTo("OK");
    }

    @Test
    public void testImportDataReturnsNGAsAResult_WhenImportingDataInTable1WithUnreadableFile() throws IOException {
        // @Given a tableId 1
        int tableId = 1;
        MultipartFile multipartFile = mock(MultipartFile.class);
        byte[] fileData = new byte[]{};
        when(multipartFile.getBytes()).thenReturn(fileData);

        // @When importing data
        Map map = this.tableController.importData(1, tableId, multipartFile);

        // @Then createrRows is called for table 1
        assertThat(map.get("result")).isEqualTo("NG");
    }

    @Test
    public void testExportDataCallsApplicationGetTableWithTableIdOne_WhenExportingDataOfTableOne() throws Exception {
        // @Given an existing table with Id 1
        int DATA_TABLE_1 = 1;
        DataTable dataTable = webAppTestsHelper.newDataTable(DATA_TABLE_1, "tableName", "description", Lists.newArrayList(webAppTestsHelper.newDataColumn("columnName")));
        when(this.tablesApplication.findDataTableById(DATA_TABLE_1)).thenReturn(dataTable);
        HttpServletResponse response = mock(HttpServletResponse.class);

        // @When exporting data from table 1
        this.tableController.exportData(1, DATA_TABLE_1, 0, 0, "", "", null, response);

        // @Then application find table by id is called for table 1
        verify(this.tablesApplication, times(1)).findDataTableById(DATA_TABLE_1);
    }

    @Test
    public void testExportDataCallsExportServiceWithDataTable_WhenExportingDataOfTableOne() throws Exception {
        // @Given an existing table with Id 1
        int DATA_TABLE_1 = 1;
        DataTable dataTable = webAppTestsHelper.newDataTable(DATA_TABLE_1, "tableName", "description", Lists.newArrayList(webAppTestsHelper.newDataColumn("columnName")));
        when(this.tablesApplication.findDataTableById(DATA_TABLE_1)).thenReturn(dataTable);
        HttpServletResponse response = mock(HttpServletResponse.class);

        // @When exporting data from table 1
        this.tableController.exportData(1, DATA_TABLE_1, 0, 0, "", "", null, response);

        // @Then exportservices export is called
        verify(this.exportServices, times(1)).export(response.getOutputStream(), dataTable, new ArrayList());
    }

    @Test
    public void testDownloadFileCallsApplicationFindRowDataFile2_WhenDownloadingTheDatafileOfARow2() throws Exception {
        // @Given a row id and a table id
        int tableId = 1;
        int rowId = 2;
        HttpServletResponse response = new MockHttpServletResponse();

        // @When downloading a matching file
        this.tableController.downloadFile(9, tableId, rowId, response);

        // @Then application findRowDataFile is called for that table and row
        verify(this.tablesApplication, times(1)).findRowDataFile(tableId, rowId);
    }

    @Test
    public void testDownloadFileCallsApplicationFindRowDataFile29_WhenDownloadingTheDatafileOfARow29() throws Exception {
        // @Given a row id and a table id
        int tableId = 34;
        int rowId = 29;
        HttpServletResponse response = new MockHttpServletResponse();

        // @When downloading a matching file
        this.tableController.downloadFile(9, tableId, rowId, response);

        // @Then application findRowDataFile is called for that table and row
        verify(this.tablesApplication, times(1)).findRowDataFile(tableId, rowId);
    }

    @Test
    public void testDownloadFileSendAFileBackToTheClientCreatedFromTheDataFileObjectFound_WhenDownloadingTheDatafileOfARow29() throws Exception {
        // @Given a row id and a table id
        int tableId = 34;
        int rowId = 29;
        HttpServletResponse response = new MockHttpServletResponse();
        when(this.tablesApplication.findRowDataFile(tableId, rowId)).thenReturn(new DataFile("filename", "example".getBytes()));

        // @When downloading a matching file
        this.tableController.downloadFile(9, tableId, rowId, response);

        // @Then the response parameters match a file download
        assertThat(response.getContentType()).isEqualTo("application/octet-stream");
        assertThat(response.containsHeader("Content-Disposition")).isTrue();
    }

    @Test
    public void testDeleteAllRowsCallsTablesApplicationDeleteAllRowsWithIdOne() {
        // @Given an existing table
        int tableId = 1;
        int campaignId = 1;

        // @When viewing the metadata
        this.tableController.deleteAllRows(campaignId, tableId);

        // @Then the table's columns are returned
        verify(this.tablesApplication, times(1)).deleteAllRows(tableId);
    }


    private InputStream readFile() {
        InputStream is = null;
        try {
            is = getClass().getResourceAsStream(EXCEL_FILE_NAME);
            assertNotNull("File cannot be null", is);
        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }

        return is;
    }
}
