package com.monsanto.metricspos.boundary.ui;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.metricspos.boundary.helpers.WebAppTestsHelper;
import com.monsanto.metricspos.core.TablesApplication;
import com.monsanto.metricspos.core.application.vo.DataProviderVO;
import com.monsanto.metricspos.core.externaldata.DataProvider;
import com.monsanto.metricspos.core.metrics.Campaign;
import com.monsanto.metricspos.persistence.DataRowPersistorFactory;
import com.monsanto.metricspos.persistence.ReflectiveDataRowPersistorFactory;
import com.monsanto.metricspos.persistence.RowValues;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.monsanto.utils.DateUtils.newDate;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 */
public class TableDefinitionController_UT {
    private TableDefinitionController tableDefinitionController;
    private TablesApplication tablesApplication;
    private WebAppTestsHelper webAppTestsHelper;

    @Before
    public void setUp() {

        this.tableDefinitionController = new TableDefinitionController();
        this.tablesApplication = mock(TablesApplication.class);

        Logger auditLog = mock(Logger.class);
        Logger actionLog = mock(Logger.class);
        field("auditLog").ofType(Logger.class).in(this.tableDefinitionController).set(auditLog);
        field("actionLog").ofType(Logger.class).in(this.tableDefinitionController).set(actionLog);

        field("application").ofType(TablesApplication.class).in(this.tableDefinitionController).set(this.tablesApplication);

        DataProvider dataProvider = new DataProvider();
        dataProvider.setCode("CRM");
        dataProvider.setName("Client Relationship Manager");

        DataRowPersistorFactory dataRowPersistorFactory = new ReflectiveDataRowPersistorFactory();

        Map<Class, String> classXprefix = Maps.newHashMap();
        classXprefix.put(String.class, RowValues.TEXT_COLUMN_PREFIX);
        classXprefix.put(Integer.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Long.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(BigDecimal.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Number.class, RowValues.NUMBER_COLUMN_PREFIX);
        classXprefix.put(Date.class, RowValues.DATE_COLUMN_PREFIX);

        field("classToPrefixMap").ofType(Map.class).in(dataRowPersistorFactory).set(classXprefix);

        Campaign campaign = new Campaign("campaignName", newDate(2011, 1, 1), newDate(2012, 1, 1));
        campaign.setId(1);

        webAppTestsHelper = new WebAppTestsHelper(dataProvider, campaign, dataRowPersistorFactory);

        HashMap<Object, Object> dataTypeMap = Maps.newHashMap();
        dataTypeMap.put("string", webAppTestsHelper.stringDataType());
    }


    @Test
    public void testListDataTypesReturnsListWithDataTypes_WhenOneDataTypeExists() {
        // @Given data types

        // @When listing the data types
        this.tableDefinitionController.listDataTypes();

        // the data types codes and names are returned
        verify(this.tablesApplication, times(1)).listDataTypes();
    }

    @Test
    public void testListDataProvidersReturnsThreeProviders_WhenThreeProvidersExist() {
        // @Given existing data providers
        when(this.tablesApplication.listProviders()).thenReturn(
                Lists.newArrayList(
                        webAppTestsHelper.newDataProvider("Code1", "Name 1"),
                        webAppTestsHelper.newDataProvider("Code2", "Name 2"),
                        webAppTestsHelper.newDataProvider("Code3", "Name 3")
                )
        );

        // @When listing the providers
        List<DataProviderVO> dataProviders = this.tableDefinitionController.listProviders();

        // @Then a list of VOs is returned
        assertThat(dataProviders).isNotNull();
        assertThat(dataProviders).isNotEmpty();
        assertThat(dataProviders).onProperty("code").containsExactly("Code1", "Code2", "Code3");
        assertThat(dataProviders).onProperty("name").containsExactly("Name 1", "Name 2", "Name 3");
    }
}
