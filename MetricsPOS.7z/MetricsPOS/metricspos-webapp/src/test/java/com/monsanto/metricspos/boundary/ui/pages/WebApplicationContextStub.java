package com.monsanto.metricspos.boundary.ui.pages;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.MessageSourceResolvable;
import org.springframework.context.NoSuchMessageException;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.web.context.WebApplicationContext;

import javax.servlet.ServletContext;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.util.Locale;
import java.util.Map;

/**
* TODO Move to proper package
*
* @author CAFAU
*/
class WebApplicationContextStub implements WebApplicationContext {

    public WebApplicationContextStub() {
    }

    @Override
    public ServletContext getServletContext() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String getId() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String getDisplayName() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public long getStartupDate() {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public ApplicationContext getParent() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public AutowireCapableBeanFactory getAutowireCapableBeanFactory() throws IllegalStateException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void publishEvent(ApplicationEvent event) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public BeanFactory getParentBeanFactory() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean containsLocalBean(String s) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean containsBeanDefinition(String s) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public int getBeanDefinitionCount() {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String[] getBeanDefinitionNames() {
        return new String[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String[] getBeanNamesForType(Class<?> aClass) {
        return new String[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String[] getBeanNamesForType(Class<?> aClass, boolean b, boolean b1) {
        return new String[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public <T> Map<String, T> getBeansOfType(Class<T> tClass) throws BeansException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public <T> Map<String, T> getBeansOfType(Class<T> tClass, boolean b, boolean b1) throws BeansException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Map<String, Object> getBeansWithAnnotation(Class<? extends Annotation> aClass) throws BeansException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public <A extends Annotation> A findAnnotationOnBean(String s, Class<A> aClass) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Object getBean(String s) throws BeansException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public <T> T getBean(String s, Class<T> tClass) throws BeansException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public <T> T getBean(Class<T> tClass) throws BeansException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Object getBean(String s, Object... objects) throws BeansException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean containsBean(String s) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isSingleton(String s) throws NoSuchBeanDefinitionException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isPrototype(String s) throws NoSuchBeanDefinitionException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public boolean isTypeMatch(String s, Class<?> aClass) throws NoSuchBeanDefinitionException {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Class<?> getType(String s) throws NoSuchBeanDefinitionException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String[] getAliases(String s) {
        return new String[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Environment getEnvironment() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String getMessage(String code, Object[] args, String defaultMessage, Locale locale) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public String getMessage(String code, Object[] args, Locale locale) throws NoSuchMessageException {
        return "$$" + code + "$$";
    }

    @Override
    public String getMessage(MessageSourceResolvable resolvable, Locale locale) throws NoSuchMessageException {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Resource[] getResources(String locationPattern) throws IOException {
        return new Resource[0];  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Resource getResource(String location) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public ClassLoader getClassLoader() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
