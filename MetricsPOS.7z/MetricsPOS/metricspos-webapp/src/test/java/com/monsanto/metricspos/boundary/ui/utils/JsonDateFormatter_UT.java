package com.monsanto.metricspos.boundary.ui.utils;

import org.junit.Test;

import java.text.ParsePosition;
import java.util.Calendar;
import java.util.Date;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class JsonDateFormatter_UT {

    @Test
    public void testParseReturnsADate_WhenInputIsInShortFormat(){
        // @Given a date in short format
        String shortFormat = "2013-01-05T11:30:48Z";

        // @When parsing the date
        Date date = new JsonDateFormatter().parse(shortFormat, new ParsePosition(0));

        // @Then a date is returned matching the short format date string
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        assertThat(calendar.get(Calendar.YEAR)).isEqualTo(2013);
        assertThat(calendar.get(Calendar.MONTH)).isEqualTo(0);
        assertThat(calendar.get(Calendar.DAY_OF_MONTH)).isEqualTo(5);
        assertThat(calendar.get(Calendar.HOUR_OF_DAY)).isEqualTo(11);
        assertThat(calendar.get(Calendar.MINUTE)).isEqualTo(30);
        assertThat(calendar.get(Calendar.SECOND)).isEqualTo(48);
    }

    @Test
    public void testParseReturnsADate_WhenInputIsInLongFormat(){
        // @Given a date in short format
        String longFormat = "2013-01-05T11:30:48.009Z";

        // @When parsing the date
        Date date = new JsonDateFormatter().parse(longFormat, new ParsePosition(0));

        // @Then a date is returned matching the short format date string
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        assertThat(calendar.get(Calendar.YEAR)).isEqualTo(2013);
        assertThat(calendar.get(Calendar.MONTH)).isEqualTo(0);
        assertThat(calendar.get(Calendar.DAY_OF_MONTH)).isEqualTo(5);
        assertThat(calendar.get(Calendar.HOUR_OF_DAY)).isEqualTo(11);
        assertThat(calendar.get(Calendar.MINUTE)).isEqualTo(30);
        assertThat(calendar.get(Calendar.SECOND)).isEqualTo(48);
        assertThat(calendar.get(Calendar.MILLISECOND)).isEqualTo(9);
    }
}
