package com.monsanto.metricspos.boundary.ui.utils;

import org.junit.Test;
import org.springframework.web.context.request.WebRequest;

import java.util.Map;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 */
public class SearchFilterUtils_UT {
    @Test
    public void testExtractFilterReturnsEmptyMap_WhenWebRequestIsNull(){
        WebRequest webRequest = null;
        Map<String,Object> map = ControllerUtils.extractFilter(webRequest);

        assertThat(map).isEmpty();
    }
}
