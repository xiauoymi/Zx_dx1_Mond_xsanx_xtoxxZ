package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BagConsumed;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface BagConsumedDao extends GenericDao<BagConsumed, Long> {

    Collection<BagConsumed> findByMaterialPackageConsumption(long mpcId) throws Exception;

}
