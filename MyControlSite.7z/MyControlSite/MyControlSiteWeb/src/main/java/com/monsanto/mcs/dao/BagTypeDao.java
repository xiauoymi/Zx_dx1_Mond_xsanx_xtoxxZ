package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BagType;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 12:06:46 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface BagTypeDao extends GenericDao<BagType, Long>{
    public BagType lookupByCriteria(BagType example) throws Exception;

    public Collection<BagType> findByType(String type) throws Exception;

}
