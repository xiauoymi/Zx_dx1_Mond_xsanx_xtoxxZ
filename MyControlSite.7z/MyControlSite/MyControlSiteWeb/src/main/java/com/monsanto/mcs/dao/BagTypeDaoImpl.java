package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BagType;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 12:08:28 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class BagTypeDaoImpl extends HibernateDao<BagType, Long> implements BagTypeDao {

    private static final Logger LOG = Logger.getLogger(BrandDaoImpl.class);

    public BagType lookupByCriteria(BagType example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("type", example.getType()));
        Collection<BagType> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No BagType found with name: " + example.getType());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<BagType> findByType(String type) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("type", "%" + type + "%"));

        Collection<BagType> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
