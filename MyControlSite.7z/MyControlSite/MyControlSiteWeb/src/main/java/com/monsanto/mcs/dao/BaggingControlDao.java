package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BaggingControl;
import com.monsanto.mcs.model.hibernate.BaggingLot;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface BaggingControlDao extends GenericDao<BaggingControl, Long> {
    
}
