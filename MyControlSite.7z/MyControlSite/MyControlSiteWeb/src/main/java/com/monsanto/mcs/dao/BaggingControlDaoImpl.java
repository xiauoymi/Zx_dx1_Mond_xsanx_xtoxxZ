package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BaggingControl;
import org.springframework.stereotype.Repository;

@Repository
public class BaggingControlDaoImpl extends HibernateDao<BaggingControl, Long> implements BaggingControlDao {

}

