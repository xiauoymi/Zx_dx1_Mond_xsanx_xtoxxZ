package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Bagging;
import com.monsanto.mcs.model.hibernate.Shift;
import org.springframework.transaction.annotation.Transactional;
import java.util.Date;
import java.util.Collection;

@Transactional
public interface BaggingDao extends GenericDao<Bagging, Long> {

    Collection<Bagging> findByDateShiftOrder(int plantId,Date date, Shift shift,long order);

    Collection<Bagging> findByOrderHybridLot(int plantId,Date date, Shift shift,long order,String hybridName,String baggingLot);

    Collection<Bagging> findByDateShiftOrder(int plantId,Date date, int shift,long order, int folio);

    Collection<Bagging> findByBaggingOrder(long baggingOrder);

    Collection<Bagging> findByFolio(int plantId,Date date, Shift shift,long folio);

    Collection<Bagging> findByDateShiftOrderSeason(int plantId,Date date, Shift shift,long order,int seasonId);

    Collection<Bagging> findByOrderHybridLotSeason(int plantId,Date date, Shift shift,long order,String hybridName,String baggingLot,int seasonId);

    Collection<Bagging> findByFolioSeason(int plantId,Date date, Shift shift,long folio,int seasonId);

    int findNextRecord(long orderNumber,Date baggingDate, Shift shift) throws Exception;
    
}
