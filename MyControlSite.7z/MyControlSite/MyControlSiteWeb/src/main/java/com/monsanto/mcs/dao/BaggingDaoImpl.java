package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Bagging;
import com.monsanto.mcs.model.hibernate.Hybrid;
import com.monsanto.mcs.model.hibernate.Shift;
import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.Date;

@Repository
public class BaggingDaoImpl extends HibernateDao<Bagging, Long> implements BaggingDao {

    public Collection<Bagging> findByDateShiftOrder(int plantId, Date date, Shift shift, long order) {
        Collection<Bagging> results = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("baggingLot", "baggingLot");
        criteria.add(Restrictions.eq("baggingLot.plant.id", (long) plantId));
        if (date != null) {
            criteria.add(Restrictions.eq("date", date));
        }
        if (shift != null) {
            criteria.createCriteria("shift", "shift");
            criteria.add(Restrictions.eq("shift.id", shift.getId()));
        }
        if (order != 0) {
            criteria.createCriteria("baggingOrder", "baggingOrder");
            criteria.add(Restrictions.eq("baggingOrder.orderNumber", order));
        }
        criteria.addOrder(Order.asc("record"));
        criteria.addOrder(Order.asc("date"));
        criteria.addOrder(Order.asc("folio"));
        results = criteria.list();
        if (results == null || results.size() == 0) {
            results = null;
        }
        return results;
    }

    public Collection<Bagging> findByOrderHybridLot(int plantId, Date date, Shift shift, long order, String hybridName, String baggingLot) {

        Collection<Bagging> results = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("baggingLot", "baggingLot");
        criteria.add(Restrictions.eq("baggingLot.plant.id", (long) plantId));
        if (date != null) {
            criteria.add(Restrictions.eq("date", date));
        }
        if (shift != null) {
            criteria.createCriteria("shift", "shift");
            criteria.add(Restrictions.eq("shift.id", shift.getId()));
        }
        if (order != 0) {
            criteria.createCriteria("baggingOrder", "baggingOrder");
            criteria.add(Restrictions.eq("baggingOrder.orderNumber", order));
        }

        if (null != hybridName && !"".equals(hybridName)) {
            DetachedCriteria hybrid = DetachedCriteria.forClass(Hybrid.class);
            hybrid.add(Restrictions.like("name", hybridName + "%"));
            hybrid.setProjection(Projections.property("id"));
            criteria.createCriteria("hybrid", "hybrid");
            criteria.add(Subqueries.propertyIn("hybrid.id", hybrid));
        }

        if (null != baggingLot && !"".equals(baggingLot)) {
            criteria.add(Restrictions.eq("baggingLot.description", baggingLot));
        }

        criteria.addOrder(Order.asc("record"));
        criteria.addOrder(Order.asc("date"));
        criteria.addOrder(Order.asc("folio"));
        results = criteria.list();
        if (results == null || results.size() == 0) {
            results = null;
        }
        return results;
    }

    public Collection<Bagging> findByFolio(int plantId, Date date, Shift shift, long folio) {
        Collection<Bagging> results = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("folio", (int) folio));
        criteria.addOrder(Order.asc("record"));
        criteria.addOrder(Order.asc("date"));
        criteria.addOrder(Order.asc("folio"));
        results = criteria.list();
        if (results == null || results.size() == 0) {
            results = null;
        }
        return results;
    }

    public Collection<Bagging> findByBaggingOrder(long baggingOrder) {
        Collection<Bagging> results = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("baggingOrder", "baggingOrder");
        criteria.add(Restrictions.eq("baggingOrder.orderNumber", baggingOrder));
        results = criteria.list();
        if (results == null || results.size() == 0) {
            results = null;
        }
        return results;
    }

    public Collection<Bagging> findByDateShiftOrder(int plantId, Date date, int shift, long order, int folio) {
        Collection<Bagging> results = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("date", date));
        if (folio != 0) {
            criteria.add(Restrictions.eq("folio", folio));
        }
        if (shift != 0) {
            criteria.createCriteria("shift", "shift")
                    .add(Restrictions.eq("shift.id", new Long(shift)));
        }
        criteria.createCriteria("baggingLot", "baggingLot")
                .add(Restrictions.eq("baggingLot.plant.id", new Long(plantId)));
        if (order != 0) {
            criteria.createCriteria("baggingOrder", "baggingOrder")
                    .add(Restrictions.eq("baggingOrder.orderNumber", order));
        }
        criteria.addOrder(Order.asc("record"));
        criteria.addOrder(Order.asc("date"));
        criteria.addOrder(Order.asc("folio"));
        results = criteria.list();
        if (results == null || results.size() == 0) {
            results = null;
        }
        return results;
    }

    public Collection<Bagging> findByDateShiftOrderSeason(int plantId, Date date, Shift shift, long order, int seasonId) {
        Collection<Bagging> results = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("baggingLot", "baggingLot");
        criteria.add(Restrictions.eq("baggingLot.plant.id", (long) plantId));
        if (seasonId != 0) {
            criteria.add(Restrictions.eq("baggingLot.season.id", (long) seasonId));
        }
        if (date != null) {
            criteria.add(Restrictions.eq("date", date));
        }
        if (shift != null) {
            criteria.createCriteria("shift", "shift");
            criteria.add(Restrictions.eq("shift.id", shift.getId()));
        }
        if (order != 0) {
            criteria.createCriteria("baggingOrder", "baggingOrder");
            criteria.add(Restrictions.eq("baggingOrder.orderNumber", order));
        }
        criteria.addOrder(Order.asc("record"));
        criteria.addOrder(Order.asc("date"));
        criteria.addOrder(Order.asc("folio"));
        results = criteria.list();
        if (results == null || results.size() == 0) {
            results = null;
        }
        return results;
    }

    public Collection<Bagging> findByOrderHybridLotSeason(int plantId, Date date, Shift shift, long order, String hybridName, String baggingLot, int seasonId) {

        Collection<Bagging> results = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("baggingLot", "baggingLot");
        criteria.add(Restrictions.eq("baggingLot.plant.id", (long) plantId));
        if (date != null) {
            criteria.add(Restrictions.eq("date", date));
        }
        if (shift != null) {
            criteria.createCriteria("shift", "shift");
            criteria.add(Restrictions.eq("shift.id", shift.getId()));
        }
        if (order != 0) {
            criteria.createCriteria("baggingOrder", "baggingOrder");
            criteria.add(Restrictions.eq("baggingOrder.orderNumber", order));
        }

        if (null != hybridName && !"".equals(hybridName)) {
            DetachedCriteria hybrid = DetachedCriteria.forClass(Hybrid.class);
            hybrid.add(Restrictions.like("name", hybridName + "%"));
            hybrid.setProjection(Projections.property("id"));
            criteria.createCriteria("hybrid", "hybrid");
            criteria.add(Subqueries.propertyIn("hybrid.id", hybrid));
        }

        if (null != baggingLot && !"".equals(baggingLot)) {
            criteria.add(Restrictions.eq("baggingLot.description", baggingLot));
        }

        if (seasonId != 0) {
            criteria.add(Restrictions.eq("baggingLot.season.id", (long) seasonId));
        }

        criteria.addOrder(Order.asc("record"));
        criteria.addOrder(Order.asc("date"));
        criteria.addOrder(Order.asc("folio"));
        results = criteria.list();
        if (results == null || results.size() == 0) {
            results = null;
        }
        return results;
    }

    public Collection<Bagging> findByFolioSeason(int plantId, Date date, Shift shift, long folio, int seasonId) {
        Collection<Bagging> results = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("folio", (int) folio));
        if (seasonId != 0 && plantId != 0) {
            criteria.createCriteria("baggingLot", "baggingLot");
            criteria.add(Restrictions.eq("baggingLot.season.id", (long) seasonId));
            criteria.add(Restrictions.eq("baggingLot.plant.id", (long) plantId));
        }
        criteria.addOrder(Order.asc("record"));
        criteria.addOrder(Order.asc("date"));
        criteria.addOrder(Order.asc("folio"));
        results = criteria.list();
        if (results == null || results.size() == 0) {
            results = null;
        }
        return results;
    }

    public int findNextRecord(long orderNumber, Date baggingDate, Shift shift) throws Exception {
        int record = 0;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("shift.id", shift.getId()));
        criteria.add(Restrictions.eq("date", baggingDate));
        criteria.createCriteria("baggingOrder", "baggingOrder")
                .add(Restrictions.eq("baggingOrder.orderNumber", orderNumber));
        criteria.setProjection(Projections.projectionList().add(Projections.max("record")));
        Collection<Integer> results = criteria.list();
        if (results == null || results.size() == 0) {
            record = 1;
        } else {
            if (results.iterator().hasNext()) {
                Integer temp = results.iterator().next();
                if (temp != null) {
                    record = temp + 1;
                }
            }
        }
        return record;
    }

}
