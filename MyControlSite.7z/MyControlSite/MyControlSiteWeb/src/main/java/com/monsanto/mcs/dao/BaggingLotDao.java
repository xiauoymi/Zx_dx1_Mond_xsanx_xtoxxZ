package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BaggingLot;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface BaggingLotDao extends GenericDao<BaggingLot, Long> {
    
}
