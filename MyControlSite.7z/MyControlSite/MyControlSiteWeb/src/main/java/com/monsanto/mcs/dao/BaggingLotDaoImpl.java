package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BaggingLot;
import org.springframework.stereotype.Repository;

@Repository
public class BaggingLotDaoImpl extends HibernateDao<BaggingLot, Long> implements BaggingLotDao {

}

