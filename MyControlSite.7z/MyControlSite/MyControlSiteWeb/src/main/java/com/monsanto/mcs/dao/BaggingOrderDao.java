package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BaggingOrder;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface BaggingOrderDao extends GenericDao<BaggingOrder, Long> {

    Collection<BaggingOrder> findBaggingOrdersByLot(String baggingLot) throws Exception;

    Collection<BaggingOrder> findBaggingOrdersByOrder(long orderNumber) throws Exception;

    Collection<BaggingOrder> findByOrderBaggingMixtureMaterial(long orderNumber,String baggingLot,String mixtureLot,long materialNumber) throws Exception;

}
