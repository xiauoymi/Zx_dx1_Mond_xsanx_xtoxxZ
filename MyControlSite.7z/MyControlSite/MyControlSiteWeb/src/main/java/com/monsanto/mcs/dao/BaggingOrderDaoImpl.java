package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BaggingOrder;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class BaggingOrderDaoImpl extends HibernateDao<BaggingOrder, Long> implements BaggingOrderDao {

    public Collection<BaggingOrder> findBaggingOrdersByLot(String baggingLot) throws Exception {
        try {
            Criteria criteria = createCriteria();
            criteria.add(Restrictions.eq("baggingLot", baggingLot));
            Collection<BaggingOrder> baggingOrders = criteria.list();
            if (baggingOrders == null || baggingOrders.isEmpty()) {
                return null;
            }
            return baggingOrders;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Collection<BaggingOrder> findBaggingOrdersByOrder(long orderNumber) throws Exception {
        try {
            Criteria criteria = createCriteria();
            criteria.add(Restrictions.eq("orderNumber", orderNumber));
            Collection<BaggingOrder> baggingOrders = criteria.list();
            if (baggingOrders == null || baggingOrders.isEmpty()) {
                return null;
            }
            return baggingOrders;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public Collection<BaggingOrder> findByOrderBaggingMixtureMaterial(long orderNumber, String baggingLot, String mixtureLot, long materialNumber) throws Exception {
        try {
            Criteria criteria = createCriteria();
            if (orderNumber != 0) {
                criteria.add(Restrictions.eq("orderNumber", orderNumber));
            }
            if (baggingLot != null && !baggingLot.equals("")) {
                criteria.add(Restrictions.eq("baggingLot", baggingLot));
            }
            if (mixtureLot != null && !mixtureLot.equals("")) {
                criteria.add(Restrictions.eq("mixtureLot", mixtureLot));
            }
            if (materialNumber != 0) {
                criteria.add(Restrictions.eq("materialNumber", materialNumber));
            }
            Collection<BaggingOrder> baggingOrders = criteria.list();
            if (baggingOrders == null || baggingOrders.isEmpty()) {
                return null;
            }
            return baggingOrders;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
