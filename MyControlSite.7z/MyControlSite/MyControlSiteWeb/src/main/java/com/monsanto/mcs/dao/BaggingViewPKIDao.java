package com.monsanto.mcs.dao;
import com.monsanto.mcs.model.hibernate.BaggingViewPKI;
import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import com.monsanto.mcs.model.hibernate.GreenCornReceivePKI;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface BaggingViewPKIDao extends GenericDao <BaggingViewPKI, Long>{
    public Collection<BaggingViewPKI> findByPlantSeason(int idPlant, int idSeason) throws Exception;

}


