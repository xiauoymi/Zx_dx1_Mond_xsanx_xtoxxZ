package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BaggingViewPKI;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

@Repository
public class BaggingViewPKIDaoImpl extends HibernateDao<BaggingViewPKI, Long> implements BaggingViewPKIDao {

    public Collection<BaggingViewPKI> findByPlantSeason(int idPlant, int idSeason) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant", idPlant));
        criteria.add(Restrictions.eq("season", idSeason));
        List<BaggingViewPKI> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No BaggingView records were found with plant: " + idPlant + " and Season " + idSeason);
        }
        return matchingEntry;
    }
}
