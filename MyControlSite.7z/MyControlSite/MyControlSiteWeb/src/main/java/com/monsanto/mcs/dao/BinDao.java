package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Bin;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 06:45:05 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface BinDao  extends GenericDao<Bin, Long>{

    public Collection<Bin> findByPlant(int plant) throws Exception;


}
