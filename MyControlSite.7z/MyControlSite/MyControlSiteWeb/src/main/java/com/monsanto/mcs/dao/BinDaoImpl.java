package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Bin;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 06:46:40 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class BinDaoImpl extends HibernateDao<Bin, Long> implements BinDao {

    private static final Logger LOG = Logger.getLogger(BinDaoImpl.class);

    public Collection<Bin> findByPlant(int plant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant.id", new Long(plant)));

        Collection<Bin> matchingEntry = criteria.list();
        return matchingEntry;
    }


}
