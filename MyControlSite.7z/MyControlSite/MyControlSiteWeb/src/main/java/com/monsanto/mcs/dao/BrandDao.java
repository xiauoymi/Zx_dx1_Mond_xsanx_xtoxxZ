package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Brand;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface BrandDao extends GenericDao<Brand, Long> {
    public Brand lookupByCriteria(Brand example) throws Exception;

    public Collection<Brand> findByName(String name) throws Exception;
}
