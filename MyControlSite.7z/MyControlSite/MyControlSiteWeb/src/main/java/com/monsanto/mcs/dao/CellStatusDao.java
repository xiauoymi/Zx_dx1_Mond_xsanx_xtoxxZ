package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.CellStatus;
import com.monsanto.mcs.model.hibernate.DryingCellReport;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface CellStatusDao extends GenericDao<CellStatus, Long> {

    public Collection<CellStatus> findLastByPlant(long plantId) throws Exception;

}
