package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.CellStatus;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class CellStatusDaoImpl extends HibernateDao<CellStatus, Long> implements CellStatusDao {

    public Collection<CellStatus> findLastByPlant(long plantId) throws Exception {
        Collection<CellStatus> results = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant", plantId));
        criteria.addOrder(Order.desc("cellStatusDate"));
        criteria.addOrder(Order.asc("cellName"));
        //criteria.setProjection(Projections.projectionList()
        //        .add(Projections.max("cellStatusDate")));
        results = criteria.list();
        return results;
    }

}
