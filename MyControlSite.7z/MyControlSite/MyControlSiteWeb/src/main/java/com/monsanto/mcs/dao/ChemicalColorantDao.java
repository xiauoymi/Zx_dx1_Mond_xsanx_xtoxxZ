package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ChemicalColorant;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 05:41:27 PM
 * To change this template use File | Settings | File Templates.
 */

@Transactional
public interface ChemicalColorantDao extends GenericDao<ChemicalColorant, Long> {

    public ChemicalColorant lookupByCriteria(ChemicalColorant example) throws Exception;
    public Collection<ChemicalColorant> findByColorant(String colorant) throws Exception;
    public Collection<ChemicalColorant> findByCode(String code) throws Exception;


}
