package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ChemicalColorant;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 05:44:02 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ChemicalColorantDaoImpl extends HibernateDao<ChemicalColorant, Long> implements ChemicalColorantDao {

    private static final Logger LOG = Logger.getLogger(ChemicalColorantDaoImpl.class);

    public ChemicalColorant lookupByCriteria(ChemicalColorant example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getColorant()));
        Collection<ChemicalColorant> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Brand found with name: " + example.getColorant());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<ChemicalColorant> findByColorant(String colorant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("colorant", "%" + colorant + "%"));

        Collection<ChemicalColorant> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<ChemicalColorant> findByCode(String code) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("code", "%" + code + "%"));

        Collection<ChemicalColorant> matchingEntry = criteria.list();
        return matchingEntry;
    }


}
