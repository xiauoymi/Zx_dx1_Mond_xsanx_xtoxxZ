package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ChemicalConsumption;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Date;

@Transactional
public interface ChemicalConsumptionDao extends GenericDao<ChemicalConsumption, Long> {

    Collection<ChemicalConsumption> findAllByPlantSeason(long plantSeason, String orderNumber) throws Exception;

    Collection<ChemicalConsumption> findAllByPlantSeason(long plantSeason, String orderNumber, int shift) throws Exception;

    ChemicalConsumption findByDateShiftOrder(long plantSeason, Date date, int shift, String orderNumber) throws Exception;

    ChemicalConsumption findByOrderNumber(String orderNumber) throws Exception;

}
