package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ChemicalConsumption;
import com.monsanto.mcs.util.DateTime;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.Date;

@Repository
public class ChemicalConsumptionDaoImpl extends HibernateDao<ChemicalConsumption, Long> implements ChemicalConsumptionDao {

    public Collection<ChemicalConsumption> findAllByPlantSeason(long plantSeason, String orderNumber) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeason.id", plantSeason));
        if (orderNumber != null && !orderNumber.equals("")) {
            criteria.add(Restrictions.eq("orderNumber", orderNumber));
        }
        return criteria.list();
    }

    public Collection<ChemicalConsumption> findAllByPlantSeason(long plantSeason, String orderNumber, int shift) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeason.id", plantSeason));
        criteria.add(Restrictions.eq("shift.id", new Long(shift)));
        if (orderNumber != null && !orderNumber.equals("")) {
            criteria.add(Restrictions.eq("orderNumber", orderNumber));
        }
        return criteria.list();
    }

    private String dateStringRepresentation(Date date) {
        DateTime dateTimeHelper = new DateTime();
        dateTimeHelper.setDate(date);
        return dateTimeHelper.getDate();
    }

    public ChemicalConsumption findByDateShiftOrder(long plantSeason, Date date, int shift, String orderNumber) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeason.id", plantSeason));
        criteria.add(Restrictions.eq("shift.id", new Long(shift)));
        if (orderNumber != null && !orderNumber.equals("")) {
            criteria.add(Restrictions.eq("orderNumber", orderNumber));
        }
        criteria.add(Restrictions.eq("baggingDate", dateStringRepresentation(date)));
        Collection<ChemicalConsumption> matchingEntry = criteria.list();
        if (null == matchingEntry || matchingEntry.isEmpty()) {
            return null;
        }
        return matchingEntry.iterator().next();
    }

    public ChemicalConsumption findByOrderNumber(String orderNumber) throws Exception {
        ChemicalConsumption matchingEntry = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("orderNumber", orderNumber));
        Collection<ChemicalConsumption> results = criteria.list();
        if (results != null && results.size() > 0) {
            matchingEntry = results.iterator().next();
        }
        return matchingEntry;
    }

}
