package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ChemicalDensityDose;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 11:44:00 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ChemicalDensityDoseDao extends GenericDao<ChemicalDensityDose, Long> {

    public Collection<ChemicalDensityDose> findByChemicalId(int id) throws Exception;
}

