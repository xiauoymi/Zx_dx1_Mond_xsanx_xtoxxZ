package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ChemicalDensityDose;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 11:44:46 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ChemicalDensityDoseDaoImpl extends HibernateDao<ChemicalDensityDose, Long> implements ChemicalDensityDoseDao {

    private static final Logger LOG = Logger.getLogger(ChemicalDensityDoseDaoImpl.class);

    public Collection<ChemicalDensityDose> findByChemicalId(int id) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("chemicals", "chemicals")
                .add(Restrictions.like("chemicals.id", new Long(id)));

        Collection<ChemicalDensityDose> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
