package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ChemicalRevision;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 27/07/2011
 * Time: 03:10:53 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ChemicalRevisionDao extends GenericDao<ChemicalRevision, Long> {

    public ChemicalRevision findByOrderNumber(long plant, long season, long orderNumber) throws Exception;     
    public Collection<ChemicalRevision> findAllByPlantSeason(long plantSeasonId, long order) throws Exception;
}
