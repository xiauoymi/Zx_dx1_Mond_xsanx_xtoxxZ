package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ChemicalRevision;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class ChemicalRevisionDaoImpl extends HibernateDao<ChemicalRevision, Long> implements ChemicalRevisionDao {

    private static final Logger LOG = Logger.getLogger(ChemicalDensityDoseDaoImpl.class);

    public ChemicalRevision findByOrderNumber(long plant, long season, long orderNumber) throws Exception {
        ChemicalRevision feedback = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("bagging", "bagging")
                .createCriteria("baggingOrder", "baggingOrder")
                .add(Restrictions.eq("baggingOrder.orderNumber", orderNumber))
                .createCriteria("bagging.baggingLot", "baggingLot")
                .add(Restrictions.eq("baggingLot.plant.id", plant))
                .add(Restrictions.eq("baggingLot.season.id", season));

        Collection<ChemicalRevision> matchingEntry = criteria.list();
        if (matchingEntry != null && matchingEntry.size() > 0) {
            feedback = matchingEntry.iterator().next();
        }
        return feedback;
    }


    public Collection<ChemicalRevision> findAllByPlantSeason(long plantSeasonId, long orderNumber) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("plantSeason.id", plantSeasonId));
        if (orderNumber != 0) {
            criteria.createCriteria("bagging", "bagging")
                    .createCriteria("baggingOrder", "baggingOrder")
                    .add(Restrictions.eq("baggingOrder.orderNumber", orderNumber));
        }
        Collection<ChemicalRevision> matchingEntry = null;
        try {
            matchingEntry = criteria.list();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return matchingEntry;
    }

}
