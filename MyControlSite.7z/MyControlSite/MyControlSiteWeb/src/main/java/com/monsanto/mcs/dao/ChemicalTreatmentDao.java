package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ChemicalTreatment;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 12:25:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ChemicalTreatmentDao extends GenericDao<ChemicalTreatment, Long> {

    public Collection<ChemicalTreatment> findByTreatment(String name) throws Exception;

    public ChemicalTreatment findByTreatmentId(long treatmentId) throws Exception;

}
