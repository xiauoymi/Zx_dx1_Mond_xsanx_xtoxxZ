package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ChemicalTreatment;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 12:26:55 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ChemicalTreatmentDaoImpl extends HibernateDao<ChemicalTreatment, Long> implements ChemicalTreatmentDao {

    private static final Logger LOG = Logger.getLogger(ChemicalTreatmentDaoImpl.class);

    public Collection<ChemicalTreatment> findByTreatment(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("treatment", "treatment")
                .add(Restrictions.like("treatment.name", "%" + name + "%"));

        criteria.addOrder(Order.asc("id"));
        Collection<ChemicalTreatment> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public ChemicalTreatment findByTreatmentId(long treatmentId) throws Exception {
        ChemicalTreatment feedback = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("treatment", "treatment")
                .add(Restrictions.like("treatment.id", treatmentId));

        criteria.addOrder(Order.asc("id"));
        Collection<ChemicalTreatment> matchingEntry = criteria.list();
        if (matchingEntry != null && matchingEntry.size() > 0) {
            feedback = matchingEntry.iterator().next();
        }
        return feedback;
    }


}
