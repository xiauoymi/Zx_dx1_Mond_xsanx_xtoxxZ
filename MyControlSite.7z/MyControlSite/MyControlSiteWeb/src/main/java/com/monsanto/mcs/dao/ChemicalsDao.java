package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Chemicals;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 05:14:25 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ChemicalsDao extends GenericDao<Chemicals, Long>{

    public Chemicals lookupByCriteria(Chemicals example) throws Exception;
    public Collection<Chemicals> findByChemicalName(String chemicalName) throws Exception;
    public Collection<Chemicals> findByCode(String code) throws Exception;


}
