package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Chemicals;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 05:16:54 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ChemicalsDaoImpl extends HibernateDao<Chemicals, Long> implements ChemicalsDao {

    private static final Logger LOG = Logger.getLogger(ChemicalsDaoImpl.class);

    public Chemicals lookupByCriteria(Chemicals example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("chemical", example.getChemical()));
        Collection<Chemicals> matchingEntry = criteria.list();
        return matchingEntry.iterator().next();
    }

    public Collection<Chemicals> findByChemicalName(String chemical) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("chemical", "%" + chemical + "%"));
        criteria.addOrder(Order.asc("id"));
        Collection<Chemicals> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<Chemicals> findByCode(String code) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("code", "%" + code + "%"));
        criteria.addOrder(Order.asc("code"));
        Collection<Chemicals> matchingEntry = criteria.list();
        return matchingEntry;
    }


}
