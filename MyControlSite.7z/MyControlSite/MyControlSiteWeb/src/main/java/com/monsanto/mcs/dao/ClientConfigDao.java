package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ClientConfig;
import com.monsanto.mcs.model.hibernate.Server;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface ClientConfigDao extends GenericDao<ClientConfig, Long> {

    ClientConfig findByPlant(long plantId) throws Exception;

}
