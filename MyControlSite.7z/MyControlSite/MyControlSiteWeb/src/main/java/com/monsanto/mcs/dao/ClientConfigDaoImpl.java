package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ClientConfig;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class ClientConfigDaoImpl extends HibernateDao<ClientConfig, Long> implements ClientConfigDao {

    public ClientConfig findByPlant(long plantId) throws Exception {
        Collection<ClientConfig> results = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant.id", plantId));
        criteria.addOrder(Order.desc("id"));
        results = criteria.list();
        if (results.isEmpty()) {
            return null;
        }
        return results.iterator().next();
    }
}

