package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ClosingCellLog;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 28/04/2011
 * Time: 09:30:02 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ClosingCellLogDao extends GenericDao<ClosingCellLog, Long>{

    public Collection<ClosingCellLog> findAllById(long plantSeasonId) throws Exception;

    public Collection<ClosingCellLog> maxId(long plantSeasonId,int cell) throws Exception;

}
