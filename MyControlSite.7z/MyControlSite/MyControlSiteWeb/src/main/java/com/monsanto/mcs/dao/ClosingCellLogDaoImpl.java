package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ClosingCellLog;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 28/04/2011
 * Time: 09:30:16 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ClosingCellLogDaoImpl extends HibernateDao<ClosingCellLog, Long> implements ClosingCellLogDao {

    public Collection<ClosingCellLog> findAllById(long plantSeasonId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeasonId", new Long(plantSeasonId)));
        criteria.addOrder(Order.asc("id"));
        Collection<ClosingCellLog> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<ClosingCellLog> maxId(long plantSeasonId, int cell) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeasonId", new Long(plantSeasonId)));
        criteria.add(Restrictions.eq("cell", cell));
        criteria.setProjection(Projections.projectionList()
                .add(Projections.max("id"))
        );
        criteria.addOrder(Order.asc("id"));
        Collection<ClosingCellLog> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
