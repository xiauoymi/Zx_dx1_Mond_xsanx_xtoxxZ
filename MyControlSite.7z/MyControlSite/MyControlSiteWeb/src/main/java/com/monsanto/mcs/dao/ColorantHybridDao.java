package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ColorantHybrid;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 10:46:31 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ColorantHybridDao  extends GenericDao<ColorantHybrid, Long>{

    public Collection<ColorantHybrid> findByPlantSeason(int idPlantSeason) throws Exception;

    public Collection<ColorantHybrid> findByPlantSeason(int idPlantSeason, String hybrid) throws Exception;

}
