package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ColorantHybrid;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 10:48:42 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ColorantHybridDaoImpl extends HibernateDao<ColorantHybrid, Long> implements ColorantHybridDao {

    private static final Logger LOG = Logger.getLogger(ColorantHybridDaoImpl.class);

    public Collection<ColorantHybrid> findByPlantSeason(int idPlantSeason) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("hybrid", "hybrid")
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("plantSeason.id", new Long(idPlantSeason)));

        criteria.addOrder(Order.asc("id"));
        Collection<ColorantHybrid> matchingEntry = criteria.list();
        return matchingEntry;
    }


    public Collection<ColorantHybrid> findByPlantSeason(int idPlantSeason, String hybrid) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("hybrid", "hybrid")
                .add(Restrictions.like("hybrid.name", "%" + hybrid + "%"))
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("plantSeason.id", new Long(idPlantSeason)));
        criteria.addOrder(Order.asc("id"));
        Collection<ColorantHybrid> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
