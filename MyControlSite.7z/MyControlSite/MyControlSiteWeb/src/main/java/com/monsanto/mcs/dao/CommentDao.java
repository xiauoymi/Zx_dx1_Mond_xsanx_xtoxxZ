package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Comment;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:43:57 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface CommentDao extends GenericDao<Comment, Long> {
    public Comment lookupByCriteria(int idPlant, Comment example) throws Exception;
    public Collection<Comment> findByCommentOrderedById(int idPlant, String name) throws Exception;

}
