package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Comment;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:46:07 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class CommentDaoImpl extends HibernateDao<Comment, Long> implements CommentDao {

    private static final Logger LOG = Logger.getLogger(CommentDaoImpl.class);

    public Comment lookupByCriteria(int idPlant, Comment example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.eq("commentValue", example.getCommentValue()));
        Collection<Comment> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Comment found with value: " + example.getCommentValue());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Comment> findByCommentOrderedById(int idPlant, String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("commentValue", "%" + name + "%"));
        criteria.addOrder(Order.asc("id"));
        Collection<Comment> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Comment found with value: " + name);
        }
        return matchingEntry;
    }


}
