package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Condition;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:23:41 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ConditionDao extends GenericDao<Condition, Long>  {
    
    public Condition lookupByCriteria(Condition example);

    public Collection<Condition> findByName(String name, int idPlant);

    public Collection<Condition> findByQuarantinedFieldStage(int fieldStageId);
}
