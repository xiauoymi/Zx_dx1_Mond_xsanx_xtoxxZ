package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Condition;
import com.monsanto.mcs.model.hibernate.QuarantineLot;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:24:45 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ConditionDaoImpl extends HibernateDao<Condition, Long> implements ConditionDao {

    private static final Logger LOG = Logger.getLogger(ConditionDaoImpl.class);

    public Condition lookupByCriteria(Condition example) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getName()));
        Collection<Condition> matchingEntry = criteria.list();
        return matchingEntry.iterator().next();
    }

    public Collection<Condition> findByName(String name, int idPlant) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        Collection<Condition> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<Condition> findByQuarantinedFieldStage(int fieldStageId) {
        DetachedCriteria conditionsForQuarantinedFS = DetachedCriteria.forClass(QuarantineLot.class);
        conditionsForQuarantinedFS.createCriteria("fieldStage", "fieldStage")
                .add(Restrictions.eq("fieldStage.id", new Long(fieldStageId)));
        conditionsForQuarantinedFS.setProjection(Projections.property("condition.id"));

        Criteria criteria = createCriteria();
        criteria.add(Subqueries.propertyIn("id", conditionsForQuarantinedFS));
        Collection<Condition> matchingEntry = criteria.list();
        return matchingEntry;
    }

}