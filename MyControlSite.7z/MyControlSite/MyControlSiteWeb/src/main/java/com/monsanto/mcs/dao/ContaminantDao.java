package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Contaminant;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:33:59 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ContaminantDao extends GenericDao<Contaminant, Long>  {

    public Contaminant lookupByCriteria(Contaminant example);

    public Collection<Contaminant> findByType(String type, int plantId);
}
