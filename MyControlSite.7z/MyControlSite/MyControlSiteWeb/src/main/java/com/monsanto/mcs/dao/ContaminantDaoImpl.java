package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Contaminant;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:34:34 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ContaminantDaoImpl extends HibernateDao<Contaminant, Long> implements ContaminantDao {

    private static final Logger LOG = Logger.getLogger(ContaminantDaoImpl.class);

    public Contaminant lookupByCriteria(Contaminant example) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("type", example.getType()));
        Collection<Contaminant> matchingEntry = criteria.list();
        return matchingEntry.iterator().next();
    }

    public Collection<Contaminant> findByType(String type, int plantId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("plantId", new Long(plantId)));
        criteria.add(Restrictions.like("type", "%" + type + "%"));
        Collection<Contaminant> matchingEntry = criteria.list();
        return matchingEntry;
    }
}
