package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ContaminationType;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:39:57 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ContaminationTypeDao extends GenericDao<ContaminationType, Long>  {

    public ContaminationType lookupByCriteria(ContaminationType example);

    public Collection<ContaminationType> findByType(String type, int plantId);
}