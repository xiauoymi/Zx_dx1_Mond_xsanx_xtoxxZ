package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ContaminationType;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:41:35 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ContaminationTypeDaoImpl extends HibernateDao<ContaminationType, Long> implements ContaminationTypeDao {

    private static final Logger LOG = Logger.getLogger(ContaminationTypeDaoImpl.class);

    public ContaminationType lookupByCriteria(ContaminationType contamination) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("type", contamination.getType()));
        Collection<ContaminationType> matchingEntry = criteria.list();
        return matchingEntry.iterator().next();
    }

    public Collection<ContaminationType> findByType(String type, int plantId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantId", new Long(plantId)));
        criteria.add(Restrictions.like("type", "%" + type + "%"));
        Collection<ContaminationType> matchingEntry = criteria.list();
        return matchingEntry;
    }
}
