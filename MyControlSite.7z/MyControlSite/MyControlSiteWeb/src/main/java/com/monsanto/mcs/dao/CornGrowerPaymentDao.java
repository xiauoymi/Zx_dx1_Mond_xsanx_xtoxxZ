package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.CornGrowerPayment;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface CornGrowerPaymentDao extends GenericDao<CornGrowerPayment, Long>{
    
    public CornGrowerPayment lookupByCriteria(CornGrowerPayment example) throws Exception;

    public Collection<CornGrowerPayment> findAllByLot(int plantSeasonid, Long lot) throws Exception;

    public Collection<CornGrowerPayment> findAllByLot(int plantTo, int seasonId, Long lot) throws Exception;

    public CornGrowerPayment findByFolio(int plantTo, int seasonId, String folio) throws Exception;

}
