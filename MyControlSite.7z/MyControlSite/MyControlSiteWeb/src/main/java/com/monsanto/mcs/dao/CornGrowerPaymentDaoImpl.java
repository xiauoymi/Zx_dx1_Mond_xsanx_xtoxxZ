package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.CornGrowerPayment;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;


@Repository
public class CornGrowerPaymentDaoImpl extends HibernateDao<CornGrowerPayment, Long> implements CornGrowerPaymentDao {

    private static final Logger LOG = Logger.getLogger(CornGrowerPaymentDaoImpl.class);

    public CornGrowerPayment lookupByCriteria(CornGrowerPayment example) throws Exception {
        Criteria criteria = createCriteria();
        Collection<CornGrowerPayment> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No QualityGrowerPayment found");
        }
        return matchingEntry.iterator().next();
    }

    public Collection<CornGrowerPayment> findAllByLot(int plantSeasonId, Long lot) throws Exception {
        Criteria criteria = createCriteria();

        criteria.createCriteria("scale", "scale")
                .createCriteria("sendFormat", "sendFormat")
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .add(Restrictions.eq("lot", lot))
                .add(Restrictions.eq("plantSeasonId", new Long(plantSeasonId)));
        criteria.addOrder(Order.desc("id"));
        Collection<CornGrowerPayment> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<CornGrowerPayment> findAllByLot(int plantTo, int seasonId, Long lot) throws Exception {
        Criteria criteria = createCriteria();

        if (lot != 0L) {
            criteria.createCriteria("scale", "scale")
                    .createCriteria("sendFormat", "sendFormat")
                    .add(Restrictions.eq("plantTo.id", new Long(plantTo)))
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .add(Restrictions.eq("lot", lot))
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("season.id", new Long(seasonId)));
        } else {
            criteria.createCriteria("scale", "scale")
                    .createCriteria("sendFormat", "sendFormat")
                    .add(Restrictions.eq("plantTo.id", new Long(plantTo)))
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("season.id", new Long(seasonId)));
        }
        criteria.addOrder(Order.desc("id"));
        Collection<CornGrowerPayment> matchingEntry = criteria.list();
        return matchingEntry;
    }


    public CornGrowerPayment findByFolio(int plantTo, int seasonId, String folio) throws Exception {
        CornGrowerPayment feedback = null;
        Criteria criteria = createCriteria();

        criteria.createCriteria("scale", "scale")
                .createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("sendFormat.plantTo.id", new Long(plantTo)))
                .add(Restrictions.eq("sendFormatFolio", folio))
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("plantSeason.season.id", new Long(seasonId)));
        criteria.addOrder(Order.desc("id"));
        Collection<CornGrowerPayment> matchingEntry = criteria.list();
        if (matchingEntry != null && matchingEntry.size() > 0) {
            feedback = matchingEntry.iterator().next();
        }
        return feedback;

    }

}
