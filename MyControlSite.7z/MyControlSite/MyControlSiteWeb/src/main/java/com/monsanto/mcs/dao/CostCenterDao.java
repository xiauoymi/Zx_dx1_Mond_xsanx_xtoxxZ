package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.*;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 31/03/2011
 * Time: 02:52:33 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface CostCenterDao extends GenericDao<CostCenter, Long> {

    public CostCenter lookupByCriteria(int idPlant, CostCenter example) throws Exception;

    public Collection<CostCenter> findAllOrderedById(int idPlant, String name) throws Exception;

    CostCenter findByRentAndZone(Rent rent, Zone zone, Plant plantId);

    CostCenter findByLocationAndRent(Location location, Rent rent);

}
