package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.*;
import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 31/03/2011
 * Time: 02:52:43 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class CostCenterDaoImpl extends HibernateDao<CostCenter, Long> implements CostCenterDao {

    public CostCenter lookupByCriteria(int idPlant, CostCenter example) throws Exception {
        Criteria criteria = createCriteria();
        Collection<CostCenter> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No CostCenter found with value ");
        }
        return matchingEntry.iterator().next();
    }

    public Collection<CostCenter> findAllOrderedById(int idPlant, String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        if (name != null && name.trim().length() > 0) {
            criteria.createCriteria("zone", "zone")
                    .add(Restrictions.like("zone.zoneName", "%" + name + "%"));
        }
        criteria.addOrder(Order.asc("id"));
        Collection<CostCenter> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No CostCenter found with value: " + name);
        }
        return matchingEntry;
    }

    public CostCenter findByRentAndZone(Rent rent, Zone zone, Plant plant) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", plant.getId()));
        criteria.createCriteria("zone", "zone")
                .add(Restrictions.eq("zone.id", zone.getId()));
        criteria.createCriteria("rent", "rent")
                .add(Restrictions.eq("rent.id", rent.getId()));
        criteria.addOrder(Order.asc("id"));
        Collection<CostCenter> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            return null;
        }
        return matchingEntry.iterator().next();
    }

    public CostCenter findByLocationAndRent(Location location, Rent rent) {
        DetachedCriteria zone = DetachedCriteria.forClass(LocationZone.class);
        zone.add(Restrictions.eq("idPlant", location.getIdPlant()));
        zone.add(Restrictions.eq("location.id", location.getId()));
        zone.setProjection(Projections.property("zone.id"));
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", location.getIdPlant()));
        criteria.add(Subqueries.propertyIn("zone.id", zone));
        criteria.add(Restrictions.eq("rent.id", rent.getId()));
        Collection<CostCenter> results = criteria.list();
        if (null == results || results.isEmpty()) {
            return null;
        }
        return results.iterator().next();
    }

}
