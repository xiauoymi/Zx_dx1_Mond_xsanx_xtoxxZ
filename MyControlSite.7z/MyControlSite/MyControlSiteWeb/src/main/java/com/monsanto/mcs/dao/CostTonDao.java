package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.CostTon;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 30/03/2011
 * Time: 10:57:29 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface CostTonDao extends GenericDao<CostTon, Long> {

    CostTon lookupByCriteria(int plantSeasonId, CostTon example) throws Exception;

    Collection<CostTon> findBySupplierOrderedById(int plantSeasonId, String name) throws Exception;

    CostTon findCostTonForSendFormat(long plantSeasonId, long transportTypeId, long transportSupplierId, long zoneId, long plantTo) throws Exception;

}
