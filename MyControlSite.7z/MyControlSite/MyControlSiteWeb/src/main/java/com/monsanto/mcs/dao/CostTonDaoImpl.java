package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.CostTon;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 30/03/2011
 * Time: 10:57:43 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class CostTonDaoImpl extends HibernateDao<CostTon, Long> implements CostTonDao {

    private static final Logger LOG = Logger.getLogger(CostTonDaoImpl.class);

    public CostTon lookupByCriteria(int idPlant, CostTon example) throws Exception {
        Criteria criteria = createCriteria();
        //criteria.add(Restrictions.eq("commentValue", ));
        Collection<CostTon> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No CostTon found with value ");
        }
        return matchingEntry.iterator().next();
    }

    public Collection<CostTon> findBySupplierOrderedById(int plantSeasonId, String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeasonId", new Long(plantSeasonId)));

        criteria.createCriteria("transportSupplier", "transportSupplier")
                .add(Restrictions.like("transportSupplier.name", "%" + name + "%"));

        criteria.addOrder(Order.asc("id"));

        Collection<CostTon> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public CostTon findCostTonForSendFormat(long plantSeasonId, long transportTypeId, long transportSupplierId, long zoneId, long plantTo) throws Exception {
        CostTon feedback = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeasonId", plantSeasonId));
        criteria.createCriteria("transportType", "transportType")
                .add(Restrictions.eq("transportType.id", transportTypeId));
        criteria.createCriteria("transportSupplier", "transportSupplier")
                .add(Restrictions.eq("transportSupplier.id", transportSupplierId));
        criteria.createCriteria("zone", "zone")
                .add(Restrictions.eq("zone.id", zoneId));
        criteria.createCriteria("plantTo", "plantTo")
                .add(Restrictions.eq("plantTo.id", plantTo));
        Collection<CostTon> matchingEntry = criteria.list();
        if (matchingEntry != null && !matchingEntry.isEmpty()) {
            feedback = matchingEntry.iterator().next();
        }
        return feedback;
    }

}
