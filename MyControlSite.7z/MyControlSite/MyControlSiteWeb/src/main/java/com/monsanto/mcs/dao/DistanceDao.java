package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Distance;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 12:22:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface DistanceDao extends GenericDao<Distance, Long> {
    public Distance lookupByCriteria(Distance example) throws Exception;
    public Collection<Distance> findByName(String name, int idPlant) throws Exception;    

}
