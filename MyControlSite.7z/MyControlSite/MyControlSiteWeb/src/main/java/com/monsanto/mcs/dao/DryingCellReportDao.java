package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.DryingCellReport;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface DryingCellReportDao extends GenericDao<DryingCellReport, Long> {

    DryingCellReport findByClossingCellId(int clossingCellId) throws Exception;

    DryingCellReport findByFolio(int plant,Long folio) throws Exception;

    DryingCellReport findLastCellFolio(int plant,int cell ) throws Exception;

    Collection<DryingCellReport> findAllByPlant(long plantId) throws Exception;

    Collection<DryingCellReport> findAllByPlantSeason(long plantSeasonId) throws Exception;

    Collection<DryingCellReport> findToDryAndShellByPlant(long plantId) throws Exception;

    void delete(DryingCellReport entity);

    Collection<DryingCellReport> findToDryAndShellByPlantSeason(long plantSeasonId) throws Exception;
    
}
