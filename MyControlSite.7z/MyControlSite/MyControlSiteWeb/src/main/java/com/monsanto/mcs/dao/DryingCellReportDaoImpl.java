package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.DryingCellReport;
import com.monsanto.mcs.model.hibernate.DryingShelling;
import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class DryingCellReportDaoImpl extends HibernateDao<DryingCellReport, Long> implements DryingCellReportDao {

    public DryingCellReport findByClossingCellId(int clossingCellId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("closingCellLog.id", new Long(clossingCellId)));
        Collection<DryingCellReport> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Drying Cell Report ID found with the associated Clossing Cell");
        }
        return matchingEntry.iterator().next();
    }

    public DryingCellReport findByFolio(int plant, Long folio) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("folio", new Long(folio)));
        criteria.add(Restrictions.eq("plant.id", new Long(plant)));
        Collection<DryingCellReport> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Folio found with value: " + folio);
        }
        return matchingEntry.iterator().next();
    }

    public DryingCellReport findLastCellFolio(int plant, int cell) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant.id", new Long(plant)));

        criteria.createCriteria("closingCellLog", "closingCellLog")
                .add(Restrictions.eq("closingCellLog.cell", cell));
        criteria.addOrder(Order.desc("folio"));
        Collection<DryingCellReport> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            return null;
        }
        return matchingEntry.iterator().next();
    }

    public Collection<DryingCellReport> findAllByPlant(long plantId) throws Exception {
        Collection<DryingCellReport> results = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant.id", plantId));
        criteria.addOrder(Order.desc("folio"));
        results = criteria.list();
        return results;
    }

    public Collection<DryingCellReport> findAllByPlantSeason(long plantSeasonId) throws Exception {
        Collection<DryingCellReport> results = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("closingCellLog", "closingCellLog")
                .add(Restrictions.eq("closingCellLog.plantSeasonId", plantSeasonId));
        criteria.addOrder(Order.desc("folio"));
        results = criteria.list();
        return results;
    }

    public Collection<DryingCellReport> findToDryAndShellByPlant(long plantId) throws Exception {

        //We find all entries that have been dried and shelled
        DetachedCriteria driedShelled = DetachedCriteria.forClass(DryingShelling.class);
        driedShelled.createCriteria("dryingCellReport", "dryingCellReport")
                .add(Restrictions.eq("plant.id", plantId));
        driedShelled.setProjection(Projections.property("dryingCellReport.id"));

        Collection<DryingCellReport> results = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant.id", plantId));
        criteria.add(Subqueries.propertyNotIn("id", driedShelled));
        criteria.addOrder(Order.desc("folio"));
        results = criteria.list();
        return results;
    }

    public Collection<DryingCellReport> findToDryAndShellByPlantSeason(long plantSeasonId) throws Exception {

        //We find all entries that have been dried and shelled
        DetachedCriteria driedShelled = DetachedCriteria.forClass(DryingShelling.class);
        driedShelled.createCriteria("dryingCellReport", "dryingCellReport")
                .createCriteria("closingCellLog", "closingCellLog")
                .add(Restrictions.eq("closingCellLog.plantSeasonId", plantSeasonId));
        driedShelled.setProjection(Projections.property("dryingCellReport.id"));

        Collection<DryingCellReport> results = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("closingCellLog", "closingCellLog");
        criteria.add(Restrictions.eq("closingCellLog.plantSeasonId", plantSeasonId));
        criteria.add(Subqueries.propertyNotIn("id", driedShelled));
        criteria.addOrder(Order.desc("folio"));
        results = criteria.list();
        return results;
    }

    public void delete(DryingCellReport entity) {
        super.delete(entity);
    }

}
