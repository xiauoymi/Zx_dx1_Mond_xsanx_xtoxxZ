package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.DryingShelling;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Date;

@Transactional
public interface DryingShellingDao extends GenericDao<DryingShelling, Long> {

    public DryingShelling findByFolio(Long folio) throws Exception;

    public DryingShelling save(DryingShelling entity) throws Exception;

    public Collection<DryingShelling> findByDateCellHybrid(long plantId,Date initialDate, Date finalDate,int cell, long hybridId) throws Exception;

    public Collection<DryingShelling> findAllByPlantOrderDryingFolio(long plantSeasonId, long order, long dryingFolio) throws Exception;

    public DryingShelling findByMixtureLot(String mixtureLot) throws Exception;

    public Collection<DryingShelling> findByMixtureLot(int plantId,String mixtureLot) throws Exception;

    public DryingShelling findByClossingCellFolio(int plantId,int clossingCellFolio) throws Exception;

    Collection<DryingShelling> findDSByMixtureLot(String mixtureLot) throws Exception;

}
