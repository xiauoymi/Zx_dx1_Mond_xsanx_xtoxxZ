package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.DryingShelling;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.Date;

@Repository
public class DryingShellingDaoImpl extends HibernateDao<DryingShelling, Long> implements DryingShellingDao {

    public DryingShelling findByFolio(Long folio) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("dryingFolio", new Long(folio)));
        Collection<DryingShelling> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Folio found with value: " + folio);
        }
        return matchingEntry.iterator().next();
    }

    public DryingShelling save(DryingShelling entity) throws Exception {
        DryingShelling dryingShelling = null;
        try {
            dryingShelling = super.saveOrUpdate(entity);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dryingShelling;
    }

    public Collection<DryingShelling> findByDateCellHybrid(long plantId, Date initialDate, Date finalDate, int cell, long hybridId) throws Exception {
        Criteria criteria = createCriteria();
        if (plantId == 0 && initialDate == null && finalDate == null && cell == 0 && hybridId == 0) {
            criteria = createCriteria(false);
        }
        if (initialDate != null) {
            criteria.add(Restrictions.ge("shellingStartDate", initialDate));
        }
        if (finalDate != null) {
            criteria.add(Restrictions.le("shellingEndDate", finalDate));
        }
        if (cell != 0) {
            criteria.createCriteria("dryingCellReport", "dryingCellReport")
                    .add(Restrictions.eq("dryingCellReport.plant.id", plantId))
                    .createCriteria("dryingCellReport.closingCellLog", "dryingCellReport.closingCellLog")
                    .add(Restrictions.eq("closingCellLog.cell", cell));
        } else {
            criteria.createCriteria("dryingCellReport", "dryingCellReport");
            criteria.add(Restrictions.eq("dryingCellReport.plant.id", plantId));
        }
        if (hybridId != 0) {
            criteria.createCriteria("shellingOrder", "shellingOrder").createCriteria("hybrid", "hybrid").add(Restrictions.eq("shellingOrder.hybrid.id", hybridId));
        }
        Collection<DryingShelling> matchingEntry = criteria.list();
        /**if (matchingEntry.isEmpty()) {
         throw new Exception("No records found with the specified filter. ");
         }*/
        return matchingEntry;
    }

    public Collection<DryingShelling> findAllByPlantOrderDryingFolio(long plantSeasonId, long order, long dryingFolio) throws Exception {
        Collection<DryingShelling> results = null;

        Criteria criteria = createCriteria();
        criteria.createCriteria("dryingCellReport", "dryingCellReport")
                .createCriteria("closingCellLog", "closingCellLog")
                .add(Restrictions.eq("plantSeasonId", plantSeasonId));
        if (dryingFolio != 0) {
            criteria.add(Restrictions.eq("dryingCellReport.folio", dryingFolio));
        }
        if (order != 0) {
            criteria.createCriteria("shellingOrder", "shellingOrder");
            criteria.add(Restrictions.eq("shellingOrder.shellingOrder", order));
        }
        results = criteria.list();
        return results;
    }

    public DryingShelling findByMixtureLot(String mixtureLot) throws Exception {
        Collection<DryingShelling> results = null;

        Criteria criteria = createCriteria();
        criteria.createCriteria("shellingOrder", "shellingOrder");
        criteria.add(Restrictions.eq("shellingOrder.mixtureLot", mixtureLot));
        criteria.add(Restrictions.isNotNull("dryingFolio"));
        results = criteria.list();
        if (results.isEmpty()) {
            return null;
        }
        return results.iterator().next();
    }

    public Collection<DryingShelling> findByMixtureLot(int plantId, String mixtureLot) throws Exception {
        Collection<DryingShelling> results = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("dryingCellReport", "dryingCellReport")
                .createCriteria("plant", "plant")
                .add(Restrictions.eq("plant.id", (long) plantId));
        criteria.createCriteria("shellingOrder", "shellingOrder");
        criteria.add(Restrictions.eq("shellingOrder.mixtureLot", mixtureLot));
        criteria.add(Restrictions.isNotNull("dryingFolio"));
        results = criteria.list();
        if (results.isEmpty()) {
            return null;
        }
        return results;
    }

    public Collection<DryingShelling> findDSByMixtureLot(String mixtureLot) throws Exception {
        Collection<DryingShelling> results = null;

        Criteria criteria = createCriteria();
        criteria.createCriteria("shellingOrder", "shellingOrder");
        criteria.add(Restrictions.eq("shellingOrder.mixtureLot", mixtureLot));
        criteria.add(Restrictions.isNotNull("dryingFolio"));
        return criteria.list();
    }

    public DryingShelling findByClossingCellFolio(int plantId, int clossingCellFolio) throws Exception {
        Collection<DryingShelling> results = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("dryingCellReport", "dryingCellReport")
                .createCriteria("plant", "plant")
                .add(Restrictions.eq("plant.id", (long) plantId))
                .createCriteria("dryingCellReport.closingCellLog", "dryingCellReport.closingCellLog")
                .add(Restrictions.eq("dryingCellReport.closingCellLog.id", (long) clossingCellFolio));
        results = criteria.list();
        if (results.isEmpty()) {
            return null;
        }
        return results.iterator().next();
    }

}
