package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.EmailTo;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/03/2011
 * Time: 09:15:17 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class EmailToDaoImpl extends HibernateDao<EmailTo, Long> implements EmailToDao {

    private static final Logger LOG = Logger.getLogger(EmailToDaoImpl.class);

    public EmailTo lookupByCriteria(int idPlant, EmailTo emailTo) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.eq("address", emailTo.getAddress()));
        Collection<EmailTo> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No EMAIL_TO found with value: " + emailTo.getAddress());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<EmailTo> findAll(String address) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("address", "%" + address + "%"));
        criteria.addOrder(Order.asc("id"));
        Collection<EmailTo> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<EmailTo> findAllByMailType(String mailType, long idPlant) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("mailType", mailType))
                .createCriteria("plant", "plant")
                .add(Restrictions.eq("plant.id", idPlant));

        Collection<EmailTo> matchingEntry = criteria.list();
        return matchingEntry;
    }


}

