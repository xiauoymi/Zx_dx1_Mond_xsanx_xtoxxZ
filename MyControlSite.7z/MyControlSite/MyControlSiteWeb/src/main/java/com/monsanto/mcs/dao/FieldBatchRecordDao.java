package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.FieldBatchRecord;
import com.monsanto.mcs.model.hibernate.FieldStage;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 12:47:53 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface FieldBatchRecordDao extends GenericDao<FieldBatchRecord, Long> {
    public Collection<FieldBatchRecord> findByName(String name) throws Exception;

    public Collection<FieldBatchRecord> findByCriterias(int plantSeason, String hybrid, String lot, String specialist, String grower) throws Exception;

    public Collection<FieldBatchRecord> findLotsByCriterias(int plantSeason, String hybrid, String lot, String specialist, String grower) throws Exception;

    public Collection<FieldBatchRecord> findAssignedLots(int plantSeason) throws Exception;

    public FieldBatchRecord findLot(long lot) throws Exception;

    public boolean isAvailableLot(long lot, Long id) throws Exception;

    public boolean isAvailableGrowerOrder(long growerOrder, Long id) throws Exception;

    public boolean isAvailablePurchaseOrder(long purchaseOrder, Long id) throws Exception;

    public Collection<FieldBatchRecord> findByPlantSeason(int plantSeason) throws Exception;

}
