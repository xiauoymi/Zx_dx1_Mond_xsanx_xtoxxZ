package com.monsanto.mcs.dao;


import com.monsanto.mcs.model.hibernate.FieldBatchRecord;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 03:57:39 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class FieldBatchRecordDaoImpl extends HibernateDao<FieldBatchRecord, Long> implements FieldBatchRecordDao {

    private static final Logger LOG = Logger.getLogger(FieldBatchRecordDaoImpl.class);

    public Collection<FieldBatchRecord> findByName(String name) throws Exception {
        Criteria criteria = createCriteria();
        Collection<FieldBatchRecord> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No field batch record was found: " + name);
        }
        return matchingEntry;
    }

    public Collection<FieldBatchRecord> findByCriterias(int plantSeason, String hybrid, String lot, String specialist, String grower) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeason.id", new Long(plantSeason)));

        if (hybrid != null && hybrid.trim().length() > 0) {
            criteria.createCriteria("hybrid", "hybrid")
                    .add(Restrictions.like("hybrid.name", "%" + hybrid + "%"));
        }
        if (specialist != null && specialist.trim().length() > 0) {
            criteria.createCriteria("specialist", "specialist")
                    .add(Restrictions.like("specialist.name", "%" + specialist + "%"));
        }
        if (grower != null && grower.trim().length() > 0) {
            criteria.createCriteria("grower", "grower")
                    .add(Restrictions.like("grower.name", "%" + grower + "%"));
        }
        if (lot != null && lot.trim().length() > 0) {
            try {
                Long longLot = new Long(lot);
                criteria.add(Restrictions.eq("lot", longLot));
            } catch (Exception e) {
            }
        }

        criteria.addOrder(Order.desc("id"));

        Collection<FieldBatchRecord> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No field batch record was found (by Criteria)");
        }
        return matchingEntry;
    }

    public Collection<FieldBatchRecord> findLotsByCriterias(int plantSeason, String hybrid, String lot, String specialist, String grower) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeason.id", new Long(plantSeason)));

        if (hybrid != null && hybrid.trim().length() > 0) {
            criteria.createCriteria("hybrid", "hybrid")
                    .add(Restrictions.like("hybrid.name", "%" + hybrid + "%"));
        }
        if (specialist != null && specialist.trim().length() > 0) {
            criteria.createCriteria("specialist", "specialist")
                    .add(Restrictions.like("specialist.name", "%" + specialist + "%"));
        }
        if (grower != null && grower.trim().length() > 0) {
            criteria.createCriteria("grower", "grower")
                    .add(Restrictions.like("grower.name", "%" + grower + "%"));
        }
        if (lot != null && lot.trim().length() > 0) {
            try {
                Long longLot = new Long(lot);
                criteria.add(Restrictions.eq("lot", longLot));
            } catch (Exception e) {
            }
        }
        criteria.add(Restrictions.gt("lot", 0L));
        criteria.addOrder(Order.desc("id"));

        Collection<FieldBatchRecord> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No field batch record was found (by Criteria)");
        }
        return matchingEntry;
    }

    public Collection<FieldBatchRecord> findAssignedLots(int plantSeason) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeason.id", new Long(plantSeason)));
        criteria.add(Restrictions.gt("lot", 0L));
        criteria.addOrder(Order.asc("lot"));

        Collection<FieldBatchRecord> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public FieldBatchRecord findLot(long lot) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("lot", lot));
        criteria.addOrder(Order.asc("lot"));
        Collection<FieldBatchRecord> matchingEntry = criteria.list();
        FieldBatchRecord result = null;
        if (matchingEntry.size() > 0) {
            result = matchingEntry.iterator().next();
        }
        return result;
    }

    public boolean isAvailableLot(long lot, Long id) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("lot", lot));
        criteria.add(Restrictions.ne("id", id));

        Collection<FieldBatchRecord> matchingEntry = criteria.list();
        boolean available = false;

        if (matchingEntry == null) {
            available = true;
        } else if (matchingEntry.size() == 0)
            available = true;
        else
            available = false;
        return available;
    }

    public boolean isAvailableGrowerOrder(long growerOrder, Long id) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("growerOrder", growerOrder));
        criteria.add(Restrictions.ne("id", id));

        Collection<FieldBatchRecord> matchingEntry = criteria.list();
        boolean available = false;

        if (matchingEntry == null) {
            available = true;
        } else if (matchingEntry.size() == 0)
            available = true;
        else
            available = false;
        return available;
    }

    public boolean isAvailablePurchaseOrder(long purchaseOrder, Long id) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("purchaseOrder", purchaseOrder));
        criteria.add(Restrictions.ne("id", id));

        Collection<FieldBatchRecord> matchingEntry = criteria.list();
        boolean available = false;

        if (matchingEntry == null) {
            available = true;
        } else if (matchingEntry.size() == 0)
            available = true;
        else
            available = false;
        return available;
    }

    public Collection<FieldBatchRecord> findByPlantSeason(int plantSeason) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeason.id", new Long(plantSeason)));
        criteria.addOrder(Order.desc("id"));
        Collection<FieldBatchRecord> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No field batch record was found (by Criteria)");
        }
        return matchingEntry;
    }

}
