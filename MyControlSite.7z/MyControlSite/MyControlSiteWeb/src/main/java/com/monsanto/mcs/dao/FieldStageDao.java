package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.FieldBatchRecord;
import com.monsanto.mcs.model.hibernate.FieldStage;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 12:53:39 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface FieldStageDao extends GenericDao<FieldStage, Long> {
    public FieldStage lookupByCriteria(FieldStage example) throws Exception;
    public Collection<FieldStage> findByBatch(int batchId) throws Exception;
    public Collection<FieldStage> findPlantingByBatch(int batchId);

    Collection<FieldStage> findFieldStagesForFbr(FieldBatchRecord fbr);
}
