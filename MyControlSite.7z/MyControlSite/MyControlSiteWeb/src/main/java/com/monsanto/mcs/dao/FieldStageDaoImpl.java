package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.FieldBatchRecord;
import com.monsanto.mcs.model.hibernate.FieldStage;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 04:06:28 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class FieldStageDaoImpl extends HibernateDao<FieldStage, Long> implements FieldStageDao {

    private static final Logger LOG = Logger.getLogger(FieldStageDaoImpl.class);
    private static final int PLANTING_STAGE_TYPE = 1;

    public FieldStage lookupByCriteria(FieldStage example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getStage()));
        Collection<FieldStage> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No stage found with value: " + example.getStage());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<FieldStage> findByBatch(int batchId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("batch", new Long(batchId)));
        criteria.addOrder(Order.asc("id"));
        Collection<FieldStage> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<FieldStage> findPlantingByBatch(int batchId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("batch", new Long(batchId)));
        criteria.add(Restrictions.eq("type", PLANTING_STAGE_TYPE));
        criteria.addOrder(Order.asc("id"));
        Collection<FieldStage> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<FieldStage> findByCriterias(int plantSeason, String hybrid, String lot, String specialist, String grower) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeasonId", new Long(plantSeason)));

        if (hybrid != null && hybrid.trim().length() > 0) {
            criteria.createCriteria("hybrid", "hybrid")
                    .add(Restrictions.like("hybrid.name", "%" + hybrid + "%"));
        }
        if (specialist != null && specialist.trim().length() > 0) {
            criteria.createCriteria("specialist", "specialist")
                    .add(Restrictions.like("specialist.name", "%" + specialist + "%"));
        }
        if (grower != null && grower.trim().length() > 0) {
            criteria.createCriteria("grower", "grower")
                    .add(Restrictions.like("grower.name", "%" + grower + "%"));
        }
        if (lot != null && lot.trim().length() > 0) {
            try {
                int intLot = new Integer(lot);
                criteria.add(Restrictions.eq("lot", intLot));
            } catch (Exception e) {
            }
        }

        criteria.addOrder(Order.desc("id"));

        Collection<FieldStage> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No field stage record was found (by Criteria)");
        }
        return matchingEntry;
    }

    public Collection<FieldStage> findFieldStagesForFbr(FieldBatchRecord fbr) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("batch", fbr.getId()));
        criteria.addOrder(Order.asc("id"));
        Collection<FieldStage> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
