package com.monsanto.mcs.dao;


import com.monsanto.mcs.model.hibernate.FloweringData;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:46:33 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface FloweringDataDao extends GenericDao<FloweringData, Long> {    

    public Collection<FloweringData> findByBatch(int batchId);

    Collection<FloweringData> findByPlantAndSeason(Integer plantSeasonId);
}
