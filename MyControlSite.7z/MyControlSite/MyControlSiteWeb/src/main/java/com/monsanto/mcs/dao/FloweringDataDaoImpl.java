package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.FloweringData;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:48:46 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class FloweringDataDaoImpl extends HibernateDao<FloweringData, Long> implements FloweringDataDao {

    private static final Logger LOG = Logger.getLogger(FloweringDataDaoImpl.class);

    public Collection<FloweringData> findByBatch(int batchId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("batchId", new Long(batchId)));
        Collection<FloweringData> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<FloweringData> findByPlantAndSeason(Integer plantSeasonId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeasonId", plantSeasonId.longValue()));
        return criteria.list();
    }

}
