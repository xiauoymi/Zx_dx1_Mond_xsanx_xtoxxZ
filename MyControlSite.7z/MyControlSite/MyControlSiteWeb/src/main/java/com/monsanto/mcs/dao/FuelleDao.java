package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Fuelle;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface FuelleDao extends GenericDao<Fuelle, Long> {
    public Fuelle lookupByCriteria(Fuelle example) throws Exception;

    public Collection<Fuelle> findByName(String name) throws Exception;
}
