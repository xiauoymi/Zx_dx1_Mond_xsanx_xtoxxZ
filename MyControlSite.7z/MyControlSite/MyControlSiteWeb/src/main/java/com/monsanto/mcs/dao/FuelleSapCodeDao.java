package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BagType;
import com.monsanto.mcs.model.hibernate.Brand;
import org.springframework.transaction.annotation.Transactional;
import com.monsanto.mcs.model.hibernate.FuelleSapCode;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:14:30 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface FuelleSapCodeDao extends GenericDao<FuelleSapCode, Long>{
    
    public FuelleSapCode lookupByCriteria(FuelleSapCode example) throws Exception;

    public Collection<FuelleSapCode> findByName(String name) throws Exception;

    public Collection<FuelleSapCode> findByBagType(BagType bagType, Brand brand) throws Exception;
}
