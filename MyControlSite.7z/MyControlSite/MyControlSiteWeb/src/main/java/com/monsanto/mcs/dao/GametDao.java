package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Gamet;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface GametDao extends GenericDao<Gamet, Long> {
    
}
