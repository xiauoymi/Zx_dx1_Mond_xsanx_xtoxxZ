package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Gamet;
import org.springframework.stereotype.Repository;

@Repository
public class GametDaoImpl extends HibernateDao<Gamet, Long> implements GametDao {

}

