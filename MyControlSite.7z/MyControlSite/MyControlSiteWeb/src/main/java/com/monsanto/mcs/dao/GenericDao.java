package com.monsanto.mcs.dao;

import org.hibernate.Criteria;
import org.springframework.transaction.annotation.Transactional;

import java.io.Serializable;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 18, 2010 Time: 10:00:28 AM To change this template use File |
 * Settings | File Templates.
 */
@Transactional
public interface GenericDao<T, ID extends Serializable> {
    public T findByPrimaryKey(ID id);

    public Collection<T> findAll();

    public Collection<T> findAll(int startIndex, int fetchSize);

    public Collection<T> findByExample(T exampleInstance, String[] excludeProperty);

    public Collection<T> findAll(String key, boolean ascending);

    public T saveOrUpdate(T entity);

    public T merge(T entity);

    public void delete(T entity);

//  void beginTransaction();
//
//  void commitTransaction();

    public Criteria createCriteria();

    Criteria createCriteria(boolean isDeleted);
}
