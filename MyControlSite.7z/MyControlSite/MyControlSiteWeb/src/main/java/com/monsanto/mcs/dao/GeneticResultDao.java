package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.FieldStage;
import com.monsanto.mcs.model.hibernate.FloweringData;
import com.monsanto.mcs.model.hibernate.GeneticResult;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:52:38 AM
 * To change this template use File | Settings | File Templates.
 */

@Transactional
public interface GeneticResultDao extends GenericDao<GeneticResult, Long> {

    Collection<GeneticResult> findByBatch(int batchId);

    Collection<GeneticResult> findByBatch(int batchId,int type);

    Collection<GeneticResult> findByFieldStage(FieldStage fieldStage);

    Collection<GeneticResult> findByFieldStage(FieldStage fieldStage,int type);

    Collection<GeneticResult> findByFieldStageCondition(FieldStage fieldStage,int type,int conditionId);

}
