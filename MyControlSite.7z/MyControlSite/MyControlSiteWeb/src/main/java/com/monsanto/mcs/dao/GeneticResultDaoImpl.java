package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.FieldStage;
import com.monsanto.mcs.model.hibernate.GeneticResult;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 11:01:33 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class GeneticResultDaoImpl extends HibernateDao<GeneticResult, Long> implements GeneticResultDao {

    private static final Logger LOG = Logger.getLogger(GeneticResultDaoImpl.class);

    public Collection<GeneticResult> findByBatch(int batchId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("batchId", new Long(batchId)));
        Collection<GeneticResult> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<GeneticResult> findByBatch(int batchId, int type) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("batchId", new Long(batchId)));
        criteria.add(Restrictions.like("type", new Long(type)));
        Collection<GeneticResult> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<GeneticResult> findByFieldStage(FieldStage fieldStage) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("fieldStage", fieldStage));
        Collection<GeneticResult> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<GeneticResult> findByFieldStage(FieldStage fieldStage, int type) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("fieldStage", fieldStage));
        criteria.add(Restrictions.like("type", new Long(type)));
        Collection<GeneticResult> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<GeneticResult> findByFieldStageCondition(FieldStage fieldStage, int type, int conditionId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("fieldStage", fieldStage));
        criteria.add(Restrictions.like("type", new Long(type)));
        if (0 != conditionId) {
            criteria.createCriteria("quarantineLot", "quarantineLot")
                    .createCriteria("condition", "condition")
                    .add(Restrictions.eq("condition.id", new Long(conditionId)));
        }
        Collection<GeneticResult> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<GeneticResult> findByFieldStageAndCondition(FieldStage fieldStage, int type) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("fieldStage", fieldStage));
        criteria.add(Restrictions.like("type", new Long(type)));
        criteria.createCriteria("fieldStage", "fieldStage")
                .add(Restrictions.like("fieldStage", new Long(type)));
        Collection<GeneticResult> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
