package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Grading;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface GradingDao extends GenericDao<Grading, Long> {

    Collection<Grading> findByMixtureLot(long plantSeasonId,String mixtureLot) throws Exception;

    Grading existsGradinCellMixtureLot(int cell, String mixtureLot) throws Exception;

    Collection<Grading> findByMixtureLotDestinationPlant(long plantSeasonId,String mixtureLot) throws Exception;

}
