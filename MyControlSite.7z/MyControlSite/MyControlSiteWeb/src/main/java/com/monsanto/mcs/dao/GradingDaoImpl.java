package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Grading;
import com.monsanto.mcs.model.hibernate.Scale;
import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class GradingDaoImpl extends HibernateDao<Grading, Long> implements GradingDao {

    public Collection<Grading> findByMixtureLot(long plantSeasonId, String mixtureLot) throws Exception {
        Collection<Grading> results = null;
        Criteria criteria = createCriteria();

        if (mixtureLot.equals("")) {
            criteria.createCriteria("dryingShelling", "dryingShelling")
                    .createCriteria("dryingCellReport", "dryingCellReport")
                    .createCriteria("closingCellLog", "closingCellLog")
                    .add(Restrictions.eq("plantSeasonId", plantSeasonId));
        } else {
            if (!mixtureLot.equals("")) {
                criteria.createCriteria("dryingShelling", "dryingShelling")
                        .createCriteria("shellingOrder", "shellingOrder")
                        .add(Restrictions.eq("shellingOrder.mixtureLot", mixtureLot))
                        .createCriteria("dryingShelling.dryingCellReport", "dryingShelling.dryingCellReport")
                        .createCriteria("closingCellLog", "closingCellLog")
                        .add(Restrictions.eq("plantSeasonId", plantSeasonId));
            }
        }
        results = criteria.list();
        return results;
    }

    public Collection<Grading> findByMixtureLotDestinationPlant(long plantSeasonId, String mixtureLot) throws Exception {
        Collection<Grading> results = null;
        Criteria criteria = createCriteria();
        if (mixtureLot.equals("")) {
            DetachedCriteria destinationClosingCell = DetachedCriteria.forClass(Scale.class);
            destinationClosingCell.createCriteria("sendFormat", "sendFormat")
                    .add(Restrictions.eq("sendFormat.plantTo.id", plantSeasonId));
            destinationClosingCell.setProjection(Projections.property("closed"));
            criteria.createCriteria("dryingShelling", "dryingShelling")
                    .createCriteria("dryingCellReport", "dryingCellReport")
                    .createCriteria("closingCellLog", "closingCellLog");
            criteria.add(Subqueries.propertyIn("closingCellLog.id", destinationClosingCell));
        } else {
            if (!mixtureLot.equals("")) {

                DetachedCriteria destinationClosingCell = DetachedCriteria.forClass(Scale.class);
                destinationClosingCell.createCriteria("sendFormat", "sendFormat")
                        .add(Restrictions.eq("sendFormat.plantTo.id", plantSeasonId));
                destinationClosingCell.setProjection(Projections.property("closed"));
                criteria.createCriteria("dryingShelling", "dryingShelling")
                        .createCriteria("shellingOrder", "shellingOrder")
                        .add(Restrictions.eq("shellingOrder.mixtureLot", mixtureLot))
                        .createCriteria("dryingShelling.dryingCellReport", "dryingShelling.dryingCellReport")
                        .createCriteria("closingCellLog", "closingCellLog");
                criteria.add(Subqueries.propertyIn("closingCellLog.id", destinationClosingCell));
            }
        }
        return criteria.list();
    }

    public Grading existsGradinCellMixtureLot(int cell, String mixtureLot) throws Exception {
        Collection<Grading> results = null;
        Criteria criteria = createCriteria();
        if (cell != 0) {
            criteria.add(Restrictions.eq("cell", cell));
        }
        if (!mixtureLot.equals("")) {
            criteria.createCriteria("dryingShelling", "dryingShelling")
                    .createCriteria("shellingOrder", "shellingOrder")
                    .add(Restrictions.eq("shellingOrder.mixtureLot", mixtureLot));
        }
        results = criteria.list();
        if (results == null || results.isEmpty()) {
            return null;
        }
        return results.iterator().next();
    }


}

