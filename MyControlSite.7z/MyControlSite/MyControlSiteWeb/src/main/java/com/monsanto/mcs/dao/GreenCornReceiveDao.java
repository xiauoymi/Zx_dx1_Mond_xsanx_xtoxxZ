package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface GreenCornReceiveDao extends GenericDao<GreenCornReceive, Long>{

    public Collection<GreenCornReceive> findByPlantSeason(int idPlant, int idSeason) throws Exception;

}
