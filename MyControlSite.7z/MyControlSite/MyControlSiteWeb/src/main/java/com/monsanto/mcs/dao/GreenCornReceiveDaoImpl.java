package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class GreenCornReceiveDaoImpl extends HibernateDao<GreenCornReceive, Long> implements GreenCornReceiveDao {

    public Collection<GreenCornReceive> findByPlantSeason(int idPlant, int idSeason) throws Exception {
        Criteria criteria = createCriteria();
        //criteria.add(Restrictions.eq("pk.plant", idPlant));
        criteria.add(Restrictions.eq("season", idSeason));
        criteria.add(Restrictions.eq("plantToId", idPlant));
        criteria.addOrder(Order.asc("pk.sendFormatFolio"));
        Collection<GreenCornReceive> matchingEntry = criteria.list();

        if (matchingEntry.isEmpty()) {
            // Do nothing so XLS will be presented empty to the user
            //throw new Exception("No GCR found with plant: " + idPlant +" and Season " + idSeason);
        }
        return matchingEntry;
    }

}
