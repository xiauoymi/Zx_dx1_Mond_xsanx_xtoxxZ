package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Grower;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 12:50:31 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface GrowerDao extends GenericDao<Grower, Long>{
    public Grower lookupByCriteria(Grower example) throws Exception;
    public Collection<Grower> findByName(String name, int idPlant) throws Exception;    
    public Collection<Grower> findAllOrderedById(String name, int idPlant) throws Exception;
}
