package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Grower;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 04:10:31 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class GrowerDaoImpl extends HibernateDao<Grower, Long> implements GrowerDao {

    private static final Logger LOG = Logger.getLogger(GrowerDaoImpl.class);

    public Grower lookupByCriteria(Grower example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getName()));
        Collection<Grower> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No grower found with name: " + example.getName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Grower> findByName(String name, int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        criteria.addOrder(Order.asc("name"));
        Collection<Grower> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No grower found with name: " + name);
        }
        return matchingEntry;
    }

    public Collection<Grower> findAllOrderedById(String name, int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        criteria.addOrder(Order.asc("id"));
        Collection<Grower> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No grower found with name: " + name);
        }
        return matchingEntry;
    }


}
