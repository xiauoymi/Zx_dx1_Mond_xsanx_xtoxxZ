package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Comment;
import com.monsanto.mcs.model.hibernate.HarvestedFieldStage;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface HarvestedFieldStageDao extends GenericDao<HarvestedFieldStage, Long> {

    public Collection<HarvestedFieldStage> findByFieldStage(int fieldStage) throws Exception;

}
