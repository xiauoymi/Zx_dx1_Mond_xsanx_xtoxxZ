package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.HarvestedFieldStage;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class HarvestedFieldStageDaoImpl extends HibernateDao<HarvestedFieldStage, Long> implements HarvestedFieldStageDao {

    private static final Logger LOG = Logger.getLogger(HarvestedFieldStageDaoImpl.class);

    public Collection<HarvestedFieldStage> findByFieldStage(int fieldStage) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("fieldStage", new Long(fieldStage)));
        Collection<HarvestedFieldStage> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Harvested Field Stage found with Field Stage code: " + fieldStage);
        }
        return matchingEntry;
    }


}
