package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Hybrid;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 12:54:26 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface HybridDao extends GenericDao<Hybrid, Long> {
    public Hybrid lookupByCriteria(Hybrid example) throws Exception;
    public Collection<Hybrid> findByName(String name, int idPlantSeason, int field) throws Exception;
    public Collection<Hybrid> findByNameExactMatch(String name, int idPlantSeason, int fieldOrder) throws Exception;
}
