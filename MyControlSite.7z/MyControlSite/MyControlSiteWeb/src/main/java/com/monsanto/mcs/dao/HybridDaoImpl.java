package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Hybrid;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 04:13:15 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class HybridDaoImpl extends HibernateDao<Hybrid, Long> implements HybridDao {

    private static final Logger LOG = Logger.getLogger(HybridDaoImpl.class);

    public Hybrid lookupByCriteria(Hybrid example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getName()));
        Collection<Hybrid> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No grower found with name: " + example.getName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Hybrid> findByName(String name, int idPlantSeason, int fieldOrder) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeason.id", new Long(idPlantSeason)));
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        switch (fieldOrder) {
            case 1:
                criteria.addOrder(Order.asc("id"));
                break;
            case 2:
                criteria.addOrder(Order.asc("name"));
                break;
            case 3:
                criteria.addOrder(Order.asc("code"));
                break;
            case 4:
                criteria.addOrder(Order.asc("materialNumber"));
                break;
        }
        Collection<Hybrid> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No hybrid found with name: " + name);
        }
        return matchingEntry;
    }

    public Collection<Hybrid> findByNameExactMatch(String name, int idPlantSeason, int fieldOrder) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeason.id", new Long(idPlantSeason)));
        if (name != null && !name.equals("")) {
            criteria.add(Restrictions.eq("name", name));
        }
        switch (fieldOrder) {
            case 1:
                criteria.addOrder(Order.asc("id"));
                break;
            case 2:
                criteria.addOrder(Order.asc("name"));
                break;
            case 3:
                criteria.addOrder(Order.asc("code"));
                break;
            case 4:
                criteria.addOrder(Order.asc("materialNumber"));
                break;
        }
        Collection<Hybrid> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No hybrid found with name: " + name);
        }
        return matchingEntry;
    }

}
