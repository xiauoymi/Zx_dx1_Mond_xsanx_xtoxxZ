package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Label;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface LabelDao extends GenericDao<Label, Long> {
    public Label lookupByCriteria(Label example) throws Exception;

    public Collection<Label> findByName(String name) throws Exception;
}
