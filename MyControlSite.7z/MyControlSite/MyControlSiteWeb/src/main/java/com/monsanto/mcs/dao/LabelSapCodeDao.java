package com.monsanto.mcs.dao;

import org.springframework.transaction.annotation.Transactional;
import com.monsanto.mcs.model.hibernate.LabelSapCode;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:14:30 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface LabelSapCodeDao extends GenericDao<LabelSapCode, Long>{
    
    public LabelSapCode lookupByCriteria(LabelSapCode example) throws Exception;

    public Collection<LabelSapCode> findByName(String name) throws Exception;

    public Collection<LabelSapCode> findByBrandName(String name) throws Exception;

    public Collection<LabelSapCode> findByLabelName(String name) throws Exception;

}
