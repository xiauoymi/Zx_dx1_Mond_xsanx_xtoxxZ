package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.LabelSapCode;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:14:47 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class LabelSapCodeDaoImpl extends HibernateDao<LabelSapCode, Long> implements LabelSapCodeDao {

    private static final Logger LOG = Logger.getLogger(LabelSapCodeDaoImpl.class);

    public LabelSapCode lookupByCriteria(LabelSapCode example) throws Exception {
        Criteria criteria = createCriteria();
        Collection<LabelSapCode> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No LabelSapCode found: " + example.getCode());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<LabelSapCode> findByName(String name) throws Exception {
        Criteria criteria = createCriteria();
        Collection<LabelSapCode> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<LabelSapCode> findByBrandName(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("brand", "brand");
        criteria.add(Restrictions.eq("brand.name", name));
        Collection<LabelSapCode> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<LabelSapCode> findByLabelName(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("label", "label");
        criteria.add(Restrictions.eq("label.name", name));
        Collection<LabelSapCode> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
