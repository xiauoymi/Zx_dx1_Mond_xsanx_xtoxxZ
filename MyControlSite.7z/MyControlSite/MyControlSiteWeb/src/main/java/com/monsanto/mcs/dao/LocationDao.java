package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Location;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 12:55:19 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface LocationDao extends GenericDao<Location, Long> {
    public Location lookupByCriteria(Location example) throws Exception;
    
    public Collection<Location> findByName(String name, int idPlant) throws Exception;

}
