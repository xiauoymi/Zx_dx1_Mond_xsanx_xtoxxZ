package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Location;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 04:15:53 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class LocationDaoImpl extends HibernateDao<Location, Long> implements LocationDao {

    private static final Logger LOG = Logger.getLogger(LocationDaoImpl.class);

    public Location lookupByCriteria(Location example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("locationName", example.getLocationName()));
        Collection<Location> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No location found with name: " + example.getLocationName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Location> findByName(String name, int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("locationName", "%" + name + "%"));
        criteria.addOrder(Order.asc("locationName"));
        Collection<Location> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No location found with name: " + name);
        }
        return matchingEntry;
    }


}
