package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.LocationZone;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/01/2011
 * Time: 03:59:25 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface LocationZoneDao extends GenericDao<LocationZone, Long>{

    public LocationZone lookupByCriteria(LocationZone example) throws Exception;

    public Collection<LocationZone> findByName(String name, int idPlant) throws Exception;

    public LocationZone findZoneByLocation(long id) throws Exception;


}
