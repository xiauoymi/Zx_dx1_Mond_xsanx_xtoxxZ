package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.LocationZone;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/01/2011
 * Time: 04:00:20 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class LocationZoneDaoImpl extends HibernateDao<LocationZone, Long> implements LocationZoneDao {

    private static final Logger LOG = Logger.getLogger(LocationZoneDaoImpl.class);

    public LocationZone lookupByCriteria(LocationZone example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getLocation().getLocationName()));
        Collection<LocationZone> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No LocationZone found with name: " + example.getLocation().getLocationName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<LocationZone> findByName(String name, int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        //criteria.add(Restrictions.like("location.locationName", "%"+name+"%"));
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        Collection<LocationZone> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No LocationZone found with name: " + name);
        }
        return matchingEntry;
    }


    public LocationZone findZoneByLocation(long id) throws Exception {

        LocationZone feedback = null;
        Criteria criteria = createCriteria();
        criteria.createCriteria("location", "location")
                .add(Restrictions.eq("location.id", id));

        Collection<LocationZone> matchingEntry = criteria.list();
        if (matchingEntry != null && !matchingEntry.isEmpty()) {
            feedback = matchingEntry.iterator().next();
        }
        return feedback;
    }


}
