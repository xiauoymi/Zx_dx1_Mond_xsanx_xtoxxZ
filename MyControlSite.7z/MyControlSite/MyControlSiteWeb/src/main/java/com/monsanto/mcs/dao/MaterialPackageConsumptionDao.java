package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Bagging;
import com.monsanto.mcs.model.hibernate.MaterialPackageConsumption;
import com.monsanto.mcs.model.hibernate.Shift;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Date;

@Transactional
public interface MaterialPackageConsumptionDao extends GenericDao<MaterialPackageConsumption, Long> {
    
}
