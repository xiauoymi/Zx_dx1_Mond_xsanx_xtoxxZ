package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.MaterialPackageConsumption;
import org.springframework.stereotype.Repository;

@Repository
public class MaterialPackageConsumptionDaoImpl extends HibernateDao<MaterialPackageConsumption, Long> implements MaterialPackageConsumptionDao {

}
