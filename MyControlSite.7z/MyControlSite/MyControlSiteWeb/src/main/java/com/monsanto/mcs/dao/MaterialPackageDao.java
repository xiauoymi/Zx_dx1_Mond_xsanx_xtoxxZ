package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.MaterialPackage;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 10:09:12 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface MaterialPackageDao  extends GenericDao<MaterialPackage, Long>{

    public Collection<MaterialPackage> findByPlantSeason(int idPlantSeason) throws Exception;

    public Collection<MaterialPackage> findByHybrid(int idHybrid) throws Exception;

}
