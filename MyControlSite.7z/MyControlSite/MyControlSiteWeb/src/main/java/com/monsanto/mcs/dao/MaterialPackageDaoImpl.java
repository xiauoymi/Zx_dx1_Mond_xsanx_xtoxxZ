package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.MaterialPackage;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 10:11:00 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class MaterialPackageDaoImpl extends HibernateDao<MaterialPackage, Long> implements MaterialPackageDao {

    private static final Logger LOG = Logger.getLogger(MaterialPackageDaoImpl.class);

    public Collection<MaterialPackage> findByPlantSeason(int idPlantSeason) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("hybrid", "hybrid")
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("plantSeason.id", new Long(idPlantSeason)));

        Collection<MaterialPackage> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<MaterialPackage> findByHybrid(int idHybrid) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("hybrid", "hybrid")
                .add(Restrictions.eq("hybrid.id", new Long(idHybrid)));

        Collection<MaterialPackage> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
