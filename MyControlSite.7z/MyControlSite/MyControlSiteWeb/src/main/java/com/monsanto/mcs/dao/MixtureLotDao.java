package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.MixtureLot;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface MixtureLotDao extends GenericDao<MixtureLot, Long> {

    Collection<MixtureLot> findByBagging(long baggingId) throws Exception;
    
}
