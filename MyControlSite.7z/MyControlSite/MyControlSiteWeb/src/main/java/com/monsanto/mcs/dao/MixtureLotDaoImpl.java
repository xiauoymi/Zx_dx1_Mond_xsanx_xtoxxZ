package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.MixtureLot;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class MixtureLotDaoImpl extends HibernateDao<MixtureLot, Long> implements MixtureLotDao {

    public Collection<MixtureLot> findByBagging(long baggingId) throws Exception {
        Collection<MixtureLot> results = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("bagging.id", baggingId));
        results = criteria.list();
        if (results == null || results.size() == 0) {
            results = null;
        }
        return results;
    }


}

