package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Module;
import org.springframework.stereotype.Repository;


@Repository
public class ModuleDaoImpl extends HibernateDao<Module, Long> implements ModuleDao {

}

