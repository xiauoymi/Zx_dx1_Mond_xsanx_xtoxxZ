package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Origin;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 04:22:43 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface OriginDao extends GenericDao<Origin, Long>{

    public Origin lookupByCriteria(Origin example) throws Exception;

    public Collection<Origin> findByName(String name) throws Exception;


}
