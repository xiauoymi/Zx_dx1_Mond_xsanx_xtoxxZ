package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Origin;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 04:25:19 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class OriginDaoImpl extends HibernateDao<Origin, Long> implements OriginDao {

    private static final Logger LOG = Logger.getLogger(OriginDaoImpl.class);

    public Origin lookupByCriteria(Origin example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("strOrigin", example.getStrOrigin()));
        Collection<Origin> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No plant found with name: " + example.getStrOrigin());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Origin> findByName(String strOrigin) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("strOrigin", "%" + strOrigin + "%"));

        Collection<Origin> matchingEntry = criteria.list();
        return matchingEntry;
    }


}
