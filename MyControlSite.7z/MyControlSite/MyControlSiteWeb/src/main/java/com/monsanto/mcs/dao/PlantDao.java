package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Plant;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 7/12/2010
 * Time: 09:38:17 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface PlantDao extends GenericDao<Plant, Long> {
    public Plant lookupByCriteria(Plant example) throws Exception;

    public Collection<Plant> findByName(String name) throws Exception;
}
