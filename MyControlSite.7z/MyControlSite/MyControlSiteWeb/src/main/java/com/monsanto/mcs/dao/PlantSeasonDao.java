package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.PlantSeason;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 8/02/2011
 * Time: 06:00:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface PlantSeasonDao extends GenericDao<PlantSeason, Long>{
    public PlantSeason lookupByCriteria(PlantSeason example) throws Exception;

    public Collection<PlantSeason> findByName(String name) throws Exception;
    public Collection<PlantSeason> findByPlant(int idPlant) throws Exception;
    public Collection<PlantSeason> findByPlantSeason(int idPlant,int idSeason) throws Exception;
}
