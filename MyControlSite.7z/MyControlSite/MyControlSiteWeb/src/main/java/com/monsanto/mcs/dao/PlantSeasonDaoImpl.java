package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.PlantSeason;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 8/02/2011
 * Time: 06:01:05 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class PlantSeasonDaoImpl extends HibernateDao<PlantSeason, Long> implements PlantSeasonDao {
    private static final Logger LOG = Logger.getLogger(PlantSeasonDaoImpl.class);

    public PlantSeason lookupByCriteria(PlantSeason example) throws Exception {
        Criteria criteria = createCriteria();
        Collection<PlantSeason> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No plant-season found with name: " + example.getPlant().getName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<PlantSeason> findByName(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("season", "season")
                .add(Restrictions.like("seasonName", name + "%"));
        Collection<PlantSeason> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No plant-season found with name: " + name);
        }
        return matchingEntry;
    }

    public Collection<PlantSeason> findByPlant(int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant.id", new Long(idPlant)));
        Collection<PlantSeason> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No plant-season found with plant: " + idPlant);
        }
        return matchingEntry;
    }

    public Collection<PlantSeason> findByPlantSeason(int idPlant, int idSeason) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant.id", new Long(idPlant)));
        criteria.add(Restrictions.eq("season.id", new Long(idSeason)));
        Collection<PlantSeason> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No plant-season found with plant: " + idPlant);
        }
        return matchingEntry;
    }

}
