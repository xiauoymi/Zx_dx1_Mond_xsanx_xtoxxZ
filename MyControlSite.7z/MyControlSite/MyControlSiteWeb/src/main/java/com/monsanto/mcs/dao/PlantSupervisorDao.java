package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.PlantSupervisor;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 01:11:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface PlantSupervisorDao extends GenericDao<PlantSupervisor, Long>{

    public Collection<PlantSupervisor> findByPlant(int idPlant, String firstName) throws Exception;    

}
