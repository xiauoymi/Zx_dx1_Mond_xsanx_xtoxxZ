package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.PlantSupervisor;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 01:13:35 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class PlantSupervisorDaoImpl extends HibernateDao<PlantSupervisor, Long> implements PlantSupervisorDao {

    private static final Logger LOG = Logger.getLogger(PlantSupervisorDaoImpl.class);

    public Collection<PlantSupervisor> findByPlant(int idPlant, String firstName) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("plant", "plant")
                .add(Restrictions.eq("plant.id", new Long(idPlant)));
        if (firstName != null && !firstName.equals("")) {
            criteria.add(Restrictions.like("firstName", "%" + firstName + "%"));
        }
        Collection<PlantSupervisor> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
