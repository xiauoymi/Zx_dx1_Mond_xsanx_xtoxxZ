package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.PlantTreatmentNX;
import com.monsanto.mcs.model.hibernate.Schedule;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import java.util.*;

@Repository
public class PlantTreatmentDaoNXImpl extends HibernateDao<PlantTreatmentNX, Long> implements PlantTreatmentNXDao {

    @Autowired
    public void setupSessionFactory(@Qualifier("sessionFactorySQLSrvrNX")SessionFactory sessionFactory) {
        super.setSessionFactorySQL(sessionFactory);
    }

    public Double getTonsByOrder(Date date, Schedule schedule, String order) throws Exception {
        Double tons = 0D;
        try {
            Calendar startTime = new GregorianCalendar();
            startTime.setTime(date);
            startTime.set(Calendar.HOUR_OF_DAY, schedule.getInitialHour());
            startTime.set(Calendar.MINUTE, schedule.getInitialMinute());

            Calendar endTime = new GregorianCalendar();
            endTime.setTime(date);
            endTime.set(Calendar.HOUR_OF_DAY, schedule.getFinalHour());
            endTime.set(Calendar.MINUTE, schedule.getFinalMinute());

            Criteria criteria = createCriteria();
            criteria.add(Restrictions.eq("processOrder", String.valueOf(order)));
            criteria.add(Restrictions.ne("tank1TW", 0D));
            criteria.setProjection(Projections.projectionList()
                    .add(Projections.sum("weight")));
            Collection<Double> matchingEntry = (Collection<Double>) criteria.list();
            if (matchingEntry == null || matchingEntry.isEmpty()) {
                return null;
            }
            Number tmp = (matchingEntry.iterator().next());
            if (tmp == null) {
                return null;
            }
            tons = tmp.doubleValue();
        } catch (Exception e){
            e.printStackTrace();
        }
        return (tons / 1000);
    }

    public Double getSlurryReference(Date date, Schedule schedule, String order) throws Exception {
        Double slurry = 0D;
        Calendar startTime = new GregorianCalendar();
        startTime.setTime(date);
        startTime.set(Calendar.HOUR_OF_DAY, schedule.getInitialHour());
        startTime.set(Calendar.MINUTE, schedule.getInitialMinute());

        Calendar endTime = new GregorianCalendar();
        endTime.setTime(date);
        endTime.set(Calendar.HOUR_OF_DAY, schedule.getFinalHour());
        endTime.set(Calendar.MINUTE, schedule.getFinalMinute());

        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("processOrder", String.valueOf(order)));
        criteria.add(Restrictions.ne("tank1TW", 0D));
        criteria.setProjection(Projections.projectionList()
                .add(Projections.sum("tank1TW")));
        Collection<Double> matchingEntry = (Collection<Double>) criteria.list();
        if (matchingEntry == null || matchingEntry.isEmpty()) {
            return null;
        }
        Number tmp = (matchingEntry.iterator().next());
        if (tmp == null) {
            return null;
        }
        slurry = tmp.doubleValue();
        return (slurry);
    }

    public Double getPonchoReference(Date date, Schedule schedule, String order) throws Exception {
        Double slurry = 0D;
        Calendar startTime = new GregorianCalendar();
        startTime.setTime(date);
        startTime.set(Calendar.HOUR_OF_DAY, schedule.getInitialHour());
        startTime.set(Calendar.MINUTE, schedule.getInitialMinute());

        Calendar endTime = new GregorianCalendar();
        endTime.setTime(date);
        endTime.set(Calendar.HOUR_OF_DAY, schedule.getFinalHour());
        endTime.set(Calendar.MINUTE, schedule.getFinalMinute());

        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("processOrder", String.valueOf(order)));
        criteria.add(Restrictions.ne("tank1TW", 0D));
        criteria.setProjection(Projections.projectionList()
                .add(Projections.sum("tank2TW")));
        Collection<Double> matchingEntry = (Collection<Double>) criteria.list();
        if (matchingEntry == null || matchingEntry.isEmpty()) {
            return null;
        }
        Number tmp = (matchingEntry.iterator().next());
        if (tmp == null) {
            return null;
        }
        slurry = tmp.doubleValue();
        return (slurry);
    }

    public Double getPreciseReference(Date date, Schedule schedule, String order) throws Exception {
        Double slurry = 0D;
        Calendar startTime = new GregorianCalendar();
        startTime.setTime(date);
        startTime.set(Calendar.HOUR_OF_DAY, schedule.getInitialHour());
        startTime.set(Calendar.MINUTE, schedule.getInitialMinute());

        Calendar endTime = new GregorianCalendar();
        endTime.setTime(date);
        endTime.set(Calendar.HOUR_OF_DAY, schedule.getFinalHour());
        endTime.set(Calendar.MINUTE, schedule.getFinalMinute());

        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("processOrder", String.valueOf(order)));
        criteria.add(Restrictions.ne("tank1TW", 0D));
        criteria.setProjection(Projections.projectionList()
                .add(Projections.sum("tank3TW")));
        Collection<Double> matchingEntry = (Collection<Double>) criteria.list();
        if (matchingEntry == null || matchingEntry.isEmpty()) {
            return null;
        }
        Number tmp = (matchingEntry.iterator().next());
        if (tmp == null) {
            return null;
        }
        slurry = tmp.doubleValue();
        return (slurry);
    }


    public Double getLtsTons(Date date, Schedule schedule, String order) throws Exception {
        Double slurry = 0D;
        Calendar startTime = new GregorianCalendar();
        startTime.setTime(date);
        startTime.set(Calendar.HOUR_OF_DAY, schedule.getInitialHour());
        startTime.set(Calendar.MINUTE, schedule.getInitialMinute());

        Calendar endTime = new GregorianCalendar();
        endTime.setTime(date);
        endTime.set(Calendar.HOUR_OF_DAY, schedule.getFinalHour());
        endTime.set(Calendar.MINUTE, schedule.getFinalMinute());

        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("processOrder", String.valueOf(order)));
        criteria.add(Restrictions.ne("tank1TW", 0D));
        criteria.setProjection(Projections.projectionList()
                .add(Projections.sum("tank1TW")));
        Collection<Double> matchingEntry = (Collection<Double>) criteria.list();
        if (matchingEntry == null || matchingEntry.isEmpty()) {
            return null;
        }
        Number tmp = (matchingEntry.iterator().next());
        if (tmp == null) {
            return null;
        }
        slurry = tmp.doubleValue();
        return (slurry / 1000);
    }

    public Collection<PlantTreatmentNX> findByDateShiftOrder(Date date, Schedule schedule, String order) throws Exception {
        Calendar startTime = new GregorianCalendar();
        startTime.setTime(date);
        startTime.set(Calendar.HOUR_OF_DAY, schedule.getInitialHour());
        startTime.set(Calendar.MINUTE, schedule.getInitialMinute());

        Calendar endTime = new GregorianCalendar();
        endTime.setTime(date);
        endTime.set(Calendar.HOUR_OF_DAY, schedule.getFinalHour());
        endTime.set(Calendar.MINUTE, schedule.getFinalMinute());

        if (schedule.getInitialHour() > schedule.getFinalHour()) {
            endTime.add(Calendar.DATE, 1);
        }

        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("processOrder", String.valueOf(order)));
        Collection<PlantTreatmentNX> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            return null;
        }
        return matchingEntry;
    }

}
