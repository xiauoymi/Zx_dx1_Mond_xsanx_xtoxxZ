package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.PlantTreatment;
import com.monsanto.mcs.model.hibernate.PlantTreatmentVI;
import com.monsanto.mcs.model.hibernate.Schedule;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Date;

@Transactional
public interface PlantTreatmentVIDao extends GenericDao<PlantTreatmentVI, Long>{

    Double getTonsByOrder(Date date,Schedule schedule, String order) throws Exception;

    Double getSlurryReference(Date date,Schedule schedule, String order) throws Exception;

    Double getPonchoReference(Date date,Schedule schedule, String order) throws Exception;

    Double getPreciseReference(Date date,Schedule schedule, String order) throws Exception;

    Collection<PlantTreatmentVI> findByDateShiftOrder(Date date,Schedule schedule, String order) throws Exception;

}
