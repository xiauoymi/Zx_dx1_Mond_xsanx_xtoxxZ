package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.PlantabilityTest;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface PlantabilityTestDao extends GenericDao<PlantabilityTest, Long> {
    
}
