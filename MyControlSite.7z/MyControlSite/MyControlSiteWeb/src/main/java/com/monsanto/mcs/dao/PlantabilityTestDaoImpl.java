package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.PlantabilityTest;
import org.springframework.stereotype.Repository;

@Repository
public class PlantabilityTestDaoImpl extends HibernateDao<PlantabilityTest, Long> implements PlantabilityTestDao {

}

