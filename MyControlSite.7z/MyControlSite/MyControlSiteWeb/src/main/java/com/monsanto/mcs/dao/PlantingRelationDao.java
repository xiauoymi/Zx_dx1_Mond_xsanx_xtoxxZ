package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.PlantingRelation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 01:00:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface PlantingRelationDao extends GenericDao<PlantingRelation, Long> {
    public PlantingRelation lookupByCriteria(PlantingRelation example) throws Exception;
    public Collection<PlantingRelation> findByName(String name, int idPlant) throws Exception;
}
