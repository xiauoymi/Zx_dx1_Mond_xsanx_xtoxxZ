package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.PlantingRelation;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 04:17:40 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class PlantingRelationDaoImpl extends HibernateDao<PlantingRelation, Long> implements PlantingRelationDao {

    private static final Logger LOG = Logger.getLogger(PlantingRelationDaoImpl.class);

    public PlantingRelation lookupByCriteria(PlantingRelation example) throws Exception {
        Criteria criteria = createCriteria();
        Collection<PlantingRelation> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No PlantingRelation found");
        }
        return matchingEntry.iterator().next();
    }

    public Collection<PlantingRelation> findByName(String name, int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        Collection<PlantingRelation> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No PlantingRelation found");
        }
        return matchingEntry;
    }


}
