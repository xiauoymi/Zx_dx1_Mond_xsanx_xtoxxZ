package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Plate;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface PlateDao extends GenericDao<Plate, Long> {
    public Plate lookupByCriteria(Plate example) throws Exception;

    public Collection<Plate> findByName(String code) throws Exception;
}
