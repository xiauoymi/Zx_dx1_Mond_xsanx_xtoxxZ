package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Plate;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 7/12/2010
 * Time: 09:38:56 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class PlateDaoImpl extends HibernateDao<Plate, Long> implements PlateDao {

    private static final Logger LOG = Logger.getLogger(PlateDaoImpl.class);

    public Plate lookupByCriteria(Plate example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getCode()));
        Collection<Plate> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Plate found with name: " + example.getCode());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Plate> findByName(String code) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("code", "%" + code + "%"));

        Collection<Plate> matchingEntry = criteria.list();
        return matchingEntry;
    }

}