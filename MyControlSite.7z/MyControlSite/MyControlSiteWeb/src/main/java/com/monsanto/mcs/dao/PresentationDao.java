package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Presentation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 04:48:26 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface PresentationDao extends GenericDao<Presentation, Long>{

    public Presentation lookupByCriteria(Presentation example) throws Exception;

    public Collection<Presentation> findByName(String code) throws Exception;    

}
