package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Presentation;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 04:50:53 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class PresentationDaoImpl extends HibernateDao<Presentation, Long> implements PresentationDao {


    private static final Logger LOG = Logger.getLogger(PresentationDaoImpl.class);

    public Presentation lookupByCriteria(Presentation example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("strValue", example.getStrValue()));
        Collection<Presentation> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Presentation found with name: " + example.getStrValue());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Presentation> findByName(String strValue) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("strValue", "%" + strValue + "%"));

        Collection<Presentation> matchingEntry = criteria.list();
        return matchingEntry;
    }


}
