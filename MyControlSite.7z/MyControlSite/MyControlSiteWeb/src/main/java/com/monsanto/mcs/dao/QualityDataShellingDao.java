package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.DryingShelling;
import com.monsanto.mcs.model.hibernate.QualityDataShelling;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Date;

@Transactional
public interface QualityDataShellingDao extends GenericDao<QualityDataShelling, Long> {

    Collection<QualityDataShelling> findByDateCellHybrid(int plantId, Date initialDate,Date finalDate, int cell, int hybridId) throws Exception;

    Collection<QualityDataShelling> findByDryingShelling(DryingShelling dryingShelling) throws Exception;

    Collection<QualityDataShelling> findByPlantSeasonDateCellHybrid(int plantSeasonId, Date initialDate,Date finalDate, int cell, int hybridId) throws Exception;
    
}
