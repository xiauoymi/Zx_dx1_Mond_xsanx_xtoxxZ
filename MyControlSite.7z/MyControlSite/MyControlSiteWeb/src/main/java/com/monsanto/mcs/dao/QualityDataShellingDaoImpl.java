package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.DryingShelling;
import com.monsanto.mcs.model.hibernate.QualityDataShelling;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.Date;

@Repository
public class QualityDataShellingDaoImpl extends HibernateDao<QualityDataShelling, Long> implements QualityDataShellingDao {

    public Collection<QualityDataShelling> findByDateCellHybrid(int plantId, Date initialDate, Date finalDate, int cell, int hybridId) throws Exception {
        Criteria criteria = createCriteria();
        if (plantId == 0 && initialDate == null && finalDate == null && cell == 0 && hybridId == 0) {
            criteria = createCriteria(false);
        }
        criteria.createCriteria("dryingShelling", "dryingShelling");
        if (initialDate != null) {
            criteria.add(Restrictions.ge("dryingShelling.shellingStartDate", initialDate));
        }
        if (finalDate != null) {
            criteria.add(Restrictions.le("dryingShelling.shellingEndDate", finalDate));
        }
        if (cell != 0) {
            criteria.createCriteria("dryingShelling.dryingCellReport", "dryingShelling.dryingCellReport")
                    .createCriteria("plant", "plant")
                    .add(Restrictions.eq("plant.id", (long) plantId));
            criteria.createCriteria("dryingShelling.dryingCellReport.closingCellLog", "dryingShelling.dryingCellReport.closingCellLog")
                    .add(Restrictions.eq("cell", cell));
        } else {
            criteria.createCriteria("dryingShelling.dryingCellReport", "dryingShelling.dryingCellReport")
                    .createCriteria("plant", "plant")
                    .add(Restrictions.eq("plant.id", (long) plantId));
        }
        if (hybridId != 0) {
            criteria.createCriteria("dryingShelling.shellingOrder", "dryingShelling.shellingOrder")
                    .createCriteria("hybrid", "hybrid")
                    .add(Restrictions.eq("hybrid.id", (long) hybridId));
        }
        Collection<QualityDataShelling> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<QualityDataShelling> findByPlantSeasonDateCellHybrid(int plantSeasonId, Date initialDate, Date finalDate, int cell, int hybridId) throws Exception {
        Criteria criteria = createCriteria();
        if (plantSeasonId == 0 && initialDate == null && finalDate == null && cell == 0 && hybridId == 0) {
            criteria = createCriteria(false);
        }
        criteria.createCriteria("dryingShelling", "dryingShelling");
        if (initialDate != null) {
            criteria.add(Restrictions.ge("dryingShelling.shellingStartDate", initialDate));
        }
        if (finalDate != null) {
            criteria.add(Restrictions.le("dryingShelling.shellingEndDate", finalDate));
        }
        if (cell != 0) {
//            criteria.createCriteria("dryingShelling.dryingCellReport.closingCellLog","dryingShelling.dryingCellReport.closingCellLog")
//                    .add(Restrictions.eq("cell",cell));
            criteria.createCriteria("dryingShelling.dryingCellReport", "dryingShelling.dryingCellReport")
                    .createCriteria("closingCellLog", "closingCellLog")
                    .add(Restrictions.eq("closingCellLog.plantSeasonId", (long) plantSeasonId))
                    .add(Restrictions.eq("closingCellLog.cell", cell));
        } else {
            criteria.createCriteria("dryingShelling.dryingCellReport", "dryingShelling.dryingCellReport")
                    .createCriteria("closingCellLog", "closingCellLog")
                    .add(Restrictions.eq("closingCellLog.plantSeasonId", (long) plantSeasonId));
        }
        if (hybridId != 0) {
            criteria.createCriteria("dryingShelling.shellingOrder", "dryingShelling.shellingOrder")
                    .createCriteria("hybrid", "hybrid")
                    .add(Restrictions.eq("hybrid.id", (long) hybridId));
        }
        Collection<QualityDataShelling> matchingEntry = criteria.list();
        for (QualityDataShelling entry : matchingEntry) {
            if (entry == null || entry.getId() == 0) {
                matchingEntry.remove(entry);
            }
        }
        return matchingEntry;
    }

    public Collection<QualityDataShelling> findByDryingShelling(DryingShelling dryingShelling) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("dryingShelling", "dryingShelling");
        criteria.add(Restrictions.eq("dryingShelling.id", dryingShelling.getId()));
        Collection<QualityDataShelling> matchingEntry = criteria.list();
        return matchingEntry;
    }

}

