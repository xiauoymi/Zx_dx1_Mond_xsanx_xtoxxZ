package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.QualityGrowerPayment;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 18/05/2011
 * Time: 02:39:21 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface QualityGrowerPaymentDao extends GenericDao<QualityGrowerPayment, Long>{
    
    public QualityGrowerPayment lookupByCriteria(QualityGrowerPayment example) throws Exception;

    public Collection<QualityGrowerPayment> findAllByLot(int plantTo, int seasonId, Long lot) throws Exception;

    public QualityGrowerPayment findBySendFormat(String folio) throws Exception;

    public Collection<QualityGrowerPayment> findAllByLot(int seasonId, Long lot) throws Exception;

}
