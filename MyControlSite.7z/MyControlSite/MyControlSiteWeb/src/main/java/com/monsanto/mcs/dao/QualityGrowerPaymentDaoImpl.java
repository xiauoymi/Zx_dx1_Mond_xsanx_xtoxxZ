package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.QualityGrowerPayment;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 18/05/2011
 * Time: 02:41:04 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class QualityGrowerPaymentDaoImpl extends HibernateDao<QualityGrowerPayment, Long> implements QualityGrowerPaymentDao {

    private static final Logger LOG = Logger.getLogger(QualityGrowerPaymentDaoImpl.class);

    public QualityGrowerPayment lookupByCriteria(QualityGrowerPayment example) throws Exception {
        Criteria criteria = createCriteria();
        Collection<QualityGrowerPayment> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No QualityGrowerPayment found");
        }
        return matchingEntry.iterator().next();
    }

    public Collection<QualityGrowerPayment> findAllByLot(int plantTo, int seasonId, Long lot) throws Exception {
        Criteria criteria = createCriteria();

        if (lot == 0L) {
            criteria.createCriteria("scale", "scale")
                    .createCriteria("sendFormat", "sendFormat")
                    .add(Restrictions.eq("sendFormat.plantTo.id", new Long(plantTo)))
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("plantSeason.season.id", new Long(seasonId)));
        } else {
            criteria.createCriteria("scale", "scale")
                    .createCriteria("sendFormat", "sendFormat")
                    .add(Restrictions.eq("sendFormat.plantTo.id", new Long(plantTo)))
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .add(Restrictions.eq("lot", lot))
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("plantSeason.season.id", new Long(seasonId)));
        }
        criteria.addOrder(Order.desc("id"));
        Collection<QualityGrowerPayment> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public QualityGrowerPayment findBySendFormat(String folio) throws Exception {
        QualityGrowerPayment feedback = null;
        Criteria criteria = createCriteria();

        criteria.createCriteria("scale", "scale")
                .createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("sendFormatFolio", folio));

        Collection<QualityGrowerPayment> matchingEntry = criteria.list();

        if (matchingEntry != null && matchingEntry.size() > 0) {
            feedback = matchingEntry.iterator().next();
        }
        return feedback;
    }

    ;

    public Collection<QualityGrowerPayment> findAllByLot(int seasonId, Long lot) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("scale", "scale")
                .createCriteria("sendFormat", "sendFormat")
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .add(Restrictions.eq("lot", new Long(lot)))
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("plantSeason.season.id", new Long(seasonId)));
        criteria.addOrder(Order.desc("id"));
        Collection<QualityGrowerPayment> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
