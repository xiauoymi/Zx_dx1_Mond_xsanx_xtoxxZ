package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Quarantine;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 11:29:46 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface QuarantineDao extends GenericDao<Quarantine, Long> {

    public Quarantine lookupByCriteria(Quarantine example);

    public Collection<Quarantine> findByType(String type, int plantId);
}
