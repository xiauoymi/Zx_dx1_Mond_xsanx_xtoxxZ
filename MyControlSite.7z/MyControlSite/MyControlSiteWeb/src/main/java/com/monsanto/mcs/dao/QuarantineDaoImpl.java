package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Quarantine;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 11:31:01 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class QuarantineDaoImpl extends HibernateDao<Quarantine, Long> implements QuarantineDao {

    private static final Logger LOG = Logger.getLogger(QuarantineDaoImpl.class);

    public Quarantine lookupByCriteria(Quarantine example) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("type", example.getType()));
        Collection<Quarantine> matchingEntry = criteria.list();
        return matchingEntry.iterator().next();
    }

    public Collection<Quarantine> findByType(String type, int plantId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("plantId", new Long(plantId)));
        criteria.add(Restrictions.like("type", "%" + type + "%"));
        Collection<Quarantine> matchingEntry = criteria.list();
        return matchingEntry;
    }
}
