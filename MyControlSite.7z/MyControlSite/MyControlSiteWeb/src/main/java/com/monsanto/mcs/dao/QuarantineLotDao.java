package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.FloweringData;
import com.monsanto.mcs.model.hibernate.QuarantineLot;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:55:56 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface QuarantineLotDao extends GenericDao<QuarantineLot, Long> {

    Collection<QuarantineLot> findByBatch(int batchId);
    QuarantineLot findByFieldStage(int fieldStageId);
    Collection <QuarantineLot> findAllQuarantineByFieldStage(int fieldStageId);    
    Collection <QuarantineLot> findAllByFieldStage(int fieldStageId);
    QuarantineLot findByFieldStageAndCondition(int fieldStageId,int conditionId);


}