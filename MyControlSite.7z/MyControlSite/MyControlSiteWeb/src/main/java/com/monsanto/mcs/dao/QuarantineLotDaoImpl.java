package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.QuarantineLot;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 10:57:22 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class QuarantineLotDaoImpl extends HibernateDao<QuarantineLot, Long> implements QuarantineLotDao {

    private static final Logger LOG = Logger.getLogger(QuarantineLotDaoImpl.class);

    public Collection<QuarantineLot> findByBatch(int batchId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("batchId", new Long(batchId)));
        criteria.addOrder(Order.asc("number"));
        Collection<QuarantineLot> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public QuarantineLot findByFieldStage(int fieldStageId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("fieldStage.id", new Long(fieldStageId)));
        criteria.addOrder(Order.asc("number"));
        Collection<QuarantineLot> matchingEntry = criteria.list();
        if (matchingEntry != null && matchingEntry.size() > 0) {
            return matchingEntry.iterator().next();
        }
        return null;
    }

    public QuarantineLot findByFieldStageAndCondition(int fieldStageId, int conditionId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("fieldStage.id", new Long(fieldStageId)));
        if (conditionId != 0) {
            criteria.createCriteria("condition", "condition")
                    .add(Restrictions.eq("condition.id", new Long(conditionId)));
        }
        criteria.addOrder(Order.asc("number"));
        Collection<QuarantineLot> matchingEntry = criteria.list();
        if (matchingEntry != null && matchingEntry.size() > 0) {
            return matchingEntry.iterator().next();
        }
        return null;
    }

    public Collection<QuarantineLot> findAllQuarantineByFieldStage(int fieldStageId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("fieldStage.id", new Long(fieldStageId)));
        criteria.addOrder(Order.asc("number"));
        Collection<QuarantineLot> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<QuarantineLot> findAllByFieldStage(int fieldStageId) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("fieldStage.id", new Long(fieldStageId)));
        criteria.addOrder(Order.asc("number"));
        Collection<QuarantineLot> matchingEntry = criteria.list();
        return matchingEntry;
    }

}
