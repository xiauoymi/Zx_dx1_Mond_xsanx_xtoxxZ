/*
 * QuarantineStatus
 *
 * My Control Site (MCS) 1.0
 *
 * Date: 02/11/2011
 *
 * Monsanto
 */
package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.QuarantineStatus;
import com.monsanto.mcs.model.hibernate.Seed;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Quarantine Status DAO
 *
 * @version 1.0
 * @author  Monsanto
 */
@Transactional
public interface QuarantineStatusDao extends GenericDao<QuarantineStatus,Long>{

    public QuarantineStatus lookupByCriteria(QuarantineStatus quarantineStatus) throws Exception;

    public Collection<QuarantineStatus> findByName(String name) throws Exception;

}
