package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.QuarantineStatus;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;


@Repository
public class QuarantineStatusDaoImpl extends HibernateDao<QuarantineStatus, Long> implements QuarantineStatusDao {

    public QuarantineStatus lookupByCriteria(QuarantineStatus quarantineStatus) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", quarantineStatus.getName()));
        Collection<QuarantineStatus> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Quarantine Status found with name: " + quarantineStatus.getName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<QuarantineStatus> findByName(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        Collection<QuarantineStatus> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Quarantine Status found with name: " + name);
        }
        return matchingEntry;
    }
}
