package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ReceiveLabel;
import com.monsanto.mcs.model.hibernate.SendFormat;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface ReceiveLabelDao extends GenericDao<ReceiveLabel,Long> {

    public ReceiveLabel findBySendFormat(String sendFormatFolio) throws Exception;

    public Collection<ReceiveLabel> findAll(int plantId) throws Exception;

    public Collection<ReceiveLabel> findAllByLot(int season, long lot) throws Exception;

    public Collection<ReceiveLabel> findByDestinationPlantAndSeason(long destinationPlantId, long seasonId) throws Exception;

}