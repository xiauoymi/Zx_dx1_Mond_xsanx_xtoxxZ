package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ReceiveLabel;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class ReceiveLabelDaoImpl extends HibernateDao<ReceiveLabel, Long> implements ReceiveLabelDao {

    private static final Logger LOG = Logger.getLogger(ReceiveLabelDaoImpl.class);

    public ReceiveLabel findBySendFormat(String sendFormatFolio) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("sendFormat.sendFormatFolio", sendFormatFolio));
        Collection<ReceiveLabel> matchingEntry = criteria.list();
        if (matchingEntry == null || matchingEntry.isEmpty()) {
            //throw new Exception("No Receive Label found referencing SF Folio: " + sendFormatFolio);
            return null;
        }
        return matchingEntry.iterator().next();
    }

    public Collection<ReceiveLabel> findAll(int plantId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant", (long) plantId));
        Collection<ReceiveLabel> results = criteria.list();
        if (results == null || results.isEmpty()) {
            return null;
        }
        return results;
    }

    public Collection<ReceiveLabel> findAllByLot(int season, long lot) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .add(Restrictions.eq("lot", lot))
                .createCriteria("plantSeason", "plantSeason")
                .createCriteria("season", "season")
                .add(Restrictions.eq("id", new Long(season)));

        Collection<ReceiveLabel> results = criteria.list();
        if (results == null || results.isEmpty()) {
            return null;
        }
        return results;
    }

    public Collection<ReceiveLabel> findByDestinationPlantAndSeason(long destinationPlant, long seasonId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("plantTo.id", destinationPlant))
                .createCriteria("fieldBatchRecord.plantSeason", "fieldBatchRecord.plantSeason")
                .add(Restrictions.eq("season.id", seasonId));
        Collection<ReceiveLabel> results = criteria.list();
        if (results == null || results.isEmpty()) {
            return null;
        }
        return results;
    }

}

