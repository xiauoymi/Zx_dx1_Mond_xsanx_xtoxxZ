package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ReleaseByLotHybrid;
import org.springframework.transaction.annotation.Transactional;
import java.util.Collection;

@Transactional(readOnly = true)
public interface ReleaseByLotHybridDao extends GenericDao<ReleaseByLotHybrid, Long>{

    Collection<ReleaseByLotHybrid> findByPlantSeason(int idPlant, int idSeason) throws Exception;

}
