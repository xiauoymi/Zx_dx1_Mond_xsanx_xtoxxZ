package com.monsanto.mcs.dao;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.ImmutableList;
import com.monsanto.mcs.model.hibernate.ReleaseByLotHybrid;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class ReleaseByLotHybridDaoImpl extends HibernateDao<ReleaseByLotHybrid, Long> implements ReleaseByLotHybridDao {

    public Collection<ReleaseByLotHybrid> findByPlantSeason(int plantId, int seasonId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant", plantId));
        return Collections2.filter(ImmutableList.copyOf(criteria.list()), bySeason(seasonId));
    }

    private Predicate<ReleaseByLotHybrid> bySeason(final int seasonId) {
        return new Predicate<ReleaseByLotHybrid>() {
            public boolean apply(ReleaseByLotHybrid releaseByLotHybrid) {
                return releaseByLotHybrid.getSeason() == seasonId;
            }
        };
    }
}
