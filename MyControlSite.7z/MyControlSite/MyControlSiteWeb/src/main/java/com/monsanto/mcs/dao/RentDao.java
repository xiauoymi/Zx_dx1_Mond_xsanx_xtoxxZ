package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Rent;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 16/03/2011
 * Time: 09:44:41 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface RentDao extends GenericDao<Rent, Long> {
    public Rent lookupByCriteria(Rent example) throws Exception;
    public Collection<Rent> findByName(String name) throws Exception;

}