package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Rent;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 16/03/2011
 * Time: 09:45:40 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class RentDaoImpl extends HibernateDao<Rent, Long> implements RentDao {

    private static final Logger LOG = Logger.getLogger(SeasonDaoImpl.class);

    public Rent lookupByCriteria(Rent example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getName()));
        Collection<Rent> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No season found with name: " + example.getName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Rent> findByName(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        criteria.addOrder(Order.asc("id"));
        Collection<Rent> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No season found with name: " + name);
        }
        return matchingEntry;
    }

}
