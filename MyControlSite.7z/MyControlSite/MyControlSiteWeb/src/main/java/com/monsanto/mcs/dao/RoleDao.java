package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Role;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/03/2011
 * Time: 10:19:32 AM
 * To change this template use File | Settings | File Templates.
 */

@Transactional
public interface RoleDao extends GenericDao<Role, Long> {

}