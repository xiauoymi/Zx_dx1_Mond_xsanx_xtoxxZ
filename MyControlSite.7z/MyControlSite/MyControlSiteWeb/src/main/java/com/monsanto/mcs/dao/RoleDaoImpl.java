package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Role;
import org.springframework.stereotype.Repository;


@Repository
public class RoleDaoImpl extends HibernateDao<Role, Long> implements RoleDao {

}

