package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.SapBaggingOrder;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface SapBaggingOrderDao extends GenericDao<SapBaggingOrder, Long> {

    Collection<SapBaggingOrder> findAll();

    Collection<SapBaggingOrder> findAllUnfilteredSapBaggingOrders() throws Exception;

}
