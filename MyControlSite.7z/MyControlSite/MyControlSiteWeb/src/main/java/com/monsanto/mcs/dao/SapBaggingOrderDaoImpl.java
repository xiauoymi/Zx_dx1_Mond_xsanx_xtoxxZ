package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.BaggingOrder;
import com.monsanto.mcs.model.hibernate.SapBaggingOrder;
import org.hibernate.Criteria;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Subqueries;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class SapBaggingOrderDaoImpl extends HibernateDao<SapBaggingOrder, Long> implements SapBaggingOrderDao {

    public Collection<SapBaggingOrder> findAllUnfilteredSapBaggingOrders() throws Exception {
        Criteria criteria = createCriteria();
        DetachedCriteria existingBaggingLots = DetachedCriteria.forClass(BaggingOrder.class);
        existingBaggingLots.setProjection(Projections.property("baggingLot"));
        criteria.add(Subqueries.propertyNotIn("baggingLot", existingBaggingLots));
        return criteria.list();
    }

}
