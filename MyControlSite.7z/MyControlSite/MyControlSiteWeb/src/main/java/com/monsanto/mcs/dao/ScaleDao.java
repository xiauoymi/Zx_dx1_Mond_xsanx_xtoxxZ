package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.DryingCellReport;
import com.monsanto.mcs.model.hibernate.Scale;
import com.monsanto.mcs.model.hibernate.SendFormat;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface ScaleDao extends GenericDao<Scale,Long> {

    public Scale findBySendFormat(String scaleId) throws Exception;

    //public Scale findByPrimaryKey(Long scaleId);
    public Collection<Scale> findByPlant(int option, int idPlantTo, int idSeason, long lot, String folio, int cell, int transport, String billNumber) throws Exception;

    public Collection <Scale> findByPlantCell(int idPlantSeason, long lot, String folio, int cell, int transport, boolean closed, int closingCellId) throws Exception;

    public Collection <Scale> findByCell(int plantTo, int seasonId, int cell) throws Exception;

    public Collection<Scale> findByTransportSupplier(int plantTo, int seasonId, String transportSupplier) throws Exception;

    public Collection<Scale> findAllByLot(long lot) throws Exception;

    public Collection <Scale> findByClosingCellLog(long closingCellId) throws Exception;

    public Collection <Scale> findByClosingCellLog(Collection<DryingCellReport> cells,long lotId, String sendFormatFolio, int cell) throws Exception;

}