package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.DryingCellReport;
import com.monsanto.mcs.model.hibernate.Scale;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collection;

@Repository
public class ScaleDaoImpl extends HibernateDao<Scale, Long> implements ScaleDao {

    public Scale findBySendFormat(String sendFormatFolio) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.like("sendFormat.sendFormatFolio", sendFormatFolio));
        Collection<Scale> matchingEntry = criteria.list();
        if (matchingEntry == null || matchingEntry.isEmpty()) {
            return null;
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Scale> findByPlant(int option, int idPlantTo, int idSeason, long lot, String folio, int cell, int transport, String billNumber) throws Exception {
        if (lot == 0L && folio.equalsIgnoreCase("") && cell == 0L && transport == 0L && billNumber.equalsIgnoreCase("")) {
            return findAllDefault(option, idPlantTo, idSeason);
        } else if (lot != 0L) {
            return findAllByLot(option, idPlantTo, idSeason, lot);
        } else if (!folio.equalsIgnoreCase("")) {
            return findAllByFolio(idPlantTo, idSeason, folio);
        } else if (cell != 0L) {
            return findAllByCell(idPlantTo, idSeason, cell);
        } else if (transport != 0L) {
            return findAllByTransport(idPlantTo, idSeason, transport);
        } else {
            return findAllByBillNumber(idPlantTo, idSeason, billNumber);
        }
    }

    private Collection<Scale> findAllDefault(int option, int idPlantTo, int idSeason) {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("plantTo.id", new Long(idPlantTo)))
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("season.id", new Long(idSeason)));
        if (option == 0) {
            criteria.addOrder(Order.desc("id"));
        } else if (option == 1) {
            criteria.addOrder(Order.desc("billNumber"));
            criteria.addOrder(Order.desc("sendFormat.transport.folio"));
            criteria.addOrder(Order.desc("sendFormat.sendFormatFolio"));
        } else if (option == 2) {
            criteria.addOrder(Order.asc("sendFormat.sendFormatFolio"));
        }
        return criteria.list();
    }

    private Collection<Scale> findAllByLot(int option, int idPlantTo, int idSeason, long lot) {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("plantTo.id", new Long(idPlantTo)))
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .add(Restrictions.eq("lot", lot))
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("season.id", new Long(idSeason)));
        if (option == 0) {
            criteria.addOrder(Order.desc("id"));
        } else {
            criteria.addOrder(Order.desc("billNumber"));
            criteria.addOrder(Order.desc("sendFormat.transport.folio"));
        }
        return criteria.list();
    }

    private Collection<Scale> findAllByFolio(int idPlantTo, int idSeason, String folio) {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("plantTo.id", new Long(idPlantTo)))
                .add(Restrictions.eq("sendFormat.sendFormatFolio", folio))
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("season.id", new Long(idSeason)));
        return criteria.list();
    }

    private Collection<Scale> findAllByCell(int idPlantTo, int idSeason, int cell) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("cell", cell))
                .createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("plantTo.id", new Long(idPlantTo)))
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("season.id", new Long(idSeason)));
        criteria.addOrder(Order.desc("id"));
        return criteria.list();
    }

    private Collection<Scale> findAllByTransport(int idPlantTo, int idSeason, int transport) {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("plantTo.id", new Long(idPlantTo)))
                .add(Restrictions.eq("sendFormat.transport.folio", transport))
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("season.id", new Long(idSeason)));
        criteria.addOrder(Order.desc("billNumber"));
        criteria.addOrder(Order.desc("sendFormat.transport.folio"));
        criteria.addOrder(Order.desc("sendFormat.sendFormatFolio"));
        return criteria.list();
    }

    private Collection<Scale> findAllByBillNumber(int idPlantTo, int idSeason, String billNumber) {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("billNumber", billNumber))
                .createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("plantTo.id", new Long(idPlantTo)))
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("season.id", new Long(idSeason)));
        criteria.addOrder(Order.desc("billNumber"));
        criteria.addOrder(Order.desc("sendFormat.transport.folio"));
        criteria.addOrder(Order.desc("sendFormat.sendFormatFolio"));
        return criteria.list();
    }

    public Collection<Scale> findByPlantCell(int idPlantSeason, long lot, String folio, int cell, int transport, boolean closed, int closingCellId) throws Exception {
        Criteria criteria = createCriteria();
        if (lot == 0L && folio.equalsIgnoreCase("") && cell == 0L && transport == 0L) {
            criteria.createCriteria("sendFormat", "sendFormat")
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("plantSeason.id", new Long(idPlantSeason)));
        } else if (lot != 0L) {
            criteria.createCriteria("sendFormat", "sendFormat")
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .add(Restrictions.eq("lot", lot))
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("plantSeason.id", new Long(idPlantSeason)));
        } else if (!folio.equalsIgnoreCase("")) {
            criteria.createCriteria("sendFormat", "sendFormat")
                    .add(Restrictions.eq("sendFormat.sendFormatFolio", folio))
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("plantSeason.id", new Long(idPlantSeason)));
        } else if (cell != 0L) {
            criteria.add(Restrictions.eq("cell", cell))
                    .createCriteria("sendFormat", "sendFormat")
                    .createCriteria("plantTo", "plantTo")
                    .add(Restrictions.eq("plantTo.id", new Long(idPlantSeason)));
        } else if (transport != 0L) {
            criteria.createCriteria("sendFormat", "sendFormat")
                    .add(Restrictions.eq("sendFormat.transport.folio", transport))
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("plantSeason.id", new Long(idPlantSeason)));
        }
        if (closed) {
            criteria.add(Restrictions.eq("closed", (long) closingCellId));
        } else {
            criteria.add(Restrictions.eq("closed", 0L));
        }
        criteria.addOrder(Order.desc("id"));
        return criteria.list();
    }

    public Collection<Scale> findByClosingCellLog(long closingCellId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat.fieldBatchRecord", "sendFormat.fieldBatchRecord");
        criteria.add(Restrictions.eq("closed", (long) closingCellId));
        criteria.addOrder(Order.desc("id"));
        return criteria.list();
    }

    private Collection<Long> getClosingCellsCollection(Collection<DryingCellReport> cells) {
        Collection<Long> collection = null;
        if (cells != null && !cells.isEmpty()) {
            collection = new ArrayList<Long>();
            for (DryingCellReport item : cells) {
                collection.add(item.getClosingCellLog().getId());
            }
        }
        return collection;
    }

    public Collection<Scale> findByClosingCellLog(Collection<DryingCellReport> cells, long lotId, String sendFormatFolio, int cell) throws Exception {
        if (cells == null || cells.isEmpty()) {
            throw (new Exception("No Unload & Scale entries found with the criteria."));
        }
        Criteria criteria = createCriteria();
        if (lotId == 0L && sendFormatFolio.equalsIgnoreCase("") && cell == 0) {
            criteria.createCriteria("sendFormat.fieldBatchRecord", "sendFormat.fieldBatchRecord");
            criteria.add(Restrictions.in("closed", getClosingCellsCollection(cells)));
        } else if (lotId != 0L) {
            criteria.add(Restrictions.in("closed", getClosingCellsCollection(cells)));
            criteria.createCriteria("sendFormat.fieldBatchRecord", "sendFormat.fieldBatchRecord")
                    .add(Restrictions.eq("lot", new Long(lotId)));
        } else if (!sendFormatFolio.equalsIgnoreCase("")) {
            criteria.add(Restrictions.in("closed", getClosingCellsCollection(cells)));
            criteria.createCriteria("sendFormat", "sendFormat")
                    .add(Restrictions.eq("sendFormatFolio", sendFormatFolio));
        } else if (cell != 0) {
            criteria.add(Restrictions.in("closed", getClosingCellsCollection(cells)));
            criteria.add(Restrictions.eq("cell", cell));
        }
        criteria.addOrder(Order.desc("id"));
        return criteria.list();
    }

    public Collection<Scale> findByCell(int plantTo, int seasonId, int cell) throws Exception {
        Criteria criteria = createCriteria();
        if (cell != 0) {
            criteria.add(Restrictions.eq("cell", cell));
        }
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("plantTo.id", new Long(plantTo)))
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("season.id", new Long(seasonId)));
        return criteria.list();
    }

    public Collection<Scale> findByTransportSupplier(int plantTo, int seasonId, String transportSupplier) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.like("plantTo.id", new Long(plantTo)))
                .createCriteria("warantyWeight", "warantyWeight")
                .createCriteria("transportSupplier", "transportSupplier")
                .add(Restrictions.like("name", "%" + transportSupplier + "%"));
        criteria.createCriteria("sendFormat.fieldBatchRecord.plantSeason", "sendFormat.fieldBatchRecord.plantSeason")
                .add(Restrictions.eq("season.id", new Long(seasonId)));
        criteria.addOrder(Order.desc("billNumber"));
        criteria.addOrder(Order.desc("sendFormat.transport.folio"));
        return criteria.list();
    }

    public Collection<Scale> findAllByLot(long lot) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .add(Restrictions.eq("lot", new Long(lot)));
        criteria.addOrder(Order.desc("sendFormat.sendFormatFolio"));
        return criteria.list();
    }

}
