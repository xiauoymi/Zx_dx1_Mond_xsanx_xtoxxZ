package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Shift;
import org.springframework.transaction.annotation.Transactional;
import com.monsanto.mcs.model.hibernate.Schedule;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:14:30 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ScheduleDao extends GenericDao<Schedule, Long>{
    
    Schedule lookupByCriteria(Schedule example) throws Exception;

    Collection<Schedule> findByIdPlant(int idPlant) throws Exception;

    Schedule findByPlantShift(int plantId, Shift shift) throws Exception;
}
