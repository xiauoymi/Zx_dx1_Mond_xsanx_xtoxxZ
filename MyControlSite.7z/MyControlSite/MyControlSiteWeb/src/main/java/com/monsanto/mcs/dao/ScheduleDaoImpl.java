package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Schedule;
import com.monsanto.mcs.model.hibernate.Shift;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:14:47 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ScheduleDaoImpl extends HibernateDao<Schedule, Long> implements ScheduleDao {

    private static final Logger LOG = Logger.getLogger(ScheduleDaoImpl.class);

    public Schedule lookupByCriteria(Schedule example) throws Exception {
        Criteria criteria = createCriteria();
        Collection<Schedule> matchingEntry = criteria.list();
        return matchingEntry.iterator().next();
    }

    public Collection<Schedule> findByIdPlant(int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        Collection<Schedule> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Schedule findByPlantShift(int plantId, Shift shift) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", (long) plantId));
        if (shift != null) {
            criteria.createCriteria("shift", "shift")
                    .add(Restrictions.eq("shift.id", shift.getId()));
        }
        Collection<Schedule> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            return null;
        }
        return matchingEntry.iterator().next();
    }

}
