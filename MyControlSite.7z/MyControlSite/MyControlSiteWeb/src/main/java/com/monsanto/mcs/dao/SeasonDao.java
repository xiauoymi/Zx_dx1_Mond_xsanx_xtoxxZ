package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Season;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 01:01:41 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface SeasonDao extends GenericDao<Season, Long> {
    public Season lookupByCriteria(Season example) throws Exception;
    public Collection<Season> findByName(String name) throws Exception;

}
