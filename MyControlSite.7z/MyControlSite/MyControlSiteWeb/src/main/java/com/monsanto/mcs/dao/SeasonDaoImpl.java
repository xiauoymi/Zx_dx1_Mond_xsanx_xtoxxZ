package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Season;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 04:20:09 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class SeasonDaoImpl extends HibernateDao<Season, Long> implements SeasonDao {

    private static final Logger LOG = Logger.getLogger(SeasonDaoImpl.class);

    public Season lookupByCriteria(Season example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getSeasonName()));
        Collection<Season> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No season found with name: " + example.getSeasonName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Season> findByName(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("seasonName", "%" + name + "%"));
        Collection<Season> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No season found with name: " + name);
        }
        return matchingEntry;
    }

}
