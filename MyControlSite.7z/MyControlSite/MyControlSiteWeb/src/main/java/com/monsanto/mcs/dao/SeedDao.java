/*
 * SeedDao
 *
 * My Control Site (MCS) 1.0
 *
 * Date: 02/11/2011
 *
 * Monsanto
 */
package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Seed;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Seed DAO
 *
 * @version 1.0
 * @author  Monsanto
 */
@Transactional
public interface SeedDao extends GenericDao<Seed,Long>{

    /**
     * Method to LookUp using specific Criteria.
     * @param seed to be looked up.
     * @return Seed instance if found, null otherwise.
     * @throws Exception if some DataBase issue arises.
     */
    public Seed lookupByCriteria(Seed seed) throws Exception;

    /**
     * Method to LookUp by Size.
     * @param sizeCode to be looked up.
     * @return Seed collection satisfying the specified size, null otherwise.
     * @throws Exception if some DataBase issue arises.
     */
    public Collection<Seed> findBySize(String sizeCode) throws Exception;

}
