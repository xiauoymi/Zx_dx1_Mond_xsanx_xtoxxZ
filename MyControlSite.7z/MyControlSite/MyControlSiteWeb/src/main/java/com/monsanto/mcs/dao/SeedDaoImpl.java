/*
 * SeedDaoImplementation
 *
 * My Control Site (MCS) 1.0
 *
 * Date: 02/11/2011
 *
 * Monsanto
 */
package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Seed;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Seed DAO
 *
 * @author Monsanto
 * @version 1.0
 */
@Repository
public class SeedDaoImpl extends HibernateDao<Seed, Long> implements SeedDao {

    /**
     * Method to LookUp using specific Criteria.
     *
     * @param seed to be looked up.
     * @return Seed instance if found, null otherwise.
     * @throws Exception if some DataBase issue arises.
     */
    public Seed lookupByCriteria(Seed seed) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("sizeCode", seed.getSizeCode()));
        Collection<Seed> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No seed found with size: " + seed.getSizeCode());
        }
        return matchingEntry.iterator().next();
    }

    /**
     * Method to LookUp by Size.
     *
     * @param sizeCode to be looked up.
     * @return Seed collection satisfying the specified size, null otherwise.
     * @throws Exception if some DataBase issue arises.
     */
    public Collection<Seed> findBySize(String sizeCode) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("sizeCode", "%" + sizeCode + "%"));
        Collection<Seed> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No seed found with size: " + sizeCode);
        }
        return matchingEntry;
    }

}
