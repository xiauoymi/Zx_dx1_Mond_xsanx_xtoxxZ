package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ReceiveLabel;
import com.monsanto.mcs.model.hibernate.SeedLossDehusking;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface SeedLossDehuskingDao extends GenericDao<SeedLossDehusking,Long> {

    public SeedLossDehusking findBySendFormat(String sendFormatFolio) throws Exception;

    public Collection<SeedLossDehusking> findAll(int plantId) throws Exception;

    public Collection<SeedLossDehusking> findByDestinationPlantAndSeason(long destinationPlantId, long seasonId) throws Exception;

}
