package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.SeedLossDehusking;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class SeedLossDehuskingDaoImpl extends HibernateDao<SeedLossDehusking, Long> implements SeedLossDehuskingDao {

    private static final Logger LOG = Logger.getLogger(SeedLossDehuskingDaoImpl.class);

    public SeedLossDehusking findBySendFormat(String sendFormatFolio) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("sendFormat.sendFormatFolio", sendFormatFolio));
        Collection<SeedLossDehusking> matchingEntry = criteria.list();
        if (matchingEntry == null || matchingEntry.isEmpty()) {
            //throw new Exception("No Seed Loss Dehusking found referencing SF Folio: " + sendFormatFolio);
            return null;
        }
        return matchingEntry.iterator().next();
    }

    public Collection<SeedLossDehusking> findAll(int plantId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant", (long) plantId));
        Collection<SeedLossDehusking> results = criteria.list();
        if (results == null || results.isEmpty()) {
            //throw new Exception("No Seed Loss Dehusking found referencing SF Folio: " + sendFormatFolio);
            return null;
        }
        return results;
    }

    public Collection<SeedLossDehusking> findByDestinationPlantAndSeason(long destinationPlant, long seasonId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("sendFormat", "sendFormat")
                .add(Restrictions.eq("plantTo.id", destinationPlant))
                .createCriteria("fieldBatchRecord.plantSeason", "fieldBatchRecord.plantSeason")
                .add(Restrictions.eq("season.id", seasonId));
        Collection<SeedLossDehusking> results = criteria.list();
        if (results == null || results.isEmpty()) {
            return null;
        }
        return results;
    }

}
