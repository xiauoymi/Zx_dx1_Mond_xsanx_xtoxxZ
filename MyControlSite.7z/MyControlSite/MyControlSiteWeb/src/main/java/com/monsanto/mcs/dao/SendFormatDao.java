package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.SendFormat;
import com.monsanto.mcs.model.hibernate.Transport;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface SendFormatDao extends GenericDao<SendFormat,Long> {

    public SendFormat findBySendFormat(String sendFormatFolio) throws Exception;

    public Collection <SendFormat> findByPlant(long idPlantTo, long idSeason, long lot, String folio) throws Exception;

    public Collection <SendFormat> findAllByLot(long lot) throws Exception;

    public Collection findAllBySendFormatFolio(String sendFormatFolio) throws Exception;

}