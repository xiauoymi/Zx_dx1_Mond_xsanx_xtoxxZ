package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.SendFormat;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class SendFormatDaoImpl extends HibernateDao<SendFormat, Long> implements SendFormatDao {

    private static final Logger LOG = Logger.getLogger(SendFormatDaoImpl.class);

    public SendFormat findBySendFormat(String sendFormatFolio) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("sendFormatFolio", sendFormatFolio));
        Collection<SendFormat> matchingEntry = criteria.list();
        if (matchingEntry == null || matchingEntry.isEmpty()) {
            return null;
        }
        return matchingEntry.iterator().next();
    }

    public Collection findAllBySendFormatFolio(String sendFormatFolio) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("sendFormatFolio", sendFormatFolio));
        Collection<SendFormat> matchingEntry = criteria.list();
        return matchingEntry;
    }


    public Collection<SendFormat> findByPlant(long idPlantTo, long idSeason, long lot, String folio) throws Exception {
        Criteria criteria = createCriteria();
        if (lot > 0L) {
            criteria.add(Restrictions.eq("plantTo.id", idPlantTo))
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .add(Restrictions.eq("fieldBatchRecord.lot", new Long(lot)))
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("season.id", new Long(idSeason)));
        } else if (!folio.equalsIgnoreCase("")) {
            criteria.add(Restrictions.eq("plantTo.id", idPlantTo))
                    .add(Restrictions.eq("sendFormatFolio", folio))
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("season.id", new Long(idSeason)));
        } else {
            criteria.add(Restrictions.eq("plantTo.id", idPlantTo))
                    .createCriteria("fieldBatchRecord", "fieldBatchRecord")
                    .createCriteria("plantSeason", "plantSeason")
                    .add(Restrictions.eq("season.id", new Long(idSeason)));
        }
        criteria.addOrder(Order.desc("id"));
        Collection<SendFormat> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<SendFormat> findAllByLot(long lot) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("fieldBatchRecord", "fieldBatchRecord")
                .add(Restrictions.eq("fieldBatchRecord.lot", new Long(lot)));

        criteria.addOrder(Order.asc("sendFormatFolio"));
        Collection<SendFormat> matchingEntry = criteria.list();
        return matchingEntry;
    }


}

