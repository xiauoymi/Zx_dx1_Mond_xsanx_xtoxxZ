package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Server;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface ServerDao extends GenericDao<Server, Long> {
    
}
