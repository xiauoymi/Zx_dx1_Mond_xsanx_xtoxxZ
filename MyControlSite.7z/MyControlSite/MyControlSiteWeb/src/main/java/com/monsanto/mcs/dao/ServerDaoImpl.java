package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Server;
import org.springframework.stereotype.Repository;

@Repository
public class ServerDaoImpl extends HibernateDao<Server, Long> implements ServerDao {

}

