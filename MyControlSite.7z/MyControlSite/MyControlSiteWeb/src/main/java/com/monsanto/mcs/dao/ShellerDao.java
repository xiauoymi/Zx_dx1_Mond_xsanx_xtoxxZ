package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Sheller;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:43:57 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ShellerDao extends GenericDao<Sheller, Long> {
    public Sheller lookupByCriteria(int idPlant, Sheller example) throws Exception;
    public Collection<Sheller> findByNameOrderedById(int idPlant, String name) throws Exception;

}
