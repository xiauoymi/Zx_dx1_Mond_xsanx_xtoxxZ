package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.DryingShelling;
import com.monsanto.mcs.model.hibernate.ShellingOrder;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface ShellingOrderDao extends GenericDao<ShellingOrder, Long> {

    public Collection<ShellingOrder> findByHybrid(Long folio) throws Exception;

    public ShellingOrder save(ShellingOrder order) throws Exception;

    public ShellingOrder findByShellingOrder(Long shellingOrder) throws Exception;

    public Collection<ShellingOrder> findUnmappedOrders() throws Exception;

    public ShellingOrder releaseShellingOrder(ShellingOrder order) throws Exception;

    public Collection<ShellingOrder> findAssignedOrders(int plantSeasonId) throws Exception;

    public Collection<ShellingOrder> findAssignedOrdersByMixtureLot(int plantSeasonId,String mixtureLot) throws Exception;

    Collection<ShellingOrder> findAssignedOrdersByDestinationPlant(int plantId, int seasonId) throws Exception;

}
