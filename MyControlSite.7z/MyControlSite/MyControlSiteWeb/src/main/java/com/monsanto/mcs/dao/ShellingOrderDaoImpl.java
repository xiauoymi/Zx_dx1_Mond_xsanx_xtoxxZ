package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.DryingCellReport;
import com.monsanto.mcs.model.hibernate.ShellingOrder;
import org.hibernate.Criteria;
import org.hibernate.criterion.*;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class ShellingOrderDaoImpl extends HibernateDao<ShellingOrder, Long> implements ShellingOrderDao {

    public Collection<ShellingOrder> findByHybrid(Long hybrid) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("hybrid.id", new Long(hybrid)));
        Collection<ShellingOrder> results = criteria.list();
        /*
        if (results.isEmpty()) {
            throw new Exception("No Hybrid found with value: " + hybrid);
        }
        */
        return results;
    }

    public ShellingOrder save(ShellingOrder order) throws Exception {
        ShellingOrder savedOrder = saveOrUpdate(order);
        return savedOrder;
    }

    public ShellingOrder releaseShellingOrder(ShellingOrder order) throws Exception {
        order.setAverage(null);
        order.setComments(null);
        order.setDamageBroken(null);
        order.setDryingFolio(null);
        order.setHealth(null);
        order.setHybrid(null);
        order.setInertMatter(null);
        order.setInsectDamage(null);
        order.setMoistureShS1(null);
        order.setMoistureShS2(null);
        order.setMoistureShS3(null);
        order.setSeedOtherColor(null);
        order.setSheller(null);
        order.setShellingHumidity(null);
        order.setSickFade(null);
        order.setVolumetricWeigth(null);
        ShellingOrder savedOrder = saveOrUpdate(order);
        return savedOrder;
    }

    public ShellingOrder findByShellingOrder(Long shellingOrder) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("shellingOrder", shellingOrder));
        Collection<ShellingOrder> results = criteria.list();
        if (results.isEmpty()) {
            return null;
        }
        return results.iterator().next();
    }

    public Collection<ShellingOrder> findUnmappedOrders() throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.isNull("dryingFolio"));
        Collection<ShellingOrder> results = criteria.list();
        return results;
    }

    public Collection<ShellingOrder> findAssignedOrders(int plantSeasonId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.createCriteria("hybrid", "hybrid");
        criteria.createCriteria("hybrid.plantSeason", "hybrid.plantSeason");
        criteria.add(Restrictions.eq("hybrid.plantSeason.id", (long) plantSeasonId));
        criteria.add(Restrictions.isNotNull("dryingFolio"));
        criteria.setProjection(Projections.projectionList().add(Projections.distinct(Projections.property("mixtureLot"))));
        Collection<ShellingOrder> results = criteria.list();
        return results;
    }

    public Collection<ShellingOrder> findAssignedOrdersByDestinationPlant(int plantId, int seasonId) throws Exception {
        DetachedCriteria destinationPlantDryingFolios = DetachedCriteria.forClass(DryingCellReport.class);
        destinationPlantDryingFolios.add(Restrictions.eq("plant.id", (long) plantId));
        destinationPlantDryingFolios.setProjection(Projections.property("folio"));
        Criteria criteria = createCriteria();
        criteria.add(Subqueries.propertyIn("dryingFolio", destinationPlantDryingFolios));
        criteria.createCriteria("hybrid", "hybrid")
                .createCriteria("plantSeason", "plantSeason")
                .add(Restrictions.eq("season.id", (long) seasonId));
        criteria.addOrder(Order.asc("mixtureLot"));
        criteria.addOrder(Order.asc("dryingFolio"));
        return criteria.list();
    }

    public Collection<ShellingOrder> findAssignedOrdersByMixtureLot(int plantSeasonId, String mixtureLot) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("mixtureLot", mixtureLot));
        criteria.add(Restrictions.isNotNull("dryingFolio"));
        criteria.createCriteria("hybrid", "hybrid");
        criteria.createCriteria("hybrid.plantSeason", "hybrid.plantSeason");
        criteria.add(Restrictions.eq("hybrid.plantSeason.id", (long) plantSeasonId));
        criteria.setProjection(Projections.projectionList().add(Projections.distinct(Projections.property("mixtureLot"))));
        Collection<ShellingOrder> results = criteria.list();
        return results;
    }

}
