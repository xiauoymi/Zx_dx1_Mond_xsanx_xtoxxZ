package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Shift;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface ShiftDao extends GenericDao<Shift, Long> {
    public Shift lookupByCriteria(Shift example) throws Exception;

    public Collection<Shift> findByName(String name) throws Exception;
}
