package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Shift;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 7/12/2010
 * Time: 09:38:56 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ShiftDaoImpl extends HibernateDao<Shift, Long> implements ShiftDao {

    private static final Logger LOG = Logger.getLogger(ShiftDaoImpl.class);

    public Shift lookupByCriteria(Shift example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getName()));
        Collection<Shift> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Shift found with name: " + example.getName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Shift> findByName(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("name", "%" + name + "%"));

        Collection<Shift> matchingEntry = criteria.list();
        return matchingEntry;
    }

}