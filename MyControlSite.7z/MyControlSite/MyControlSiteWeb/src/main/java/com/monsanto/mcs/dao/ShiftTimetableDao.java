package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ShiftTimetable;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.Date;

@Transactional
public interface ShiftTimetableDao extends GenericDao<ShiftTimetable, Long> {

    Collection<ShiftTimetable> findByPlant(int idPlant) throws Exception;

}
