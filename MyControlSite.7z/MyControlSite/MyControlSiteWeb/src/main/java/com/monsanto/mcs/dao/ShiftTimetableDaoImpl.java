package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.ShiftTimetable;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class ShiftTimetableDaoImpl extends HibernateDao<ShiftTimetable, Long> implements ShiftTimetableDao {

    public Collection<ShiftTimetable> findByPlant(int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant.id", new Long(idPlant)));
        criteria.addOrder(Order.asc("shift.id"));
        Collection<ShiftTimetable> matchingEntry = criteria.list();
        return matchingEntry;
    }

}

