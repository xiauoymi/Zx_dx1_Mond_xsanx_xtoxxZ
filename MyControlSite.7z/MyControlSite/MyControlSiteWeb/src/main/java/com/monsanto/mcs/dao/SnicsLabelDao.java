package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.SnicsLabel;
import org.springframework.transaction.annotation.Transactional;

@Transactional
public interface SnicsLabelDao extends GenericDao<SnicsLabel, Long> {
    
}
