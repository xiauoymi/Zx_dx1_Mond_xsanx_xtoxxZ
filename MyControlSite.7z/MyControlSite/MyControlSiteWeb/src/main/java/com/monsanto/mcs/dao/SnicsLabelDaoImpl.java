package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.SnicsLabel;
import org.springframework.stereotype.Repository;

@Repository
public class SnicsLabelDaoImpl extends HibernateDao<SnicsLabel, Long> implements SnicsLabelDao {

}
