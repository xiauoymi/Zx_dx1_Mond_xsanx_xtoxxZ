package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Specialist;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 01:02:58 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface SpecialistDao extends GenericDao<Specialist, Long> {
    public Specialist lookupByCriteria(Specialist example) throws Exception;
    
    public Collection<Specialist> findByName(String name, int idPlant) throws Exception;
}
