package com.monsanto.mcs.dao;

import org.springframework.transaction.annotation.Transactional;
import com.monsanto.mcs.model.hibernate.SpecialistLocation;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:14:30 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface SpecialistLocationDao extends GenericDao<SpecialistLocation, Long>{
    
    public SpecialistLocation lookupByCriteria(SpecialistLocation example) throws Exception;

    public Collection<SpecialistLocation> findByName(String name, int idPlant) throws Exception;


}
