package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.SpecialistLocation;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:14:47 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class SpecialistLocationDaoImpl extends HibernateDao<SpecialistLocation, Long> implements SpecialistLocationDao {

    private static final Logger LOG = Logger.getLogger(SpecialistLocationDaoImpl.class);

    public SpecialistLocation lookupByCriteria(SpecialistLocation example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getLocation().getLocationName()));
        Collection<SpecialistLocation> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No SpecialistLocation found with name: " + example.getLocation().getLocationName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<SpecialistLocation> findByName(String name, int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        //criteria.add(Restrictions.like("location.locationName", "%"+name+"%"));
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        Collection<SpecialistLocation> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No specialist found with name: " + name);
        }
        return matchingEntry;
    }


}
