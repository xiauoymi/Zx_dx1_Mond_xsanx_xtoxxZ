package com.monsanto.mcs.dao;

import org.springframework.transaction.annotation.Transactional;
import com.monsanto.mcs.model.hibernate.SpecialistSupervisor;

import java.util.Collection;


/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/01/2011
 * Time: 12:45:06 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface SpecialistSupervisorDao extends GenericDao<SpecialistSupervisor, Long> {

    public SpecialistSupervisor lookupByCriteria(SpecialistSupervisor example) throws Exception;

    public Collection<SpecialistSupervisor> findByName(String name, int idPlant) throws Exception;

}
