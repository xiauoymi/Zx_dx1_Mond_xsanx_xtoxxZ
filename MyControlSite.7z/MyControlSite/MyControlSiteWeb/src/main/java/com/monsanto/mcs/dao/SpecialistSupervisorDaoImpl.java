package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.SpecialistSupervisor;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/01/2011
 * Time: 12:45:25 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class SpecialistSupervisorDaoImpl extends HibernateDao<SpecialistSupervisor, Long> implements SpecialistSupervisorDao {

    private static final Logger LOG = Logger.getLogger(SpecialistSupervisorDaoImpl.class);

    public SpecialistSupervisor lookupByCriteria(SpecialistSupervisor example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getSpecialist().getName()));
        Collection<SpecialistSupervisor> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No SpecialistLocation found with name: " + example.getSpecialist().getName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<SpecialistSupervisor> findByName(String name, int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        Collection<SpecialistSupervisor> matchingEntry = criteria.list();
        //criteria.add(Restrictions.like("SpecialistSupervisor.", "%"+name+"%"));
        if (matchingEntry.isEmpty()) {
            throw new Exception("No SpecialistSupervisor found with name: " + name);
        }
        return matchingEntry;
    }


}
