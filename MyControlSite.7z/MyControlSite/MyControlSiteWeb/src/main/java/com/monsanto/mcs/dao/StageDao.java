package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Stage;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 01:03:54 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface StageDao extends GenericDao<Stage, Long> {
    public Stage lookupByCriteria(Stage example) throws Exception;
    public Collection<Stage> findByName(String name, int idPlant) throws Exception;    
}
