package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Stage;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 04:26:45 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class StageDaoImpl extends HibernateDao<Stage, Long> implements StageDao {

    private static final Logger LOG = Logger.getLogger(StageDaoImpl.class);

    public Stage lookupByCriteria(Stage example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getStageName()));
        Collection<Stage> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No stage found with name: " + example.getStageName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Stage> findByName(String name, int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("stageName", "%" + name + "%"));
        criteria.addOrder(Order.asc("id"));
        Collection<Stage> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No stage found with name: " + name);
        }
        return matchingEntry;
    }


}
