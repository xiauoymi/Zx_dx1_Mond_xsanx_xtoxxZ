package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.StageType;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MONSANTO
 * Date: 16/02/2011
 * Time: 12:07:05 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface StageTypeDao extends GenericDao<StageType,Long>{

    /**
     * Method to LookUp using specific Criteria.
     * @param stageType to be looked up.
     * @return stageType instance if found, null otherwise.
     * @throws Exception if some DataBase issue arises.
     */
    public StageType lookupByCriteria(StageType stageType) throws Exception;

    /**
     * Method to LookUp by Name.
     * @param name to be looked up.
     * @return StageType collection satisfying the specified name, null otherwise.
     * @throws Exception if some DataBase issue arises.
     */
    public Collection<StageType> findByName(String name) throws Exception;

}
