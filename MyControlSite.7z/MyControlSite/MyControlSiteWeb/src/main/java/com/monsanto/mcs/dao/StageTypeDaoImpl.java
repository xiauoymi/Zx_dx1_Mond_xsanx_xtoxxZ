package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.StageType;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: MONSANTO
 * Date: 16/02/2011
 * Time: 12:10:48 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class StageTypeDaoImpl extends HibernateDao<StageType, Long> implements StageTypeDao {

    /**
     * Method to LookUp using specific Criteria.
     *
     * @param stageType to be looked up.
     * @return stageType instance if found, null otherwise.
     * @throws Exception if some DataBase issue arises.
     */
    public StageType lookupByCriteria(StageType stageType) throws Exception {
        Criteria criteria = createCriteria();
        if (stageType.getId() != 0) {
            criteria.add(Restrictions.eq("id", stageType.getId()));
        }
        if (stageType.getName() != null) {
            criteria.add(Restrictions.like("name", "%" + stageType.getName() + "%"));
        }
        Collection<StageType> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Stage type found with name: " + stageType.getName());
        }
        return matchingEntry.iterator().next();
    }

    /**
     * Method to LookUp by Name.
     *
     * @param name to be looked up.
     * @return StageType collection satisfying the specified name, null otherwise.
     * @throws Exception if some DataBase issue arises.
     */
    public Collection<StageType> findByName(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        Collection<StageType> results = criteria.list();
        if (results == null || results.isEmpty()) {
            throw new Exception("No Stage Type found with name: " + name);
        }
        return results;
    }

}
