package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Storage;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 7/12/2010
 * Time: 09:38:17 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface StorageDao extends GenericDao<Storage, Long> {
    public Storage lookupByCriteria(int idPlant, Storage example) throws Exception;

    public Collection<Storage> findByNameOrderedById(int idPlant, String name) throws Exception;
}
