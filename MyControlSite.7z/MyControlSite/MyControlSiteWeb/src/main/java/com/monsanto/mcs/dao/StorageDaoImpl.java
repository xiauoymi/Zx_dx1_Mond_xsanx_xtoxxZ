package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Storage;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 7/12/2010
 * Time: 09:38:56 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class StorageDaoImpl extends HibernateDao<Storage, Long> implements StorageDao {

    private static final Logger LOG = Logger.getLogger(StorageDaoImpl.class);

    public Storage lookupByCriteria(int idPlant, Storage example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.eq("name", example.getName()));
        Collection<Storage> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No storage found with name: " + example.getName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Storage> findByNameOrderedById(int idPlant, String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        criteria.addOrder(Order.asc("id"));

        Collection<Storage> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No storage found with name: " + name);
        }
        return matchingEntry;
    }

}