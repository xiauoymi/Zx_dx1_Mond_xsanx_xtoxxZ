package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Supervisor;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 01:04:57 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface SupervisorDao extends GenericDao<Supervisor, Long> {
    public Supervisor lookupByCriteria(Supervisor example) throws Exception;
    public Collection<Supervisor> findByName(String name, int idPlant) throws Exception;
}
