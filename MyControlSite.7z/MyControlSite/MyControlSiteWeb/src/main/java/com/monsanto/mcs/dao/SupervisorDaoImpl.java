package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Supervisor;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 04:28:38 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class SupervisorDaoImpl extends HibernateDao<Supervisor, Long> implements SupervisorDao {

    private static final Logger LOG = Logger.getLogger(SupervisorDaoImpl.class);

    public Supervisor lookupByCriteria(Supervisor example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getName()));
        Collection<Supervisor> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No supervisor found with name: " + example.getName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Supervisor> findByName(String name, int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        criteria.addOrder(Order.asc("name"));
        Collection<Supervisor> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No supervisor found with name: " + name);
        }
        return matchingEntry;
    }


}
