package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Thresher;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:43:57 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface ThresherDao extends GenericDao<Thresher, Long> {
    public Thresher lookupByCriteria(int idPlant, Thresher example) throws Exception;
    public Collection<Thresher> findByNameOrderedById(int idPlant, int thresherNumber) throws Exception;
   
}
