package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Thresher;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:46:07 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ThresherDaoImpl extends HibernateDao<Thresher, Long> implements ThresherDao {

    private static final Logger LOG = Logger.getLogger(ThresherDaoImpl.class);

    public Thresher lookupByCriteria(int idPlant, Thresher example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.eq("thresherNumber", example.getThresherNumber()));
        Collection<Thresher> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No thresher found with name: " + example.getThresherNumber());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Thresher> findByNameOrderedById(int idPlant, int thresherNumber) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        if (thresherNumber > 0) {
            criteria.add(Restrictions.eq("thresherNumber", thresherNumber));
        }
        criteria.addOrder(Order.asc("id"));

        Collection<Thresher> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No thresher found with name: " + thresherNumber);
        }
        return matchingEntry;
    }


}
