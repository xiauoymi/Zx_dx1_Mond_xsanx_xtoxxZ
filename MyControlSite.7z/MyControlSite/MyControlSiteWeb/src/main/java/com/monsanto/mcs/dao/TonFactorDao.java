package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.TonFactor;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 09:42:23 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface TonFactorDao extends GenericDao<TonFactor, Long> {

    public Collection<TonFactor> findByPlant(int idPlant) throws Exception;

}
