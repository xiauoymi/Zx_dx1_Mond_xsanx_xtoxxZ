package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.TonFactor;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 09:44:04 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class TonFactorDaoImpl extends HibernateDao<TonFactor, Long> implements TonFactorDao {

    private static final Logger LOG = Logger.getLogger(TonFactorDaoImpl.class);

    public Collection<TonFactor> findByPlant(int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plant.id", new Long(idPlant)));
        criteria.addOrder(Order.asc("id"));

        Collection<TonFactor> matchingEntry = criteria.list();
        return matchingEntry;
    }


}
