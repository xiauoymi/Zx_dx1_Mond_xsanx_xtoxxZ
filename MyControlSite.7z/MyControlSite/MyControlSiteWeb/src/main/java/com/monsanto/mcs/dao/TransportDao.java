package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Transport;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

@Transactional
public interface TransportDao extends GenericDao<Transport,Long> {

    public Collection<Transport> findBySendFormat(String sendFormatFolio) throws Exception;

}