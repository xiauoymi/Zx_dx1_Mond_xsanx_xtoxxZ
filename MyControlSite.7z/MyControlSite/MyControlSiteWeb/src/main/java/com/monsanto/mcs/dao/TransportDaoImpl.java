package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Transport;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

@Repository
public class TransportDaoImpl extends HibernateDao<Transport, Long> implements TransportDao {

    private static final Logger LOG = Logger.getLogger(TransportDaoImpl.class);

    public Collection<Transport> findBySendFormat(String sendFormatFolio) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("sendFormatFolio", sendFormatFolio));

        Collection<Transport> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No Transport found with value: " + sendFormatFolio);
        }
        return matchingEntry;
    }

}

