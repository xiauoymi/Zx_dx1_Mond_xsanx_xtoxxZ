package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.TransportSupplier;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/03/2011
 * Time: 10:19:32 AM
 * To change this template use File | Settings | File Templates.
 */

@Transactional
public interface TransportSupplierDao extends GenericDao<TransportSupplier, Long> {
    public TransportSupplier lookupByCriteria(int idPlant, TransportSupplier example) throws Exception;
    public Collection<TransportSupplier> findByNameOrderedById(int idPlant, String name) throws Exception;
    public Collection<TransportSupplier> findByNameOrderedByName(int idPlant, String name) throws Exception;

}