package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.TransportSupplier;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/03/2011
 * Time: 09:15:17 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class TransportSupplierDaoImpl extends HibernateDao<TransportSupplier, Long> implements TransportSupplierDao {

    private static final Logger LOG = Logger.getLogger(TransportSupplierDaoImpl.class);

    public TransportSupplier lookupByCriteria(int idPlant, TransportSupplier example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.eq("name", example.getName()));
        Collection<TransportSupplier> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No TransportSupplier found with value: " + example.getName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<TransportSupplier> findByNameOrderedById(int idPlant, String name) throws Exception {
        Criteria criteria = createCriteria();
        //   criteria.add(Restrictions.like("name", "%"+name+"%"));
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.addOrder(Order.asc("id"));
        Collection<TransportSupplier> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No TransportSupplier found with value: " + name);
        }
        return matchingEntry;
    }

    public Collection<TransportSupplier> findByNameOrderedByName(int idPlant, String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        criteria.addOrder(Order.asc("name"));
        Collection<TransportSupplier> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No TransportSupplier found with value: " + name);
        }
        return matchingEntry;
    }


}

