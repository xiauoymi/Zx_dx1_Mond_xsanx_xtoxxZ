package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.TransportType;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 04:31:45 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class TransportTypeDaoImpl extends HibernateDao<TransportType, Long> implements TransportTypeDao {

    private static final Logger LOG = Logger.getLogger(TransportTypeDaoImpl.class);

    public TransportType lookupByCriteria(TransportType example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getType()));
        Collection<TransportType> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No transport found with type: " + example.getType());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<TransportType> findByName(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("type", "%" + name + "%"));
        criteria.addOrder(Order.asc("type"));
        Collection<TransportType> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No transport found with name: " + name);
        }
        return matchingEntry;
    }

    public Collection<TransportType> findByNameOrderedById(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("type", "%" + name + "%"));
        criteria.addOrder(Order.asc("id"));
        Collection<TransportType> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No transport found with name: " + name);
        }
        return matchingEntry;
    }


}
