package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Treatment;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 03:54:27 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class TreatmentDaoImpl extends HibernateDao<Treatment, Long> implements TreatmentDao {

    private static final Logger LOG = Logger.getLogger(TreatmentDaoImpl.class);

    public Treatment lookupByCriteria(Treatment example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("name", example.getName()));
        Collection<Treatment> matchingEntry = criteria.list();
        return matchingEntry.iterator().next();
    }

    public Collection<Treatment> findByNameOrderedById(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("name", "%" + name + "%"));
        criteria.addOrder(Order.asc("id"));
        Collection<Treatment> matchingEntry = criteria.list();
        return matchingEntry;
    }


}
