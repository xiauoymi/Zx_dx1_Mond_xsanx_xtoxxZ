package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.TruckBrand;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/03/2011
 * Time: 09:10:23 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface TruckBrandDao extends GenericDao<TruckBrand, Long> {
    public TruckBrand lookupByCriteria(TruckBrand example) throws Exception;
    public Collection<TruckBrand> findByNameOrderedById(String name) throws Exception;

}
