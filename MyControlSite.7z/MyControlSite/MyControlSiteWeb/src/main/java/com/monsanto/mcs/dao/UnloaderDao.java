package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Unloader;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:43:57 AM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface UnloaderDao extends GenericDao<Unloader, Long> {
    public Unloader lookupByCriteria(int idPlant, Unloader example) throws Exception;
    public Collection<Unloader> findByNameOrderedById(int idPlant, String name) throws Exception;
    public Collection<Unloader> findByNameOrderedByName(int idPlant, String name) throws Exception;

}
