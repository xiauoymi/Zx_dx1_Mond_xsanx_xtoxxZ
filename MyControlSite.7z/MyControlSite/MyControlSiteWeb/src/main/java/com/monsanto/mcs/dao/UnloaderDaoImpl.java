package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Unloader;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:46:07 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class UnloaderDaoImpl extends HibernateDao<Unloader, Long> implements UnloaderDao {

    private static final Logger LOG = Logger.getLogger(UnloaderDaoImpl.class);

    public Unloader lookupByCriteria(int idPlant, Unloader example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.eq("fullName", example.getFullName()));
        Collection<Unloader> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No UNLOADER found with name: " + example.getFullName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Unloader> findByNameOrderedById(int idPlant, String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("fullName", "%" + name + "%"));
        criteria.addOrder(Order.asc("id"));

        Collection<Unloader> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public Collection<Unloader> findByNameOrderedByName(int idPlant, String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("fullName", "%" + name + "%"));
        criteria.addOrder(Order.asc("fullName"));

        Collection<Unloader> matchingEntry = criteria.list();
        return matchingEntry;
    }


}
