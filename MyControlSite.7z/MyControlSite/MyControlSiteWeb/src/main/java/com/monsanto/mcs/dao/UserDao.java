package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.MCSUser;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;


@Transactional
public interface UserDao extends GenericDao<MCSUser, Long> {
    public MCSUser lookupByCriteria(MCSUser example) throws Exception;
    public MCSUser findByName(String name) throws Exception;
    public Collection <MCSUser> findAllUsers(String name) throws Exception;



}
