package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.MCSUser;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;


@Repository
public class UserDaoImpl extends HibernateDao<MCSUser, Long> implements UserDao {

    private static final Logger LOG = Logger.getLogger(UserDaoImpl.class);

    public MCSUser lookupByCriteria(MCSUser example) throws Exception {
        Criteria criteria = createCriteria();
        //criteria.add(Restrictions.eq("name", example.getName()));
        Collection<MCSUser> matchingEntry = criteria.list();
        return matchingEntry.iterator().next();
    }

    public MCSUser findByName(String name) throws Exception {
        MCSUser user = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("userId", name));
        Collection<MCSUser> matchingEntry = criteria.list();
        if (matchingEntry.size() > 0) {
            user = matchingEntry.iterator().next();
        }
        return user;
    }

    public Collection<MCSUser> findAllUsers(String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.like("userId", "%" + name + "%"));
        criteria.addOrder(Order.asc("userId"));
        Collection<MCSUser> results = criteria.list();
        return results;
    }

    ;


}
