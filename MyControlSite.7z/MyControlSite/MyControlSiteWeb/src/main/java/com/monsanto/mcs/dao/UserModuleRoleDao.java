package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.UserModuleRole;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 1/03/2011
 * Time: 12:59:15 PM
 * To change this template use File | Settings | File Templates.
 */
 @Transactional
public interface UserModuleRoleDao extends GenericDao<UserModuleRole, Long> {

        public Collection<UserModuleRole> lookupByCriteria(String userId) throws Exception;

}
