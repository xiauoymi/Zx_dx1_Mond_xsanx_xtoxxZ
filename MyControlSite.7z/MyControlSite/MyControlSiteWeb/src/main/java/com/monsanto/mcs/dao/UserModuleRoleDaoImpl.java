package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.UserModuleRole;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 1/03/2011
 * Time: 12:59:31 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class UserModuleRoleDaoImpl extends HibernateDao<UserModuleRole, Long> implements UserModuleRoleDao {

    private static final Logger LOG = Logger.getLogger(ConditionDaoImpl.class);

    public Collection<UserModuleRole> lookupByCriteria(String userId) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("userId", userId));
        Collection<UserModuleRole> results = criteria.list();
        return results;
    }

    ;

}
