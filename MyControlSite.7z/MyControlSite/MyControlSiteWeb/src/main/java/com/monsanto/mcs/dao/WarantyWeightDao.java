package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.WarantyWeight;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/03/2011
 * Time: 12:29:43 PM
 * To change this template use File | Settings | File Templates.
 */
@Transactional
public interface WarantyWeightDao extends GenericDao<WarantyWeight, Long> {
    public WarantyWeight lookupByCriteria(int plantSeasonId, WarantyWeight example) throws Exception;
    public Collection<WarantyWeight> findBySupplierOrderedById(int plantSeasonId, String name) throws Exception;

    public WarantyWeight findWarrantyForSendFormat(long plantSeasonId, long transportTypeId, long transportSupplierId, long zoneId, Long id) throws Exception;

}
