package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.WarantyWeight;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 25/03/2011
 * Time: 12:30:56 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class WarantyWeightDaoImpl extends HibernateDao<WarantyWeight, Long> implements WarantyWeightDao {

    private static final Logger LOG = Logger.getLogger(WarantyWeightDaoImpl.class);

    public WarantyWeight lookupByCriteria(int idPlant, WarantyWeight example) throws Exception {
        Criteria criteria = createCriteria();
        //criteria.add(Restrictions.eq("commentValue", ));
        Collection<WarantyWeight> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No WarantyWeight found with value ");
        }
        return matchingEntry.iterator().next();
    }

    public Collection<WarantyWeight> findBySupplierOrderedById(int plantSeasonId, String name) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeasonId", new Long(plantSeasonId)));
        criteria.createCriteria("transportSupplier", "transportSupplier")
                .add(Restrictions.like("transportSupplier.name", "%" + name + "%"));
        criteria.addOrder(Order.asc("id"));
        Collection<WarantyWeight> matchingEntry = criteria.list();
        return matchingEntry;
    }

    public WarantyWeight findWarrantyForSendFormat(long plantSeasonId, long transportTypeId, long transportSupplierId, long zoneId, Long plantId) throws Exception {
        WarantyWeight feedback = null;
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("plantSeasonId", plantSeasonId));

        criteria.createCriteria("transportType", "transportType")
                .add(Restrictions.eq("transportType.id", transportTypeId));

        criteria.createCriteria("transportSupplier", "transportSupplier")
                .add(Restrictions.eq("transportSupplier.id", transportSupplierId));

        criteria.createCriteria("zone", "zone")
                .add(Restrictions.eq("zone.id", zoneId));

        criteria.createCriteria("sendToPlant", "sendToPlant")
                .add(Restrictions.eq("sendToPlant.id", plantId));

        Collection<WarantyWeight> matchingEntry = criteria.list();
        if (matchingEntry != null && !matchingEntry.isEmpty()) {
            feedback = matchingEntry.iterator().next();
        }
        return feedback;
    }

}
