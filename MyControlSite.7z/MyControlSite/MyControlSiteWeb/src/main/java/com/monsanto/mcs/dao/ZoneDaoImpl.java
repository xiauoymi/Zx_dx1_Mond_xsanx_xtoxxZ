package com.monsanto.mcs.dao;

import com.monsanto.mcs.model.hibernate.Zone;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 04:34:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class ZoneDaoImpl extends HibernateDao<Zone, Long> implements ZoneDao {

    private static final Logger LOG = Logger.getLogger(ZoneDaoImpl.class);

    public Zone lookupByCriteria(Zone example) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("zoneName", example.getZoneName()));
        Collection<Zone> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No zone found with name: " + example.getZoneName());
        }
        return matchingEntry.iterator().next();
    }

    public Collection<Zone> findByName(String name, int idPlant) throws Exception {
        Criteria criteria = createCriteria();
        criteria.add(Restrictions.eq("idPlant", new Long(idPlant)));
        criteria.add(Restrictions.like("zoneName", "%" + name + "%"));
        criteria.addOrder(Order.asc("zoneName"));
        Collection<Zone> matchingEntry = criteria.list();
        if (matchingEntry.isEmpty()) {
            throw new Exception("No zone found with name: " + name);
        }
        return matchingEntry;
    }


}
