package com.monsanto.mcs.model;

import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class DryingCell {

    private int cell;
    private String folio;
    private String hybrid;
    private Double averageHumidity = 0D;
    private int travelQuantity;
    private Double tons = 0D;
    private boolean status;
    private Date cellOpened;
    private Date cellClosed;
    private Date lastEntry;
    private int entriesSize;

    private Set<DryingCellEntry> entries = new TreeSet<DryingCellEntry>();

    public Double getAverageHumidity() {
        return averageHumidity;
    }

    public void setAverageHumidity(Double averageHumidity) {
        this.averageHumidity = averageHumidity;
    }

    public int getCell() {
        return cell;
    }

    public void setCell(int cell) {
        this.cell = cell;
    }

    public String getFolio() {
        return folio;
    }

    public void setFolio(String folio) {
        this.folio = folio;
    }

    public String getHybrid() {
        return hybrid;
    }

    public void setHybrid(String hybrid) {
        this.hybrid = hybrid;
    }

    public Double getTons() {
        return tons;
    }

    public void setTons(Double tons) {
        this.tons = tons;
    }

    public int getTravelQuantity() {
        return travelQuantity;
    }

    public void setTravelQuantity(int travelQuantity) {
        this.travelQuantity = travelQuantity;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
        if (this.status == false){
            this.setCellClosed(this.lastEntry);
        }
    }

    public Date getCellClosed() {
        return cellClosed;
    }

    public void setCellClosed(Date cellClosed) {
        this.cellClosed = cellClosed;
    }

    public Date getCellOpened() {
        return cellOpened;
    }

    public void setCellOpened(Date cellOpened) {
        this.cellOpened = cellOpened;
    }

    public void addEntry(DryingCellEntry entry){
        entries.add(entry);
        calculateStatistics();
    }

    public Set<DryingCellEntry> getEntries(){
        return entries;
    }

    public int getEntriesSize() {
        return this.entriesSize;
    }

    private void calculateStatistics(){
        Iterator<DryingCellEntry> entryIterator = this.entries.iterator();

        int travelQuantity = 0;
        DryingCellEntry entry = null;
        double totalTons = 0D;
        double totalHumidity = 0D;
        while (entryIterator.hasNext()){
            entry = entryIterator.next();
            totalTons += entry.getPlantData().getWeigth();
            totalHumidity += entry.getPlantData().getHumidity();
            travelQuantity++;
        }
        this.tons = totalTons;
        this.averageHumidity = totalHumidity;
        this.setTravelQuantity(travelQuantity);
        this.averageHumidity = this.averageHumidity / this.travelQuantity;
        lastEntry = ((TreeSet<DryingCellEntry>)entries).last().getPlantData().getUnloadEnd();
        if (!this.isStatus()){
            this.cellClosed = lastEntry;
        }
        this.entriesSize = entries.size();
    }

}
