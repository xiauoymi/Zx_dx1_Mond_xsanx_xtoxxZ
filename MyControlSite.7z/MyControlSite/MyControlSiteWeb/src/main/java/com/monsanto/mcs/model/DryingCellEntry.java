package com.monsanto.mcs.model;

import java.util.Date;

public class DryingCellEntry implements Comparable<DryingCellEntry> {

    private DryingCellFieldData fieldData;
    private DryingCellPlantData plantData;
    private Date entryDate;
    private int sample;

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public DryingCellFieldData getFieldData() {
        return fieldData;
    }

    public void setFieldData(DryingCellFieldData fieldData) {
        this.fieldData = fieldData;
    }

    public DryingCellPlantData getPlantData() {
        return plantData;
    }

    public void setPlantData(DryingCellPlantData plantData) {
        this.plantData = plantData;
    }

    public int getSample() {
        return sample;
    }

    public void setSample(int sample) {
        this.sample = sample;
    }

    public boolean equals(com.monsanto.mcs.model.DryingCellEntry test) {
        boolean testResult = false;
        if (test.getFieldData().getSendFormatFolio().equals(this.getFieldData().getSendFormatFolio())) {
            testResult = true;
        }
        return testResult;
    }

    public int compareTo(DryingCellEntry test) {
        int thisSFFolio = 0;
        int testSFFolio = 0;
        try {
            thisSFFolio = Integer.parseInt(this.getFieldData().getSendFormatFolio().substring(5));
            testSFFolio = Integer.parseInt(test.getFieldData().getSendFormatFolio().substring(5));
        } catch (Exception e) {
            System.out.println("Error with values:" + this.getFieldData().getSendFormatFolio() + "**" + test.getFieldData().getSendFormatFolio());
        }
        return (thisSFFolio - testSFFolio);
    }

}
