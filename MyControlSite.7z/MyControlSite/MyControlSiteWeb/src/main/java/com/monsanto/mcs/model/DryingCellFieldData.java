package com.monsanto.mcs.model;

public class DryingCellFieldData{

    private String sendFormatFolio;
    private String plates;
    private String table;
    private Double weight;
    private Double humidity;
    private String lot;

    public Double getHumidity() {
        return humidity;
    }

    public void setHumidity(Double humidity) {
        this.humidity = humidity;
    }

    public String getPlates() {
        return plates;
    }

    public void setPlates(String plates) {
        this.plates = plates;
    }

    public String getSendFormatFolio() {
        return sendFormatFolio;
    }

    public void setSendFormatFolio(String sendFormatFolio) {
        this.sendFormatFolio = sendFormatFolio;
    }

    public String getTable() {
        return table;
    }

    public void setTable(String table) {
        this.table = table;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public String getLot() {
        return lot;
    }

    public void setLot(String lot) {
        this.lot = lot;
    }
}
