package com.monsanto.mcs.model;

import java.util.Date;

public class DryingCellPlantData{

    private Double humidity;
    private Double weigth;
    private Date unloadStart;
    private Date unloadEnd;

    public Double getHumidity() {
        return humidity;
    }

    public void setHumidity(Double humidity) {
        this.humidity = humidity;
    }

    public Date getUnloadEnd() {
        return unloadEnd;
    }

    public void setUnloadEnd(Date unloadEnd) {
        this.unloadEnd = unloadEnd;
    }

    public Date getUnloadStart() {
        return unloadStart;
    }

    public void setUnloadStart(Date unloadStart) {
        this.unloadStart = unloadStart;
    }

    public Double getWeigth() {
        return weigth;
    }

    public void setWeigth(Double weigth) {
        this.weigth = weigth;
    }
}
