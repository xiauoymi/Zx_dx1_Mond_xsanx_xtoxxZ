package com.monsanto.mcs.model;

import com.monsanto.mcs.model.hibernate.ReceiveLabel;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 30/06/2011
 * Time: 03:53:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class QualityDataGreenCornReceive {

    private ReceiveLabel receiveLabel;
    private int cell;

    public ReceiveLabel getReceiveLabel() {
        return receiveLabel;
    }

    public void setReceiveLabel(ReceiveLabel receiveLabel) {
        this.receiveLabel = receiveLabel;
    }

    public int getCell() {
        return cell;
    }

    public void setCell(int cell) {
        this.cell = cell;
    }
}
