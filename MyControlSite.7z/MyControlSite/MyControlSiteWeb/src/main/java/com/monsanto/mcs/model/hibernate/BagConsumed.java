package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "BAGS_CONSUMED")
public class BagConsumed implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_BAGS_CONSUMED")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @OneToOne
    @JoinColumn(name = "FUELLE_SAP_CODE_ID", referencedColumnName = "ID")
    private FuelleSapCode fuelleSapCode;

    @Column(name = "BAGS")
    private Double bags;

    @OneToOne
    @JoinColumn(name = "MATERIAL_PCKGE_CONSUMPTION_ID", referencedColumnName = "ID")
    private MaterialPackageConsumption materialPackageConsumption;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getBags() {
        return bags;
    }

    public void setBags(Double bags) {
        this.bags = bags;
    }

    public FuelleSapCode getFuelleSapCode() {
        return fuelleSapCode;
    }

    public void setFuelleSapCode(FuelleSapCode fuelleSapCode) {
        this.fuelleSapCode = fuelleSapCode;
    }

    public MaterialPackageConsumption getMaterialPackageConsumption() {
        return materialPackageConsumption;
    }

    public void setMaterialPackageConsumption(MaterialPackageConsumption materialPackageConsumption) {
        this.materialPackageConsumption = materialPackageConsumption;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
