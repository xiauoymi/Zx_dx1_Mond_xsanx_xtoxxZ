package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;
import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.Formula;

import java.util.Collection;
import java.util.Date;
import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "BAGGING")
public class Bagging implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_BAGGING")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @OneToOne
    @JoinColumn(name = "SHIFT_ID", referencedColumnName = "ID")
    private Shift shift;

    @Column(name = "RECORD")
    private Integer record;

    @Column(name = "REBAGGING")
    private Boolean rebagging;

    @Column(name = "FOLIO")
    private Integer folio;

    @OneToOne
    @JoinColumn(name = "BAGGING_ORDER_ID", referencedColumnName = "ID")
    private BaggingOrder baggingOrder;

    @OneToOne
    @JoinColumn(name = "BAGGING_LOT_ID", referencedColumnName = "ID")
    @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE})
    private BaggingLot baggingLot;

    @Transient
    private Collection<MixtureLot> mixtureLots;

    @OneToOne
    @JoinColumn(name = "BAGGING_CONTROL_ID", referencedColumnName = "ID")
    @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE})
    private BaggingControl baggingControl;

    @OneToOne
    @JoinColumn(name = "SNICS_LABEL_ID", referencedColumnName = "ID")
    @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE})
    private SnicsLabel snicsLabel;

    @OneToOne
    @JoinColumn(name = "PLANTABILITY_TEST_ID", referencedColumnName = "ID")
    @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE})
    private PlantabilityTest plantabilityTest;

    @OneToOne
    @JoinColumn(name = "GAMET_ID", referencedColumnName = "ID")
    @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE})
    private Gamet gamet;

    @OneToOne
    @JoinColumn(name = "MATERIAL_PCKGE_CONSUMPTION_ID", referencedColumnName = "ID")
    private MaterialPackageConsumption materialPackageConsumption;

    @OneToOne
    @JoinColumn(name = "ORIGIN_ID", referencedColumnName = "ID")
    private Origin origin;

    @OneToOne
    @JoinColumn(name = "HYBRID_ID", referencedColumnName = "ID")
    private Hybrid hybrid;

    @Column(name = "BAGGING_DATE")
    private Date date;

    @Formula ("to_char(BAGGING_DATE,'DD/MM/YYYY')")
    private String baggingDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setBaggingDate(String date) {
        //DO NOT REMOVE. METHOD DECLARED TO PASS VALUE TO Flex BlaseDS  
    }

    public String getBaggingDate() {
        return this.baggingDate;
    }

    public Boolean getRebagging() {
        return rebagging;
    }

    public void setRebagging(Boolean rebagging) {
        this.rebagging = rebagging;
    }

    public Integer getRecord() {
        return record;
    }

    public void setRecord(Integer record) {
        this.record = record;
    }

    public Shift getShift() {
        return shift;
    }

    public void setShift(Shift shift) {
        this.shift = shift;
    }

    public BaggingControl getBaggingControl() {
        return baggingControl;
    }

    public void setBaggingControl(BaggingControl baggingControl) {
        this.baggingControl = baggingControl;
    }

    public Gamet getGamet() {
        return gamet;
    }

    public void setGamet(Gamet gamet) {
        this.gamet = gamet;
    }

    public PlantabilityTest getPlantabilityTest() {
        return plantabilityTest;
    }

    public void setPlantabilityTest(PlantabilityTest plantabilityTest) {
        this.plantabilityTest = plantabilityTest;
    }

    public SnicsLabel getSnicsLabel() {
        return snicsLabel;
    }

    public void setSnicsLabel(SnicsLabel snicsLabel) {
        this.snicsLabel = snicsLabel;
    }

    public BaggingLot getBaggingLot() {
        return baggingLot;
    }

    public void setBaggingLot(BaggingLot baggingLot) {
        this.baggingLot = baggingLot;
    }

    public Collection<MixtureLot> getMixtureLots() {
        return mixtureLots;
    }

    public void setMixtureLots(Collection<MixtureLot> mixtureLots) {
        this.mixtureLots = mixtureLots;
    }

    public BaggingOrder getBaggingOrder() {
        return baggingOrder;
    }

    public void setBaggingOrder(BaggingOrder baggingOrder) {
        this.baggingOrder = baggingOrder;
    }

    public MaterialPackageConsumption getMaterialPackageConsumption() {
        return materialPackageConsumption;
    }

    public void setMaterialPackageConsumption(MaterialPackageConsumption materialPackageConsumption) {
        this.materialPackageConsumption = materialPackageConsumption;
    }

    public Hybrid getHybrid() {
        return hybrid;
    }

    public void setHybrid(Hybrid hybrid) {
        this.hybrid = hybrid;
    }

    public Origin getOrigin() {
        return origin;
    }

    public void setOrigin(Origin origin) {
        this.origin = origin;
    }

    public Integer getFolio() {
        return folio;
    }

    public void setFolio(Integer folio) {
        this.folio = folio;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
