package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "BAGGING_CONTROL")
public class BaggingControl implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_BAGGING_CONTROL")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "COUNTS1")
    private Double counts1;

    @Column(name = "COUNTS2")
    private Double counts2;

    @Column(name = "COUNTS3")
    private Double counts3;

    @Column(name = "COUNTS_AVG")
    private Double countsAvg;

    @Column(name = "SEED_KG")
    private Double seedKilogram;

    @Column(name = "BAG_WEIGHT")
    private Double bagWeigth;

    @Column(name = "LABELED_WEIGHT")
    private Double labeledWeigth;

    @Column(name = "SCALE_WEIGHT")
    private Double scaleWeigth;

    @Column(name = "BAGGED_BAGS")
    private Double baggedBags;

    @Column(name = "VERIFICATION")
    private Boolean verification;

    @Column(name = "TARIMA1")
    private Double tarima1;

    @Column(name = "TARIMA2")
    private Double tarima2;

    @Column(name = "TARIMA3")
    private Double tarima3;

    @Column(name = "TARIMA4")
    private Double tarima4;

    @Column(name="MANIPULATED_BULK")
    private Double manipulatedBulk;

    @OneToOne
    @JoinColumn(name = "BIN_ID", referencedColumnName = "ID")
    private Bin bin;

    @OneToOne
    @JoinColumn(name = "PRESENTATION_ID", referencedColumnName = "ID")
    private Presentation presentation;

    @OneToOne
    @JoinColumn(name = "SHIFT_MANAGER_ID", referencedColumnName = "ID")
    private ShiftManager shiftManager;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getBaggedBags() {
        return baggedBags;
    }

    public void setBaggedBags(Double baggedBags) {
        this.baggedBags = baggedBags;
    }

    public Double getBagWeigth() {
        return bagWeigth;
    }

    public void setBagWeigth(Double bagWeigth) {
        this.bagWeigth = bagWeigth;
    }

    public Bin getBin() {
        return bin;
    }

    public void setBin(Bin bin) {
        this.bin = bin;
    }

    public Double getCounts1() {
        return counts1;
    }

    public void setCounts1(Double counts1) {
        this.counts1 = counts1;
    }

    public Double getCounts2() {
        return counts2;
    }

    public void setCounts2(Double counts2) {
        this.counts2 = counts2;
    }

    public Double getCounts3() {
        return counts3;
    }

    public void setCounts3(Double counts3) {
        this.counts3 = counts3;
    }

    public Double getCountsAvg() {
        return countsAvg;
    }

    public void setCountsAvg(Double countsAvg) {
        this.countsAvg = countsAvg;
    }

    public Double getLabeledWeigth() {
        return labeledWeigth;
    }

    public void setLabeledWeigth(Double labeledWeigth) {
        this.labeledWeigth = labeledWeigth;
    }

    public Presentation getPresentation() {
        return presentation;
    }

    public void setPresentation(Presentation presentation) {
        this.presentation = presentation;
    }

    public Double getScaleWeigth() {
        return scaleWeigth;
    }

    public void setScaleWeigth(Double scaleWeigth) {
        this.scaleWeigth = scaleWeigth;
    }

    public Double getSeedKilogram() {
        return seedKilogram;
    }

    public void setSeedKilogram(Double seedKilogram) {
        this.seedKilogram = seedKilogram;
    }

    public ShiftManager getShiftManager() {
        return shiftManager;
    }

    public void setShiftManager(ShiftManager shiftManager) {
        this.shiftManager = shiftManager;
    }

    public Double getTarima1() {
        return tarima1;
    }

    public void setTarima1(Double tarima1) {
        this.tarima1 = tarima1;
    }

    public Double getTarima2() {
        return tarima2;
    }

    public void setTarima2(Double tarima2) {
        this.tarima2 = tarima2;
    }

    public Double getTarima3() {
        return tarima3;
    }

    public void setTarima3(Double tarima3) {
        this.tarima3 = tarima3;
    }

    public Double getTarima4() {
        return tarima4;
    }

    public void setTarima4(Double tarima4) {
        this.tarima4 = tarima4;
    }

    public Boolean getVerification() {
        return verification;
    }

    public void setVerification(Boolean verification) {
        this.verification = verification;
    }

    public Double getManipulatedBulk() {
        return manipulatedBulk;
    }

    public void setManipulatedBulk(Double manipulatedBulk) {
        this.manipulatedBulk = manipulatedBulk;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
