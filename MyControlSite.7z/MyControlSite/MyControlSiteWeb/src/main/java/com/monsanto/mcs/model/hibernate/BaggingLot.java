package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "BAGGING_LOT")
public class BaggingLot implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_BAGGING_LOT")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "SEED_SIZE")
    private String seedSize;

    @Column(name = "CERTIFIED")
    private Boolean certificated;

    @Column(name = "NUMERIC_SEQUENCE")
    private String numericSequence;

    @Column(name = "ALPHA_SEQUENCE")
    private String alphaSequence;

    @OneToOne
    @javax.persistence.JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
    private Plant plant;

    @OneToOne
    @javax.persistence.JoinColumn(name = "SEASON_ID", referencedColumnName = "ID")
    private Season season;

    @OneToOne
    @javax.persistence.JoinColumn(name = "TREATMENT_ID", referencedColumnName = "ID")
    private Treatment treatment;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public String getAlphaSequence() {
        return alphaSequence;
    }

    public void setAlphaSequence(String alphaSequence) {
        this.alphaSequence = alphaSequence;
    }

    public Boolean isCertificated() {
        return certificated;
    }

    public void setCertificated(Boolean certificated) {
        this.certificated = certificated;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNumericSequence() {
        return numericSequence;
    }

    public void setNumericSequence(String numericSequence) {
        this.numericSequence = numericSequence;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public Season getSeason() {
        return season;
    }

    public void setSeason(Season season) {
        this.season = season;
    }

    public String getSeedSize() {
        return seedSize;
    }

    public void setSeedSize(String seedSize) {
        this.seedSize = seedSize;
    }

    public Treatment getTreatment() {
        return treatment;
    }

    public void setTreatment(Treatment treatment) {
        this.treatment = treatment;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
