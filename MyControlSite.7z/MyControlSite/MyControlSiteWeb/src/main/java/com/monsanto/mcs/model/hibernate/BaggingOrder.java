package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "FILTERED_BAGGING_ORDER")
public class BaggingOrder implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_BAGGING_ORDER")
    @Id @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "BAGGING_LOT")
    private String baggingLot;

    @Column(name = "ORDER_NUMBER")
    private Long orderNumber;

    @Column(name = "DESCRIPTION")
    private String description;

    @Column(name = "MIXTURE_LOT")
    private String mixtureLot;

    @Column(name = "MATERIAL_NUMBER")
    private Long materialNumber;

    @Column(name = "HYBRID")
    private String hybrid;

    @Column(name = "\"DATE\"")
    private Date date;

    @Column(name = "PLANT_ID")
    private Integer plantId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L) {
            return;
        }
        this.id = id;
    }

    public String getBaggingLot() {
        return baggingLot;
    }

    public void setBaggingLot(String baggingLot) {
        this.baggingLot = baggingLot;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getHybrid() {
        return hybrid;
    }

    public void setHybrid(String hybrid) {
        this.hybrid = hybrid;
    }

    public Long getMaterialNumber() {
        return materialNumber;
    }

    public void setMaterialNumber(Long materialNumber) {
        this.materialNumber = materialNumber;
    }

    public String getMixtureLot() {
        return mixtureLot;
    }

    public void setMixtureLot(String mixtureLot) {
        this.mixtureLot = mixtureLot;
    }

    public Long getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(Long orderNumber) {
        this.orderNumber = orderNumber;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getPlantId() {
        return plantId;
    }

    public void setPlantId(Integer plantId) {
        this.plantId = plantId;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
