package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "BAGGING_VIEW_PKI")
public class BaggingViewPKI implements Serializable {

    @Id
    private Long id;

    @Column(name = "BAGGING_DATE")
    private String baggingDate;

    @Column(name = "TREATMENT")
    private String treatment;

    @Column(name = "PLANT_ID")
    private Integer plant;

    @Column(name = "SEASON_ID")
    private Integer season;

    @Column (name = "BAGGED_BAGS")
    private Double baggedBags;

    @Column (name = "PRESENTATION_DSC")
    private Double presentacionDsc;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBaggingDate() {
        return baggingDate;
    }

    public void setBaggingDate(String baggingDate) {
        this.baggingDate = baggingDate;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    public Integer getPlant() {
        return plant;
    }

    public void setPlant(Integer plant) {
        this.plant = plant;
    }

    public Integer getSeason() {
        return season;
    }

    public void setSeason(Integer season) {
        this.season = season;
    }

    public Double getBaggedBags() {
        return baggedBags;
    }

    public void setBaggedBags(Double baggedBags) {
        this.baggedBags = baggedBags;
    }

    public Double getPresentacionDsc() {
        return presentacionDsc;
    }

    public void setPresentacionDsc(Double presentacionDsc) {
        this.presentacionDsc = presentacionDsc;
    }
}
