package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "CELL_STATUS")
public class CellStatus implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="CELL_STATUS_SEQ")
    @Id
    @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column (name = "PLANT_DSC")
    private String plantDescription;

    @Column (name = "CELL_STAT_DATE")
    private Date cellStatusDate;

    @Column (name = "CELL_DSC")
    private String cellName;

    @Column (name = "HYBRID_DSC")
    private String hybridName;

    @Column (name = "LOT")
    private String lot;

    @Column (name = "RECEIVE_DATE")
    private String receiveDate;

    @Column (name = "INITIAL_HUMIDITY")
    private Double initialHumidity;

    @Column (name = "CURRENT_HUMIDITY")
    private Double currentHumidity;

    @Column (name = "INFERIOR_HUMIDITY_PERCENT")
    private Double inferiorHumidity;

    @Column (name = "SUPERIOR_HUMIDITY_PERCENT")
    private Double superiorHumidity;

    @Column (name = "WEIGTH")
    private String weigth;

    @Column (name = "BIN_PRESSURE")
    private Double binPressure;

    @Column (name = "STATUS")
    private String status;

    @Column (name = "DRYING_SPENT_HOURS")
    private Double dryingSpentHours;

    @Column (name = "DRY_QUATITY")
    private Double dryQuantity;

    @Column (name = "DESTINATION")
    private Double destination;

    @Column (name = "PLANT_ID")
    private Long plant;

    public Double getBinPressure() {
        return binPressure;
    }

    public void setBinPressure(Double binPressure) {
        this.binPressure = binPressure;
    }

    public String getCellName() {
        return cellName;
    }

    public void setCellName(String cellName) {
        this.cellName = cellName;
    }

    public Date getCellStatusDate() {
        return cellStatusDate;
    }

    public void setCellStatusDate(Date cellStatusDate) {
        this.cellStatusDate = cellStatusDate;
    }

    public Double getCurrentHumidity() {
        return currentHumidity;
    }

    public void setCurrentHumidity(Double currentHumidity) {
        this.currentHumidity = currentHumidity;
    }

    public Double getDestination() {
        return destination;
    }

    public void setDestination(Double destination) {
        this.destination = destination;
    }

    public Double getDryingSpentHours() {
        return dryingSpentHours;
    }

    public void setDryingSpentHours(Double dryingSpentHours) {
        this.dryingSpentHours = dryingSpentHours;
    }

    public Double getDryQuantity() {
        return dryQuantity;
    }

    public void setDryQuantity(Double dryQuantity) {
        this.dryQuantity = dryQuantity;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getInferiorHumidity() {
        return inferiorHumidity;
    }

    public void setInferiorHumidity(Double inferiorHumidity) {
        this.inferiorHumidity = inferiorHumidity;
    }

    public Double getInitialHumidity() {
        return initialHumidity;
    }

    public void setInitialHumidity(Double initialHumidity) {
        this.initialHumidity = initialHumidity;
    }

    public String getLot() {
        return lot;
    }

    public void setLot(String lot) {
        this.lot = lot;
    }

    public String getReceiveDate() {
        return receiveDate;
    }

    public void setReceiveDate(String receiveDate) {
        this.receiveDate = receiveDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getSuperiorHumidity() {
        return superiorHumidity;
    }

    public void setSuperiorHumidity(Double superiorHumidity) {
        this.superiorHumidity = superiorHumidity;
    }

    public String getWeigth() {
        return weigth;
    }

    public void setWeigth(String weigth) {
        this.weigth = weigth;
    }

    public String getPlantDescription() {
        return plantDescription;
    }

    public void setPlantDescription(String plantDescription) {
        this.plantDescription = plantDescription;
    }

    public Long getPlant() {
        return plant;
    }

    public void setPlant(Long plant) {
        this.plant = plant;
    }
}
