package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;
import org.hibernate.annotations.Formula;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;

@Entity
@Table(name = "CHEMICAL_CONSUMPTION")
public class ChemicalConsumption implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_CHEMICAL_CONSUMPTION")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "BAGGING_DATE")
    private Date date;

    @Formula ("to_char(BAGGING_DATE,'DD/MM/YYYY')")
    private String baggingDate;

    @OneToOne
    @JoinColumn(name = "SHIFT_ID", referencedColumnName = "ID")
    private Shift shift;

    @Column(name = "ORDER_NUMBER")
    private String orderNumber;

    @Column(name = "TONS")
    private Double tons;

    @Column(name = "LTS_TONS")
    private Double ltsTons;

    @Column(name = "SLURRY")
    private Double slurry;

    @Column(name = "MAXIM")
    private Double maxim;

    @Column(name = "KOBIOL")
    private Double kobiol;

    @Column(name = "PRECISE")
    private Double precise;

    @Column(name = "PONCHO")
    private Double poncho;

    @Column(name = "BAYTAN")
    private Double baytan;

    @Column(name = "APRON")
    private Double apron;

    @Column(name = "DINASTY")
    private Double dinasty;

    @Column(name = "RED_COLORANT")
    private Double redColorant;

    @Column(name = "GREEN_COLORANT")
    private Double greenColorant;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    @OneToOne
    @JoinColumn(name = "TREATMENT_ID", referencedColumnName = "ID")
    private Treatment treatment;

    @OneToOne
    @JoinColumn(name = "HYBRID_ID", referencedColumnName = "ID")
    private Hybrid hybrid;

    @OneToOne
    @JoinColumn(name = "ORIGIN_ID", referencedColumnName = "ID")
    private Origin origin;

    @OneToOne
    @JoinColumn(name = "PLANT_SUPERVISOR_ID", referencedColumnName = "ID")
    private PlantSupervisor plantSupervisor;

    @OneToOne
    @JoinColumn(name = "PLANT_SEASON_ID", referencedColumnName = "ID")
    private PlantSeason plantSeason;

    @OneToOne
    @JoinColumn(name = "BAGGING_ID", referencedColumnName = "ID")
    private Bagging bagging;

    @Transient
    private HashMap<Chemicals,Double> chemicalsConsumption;

    public ChemicalConsumption(){
        tons = 0D;
        ltsTons = 0D;
        slurry = 0D;
        maxim = 0D;
        kobiol = 0D;
        precise = 0D;
        poncho = 0D;
        baytan = 0D;
        apron = 0D;
        dinasty = 0D;
        redColorant = 0D;
        greenColorant = 0D;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Hybrid getHybrid() {
        return hybrid;
    }

    public void setHybrid(Hybrid hybrid) {
        this.hybrid = hybrid;
    }

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public Origin getOrigin() {
        return origin;
    }

    public void setOrigin(Origin origin) {
        this.origin = origin;
    }

    public PlantSupervisor getPlantSupervisor() {
        return plantSupervisor;
    }

    public void setPlantSupervisor(PlantSupervisor plantSupervisor) {
        this.plantSupervisor = plantSupervisor;
    }

    public Shift getShift() {
        return shift;
    }

    public void setShift(Shift shift) {
        this.shift = shift;
    }

    public Double getLtsTons() {
        return ltsTons;
    }

    public void setLtsTons(Double ltsTons) {
        this.ltsTons = ltsTons;
    }

    public Double getSlurry() {
        return slurry;
    }

    public void setSlurry(Double slurry) {
        this.slurry = slurry;
    }

    public Double getTons() {
        return tons;
    }

    public void setTons(Double tons) {
        this.tons = tons;
    }

    public double getMaxim() {
        return maxim;
    }

    public void setMaxim(double maxim) {
        this.maxim = maxim;
    }

    public double getKobiol() {
        return kobiol;
    }

    public void setKobiol(double kobiol) {
        this.kobiol = kobiol;
    }

    public double getPrecise() {
        return precise;
    }

    public void setPrecise(double precise) {
        this.precise = precise;
    }

    public double getPoncho() {
        return poncho;
    }

    public void setPoncho(double poncho) {
        this.poncho = poncho;
    }

    public double getBaytan() {
        return baytan;
    }

    public void setBaytan(double baytan) {
        this.baytan = baytan;
    }

    public double getApron() {
        return apron;
    }

    public void setApron(double apron) {
        this.apron = apron;
    }

    public double getDinasty() {
        return dinasty;
    }

    public void setDinasty(double dinasty) {
        this.dinasty = dinasty;
    }

    public double getRedColorant() {
        return redColorant;
    }

    public void setRedColorant(double redColorant) {
        this.redColorant = redColorant;
    }

    public double getGreenColorant() {
        return greenColorant;
    }

    public void setGreenColorant(double greenColorant) {
        this.greenColorant = greenColorant;
    }

    public Treatment getTreatment() {
        return treatment;
    }

    public void setTreatment(Treatment treatment) {
        this.treatment = treatment;
    }

    public PlantSeason getPlantSeason() {
        return plantSeason;
    }

    public void setPlantSeason(PlantSeason plantSeason) {
        this.plantSeason = plantSeason;
    }

    public Bagging getBagging() {
        return bagging;
    }

    public void setBagging(Bagging bagging) {
        this.bagging = bagging;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getBaggingDate() {
        return baggingDate;
    }

    public void setBaggingDate(String baggingDate) {
        this.baggingDate = baggingDate;
    }

    public HashMap<Chemicals, Double> getChemicalsConsumption() {
        return chemicalsConsumption;
    }

    public void setChemicalsConsumption(HashMap<Chemicals, Double> chemicalsConsumption) {
        this.chemicalsConsumption = chemicalsConsumption;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
