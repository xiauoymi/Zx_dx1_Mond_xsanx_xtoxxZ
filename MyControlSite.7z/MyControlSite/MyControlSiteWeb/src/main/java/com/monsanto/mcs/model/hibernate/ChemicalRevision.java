package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;

@Entity
@Table(name = "CHEMICAL_REVISION")
public class ChemicalRevision implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_CATALOGS")
    @Id
    @GeneratedValue(generator="mcsSeq")
    private Long id;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "PLANT_SEASON_ID", referencedColumnName = "ID")
    private PlantSeason plantSeason;

    @OneToOne
    @JoinColumn(name = "BAGGING_ID", referencedColumnName = "ID")
    private Bagging bagging;

    @Column(name = "MAXIM")
    private double maxim;

    @Column(name = "KOBIOL")
    private double kobiol;

    @Column(name = "PRECISE")
    private double precise;

    @Column(name = "PONCHO")
    private double poncho;

    @Column(name = "BAYTAN")
    private double baytan;

    @Column(name = "APRON")
    private double apron;

    @Column(name = "DINASTY")
    private double dinasty;

    @Column(name = "RED_COLORANT")
    private double redColorant;

    @Column(name = "GREEN_COLORANT")
    private double greenColorant;

    @Column(name = "DISCARD_BULK")
    private double discardBulk;

    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    @Transient
    private HashMap<Chemicals,Double> chemicalsRevision;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public PlantSeason getPlantSeason() {
        return plantSeason;
    }

    public void setPlantSeason(PlantSeason plantSeason) {
        this.plantSeason = plantSeason;
    }

    public double getMaxim() {
        return maxim;
    }

    public void setMaxim(double maxim) {
        this.maxim = maxim;
    }

    public double getKobiol() {
        return kobiol;
    }

    public void setKobiol(double kobiol) {
        this.kobiol = kobiol;
    }

    public double getPrecise() {
        return precise;
    }

    public void setPrecise(double precise) {
        this.precise = precise;
    }

    public double getPoncho() {
        return poncho;
    }

    public void setPoncho(double poncho) {
        this.poncho = poncho;
    }

    public double getBaytan() {
        return baytan;
    }

    public void setBaytan(double baytan) {
        this.baytan = baytan;
    }

    public double getApron() {
        return apron;
    }

    public void setApron(double apron) {
        this.apron = apron;
    }

    public double getDinasty() {
        return dinasty;
    }

    public void setDinasty(double dinasty) {
        this.dinasty = dinasty;
    }

    public double getRedColorant() {
        return redColorant;
    }

    public void setRedColorant(double redColorant) {
        this.redColorant = redColorant;
    }

    public double getGreenColorant() {
        return greenColorant;
    }

    public void setGreenColorant(double greenColorant) {
        this.greenColorant = greenColorant;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public Bagging getBagging() {
        return bagging;
    }

    public void setBagging(Bagging bagging) {
        this.bagging = bagging;
    }

    public double getDiscardBulk() {
        return discardBulk;
    }

    public void setDiscardBulk(double discardBulk) {
        this.discardBulk = discardBulk;
    }

    public HashMap<Chemicals, Double> getChemicalsRevision() {
        return chemicalsRevision;
    }

    public void setChemicalsRevision(HashMap<Chemicals, Double> chemicalsRevision) {
        this.chemicalsRevision = chemicalsRevision;
    }

}
