package com.monsanto.mcs.model.hibernate;


import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(name = "CHEMICAL_TREATMENT")
public class ChemicalTreatment implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_CATALOGS")
    @Id
    @GeneratedValue(generator="mcsSeq")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "TREATMENT_ID", referencedColumnName = "ID")
    private Treatment treatment;

    @Column (name = "MAXIM")
    private Boolean maxim;

    @Column (name = "KOBIOL")
    private Boolean kobiol;

    @Column (name = "BAYTAN")
    private Boolean baytan;

    @Column (name = "APRON")
    private Boolean apron;

    @Column (name = "PRECISE")
    private Boolean precise;

    @Column (name = "PONCHO")
    private Boolean poncho;

    @Column (name = "DINASTY")
    private Boolean dinasty;

    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Treatment getTreatment() {
        return treatment;
    }

    public void setTreatment(Treatment treatment) {
        this.treatment = treatment;
    }

    public Boolean getMaxim() {
        return maxim;
    }

    public void setMaxim(Boolean maxim) {
        this.maxim = maxim;
    }

    public Boolean getKobiol() {
        return kobiol;
    }

    public void setKobiol(Boolean kobiol) {
        this.kobiol = kobiol;
    }

    public Boolean getBaytan() {
        return baytan;
    }

    public void setBaytan(Boolean baytan) {
        this.baytan = baytan;
    }

    public Boolean getApron() {
        return apron;
    }

    public void setApron(Boolean apron) {
        this.apron = apron;
    }

    public Boolean getPrecise() {
        return precise;
    }

    public void setPrecise(Boolean precise) {
        this.precise = precise;
    }

    public Boolean getPoncho() {
        return poncho;
    }

    public void setPoncho(Boolean poncho) {
        this.poncho = poncho;
    }

    public Boolean getDinasty() {
        return dinasty;
    }

    public void setDinasty(Boolean dinasty) {
        this.dinasty = dinasty;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
}
