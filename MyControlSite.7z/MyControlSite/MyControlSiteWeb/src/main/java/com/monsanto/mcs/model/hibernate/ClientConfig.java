package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "CLIENT_CONFIG")
public class ClientConfig implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_CATALOGS")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "LOCAL_DIR")
    private String localDirectory;

    @OneToOne
    @JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
    private Plant plant;

    @OneToOne
    @JoinColumn(name = "SERVER_ID", referencedColumnName = "ID")
    private Server server;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public String getLocalDirectory() {
        return localDirectory;
    }

    public void setLocalDirectory(String localDirectory) {
        this.localDirectory = localDirectory;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public Server getServer() {
        return server;
    }

    public void setServer(Server server) {
        this.server = server;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
