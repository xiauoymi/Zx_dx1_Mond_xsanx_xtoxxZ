package com.monsanto.mcs.model.hibernate;

/**
 * Created by IntelliJ IDEA.
 * User: ADRIAN ROJAS
 * Date: 22/03/2011
 * To change this template use File | Settings | File Templates.
 */

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

@Entity
@Table(name = "CLOSING_CELL_LOG")
public class ClosingCellLog implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="CELL_LOG_SEQ")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "PLANT_SEASON_ID")
    private Long plantSeasonId;

    @Column(name = "CELL")
    private int cell;

    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Long getPlantSeasonId() {
        return plantSeasonId;
    }

    public void setPlantSeasonId(Long plantSeasonId) {
        this.plantSeasonId = plantSeasonId;
    }

    public int getCell() {
        return cell;
    }

    public void setCell(int cell) {
        this.cell = cell;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
}
