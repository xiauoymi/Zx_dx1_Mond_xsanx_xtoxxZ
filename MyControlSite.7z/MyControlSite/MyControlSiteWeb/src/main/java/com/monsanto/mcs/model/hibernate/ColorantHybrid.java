package com.monsanto.mcs.model.hibernate;


import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(name = "COLORANT_HYBRID")
public class ColorantHybrid implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_CATALOGS")
    @Id
    @GeneratedValue(generator="mcsSeq")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "CHEMICAL_COLORANT_ID", referencedColumnName = "ID")
    private ChemicalColorant chemicalColorant;

    @ManyToOne
    @JoinColumn(name = "HYBRID_ID", referencedColumnName = "ID")
    private Hybrid hybrid;


    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }


    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public ChemicalColorant getChemicalColorant() {
        return chemicalColorant;
    }

    public void setChemicalColorant(ChemicalColorant chemicalColorant) {
        this.chemicalColorant = chemicalColorant;
    }

    public Hybrid getHybrid() {
        return hybrid;
    }

    public void setHybrid(Hybrid hybrid) {
        this.hybrid = hybrid;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
}
