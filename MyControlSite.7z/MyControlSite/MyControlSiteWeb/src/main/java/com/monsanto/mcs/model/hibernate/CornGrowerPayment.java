package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 23/05/2011
 * Time: 12:54:27 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "CORN_GROWER_PAYMENT")
public class CornGrowerPayment implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="CORN_GROWER_PAYMENT_SEQ")
    @Id
    @GeneratedValue(generator="mcsSeq")
    private Long id;


    @ManyToOne
    @JoinColumn(name = "UNLOAD_SCALE_ID", referencedColumnName = "ID")
    private Scale scale;

    @Column(name = "OLOTE_WEIGHT")
    private Double oloteWeight;

    @Column(name = "SAMPLE_WEIGHT_WLEAF1")
    private Double sampleWeightWithLeaf1;

    @Column(name = "SAMPLE_WEIGHT_WLEAF2")
    private Double sampleWeightWithLeaf2;

    @Column(name = "VOLCADOR_OPERADOR")
    private String volcador;

    @Column(name = "QUALITY_CONTROL")
    private String qualityControl;

    @Column(name = "QUALITY_NAME_RECEIVE")
    private String qualityNameReceive;

    @Column(name = "QUALITY_NAME_SHELLING")
    private String qualityNameShelling;


    @Column(name = "COMMENTS")
    private String comments;


    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L)
           return;
        this.id = id;
    }

    public Scale getScale() {
        return scale;
    }

    public void setScale(Scale scale) {
        this.scale = scale;
    }

    public Double getOloteWeight() {
        return oloteWeight;
    }

    public void setOloteWeight(Double oloteWeight) {
        this.oloteWeight = oloteWeight;
    }

    public Double getSampleWeightWithLeaf1() {
        return sampleWeightWithLeaf1;
    }

    public void setSampleWeightWithLeaf1(Double sampleWeightWithLeaf) {
        this.sampleWeightWithLeaf1 = sampleWeightWithLeaf;
    }

    public Double getSampleWeightWithLeaf2() {
        return sampleWeightWithLeaf2;
    }

    public void setSampleWeightWithLeaf2(Double sampleWeightWithLeaf2) {
        this.sampleWeightWithLeaf2 = sampleWeightWithLeaf2;
    }

    public String getVolcador() {
        return volcador;
    }

    public void setVolcador(String volcador) {
        this.volcador = volcador;
    }

    public String getQualityControl() {
        return qualityControl;
    }

    public void setQualityControl(String qualityControl) {
        this.qualityControl = qualityControl;
    }

    public String getQualityNameReceive() {
        return qualityNameReceive;
    }

    public void setQualityNameReceive(String qualityNameReceive) {
        this.qualityNameReceive = qualityNameReceive;
    }

    public String getQualityNameShelling() {
        return qualityNameShelling;
    }


    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public void setQualityNameShelling(String qualityNameShelling) {
        this.qualityNameShelling = qualityNameShelling;
    }



}
