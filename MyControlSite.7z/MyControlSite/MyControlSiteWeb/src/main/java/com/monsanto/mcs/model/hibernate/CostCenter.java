package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 31/03/2011
 * Time: 01:08:14 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "COST_CENTER")
public class CostCenter implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_CATALOGS")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "RENT_ID", referencedColumnName = "ID")
    private Rent rent;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "ZONE_ID", referencedColumnName = "ID")
    private Zone zone;

    @Column(name = "PLANT_ID")
    private Long idPlant;

    @Column(name = "CODE")
    private String code;

    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L)
           return;
        this.id = id;
    }

    public Rent getRent() {
        return rent;
    }

    public void setRent(Rent rent) {
        this.rent = rent;
    }

    public Zone getZone() {
        return zone;
    }

    public void setZone(Zone zone) {
        this.zone = zone;
    }

    public Long getIdPlant() {
        return idPlant;
    }

    public void setIdPlant(Long idPlant) {
        this.idPlant = idPlant;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

}
