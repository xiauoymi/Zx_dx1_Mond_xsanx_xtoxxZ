package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 30/03/2011
 * Time: 10:51:38 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "COST_TON")
public class CostTon implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_CATALOGS")
    @Id
    @GeneratedValue(generator="mcsSeq")
    private Long id;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "TRANSPORT_TYPE_ID", referencedColumnName = "ID")
    private TransportType transportType;


    @ManyToOne
    @javax.persistence.JoinColumn(name = "TRANSPORT_SUPPLIER_ID", referencedColumnName = "ID")
    private TransportSupplier transportSupplier;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "ZONE_ID", referencedColumnName = "ID")
    private Zone zone;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "PLANT_TO", referencedColumnName = "ID")
    private Plant plantTo;

    @Column(name = "PLANT_SEASON_ID")
    private Long plantSeasonId;

    @Column(name = "COST")
    private double cost;

    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L)
           return;
        this.id = id;
    }

    public TransportType getTransportType() {
        return transportType;
    }

    public void setTransportType(TransportType transportType) {
        this.transportType = transportType;
    }

    public TransportSupplier getTransportSupplier() {
        return transportSupplier;
    }

    public void setTransportSupplier(TransportSupplier transportSupplier) {
        this.transportSupplier = transportSupplier;
    }

    public Zone getZone() {
        return zone;
    }

    public void setZone(Zone zone) {
        this.zone = zone;
    }

    public Long getPlantSeasonId() {
        return plantSeasonId;
    }

    public void setPlantSeasonId(Long plantSeasonId) {
        this.plantSeasonId = plantSeasonId;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public Plant getPlantTo() {
        return plantTo;
    }

    public void setPlantTo(Plant plantTo) {
        this.plantTo = plantTo;
    }
}
