package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "DRYING_CELL_REPORT")
public class DryingCellReport implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_DRYING_CELL_REPORT_SEQ")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @OneToOne
    @JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
    private Plant plant;

    @OneToOne
    @JoinColumn(name = "CLOSING_CELL_ID", referencedColumnName = "ID")
    private ClosingCellLog closingCellLog;

    @Column (name = "FOLIO")
    private Long folio;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public ClosingCellLog getClosingCellLog() {
        return closingCellLog;
    }

    public void setClosingCellLog(ClosingCellLog closingCellLog) {
        this.closingCellLog = closingCellLog;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public Long getFolio() {
        return folio;
    }

    public void setFolio(Long folio) {
        this.folio = folio;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
