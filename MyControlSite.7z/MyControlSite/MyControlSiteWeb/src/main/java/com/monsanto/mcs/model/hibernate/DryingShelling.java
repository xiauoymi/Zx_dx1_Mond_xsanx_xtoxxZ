package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;
import org.hibernate.annotations.Cascade;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "DRYING_SHELLING")
public class DryingShelling implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_DRYING_SHELLING_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "DRYING_FOLIO")
    private Long dryingFolio;

    @OneToOne
    @JoinColumn(name = "SHELLING_ORDER_ID", referencedColumnName = "SHELLING_ORDER")
    @Cascade({org.hibernate.annotations.CascadeType.SAVE_UPDATE})
    private ShellingOrder shellingOrder;

    @Column (name = "DRYING_START_DATE")
    private Date dryingStartDate;

    @Column (name = "DRYING_END_DATE")
    private Date dryingEndDate;

    @Column (name = "SHELLING_START_DATE")
    private Date shellingStartDate;

    @Column (name = "SHELLING_END_DATE")
    private Date shellingEndDate;

    @OneToOne
    @javax.persistence.JoinColumn(name = "DRYING_CELL_REPORT_ID", referencedColumnName = "ID")
    private DryingCellReport dryingCellReport;

    @Transient
    private Collection<Scale> unloadScales;

    @Column (name = "SHELLING_KG1")
    public Double additionalShellingKg1;

    @Column (name = "SHELLING_KG2")
    public Double additionalShellingKg2;

    @Column (name = "STORAGE1")
    public Double additionalStorage1;

    @Column (name = "STORAGE2")
    public Double additionalStorage2;

    public Date getDryingEndDate() {
        return dryingEndDate;
    }

    public void setDryingEndDate(Date dryingEndDate) {
        this.dryingEndDate = dryingEndDate;
    }

    public Long getDryingFolio() {
        return dryingFolio;
    }

    public void setDryingFolio(Long dryingFolio) {
        this.dryingFolio = dryingFolio;
    }

    public Date getDryingStartDate() {
        return dryingStartDate;
    }

    public void setDryingStartDate(Date dryingStartDate) {
        this.dryingStartDate = dryingStartDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Date getShellingEndDate() {
        return shellingEndDate;
    }

    public void setShellingEndDate(Date shellingEndDate) {
        this.shellingEndDate = shellingEndDate;
    }

    public ShellingOrder getShellingOrder() {
        return shellingOrder;
    }

    public void setShellingOrder(ShellingOrder shellingOrder) {
        this.shellingOrder = shellingOrder;
    }

    public Date getShellingStartDate() {
        return shellingStartDate;
    }

    public void setShellingStartDate(Date shellingStartDate) {
        this.shellingStartDate = shellingStartDate;
    }

    public DryingCellReport getDryingCellReport() {
        return dryingCellReport;
    }

    public void setDryingCellReport(DryingCellReport dryingCellReport) {
        this.dryingCellReport = dryingCellReport;
    }

    public Collection<Scale> getUnloadScales() {
        return unloadScales;
    }

    public void setUnloadScales(Collection<Scale> unloadScales) {
        this.unloadScales = unloadScales;
    }

    public Double getAdditionalShellingKg1() {
        return additionalShellingKg1;
    }

    public void setAdditionalShellingKg1(Double additionalShellingKg1) {
        this.additionalShellingKg1 = additionalShellingKg1;
    }

    public Double getAdditionalShellingKg2() {
        return additionalShellingKg2;
    }

    public void setAdditionalShellingKg2(Double additionalShellingKg2) {
        this.additionalShellingKg2 = additionalShellingKg2;
    }

    public Double getAdditionalStorage1() {
        return additionalStorage1;
    }

    public void setAdditionalStorage1(Double additionalStorage1) {
        this.additionalStorage1 = additionalStorage1;
    }

    public Double getAdditionalStorage2() {
        return additionalStorage2;
    }

    public void setAdditionalStorage2(Double additionalStorage2) {
        this.additionalStorage2 = additionalStorage2;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
