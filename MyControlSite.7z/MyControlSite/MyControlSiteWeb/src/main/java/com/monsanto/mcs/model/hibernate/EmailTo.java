package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 11:03:30 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "EMAIL_TO")
public class EmailTo implements Serializable{

    @SequenceGenerator(name = "mcsSeq", sequenceName = "EMAIL_TO_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
    private Plant plant;

    @Column(name = "MAIL_TYPE")
    private String mailType;
    

    @Column(name = "ADDRESS")
    private String address;


    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id ==0L) {
            return;
        }
        this.id = id;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public String getMailType() {
        return mailType;
    }

    public void setMailType(String mailType) {
        this.mailType = mailType;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }


}
