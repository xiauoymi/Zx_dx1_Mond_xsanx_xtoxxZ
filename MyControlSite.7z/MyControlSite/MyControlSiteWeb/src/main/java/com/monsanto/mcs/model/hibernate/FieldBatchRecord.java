package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 10:58:37 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "FIELD_BATCH_RECORD")
public class FieldBatchRecord implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_MOVTOS")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "DISTANCE_ID", referencedColumnName = "ID")
    private Distance distance;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "PLANTING_RELATION_ID", referencedColumnName = "ID")
    private PlantingRelation plantingRelation;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "SPECIALIST_ID", referencedColumnName = "ID")
    private Specialist specialist;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "TRANSPORT_TYPE_ID", referencedColumnName = "ID")
    private TransportType transportType;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "LOCATION_ID", referencedColumnName = "ID")
    private Location location;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "GROWER_ID", referencedColumnName = "ID")
    private Grower grower;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "HYBRID_ID", referencedColumnName = "ID")
    private Hybrid hybrid;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "SUPERVISOR_ID", referencedColumnName = "ID")
    private Supervisor supervisor;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "RENT_ID", referencedColumnName = "ID")
    private Rent rent;


    @ManyToOne
    @javax.persistence.JoinColumn(name = "PLANT_SEASON_ID", referencedColumnName = "ID")
    private PlantSeason plantSeason;

    @Column(name = "TABLE_NAME")
    private String tableName;

    @Column(name = "ALTITUDE")
    private String altitude;

    @Column(name = "LATITUDE")
    private String latitude;

    @Column(name = "LONGITUDE")
    private String longitude;

    @Column(name = "TOTALS")
    private double totals;

    @Column(name = "FFEMALE")
    private double fFemale;

    @Column(name = "SFEMALE")
    private double sFemale;

    @Column(name = "SPHA")
    private int spha;

    @Column(name = "SOWING_START_FEMALE")
    private Date sowing_start_female;

    @Column(name = "SOWING_START_1_MALE")
    private Date sowing_start_1_male;

    @Column(name = "SOWING_START_2_MALE")
    private Date sowing_start_2_male;

    @Column(name = "SOWING_END_FEMALE")
    private Date sowing_end_female;

    @Column(name = "SOWING_END_1_MALE")
    private Date sowing_end_1_male;

    @Column(name = "SOWING_END_2_MALE")
    private Date sowing_end_2_male;

    @Column(name = "TENTATIVE_START")
    private Date tentativeStart;

    @Column(name = "REAL_SURFACE")
    private double realSurface;

    @Column(name = "VENDOR")
    private String vendor;

    @Column(name = "LOT")
    private long lot;

    @Column(name = "GROWER_ORDER")
    private long growerOrder;

    @Column(name = "PURCHASE_ORDER")
    private long purchaseOrder;

    @Column(name = "DISCARD")
    private double discard;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "CONTRACT")
    private String contract;

    @Column(name = "CONSECUTIVE")
    private String consecutive;

    @OneToOne
    @JoinColumn(name = "COST_CENTER_ID", referencedColumnName = "ID")
    private CostCenter costCenter;

    public PlantSeason getPlantSeason() {
        return plantSeason;
    }

    public void setPlantSeason(PlantSeason plantSeason) {
        this.plantSeason = plantSeason;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L)
           return;
        this.id = id;
    }
    

    public Distance getDistance() {
        return distance;
    }

    public void setDistance(Distance distance) {
        this.distance = distance;
    }

    public PlantingRelation getPlantingRelation() {
        return plantingRelation;
    }

    public void setPlantingRelation(PlantingRelation plantingRelation) {
        this.plantingRelation = plantingRelation;
    }

    public Specialist getSpecialist() {
        return specialist;
    }

    public void setSpecialist(Specialist specialist) {
        this.specialist = specialist;
    }

    public TransportType getTransportType() {
        return transportType;
    }

    public void setTransportType(TransportType transportType) {
        this.transportType = transportType;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    public Grower getGrower() {
        return grower;
    }

    public void setGrower(Grower grower) {
        this.grower = grower;
    }

    public Hybrid getHybrid() {
        return hybrid;
    }

    public void setHybrid(Hybrid hybrid) {
        this.hybrid = hybrid;
    }

    public Rent getRent() {
        return rent;
    }

    public void setRent(Rent rent) {
        this.rent = rent;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public String getAltitude() {
        return altitude;
    }

    public void setAltitude(String altitude) {
        this.altitude = altitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public double getTotals() {
        return totals;
    }

    public void setTotals(double totals) {
        this.totals = totals;
    }

    public double getfFemale() {
        return fFemale;
    }

    public void setfFemale(double fFemale) {
        this.fFemale = fFemale;
    }

    public double getsFemale() {
        return sFemale;
    }

    public void setsFemale(double sFemale) {
        this.sFemale = sFemale;
    }

    public int getSpha() {
        return spha;
    }

    public void setSpha(int spha) {
        this.spha = spha;
    }

    public Date getSowing_start_female() {
        return sowing_start_female;
    }

    public void setSowing_start_female(Date sowing_start_female) {
        this.sowing_start_female = sowing_start_female;
    }

    public Date getSowing_start_1_male() {
        return sowing_start_1_male;
    }

    public void setSowing_start_1_male(Date sowing_start_1_male) {
        this.sowing_start_1_male = sowing_start_1_male;
    }

    public Date getSowing_start_2_male() {
        return sowing_start_2_male;
    }

    public void setSowing_start_2_male(Date sowing_start_2_male) {
        this.sowing_start_2_male = sowing_start_2_male;
    }

    public Date getSowing_end_female() {
        return sowing_end_female;
    }

    public void setSowing_end_female(Date sowing_end_female) {
        this.sowing_end_female = sowing_end_female;
    }

    public Date getSowing_end_1_male() {
        return sowing_end_1_male;
    }

    public void setSowing_end_1_male(Date sowing_end_1_male) {
        this.sowing_end_1_male = sowing_end_1_male;
    }

    public Date getSowing_end_2_male() {
        return sowing_end_2_male;
    }

    public void setSowing_end_2_male(Date sowing_end_2_male) {
        this.sowing_end_2_male = sowing_end_2_male;
    }

    public Date getTentativeStart() {
        return tentativeStart;
    }

    public void setTentativeStart(Date tentativeStart) {
        this.tentativeStart = tentativeStart;
    }

    public Double getRealSurface() {
        return realSurface;
    }

    public void setRealSurface(Double realSurface) {
        this.realSurface = realSurface;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }

    public long getLot() {
        return lot;
    }

    public void setLot(long lot) {
        this.lot = lot;
    }

    public long getGrowerOrder() {
        return growerOrder;
    }

    public void setGrowerOrder(long growerOrder) {
        this.growerOrder = growerOrder;
    }

    public long getPurchaseOrder() {
        return purchaseOrder;
    }

    public void setPurchaseOrder(long purchaseOrder) {
        this.purchaseOrder = purchaseOrder;
    }

    public Double getDiscard() {
        return discard;
    }

    public void setDiscard(Double discard) {
        this.discard = discard;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getContract() {
        return contract;
    }

    public void setContract(String contract) {
        this.contract = contract;
    }

    public Supervisor getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Supervisor supervisor) {
        this.supervisor = supervisor;
    }

    public String getConsecutive() {
        return consecutive;
    }

    public void setConsecutive(String consecutive) {
        this.consecutive = consecutive;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

    public void setCostCenter(CostCenter costCenter) {
        this.costCenter = costCenter;
    }

    public CostCenter getCostCenter() {
        return costCenter;
    }
}
