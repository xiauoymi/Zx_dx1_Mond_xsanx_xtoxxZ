package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 11:38:24 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "FIELD_STAGE")
public class FieldStage implements Serializable{

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "STAGE_ID", referencedColumnName = "ID")
    private Stage stage;

    @Column(name = "STAGE_TYPE")
    private int type;

    @Column(name = "STAGE_DATE")
    private Date dateStage;

    @Column(name = "STAGE_HECTARES")
    private Double hectares;

    @Column(name = "STAGE_RANDOM")
    private boolean isRandomMark;

    @Column(name = "BATCH_ID")
    private long batch;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L)
           return;
        this.id = id;
    }

    public long getBatch() {
        return batch;
    }

    public void setBatch(long batch) {
        this.batch = batch;
    }

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public Date getDateStage() {
        return dateStage;
    }

    public void setDateStage(Date dateStage) {
        this.dateStage = dateStage;
    }

    public Double getHectares() {
        return hectares;
    }

    public void setHectares(Double hectares) {
        this.hectares = hectares;
    }

    public boolean isRandomMark() {
        return isRandomMark;
    }

    public void setRandomMark(boolean randomMark) {
        isRandomMark = randomMark;
    }


    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
}
