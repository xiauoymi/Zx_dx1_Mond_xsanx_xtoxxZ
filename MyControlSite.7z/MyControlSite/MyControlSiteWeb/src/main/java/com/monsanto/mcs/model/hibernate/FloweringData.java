package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 07:56:39 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "FLOWERING_DATA")
public class FloweringData implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SEQ")
    @Id

    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "FIELD_STAGE_ID", referencedColumnName = "ID")
    private FieldStage fieldStage;

    @Column(name = "BATCH_ID")
    private Long batchId;    

    @Column(name = "PLANT_SEASON_ID")
    private Long plantSeasonId;

    @Column(name = "SURFACE")
    private Double surface;

    @Column(name = "SOWING_DATE")
    private Date sowingDate;

    @Column(name = "FERTILE1")
    private Double fertile1;

    @Column(name = "STERILE1")
    private Double sterile1;

    @Column(name = "FERTILE2")
    private Double fertile2;

    @Column(name = "STERILE2")
    private Double sterile2;

    @Column(name = "FERTILE3")
    private Double fertile3;

    @Column(name = "STERILE3")
    private Double sterile3;

    @Column(name = "FERTILE4")
    private Double fertile4;

    @Column(name = "STERILE4")
    private Double sterile4;

    @Column(name = "FERTILE5")
    private Double fertile5;

    @Column(name = "STERILE5")
    private Double sterile5;

    @Column(name = "FERTILE6")
    private Double fertile6;

    @Column(name = "STERILE6")
    private Double sterile6;

    @Column(name = "FERTILE7")
    private Double fertile7;

    @Column(name = "STERILE7")
    private Double sterile7;

    @Column(name = "FERTILE8")
    private Double fertile8;

    @Column(name = "STERILE8")
    private Double sterile8;

    @Column(name = "FERTILE9")
    private Double fertile9;

    @Column(name = "STERILE9")
    private Double sterile9;

    @Column(name = "FERTILE10")
    private Double fertile10;

    @Column(name = "STERILE10")
    private Double sterile10;

    @Column(name = "FERTILE11")
    private Double fertile11;

    @Column(name = "STERILE11")
    private Double sterile11;

    @Column(name = "FERTILE12")
    private Double fertile12;

    @Column(name = "STERILE12")
    private Double sterile12;

    @Column(name = "COMMENTS")
    private String comments;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if(id == 0L)
            return;
        
        this.id = id;
    }

    public FieldStage getFieldStage() {
        return fieldStage;
    }

    public void setFieldStage(FieldStage fieldStage) {
        this.fieldStage = fieldStage;
    }

    public Long getBatchId(){
        return batchId;
    }

    public void setBatchId(Long batchId){
        this.batchId = batchId;
    }

    public Long getPlantSeasonId() {
        return plantSeasonId;
    }

    public void setPlantSeasonId(Long plantSeasonId) {
        this.plantSeasonId = plantSeasonId;
    }

    public Double getSurface() {
        return surface;
    }

    public void setSurface(Double surface) {
        this.surface = surface;
    }

    public Date getSowingDate() {
        return sowingDate;
    }

    public void setSowingDate(Date sowingDate) {
        this.sowingDate = sowingDate;
    }

    public Double getFertile1() {
        return fertile1;
    }

    public void setFertile1(Double fertile1) {
        this.fertile1 = fertile1;
    }

    public Double getSterile1() {
        return sterile1;
    }

    public void setSterile1(Double sterile1) {
        this.sterile1 = sterile1;
    }

    public Double getFertile2() {
        return fertile2;
    }

    public void setFertile2(Double fertile2) {
        this.fertile2 = fertile2;
    }

    public Double getSterile2() {
        return sterile2;
    }

    public void setSterile2(Double sterile2) {
        this.sterile2 = sterile2;
    }

    public Double getFertile3() {
        return fertile3;
    }

    public void setFertile3(Double fertile3) {
        this.fertile3 = fertile3;
    }

    public Double getSterile3() {
        return sterile3;
    }

    public void setSterile3(Double sterile3) {
        this.sterile3 = sterile3;
    }

    public Double getFertile4() {
        return fertile4;
    }

    public void setFertile4(Double fertile4) {
        this.fertile4 = fertile4;
    }

    public Double getSterile4() {
        return sterile4;
    }

    public void setSterile4(Double sterile4) {
        this.sterile4 = sterile4;
    }

    public Double getFertile5() {
        return fertile5;
    }

    public void setFertile5(Double fertile5) {
        this.fertile5 = fertile5;
    }

    public Double getSterile5() {
        return sterile5;
    }

    public void setSterile5(Double sterile5) {
        this.sterile5 = sterile5;
    }

    public Double getFertile6() {
        return fertile6;
    }

    public void setFertile6(Double fertile6) {
        this.fertile6 = fertile6;
    }

    public Double getSterile6() {
        return sterile6;
    }

    public void setSterile6(Double sterile6) {
        this.sterile6 = sterile6;
    }

    public Double getFertile7() {
        return fertile7;
    }

    public void setFertile7(Double fertile7) {
        this.fertile7 = fertile7;
    }

    public Double getSterile7() {
        return sterile7;
    }

    public void setSterile7(Double sterile7) {
        this.sterile7 = sterile7;
    }

    public Double getFertile8() {
        return fertile8;
    }

    public void setFertile8(Double fertile8) {
        this.fertile8 = fertile8;
    }

    public Double getSterile8() {
        return sterile8;
    }

    public void setSterile8(Double sterile8) {
        this.sterile8 = sterile8;
    }

    public Double getFertile9() {
        return fertile9;
    }

    public void setFertile9(Double fertile9) {
        this.fertile9 = fertile9;
    }

    public Double getSterile9() {
        return sterile9;
    }

    public void setSterile9(Double sterile9) {
        this.sterile9 = sterile9;
    }

    public Double getFertile10() {
        return fertile10;
    }

    public void setFertile10(Double fertile10) {
        this.fertile10 = fertile10;
    }

    public Double getSterile10() {
        return sterile10;
    }

    public void setSterile10(Double sterile10) {
        this.sterile10 = sterile10;
    }

    public Double getFertile11() {
        return fertile11;
    }

    public void setFertile11(Double fertile11) {
        this.fertile11 = fertile11;
    }

    public Double getSterile11() {
        return sterile11;
    }

    public void setSterile11(Double sterile11) {
        this.sterile11 = sterile11;
    }

    public Double getFertile12() {
        return fertile12;
    }

    public void setFertile12(Double fertile12) {
        this.fertile12 = fertile12;
    }

    public Double getSterile12() {
        return sterile12;
    }

    public void setSterile12(Double sterile12) {
        this.sterile12 = sterile12;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
