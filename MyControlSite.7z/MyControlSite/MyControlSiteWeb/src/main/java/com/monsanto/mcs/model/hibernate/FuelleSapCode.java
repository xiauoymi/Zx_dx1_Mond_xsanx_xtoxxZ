package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 10:10:46 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "FUELLE_SAP_CODE")
public class FuelleSapCode implements Serializable{

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "CODE")
    private String code;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "FUELLE_ID", referencedColumnName = "ID")
    private Fuelle fuelle;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "BRAND_ID", referencedColumnName = "ID")
    private Brand brand;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "BAG_TYPE_ID", referencedColumnName = "ID")
    private BagType bagType;


    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
           return;
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Fuelle getFuelle() {
        return fuelle;
    }

    public void setFuelle(Fuelle fuelle) {
        this.fuelle = fuelle;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public BagType getBagType() {
        return bagType;
    }

    public void setBagType(BagType bagType) {
        this.bagType = bagType;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
    
}
