package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "GAMET")
public class Gamet implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_GAMET")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "TONS")
    private Double tons;

    @Column(name = "FREQUENCY")
    private Double frequency;

    @Column(name = "PURGE")
    private Boolean purge;

    @Column(name = "OPERATION")
    private Boolean operation;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getFrequency() {
        return frequency;
    }

    public void setFrequency(Double frequency) {
        this.frequency = frequency;
    }

    public Boolean getOperation() {
        return operation;
    }

    public void setOperation(Boolean operation) {
        this.operation = operation;
    }

    public Boolean getPurge() {
        return purge;
    }

    public void setPurge(Boolean purge) {
        this.purge = purge;
    }

    public Double getTons() {
        return tons;
    }

    public void setTons(Double tons) {
        this.tons = tons;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
