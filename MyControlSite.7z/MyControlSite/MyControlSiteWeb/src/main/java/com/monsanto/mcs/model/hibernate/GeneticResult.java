package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 09:21:42 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "GENETIC_RESULT")
public class GeneticResult implements Serializable {

@SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "BDI")
    private Integer bdi;

    @Column(name = "SOWING_DATE")
    private Date date;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "F_SELFS")
    private Double fselfs;

    @Column(name = "M_SELFS")
    private Double mselfs;

    @Column(name = "OFF_TYPE_2")
    private Double offType2;

    @Column(name = "OFF_TYPE_3")
    private Double offType3;

    @Column(name = "OFF_TYPE_T")
    private Double offTypeT;

    @Column(name = "PLANT_SEASON_ID")
    private Long plantSeasonId;

    @Column(name = "VARIANTS")
    private Double variants;

    @Column(name = "QUALITY_STATUS")
    private String qualityStatus;

    @Column(name = "GENETIC_RESULTS_TYPE_ID")
    private Long type;

    /*
    @Column(name = "SEED_SIZE_ID")
    private Long seedSize;
    */

    @OneToOne
    @javax.persistence.JoinColumn(name = "SEED_SIZE_ID", referencedColumnName = "ID")
    private Seed seedSize;

    @Column(name = "T_SELFS")
    private Double tselfs;

    @Column(name = "TEST_NAME")
    private String testName;

    @Column(name = "TEST_NUMBER")
    private Integer testNumber;

    @Column(name = "TOTAL_PURITY")
    private Double totalPurity;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "FIELD_STAGE_ID", referencedColumnName = "ID")
    private FieldStage fieldStage;

    @OneToOne
    @javax.persistence.JoinColumn(name = "QUARANTINE_LOT_ID", referencedColumnName = "ID")
    private QuarantineLot quarantineLot;

    public Seed getSeedSize() {
        return seedSize;
    }

    public void setSeedSize(Seed seedSize) {
        this.seedSize = seedSize;
    }

    public Long getBatchId() {
        return batchId;
    }

    public void setBatchId(Long batchId) {
        this.batchId = batchId;
    }

    @Column(name = "BATCH_ID")
    private Long batchId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L){
            return;
        }
        this.id = id;
    }

    public Long getPlantSeasonId() {
        return plantSeasonId;
    }

    public void setPlantSeasonId(Long plantSeasonId) {
        this.plantSeasonId = plantSeasonId;
    }

    public FieldStage getFieldStage() {
        return fieldStage;
    }

    public void setFieldStage(FieldStage fieldStage) {
        this.fieldStage = fieldStage;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getBdi() {
        return bdi;
    }

    public void setBdi(Integer bdi) {
        this.bdi = bdi;
    }

    /*
    public Long getSeedSize() {
        return seedSize;
    }

    public void setSeedSize(Long seedSize) {
        this.seedSize = seedSize;
    }
    */

    public String getTestName() {
        return testName;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }

    public Integer getTestNumber() {
        return testNumber;
    }

    public void setTestNumber(Integer testNumber) {
        this.testNumber = testNumber;
    }

    public Double getTotalPurity() {
        return totalPurity;
    }

    public void setTotalPurity(Double totalPurity) {
        this.totalPurity = totalPurity;
    }

    public Double getFselfs() {
        return fselfs;
    }

    public void setFselfs(Double fselfs) {
        this.fselfs = fselfs;
    }

    public Double getMselfs() {
        return mselfs;
    }

    public void setMselfs(Double mselfs) {
        this.mselfs = mselfs;
    }

    public Double getTselfs() {
        return tselfs;
    }

    public void setTselfs(Double tselfs) {
        this.tselfs = tselfs;
    }

    public Double getOffType3() {
        return offType3;
    }

    public void setOffType3(Double offType3) {
        this.offType3 = offType3;
    }

    public Double getOffType2() {
        return offType2;
    }

    public void setOffType2(Double offType2) {
        this.offType2 = offType2;
    }

    public Double getOffTypeT() {
        return offTypeT;
    }

    public void setOffTypeT(Double offTypeT) {
        this.offTypeT = offTypeT;
    }

    public Double getVariants() {
        return variants;
    }

    public void setVariants(Double variants) {
        this.variants = variants;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getQualityStatus() {
        return qualityStatus;
    }

    public void setQualityStatus(String qualityStatus) {
        this.qualityStatus = qualityStatus;
    }

    public Long getType() {
        return type;
    }

    public void setType(Long type) {
        this.type = type;
    }

    public QuarantineLot getQuarantineLot() {
        return quarantineLot;
    }

    public void setQuarantineLot(QuarantineLot quarantineLot) {
        this.quarantineLot = quarantineLot;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
        

}
