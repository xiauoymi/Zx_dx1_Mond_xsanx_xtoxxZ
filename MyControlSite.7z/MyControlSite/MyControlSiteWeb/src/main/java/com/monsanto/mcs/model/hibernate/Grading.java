package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "GRADING")
public class Grading implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_GRADING_SEQ")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "CELL")
    private int cell;

    @Column(name = "SILO")
    private String silo;

    @Column(name = "SHELLING_WEIGTH")
    private Double shellingWeigth;

    @Column(name = "SIP_TWEIGTH")
    private Double sipTWeigth;

    @Column(name = "SIP_W100")
    private Double sipW100;

    @Column(name = "SIP_IMPURITIES")
    private Double sipImpurities;

    @Column(name = "PW_TWEIGTH")
    private Double pwTWeigth;

    @Column(name = "PW_W100")
    private Double pwW100;

    @Column(name = "PW_LONG1")
    private Double pwlong1;

    @Column(name = "PW_LONG2")
    private Double pwlong2;

    @Column(name = "PW_IMPURITIES")
    private Double pwImpurities;

    @Column(name = "BW_TWEIGTH")
    private Double bwTWeigth;

    @Column(name = "BW_W100")
    private Double bwW100;

    @Column(name = "BW_LONG1")
    private Double bwlong1;

    @Column(name = "BW_LONG2")
    private Double bwlong2;

    @Column(name = "BW_IMPURITIES")
    private Double bwImpurities;

    @Column(name = "PT_TWEIGTH")
    private Double ptTWeigth;

    @Column(name = "PT_W100")
    private Double ptW100;

    @Column(name = "PT_LONG1")
    private Double ptlong1;

    @Column(name = "PT_LONG2")
    private Double ptlong2;

    @Column(name = "PT_LONG3")
    private Double ptlong3;
    
    @Column(name = "PT_IMPURITIES")
    private Double ptImpurities;

    @Column(name = "BT_TWEIGTH")
    private Double btTWeigth;

    @Column(name = "BT_W100")
    private Double btW100;

    @Column(name = "BT_LONG1")
    private Double btlong1;

    @Column(name = "BT_LONG2")
    private Double btlong2;

    @Column(name = "BT_LONG3")
    private Double btlong3;

    @Column(name = "BT_IMPURITIES")
    private Double btImpurities;

    @Column(name = "SMALL_GRAIN_WEIGTH")
    private Double smallGrainWeigth;

    @Column(name = "FULL_TOTAL_WEIGTH")
    private String fullTotalWeigth;

    @OneToOne
    @JoinColumn(name = "DRYING_SHELLING_ID", referencedColumnName = "ID")
    private DryingShelling dryingShelling;

    @Column(name = "SF_FOLIOS")
    private String sfFolios;

    @Column(name = "FIELD_LOTS")
    private String fieldLots;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getBtImpurities() {
        return btImpurities;
    }

    public void setBtImpurities(Double btImpurities) {
        this.btImpurities = btImpurities;
    }

    public Double getBtlong1() {
        return btlong1;
    }

    public void setBtlong1(Double btlong1) {
        this.btlong1 = btlong1;
    }

    public Double getBtlong2() {
        return btlong2;
    }

    public void setBtlong2(Double btlong2) {
        this.btlong2 = btlong2;
    }

    public Double getBtTWeigth() {
        return btTWeigth;
    }

    public void setBtTWeigth(Double btTWeigth) {
        this.btTWeigth = btTWeigth;
    }

    public Double getBtW100() {
        return btW100;
    }

    public void setBtW100(Double btW100) {
        this.btW100 = btW100;
    }

    public Double getBwImpurities() {
        return bwImpurities;
    }

    public void setBwImpurities(Double bwImpurities) {
        this.bwImpurities = bwImpurities;
    }

    public Double getBwlong1() {
        return bwlong1;
    }

    public void setBwlong1(Double bwlong1) {
        this.bwlong1 = bwlong1;
    }

    public Double getBwlong2() {
        return bwlong2;
    }

    public void setBwlong2(Double bwlong2) {
        this.bwlong2 = bwlong2;
    }

    public Double getBwTWeigth() {
        return bwTWeigth;
    }

    public void setBwTWeigth(Double bwTWeigth) {
        this.bwTWeigth = bwTWeigth;
    }

    public Double getBwW100() {
        return bwW100;
    }

    public void setBwW100(Double bwW100) {
        this.bwW100 = bwW100;
    }

    public int getCell() {
        return cell;
    }

    public void setCell(int cell) {
        this.cell = cell;
    }

    public String getFullTotalWeigth() {
        return fullTotalWeigth;
    }

    public void setFullTotalWeigth(String fullTotalWeigth) {
        this.fullTotalWeigth = fullTotalWeigth;
    }

    public Double getPtImpurities() {
        return ptImpurities;
    }

    public void setPtImpurities(Double ptImpurities) {
        this.ptImpurities = ptImpurities;
    }

    public Double getPtlong1() {
        return ptlong1;
    }

    public void setPtlong1(Double ptlong1) {
        this.ptlong1 = ptlong1;
    }

    public Double getPtlong2() {
        return ptlong2;
    }

    public void setPtlong2(Double ptlong2) {
        this.ptlong2 = ptlong2;
    }

    public Double getPtTWeigth() {
        return ptTWeigth;
    }

    public void setPtTWeigth(Double ptTWeigth) {
        this.ptTWeigth = ptTWeigth;
    }

    public Double getPtW100() {
        return ptW100;
    }

    public void setPtW100(Double ptW100) {
        this.ptW100 = ptW100;
    }

    public Double getPwImpurities() {
        return pwImpurities;
    }

    public void setPwImpurities(Double pwImpurities) {
        this.pwImpurities = pwImpurities;
    }

    public Double getPwlong1() {
        return pwlong1;
    }

    public void setPwlong1(Double pwlong1) {
        this.pwlong1 = pwlong1;
    }

    public Double getPwlong2() {
        return pwlong2;
    }

    public void setPwlong2(Double pwlong2) {
        this.pwlong2 = pwlong2;
    }

    public Double getPwTWeigth() {
        return pwTWeigth;
    }

    public void setPwTWeigth(Double pwTWeigth) {
        this.pwTWeigth = pwTWeigth;
    }

    public Double getPwW100() {
        return pwW100;
    }

    public void setPwW100(Double pwW100) {
        this.pwW100 = pwW100;
    }

    public Double getShellingWeigth() {
        return shellingWeigth;
    }

    public void setShellingWeigth(Double shellingWeigth) {
        this.shellingWeigth = shellingWeigth;
    }

    public String getSilo() {
        return silo;
    }

    public void setSilo(String silo) {
        this.silo = silo;
    }

    public Double getSipImpurities() {
        return sipImpurities;
    }

    public void setSipImpurities(Double sipImpurities) {
        this.sipImpurities = sipImpurities;
    }

    public Double getSipTWeigth() {
        return sipTWeigth;
    }

    public void setSipTWeigth(Double sipTWeigth) {
        this.sipTWeigth = sipTWeigth;
    }

    public Double getSipW100() {
        return sipW100;
    }

    public void setSipW100(Double sipW100) {
        this.sipW100 = sipW100;
    }

    public Double getSmallGrainWeigth() {
        return smallGrainWeigth;
    }

    public void setSmallGrainWeigth(Double smallGrainWeigth) {
        this.smallGrainWeigth = smallGrainWeigth;
    }

    public DryingShelling getDryingShelling() {
        return dryingShelling;
    }

    public void setDryingShelling(DryingShelling dryingShelling) {
        this.dryingShelling = dryingShelling;
    }

    public String getFieldLots() {
        return fieldLots;
    }

    public void setFieldLots(String fieldLots) {
        this.fieldLots = fieldLots;
    }

    public String getSfFolios() {
        return sfFolios;
    }

    public void setSfFolios(String sfFolios) {
        this.sfFolios = sfFolios;
    }

    public Double getBtlong3() {
        return btlong3;
    }

    public void setBtlong3(Double btlong3) {
        this.btlong3 = btlong3;
    }

    public Double getPtlong3() {
        return ptlong3;
    }

    public void setPtlong3(Double ptlong3) {
        this.ptlong3 = ptlong3;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
