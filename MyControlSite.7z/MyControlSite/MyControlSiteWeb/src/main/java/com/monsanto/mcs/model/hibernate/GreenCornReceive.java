package com.monsanto.mcs.model.hibernate;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "GREEN_CORN_RECEIVE_VW")
public class GreenCornReceive {

    @EmbeddedId
    private GreenCornReceivePk pk;

    @Column(name = "DAY_TRUCK_NUMBER")
    private Integer dayTruckNumber;

    @Column(name = "LOT_TRUCK_NUMBER")
    private Integer lotTruckNumber;

    @Column(name = "TRANSPORT_SUPPLIER")
    private String transportSupplier;

    @Column(name = "TRANSPORT_FOLIO")
    private Integer transportFolio;

    @Column(name = "TRANSPORT_TYPE")
    private String transportType;

    @Column(name = "PLATE")
    private String plate;

    @Column(name = "SPECIALIST")
    private String specialist;

    //@Column(name = "SEND_FORMAT_FOLIO")
    //private String sendFormatFolio;

    @Column(name = "SCALE_TICKET")
    private Long scaleTicket;

    @Column(name = "QUARANTINED")
    private String quarantined;

    @Column(name = "GROWER")
    private String grower;

    @Column(name = "VENDOR")
    private Long vendor;

    @Column(name = "END_OF_LOT")
    private String endOfLot;

    @Column(name = "SEND_DATE")
    private String sendDate;

    @Column(name = "SEND_HOUR")
    private String sendHour;

    @Column(name = "ENTRY_DATE")
    private String entryDate;

    @Column(name = "ENTRY_HOUR")
    private String entryHour;

    @Column(name = "OUT_PLANT_DATE")
    private String outPlantDate;

    @Column(name = "OUT_PLANT_HOUR")
    private String outPlantHour;

    @Column(name = "TIME_IN_PLANT")
    private String timeInPlant;

    @Column(name = "UNLOAD_START_DATE")
    private String unloadStartDate;

    @Column(name = "UNLOAD_START_HOUR")
    private String unloadStartHour;

    @Column(name = "UNLOAD_END_DATE")
    private String unloadEndDate;

    @Column(name = "UNLOAD_END_HOUR")
    private String unloadEndHour;

    @Column(name = "UNLOAD_TOTAL_TIME")
    private String unloadTotalTime;

    @Column(name = "UNLOADER")
    private String unloader;

    @Column(name = "ENTRY_VS_UNLOAD_TIME")
    private String entryVsUnloadTime;

    @Column(name = "FIELD_WEIGHT")
    private Double fieldWeight;

    @Column(name = "GROSS_WEIGHT")
    private Double grossWeight;

    @Column(name = "TARE_WEIGHT")
    private Double tareWeight;

    @Column(name = "RECEIVED_WEIGHT")
    private Double receivedWeight;

    @Column(name = "FIELD_HUMIDITY")
    private Double fieldHumidity;

    @Column(name = "PLANT_HUMIDITY")
    private Double plantHumidity;

    @Column(name = "FILL")
    private Double fill;

    @Column(name = "MATURITY")
    private Double maturity;

    @Column(name = "MILK_LINE")
    private Double milkLine;

    @Column(name = "TEMPERATURE")
    private Double temperature;

    @Column(name = "KG_SAMPLE_MANUAL")
    private Double kgSampleManual;

    @Column(name = "KG_SAMPLE_MECH")
    private Double kgSampleMech;

    @Column(name = "SHORTAGE")
    private Double Shortage;

    @Column(name = "DRYING_START_DATE")
    private String dryingStartDate;

    @Column(name = "DRYING_START_HOUR")
    private String dryingStartHour;

    @Column(name = "DRYING_END_DATE")
    private String dryingEndDate;

    @Column(name = "DRYING_END_HOUR")
    private String dryingEndHour;

    @Column(name = "DRYING_SPENT_TIME")
    private Integer dryingSpentTime;

    @Column(name = "PLANT_HUMIDITY_AVG")             
    private Double plantHumidityAvg;

    @Column(name = "DRYING_RATE")
    private Double dryingRate;

    @Column(name = "SHELLING_START_DATE")
    private String shellingStartDate;

    @Column(name = "SHELLING_START_HOUR")
    private String shellingStartHour;

    @Column(name = "SHELLING_END_DATE")
    private String shellingEndDate;

    @Column(name = "SHELLING_END_HOUR")
    private String shellingEndHour;

    @Column(name = "SHELLING_SPENT_TIME")
    private String shellingSpentTime;

    @Column(name = "SHELLING_ORDER_ID")
    private Long shellingOrder;

    @Column(name = "SHELLER")
    private String sheller;

    @Column(name = "RECEIVED_WEIGHT_SUM")
    private Double receivedWeightSum;

    @Column(name = "SHELLING_KG")
    private Double shellingKg;

    @Column(name = "TRUCK_SHELLING_KGS")
    private Double truckShellingKg;

    @Column(name = "SILO")
    private String silo;

    @Column(name = "MIXTURE_LOT")
    private String mixtureLot;

    @Column(name = "AVERAGE_HUMIDITY")
    private Double averageHumidity;

    @Column(name = "MOISTURE_ADJUSTMENT_12")
    private Double moistureAdjustment12;

    @Column(name = "SEED_OTHER_COLOR")
    private Double seedOtherColor;

    @Column(name = "DAMAGE_BROKEN")
    private Double damageBroken;

    @Column(name = "INSECT_DAMAGE")
    private Double insectDamage;

    @Column(name = "INNER_MATTER")
    private Double innertMatter;

    @Column(name = "RECEIVED_WEIGHT_PQ")
    private Double receivedWeightPq;

    @Column(name = "HFM")
    private Double hfm;

    @Column(name = "PTM")
    private Double ptm;

    @Column(name = "PGM")
    private Double pgm;

    @Column(name = "TOTAL_LIQUIDAR")
    private Double totalToSettle;

    @Column(name = "YIELD")
    private Double yield;

    @Column(name = "DIF_GROWER_PAYMENT")
    private Double difGrowerPayment;

    @Column(name = "RESULTS_DATE")
    private String resultsDate;

    @Column(name = "PAYMENT_DATE")
    private String paymentDate;

    @Column(name = "SEASON_ID")
    private Integer season;

    @Column(name = "RETURN_PERCENTAGE")
    private Double returnPercentage;

    @Column(name = "MOISTURE_CLOSING_CELL")
    private Double moistureClosingCell;

    @Column(name = "CELL_HEIGHT")
    private Double cellHeight;

    @Column(name = "PLANT_TO")
    private String plantTo;

    @Column(name = "PLANT_TO_ID")
    private Integer plantToId;

    @Column(name = "DRIVER_NAME")
    private String driverName;

    public Double getAverageHumidity() {
        return averageHumidity;
    }

    public void setAverageHumidity(Double averageHumidity) {
        this.averageHumidity = averageHumidity;
    }

    public Double getDamageBroken() {
        return damageBroken;
    }

    public void setDamageBroken(Double damageBroken) {
        this.damageBroken = damageBroken;
    }

    public Integer getDayTruckNumber() {
        return dayTruckNumber;
    }

    public void setDayTruckNumber(Integer dayTruckNumber) {
        this.dayTruckNumber = dayTruckNumber;
    }

    public Double getDifGrowerPayment() {
        return difGrowerPayment;
    }

    public void setDifGrowerPayment(Double difGrowerPayment) {
        this.difGrowerPayment = difGrowerPayment;
    }

    public String getDryingEndDate() {
        return dryingEndDate;
    }

    public void setDryingEndDate(String dryingEndDate) {
        this.dryingEndDate = dryingEndDate;
    }

    public String getDryingEndHour() {
        return dryingEndHour;
    }

    public void setDryingEndHour(String dryingEndHour) {
        this.dryingEndHour = dryingEndHour;
    }

    public Double getDryingRate() {
        return dryingRate;
    }

    public void setDryingRate(Double dryingRate) {
        this.dryingRate = dryingRate;
    }

    public Integer getDryingSpentTime() {
        return dryingSpentTime;
    }

    public void setDryingSpentTime(Integer dryingSpentTime) {
        this.dryingSpentTime = dryingSpentTime;
    }

    public String getDryingStartDate() {
        return dryingStartDate;
    }

    public void setDryingStartDate(String dryingStartDate) {
        this.dryingStartDate = dryingStartDate;
    }

    public String getDryingStartHour() {
        return dryingStartHour;
    }

    public void setDryingStartHour(String dryingStartHour) {
        this.dryingStartHour = dryingStartHour;
    }

    public String getEndOfLot() {
        return endOfLot;
    }

    public void setEndOfLot(String endOfLot) {
        this.endOfLot = endOfLot;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryHour() {
        return entryHour;
    }

    public void setEntryHour(String entryHour) {
        this.entryHour = entryHour;
    }

    public String getEntryVsUnloadTime() {
        return entryVsUnloadTime;
    }

    public void setEntryVsUnloadTime(String entryVsUnloadTime) {
        this.entryVsUnloadTime = entryVsUnloadTime;
    }

    public Double getFieldHumidity() {
        return fieldHumidity;
    }

    public void setFieldHumidity(Double fieldHumidity) {
        this.fieldHumidity = fieldHumidity;
    }

    public Double getFieldWeight() {
        return fieldWeight;
    }

    public void setFieldWeight(Double fieldWeight) {
        this.fieldWeight = fieldWeight;
    }

    public Double getFill() {
        return fill;
    }

    public void setFill(Double fill) {
        this.fill = fill;
    }

    public Double getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(Double grossWeight) {
        this.grossWeight = grossWeight;
    }

    public String getGrower() {
        return grower;
    }

    public void setGrower(String grower) {
        this.grower = grower;
    }

    public Double getHfm() {
        return hfm;
    }

    public void setHfm(Double hfm) {
        this.hfm = hfm;
    }

    public Double getInnertMatter() {
        return innertMatter;
    }

    public void setInnertMatter(Double innertMatter) {
        this.innertMatter = innertMatter;
    }

    public Double getInsectDamage() {
        return insectDamage;
    }

    public void setInsectDamage(Double insectDamage) {
        this.insectDamage = insectDamage;
    }

    public Double getKgSampleManual() {
        return kgSampleManual;
    }

    public void setKgSampleManual(Double kgSampleManual) {
        this.kgSampleManual = kgSampleManual;
    }

    public Double getKgSampleMech() {
        return kgSampleMech;
    }

    public void setKgSampleMech(Double kgSampleMech) {
        this.kgSampleMech = kgSampleMech;
    }

    public Integer getLotTruckNumber() {
        return lotTruckNumber;
    }

    public void setLotTruckNumber(Integer lotTruckNumber) {
        this.lotTruckNumber = lotTruckNumber;
    }

    public Double getMaturity() {
        return maturity;
    }

    public void setMaturity(Double maturity) {
        this.maturity = maturity;
    }

    public Double getMilkLine() {
        return milkLine;
    }

    public void setMilkLine(Double milkLine) {
        this.milkLine = milkLine;
    }

    public String getMixtureLot() {
        return mixtureLot;
    }

    public void setMixtureLot(String mixtureLot) {
        this.mixtureLot = mixtureLot;
    }

    public Double getMoistureAdjustment12() {
        return moistureAdjustment12;
    }

    public void setMoistureAdjustment12(Double moistureAdjustment12) {
        this.moistureAdjustment12 = moistureAdjustment12;
    }

    public String getOutPlantDate() {
        return outPlantDate;
    }

    public void setOutPlantDate(String outPlantDate) {
        this.outPlantDate = outPlantDate;
    }

    public String getOutPlantHour() {
        return outPlantHour;
    }

    public void setOutPlantHour(String outPlantHour) {
        this.outPlantHour = outPlantHour;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Double getPgm() {
        return pgm;
    }

    public void setPgm(Double pgm) {
        this.pgm = pgm;
    }

    public Double getPlantHumidity() {
        return plantHumidity;
    }

    public void setPlantHumidity(Double plantHumidity) {
        this.plantHumidity = plantHumidity;
    }

    public Double getPlantHumidityAvg() {
        return plantHumidityAvg;
    }

    public void setPlantHumidityAvg(Double plantHumidityAvg) {
        this.plantHumidityAvg = plantHumidityAvg;
    }

    public String getPlate() {
        return plate;
    }

    public void setPlate(String plate) {
        this.plate = plate;
    }

    public Double getPtm() {
        return ptm;
    }

    public void setPtm(Double ptm) {
        this.ptm = ptm;
    }

    public String getQuarantined() {
        return quarantined;
    }

    public void setQuarantined(String quarantined) {
        this.quarantined = quarantined;
    }

    public Double getReceivedWeight() {
        return receivedWeight;
    }

    public void setReceivedWeight(Double receivedWeight) {
        this.receivedWeight = receivedWeight;
    }

    public Double getReceivedWeightPq() {
        return receivedWeightPq;
    }

    public void setReceivedWeightPq(Double receivedWeightPq) {
        this.receivedWeightPq = receivedWeightPq;
    }

    public Double getReceivedWeightSum() {
        return receivedWeightSum;
    }

    public void setReceivedWeightSum(Double receivedWeightSum) {
        this.receivedWeightSum = receivedWeightSum;
    }

    public String getResultsDate() {
        return resultsDate;
    }

    public void setResultsDate(String resultsDate) {
        this.resultsDate = resultsDate;
    }

    public Long getScaleTicket() {
        return scaleTicket;
    }

    public void setScaleTicket(Long scaleTicket) {
        this.scaleTicket = scaleTicket;
    }

    public Double getSeedOtherColor() {
        return seedOtherColor;
    }

    public void setSeedOtherColor(Double seedOtherColor) {
        this.seedOtherColor = seedOtherColor;
    }

    public String getSendDate() {
        return sendDate;
    }

    public void setSendDate(String sendDate) {
        this.sendDate = sendDate;
    }
    /*
    public String getSendFormatFolio() {
        return sendFormatFolio;
    }

    public void setSendFormatFolio(String sendFormatFolio) {
        this.sendFormatFolio = sendFormatFolio;
    }
    */
    public String getSendHour() {
        return sendHour;
    }

    public void setSendHour(String sendHour) {
        this.sendHour = sendHour;
    }

    public String getSheller() {
        return sheller;
    }

    public void setSheller(String sheller) {
        this.sheller = sheller;
    }

    public String getShellingEndDate() {
        return shellingEndDate;
    }

    public void setShellingEndDate(String shellingEndDate) {
        this.shellingEndDate = shellingEndDate;
    }

    public Double getShellingKg() {
        return shellingKg;
    }

    public void setShellingKg(Double shellingKg) {
        this.shellingKg = shellingKg;
    }

    public Long getShellingOrder() {
        return shellingOrder;
    }

    public void setShellingOrder(Long shellingOrder) {
        this.shellingOrder = shellingOrder;
    }

    public String getShellingSpentTime() {
        return shellingSpentTime;
    }

    public void setShellingSpentTime(String shellingSpentTime) {
        this.shellingSpentTime = shellingSpentTime;
    }

    public String getShellingStartDate() {
        return shellingStartDate;
    }

    public void setShellingStartDate(String shellingStartDate) {
        this.shellingStartDate = shellingStartDate;
    }

    public Double getShortage() {
        return Shortage;
    }

    public void setShortage(Double shortage) {
        Shortage = shortage;
    }

    public String getSilo() {
        return silo;
    }

    public void setSilo(String silo) {
        this.silo = silo;
    }

    public String getSpecialist() {
        return specialist;
    }

    public void setSpecialist(String specialist) {
        this.specialist = specialist;
    }

    public Double getTareWeight() {
        return tareWeight;
    }

    public void setTareWeight(Double tareWeight) {
        this.tareWeight = tareWeight;
    }

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public String getTimeInPlant() {
        return timeInPlant;
    }

    public void setTimeInPlant(String timeInPlant) {
        this.timeInPlant = timeInPlant;
    }

    public Double getTotalToSettle() {
        return totalToSettle;
    }

    public void setTotalToSettle(Double totalToSettle) {
        this.totalToSettle = totalToSettle;
    }

    public Integer getTransportFolio() {
        return transportFolio;
    }

    public void setTransportFolio(Integer transportFolio) {
        this.transportFolio = transportFolio;
    }

    public String getTransportSupplier() {
        return transportSupplier;
    }

    public void setTransportSupplier(String transportSupplier) {
        this.transportSupplier = transportSupplier;
    }

    public String getTransportType() {
        return transportType;
    }

    public void setTransportType(String transportType) {
        this.transportType = transportType;
    }

    public Double getTruckShellingKg() {
        return truckShellingKg;
    }

    public void setTruckShellingKg(Double truckShellingKg) {
        this.truckShellingKg = truckShellingKg;
    }

    public String getUnloadEndDate() {
        return unloadEndDate;
    }

    public void setUnloadEndDate(String unloadEndDate) {
        this.unloadEndDate = unloadEndDate;
    }

    public String getUnloadEndHour() {
        return unloadEndHour;
    }

    public void setUnloadEndHour(String unloadEndHour) {
        this.unloadEndHour = unloadEndHour;
    }

    public String getUnloader() {
        return unloader;
    }

    public void setUnloader(String unloader) {
        this.unloader = unloader;
    }

    public String getUnloadStartDate() {
        return unloadStartDate;
    }

    public void setUnloadStartDate(String unloadStartDate) {
        this.unloadStartDate = unloadStartDate;
    }

    public String getUnloadStartHour() {
        return unloadStartHour;
    }

    public void setUnloadStartHour(String unloadStartHour) {
        this.unloadStartHour = unloadStartHour;
    }

    public String getUnloadTotalTime() {
        return unloadTotalTime;
    }

    public void setUnloadTotalTime(String unloadTotalTime) {
        this.unloadTotalTime = unloadTotalTime;
    }

    public Long getVendor() {
        return vendor;
    }

    public void setVendor(Long vendor) {
        this.vendor = vendor;
    }

    public Double getYield() {
        return yield;
    }

    public void setYield(Double yield) {
        this.yield = yield;
    }

    public GreenCornReceivePk getPk() {
        return pk;
    }

    public void setPk(GreenCornReceivePk pk) {
        this.pk = pk;
    }

    public Integer getSeason() {
        return season;
    }

    public void setSeason(Integer season) {
        this.season = season;
    }

    public Double getCellHeight() {
        return cellHeight;
    }

    public void setCellHeight(Double cellHeight) {
        this.cellHeight = cellHeight;
    }

    public Double getMoistureClosingCell() {
        return moistureClosingCell;
    }

    public void setMoistureClosingCell(Double moistureClosingCell) {
        this.moistureClosingCell = moistureClosingCell;
    }

    public Double getReturnPercentage() {
        return returnPercentage;
    }

    public void setReturnPercentage(Double returnPercentage) {
        this.returnPercentage = returnPercentage;
    }

    public String getPlantTo() {
        return plantTo;
    }

    public void setPlantTo(String plantTo) {
        this.plantTo = plantTo;
    }

    public Integer getPlantToId() {
        return plantToId;
    }

    public void setPlantToId(Integer plantToId) {
        this.plantToId = plantToId;
    }

    @Column(name = "DRYING_FOLIO", insertable=false, updatable=false, nullable = true)
    private Integer dryingFolio;

    @Column(name = "CELL", insertable=false, updatable=false, nullable = true)
    private Integer cell;

    public Integer getCell() {
        return cell;
    }

    public void setCell(Integer cell) {
        this.cell = cell;
    }

    public Integer getDryingFolio() {
        return dryingFolio;
    }

    public void setDryingFolio(Integer dryingFolio) {
        this.dryingFolio = dryingFolio;
    }

    public String getShellingStartHour() {
        return shellingStartHour;
    }

    public void setShellingStartHour(String shellingStartHour) {
        this.shellingStartHour = shellingStartHour;
    }

    public String getShellingEndHour() {
        return shellingEndHour;
    }

    public void setShellingEndHour(String shellingEndHour) {
        this.shellingEndHour = shellingEndHour;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }
}
