package com.monsanto.mcs.model.hibernate;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;


@Embeddable
public class GreenCornReceivePk implements Serializable {

    @Column(name = "ORIGIN", insertable=false, updatable=false)
    private String origin;

    @Column(name = "HYBRID", insertable=false, updatable=false)
    private String hybrid;

    @Column(name = "LOT_CODE", insertable=false, updatable=false)
    private String lotCode;

    @Column(name = "PLANT_ID", insertable=false, updatable=false)
    private Integer plant;

    @Column(name = "SEND_FORMAT_FOLIO", insertable=false, updatable=false)
    private String sendFormatFolio;

    @Column(name = "UNLOAD_SCALE_ID", insertable=false, updatable=false)
    private Integer unloadScaleId;

    public String getHybrid() {
        return hybrid;
    }

    public void setHybrid(String hybrid) {
        this.hybrid = hybrid;
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }
    
    public Integer getPlant() {
        return plant;
    }

    public void setPlant(Integer plant) {
        this.plant = plant;
    }

    public String getSendFormatFolio() {
        return sendFormatFolio;
    }

    public void setSendFormatFolio(String sendFormatFolio) {
        this.sendFormatFolio = sendFormatFolio;
    }

    public Integer getUnloadScaleId() {
        return unloadScaleId;
    }

    public void setUnloadScaleId(Integer unloadScaleId) {
        this.unloadScaleId = unloadScaleId;
    }

}
