package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;

@Embeddable
public class HarvestedFieldStage implements Serializable {

    @Column(name = "QUARANTINED")
    private Boolean quarantined;

    @Column(name = "FIELD_KG")
    private Double fieldTons;

    @Column(name = "FIELD_HUMIDITY")
    private Double fieldHumidity;

    @Column(name = "HARVEST_IN_CHARGE")
    private String harvestInCharge;

    @Column(name = "END_OF_LOT")
    private Boolean endOfLot;

    @OneToOne
    @JoinColumn(name = "QUARANTINE_ID", referencedColumnName = "ID")
    private Quarantine quarantineType;

    @OneToOne
    @javax.persistence.JoinColumn(name = "FIELD_STAGE_ID", referencedColumnName = "ID")
    private FieldStage fieldStage;

    @OneToOne
    @javax.persistence.JoinColumn(name = "THRESHER_ID", referencedColumnName = "ID")
    private Thresher thresher;

    public Boolean getEndOfLot() {
        return endOfLot;
    }

    public void setEndOfLot(Boolean endOfLot) {
        this.endOfLot = endOfLot;
    }

    public Double getFieldHumidity() {
        return fieldHumidity;
    }

    public void setFieldHumidity(Double fieldHumidity) {
        this.fieldHumidity = fieldHumidity;
    }

    public FieldStage getFieldStage() {
        return fieldStage;
    }

    public void setFieldStage(FieldStage fieldStage) {
        this.fieldStage = fieldStage;
    }

    public Double getFieldTons() {
        return fieldTons;
    }

    public void setFieldTons(Double fieldTons) {
        this.fieldTons = fieldTons;
    }

    public String getHarvestInCharge() {
        return harvestInCharge;
    }

    public void setHarvestInCharge(String harvestInCharge) {
        this.harvestInCharge = harvestInCharge;
    }

    public Thresher getThresher() {
        return thresher;
    }

    public void setThresher(Thresher thresher) {
        this.thresher = thresher;
    }

    public Boolean getQuarantined() {
        return quarantined;
    }

    public void setQuarantined(Boolean quarantined) {
        this.quarantined = quarantined;
    }

    public Quarantine getQuarantineType() {
        return quarantineType;
    }

    public void setQuarantineType(Quarantine quarantineType) {
        this.quarantineType = quarantineType;
    }

    public String toString() {
        String value = "\nquarantined=" + quarantined + " " +
                       "fieldTons="   + fieldTons + " " +
                       "fieldHumidity=" + fieldHumidity + " " +
                       "harvestInCharge=" + harvestInCharge + " " +
                       "endOfLot=" + endOfLot + " ";
        return value;
    }

}
