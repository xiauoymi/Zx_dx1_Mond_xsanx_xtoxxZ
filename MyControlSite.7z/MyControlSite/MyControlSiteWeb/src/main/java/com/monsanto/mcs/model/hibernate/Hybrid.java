package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 09:31:15 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "HYBRID")
public class Hybrid implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;


    @ManyToOne
    @javax.persistence.JoinColumn(name = "PLANT_SEASON_ID", referencedColumnName = "ID")
    private PlantSeason plantSeason;

    @Column(name = "NAME")
    private String name;

    @Column(name = "CODE")
    private String code;

    @Column(name = "MATERIAL_NUMBER")
    private Double materialNumber;

    @Column(name = "PAYMENT_FACTOR")
    private String paymentFactor;

    @Column(name = "KIND_OF_CROSS")
    private String kindOfCross;

    @Column(name = "PLAN_PRODUCTION")
    private Double planProduction;

    @Column(name = "SPHA")
    private Integer spHa;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L)
           return;
        this.id = id;
    }


    public PlantSeason getPlantSeason() {
        return plantSeason;
    }

    public void setPlantSeason(PlantSeason plantSeason) {
        this.plantSeason = plantSeason;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Double getMaterialNumber() {
        return materialNumber;
    }

    public void setMaterialNumber(Double materialNumber) {
        this.materialNumber = materialNumber;
    }

    public String getPaymentFactor() {
        return paymentFactor;
    }

    public void setPaymentFactor(String paymentFactor) {
        this.paymentFactor = paymentFactor;
    }

    public String getKindOfCross() {
        return kindOfCross;
    }

    public void setKindOfCross(String kindOfCross) {
        this.kindOfCross = kindOfCross;
    }

    public Double getPlanProduction() {
        return planProduction;
    }

    public void setPlanProduction(Double planProduction) {
        this.planProduction = planProduction;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

    public Integer getSpHa() {
        return spHa;
    }

    public void setSpHa(Integer spHa) {
        this.spHa = spHa;
    }
}
