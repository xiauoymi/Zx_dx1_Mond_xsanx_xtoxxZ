/*
 * Copyright:  Copyright � 2009 Monsanto.  All rights reserved.
 * BBSUser was created on Dec 16, 2009 using Monsanto resources and
 * is the sole property of Monsanto. Any duplication of the code
 * and/or logic is a direct infringement of Monsanto's copyright.
 */
package com.monsanto.mcs.model.hibernate;

import org.apache.commons.lang.StringUtils;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "MCS_USERS")
public class  MCSUser {

  @Id
  @SequenceGenerator(name = "mcsSeqUser", sequenceName = "MCS_SEQ_USER")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "mcsSeqUser")
  @Column(name = "ID")
  private Long id;

  @Column(name = "USER_ID")
  private String userId;

  @Column(name = "FIRST_NAME")
  private String firstName;

  @Column(name = "LAST_NAME")
  private String lastName;

  @Column(name = "MIDDLE_NAME")
  private String middleName;

  @Column(name = "ACTIVE")
  private boolean active;


  public MCSUser() {
  }

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    if (id == 0L)
       return;
    this.id = id;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getMiddleName() {
    return middleName;
  }

  public void setMiddleName(String middleName) {
    this.middleName = middleName;
  }

  public String getFullName() {
    String fullName = firstName;
    if (StringUtils.isNotBlank(this.middleName)) {
      fullName = fullName + " " + this.middleName;
    }
    fullName = fullName + " " + lastName;
    return fullName;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

}
