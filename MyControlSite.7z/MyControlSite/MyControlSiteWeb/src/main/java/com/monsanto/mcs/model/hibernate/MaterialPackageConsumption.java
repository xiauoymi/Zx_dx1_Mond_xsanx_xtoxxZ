package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;

@Entity
@Table(name = "MATERIAL_PACKAGE_CONSUMPTION")
public class MaterialPackageConsumption implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_MATERIAL_PCKGE_CONSUMPTION")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @OneToOne
    @JoinColumn(name = "BRAND_ID", referencedColumnName = "ID")
    private Brand brand;

    @Column(name = "ANALITICAL_LAB")
    private Double analiticalLab;

    @OneToOne
    @JoinColumn(name = "LABEL_SAP_CODE_ID", referencedColumnName = "ID")
    private LabelSapCode labelSapCode;

    @OneToOne
    @JoinColumn(name = "BAGGING_TYPE_ID", referencedColumnName = "ID")
    private BagType bagType;

    @OneToOne
    @JoinColumn(name = "MATERIAL_PACKAGE_ID", referencedColumnName = "ID")
    private MaterialPackage materialPackage;

    @Column(name = "ACTIONS")
    private String actions;

    @Column(name = "COMMENTS")
    private String comments;

    @OneToOne
    @JoinColumn(name = "PLANT_SUPERVISOR_ID", referencedColumnName = "ID")
    private PlantSupervisor plantSupervisor;

    @Transient
    private Collection<BagConsumed> fuelleBagConsumption;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public String getActions() {
        return actions;
    }

    public void setActions(String actions) {
        if (null != actions){
            actions = actions.replace("\\r",",");
        }
        this.actions = actions;
    }

    public Double getAnaliticalLab() {
        return analiticalLab;
    }

    public void setAnaliticalLab(Double analiticalLab) {
        this.analiticalLab = analiticalLab;
    }

    public BagType getBagType() {
        return bagType;
    }

    public void setBagType(BagType bagType) {
        this.bagType = bagType;
    }

    public Brand getBrand() {
        return brand;
    }

    public void setBrand(Brand brand) {
        this.brand = brand;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        if (null != comments){
            comments = comments.replace("\\r",",");
        }
        this.comments = comments;
    }

    public LabelSapCode getLabelSapCode() {
        return labelSapCode;
    }

    public void setLabelSapCode(LabelSapCode labelSapCode) {
        this.labelSapCode = labelSapCode;
    }

    public Collection<BagConsumed> getFuelleBagConsumption() {
        return fuelleBagConsumption;
    }

    public void setFuelleBagConsumption(Collection<BagConsumed> fuelleBagConsumption) {
        this.fuelleBagConsumption = fuelleBagConsumption;
    }

    public MaterialPackage getMaterialPackage() {
        return materialPackage;
    }

    public void setMaterialPackage(MaterialPackage materialPackage) {
        this.materialPackage = materialPackage;
    }

    public PlantSupervisor getPlantSupervisor() {
        return plantSupervisor;
    }

    public void setPlantSupervisor(PlantSupervisor plantSupervisor) {
        this.plantSupervisor = plantSupervisor;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
