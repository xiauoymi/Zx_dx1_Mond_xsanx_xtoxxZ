package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "MIXTURE_LOT")
public class MixtureLot implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_MIXTURE_LOT")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "DESCRIPTION")
    private String description;

    @OneToOne
    @JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
    private Plant plant;

    @OneToOne
    @JoinColumn(name = "SEASON_ID", referencedColumnName = "ID")
    private Season season;

    @OneToOne
    @JoinColumn(name = "ORIGIN_ID", referencedColumnName = "ID")
    private Origin origin;

    @Column(name = "NUMERIC_SEQUENCE")
    private String numericSequence;

    @Column(name = "RESTRICTION")
    private String restriction;

    @OneToOne
    @JoinColumn(name = "BAGGING_ID", referencedColumnName = "ID")
    private Bagging bagging;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getNumericSequence() {
        return numericSequence;
    }

    public void setNumericSequence(String numericSequence) {
        this.numericSequence = numericSequence;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public Season getSeason() {
        return season;
    }

    public void setSeason(Season season) {
        this.season = season;
    }

    public Origin getOrigin() {
        return origin;
    }

    public void setOrigin(Origin origin) {
        this.origin = origin;
    }

    public String getRestriction() {
        return restriction;
    }

    public void setRestriction(String restriction) {
        this.restriction = restriction;
    }

    public Bagging getBagging() {
        return bagging;
    }

    public void setBagging(Bagging bagging) {
        this.bagging = bagging;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
