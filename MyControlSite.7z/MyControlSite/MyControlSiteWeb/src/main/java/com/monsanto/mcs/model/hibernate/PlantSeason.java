package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 7/12/2010
 * Time: 04:55:33 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PLANTSEASON")
public class PlantSeason implements Serializable {
    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_CATALOGS")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
    private Plant plant;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "SEASON_ID", referencedColumnName = "ID")
    private Season season;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L) {
            return;
        }
        this.id = id;
    }

    public Plant getPlant() {
        return this.plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public Season getSeason() {
        return this.season;
    }

    public void setSeason(Season season) {
        this.season = season;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
