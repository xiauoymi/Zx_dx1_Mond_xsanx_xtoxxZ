package com.monsanto.mcs.model.hibernate;


import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.Date;


@Entity
@Table(catalog = "Treater",schema = "dbo",name = "Treatment")
public class PlantTreatmentVI implements Serializable {

    @Id
    @Column(name = "End_Time")
    private Date endTime;

    @Column(name = "Fecha")
    private String fecha;

    @Column(name = "Start_Time")
    private String startTime;

    @Column(name = "Turno")
    private String shift;

    @Column(name = "Process_Order")
    private String processOrder;

    @Column(name = "Variety")
    private String variety;

    @Column(name = "Seed_Size")
    private String seedSize;

    @Column(name = "Bulk_Batch")
    private String bulkBatch;

    @Column(name = "Source_Bin")
    private String sourceBin;

    @Column(name = "Dest_Bin")
    private String destBin;

    @Column(name = "Treater_No")
    private String treaterNo;

    @Column(name = "Y_Cnt1")
    private Integer yCnt1;

    @Column(name = "Y_Cnt2")
    private Integer yCnt2;

    @Column(name = "Y_Cnt3")
    private Integer yCnt3;

    @Column(name = "Y_CntAvg")
    private Integer yCntAvg;

    @Column(name = "Poncho_Rate")
    private Double ponchoRate;

    @Column(name = "T_Cnt1")
    private Integer tCnt1;

    @Column(name = "T_Cnt2")
    private Integer tCnt2;

    @Column(name = "T_Cnt3")
    private Integer tCnt3;

    @Column(name = "T_CntAvg")
    private Integer tCntAvg;

    @Column(name = "Weight")
    private Double weight;

    @Column(name = "Tank1_Name")
    private String tank1Name;

    @Column(name = "Tank1_TWG")
    private Double tank1TWG;

    @Column(name = "Tank1_TW")
    private Double tank1TW;

    @Column(name = "Tank1_RW")
    private Double tank1RW;

    @Column(name = "Tank1_ERR")
    private Double tank1ERR;

    @Column(name = "Tank2_Name")
    private String tank2Name;

    @Column(name = "Tank2_TWG")
    private Double tank2TWG;

    @Column(name = "Tank2_TW")
    private Double tank2TW;

    @Column(name = "Tank2_RW")
    private Double tank2RW;

    @Column(name = "Tank2_ERR")
    private Double tank2ERR;

    @Column(name = "Tank3_Name")
    private String tank3Name;

    @Column(name = "Tank3_TWG")
    private Double tank3TWG;

    @Column(name = "Tank3_TW")
    private Double tank3TW;

    @Column(name = "Tank3_RW")
    private Double tank3RW;

    @Column(name = "Tank3_ERR")
    private Double tank3ERR;

    @Column(name = "Tank4_Name")
    private String tank4Name;

    @Column(name = "Tank4_TWG")
    private Double tank4TWG;

    @Column(name = "Tank4_TW")
    private Double tank4TW;

    @Column(name = "Tank4_RW")
    private Double tank4RW;

    @Column(name = "Tank4_ERR")
    private Double tank4ERR;

    @Column(name = "Powder1_Name")
    private String powder1Name;

    @Column(name = "Powder1_TWG")
    private Double powder1TWG;

    @Column(name = "Powder1_TW")
    private Double powder1TW;

    @Column(name = "Powder1_RW")
    private Double powder1RW;

    @Column(name = "Powder2_Name")
    private String powder2Name;

    @Column(name = "Powder2_TWG")
    private Double powder2TWG;

    @Column(name = "Powder2_TW")
    private Double powder2TW;

    @Column(name = "Powder2_RW")
    private Double powder2RW;

    @Column(name = "Treater_Oper")
    private String treaterOper;

    @Column(name = "Poncho_Tank")
    private Double ponchoTank;

    @Column(name = "Precise_Tank")
    private Double preciseTank;

    @Column(name = "Num_Batches")
    private Double numBatches;

    @Column(name = "Batch_Size")
    private Double batchSize;

    @Column(name = "Lot_Size")
    private Double lotSize;

    @Column(name = "Batch_Recipe_Name")
    private String batchRecipeName;

    @Column(name = "Batch_Recipe_Comment")
    private String batchRecipeComment;

    @Column(name = "Poncho_Accuracy")
    private Double ponchoAccuracy;

    @Column(name = "Precise_Accuracy")
    private Double preciseAccuracy;

    @Column(name = "Finished_Batch1")
    private String finishedBatch1;

    @Column(name = "Finished_Batch2")
    private String finishedBatch2;

    @Column(name = "Finished_Batch3")
    private String finishedBatch3;

    @Column(name = "Finshed_Batch4")
    private String finshedBatch4;

    @Column(name = "Finished_Batch5")
    private String finishedBatch5;

    @Column(name = "Finished_Pack1")
    private String finishedPack1;

    @Column(name = "Finished_Pack2")
    private String finishedPack2;

    @Column(name = "Finished_Pack3")
    private String finishedPack3;

    @Column(name = "Finished_Pack4")
    private String finishedPack4;

    @Column(name = "Finished_Pack5")
    private String finishedPack5;

    @Column(name = "Target_Units1")
    private Integer targetUnits1;

    @Column(name = "Target_Units2")
    private Integer targetUnits2;

    @Column(name = "Target_Units3")
    private Integer targetUnits3;

    @Column(name = "Target_Units4")
    private Integer targetUnits4;

    @Column(name = "Target_Units5")
    private Integer targetUnits5;

    @Column(name = "Avail_Units1")
    private Integer availUnits1;

    @Column(name = "Avail_Units2")
    private Integer availUnits2;

    @Column(name = "Avail_Units3")
    private Integer availUnits3;

    @Column(name = "Avail_Units4")
    private Integer availUnits4;

    @Column(name = "Avail_Units5")
    private Integer availUnits5;

    @Column(name = "Bag_Weight_Kg")
    private Double bagWeightKg;

    @Column(name = "Bag_Weight_Lb")
    private Double bagWeightLb;

    @Column(name = "Finished_Mat1")
    private String finishedMat1;

    @Column(name = "Finished_Mat2")
    private String finishedMat2;

    @Column(name = "Finished_Mat3")
    private String finishedMat3;

    @Column(name = "Finished_Mat4")
    private String finishedMat4;

    @Column(name = "Finished_Mat5")
    private String finishedMat5;

    @Column(name = "Finished_MatDesc1")
    private String finishedMatDesc1;

    @Column(name = "Finished_MatDesc2")
    private String finishedMatDesc2;

    @Column(name = "Finished_MatDesc3")
    private String finishedMatDesc3;

    @Column(name = "Finished_MatDesc4")
    private String finishedMatDesc4;

    @Column(name = "Finished_MatDesc5")
    private String finishedMatDesc5;

    @Column(name = "Finished_Country1")
    private String finishedCountry1;

    @Column(name = "Finished_Country2")
    private String finishedCountry2;

    @Column(name = "Finished_Country3")
    private String finishedCountry3;

    @Column(name = "Finished_Country4")
    private String finishedCountry4;

    @Column(name = "Finished_Country5")
    private String finishedCountry5;

    @Column(name = "TimeStamp")
    private Date timeStamp;


    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public Date getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(Date timeStamp) {
        this.timeStamp = timeStamp;
    }

    public Integer getAvailUnits1() {
        return availUnits1;
    }

    public void setAvailUnits1(Integer availUnits1) {
        this.availUnits1 = availUnits1;
    }

    public Integer getAvailUnits2() {
        return availUnits2;
    }

    public void setAvailUnits2(Integer availUnits2) {
        this.availUnits2 = availUnits2;
    }

    public Integer getAvailUnits3() {
        return availUnits3;
    }

    public void setAvailUnits3(Integer availUnits3) {
        this.availUnits3 = availUnits3;
    }

    public Integer getAvailUnits4() {
        return availUnits4;
    }

    public void setAvailUnits4(Integer availUnits4) {
        this.availUnits4 = availUnits4;
    }

    public Integer getAvailUnits5() {
        return availUnits5;
    }

    public void setAvailUnits5(Integer availUnits5) {
        this.availUnits5 = availUnits5;
    }

    public Double getBagWeightKg() {
        return bagWeightKg;
    }

    public void setBagWeightKg(Double bagWeightKg) {
        this.bagWeightKg = bagWeightKg;
    }

    public Double getBagWeightLb() {
        return bagWeightLb;
    }

    public void setBagWeightLb(Double bagWeightLb) {
        this.bagWeightLb = bagWeightLb;
    }

    public String getBatchRecipeComment() {
        return batchRecipeComment;
    }

    public void setBatchRecipeComment(String batchRecipeComment) {
        this.batchRecipeComment = batchRecipeComment;
    }

    public String getBatchRecipeName() {
        return batchRecipeName;
    }

    public void setBatchRecipeName(String batchRecipeName) {
        this.batchRecipeName = batchRecipeName;
    }

    public Double getBatchSize() {
        return batchSize;
    }

    public void setBatchSize(Double batchSize) {
        this.batchSize = batchSize;
    }

    public String getBulkBatch() {
        return bulkBatch;
    }

    public void setBulkBatch(String bulkBatch) {
        this.bulkBatch = bulkBatch;
    }

    public String getDestBin() {
        return destBin;
    }

    public void setDestBin(String destBin) {
        this.destBin = destBin;
    }

    public String getFinishedBatch1() {
        return finishedBatch1;
    }

    public void setFinishedBatch1(String finishedBatch1) {
        this.finishedBatch1 = finishedBatch1;
    }

    public String getFinishedBatch2() {
        return finishedBatch2;
    }

    public void setFinishedBatch2(String finishedBatch2) {
        this.finishedBatch2 = finishedBatch2;
    }

    public String getFinishedBatch3() {
        return finishedBatch3;
    }

    public void setFinishedBatch3(String finishedBatch3) {
        this.finishedBatch3 = finishedBatch3;
    }

    public String getFinishedBatch5() {
        return finishedBatch5;
    }

    public void setFinishedBatch5(String finishedBatch5) {
        this.finishedBatch5 = finishedBatch5;
    }

    public String getFinishedCountry1() {
        return finishedCountry1;
    }

    public void setFinishedCountry1(String finishedCountry1) {
        this.finishedCountry1 = finishedCountry1;
    }

    public String getFinishedCountry2() {
        return finishedCountry2;
    }

    public void setFinishedCountry2(String finishedCountry2) {
        this.finishedCountry2 = finishedCountry2;
    }

    public String getFinishedCountry3() {
        return finishedCountry3;
    }

    public void setFinishedCountry3(String finishedCountry3) {
        this.finishedCountry3 = finishedCountry3;
    }

    public String getFinishedCountry4() {
        return finishedCountry4;
    }

    public void setFinishedCountry4(String finishedCountry4) {
        this.finishedCountry4 = finishedCountry4;
    }

    public String getFinishedCountry5() {
        return finishedCountry5;
    }

    public void setFinishedCountry5(String finishedCountry5) {
        this.finishedCountry5 = finishedCountry5;
    }

    public String getFinishedMat1() {
        return finishedMat1;
    }

    public void setFinishedMat1(String finishedMat1) {
        this.finishedMat1 = finishedMat1;
    }

    public String getFinishedMat2() {
        return finishedMat2;
    }

    public void setFinishedMat2(String finishedMat2) {
        this.finishedMat2 = finishedMat2;
    }

    public String getFinishedMat3() {
        return finishedMat3;
    }

    public void setFinishedMat3(String finishedMat3) {
        this.finishedMat3 = finishedMat3;
    }

    public String getFinishedMat4() {
        return finishedMat4;
    }

    public void setFinishedMat4(String finishedMat4) {
        this.finishedMat4 = finishedMat4;
    }

    public String getFinishedMat5() {
        return finishedMat5;
    }

    public void setFinishedMat5(String finishedMat5) {
        this.finishedMat5 = finishedMat5;
    }

    public String getFinishedMatDesc1() {
        return finishedMatDesc1;
    }

    public void setFinishedMatDesc1(String finishedMatDesc1) {
        this.finishedMatDesc1 = finishedMatDesc1;
    }

    public String getFinishedMatDesc2() {
        return finishedMatDesc2;
    }

    public void setFinishedMatDesc2(String finishedMatDesc2) {
        this.finishedMatDesc2 = finishedMatDesc2;
    }

    public String getFinishedMatDesc3() {
        return finishedMatDesc3;
    }

    public void setFinishedMatDesc3(String finishedMatDesc3) {
        this.finishedMatDesc3 = finishedMatDesc3;
    }

    public String getFinishedMatDesc4() {
        return finishedMatDesc4;
    }

    public void setFinishedMatDesc4(String finishedMatDesc4) {
        this.finishedMatDesc4 = finishedMatDesc4;
    }

    public String getFinishedMatDesc5() {
        return finishedMatDesc5;
    }

    public void setFinishedMatDesc5(String finishedMatDesc5) {
        this.finishedMatDesc5 = finishedMatDesc5;
    }

    public String getFinishedPack1() {
        return finishedPack1;
    }

    public void setFinishedPack1(String finishedPack1) {
        this.finishedPack1 = finishedPack1;
    }

    public String getFinishedPack2() {
        return finishedPack2;
    }

    public void setFinishedPack2(String finishedPack2) {
        this.finishedPack2 = finishedPack2;
    }

    public String getFinishedPack3() {
        return finishedPack3;
    }

    public void setFinishedPack3(String finishedPack3) {
        this.finishedPack3 = finishedPack3;
    }

    public String getFinishedPack4() {
        return finishedPack4;
    }

    public void setFinishedPack4(String finishedPack4) {
        this.finishedPack4 = finishedPack4;
    }

    public String getFinishedPack5() {
        return finishedPack5;
    }

    public void setFinishedPack5(String finishedPack5) {
        this.finishedPack5 = finishedPack5;
    }

    public String getFinshedBatch4() {
        return finshedBatch4;
    }

    public void setFinshedBatch4(String finshedBatch4) {
        this.finshedBatch4 = finshedBatch4;
    }

    public Double getLotSize() {
        return lotSize;
    }

    public void setLotSize(Double lotSize) {
        this.lotSize = lotSize;
    }

    public Double getNumBatches() {
        return numBatches;
    }

    public void setNumBatches(Double numBatches) {
        this.numBatches = numBatches;
    }

    public Double getPonchoAccuracy() {
        return ponchoAccuracy;
    }

    public void setPonchoAccuracy(Double ponchoAccuracy) {
        this.ponchoAccuracy = ponchoAccuracy;
    }

    public Double getPonchoRate() {
        return ponchoRate;
    }

    public void setPonchoRate(Double ponchoRate) {
        this.ponchoRate = ponchoRate;
    }

    public Double getPonchoTank() {
        return ponchoTank;
    }

    public void setPonchoTank(Double ponchoTank) {
        this.ponchoTank = ponchoTank;
    }

    public String getPowder1Name() {
        return powder1Name;
    }

    public void setPowder1Name(String powder1Name) {
        this.powder1Name = powder1Name;
    }

    public Double getPowder1RW() {
        return powder1RW;
    }

    public void setPowder1RW(Double powder1RW) {
        this.powder1RW = powder1RW;
    }

    public Double getPowder1TW() {
        return powder1TW;
    }

    public void setPowder1TW(Double powder1TW) {
        this.powder1TW = powder1TW;
    }

    public Double getPowder1TWG() {
        return powder1TWG;
    }

    public void setPowder1TWG(Double powder1TWG) {
        this.powder1TWG = powder1TWG;
    }

    public String getPowder2Name() {
        return powder2Name;
    }

    public void setPowder2Name(String powder2Name) {
        this.powder2Name = powder2Name;
    }

    public Double getPowder2RW() {
        return powder2RW;
    }

    public void setPowder2RW(Double powder2RW) {
        this.powder2RW = powder2RW;
    }

    public Double getPowder2TW() {
        return powder2TW;
    }

    public void setPowder2TW(Double powder2TW) {
        this.powder2TW = powder2TW;
    }

    public Double getPowder2TWG() {
        return powder2TWG;
    }

    public void setPowder2TWG(Double powder2TWG) {
        this.powder2TWG = powder2TWG;
    }

    public Double getPreciseAccuracy() {
        return preciseAccuracy;
    }

    public void setPreciseAccuracy(Double preciseAccuracy) {
        this.preciseAccuracy = preciseAccuracy;
    }

    public Double getPreciseTank() {
        return preciseTank;
    }

    public void setPreciseTank(Double preciseTank) {
        this.preciseTank = preciseTank;
    }

    public String getProcessOrder() {
        return processOrder;
    }

    public void setProcessOrder(String processOrder) {
        this.processOrder = processOrder;
    }

    public String getSeedSize() {
        return seedSize;
    }

    public void setSeedSize(String seedSize) {
        this.seedSize = seedSize;
    }

    public String getShift() {
        return shift;
    }

    public void setShift(String shift) {
        this.shift = shift;
    }

    public String getSourceBin() {
        return sourceBin;
    }

    public void setSourceBin(String sourceBin) {
        this.sourceBin = sourceBin;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public Double getTank1ERR() {
        return tank1ERR;
    }

    public void setTank1ERR(Double tank1ERR) {
        this.tank1ERR = tank1ERR;
    }

    public String getTank1Name() {
        return tank1Name;
    }

    public void setTank1Name(String tank1Name) {
        this.tank1Name = tank1Name;
    }

    public Double getTank1RW() {
        return tank1RW;
    }

    public void setTank1RW(Double tank1RW) {
        this.tank1RW = tank1RW;
    }

    public Double getTank1TW() {
        return tank1TW;
    }

    public void setTank1TW(Double tank1TW) {
        this.tank1TW = tank1TW;
    }

    public Double getTank1TWG() {
        return tank1TWG;
    }

    public void setTank1TWG(Double tank1TWG) {
        this.tank1TWG = tank1TWG;
    }

    public Double getTank2ERR() {
        return tank2ERR;
    }

    public void setTank2ERR(Double tank2ERR) {
        this.tank2ERR = tank2ERR;
    }

    public String getTank2Name() {
        return tank2Name;
    }

    public void setTank2Name(String tank2Name) {
        this.tank2Name = tank2Name;
    }

    public Double getTank2RW() {
        return tank2RW;
    }

    public void setTank2RW(Double tank2RW) {
        this.tank2RW = tank2RW;
    }

    public Double getTank2TW() {
        return tank2TW;
    }

    public void setTank2TW(Double tank2TW) {
        this.tank2TW = tank2TW;
    }

    public Double getTank2TWG() {
        return tank2TWG;
    }

    public void setTank2TWG(Double tank2TWG) {
        this.tank2TWG = tank2TWG;
    }

    public Double getTank3ERR() {
        return tank3ERR;
    }

    public void setTank3ERR(Double tank3ERR) {
        this.tank3ERR = tank3ERR;
    }

    public String getTank3Name() {
        return tank3Name;
    }

    public void setTank3Name(String tank3Name) {
        this.tank3Name = tank3Name;
    }

    public Double getTank3RW() {
        return tank3RW;
    }

    public void setTank3RW(Double tank3RW) {
        this.tank3RW = tank3RW;
    }

    public Double getTank3TW() {
        return tank3TW;
    }

    public void setTank3TW(Double tank3TW) {
        this.tank3TW = tank3TW;
    }

    public Double getTank3TWG() {
        return tank3TWG;
    }

    public void setTank3TWG(Double tank3TWG) {
        this.tank3TWG = tank3TWG;
    }

    public Double getTank4ERR() {
        return tank4ERR;
    }

    public void setTank4ERR(Double tank4ERR) {
        this.tank4ERR = tank4ERR;
    }

    public String getTank4Name() {
        return tank4Name;
    }

    public void setTank4Name(String tank4Name) {
        this.tank4Name = tank4Name;
    }

    public Double getTank4RW() {
        return tank4RW;
    }

    public void setTank4RW(Double tank4RW) {
        this.tank4RW = tank4RW;
    }

    public Double getTank4TW() {
        return tank4TW;
    }

    public void setTank4TW(Double tank4TW) {
        this.tank4TW = tank4TW;
    }

    public Double getTank4TWG() {
        return tank4TWG;
    }

    public void setTank4TWG(Double tank4TWG) {
        this.tank4TWG = tank4TWG;
    }

    public Integer getTargetUnits1() {
        return targetUnits1;
    }

    public void setTargetUnits1(Integer targetUnits1) {
        this.targetUnits1 = targetUnits1;
    }

    public Integer getTargetUnits2() {
        return targetUnits2;
    }

    public void setTargetUnits2(Integer targetUnits2) {
        this.targetUnits2 = targetUnits2;
    }

    public Integer getTargetUnits3() {
        return targetUnits3;
    }

    public void setTargetUnits3(Integer targetUnits3) {
        this.targetUnits3 = targetUnits3;
    }

    public Integer getTargetUnits4() {
        return targetUnits4;
    }

    public void setTargetUnits4(Integer targetUnits4) {
        this.targetUnits4 = targetUnits4;
    }

    public Integer getTargetUnits5() {
        return targetUnits5;
    }

    public void setTargetUnits5(Integer targetUnits5) {
        this.targetUnits5 = targetUnits5;
    }

    public Integer gettCnt1() {
        return tCnt1;
    }

    public void settCnt1(Integer tCnt1) {
        this.tCnt1 = tCnt1;
    }

    public Integer gettCnt2() {
        return tCnt2;
    }

    public void settCnt2(Integer tCnt2) {
        this.tCnt2 = tCnt2;
    }

    public Integer gettCnt3() {
        return tCnt3;
    }

    public void settCnt3(Integer tCnt3) {
        this.tCnt3 = tCnt3;
    }

    public Integer gettCntAvg() {
        return tCntAvg;
    }

    public void settCntAvg(Integer tCntAvg) {
        this.tCntAvg = tCntAvg;
    }

    public String getTreaterNo() {
        return treaterNo;
    }

    public void setTreaterNo(String treaterNo) {
        this.treaterNo = treaterNo;
    }

    public String getTreaterOper() {
        return treaterOper;
    }

    public void setTreaterOper(String treaterOper) {
        this.treaterOper = treaterOper;
    }

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety;
    }

    public Double getWeight() {
        return weight;
    }

    public void setWeight(Double weight) {
        this.weight = weight;
    }

    public Integer getyCnt1() {
        return yCnt1;
    }

    public void setyCnt1(Integer yCnt1) {
        this.yCnt1 = yCnt1;
    }

    public Integer getyCnt2() {
        return yCnt2;
    }

    public void setyCnt2(Integer yCnt2) {
        this.yCnt2 = yCnt2;
    }

    public Integer getyCnt3() {
        return yCnt3;
    }

    public void setyCnt3(Integer yCnt3) {
        this.yCnt3 = yCnt3;
    }

    public Integer getyCntAvg() {
        return yCntAvg;
    }

    public void setyCntAvg(Integer yCntAvg) {
        this.yCntAvg = yCntAvg;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
