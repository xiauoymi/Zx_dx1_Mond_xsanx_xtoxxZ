package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "PLANTABILITY_TEST")
public class PlantabilityTest implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_PLANTABILITY_TEST")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "REP1")
    private Double counts1;

    @Column(name = "REP2")
    private Double counts2;

    @Column(name = "REP3")
    private Double counts3;

    @Column(name = "REP_AVG")
    private Double countsAvg;

    @Column(name = "VERIFICATION")
    private Boolean verification;

    @OneToOne
    @JoinColumn(name = "PLATE_ID", referencedColumnName = "ID")
    private Plate plate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getCounts1() {
        return counts1;
    }

    public void setCounts1(Double counts1) {
        this.counts1 = counts1;
    }

    public Double getCounts2() {
        return counts2;
    }

    public void setCounts2(Double counts2) {
        this.counts2 = counts2;
    }

    public Double getCounts3() {
        return counts3;
    }

    public void setCounts3(Double counts3) {
        this.counts3 = counts3;
    }

    public Double getCountsAvg() {
        return countsAvg;
    }

    public void setCountsAvg(Double countsAvg) {
        this.countsAvg = countsAvg;
    }

    public Plate getPlate() {
        return plate;
    }

    public void setPlate(Plate plate) {
        this.plate = plate;
    }

    public Boolean getVerification() {
        return verification;
    }

    public void setVerification(Boolean verification) {
        this.verification = verification;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
