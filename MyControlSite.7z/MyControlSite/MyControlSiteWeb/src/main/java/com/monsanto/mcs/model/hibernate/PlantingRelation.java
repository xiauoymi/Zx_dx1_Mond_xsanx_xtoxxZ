package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 10:29:06 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "PLANTINGRELATION")
public class PlantingRelation implements Serializable{

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "PLANT_ID")
    private Long idPlant;

    @Column(name = "MALE_ROW")
    private int maleRow;

    @Column(name = "FEMALE_ROW")
    private int femaleRow;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L)
           return;
        this.id = id;
    }


    public Long getIdPlant() {
        return idPlant;
    }

    public void setIdPlant(Long idPlant) {
        this.idPlant = idPlant;
    }

    public int getMaleRow() {
        return maleRow;
    }

    public void setMaleRow(int maleRow) {
        this.maleRow = maleRow;
    }

    public int getFemaleRow() {
        return femaleRow;
    }

    public void setFemaleRow(int femaleRow) {
        this.femaleRow = femaleRow;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
