package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "QUALITY_DATA_SHELLING")
public class QualityDataShelling implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_QUALITY_DATA_SHELLING_SEQ")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @OneToOne
    @JoinColumn(name = "DRYING_SHELLING_ID", referencedColumnName = "ID")
    private DryingShelling dryingShelling;

    @OneToOne
    @JoinColumn(name = "UNLOAD_SCALE_ID", referencedColumnName = "ID")
    private Scale unloadScale;

    @OneToOne
    @JoinColumn(name = "SEND_FORMAT_ID", referencedColumnName = "ID")
    private SendFormat sendFormat;

    @Column (name = "SHELLING_HUMIDITY")
    private Double shellingHumidity;

    @Column (name = "VOLUMETRIC_WEIGTH")
    private Double volumetricWeigth;

    @Column (name = "SICK_FADE")
    private Double sickFade;

    @Column (name = "HEALTH")
    private Double health;

    @Column (name = "DAMAGE_BROKEN")
    private Double damageBroken;

    @Column (name = "INSECT_DAMAGE")
    private Double insectDamage;

    @Column (name = "INNER_MATTER")
    private Double inertMatter;

    @Column (name = "SEED_OTHER_COLOR")
    private Double seedOtherColor;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getDamageBroken() {
        return damageBroken;
    }

    public void setDamageBroken(Double damageBroken) {
        this.damageBroken = damageBroken;
    }

    public DryingShelling getDryingShelling() {
        return dryingShelling;
    }

    public void setDryingShelling(DryingShelling dryingShelling) {
        this.dryingShelling = dryingShelling;
    }

    public Double getHealth() {
        return health;
    }

    public void setHealth(Double health) {
        this.health = health;
    }

    public Double getInertMatter() {
        return inertMatter;
    }

    public void setInertMatter(Double inertMatter) {
        this.inertMatter = inertMatter;
    }

    public Double getInsectDamage() {
        return insectDamage;
    }

    public void setInsectDamage(Double insectDamage) {
        this.insectDamage = insectDamage;
    }

    public Double getSeedOtherColor() {
        return seedOtherColor;
    }

    public void setSeedOtherColor(Double seedOtherColor) {
        this.seedOtherColor = seedOtherColor;
    }

    public Double getShellingHumidity() {
        return shellingHumidity;
    }

    public void setShellingHumidity(Double shellingHumidity) {
        this.shellingHumidity = shellingHumidity;
    }

    public Double getSickFade() {
        return sickFade;
    }

    public void setSickFade(Double sickFade) {
        this.sickFade = sickFade;
    }

    public Scale getUnloadScale() {
        return unloadScale;
    }

    public void setUnloadScale(Scale unloadScale) {
        this.unloadScale = unloadScale;
    }

    public SendFormat getSendFormat() {
        return sendFormat;
    }

    public void setSendFormat(SendFormat sendFormat) {
        this.sendFormat = sendFormat;
    }

    public Double getVolumetricWeigth() {
        return volumetricWeigth;
    }

    public void setVolumetricWeigth(Double volumetricWeigth) {
        this.volumetricWeigth = volumetricWeigth;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
