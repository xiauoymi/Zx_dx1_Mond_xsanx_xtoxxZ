package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 10/12/2010
 * Time: 01:36:39 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "QUARANTINE")
public class Quarantine implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "PLANT_ID")
    private Long plantId;

    @Column(name = "TYPE")
    private String type;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if(id == 0L)
            return;
        this.id = id;
    }

    public Long getPlantId() {
        return plantId;
    }

    public void setPlantId(Long plantId) {
        this.plantId = plantId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
}
