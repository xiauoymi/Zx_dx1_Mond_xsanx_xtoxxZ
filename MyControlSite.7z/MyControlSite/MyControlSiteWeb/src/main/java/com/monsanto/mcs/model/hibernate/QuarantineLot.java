package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 13/12/2010
 * Time: 08:53:43 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "QUARANTINE_LOT")
public class QuarantineLot implements Serializable {

@SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "FIELD_STAGE_ID", referencedColumnName = "ID")
    private FieldStage fieldStage;

    //@ManyToOne
    //@javax.persistence.JoinColumn(name = "BATCH_ID", referencedColumnName = "ID")
    @Column(name = "BATCH_ID")
    private Long batchId;

    @Column(name = "PLANT_SEASON_ID")
    private Long plantSeasonId;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "CONTAMINATION_TYPE_ID", referencedColumnName = "ID")
    private ContaminationType contaminationType;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "CONTAMINANT_ID", referencedColumnName = "ID")
    private Contaminant contaminant;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "CONDITION_TYPE_ID", referencedColumnName = "ID")
    private Condition condition;

    @Column(name = "AREA")
    private Double area;

    @Column(name = "COMMENTS")
    private String comments;

    @Column(name = "DISTANCE")
    private Double distance;

    @Column(name = "FERTILE")
    private Double fertile;

    @Column(name = "M1E")
    private Double m1e;

    @Column(name = "M2E")
    private Double m2e;

    @Column(name = "M1F")
    private Double m1f;

    @Column(name = "M2F")
    private Double m2f;

    @Column(name = "POLLE")
    private Double polle;

    //@Column(name = "STATUS")
    @OneToOne
    @javax.persistence.JoinColumn(name = "STATUS", referencedColumnName = "ID")
    private QuarantineStatus status;

    @Column(name = "STERILE")
    private Double sterile;

    @Column(name = "SURFACE")
    private Double surface;

    /*
    @ManyToMany(cascade = CascadeType.ALL)
    @javax.persistence.JoinColumn(name = "QUARANTINE_ID", referencedColumnName = "ID")
    private Collection<Quarantine> quarantineTypes;
    */
    /*
    @Column(name = "QUARANTINE_ID")
    private long quarantineTypes;
    */

    @ManyToOne
    @javax.persistence.JoinColumn(name = "QUARANTINE_TYPE_ID", referencedColumnName = "ID")
    private Quarantine quarantine;

    @Column(name = "CONSECUTIVE")
    private Integer number;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L){
            return;
        }
        this.id = id;
    }

    public Long getPlantSeasonId() {
        return plantSeasonId;
    }

    public void setPlantSeasonId(Long plantSeasonId) {
        this.plantSeasonId = plantSeasonId;
    }

    public FieldStage getFieldStage() {
        return fieldStage;
    }

    public void setFieldStage(FieldStage fieldStage) {
        this.fieldStage = fieldStage;
    }
    /*
    public Collection<Quarantine> getQuarantineTypes() {
        return quarantineTypes;
    }

    public void setQuarantineTypes(Collection<Quarantine> quarantineTypes) {
        this.quarantineTypes = quarantineTypes;
    }
    */

    public Contaminant getContaminant() {
        return contaminant;
    }

    public void setContaminant(Contaminant contaminant) {
        this.contaminant = contaminant;
    }

    public ContaminationType getContaminationType() {
        return contaminationType;
    }

    public void setContaminationType(ContaminationType contaminationType) {
        this.contaminationType = contaminationType;
    }

    public Condition getCondition() {
        return condition;
    }

    public void setCondition(Condition condition) {
        this.condition = condition;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Double getFertile() {
        return fertile;
    }

    public void setFertile(Double fertile) {
        this.fertile = fertile;
    }

    public Double getSterile() {
        return sterile;
    }

    public void setSterile(Double sterile) {
        this.sterile = sterile;
    }

    public Double getM1f() {
        return m1f;
    }

    public void setM1f(Double m1f) {
        this.m1f = m1f;
    }

    public Double getM1e() {
        return m1e;
    }

    public void setM1e(Double m1e) {
        this.m1e = m1e;
    }

    public Double getM2f() {
        return m2f;
    }

    public void setM2f(Double m2f) {
        this.m2f = m2f;
    }

    public Double getM2e() {
        return m2e;
    }

    public void setM2e(Double m2e) {
        this.m2e = m2e;
    }

    public Double getSurface() {
        return surface;
    }

    public void setSurface(Double surface) {
        this.surface = surface;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public Double getArea() {
        return area;
    }

    public void setArea(Double area) {
        this.area = area;
    }

    public Double getPolle() {
        return polle;
    }

    public void setPolle(Double polle) {
        this.polle = polle;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public QuarantineStatus getStatus() {
        return status;
    }

    public void setStatus(QuarantineStatus status) {
        this.status = status;
    }

    public Long getBatchId() {
        return batchId;
    }

    public void setBatchId(Long batchId) {
        this.batchId = batchId;
    }

    public Quarantine getQuarantine() {
        return quarantine;
    }

    public void setQuarantine(Quarantine quarantine) {
        this.quarantine = quarantine;
    }

    /*
    public long getQuarantineTypes() {
        return quarantineTypes;
    }

    public void setQuarantineTypes(long quarantineTypes) {
        this.quarantineTypes = quarantineTypes;
    }
    */

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}