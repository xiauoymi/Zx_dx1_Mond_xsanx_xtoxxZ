package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;

/**
 *
 * @version 1.0
 * @author  Monsanto
 */
@Entity
@Table(name = "QUARANTINE_STATUS")
public class QuarantineStatus implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName="MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "NAME")
    private String name;

    public Long getId(){
        return this.id;
    }


    public String getName(){
        return this.name;
    }

    public void setId(Long newId){
        if (newId == 0L){
            return;
        }
        this.id = newId;
    }

    public void setName(String newSizeCode){
        this.name = newSizeCode;
    }
}
