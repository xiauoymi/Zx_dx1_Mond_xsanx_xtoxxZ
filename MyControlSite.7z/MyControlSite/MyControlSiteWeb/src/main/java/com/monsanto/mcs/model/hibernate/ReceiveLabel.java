package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "RECEIVE_LABEL")
public class ReceiveLabel implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="RECEIVE_LABEL_SEQ")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "PLANT_HUMIDITY")
    private Double plantHumidity;

    @Column(name = "MATURITY")
    private Double maturity;

    @Column(name = "TEMPERATURE")
    private Double temperature;

    @Column(name = "FILL")
    private Double fill;

    @Column(name = "MILK_LINE")
    private Double milkLine;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    @Column(name = "USER_ID")
    private String user;

    @Column(name = "PLANT_ID")
    private Long plant;

    @OneToOne
    @JoinColumn(name = "SEND_FORMAT_ID", referencedColumnName = "ID")
    private SendFormat sendFormat;

    @Column(name = "HEALT")
    private Long health;

    @Column(name = "OUT_OFFTYPE")
    private Long outOffType;

    @Column(name = "OTHER_COLOR")
    private String otherColor;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getFill() {
        return fill;
    }

    public void setFill(Double fill) {
        this.fill = fill;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public Double getMaturity() {
        return maturity;
    }

    public void setMaturity(Double maturity) {
        this.maturity = maturity;
    }

    public Double getMilkLine() {
        return milkLine;
    }

    public void setMilkLine(Double milkLine) {
        this.milkLine = milkLine;
    }

    public Long getPlant() {
        return plant;
    }

    public void setPlant(Long plant) {
        this.plant = plant;
    }

    public Double getPlantHumidity() {
        return plantHumidity;
    }

    public void setPlantHumidity(Double plantHumidity) {
        this.plantHumidity = plantHumidity;
    }

    public SendFormat getSendFormat() {
        return sendFormat;
    }

    public void setSendFormat(SendFormat sendFormat) {
        this.sendFormat = sendFormat;
    }

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Long getHealth() {
        return health;
    }

    public void setHealth(Long health) {
        this.health = health;
    }

    public Long getOutOffType() {
        return outOffType;
    }

    public void setOutOffType(Long outOffType) {
        this.outOffType = outOffType;
    }

    public String getOtherColor() {
        return otherColor;
    }

    public void setOtherColor(String otherColor) {
        this.otherColor = otherColor;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
}
