package com.monsanto.mcs.model.hibernate;

import java.util.Date;

public class Reciba {

    private Integer dayTruckNumber;
    private Integer lotTruckNumber;
    private String transportSupplier;
    private Integer transportFolio;
    private String transportType;
    private String plates;
    private String harvestInCharge;
    private String sendFormatFolio;
    private Integer scaleTicket;
    private String origin;
    private String hybrid;
    private Long lot;
    private String quarantined;
    private String grower;
    private Integer vendor;
    private Boolean endOfLot;
    private String sendDate;
    private String sendHour;
    private String entryDate;
    private String entryHour;
    private String unloadStartDate;
    private String unloadStartHour;
    private String unloadEndDate;
    private String unloadEndHour;
    private String entryVsUnloadTime;
    private String unloadTotalTime;
    private Double fieldEeight;
    private Double grossWeight;
    private Double tareWeight;
    private Double receivedWeight;
    private Integer cell;
    private Double fieldHumidity;
    private Double plantHumidity;
    private Double fill;
    private Double maturity;
    private Double milkLine;
    private Double temperature;
    private Double kgSampleManual;
    private Double kgSampleMech;
    private Double shortage;
    private String dryingStartDate;
    private String dryingStartHOur;
    private String dryingSpentTime;
    private Double plantHumidityAverage;
    private Double dryingRate;
    private String shellingStartDate;
    private String shellingEndDate;
    private String shellingSpentTime;
    private Integer dryingFolio;
    private Integer shellingOrder;
    private Double receivedWeightSum;
    private Double shellingKg;
    private Double truckShellingKg;
    private String silo;
    private String mixtureLot;
    private Double averageHumidity;
    private Double moistureAdjustment12;
    private Double seedOtherColor;
    private Double damageBroken;
    private Double insectDamage;
    private Double innertMatter;
    private Date resultsDate;
    private Date paymentDate;

    public Double getAverageHumidity() {
        return averageHumidity;
    }

    public void setAverageHumidity(Double averageHumidity) {
        this.averageHumidity = averageHumidity;
    }

    public Integer getCell() {
        return cell;
    }

    public void setCell(Integer cell) {
        this.cell = cell;
    }

    public Double getDamageBroken() {
        return damageBroken;
    }

    public void setDamageBroken(Double damageBroken) {
        this.damageBroken = damageBroken;
    }

    public Integer getDayTruckNumber() {
        return dayTruckNumber;
    }

    public void setDayTruckNumber(Integer dayTruckNumber) {
        this.dayTruckNumber = dayTruckNumber;
    }

    public Integer getDryingFolio() {
        return dryingFolio;
    }

    public void setDryingFolio(Integer dryingFolio) {
        this.dryingFolio = dryingFolio;
    }

    public Double getDryingRate() {
        return dryingRate;
    }

    public void setDryingRate(Double dryingRate) {
        this.dryingRate = dryingRate;
    }

    public String getDryingSpentTime() {
        return dryingSpentTime;
    }

    public void setDryingSpentTime(String dryingSpentTime) {
        this.dryingSpentTime = dryingSpentTime;
    }

    public String getDryingStartDate() {
        return dryingStartDate;
    }

    public void setDryingStartDate(String dryingStartDate) {
        this.dryingStartDate = dryingStartDate;
    }

    public String getDryingStartHOur() {
        return dryingStartHOur;
    }

    public void setDryingStartHOur(String dryingStartHOur) {
        this.dryingStartHOur = dryingStartHOur;
    }

    public Boolean getEndOfLot() {
        return endOfLot;
    }

    public void setEndOfLot(Boolean endOfLot) {
        this.endOfLot = endOfLot;
    }

    public String getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(String entryDate) {
        this.entryDate = entryDate;
    }

    public String getEntryHour() {
        return entryHour;
    }

    public void setEntryHour(String entryHour) {
        this.entryHour = entryHour;
    }

    public String getEntryVsUnloadTime() {
        return entryVsUnloadTime;
    }

    public void setEntryVsUnloadTime(String entryVsUnloadTime) {
        this.entryVsUnloadTime = entryVsUnloadTime;
    }

    public Double getFieldEeight() {
        return fieldEeight;
    }

    public void setFieldEeight(Double fieldEeight) {
        this.fieldEeight = fieldEeight;
    }

    public Double getFieldHumidity() {
        return fieldHumidity;
    }

    public void setFieldHumidity(Double fieldHumidity) {
        this.fieldHumidity = fieldHumidity;
    }

    public Double getFill() {
        return fill;
    }

    public void setFill(Double fill) {
        this.fill = fill;
    }

    public Double getGrossWeight() {
        return grossWeight;
    }

    public void setGrossWeight(Double grossWeight) {
        this.grossWeight = grossWeight;
    }

    public String getGrower() {
        return grower;
    }

    public void setGrower(String grower) {
        this.grower = grower;
    }

    public String getHarvestInCharge() {
        return harvestInCharge;
    }

    public void setHarvestInCharge(String harvestInCharge) {
        this.harvestInCharge = harvestInCharge;
    }

    public String getHybrid() {
        return hybrid;
    }

    public void setHybrid(String hybrid) {
        this.hybrid = hybrid;
    }

    public Double getInnertMatter() {
        return innertMatter;
    }

    public void setInnertMatter(Double innertMatter) {
        this.innertMatter = innertMatter;
    }

    public Double getInsectDamage() {
        return insectDamage;
    }

    public void setInsectDamage(Double insectDamage) {
        this.insectDamage = insectDamage;
    }

    public Double getKgSampleManual() {
        return kgSampleManual;
    }

    public void setKgSampleManual(Double kgSampleManual) {
        this.kgSampleManual = kgSampleManual;
    }

    public Double getKgSampleMech() {
        return kgSampleMech;
    }

    public void setKgSampleMech(Double kgSampleMech) {
        this.kgSampleMech = kgSampleMech;
    }

    public Long getLot() {
        return lot;
    }

    public void setLot(Long lot) {
        this.lot = lot;
    }

    public Integer getLotTruckNumber() {
        return lotTruckNumber;
    }

    public void setLotTruckNumber(Integer lotTruckNumber) {
        this.lotTruckNumber = lotTruckNumber;
    }

    public Double getMaturity() {
        return maturity;
    }

    public void setMaturity(Double maturity) {
        this.maturity = maturity;
    }

    public Double getMilkLine() {
        return milkLine;
    }

    public void setMilkLine(Double milkLine) {
        this.milkLine = milkLine;
    }

    public String getMixtureLot() {
        return mixtureLot;
    }

    public void setMixtureLot(String mixtureLot) {
        this.mixtureLot = mixtureLot;
    }

    public Double getMoistureAdjustment12() {
        return moistureAdjustment12;
    }

    public void setMoistureAdjustment12(Double moistureAdjustment12) {
        this.moistureAdjustment12 = moistureAdjustment12;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public Double getPlantHumidity() {
        return plantHumidity;
    }

    public void setPlantHumidity(Double plantHumidity) {
        this.plantHumidity = plantHumidity;
    }

    public Double getPlantHumidityAverage() {
        return plantHumidityAverage;
    }

    public void setPlantHumidityAverage(Double plantHumidityAverage) {
        this.plantHumidityAverage = plantHumidityAverage;
    }

    public String getPlates() {
        return plates;
    }

    public void setPlates(String plates) {
        this.plates = plates;
    }

    public String getQuarantined() {
        return quarantined;
    }

    public void setQuarantined(String quarantined) {
        this.quarantined = quarantined;
    }

    public Double getReceivedWeight() {
        return receivedWeight;
    }

    public void setReceivedWeight(Double receivedWeight) {
        this.receivedWeight = receivedWeight;
    }

    public Double getReceivedWeightSum() {
        return receivedWeightSum;
    }

    public void setReceivedWeightSum(Double receivedWeightSum) {
        this.receivedWeightSum = receivedWeightSum;
    }

    public Date getResultsDate() {
        return resultsDate;
    }

    public void setResultsDate(Date resultsDate) {
        this.resultsDate = resultsDate;
    }

    public Integer getScaleTicket() {
        return scaleTicket;
    }

    public void setScaleTicket(Integer scaleTicket) {
        this.scaleTicket = scaleTicket;
    }

    public Double getSeedOtherColor() {
        return seedOtherColor;
    }

    public void setSeedOtherColor(Double seedOtherColor) {
        this.seedOtherColor = seedOtherColor;
    }

    public String getSendDate() {
        return sendDate;
    }

    public void setSendDate(String sendDate) {
        this.sendDate = sendDate;
    }

    public String getSendFormatFolio() {
        return sendFormatFolio;
    }

    public void setSendFormatFolio(String sendFormatFolio) {
        this.sendFormatFolio = sendFormatFolio;
    }

    public String getSendHour() {
        return sendHour;
    }

    public void setSendHour(String sendHour) {
        this.sendHour = sendHour;
    }

    public String getShellingEndDate() {
        return shellingEndDate;
    }

    public void setShellingEndDate(String shellingEndDate) {
        this.shellingEndDate = shellingEndDate;
    }

    public Double getShellingKg() {
        return shellingKg;
    }

    public void setShellingKg(Double shellingKg) {
        this.shellingKg = shellingKg;
    }

    public Integer getShellingOrder() {
        return shellingOrder;
    }

    public void setShellingOrder(Integer shellingOrder) {
        this.shellingOrder = shellingOrder;
    }

    public String getShellingSpentTime() {
        return shellingSpentTime;
    }

    public void setShellingSpentTime(String shellingSpentTime) {
        this.shellingSpentTime = shellingSpentTime;
    }

    public String getShellingStartDate() {
        return shellingStartDate;
    }

    public void setShellingStartDate(String shellingStartDate) {
        this.shellingStartDate = shellingStartDate;
    }

    public Double getShortage() {
        return shortage;
    }

    public void setShortage(Double shortage) {
        this.shortage = shortage;
    }

    public String getSilo() {
        return silo;
    }

    public void setSilo(String silo) {
        this.silo = silo;
    }

    public Double getTareWeight() {
        return tareWeight;
    }

    public void setTareWeight(Double tareWeight) {
        this.tareWeight = tareWeight;
    }

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public Integer getTransportFolio() {
        return transportFolio;
    }

    public void setTransportFolio(Integer transportFolio) {
        this.transportFolio = transportFolio;
    }

    public String getTransportSupplier() {
        return transportSupplier;
    }

    public void setTransportSupplier(String transportSupplier) {
        this.transportSupplier = transportSupplier;
    }

    public String getTransportType() {
        return transportType;
    }

    public void setTransportType(String transportType) {
        this.transportType = transportType;
    }

    public Double getTruckShellingKg() {
        return truckShellingKg;
    }

    public void setTruckShellingKg(Double truckShellingKg) {
        this.truckShellingKg = truckShellingKg;
    }

    public String getUnloadEndDate() {
        return unloadEndDate;
    }

    public void setUnloadEndDate(String unloadEndDate) {
        this.unloadEndDate = unloadEndDate;
    }

    public String getUnloadEndHour() {
        return unloadEndHour;
    }

    public void setUnloadEndHour(String unloadEndHour) {
        this.unloadEndHour = unloadEndHour;
    }

    public String getUnloadStartDate() {
        return unloadStartDate;
    }

    public void setUnloadStartDate(String unloadStartDate) {
        this.unloadStartDate = unloadStartDate;
    }

    public String getUnloadStartHour() {
        return unloadStartHour;
    }

    public void setUnloadStartHour(String unloadStartHour) {
        this.unloadStartHour = unloadStartHour;
    }

    public String getUnloadTotalTime() {
        return unloadTotalTime;
    }

    public void setUnloadTotalTime(String unloadTotalTime) {
        this.unloadTotalTime = unloadTotalTime;
    }

    public Integer getVendor() {
        return vendor;
    }

    public void setVendor(Integer vendor) {
        this.vendor = vendor;
    }
}
