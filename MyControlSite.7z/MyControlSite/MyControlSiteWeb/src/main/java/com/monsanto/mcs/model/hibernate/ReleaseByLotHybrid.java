package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;
import org.apache.commons.lang.ObjectUtils;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;

@Entity
@Table(name = "RELEASE_BY_LOT_HYBRD_DEV_VW")
public class ReleaseByLotHybrid implements Serializable {

    @Id
    @Column(name = "LOT_CODE")
    private Long lotCode;

    @Column(name = "HYBRID")
    private String hybrid;

    @Column(name = "TRUCKS_TOTAL")
    private Integer trucksTotal;

    @Column(name = "GROWER")
    private String grower;

    @Column(name = "GREEN_CORN_RECEIVED")
    private Double greenCornReceived;

    @Column(name = "SHELLING")
    private Double shelling;

    @Column(name = "PLANT_YIELD")
    private Double plantYield;

    @Column(name = "GROWER_PAYMENT")
    private Double growerPayment;

    @Column(name = "SHELLING_12")
    private Double shelling12;

    @Column(name = "GROWER_PAYMENT_DIF_VS_SHELL_12")
    private Double growerPaymentDifVsShell12;

    @Column(name = "HAS")
    private Double has;

    @Column(name = "PLANT_ID")
    private Integer plant;

    @Column(name = "SEASON_ID")
    private Integer season;

    @Column(name = "LOT_EFFICIENCY")
    private BigDecimal efficency;

    @Column(name = "LOT_UNIT_WEIGHT")
    private BigDecimal unitWeight;

    @Column( name = "MIXLOT_CONSUMPTION_PROGRESS" )
    private Double mixLotConsumptionProgress;

    @Column( name = "HYBRID_SSUS" )
    private Long hybridSsus;

    @Column( name = "SHELLING_STATUS" )
    private String shellingStatus;

    public Double getGreenCornReceived() {
        return greenCornReceived;
    }

    public void setGreenCornReceived(Double greenCornReceived) {
        this.greenCornReceived = greenCornReceived;
    }

    public String getGrower() {
        return grower;
    }

    public void setGrower(String grower) {
        this.grower = grower;
    }

    public Double getGrowerPayment() {
        return growerPayment;
    }

    public void setGrowerPayment(Double growerPayment) {
        this.growerPayment = growerPayment;
    }

    public Double getGrowerPaymentDifVsShell12() {
        return growerPaymentDifVsShell12;
    }

    public void setGrowerPaymentDifVsShell12(Double growerPaymentDifVsShell12) {
        this.growerPaymentDifVsShell12 = growerPaymentDifVsShell12;
    }

    public String getHybrid() {
        return hybrid;
    }

    public void setHybrid(String hybrid) {
        this.hybrid = hybrid;
    }

    public Long getLotCode() {
        return lotCode;
    }

    public void setLotCode(Long lotCode) {
        this.lotCode = lotCode;
    }

    public Double getPlantYield() {
        return plantYield;
    }

    public void setPlantYield(Double plantYield) {
        this.plantYield = plantYield;
    }

    public Double getShelling12() {
        return shelling12;
    }

    public void setShelling12(Double shelling12) {
        this.shelling12 = shelling12;
    }

    public Double getShelling() {
        return shelling;
    }

    public void setShelling(Double shelling) {
        this.shelling = shelling;
    }

    public Integer getTrucksTotal() {
        return trucksTotal;
    }

    public void setTrucksTotal(Integer trucksTotal) {
        this.trucksTotal = trucksTotal;
    }

    public Double getHas() {
        return has;
    }

    public void setHas(Double has) {
        this.has = has;
    }

    public Integer getPlant() {
        return plant;
    }

    public void setPlant(Integer plant) {
        this.plant = plant;
    }

    public Integer getSeason() {
        return season;
    }

    public void setSeason(Integer season) {
        this.season = season;
    }

    public BigDecimal getEfficency() {
        return efficency;
    }

    public void setEfficency(BigDecimal efficency) {
        this.efficency = efficency;
    }

    public BigDecimal getUnitWeight() {
        return unitWeight;
    }

    public void setUnitWeight(BigDecimal unitWeight) {
        this.unitWeight = unitWeight;
    }

    public Long getHybridSsus() {
        return hybridSsus;
    }

    public void setHybridSsus(Long hybridSsus) {
        this.hybridSsus = hybridSsus;
    }

    public Double getMixLotConsumptionProgress() {
        return mixLotConsumptionProgress;
    }

    public void setMixLotConsumptionProgress(Double mixLotConsumptionProgress) {
        this.mixLotConsumptionProgress = mixLotConsumptionProgress;
    }

    public String getShellingStatus() {
        return shellingStatus;
    }

    public void setShellingStatus(String shellingStatus) {
        this.shellingStatus = shellingStatus;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
