package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 16/03/2011
 * Time: 09:38:11 AM
 * To change this template use File | Settings | File Templates.
 */

@Entity
@Table(name = "ROLE")
public class Role implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_SEQ")
    @Id
    @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "NAME")
    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
}
