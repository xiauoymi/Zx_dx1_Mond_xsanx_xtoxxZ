package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "UNLOAD_SCALE")
public class Scale implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_UNLOAD_SCALE_SEQ")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "SCALE_TICKET")
    private Long scaleTicket;

    @Column(name = "OUT_PLANT_DATE")
    private Date outPlantDate;

    @Column(name = "GROSS_WEIGTH")
    private Double grossWeigth;

    @Column(name = "TARE_WEIGTH")
    private Double tareWeigth;

    @Column(name = "RECEIVED_WEIGTH")
    private Double receivedWeigth;

    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    @Column(name = "CELL")
    private int cell;

    @Column(name = "CLOSED")
    private Long closed;

    @Column(name = "EXTRA_COST")
    private double extraCost;

    @Column(name = "BILL_ASSIGNED_BY")
    private String billAssignedBy;

    @Column(name = "BILL_ASSIGNED_DATE")
    private Date billAssignedDate;

    @Column(name = "BILL_NUMBER")
    private String billNumber;
    


    @OneToOne
    @JoinColumn(name = "SEND_FORMAT_ID", referencedColumnName = "ID")
    private SendFormat sendFormat;

    @Embedded
    private Unload unload;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getGrossWeigth() {
        return grossWeigth;
    }

    public void setGrossWeigth(Double grossWeigth) {
        this.grossWeigth = grossWeigth;
    }

    public Date getOutPlantDate() {
        return outPlantDate;
    }

    public void setOutPlantDate(Date outPlantDate) {
        this.outPlantDate = outPlantDate;
    }

    public Double getReceivedWeigth() {
        return receivedWeigth;
    }

    public void setReceivedWeigth(Double receivedWeigth) {
        this.receivedWeigth = receivedWeigth;
    }

    public Long getScaleTicket() {
        return scaleTicket;
    }

    public void setScaleTicket(Long scaleTicket) {
        this.scaleTicket = scaleTicket;
    }

    public SendFormat getSendFormat() {
        return sendFormat;
    }

    public void setSendFormat(SendFormat sendFormat) {
        this.sendFormat = sendFormat;
    }

    public Double getTareWeigth() {
        return tareWeigth;
    }

    public void setTareWeigth(Double tareWeigth) {
        this.tareWeigth = tareWeigth;
    }


    public Unload getUnload() {
        return unload;
    }

    public void setUnload(Unload unload) {
        this.unload = unload;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public int getCell() {
        return cell;
    }

    public void setCell(int cell) {
        this.cell = cell;
    }

    public Long getClosed() {
        return closed;
    }

    public void setClosed(Long closed) {
        this.closed = closed;
    }

    public double getExtraCost() {
        return extraCost;
    }

    public void setExtraCost(double extraCost) {
        this.extraCost = extraCost;
    }

    public String getBillNumber() {
        return billNumber;
    }

    public void setBillNumber(String billNumber) {
        this.billNumber = billNumber;
    }

    public String getBillAssignedBy() {
        return billAssignedBy;
    }

    public void setBillAssignedBy(String billAssignedBy) {
        this.billAssignedBy = billAssignedBy;
    }

    public Date getBillAssignedDate() {
        return billAssignedDate;
    }

    public void setBillAssignedDate(Date billAssignedDate) {
        this.billAssignedDate = billAssignedDate;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
