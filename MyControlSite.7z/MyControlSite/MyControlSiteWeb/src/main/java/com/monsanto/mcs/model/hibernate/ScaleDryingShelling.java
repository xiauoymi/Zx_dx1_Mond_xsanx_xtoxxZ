package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SCALE_DRYING_SHELLING")
public class ScaleDryingShelling implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_SCALE_DRYING_SHELLING_SEQ")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;


    @OneToOne
    @javax.persistence.JoinColumn(name = "DRYING_SHELLING_ID", referencedColumnName = "ID")
    private DryingShelling dryingShelling;

    @OneToOne
    @javax.persistence.JoinColumn(name = "UNLOAD_SCALE_ID", referencedColumnName = "ID")
    private Scale scale;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public DryingShelling getDryingShelling() {
        return dryingShelling;
    }

    public void setDryingShelling(DryingShelling dryingShelling) {
        this.dryingShelling = dryingShelling;
    }

    public Scale getScale() {
        return scale;
    }

    public void setScale(Scale scale) {
        this.scale = scale;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
