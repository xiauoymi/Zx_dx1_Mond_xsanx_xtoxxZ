package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 10:10:46 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "SCHEDULE")
public class Schedule implements Serializable{

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "PLANT_ID")
    private Long idPlant;

    @Column(name = "INITIAL_HOUR")
    private int initialHour;

    @Column(name = "INITIAL_MINUTE")
    private int initialMinute;

    @Column(name = "FINAL_HOUR")
    private int finalHour;

    @Column(name = "FINAL_MINUTE")
    private int finalMinute;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "SHIFT_ID", referencedColumnName = "ID")
    private Shift shift;

    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
           return;
        this.id = id;
    }

    public Long getIdPlant() {
        return idPlant;
    }

    public void setIdPlant(Long plant) {
        this.idPlant = plant;
    }

    public int getInitialHour() {
        return initialHour;
    }

    public void setInitialHour(int initialHour) {
        this.initialHour = initialHour;
    }

    public int getInitialMinute() {
        return initialMinute;
    }

    public void setInitialMinute(int initialMinute) {
        this.initialMinute = initialMinute;
    }

    public int getFinalHour() {
        return finalHour;
    }

    public void setFinalHour(int finalHour) {
        this.finalHour = finalHour;
    }

    public int getFinalMinute() {
        return finalMinute;
    }

    public void setFinalMinute(int finalMinute) {
        this.finalMinute = finalMinute;
    }

    public Shift getShift() {
        return shift;
    }

    public void setShift(Shift shift) {
        this.shift = shift;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
    
}
