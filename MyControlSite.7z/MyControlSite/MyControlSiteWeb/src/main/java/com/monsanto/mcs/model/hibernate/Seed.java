/*
 * Seed
 *
 * My Control Site (MCS) 1.0
 *
 * Date: 02/11/2011
 *
 * Monsanto
 */
package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Seed Entity
 *
 * @version 1.0
 * @author  Monsanto
 */
@Entity
@Table(name = "SEED")
public class Seed implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName="MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "SEED_SIZE")
    private String sizeCode;

    /**
     * Seed ID getter
     * @return ID representation.
     */
    public Long getId(){
        return this.id;
    }

    /**
     * Seed Size Code getter
     * @return String representation of Seed Size.
     */
    public String getSizeCode(){
        return this.sizeCode;
    }

    /**
     * Seed Id setter
     * @param newId
     */
    public void setId(Long newId){
        if (newId == 0L){
            return;
        }
        this.id = newId;
    }

    /**
     * Seed Size Code
     * @param newSizeCode
     */
    public void setSizeCode(String newSizeCode){
        this.sizeCode = newSizeCode;
    }
}
