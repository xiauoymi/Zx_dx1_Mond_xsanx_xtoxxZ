package com.monsanto.mcs.model.hibernate;

import com.monsanto.mcs.util.DateTime;
import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.util.Calendar;
import java.util.Date;

@Entity
@Table(name = "SEED_LOSS_DEHUSKING")
public class SeedLossDehusking {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "SEED_LOSS_DEHUSKING_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "G_SAMPLE_MANUAL")
    private Double kgSampleManual;

    @Column(name = "KG_SAMPLE_MECH")
    private Double kgSampleMech;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    @Column(name = "USER_ID")
    private String user;

    @Column(name = "PLANT_ID")
    private Long plant;

    @OneToOne
    @JoinColumn(name = "SEND_FORMAT_ID", referencedColumnName = "ID")
    private SendFormat sendFormat;

    @Column(name = "RETURN_PERCENTAGE")
    private Double returnPercentage;

    @Transient
    private Date unloadEndDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getKgSampleManual() {
        return kgSampleManual;
    }

    public void setKgSampleManual(Double kgSampleManual) {
        this.kgSampleManual = kgSampleManual;
    }

    public Double getKgSampleMech() {
        return kgSampleMech;
    }

    public void setKgSampleMech(Double kgSampleMech) {
        this.kgSampleMech = kgSampleMech;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public Long getPlant() {
        return plant;
    }

    public void setPlant(Long plant) {
        this.plant = plant;
    }

    public SendFormat getSendFormat() {
        return sendFormat;
    }

    public void setSendFormat(SendFormat sendFormat) {
        this.sendFormat = sendFormat;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Double getReturnPercentage() {
        return returnPercentage;
    }

    public void setReturnPercentage(Double returnPercentage) {
        this.returnPercentage = returnPercentage;
    }

    public Date getUnloadEndDate() {
        return unloadEndDate;
    }

    public void setUnloadEndDate(Date unloadEndDate) {
        this.unloadEndDate = unloadEndDate;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
