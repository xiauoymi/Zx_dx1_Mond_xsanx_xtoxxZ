package com.monsanto.mcs.model.hibernate;

import com.monsanto.mcs.util.DateTime;
import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

@Entity
@Table(name = "SEND_FORMAT")
public class SendFormat implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SENT_FORMAT_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "FOLIO")
    private String sendFormatFolio;

    @Column(name = "ENTRY_DATE")
    private Date entryDate;

    @Column(name = "SENT_DATE")
    private Date sentDate;

    @Column(name = "DAY_TRUCK_NUMBER")
    private Integer dayTruckNumber;

    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    @Column(name = "GRAL_COMMENT")
    private String gralComment;

    @OneToOne
    @JoinColumn(name = "PLANT_TO", referencedColumnName = "ID")
    private Plant plantTo;

    @OneToOne
    @JoinColumn(name = "COMMENTS_ID", referencedColumnName = "ID")
    private Comment comment;

    @Embedded
    private Transport transport;

    @Embedded
    private HarvestedFieldStage harvestedFieldStage;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "BATCH_ID", referencedColumnName = "ID")
    private FieldBatchRecord fieldBatchRecord;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "WARANTY_WEIGHT_ID", referencedColumnName = "ID")
    private WarantyWeight warantyWeight;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "COSTTON_ID", referencedColumnName = "ID")
    private CostTon costTon;

    public Comment getComment() {
        return comment;
    }

    public void setComment(Comment comment) {
        this.comment = comment;
    }

    public HarvestedFieldStage getHarvestedFieldStage() {
        return harvestedFieldStage;
    }

    public void setHarvestedFieldStage(HarvestedFieldStage harvestedFieldStage) {
        this.harvestedFieldStage = harvestedFieldStage;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Plant getPlantTo() {
        return plantTo;
    }

    public void setPlantTo(Plant plantTo) {
        this.plantTo = plantTo;
    }

    public String getSendFormatFolio() {
        return sendFormatFolio;
    }

    public void setSendFormatFolio(String sendFormatFolio) {
        this.sendFormatFolio = sendFormatFolio;
    }

    public Transport getTransport() {
        return transport;
    }

    public void setTransport(Transport transport) {
        this.transport = transport;
    }

    public Date getSentDate() {
        return sentDate;
    }

    public void setSentDate(Date sentDate) {
        this.sentDate = sentDate;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public Integer getDayTruckNumber() {
        return dayTruckNumber;
    }

    public void setDayTruckNumber(Integer dayTruckNumber) {
        this.dayTruckNumber = dayTruckNumber;
    }

    private DateTime getDateTime(Date value){
        DateTime representation = new DateTime();
        Calendar entryCalendar = Calendar.getInstance();
        entryCalendar.setTime(value);
        representation.setDate(value);
        representation.setHour(entryCalendar.get(Calendar.HOUR));
        representation.setMinute(entryCalendar.get(Calendar.MINUTE));
        representation.setAmPm(entryCalendar.get(Calendar.AM_PM));
        return representation;
    }

    public DateTime getEntryDateTime(){
        return getDateTime(this.entryDate);
    }

    public DateTime getSentDateTime(){
        return getDateTime(this.sentDate);
    }

    public FieldBatchRecord getFieldBatchRecord() {
        return fieldBatchRecord;
    }

    public void setFieldBatchRecord(FieldBatchRecord fieldBatchRecord) {
        this.fieldBatchRecord = fieldBatchRecord;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }


    public WarantyWeight getWarantyWeight() {
        return warantyWeight;
    }

    public void setWarantyWeight(WarantyWeight warantyWeight) {
        this.warantyWeight = warantyWeight;
    }


    public  CostTon getCostTon() {
        return costTon;
    }

    public void setCostTon(CostTon costoRecord) {
        costTon = costoRecord;
    }

    public String getGralComment() {
        return gralComment;
    }

    public void setGralComment(String gralComment) {
        this.gralComment = gralComment;
    }

    @Override
    public boolean equals(Object o) {
        return !(null == o || !(o instanceof SendFormat)) && EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

    @Override
    public String toString(){
          return "sendFormatFolio=" + sendFormatFolio + " " +
                 "entryDate=" + entryDate + " " +
                 "sentDate=" + sentDate + " " +
                 "dayTruckNumber=" + dayTruckNumber + " " +
                 "comment=" + comment +
                 "TRANSPORT=" + transport + " " +
                 "HARVESTED_FIELD_STAGE=" + harvestedFieldStage;
    }

}
