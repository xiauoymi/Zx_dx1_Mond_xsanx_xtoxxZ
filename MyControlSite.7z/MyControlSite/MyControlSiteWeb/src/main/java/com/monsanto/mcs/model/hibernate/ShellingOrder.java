package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SHELLING_ORDER")
public class ShellingOrder implements Serializable {

    @Id
    @Column (name = "SHELLING_ORDER")
    private Long shellingOrder;

    @Column (name = "SHELLING_KG")
    private Double shellingKg;

    @Column (name = "DRYING_FOLIO")
    private Long dryingFolio;

    @Column (name = "SILO")
    private String silo;

    @Column (name = "MIXTURE_LOT")
    private String mixtureLot;

    @Column (name = "MIXTURE_LOT_DSC")
    private String mixtureLotDsc;

    @OneToOne
    @JoinColumn(name = "SHELLER_ID", referencedColumnName = "ID")
    private Sheller sheller;

    @OneToOne
    @JoinColumn(name = "HYBRID_ID", referencedColumnName = "ID")
    @Basic(fetch = FetchType.EAGER)    
    private Hybrid hybrid;

    @Column (name = "MOISTURE_S1")
    private Double moistureShS1;

    @Column (name = "MOISTURE_S2")
    private Double moistureShS2;

    @Column (name = "MOISTURE_S3")
    private Double moistureShS3;

    @Column (name = "AVERAGE")
    private Double average;

    @Column (name = "COMMENTS")
    private String comments;

    @Column (name = "SHELLING_HUMIDITY")
    private Double shellingHumidity;

    @Column (name = "VOLUMETRIC_WEIGTH")
    private Double volumetricWeigth;

    @Column (name = "SICK_FADE")
    private Double sickFade;

    @Column (name = "HEALTH")
    private Double health;

    @Column (name = "DAMAGE_BROKEN")
    private Double damageBroken;

    @Column (name = "INSECT_DAMAGE")
    private Double insectDamage;

    @Column (name = "INNER_MATTER")
    private Double inertMatter;

    @Column (name = "SEED_OTHER_COLOR")
    private Double seedOtherColor;

    @Column (name = "HYBRID_ID_SAP")
    private String acronym;

    @Column (name = "MOISTURE_CLOSING_CELL")
    private Double moistureClosingCell;

    @Column (name = "CELL_HEIGHT")
    private Double cellHeight;

    public Double getAverage() {
        return average;
    }

    public void setAverage(Double average) {
        this.average = average;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Hybrid getHybrid() {
        return hybrid;
    }

    public void setHybrid(Hybrid hybrid) {
        this.hybrid = hybrid;
    }

    public String getMixtureLot() {
        return mixtureLot;
    }

    public void setMixtureLot(String mixtureLot) {
        this.mixtureLot = mixtureLot;
    }

    public String getMixtureLotDsc() {
        return mixtureLotDsc;
    }

    public void setMixtureLotDsc(String mixtureLotDsc) {
        this.mixtureLotDsc = mixtureLotDsc;
    }

    public Double getMoistureShS1() {
        return moistureShS1;
    }

    public void setMoistureShS1(Double moistureShS1) {
        this.moistureShS1 = moistureShS1;
    }

    public Double getMoistureShS2() {
        return moistureShS2;
    }

    public void setMoistureShS2(Double moistureShS2) {
        this.moistureShS2 = moistureShS2;
    }

    public Double getMoistureShS3() {
        return moistureShS3;
    }

    public void setMoistureShS3(Double moistureShS3) {
        this.moistureShS3 = moistureShS3;
    }

    public Sheller getSheller() {
        return sheller;
    }

    public void setSheller(Sheller sheller) {
        this.sheller = sheller;
    }

    public Double getShellingKg() {
        return shellingKg;
    }

    public void setShellingKg(Double shellingKg) {
        this.shellingKg = shellingKg;
    }

    public Long getShellingOrder() {
        return shellingOrder;
    }

    public void setShellingOrder(Long shellingOrder) {
        this.shellingOrder = shellingOrder;
    }

    public String getSilo() {
        return silo;
    }

    public void setSilo(String silo) {
        this.silo = silo;
    }

    public Long getDryingFolio() {
        return dryingFolio;
    }

    public void setDryingFolio(Long dryingFolio) {
        this.dryingFolio = dryingFolio;
    }

    public Double getDamageBroken() {
        return damageBroken;
    }

    public void setDamageBroken(Double damageBroken) {
        this.damageBroken = damageBroken;
    }

    public Double getHealth() {
        return health;
    }

    public void setHealth(Double health) {
        this.health = health;
    }

    public Double getInertMatter() {
        return inertMatter;
    }

    public void setInertMatter(Double inertMatter) {
        this.inertMatter = inertMatter;
    }

    public Double getInsectDamage() {
        return insectDamage;
    }

    public void setInsectDamage(Double insectDamage) {
        this.insectDamage = insectDamage;
    }

    public Double getSeedOtherColor() {
        return seedOtherColor;
    }

    public void setSeedOtherColor(Double seedOtherColor) {
        this.seedOtherColor = seedOtherColor;
    }

    public Double getShellingHumidity() {
        return shellingHumidity;
    }

    public void setShellingHumidity(Double shellingHumidity) {
        this.shellingHumidity = shellingHumidity;
    }

    public Double getSickFade() {
        return sickFade;
    }

    public void setSickFade(Double sickFade) {
        this.sickFade = sickFade;
    }

    public Double getVolumetricWeigth() {
        return volumetricWeigth;
    }

    public void setVolumetricWeigth(Double volumetricWeigth) {
        this.volumetricWeigth = volumetricWeigth;
    }

    public String getAcronym() {
        return acronym;
    }

    public void setAcronym(String acronym) {
        this.acronym = acronym;
    }

    public Double getCellHeight() {
        return cellHeight;
    }

    public void setCellHeight(Double cellHeight) {
        this.cellHeight = cellHeight;
    }

    public Double getMoistureClosingCell() {
        return moistureClosingCell;
    }

    public void setMoistureClosingCell(Double moistureClosingCell) {
        this.moistureClosingCell = moistureClosingCell;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
