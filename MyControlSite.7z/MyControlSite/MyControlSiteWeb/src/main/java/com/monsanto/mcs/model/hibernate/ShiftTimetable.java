package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SHIFT_TIMETABLE")
public class ShiftTimetable implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_CATALOGS")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "START_HOUR")
    private Integer startHour;

    @Column(name = "START_MINUTE")
    private Integer startMinute;

    @Column(name = "END_HOUR")
    private Integer endHour;

    @Column(name = "END_MINUTE")
    private Integer endMinute;

    @OneToOne
    @JoinColumn(name = "SHIFT_ID", referencedColumnName = "ID")
    private Shift shift;

    @OneToOne
    @JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
    private Plant plant;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public int getEndHour() {
        return endHour;
    }

    public void setEndHour(int endHour) {
        this.endHour = endHour;
    }

    public int getEndMinute() {
        return endMinute;
    }

    public void setEndMinute(int endMinute) {
        this.endMinute = endMinute;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    public Shift getShift() {
        return shift;
    }

    public void setShift(Shift shift) {
        this.shift = shift;
    }

    public int getStartHour() {
        return startHour;
    }

    public void setStartHour(int startHour) {
        this.startHour = startHour;
    }

    public int getStartMinute() {
        return startMinute;
    }

    public void setStartMinute(int startMinute) {
        this.startMinute = startMinute;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
