package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "SNICS_LABEL")
public class SnicsLabel implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_SNICS_LABEL")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "INITIAL_FOLIO")
    private Double initialFolio;

    @Column(name = "FINAL_FOLIO")
    private Double finalFolio;

    @Column(name = "TOTAL_SNICS")
    private Double totalSnics;

    @Column(name = "MERMA")
    private Double merma;

    @Column(name = "SNICS_LOT")
    private String snicsLot;

    @Column(name = "SNICS_YEAR")
    private Integer year;

    @Column(name = "GERMINATION")
    private Double germination;

    @OneToOne
    @JoinColumn(name = "LABEL_SAP_CODE_ID", referencedColumnName = "ID")
    private LabelSapCode labelSapCode;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Double getFinalFolio() {
        return finalFolio;
    }

    public void setFinalFolio(Double finalFolio) {
        this.finalFolio = finalFolio;
    }

    public Double getInitialFolio() {
        return initialFolio;
    }

    public void setInitialFolio(Double initialFolio) {
        this.initialFolio = initialFolio;
    }

    public LabelSapCode getLabelSapCode() {
        return labelSapCode;
    }

    public void setLabelSapCode(LabelSapCode labelSapCode) {
        this.labelSapCode = labelSapCode;
    }

    public Double getMerma() {
        return merma;
    }

    public void setMerma(Double merma) {
        this.merma = merma;
    }

    public String getSnicsLot() {
        return snicsLot;
    }

    public void setSnicsLot(String snicsLot) {
        this.snicsLot = snicsLot;
    }

    public Double getTotalSnics() {
        return totalSnics;
    }

    public void setTotalSnics(Double totalSnics) {
        this.totalSnics = totalSnics;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }

    public Double getGermination() {
        return germination;
    }

    public void setGermination(Double germination) {
        this.germination = germination;
    }

    @Override
    public boolean equals(Object o) {
        if (null == o || (o.getClass() != this.getClass())) {
            return false;
        }
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
