package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 10:19:41 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "SPECIALISTSUPERVISOR")
public class SpecialistSupervisor implements Serializable{

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "PLANT_ID")
    private Long idPlant;


    @ManyToOne
    @javax.persistence.JoinColumn(name = "SPECIALIST_ID", referencedColumnName = "ID")
    private Specialist specialist;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "SUPERVISOR_ID", referencedColumnName = "ID")
    private Supervisor supervisor;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L)
            return;
        this.id = id;
    }

    public Long getIdPlant() {
        return idPlant;
    }

    public void setIdPlant(Long idPlant) {
        this.idPlant = idPlant;
    }

    public Specialist getSpecialist() {
        return specialist;
    }

    public void setSpecialist(Specialist specialist) {
        this.specialist = specialist;
    }

    public Supervisor getSupervisor() {
        return supervisor;
    }

    public void setSupervisor(Supervisor supervisor) {
        this.supervisor = supervisor;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
