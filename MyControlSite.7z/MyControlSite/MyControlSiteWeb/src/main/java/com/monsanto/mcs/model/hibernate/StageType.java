package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;


/**
 * Created by IntelliJ IDEA.
 * User: MONSANTO
 * Date: 16/02/2011
 * Time: 11:56:41 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "STAGE_TYPE")
public class StageType {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_STAGE_TYPE")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    @OneToOne(mappedBy = "type")
    private Long id;

    @Column (name="NAME")
    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0){
            return;
        }
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
