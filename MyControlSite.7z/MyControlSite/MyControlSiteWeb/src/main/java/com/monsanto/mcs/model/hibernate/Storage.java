package com.monsanto.mcs.model.hibernate;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 7/12/2010
 * Time: 07:42:18 AM
 * To change this template use File | Settings | File Templates.
 */

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 14, 2010 Time: 2:56:23 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
    @Table(name = "STORAGE")
public class Storage implements Serializable {

    @SequenceGenerator(name="mcsSeq", sequenceName="MCS_CATALOGS")
    @Id @GeneratedValue(generator="mcsSeq")
    private Long id;

    @Column(name = "PLANT_ID")
    private Long idPlant;

    @Column(name = "NAME")
    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id==0L)
            return;
        this.id = id;
    }

    public Long getIdPlant() {
        return idPlant;
    }

    public void setIdPlant(Long idPlant) {
        this.idPlant = idPlant;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
}
