package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;

@Embeddable
public class Transport implements Serializable {

    @Column(name = "DRIVER_NAME")
    private String driver;

    @Column(name = "PLATE ")
    private String plates;

    @Column(name = "COLOR ")
    private String color;

    @Column(name = "MODEL")
    private Integer model;

    @Column(name = "TRANSPORT_FOLIO")
    private Integer folio;

    @Column(name = "LOT_TRUCK_NUMBER")
    private Integer lotTruckNumber;

    @OneToOne
    @javax.persistence.JoinColumn(name = "BRAND_ID", referencedColumnName = "ID")
    private TruckBrand brand;

    /*
    @OneToOne
    @javax.persistence.JoinColumn(name = "TRANSPORT_SUPPLIER_ID", referencedColumnName = "ID")
    private TransportSupplier transportSupplier;
    */

    /*
    @OneToOne
    @javax.persistence.JoinColumn(name = "TRANSPORT_TYPE_ID", referencedColumnName = "ID")
    private TransportType type;
    */

    public TruckBrand getBrand() {
        return brand;
    }

    public void setBrand(TruckBrand brand) {
        this.brand = brand;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getDriver() {
        return driver;
    }

    public void setDriver(String driver) {
        this.driver = driver;
    }

    public Integer getFolio() {
        return folio;
    }

    public void setFolio(Integer folio) {
        this.folio = folio;
    }

    public Integer getModel() {
        return model;
    }

    public void setModel(Integer model) {
        this.model = model;
    }

    public String getPlates() {
        return plates;
    }

    public void setPlates(String plates) {
        this.plates = plates;
    }

    /*
    public TransportSupplier getTransportSupplier() {
        return transportSupplier;
    }

    public void setTransportSupplier(TransportSupplier transportSupplier) {
        this.transportSupplier = transportSupplier;
    }

    public TransportType getType() {
        return type;
    }

    public void setType(TransportType type) {
        this.type = type;
    }
    */

    public Integer getLotTruckNumber() {
        return lotTruckNumber;
    }

    public void setLotTruckNumber(Integer lotTruckNumber) {
        this.lotTruckNumber = lotTruckNumber;
    }

    public String toString() {
        String value = "driver=" + driver + " " +
                       "plate=" + plates + " " +
                       "color=" + color + " " +
                       "model=" + model + " " +
                       "folio=" + folio + " " +
                       "lotTruckNumber=" + lotTruckNumber +
                       brand.toString() + "\n";
        return value;
    }

}
