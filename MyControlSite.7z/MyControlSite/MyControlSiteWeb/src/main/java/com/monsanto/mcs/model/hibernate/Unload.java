package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Embeddable
public class Unload implements Serializable {

    @Column(name = "UNLOAD_START_DATE")
    private Date unloadStartDate;

    @Column(name = "UNLOAD_END_DATE")
    private Date unloadEndDate;

    @OneToOne
    @JoinColumn(name = "UNLOADER_ID", referencedColumnName = "ID")
    private Unloader unloader;

    public Date getUnloadEndDate() {
        return unloadEndDate;
    }

    public void setUnloadEndDate(Date unloadEndDate) {
        this.unloadEndDate = unloadEndDate;
    }

    public Unloader getUnloader() {
        return unloader;
    }

    public void setUnloader(Unloader unloader) {
        this.unloader = unloader;
    }

    public Date getUnloadStartDate() {
        return unloadStartDate;
    }

    public void setUnloadStartDate(Date unloadStartDate) {
        this.unloadStartDate = unloadStartDate;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}
