package com.monsanto.mcs.model.hibernate;

import com.monsanto.wst.hibernate.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 8/12/2010
 * Time: 11:03:30 AM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "USER_MODULE_ROLE")
public class UserModuleRole implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_USER_MODULE_ROLE_SEQ")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @Column(name = "USER_ID")
    private String userId;



    @ManyToOne
    @javax.persistence.JoinColumn(name = "MODULE_ID", referencedColumnName = "ID")
    private Module module;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "ROLE_ID", referencedColumnName = "ID")
    private Role role;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
    private Plant plant;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
       if (id==0L)
            return;
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Module getModule() {
        return module;
    }

    public void setModule(Module module) {
        this.module = module;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

    public Plant getPlant() {
        return plant;
    }

    public void setPlant(Plant plant) {
        this.plant = plant;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }

}

