package com.monsanto.mcs.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "WARANTY_WEIGHT")
public class WarantyWeight implements Serializable {

    @SequenceGenerator(name = "mcsSeq", sequenceName = "MCS_CATALOGS")
    @Id
    @GeneratedValue(generator = "mcsSeq")
    private Long id;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "TRANSPORT_TYPE_ID", referencedColumnName = "ID")
    private TransportType transportType;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "TRANSPORT_SUPPLIER_ID", referencedColumnName = "ID")
    private TransportSupplier transportSupplier;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "PLANT_ID", referencedColumnName = "ID")
    private Plant sendToPlant;

    @ManyToOne
    @javax.persistence.JoinColumn(name = "ZONE_ID", referencedColumnName = "ID")
    private Zone zone;

    @Column(name = "PLANT_SEASON_ID")
    private Long plantSeasonId;

    @Column(name = "WEIGHT")
    private double weight;

    @Column(name = "CREATED_BY")
    private String userId;

    @Column(name = "LAST_UPDATE")
    private Date lastUpdate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        if (id == 0L) {
           return;
        }
        this.id = id;
    }

    public Long getPlantSeasonId() {
        return plantSeasonId;
    }

    public void setPlantSeasonId(Long plantSeasonId) {
        this.plantSeasonId = plantSeasonId;
    }

    public TransportType getTransportType() {
        return transportType;
    }

    public void setTransportType(TransportType transportType) {
        this.transportType = transportType;
    }

    public TransportSupplier getTransportSupplier() {
        return transportSupplier;
    }

    public void setTransportSupplier(TransportSupplier transportSupplier) {
        this.transportSupplier = transportSupplier;
    }

    public Zone getZone() {
        return zone;
    }

    public void setZone(Zone zone) {
        this.zone = zone;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public Plant getSendToPlant() {
        return sendToPlant;
    }

    public void setSendToPlant(Plant sendToPlant) {
        this.sendToPlant = sendToPlant;
    }

}
