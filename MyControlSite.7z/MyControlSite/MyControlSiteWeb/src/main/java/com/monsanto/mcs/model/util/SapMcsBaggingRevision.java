package com.monsanto.mcs.model.util;

public class SapMcsBaggingRevision {

    private String material;
    private int plant;
    private String materialDescription;
    private String sloc;
    private String eun;
    private double unrestricted;

    private String batch;
    private int mvt;
    private String time;
    private String userName;
    private String reference;
    private long order;
    private int quantityUne;
    private String documentDate;

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public int getPlant() {
        return plant;
    }

    public void setPlant(int plant) {
        this.plant = plant;
    }

    public String getMaterialDescription() {
        return materialDescription;
    }

    public void setMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
    }

    public String getSloc() {
        return sloc;
    }

    public void setSloc(String sloc) {
        this.sloc = sloc;
    }

    public String getEun() {
        return eun;
    }

    public void setEun(String eun) {
        this.eun = eun;
    }

    public double getUnrestricted() {
        return unrestricted;
    }

    public void setUnrestricted(double unrestricted) {
        this.unrestricted = unrestricted;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public int getMvt() {
        return mvt;
    }

    public void setMvt(int mvt) {
        this.mvt = mvt;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public long getOrder() {
        return order;
    }

    public void setOrder(long order) {
        this.order = order;
    }

    public int getQuantityUne() {
        return quantityUne;
    }

    public void setQuantityUne(int quantityUne) {
        this.quantityUne = quantityUne;
    }

    public String getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(String documentDate) {
        this.documentDate = documentDate;
    }

}
