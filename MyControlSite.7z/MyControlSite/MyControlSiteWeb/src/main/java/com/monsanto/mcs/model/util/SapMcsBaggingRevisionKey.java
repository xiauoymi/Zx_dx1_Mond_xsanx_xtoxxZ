package com.monsanto.mcs.model.util;

public class SapMcsBaggingRevisionKey implements Comparable{

    private String material;
    private String materialDescription;
    private long order;
    private String documentDate;
    private String batch;

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public long getOrder() {
        return order;
    }

    public void setOrder(long order) {
        this.order = order;
    }

    public String getDocumentDate() {
        return documentDate;
    }

    public void setDocumentDate(String documentDate) {
        this.documentDate = documentDate;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public int compareTo(Object o){
        SapMcsBaggingRevisionKey test = (SapMcsBaggingRevisionKey) o;
        return (this.documentDate+this.material+this.order+this.batch).compareTo(test.getDocumentDate()+test.getMaterial()+test.getOrder()+test.getBatch());
    }

    public String getMaterialDescription() {
        return materialDescription;
    }

    public void setMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
    }

    @Override
    public boolean equals(Object o){
        if (o instanceof SapMcsBaggingRevisionKey){
            SapMcsBaggingRevisionKey test = (SapMcsBaggingRevisionKey) o;
            return (this.documentDate+this.material+this.order+this.batch).equals(test.getDocumentDate()+test.getMaterial()+test.getOrder()+test.getBatch());
        } else{
            return false;
        }
    }

    @Override
    public int hashCode(){
        return (this.documentDate+this.material+this.order+this.batch).hashCode();
    }

}
