package com.monsanto.mcs.model.util;

public class SapMcsChemicalRevision {

    private String material;
    private int plant;
    private String materialDescription;
    private String sloc;
    private String bun;
    private double unrestricted;

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public int getPlant() {
        return plant;
    }

    public void setPlant(int plant) {
        this.plant = plant;
    }

    public String getMaterialDescription() {
        return materialDescription;
    }

    public void setMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
    }

    public String getSloc() {
        return sloc;
    }

    public void setSloc(String sloc) {
        this.sloc = sloc;
    }

    public String getBun() {
        return bun;
    }

    public void setBun(String bun) {
        this.bun = bun;
    }

    public double getUnrestricted() {
        return unrestricted;
    }

    public void setUnrestricted(double unrestricted) {
        this.unrestricted = unrestricted;
    }

}
