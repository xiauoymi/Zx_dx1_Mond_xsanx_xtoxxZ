package com.monsanto.mcs.model.util;

public class SapMcsRevisionSummary {

    private String material;
    private int plant;
    private String materialDescription;
    private long order;
    private double sapValue;
    private double mcsValue;
    private double difference;
    private String batch;

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public int getPlant() {
        return plant;
    }

    public void setPlant(int plant) {
        this.plant = plant;
    }

    public String getMaterialDescription() {
        return materialDescription;
    }

    public void setMaterialDescription(String materialDescription) {
        this.materialDescription = materialDescription;
    }

    public long getOrder() {
        return order;
    }

    public void setOrder(long order) {
        this.order = order;
    }

    public double getDifference() {
        return difference;
    }

    public void setDifference(double difference) {
        this.difference = difference;
    }

    public double getSapValue() {
        return sapValue;
    }

    public void setSapValue(double sapValue) {
        this.sapValue = sapValue;
    }

    public double getMcsValue() {
        return mcsValue;
    }

    public void setMcsValue(double mcsValue) {
        this.mcsValue = mcsValue;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    @Override
    public boolean equals(Object o){
        if (null != o && (o instanceof SapMcsRevisionSummary)) {
            SapMcsRevisionSummary test = (SapMcsRevisionSummary) o;
            return (this.material+this.order+this.batch).equals(test.getMaterial()+test.getOrder()+test.getBatch());
        } else{
            return false;
        }
    }

    @Override
    public int hashCode() {
        return (this.material+this.order+this.batch).hashCode();
    }

}
