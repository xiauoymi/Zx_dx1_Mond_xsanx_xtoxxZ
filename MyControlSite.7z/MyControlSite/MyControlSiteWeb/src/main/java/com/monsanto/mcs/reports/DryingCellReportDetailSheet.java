package com.monsanto.mcs.reports;

import com.monsanto.mcs.model.DryingCell;
import com.monsanto.mcs.model.DryingCellEntry;
import com.monsanto.mcs.model.hibernate.DryingCellReport;
import com.monsanto.mcs.model.hibernate.Plant;
import com.monsanto.mcs.util.MCSProperties;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class DryingCellReportDetailSheet extends MCSGCRXlsSheet implements DryingCellReportSheet {

    static final String NO_RECORDS_FOUND = "No records found for Drying Cell Report";

    public DryingCellReportDetailSheet(int sheetIndex) {
        super(sheetIndex);
    }

    public void populateSheet(HSSFWorkbook wb, Plant plant, DryingCell dryingCell, DryingCellReport dryingCellReport) throws Exception {
        if (!isEmptyReport(dryingCell, dryingCellReport)) {
            HSSFSheet sheet = wb.getSheetAt(sheetIndex);
            setDryingCellReportHeader(sheet, plant, dryingCellReport);
            setDryingCellReportData(sheet, dryingCell);
        }
    }

    private boolean isEmptyReport(DryingCell cell, DryingCellReport dryingCellReport) {
        boolean emptyReport = false;
        if (cell == null || cell.getEntries() == null || cell.getEntriesSize() == 0) {
            emptyReport = true;
        }
        if (dryingCellReport == null) {
            emptyReport =  true;
        }
        if (emptyReport) {
            System.out.println(NO_RECORDS_FOUND);
        }
        return emptyReport;
    }

    private void setDryingCellReportHeader(HSSFSheet sheet, Plant plant, DryingCellReport dryingCellReport) throws MCSInvalidXlsLayoutException {
        int INITIAL_ROW = 0;
        int INITIAL_COL = 3;
        setHeaderData(sheet, plant, dryingCellReport, INITIAL_ROW, INITIAL_COL);
    }

    public void setHeaderData(HSSFSheet sheet, Plant plant, DryingCellReport dryingCellReport, int initialRow, int initialCol) throws MCSInvalidXlsLayoutException {
        String RELEASE_DATE_MSG = "Fecha de revisi�n: 07/Marzo/2011";
        String VERSION_MSG = "Revisi�n: " + MCSProperties.getVersion();
        String SPACE = " ";
        int COL_FOLIO = 11;

        HSSFRow mcsVersionRelease = sheet.getRow(initialRow);
        setCellValue(mcsVersionRelease, initialCol, getStringValue(VERSION_MSG));
        HSSFRow mcsReleaseDate = sheet.getRow(++initialRow);
        setCellValue(mcsReleaseDate, initialCol, getStringValue(RELEASE_DATE_MSG));
        setCellValue(mcsReleaseDate, COL_FOLIO, getStringValue(plant.getAbbreviation() + SPACE + dryingCellReport.getFolio()));
    }

    private void setDryingCellReportData(HSSFSheet sheet, DryingCell dryingCell) throws Exception {
        int GRID_INITIAL_COL = 2;
        int COL_ZERO = 0;
        int COL_TRAVEL_QTY = 6;
        int COL_AVG_TONS = 8;

        HSSFRow dateRow = sheet.getRow(5);
        HSSFRow sampleRow = sheet.getRow(6);
        HSSFRow sendFormatFolioRow = sheet.getRow(7);
        HSSFRow platesRow = sheet.getRow(8);
        HSSFRow hybridRow = sheet.getRow(9);
        HSSFRow sourceRow = sheet.getRow(10);
        HSSFRow lotRow = sheet.getRow(11);
        HSSFRow fieldWeightRow = sheet.getRow(12);
        HSSFRow fieldHumidityRow = sheet.getRow(13);
        HSSFRow cellRow = sheet.getRow(15);
        HSSFRow plantHumidityRow = sheet.getRow(16);
        HSSFRow plantWeightRow = sheet.getRow(17);
        HSSFRow unloadStartRow = sheet.getRow(19);
        HSSFRow unloadEndRow = sheet.getRow(20);
        HSSFRow averageValuesRow = sheet.getRow(35);
        HSSFRow dehuskingValuesRow = sheet.getRow(38);

        populateDate(dateRow, GRID_INITIAL_COL, dryingCell);
        populateSample(sampleRow, GRID_INITIAL_COL, dryingCell);
        //Field Data
        populateSendFormat(sendFormatFolioRow, GRID_INITIAL_COL, dryingCell);
        populatePlates(platesRow, GRID_INITIAL_COL, dryingCell);
        populateHybrid(hybridRow, GRID_INITIAL_COL, dryingCell);
        populateTable(sourceRow, GRID_INITIAL_COL, dryingCell);
        populateLot(lotRow, GRID_INITIAL_COL, dryingCell);
        populateFieldWeight(fieldWeightRow, GRID_INITIAL_COL, dryingCell);
        populateFieldHumidity(fieldHumidityRow, GRID_INITIAL_COL, dryingCell);
        //Plant Data
        populateCell(cellRow, GRID_INITIAL_COL, dryingCell);
        populatePlantHumidity(plantHumidityRow, GRID_INITIAL_COL, dryingCell);
        populatePlantWeigth(plantWeightRow, GRID_INITIAL_COL, dryingCell);
        populateUnloadStart(unloadStartRow, GRID_INITIAL_COL, dryingCell);
        populateUnloadEnd(unloadEndRow, GRID_INITIAL_COL, dryingCell);
        //Drying start info
        populateAvgHumidity(averageValuesRow, COL_ZERO, dryingCell);
        populateTravelQuantity(averageValuesRow, COL_TRAVEL_QTY, dryingCell);
        populateAvgTons(averageValuesRow, COL_AVG_TONS, dryingCell);
        populateHybridCell(dehuskingValuesRow, COL_ZERO, dryingCell);
    }

    private void populateDate(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            setCellValue(row, colIndex + colCount, getFormattedDate(entry.getPlantData().getUnloadStart()));
            colCount++;
        }
    }

    private void populateSample(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        for (int colCount = 0; colCount < cell.getEntries().size(); colCount++) {
            setCellValue(row, colIndex + colCount, getNumericValue(colCount + 1));
        }
    }

    private void populateSendFormat(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            if (entry.getFieldData() != null) {
                setCellValue(row, colIndex + colCount, getStringValue(entry.getFieldData().getSendFormatFolio()));
                colCount++;
            } else {
                break;
            }
        }
    }

    private void populatePlates(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            setCellValue(row, colIndex + colCount, getStringValue(entry.getFieldData().getPlates()));
            colCount++;
        }
    }

    private void populateTable(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            setCellValue(row, colIndex + colCount, getStringValue(entry.getFieldData().getTable()));
            colCount++;
        }
    }

    private void populateLot(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            setCellValue(row, colIndex + colCount, getStringValue(entry.getFieldData().getLot()));
            colCount++;
        }
    }

    private void populateFieldWeight(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            setCellValue(row, colIndex + colCount, getNumericValue(entry.getFieldData().getWeight()));
            colCount++;
        }
    }

    private void populateFieldHumidity(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            setCellValue(row, colIndex + colCount, getNumericValue(entry.getFieldData().getHumidity()));
            colCount++;
        }
    }

    private void populatePlantHumidity(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            setCellValue(row, colIndex + colCount, getNumericValue(entry.getPlantData().getHumidity()));
            colCount++;
        }
    }

    private void populatePlantWeigth(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            setCellValue(row, colIndex + colCount, getNumericValue(entry.getPlantData().getWeigth()));
            colCount++;
        }
    }

    private void populateUnloadStart(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            setCellValue(row, colIndex + colCount, getFormattedHour(entry.getPlantData().getUnloadStart()));
            colCount++;
        }
    }

    private void populateUnloadEnd(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        int colCount = 0;
        for (DryingCellEntry entry : cell.getEntries()) {
            setCellValue(row, colIndex + colCount, getFormattedHour(entry.getPlantData().getUnloadEnd()));
            colCount++;
        }
    }

    private void populateHybrid(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        for (int colCount = 0; colCount < cell.getEntries().size(); colCount++) {
            setCellValue(row, colIndex + colCount, getStringValue(cell.getHybrid()));
        }
    }

    private void populateAvgHumidity(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        setCellValue(row, colIndex, getNumericValue(cell.getAverageHumidity()));
    }

    private void populateTravelQuantity(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        setCellValue(row, colIndex, getNumericValue(cell.getTravelQuantity()));
    }

    private void populateAvgTons(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        setCellValue(row, colIndex, getNumericValue(cell.getTons()));
    }

    private void populateCell(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        for (int colCount = 0; colCount < cell.getEntries().size(); colCount++) {
            setCellValue(row, colIndex + colCount, getNumericValue(cell.getCell()));
        }
    }

    private void populateHybridCell(HSSFRow row, int colIndex, DryingCell cell) throws MCSInvalidXlsLayoutException {
        setCellValue(row, colIndex, getStringValue(cell.getHybrid()));
    }

}
