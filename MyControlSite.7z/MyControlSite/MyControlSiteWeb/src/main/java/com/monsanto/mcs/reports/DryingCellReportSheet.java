package com.monsanto.mcs.reports;

import com.monsanto.mcs.model.DryingCell;
import com.monsanto.mcs.model.hibernate.DryingCellReport;
import com.monsanto.mcs.model.hibernate.Plant;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public interface DryingCellReportSheet {

    void populateSheet(HSSFWorkbook wb, Plant plant, DryingCell dryingCell, DryingCellReport dryingCellReport) throws Exception;

}
