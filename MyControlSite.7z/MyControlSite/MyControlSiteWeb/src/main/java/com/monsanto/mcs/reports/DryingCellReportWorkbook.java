package com.monsanto.mcs.reports;

import com.monsanto.mcs.model.DryingCell;
import com.monsanto.mcs.model.hibernate.DryingCellReport;
import com.monsanto.mcs.model.hibernate.Plant;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidParameterException;

public class DryingCellReportWorkbook {

    private HSSFWorkbook wb;
    private InputStream in;

    private DryingCellReportDetailSheet dryingCellReportDetail;

    private static final String INVALID_INPUT_STREAM = "The provided InputStream is not valid";

    public DryingCellReportWorkbook(InputStream in) throws InvalidParameterException {
        if (null != in ){
            this.in = in;
        } else {
            throw (new InvalidParameterException(INVALID_INPUT_STREAM));
        }
        dryingCellReportDetail = new DryingCellReportDetailSheet(0);
    }

    public void writeWorkbook(OutputStream out) throws Exception{
        wb.write(out);
    }

    public void populateWorkbook(Plant plant, DryingCell dryingCell, DryingCellReport dryingCellReport) throws Exception{
        wb = new HSSFWorkbook(in);
        dryingCellReportDetail.populateSheet(wb,plant,dryingCell,dryingCellReport);
    }

}
