package com.monsanto.mcs.reports;

import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import org.apache.poi.hssf.usermodel.*;

import java.util.Collection;

public class GCRReportDetailSheet extends MCSGCRXlsSheet implements GCRReportSheet<GreenCornReceive> {

    static final String NO_RECORDS_FOUND_GCR = "No records found for Green Corn Receive";

    public GCRReportDetailSheet(int sheetIndex) {
        super(sheetIndex);
    }

    public void populateSheet(HSSFWorkbook wb,Collection<GreenCornReceive> greenCornReceive) throws Exception {
        HSSFSheet sheet = wb.getSheetAt(sheetIndex);
        checkEmptyReport(greenCornReceive);
        setGreenCornReceiveHeader(sheet);
        setGreenCornReceiveData(sheet, greenCornReceive);
    }

    private void checkEmptyReport(Collection<GreenCornReceive> collection) {
        if (collection == null || collection.size() == 0) {
            System.out.println(NO_RECORDS_FOUND_GCR);
        }
    }

    private void setGreenCornReceiveHeader(HSSFSheet sheet) throws MCSInvalidXlsLayoutException {
        int INITIAL_ROW = 1;
        int INITIAL_COL = 3;
        setHeaderData(sheet, INITIAL_ROW, INITIAL_COL);
    }

    private void setGreenCornReceiveData(HSSFSheet sheet, Collection<GreenCornReceive> collection) throws Exception{
        int INITIAL_ROW = 6;
        int rowCount = 0;
        for (GreenCornReceive row : collection) {
            if (row == null) {
                continue;
            }
            HSSFRow currentRow = sheet.getRow(INITIAL_ROW + rowCount);
            setSendFormatData(row, currentRow);
            setUnloadScaleData(row, currentRow);
            setPlantQualityData(row, currentRow);
            setDehuskingData(row, currentRow);
            setDryingShellingData(row, currentRow);
            setFieldQualityData(row, currentRow);
            setGrowerPaymentData(row, currentRow);
            rowCount++;
        }
    }

    private void setSendFormatData(GreenCornReceive row, HSSFRow currentRow) throws Exception{
        //DAY TRUCK SEQ A
        setCellValue(currentRow, 0, getNumericValue(row.getDayTruckNumber()));
        //LOT TRUCK SEQ B
        setCellValue(currentRow, 1, getNumericValue(row.getLotTruckNumber()));
        //TRANSPORT SUPPLIER C
        setCellValue(currentRow, 2, getStringValue(row.getTransportSupplier()));
        //TRANSPORT TYPE D
        setCellValue(currentRow, 3, getStringValue(row.getTransportType()));
        //PLATES E
        setCellValue(currentRow, 4, getStringValue(row.getPlate()));
        //SPECIALIST F
        setCellValue(currentRow, 5, getStringValue(row.getSpecialist()));
        //SEND FORMAT FOLIO G
        setCellValue(currentRow, 6, getStringValue(row.getPk().getSendFormatFolio()));
        //SEND FORMAT FOLIO H
        setCellValue(currentRow, 7, getStringValue(row.getPlantTo()));
        //SCALE TICKET I
        setCellValue(currentRow, 8, getNumericValue(row.getScaleTicket()));
        //ORIGIN J
        setCellValue(currentRow, 9, getStringValue(row.getPk().getOrigin()));
        //HYBRID K
        setCellValue(currentRow, 10, getStringValue(row.getPk().getHybrid()));
        //LOT L
        setCellValue(currentRow, 11, getStringValue(row.getPk().getLotCode()));
        //QUARANTINED M
        setCellValue(currentRow, 12, getStringValue(row.getQuarantined()));
        //GROWER N
        setCellValue(currentRow, 13, getStringValue(row.getGrower()));
        //END OF LOT O
        setCellValue(currentRow, 14, getStringValue(row.getEndOfLot()));
        //SEND DATE P
        setCellValue(currentRow, 15, getDateValue(row.getSendDate()));
        //SEND HOUR Q
        setCellValue(currentRow, 16, getStringValue(row.getSendHour()));
        //ENTRY DATE R
        setCellValue(currentRow, 17, getDateValue(row.getEntryDate()));
        //ENTRY HOUR S
        setCellValue(currentRow, 18, getStringValue(row.getEntryHour()));
    }

    private void setUnloadScaleData(GreenCornReceive row, HSSFRow currentRow) throws Exception{
        //OUT DATE T
        setCellValue(currentRow, 19, getDateValue(row.getOutPlantDate()));
        //OUT HOUR U
        setCellValue(currentRow, 20, getStringValue(row.getOutPlantHour()));
        //TIME IN PLANT V
        setCellValue(currentRow, 21, getDHMFormattedInterval(row.getTimeInPlant()));
        //UNLOAD START DATE W
        setCellValue(currentRow, 22, getDateValue(row.getUnloadStartDate()));
        //UNLOAD START HOUR X
        setCellValue(currentRow, 23, getStringValue(row.getUnloadStartHour()));
        //UNLOAD END HOUR Y
        setCellValue(currentRow, 24, getStringValue(row.getUnloadEndHour()));
        //UNLOAD TIME Z
        setCellValue(currentRow, 25, getFormattedInterval(row.getUnloadTotalTime()));
        //UNLOADER AA
        setCellValue(currentRow, 26, getStringValue(row.getUnloader()));
        //ENTRY_VS_UNLOAD_TIME AB
        setCellValue(currentRow, 27, getFormattedInterval(row.getEntryVsUnloadTime()));
        //FIELD WEIGHT AC
        setCellValue(currentRow, 28, getNumericValue(row.getFieldWeight()));
        //GROSS WEIGHT AD
        setCellValue(currentRow, 29, getNumericValue(row.getGrossWeight()));
        //TARE WEIGHT AE
        setCellValue(currentRow, 30, getNumericValue(row.getTareWeight()));
        //RECEIVED WEIGHT AF
        setCellValue(currentRow, 31, getNumericValue(row.getReceivedWeight()));
        //CELL AG
        setCellValue(currentRow, 32, getNumericValue(row.getCell()));
        //FIELD HUMIDITY AH
        setCellValue(currentRow, 33, getNumericValue(row.getFieldHumidity()));
    }

    private void setPlantQualityData(GreenCornReceive row, HSSFRow currentRow) throws Exception{
        //PLANT HUMIDITY AI
        setCellValue(currentRow, 34, getNumericValue(row.getPlantHumidity()));
        //FILL AJ
        setCellValue(currentRow, 35, getNumericValue(row.getFill()));
        //MATURITY AK
        setCellValue(currentRow, 36, getNumericValue(row.getMaturity()));
        //MILK LINE AL
        setCellValue(currentRow, 37, getNumericValue(row.getMilkLine()));
        //TEMPERATURE AM
        setCellValue(currentRow, 38, getNumericValue(row.getTemperature()));
    }

    private void setDehuskingData(GreenCornReceive row, HSSFRow currentRow) throws Exception{
        //MANUAL SAMPLE AN
        setCellValue(currentRow, 39, getNumericValue(row.getKgSampleManual()));
        //MECH SAMPLE AO
        setCellValue(currentRow, 40, getNumericValue(row.getKgSampleMech()));
        //MERMA AP
        setCellValue(currentRow, 41, getNumericValue(row.getShortage()));
        //RETURN PERCENTAGE AQ
        setCellValue(currentRow, 42, getNumericValue(row.getReturnPercentage()));
    }

    private void setDryingShellingData(GreenCornReceive row, HSSFRow currentRow) throws Exception{
        //DRYING START DATE AR
        setCellValue(currentRow, 43, getDateValue(row.getDryingStartDate()));
        //DRYING START HOUR AS
        setCellValue(currentRow, 44, getStringValue(row.getDryingStartHour()));
        //DRYING END DATE AT
        setCellValue(currentRow, 45, getDateValue(row.getDryingEndDate()));
        //DRYING END HOUR AU
        setCellValue(currentRow, 46, getStringValue(row.getDryingEndHour()));
        //DRYING SPENT TIME AV
        setCellValue(currentRow, 47, getNumericValue(row.getDryingSpentTime()));
        //AVG HUMIDITY AW
        setCellValue(currentRow, 48, getNumericValue(row.getPlantHumidityAvg()));
        //DRYING RATE AX
        setCellValue(currentRow, 49, getNumericValue(row.getDryingRate()));
        //MOISTURE CLOSING CELL AY
        setCellValue(currentRow, 50, getNumericValue(row.getMoistureClosingCell()));
        //SHELLING START DATE AZ
        setCellValue(currentRow, 51, getDateValue(row.getShellingStartDate()));
        //SHELLING START HOUR BA
        setCellValue(currentRow, 52, getStringValue(row.getShellingStartHour()));
        //SHELLING END DATE BB
        setCellValue(currentRow, 53, getDateValue(row.getShellingEndDate()));
        //SHELLING END HOUR BC
        setCellValue(currentRow, 54, getStringValue(row.getShellingEndHour()));
        //SHELLING SPENT TIME BD
        setCellValue(currentRow, 55, getFormattedInterval(row.getShellingSpentTime()));
        //DRYING SHELLING FOLIO BE
        setCellValue(currentRow, 56, getNumericValue(row.getDryingFolio()));
        //SHELLER BF
        setCellValue(currentRow, 57, getStringValue(row.getSheller()));
        //SHELLING ORDER BG
        setCellValue(currentRow, 58, getNumericValue(row.getShellingOrder()));
        //SHELLING ORDER BH
        setCellValue(currentRow, 59, getNumericValue(row.getCellHeight()));
        //GREEN CORN KGS BI
        setCellValue(currentRow, 60, getNumericValue(row.getReceivedWeightSum()));
        //SHELLING KG (CELL) BJ
        setCellValue(currentRow, 61, getNumericValue(row.getShellingKg()));
        //SHELLING KG (TRUCK) BK
        setCellValue(currentRow, 62, getNumericValue(row.getTruckShellingKg()));
        //SILO BL
        setCellValue(currentRow, 63, getStringValue(row.getSilo()));
        //MIXTURE LOT BM
        setCellValue(currentRow, 64, getStringValue(row.getMixtureLot()));
    }

    private void setFieldQualityData(GreenCornReceive row, HSSFRow currentRow) throws Exception{
        //SHELLING HUMIDITY BN
        setCellValue(currentRow, 65, getNumericValue(row.getAverageHumidity()));
        //MOISTURE ADJUSTMENT 12% BO
        setCellValue(currentRow, 66, getNumericValue(row.getMoistureAdjustment12()));
        //OTHER COLOR SEED BP
        setCellValue(currentRow, 67, getNumericValue(row.getSeedOtherColor()));
        //DAMAGE BROKEN BQ
        setCellValue(currentRow, 68, getNumericValue(row.getDamageBroken()));
        //INSECT DAMAGE BR
        setCellValue(currentRow, 69, getNumericValue(row.getInsectDamage()));
        //INERT MATTER BS
        setCellValue(currentRow, 70, getNumericValue(row.getInnertMatter()));
    }

    private void setGrowerPaymentData(GreenCornReceive row, HSSFRow currentRow) throws Exception{
        //RECEIVED WEIGHT BT
        setCellValue(currentRow, 71, getNumericValue(row.getReceivedWeightPq()));
        //HFM BU
        setCellValue(currentRow, 72, getNumericValue(row.getHfm()));
        //PTM BV
        setCellValue(currentRow, 73, getNumericValue(row.getPtm()));
        //PGM BW
        setCellValue(currentRow, 74, getNumericValue(row.getPgm()));
        //TOTAL TO SETTLE BX
        setCellValue(currentRow, 75, getNumericValue(row.getTotalToSettle()));
        //YIELD BY
        setCellValue(currentRow, 76, getNumericValue(row.getYield()));
        //DIF_GROWER_PAYMENT BZ
        setCellValue(currentRow, 77, getNumericValue(row.getDifGrowerPayment()));
        //RESULTS_DATE CA
        setCellValue(currentRow, 78, getDateValue(row.getResultsDate()));
        //PAYMENT_DATE CB
        setCellValue(currentRow, 79, getDateValue(row.getPaymentDate()));
    }

}
