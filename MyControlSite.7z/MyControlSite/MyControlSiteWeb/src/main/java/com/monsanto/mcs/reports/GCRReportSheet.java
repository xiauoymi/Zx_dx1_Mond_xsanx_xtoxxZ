package com.monsanto.mcs.reports;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import java.util.Collection;

public interface GCRReportSheet<T> {

    void populateSheet(HSSFWorkbook wb,Collection<T> collection) throws Exception;

}
