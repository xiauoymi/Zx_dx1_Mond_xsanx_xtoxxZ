package com.monsanto.mcs.reports;

import com.monsanto.mcs.model.hibernate.ReleaseByLotHybrid;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFCellUtil;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Workbook;
import org.hibernate.hql.ast.tree.FromClause;

import java.text.MessageFormat;
import java.text.NumberFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class GCRReportSummarySheet extends MCSGCRXlsSheet implements GCRReportSheet<ReleaseByLotHybrid>{

    private static final String NO_RECORDS_FOUND = "No records found for Green Corn Receive Summary";
    private static final Short  FORMAT_PERCENT   = HSSFDataFormat.getBuiltinFormat( "0.00%" );
    private static final Short  FORMAT_NUMERIC   = HSSFDataFormat.getBuiltinFormat( "#,##0.00" );
    private static final Short  FONT_WEIGHT      = HSSFFont.BOLDWEIGHT_BOLD;
    private static final String FONT_NAME        = "Calibri";
    private static final short  FONT_SIZE        = 8;
    private static final int    INITIAL_DATA_ROW = 5;
    private static final int    INITIAL_HEAD_ROW = 2;

    private static final Short COLOR_TOTALS      = HSSFColor.GREY_25_PERCENT.index;
    private static final Short COLOR_WARN        = HSSFColor.LIGHT_YELLOW.index;
    private static final Short COLOR_OK          = HSSFColor.LIGHT_GREEN.index;
    private static final Short COLOR_ERROR       = HSSFColor.LIGHT_ORANGE.index;

    public GCRReportSummarySheet( int sheetIndex ) {
        super( sheetIndex );
    }

    private void checkEmptySummary(Collection<ReleaseByLotHybrid> collection) {
        if ( CollectionUtils.isEmpty( collection ) ){
            System.out.println( NO_RECORDS_FOUND );
        }
    }

    public void populateSheet(HSSFWorkbook wb,Collection<ReleaseByLotHybrid> release) throws Exception {
        // set the thread local workbook for fonts and styles generation...
        setWorkbook( wb );
        HSSFSheet releaseSheet = wb.getSheetAt(sheetIndex);

        checkEmptySummary( release );
        setHeaderData(     releaseSheet, INITIAL_HEAD_ROW, 0 );
        setSummaryData(    releaseSheet, release );
    }

    private void setSummaryData( HSSFSheet releaseSheet, Collection<ReleaseByLotHybrid> releaseCollection) throws Exception{
        int currentRowIndex = INITIAL_DATA_ROW;
        int groupFirstRowIndex = currentRowIndex;

        ReleaseByLotHybrid item=null, lastItem = null;

        Iterator<ReleaseByLotHybrid> iterator = releaseCollection.iterator();

        while( iterator.hasNext() ){

            item = iterator.next();
            if (item != null) {
                // to write each hybrid totals
                if ( lastItem != null && !item.getHybrid().equals( lastItem.getHybrid() ) ){
                    buildHybridTotalsRow( lastItem, groupFirstRowIndex, currentRowIndex++,  releaseSheet );
                    groupFirstRowIndex = currentRowIndex;
                }

                HSSFRow currentRow = releaseSheet.getRow( currentRowIndex++ );

                setFieldBatchRecordData(    item, currentRow );
                setUnloadShellingYieldData( item, currentRow );
                setGrowerPaymentData(       item, currentRow );
                setBaggingData(             item, currentRow );

                lastItem = item;
            }
        }
        // for the last hybrid totals
        if (lastItem != null) {
            buildHybridTotalsRow( lastItem, groupFirstRowIndex, currentRowIndex, releaseSheet);
        }
    }

    private void buildHybridTotalsRow( ReleaseByLotHybrid item, int firstRow, int lastRow, HSSFSheet releaseSheet) throws Exception {

        HSSFRow row = releaseSheet.getRow( lastRow );

        // HYBRID
        setCellValue(   row,  0, getStringValue(item.getHybrid()));
        // HAS SUM
        setCellFormula( row,  4, buildSumFormula( "E", firstRow + 1, lastRow ) );
        // FORMULA CALCULATED HYBRID RELEASED SSUS
        setCellFormula( row, 15, buildSumFormula( "P", firstRow + 1, lastRow ));
        // HYBRID RELEASED SSUS
        setCellValue(   row, 16, getNumericValue( item.getHybridSsus() ) );

        // set style...
        setTotalsRowStyle( row );
    }

    private void setTotalsRowStyle( HSSFRow row ) throws Exception{

        HSSFFont font = getFont( FONT_NAME, FONT_WEIGHT, FONT_SIZE );

        setRowStyle( row,  getStyle( font, HSSFCellStyle.ALIGN_CENTER, COLOR_TOTALS, true, null           ) );
        setCellStyle( row, getStyle( font, HSSFCellStyle.ALIGN_RIGHT,  COLOR_TOTALS, true, FORMAT_NUMERIC ), 4, 15, 16, 17 );
    }

    private void setFieldBatchRecordData(ReleaseByLotHybrid row, HSSFRow currentRow) throws Exception{
        //HYBRID A
        setCellValue(currentRow, 0, getStringValue(row.getHybrid()));
        //TRUCKS_TOTAL B
        setCellValue(currentRow, 1, getNumericValue(row.getTrucksTotal()));
        //GROWER C
        setCellValue(currentRow, 2, getStringValue(row.getGrower()));
        //LOT D
        setCellValue(currentRow, 3, getNumericValue(row.getLotCode()));
        //Hectares E
        setCellValue(currentRow, 4, getNumericValue(row.getHas()));
    }

    private void setUnloadShellingYieldData(ReleaseByLotHybrid row, HSSFRow currentRow) throws Exception{
        //Green corn received F
        setCellValue(currentRow, 5, getNumericValue(row.getGreenCornReceived()));
        //Shelling G
        setCellValue(currentRow, 6, getNumericValue(row.getShelling()));
        //Plant_yield H
        setCellValue(currentRow, 7, getNumericValue(row.getPlantYield()));
    }

    private void setGrowerPaymentData(ReleaseByLotHybrid dto, HSSFRow row) throws Exception{
        //Grower_payment I
        setCellValue( row, 8,  getFloorValue(   dto.getGrowerPayment()));
        //Shelling12 J
        setCellValue( row, 9,  getFloorValue(   dto.getShelling12()));
        //Grower_Payment_Dif_Vs_Shell12 K
        setCellValue( row, 10, getNumericValue( dto.getGrowerPaymentDifVsShell12()));
        // Shelling status
        setCellValue( row, 11, getStringValue(  dto.getShellingStatus() ) );
    }

    private void setBaggingData( ReleaseByLotHybrid row, HSSFRow currentRow ) throws Exception{
        // Efficiency
        setCellValue(currentRow, 12, getNumericValue(row.getEfficency()));
        // Unit Weight
        setCellValue(currentRow, 13, getNumericValue(row.getUnitWeight()) );
        // Bagging Progress Flag
        setConsumptionProgressFlag( row, currentRow );
    }

    private void setConsumptionProgressFlag( final ReleaseByLotHybrid dto, HSSFRow row ) throws Exception{

        Double     progress = dto.getMixLotConsumptionProgress();
        progress = (progress != null)? progress: 0.0;
        Short         color = ( progress < 1.0 )? COLOR_WARN : ( progress > 1.0 )? COLOR_ERROR : COLOR_OK;
        HSSFCellStyle style = getStyle( FONT_NAME, FONT_WEIGHT, FONT_SIZE, HSSFCellStyle.ALIGN_RIGHT, color, true, FORMAT_PERCENT );

        setCellStyle( row, style, 18 );
        setCellValue( row, 18, progress );
    }
}
