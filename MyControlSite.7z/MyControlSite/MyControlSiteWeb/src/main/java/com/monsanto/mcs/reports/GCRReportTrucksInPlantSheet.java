package com.monsanto.mcs.reports;

import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.util.Collection;

public class GCRReportTrucksInPlantSheet extends MCSGCRXlsSheet implements GCRReportSheet<GreenCornReceive>{

    private static String QUARANTINED_STATUS = "CUARENTENADO";
    private static String FREE_STATUS = "LIBRE";
    private static String TRUCK_IN_PLANT = "EN PLANTA";
    private static String TRUCK_OUT_PLANT = "NO";

    public GCRReportTrucksInPlantSheet(int sheetIndex) {
        super(sheetIndex);
    }

    public void populateSheet(HSSFWorkbook wb, Collection<GreenCornReceive> greenCornReceive) throws Exception {
        HSSFSheet trucksInPlantSheet = wb.getSheetAt(sheetIndex);
        setTrucksInPlantData(trucksInPlantSheet, greenCornReceive);
    }

    private void setTrucksInPlantData(HSSFSheet trucksInPlantSheet, Collection<GreenCornReceive> greenCornReceiveCollection) throws Exception{
        int rowCount = 0;
        int INITIAL_ROW = 3;
        for (GreenCornReceive row : greenCornReceiveCollection) {
            if (row == null) {
                continue;
            }
            HSSFRow currentRow = trucksInPlantSheet.getRow(INITIAL_ROW + rowCount);
            setFieldData(row, currentRow);
            setTransportationData(row, currentRow);
            setPlantData(row, currentRow);
            rowCount++;
        }
    }

    private void setFieldData(GreenCornReceive row, HSSFRow currentRow) throws Exception{
        //HYBRID A
        setCellValue(currentRow, 0, getStringValue(row.getPk().getLotCode().substring(4,7)));
        //MATERIAL B
        setCellValue(currentRow, 1, getStringValue(row.getPk().getHybrid()));
        //LOT C
        setCellValue(currentRow, 2, getStringValue(row.getPk().getLotCode()));
        //QUARANTINED D
        setCellValue(currentRow, 3, getStringValue(row.getQuarantined()));
    }

    private void setTransportationData(GreenCornReceive row, HSSFRow currentRow) throws Exception{
        //SEND FORMAT E
        setCellValue(currentRow, 4, getStringValue(row.getPk().getSendFormatFolio()));
        //PLATES F
        setCellValue(currentRow, 5, getStringValue(row.getPlate()));
        //TRANSPORT SUPPLIER G
        setCellValue(currentRow, 6, getStringValue(row.getTransportSupplier()));
        //DRIVER NAME H
        setCellValue(currentRow, 7, getStringValue(row.getDriverName()));
        //FIELD HUMIDITY I
        setCellValue(currentRow, 8, getNumericValue(row.getFieldHumidity()));
        //FIELD WEIGHT J
        setCellValue(currentRow, 9, getNumericValue(row.getFieldWeight()));
        //TRANSPORT TYPE K
        setCellValue(currentRow, 10, getStringValue(row.getTransportType()));
    }

    private void setPlantData(GreenCornReceive row, HSSFRow currentRow) throws Exception{
        //ENTRY HOUR L
        setCellValue(currentRow, 11, getStringValue(row.getEntryDate()));
        //ENTRY HOUR M
        setCellValue(currentRow, 12, getStringValue(row.getEntryHour()));
        //QUARANTINED N
        setCellValue(currentRow, 13, getStringValue(row.getQuarantined() == null?GCRReportTrucksInPlantSheet.FREE_STATUS:GCRReportTrucksInPlantSheet.QUARANTINED_STATUS));
        //IN PLANT O
        setCellValue(currentRow, 14, getStringValue(row.getReceivedWeight() == null?GCRReportTrucksInPlantSheet.TRUCK_IN_PLANT:GCRReportTrucksInPlantSheet.TRUCK_OUT_PLANT));

    }

}
