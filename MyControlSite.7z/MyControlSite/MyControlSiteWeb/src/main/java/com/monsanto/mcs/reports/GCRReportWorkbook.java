package com.monsanto.mcs.reports;

import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import com.monsanto.mcs.model.hibernate.ReleaseByLotHybrid;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidParameterException;
import java.util.Collection;

public class GCRReportWorkbook {

    private HSSFWorkbook wb;
    private InputStream in;

    private GCRReportSheet gcrReportSummary;
    private GCRReportSheet gcrReportDetail;
    private GCRReportSheet gcrReportTrucksInPlant;

    private static final String INVALID_INPUT_STREAM = "The provided InputStream is not valid";

    public GCRReportWorkbook(InputStream in) throws InvalidParameterException {
        if (null != in ){
            this.in = in;
        } else {
            throw (new InvalidParameterException(INVALID_INPUT_STREAM));
        }
        gcrReportSummary = new GCRReportSummarySheet(0);
        gcrReportDetail = new GCRReportDetailSheet(1);
        gcrReportTrucksInPlant = new GCRReportTrucksInPlantSheet(2);
    }

    public void writeWorkbook(OutputStream out) throws Exception{
        wb.write(out);
    }

    public void populateWorkbook(Collection<ReleaseByLotHybrid> release, Collection<GreenCornReceive> greenCornReceive) throws Exception{
        wb = new HSSFWorkbook(in);
        gcrReportSummary.populateSheet(wb,release);
        gcrReportDetail.populateSheet(wb,greenCornReceive);
        gcrReportTrucksInPlant.populateSheet(wb,greenCornReceive);
        wb.setForceFormulaRecalculation( true );
    }

}
