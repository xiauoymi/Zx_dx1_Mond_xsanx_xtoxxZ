package com.monsanto.mcs.reports;

import com.monsanto.mcs.model.hibernate.PlantSeason;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.util.Collection;

public class KPIReportDetailSheet extends MCSXlsSheet implements KPIReportSheet<KPIReportVo> {

    private HSSFRow  receivedWeightRow;
    private HSSFRow  weightLessThan25Row;
    private HSSFRow  cellWeightGreatherThan28;
    private HSSFRow  cellWeightWithTemperatureGrather40InQuality;
    private HSSFRow  cellGreenSeedLoses;
    private HSSFRow  cellDryingRate;
    private HSSFRow  cellStdDevDryingRate;
    private HSSFRow  cellAverageMonthReceivedWeight;
    private HSSFRow  cellHoursPerHumidityPoing;
    private HSSFRow  cellGranelConversion;
    private HSSFRow  cellRedColorantFactor;
    private HSSFRow  cellMaximFactor;
    private HSSFRow  cellKobiolFactor;
    private HSSFRow  cellSSUPonchoTotal;
    private HSSFRow  cellPonchoBagged;
    private HSSFRow  cellDaylyBaggedAvg;
    private HSSFRow  cellTotalBaggedUnits;
    private static final int INITIAL_COLUMN = 3;

    private static final String NA = "NA";

    public KPIReportDetailSheet(int sheetIndex) {
        super(sheetIndex);
    }

    public void populateSheet(HSSFWorkbook wb,PlantSeason plantSeason,String year,Collection<KPIReportVo> kpiValues) throws Exception {
        HSSFSheet sheet = wb.getSheetAt(sheetIndex);
        printPlantSeasonHeading(sheet, plantSeason);
        printYearHeadings(sheet, year);
        printKPIValues(sheet, kpiValues);
    }

    private void prepareRows(HSSFSheet sheet) {
        receivedWeightRow = sheet.getRow(6);
        weightLessThan25Row = sheet.getRow(7);
        cellWeightGreatherThan28 = sheet.getRow(8);
        cellWeightWithTemperatureGrather40InQuality = sheet.getRow(9);
        cellGreenSeedLoses = sheet.getRow(10);
        cellDryingRate = sheet.getRow(11);
        cellStdDevDryingRate = sheet.getRow(12);
        cellAverageMonthReceivedWeight = sheet.getRow(13);
        cellHoursPerHumidityPoing = sheet.getRow(14);
        cellGranelConversion = sheet.getRow(15);
        cellRedColorantFactor = sheet.getRow(17);
        cellMaximFactor = sheet.getRow(18);
        cellKobiolFactor = sheet.getRow(19);
        cellSSUPonchoTotal = sheet.getRow(20);
        cellPonchoBagged = sheet.getRow(21);
        cellDaylyBaggedAvg = sheet.getRow(22);
        cellTotalBaggedUnits = sheet.getRow(23);
    }

    private void printPlantSeasonHeading(HSSFSheet sheet, PlantSeason plantSeasonItem) throws Exception {
        if (plantSeasonItem != null) {
            HSSFRow  plantSeasonRow = sheet.getRow(1);
            setCellValue(plantSeasonRow, 8, getStringValue(plantSeasonItem.getPlant().getName()));
            setCellValue(plantSeasonRow, 11, getStringValue(plantSeasonItem.getSeason().getSeasonName()));
        }
    }

    private void printYearHeadings(HSSFSheet sheet, String year)throws Exception{
        HSSFRow yearRow = sheet.getRow(4);
        for (int index = 0; index < 12; index++){
            setCellValue(yearRow, INITIAL_COLUMN + index, getStringValue(year));
        }
    }

    private void printKPIValues(HSSFSheet sheet, Collection<KPIReportVo> kpiValues) throws Exception{
        int column = 0;
        prepareRows(sheet);
        for (KPIReportVo kpiValue : kpiValues){
            setCellValue(receivedWeightRow, INITIAL_COLUMN + column, getNumericValue(kpiValue.getTotalWeight()));
            if (0 != kpiValue.getTotalWeight()){
                setCellValue(weightLessThan25Row, INITIAL_COLUMN + column, getNumericValue(kpiValue.getWeigthLessThan25Humidity()));
                setCellValue(cellWeightGreatherThan28, INITIAL_COLUMN + column, getNumericValue(kpiValue.getWeightGreatherThan28Humidity()));
            } else{
                setCellValue(weightLessThan25Row, INITIAL_COLUMN + column, getStringValue(NA));
                setCellValue(cellWeightGreatherThan28, INITIAL_COLUMN + column, getStringValue(NA));
            }
            setCellValue(cellWeightWithTemperatureGrather40InQuality, INITIAL_COLUMN + column, getNumericValue(kpiValue.getWeightWithTemperatureGrather40InQuality()));
            setCellValue(cellGreenSeedLoses, INITIAL_COLUMN + column, getNumericValue(kpiValue.getGreenSeedLoses()));
            setCellValue(cellDryingRate, INITIAL_COLUMN + column, getNumericValue(kpiValue.getDryingRate()));
            setCellValue(cellStdDevDryingRate, INITIAL_COLUMN + column, getNumericValue(kpiValue.getStdDevDryingRate()));
            setCellValue(cellAverageMonthReceivedWeight, INITIAL_COLUMN + column, getNumericValue(kpiValue.getAverageMonthReceivedWeight()));
            setCellValue(cellHoursPerHumidityPoing, INITIAL_COLUMN + column, getNumericValue(kpiValue.getHoursPerHumidityPoint()));
            setCellValue(cellGranelConversion, INITIAL_COLUMN + column, getNumericValue(kpiValue.getGranelConversion()));
            setCellValue(cellRedColorantFactor, INITIAL_COLUMN + column, getNumericValue(kpiValue.getRedColorantFactor()));
            setCellValue(cellMaximFactor, INITIAL_COLUMN + column, getNumericValue(kpiValue.getMaximFactor()));
            setCellValue(cellKobiolFactor, INITIAL_COLUMN + column, getNumericValue(kpiValue.getKobiolFactor()));
            setCellValue(cellSSUPonchoTotal, INITIAL_COLUMN + column, getNumericValue(kpiValue.getSsuPonchoTotal()));
            setCellValue(cellPonchoBagged, INITIAL_COLUMN + column, getNumericValue(kpiValue.getTotalPonchoBagged()));
            setCellValue(cellDaylyBaggedAvg, INITIAL_COLUMN + column, getNumericValue(kpiValue.getDailyBaggedAvg()));
            setCellValue(cellTotalBaggedUnits, INITIAL_COLUMN + column, getNumericValue(kpiValue.getTotalBaggedUnits()));
            column++;
        }
    }

}
