package com.monsanto.mcs.reports;

import com.monsanto.mcs.model.hibernate.PlantSeason;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import java.util.Collection;

public interface KPIReportSheet<T> {
    
public void populateSheet(HSSFWorkbook wb, PlantSeason plantSeason,String year,Collection<T> kpiValues) throws Exception;

}
