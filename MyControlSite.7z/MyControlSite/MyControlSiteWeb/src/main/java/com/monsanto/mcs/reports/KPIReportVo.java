package com.monsanto.mcs.reports;

public class KPIReportVo {

    private double totalWeight;
    private double weigthLessThan25Humidity;
    private double weightGreatherThan28Humidity;
    private double weightWithTemperatureGrather40InQuality;
    private double greenSeedLoses;
    private double dryingRate;
    private double stdDevDryingRate;
    private double hoursPerHumidityPoint;
    private double granelConversion;
    private double redColorantFactor;
    private double maximFactor;
    private double kobiolFactor;
    private double ssuPonchoTotal;
    private double dailyBaggedAvg;
    private double totalBaggedUnits;
    private double totalPonchoBagged;
    private double averageMonthReceivedWeight;

    public double getDailyBaggedAvg() {
        return dailyBaggedAvg;
    }

    public void setDailyBaggedAvg(double dailyBaggedAvg) {
        this.dailyBaggedAvg = dailyBaggedAvg;
    }

    public double getDryingRate() {
        return dryingRate;
    }

    public void setDryingRate(double dryingRate) {
        this.dryingRate = dryingRate;
    }

    public double getGranelConversion() {
        return granelConversion;
    }

    public void setGranelConversion(double granelConversion) {
        this.granelConversion = granelConversion;
    }

    public double getGreenSeedLoses() {
        return greenSeedLoses;
    }

    public void setGreenSeedLoses(double greenSeedLoses) {
        this.greenSeedLoses = greenSeedLoses;
    }

    public double getHoursPerHumidityPoint() {
        return hoursPerHumidityPoint;
    }

    public void setHoursPerHumidityPoint(double hoursPerHumidityPoint) {
        this.hoursPerHumidityPoint = hoursPerHumidityPoint;
    }

    public double getKobiolFactor() {
        return kobiolFactor;
    }

    public void setKobiolFactor(double kobiolFactor) {
        this.kobiolFactor = kobiolFactor;
    }

    public double getMaximFactor() {
        return maximFactor;
    }

    public void setMaximFactor(double maximFactor) {
        this.maximFactor = maximFactor;
    }

    public double getRedColorantFactor() {
        return redColorantFactor;
    }

    public void setRedColorantFactor(double redColorantFactor) {
        this.redColorantFactor = redColorantFactor;
    }

    public double getSsuPonchoTotal() {
        return ssuPonchoTotal;
    }

    public void setSsuPonchoTotal(double ssuPonchoTotal) {
        this.ssuPonchoTotal = ssuPonchoTotal;
    }

    public double getStdDevDryingRate() {
        return stdDevDryingRate;
    }

    public void setStdDevDryingRate(double stdDevDryingRate) {
        this.stdDevDryingRate = stdDevDryingRate;
    }

    public double getTotalBaggedUnits() {
        return totalBaggedUnits;
    }

    public void setTotalBaggedUnits(double totalBaggedUnits) {
        this.totalBaggedUnits = totalBaggedUnits;
    }

    public double getTotalPonchoBagged() {
        return totalPonchoBagged;
    }

    public void setTotalPonchoBagged(double totalPonchoBagged) {
        this.totalPonchoBagged = totalPonchoBagged;
    }

    public double getTotalWeight() {
        return totalWeight;
    }

    public void setTotalWeight(double totalWeight) {
        this.totalWeight = totalWeight;
    }

    public double getWeightGreatherThan28Humidity() {
        return weightGreatherThan28Humidity;
    }

    public void setWeightGreatherThan28Humidity(double weightGreatherThan28Humidity) {
        this.weightGreatherThan28Humidity = weightGreatherThan28Humidity;
    }

    public double getWeightWithTemperatureGrather40InQuality() {
        return weightWithTemperatureGrather40InQuality;
    }

    public void setWeightWithTemperatureGrather40InQuality(double weightWithTemperatureGrather40InQuality) {
        this.weightWithTemperatureGrather40InQuality = weightWithTemperatureGrather40InQuality;
    }

    public double getWeigthLessThan25Humidity() {
        return weigthLessThan25Humidity;
    }

    public void setWeigthLessThan25Humidity(double weigthLessThan25Humidity) {
        this.weigthLessThan25Humidity = weigthLessThan25Humidity;
    }

    public double getAverageMonthReceivedWeight() {
        return averageMonthReceivedWeight;
    }

    public void setAverageMonthReceivedWeight(double averageMonthReceivedWeight) {
        this.averageMonthReceivedWeight = averageMonthReceivedWeight;
    }

}
