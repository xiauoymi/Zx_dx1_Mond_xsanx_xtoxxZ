package com.monsanto.mcs.reports;

import com.monsanto.mcs.model.hibernate.PlantSeason;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.InputStream;
import java.io.OutputStream;
import java.security.InvalidParameterException;
import java.util.Collection;

public class KPIReportWorkbook {

    private HSSFWorkbook wb;
    private InputStream in;

    private KPIReportDetailSheet kpiReportSummary;

    private static final String INVALID_INPUT_STREAM = "The provided Input Stream is not valid";
    private static final String INVALID_OUTPUT_STREAM = "The provided Output Stream is not valid";

    public KPIReportWorkbook(InputStream in) {
        if (null != in ){
            this.in = in;
        } else {
            throw (new InvalidParameterException(INVALID_INPUT_STREAM));
        }
        kpiReportSummary = new KPIReportDetailSheet(0);
    }

    public void writeWorkbook(OutputStream out) throws Exception{
        if (null == out){
            throw (new InvalidParameterException(INVALID_OUTPUT_STREAM));
        }
        wb.write(out);
    }

    public void populateWorkbook(PlantSeason plantSeason, String year,Collection<KPIReportVo> kpiValues) throws Exception{
        wb = new HSSFWorkbook(in);
        kpiReportSummary.populateSheet(wb,plantSeason,year,kpiValues);
    }

}
