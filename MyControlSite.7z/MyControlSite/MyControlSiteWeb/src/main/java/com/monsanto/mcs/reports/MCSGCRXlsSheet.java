package com.monsanto.mcs.reports;

import com.monsanto.mcs.util.MCSProperties;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;

public class MCSGCRXlsSheet extends MCSXlsSheet {

    public MCSGCRXlsSheet(int sheetIndex) {
        super(sheetIndex);
    }

    protected void setHeaderData(HSSFSheet sheet, int initialRow, int initialCol) throws MCSInvalidXlsLayoutException {
        HSSFRow mcsVersionRelease = sheet.getRow(initialRow);      
        HSSFCell versionCell = getValidCellFromRow(mcsVersionRelease,initialCol);
        versionCell.setCellValue(getStringValue("MCS Version:"+MCSProperties.getVersion()));

        HSSFRow mcsReleaseDate = sheet.getRow(++initialRow);
        HSSFCell releaseDateCell = getValidCellFromRow(mcsReleaseDate,initialCol);
        releaseDateCell.setCellValue(getStringValue("MCS Release Date:"+MCSProperties.getReleaseDate()));
    }

}
