package com.monsanto.mcs.reports;

public class MCSInvalidXlsLayoutException extends Exception{

    public MCSInvalidXlsLayoutException(String message){
        super(message);
    }

}
