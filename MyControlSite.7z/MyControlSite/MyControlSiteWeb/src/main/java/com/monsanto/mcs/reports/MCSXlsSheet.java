package com.monsanto.mcs.reports;

import com.monsanto.mcs.util.DateTime;
import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MCSXlsSheet {

    public int sheetIndex;

    private static final String INVALID_LAYOUT = "The XLS layout is invalid.";

    public static final String DATE_PATTERN = "dd/MM/yyyy";

    public static final String HOUR_PATTERN = "HH:mm";

    private static final String EMPTY_STRING = "";

    private static final String SPACE = " ";

    private static final String DATE_INTERVAL_PREFIX_REGEXP = "(\\+0+)|(\\s)|(\\.0+)";

    private static final String ZEROS_PREFIX_REGEXP = "(\\+0+)|(\\.0+)";

    private final ThreadLocal<Map<MultiKey,HSSFCellStyle>> localStylesMap = new ThreadLocal<Map<MultiKey, HSSFCellStyle>>();
    private final ThreadLocal<Map<MultiKey,HSSFFont>>      localFontsMap  = new ThreadLocal<Map<MultiKey, HSSFFont>>();
    private final ThreadLocal<HSSFWorkbook>                localWorkbook  = new ThreadLocal<HSSFWorkbook>();

    public MCSXlsSheet(int sheetIndex) {
        this.sheetIndex = sheetIndex;
        localFontsMap.set( new HashMap<MultiKey, HSSFFont>() );
        localStylesMap.set( new HashMap<MultiKey, HSSFCellStyle>() );
    }

    protected void setWorkbook( HSSFWorkbook workbook ){
        localWorkbook.set( workbook );
    }

    String mergeStringValues(String value1, String value2) {
        if (null != value1 && null != value2) {
            return value1 + SPACE + value2;
        }
        return SPACE;
    }

    void setCellValue(HSSFRow currentRow, int columnIndex, Date cellValue) throws MCSInvalidXlsLayoutException {
        HSSFCell currentCell = getValidCellFromRow(currentRow, columnIndex);
        if (null != cellValue){

            currentCell.setCellValue(cellValue);
        }
    }

    void setCellValue(HSSFRow row, int columnIndex, double cellValue) throws MCSInvalidXlsLayoutException {
        getValidCellFromRow( row, columnIndex ).setCellValue(cellValue);
    }

    void setCellStyle(HSSFRow row, HSSFCellStyle style, int... columns ) throws MCSInvalidXlsLayoutException{
        for ( int column: columns ){
            getValidCellFromRow( row, column ).setCellStyle(style);
        }
    }

    void setRowStyle( HSSFRow row, HSSFCellStyle style ) throws MCSInvalidXlsLayoutException{
        for( Cell cell: row ){
            cell.setCellStyle( style );
        }
    }

    void setCellValue(HSSFRow currentRow, int columnIndex, HSSFRichTextString cellValue) throws MCSInvalidXlsLayoutException {
        getValidCellFromRow(currentRow, columnIndex).setCellValue(cellValue);
    }

    void setCellFormula( HSSFRow row, int columnIndex, String formula ) throws MCSInvalidXlsLayoutException{
        getValidCellFromRow( row, columnIndex ).setCellFormula( formula );
    }

    protected HSSFCell getValidCellFromRow( HSSFRow row, int columnIndex ) throws MCSInvalidXlsLayoutException{
        if ( null == row ){
            throw (new MCSInvalidXlsLayoutException(INVALID_LAYOUT));
        }
        HSSFCell cell = row.getCell( columnIndex );
        if ( cell != null ){
            return cell;
        }
        else{
            throw (new MCSInvalidXlsLayoutException(INVALID_LAYOUT));
        }
    }

    protected HSSFRichTextString getDHMFormattedInterval(String interval) {

        if (null != interval && !(EMPTY_STRING.equals(interval))) {
            interval = interval.replaceAll(ZEROS_PREFIX_REGEXP, EMPTY_STRING);

            return getStringValue(interval);
        }
        return getStringValue(EMPTY_STRING);
    }

    protected HSSFRichTextString getStringValue(String value){
        if (null == value ){
            return (new HSSFRichTextString(EMPTY_STRING));
        }
        return new HSSFRichTextString(value);
    }

    protected Date getDateValue(String value){
        if ( null != value && !value.equals("")){
            DateTime dateTime = new DateTime();
            try {
                dateTime.setDate(value);
            } catch (ParseException e) {
                return null;
            }
            return dateTime.getDateTime();
        }
        return null;
    }

    protected double getNumericValue(Number value){
        if ( null == value ){
            return (0D);
        }
        return value.doubleValue();
    }

    protected double getFloorValue(Number value){
        if ( null == value ){
            return (0D);
        }
        return Math.floor(value.doubleValue());
    }

    protected HSSFRichTextString getFormattedInterval(String interval){
        DateFormat df = new SimpleDateFormat(HOUR_PATTERN);
        if (null != interval && !(EMPTY_STRING.equals(interval)) ){
            interval = interval.replaceAll(DATE_INTERVAL_PREFIX_REGEXP,EMPTY_STRING);
            Date dateInterval;
            try {
                dateInterval = df.parse(interval);
            } catch (ParseException e) {
                return getStringValue(EMPTY_STRING);
            }
            return getStringValue(df.format(dateInterval));
        }
        return getStringValue(EMPTY_STRING);
    }

    protected HSSFRichTextString getFormattedDate(Date date){
        DateFormat df = new SimpleDateFormat(DATE_PATTERN);
        if (null != date){
            return getStringValue(df.format(date));
        }
        return getStringValue(EMPTY_STRING);
    }

    protected HSSFRichTextString getFormattedHour(Date date){
        DateFormat df = new SimpleDateFormat(HOUR_PATTERN);
        if (null != date){
            return getStringValue(df.format(date));
        }
        return getStringValue(EMPTY_STRING);
    }

    protected final HSSFFont getFont( final String fontName, final Short fontWeight, final Short fontSize ){
        MultiKey key = new MultiKey( fontName, fontWeight, fontSize );
        Map<MultiKey,HSSFFont> fontsMap = localFontsMap.get();

        if( !fontsMap.containsKey( key ) ){

            fontsMap.put( key, buildFont( localWorkbook.get().createFont(), fontName, fontWeight, fontSize ) );
        }
        return fontsMap.get( key );
    }

    private HSSFFont buildFont( final HSSFFont font, final String fontName, final Short fontWeight, final Short fontSize ){
        font.setFontName( fontName );
        font.setFontHeightInPoints( fontSize );
        font.setBoldweight( fontWeight );

        return font;
    }

    protected final HSSFCellStyle getStyle( final String fontName, final Short fontWeight, final Short fontSize, final Short alignment, final Short bgColor, final Boolean bordered, final Short dataFormat ){

        return getStyle( getFont( fontName, fontWeight, fontSize ), alignment, bgColor, bordered, dataFormat );
    }

    protected final HSSFCellStyle getStyle( final HSSFFont font, final Short alignment, final Short bgColor, final Boolean bordered, final Short dataFormat ){

        MultiKey key = new MultiKey( font, alignment, bgColor, bordered, dataFormat );
        Map<MultiKey,HSSFCellStyle> stylesMap = localStylesMap.get();

        if( !stylesMap.containsKey( key ) ){

            stylesMap.put( key, buildStyle( localWorkbook.get().createCellStyle(), font, alignment, bgColor, bordered, dataFormat ) );
        }
        return stylesMap.get( key );
    }

    private HSSFCellStyle buildStyle( final HSSFCellStyle style, final HSSFFont font, final Short alignment, Short bgColor, final Boolean bordered, final Short dataFormat ){
        style.setFont( font );
        style.setFillForegroundColor( bgColor );
        style.setFillPattern( HSSFCellStyle.SOLID_FOREGROUND );
        style.setAlignment(   alignment );

        if( dataFormat != null ){

            style.setDataFormat(  dataFormat );
        }

        if( bordered ){

            style.setBorderRight(  HSSFCellStyle.BORDER_THIN );
            style.setBorderLeft(   HSSFCellStyle.BORDER_THIN );
            style.setBorderBottom( HSSFCellStyle.BORDER_THIN );
            style.setBorderTop(    HSSFCellStyle.BORDER_THIN );
        }
        return style;
    }

    private static final String SUM_PATTERN = "SUM({0}{1}:{0}{2})";
    protected String buildSumFormula( String column, int from, int to ){
        return MessageFormat.format( SUM_PATTERN, column, from, to );
    }

}
