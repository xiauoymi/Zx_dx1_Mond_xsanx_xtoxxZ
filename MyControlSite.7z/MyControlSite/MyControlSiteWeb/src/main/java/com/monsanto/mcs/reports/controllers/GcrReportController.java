package com.monsanto.mcs.reports.controllers;

import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import com.monsanto.mcs.model.hibernate.ReleaseByLotHybrid;
import com.monsanto.mcs.services.gcorn.GreenCornReceiveService;
import com.monsanto.mcs.services.gcorn.ReleaseByLotHybridService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping(value = "/GCRReport")
public class GcrReportController {

    @Autowired
    private ReleaseByLotHybridService releaseByLotHybridService;

    @Autowired
    private GreenCornReceiveService greenCornReceiveService;

    private static final String GCR_REPORT_EXCEL_VIEW = "gcrReportExcelView";

    @RequestMapping(method = RequestMethod.GET, params = {"plant", "season"})
    public final ModelAndView getGcrReportInExcel(@RequestParam(value = "plant") int plantId, @RequestParam(value = "season") int seasonId) throws Exception {

        Map<String, Object> model = new HashMap<String, Object>();
        model.put("release", releaseByLotHybridService.findByPlantSeason(plantId, seasonId));
        model.put("greenCornReceive", greenCornReceiveService.findByPlantSeason(plantId, seasonId));

        return new ModelAndView(GCR_REPORT_EXCEL_VIEW, model);
    }
}
