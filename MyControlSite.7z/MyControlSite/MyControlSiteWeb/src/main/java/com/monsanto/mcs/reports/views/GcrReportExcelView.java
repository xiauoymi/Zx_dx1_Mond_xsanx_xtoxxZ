package com.monsanto.mcs.reports.views;

import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import com.monsanto.mcs.model.hibernate.ReleaseByLotHybrid;
import com.monsanto.mcs.reports.GCRReportDetailSheet;
import com.monsanto.mcs.reports.GCRReportSheet;
import com.monsanto.mcs.reports.GCRReportSummarySheet;
import com.monsanto.mcs.reports.GCRReportTrucksInPlantSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Collection;
import java.util.Map;

public class GcrReportExcelView extends AbstractExcelView {

    private GCRReportSheet gcrReportSummary;
    private GCRReportSheet gcrReportDetail;
    private GCRReportSheet gcrReportTrucksInPlant;

    public GcrReportExcelView() {
        setUrl("/WEB-INF/BlankReleaseByHibrid");
    }

    @Override
    protected void buildExcelDocument(Map model,
                                      HSSFWorkbook workbook,
                                      HttpServletRequest request,
                                      HttpServletResponse response) throws Exception {

        response.setHeader("Content-Disposition", "attachment; filename=\"GCR.xls\"");

        gcrReportSummary = new GCRReportSummarySheet(0);
        gcrReportDetail = new GCRReportDetailSheet(1);
        gcrReportTrucksInPlant = new GCRReportTrucksInPlantSheet(2);

        gcrReportSummary.populateSheet(workbook, (Collection<ReleaseByLotHybrid>) model.get("release"));
        gcrReportDetail.populateSheet(workbook, (Collection<GreenCornReceive>) model.get("greenCornReceive"));
        gcrReportTrucksInPlant.populateSheet(workbook, (Collection<GreenCornReceive>) model.get("greenCornReceive"));

        workbook.setForceFormulaRecalculation(true);
    }
}
