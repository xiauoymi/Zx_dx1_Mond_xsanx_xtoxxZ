package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.BagConsumed;

import java.util.Collection;

public interface BagConsumedService {

    BagConsumed save(BagConsumed bagConsumed);

    BagConsumed update(BagConsumed bagConsumed);

    void remove(BagConsumed bagConsumed);

    Collection<BagConsumed> findAll() throws Exception;

    Collection<BagConsumed> findByMaterialPackageConsumption(long mpcId) throws Exception;

}
