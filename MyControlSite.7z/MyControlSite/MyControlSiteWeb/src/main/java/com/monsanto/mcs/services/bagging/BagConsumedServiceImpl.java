package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BagConsumedDao;
import com.monsanto.mcs.model.hibernate.BagConsumed;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import java.util.Collection;

@Service("bagConsumedService")
@RemotingDestination
public class BagConsumedServiceImpl implements BagConsumedService {

    @Autowired
    BagConsumedDao bagConsumedDao = null;

    @RemotingInclude
    public void remove(BagConsumed bagConsumed) {
        bagConsumedDao.delete(bagConsumed);
    }

    @RemotingInclude
    public BagConsumed save(BagConsumed bagConsumed) {
        return bagConsumedDao.saveOrUpdate(bagConsumed);
    }

    @RemotingInclude
    public BagConsumed update(BagConsumed bagConsumed) {
        return bagConsumedDao.saveOrUpdate(bagConsumed);
    }

    @RemotingInclude
    public Collection<BagConsumed> findAll() throws Exception {
        return bagConsumedDao.findAll();
    }

    @RemotingInclude
    public Collection<BagConsumed> findByMaterialPackageConsumption(long mpcId) throws Exception {
        return bagConsumedDao.findByMaterialPackageConsumption(mpcId);
    }

}
