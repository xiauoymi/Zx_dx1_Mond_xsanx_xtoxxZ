package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.BagType;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 12:13:28 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BagTypeService {

    BagType save(BagType brand);

    BagType update(BagType brand);

    void remove(BagType brand) throws Exception;

    Collection<BagType> findByType(String type) throws Exception;

    Collection<BagType> findAll() throws Exception;

}
