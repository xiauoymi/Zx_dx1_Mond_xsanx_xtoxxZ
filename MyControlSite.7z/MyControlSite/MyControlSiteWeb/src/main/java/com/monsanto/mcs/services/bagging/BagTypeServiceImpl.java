package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BagTypeDao;
import com.monsanto.mcs.model.hibernate.BagType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 12:13:38 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("bagTypeService")
@RemotingDestination
public class BagTypeServiceImpl implements BagTypeService {

    @Autowired
    BagTypeDao dao = null;

    @RemotingInclude
    public BagType save(BagType bagType) {
        bagType.setLastUpdate(new Date());
        BagType result = dao.saveOrUpdate(bagType);
        return result;
    }

    @RemotingInclude
    public BagType update(BagType bagType) {
        bagType.setLastUpdate(new Date());
        BagType result = dao.saveOrUpdate(bagType);
        return result;
    }

    @RemotingInclude
    public void remove(BagType bagType) throws Exception{
        try {
           dao.delete(bagType);
        }
        catch (Exception e) {
            throw new Exception ("Imposible to delete this record");
        }
    }

    @RemotingInclude
    public Collection<BagType> findByType(String type) throws Exception {
        Collection<BagType> results = dao.findByType(type);
        return results;
    }

    @RemotingInclude
    public Collection<BagType> findAll() throws Exception {
        Collection<BagType> results = dao.findAll();
        return results;
    }
}
