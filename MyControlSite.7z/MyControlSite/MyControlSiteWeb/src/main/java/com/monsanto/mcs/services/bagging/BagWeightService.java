package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.BagWeight;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 06:17:54 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BagWeightService {

    BagWeight save(BagWeight bg);

    BagWeight update(BagWeight bg);

    void remove(BagWeight bg) throws Exception;

    Collection<BagWeight> findAll() throws Exception;    

}
