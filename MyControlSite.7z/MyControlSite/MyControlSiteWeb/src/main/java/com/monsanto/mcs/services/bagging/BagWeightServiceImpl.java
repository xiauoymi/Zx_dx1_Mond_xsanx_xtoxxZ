package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BagWeightDao;
import com.monsanto.mcs.model.hibernate.BagWeight;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 06:19:03 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("bagWeightService")
@RemotingDestination
public class BagWeightServiceImpl  implements BagWeightService  {

    @Autowired
    BagWeightDao dao = null;

    @RemotingInclude
    public BagWeight save(BagWeight bw) {
        bw.setLastUpdate(new Date());
        BagWeight result = dao.saveOrUpdate(bw);
        return result;
    }

    @RemotingInclude
    public BagWeight update(BagWeight bw) {
        bw.setLastUpdate(new Date());
        BagWeight result = dao.saveOrUpdate(bw);
        return result;
    }

    @RemotingInclude
    public void remove(BagWeight bw) throws Exception{
        try {
           dao.delete(bw);
        }
        catch (Exception e) {
            throw new Exception ("Imposible to delete this record.");
        }
    }


    @RemotingInclude
    public Collection<BagWeight> findAll() throws Exception {
        Collection<BagWeight> results = dao.findAll();
        return results;
    }

}
