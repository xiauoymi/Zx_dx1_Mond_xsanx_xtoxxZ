package com.monsanto.mcs.services.bagging;

import java.io.InputStream;
import java.io.OutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 6/09/2011
 * Time: 04:29:17 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BaggingControlReportService {
    
    public void createXls(OutputStream out, InputStream in, int plantId, String date, int shift, long order, int folio,  int plantSeasonId) throws Exception;

}
