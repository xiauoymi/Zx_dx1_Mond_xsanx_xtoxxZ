package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BaggingDao;
import com.monsanto.mcs.model.hibernate.*;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 6/09/2011
 * Time: 04:30:20 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("baggingControlReportService")
@RemotingDestination

public class BaggingControlReportServiceImpl implements BaggingControlReportService {

    private String DATE_FORMAT = "dd/MM/yyyy";
    private SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);

    @Autowired
    BaggingDao baggingDao = null;

    @Autowired
    BagConsumedService bagConsumedService = null;

    @Autowired
    FuelleSapCodeService fuelleSapCodeService = null;

    @Autowired
    ChemicalConsumptionService chemicalConsumptionService = null;

    @RemotingInclude
    public void createXls(OutputStream out, InputStream in, int plantId, String dateSelected, int shift, long order, int folio, int plantSeasonId) throws Exception {
        HSSFWorkbook wb = new HSSFWorkbook(in);
        HSSFSheet sheet = wb.getSheetAt(0);

        Date fecha = formatter.parse(dateSelected);
        Collection<Bagging> listOfRecords = baggingDao.findByDateShiftOrder(plantId, fecha, shift, order, folio);
        if (listOfRecords == null || listOfRecords.size() == 0) {
            throw new Exception("No records were found");
        }

        //RETRIEVES THE FIRST RECORD (HEADER)
        Collection<Bagging> col = listOfRecords;
        if (listOfRecords != null && listOfRecords.size() > 0) {
            Bagging header = listOfRecords.iterator().next();
            if (header == null) {
                return;
            }
            // HSSFRow mcsReleaseDate = sheet.getRow(0);
            //  HSSFCell releaseDateCell = mcsReleaseDate.getCell(2);
            //releaseDateCell.setCellValue("Rev.:" + MCSProperties.getVersion() + "  Fecha release:" + MCSProperties.getReleaseDate());

            //STARTS FILLING THE REPORT
            HSSFRow row3 = sheet.getRow(3);
            HSSFCell cellFolio = row3.getCell(3);
            cellFolio.setCellValue(folio);

            HSSFCell cellOrder = row3.getCell(7);
            cellOrder.setCellValue(header.getBaggingOrder().getOrderNumber());

            HSSFCell cellTreatment = row3.getCell(11);
            cellTreatment.setCellValue(header.getBaggingLot().getTreatment().getName());

            HSSFRow row5 = sheet.getRow(5);
            HSSFCell cellDate = row5.getCell(2);
            if (header.getDate() != null) {
                cellDate.setCellValue(header.getDate());
            }

            HSSFCell cellHibrido = row5.getCell(7);
            cellHibrido.setCellValue(header.getHybrid().getName());

            HSSFCell cellOrigen = row5.getCell(11);
            cellOrigen.setCellValue(header.getOrigin().getStrOrigin());
            HSSFCell cellShift = row5.getCell(14);
            cellShift.setCellValue(header.getShift().getName());

            fillsBaggingControlSection(sheet, col);
            //  fillsPlantabilitySection(sheet, col);
            fillsGametSection(sheet, col);
            fillsFuelleSection(sheet, col);
            fillsAnaliticLabel(sheet, col);

            fillsSnicsLabel(sheet, col);
            fillsChemicalConsumption(sheet, plantSeasonId, order, shift, fecha);
            fillsActionAndCommentSection(sheet, col);

            //SHIFT MANAGER
            HSSFRow row43 = sheet.getRow(43);
            HSSFCell cellShiftManager = row43.getCell(1);
            cellShiftManager.setCellValue(header.getBaggingControl().getShiftManager().getFullName());
            HSSFCell cellPlantSupervisor = row43.getCell(14);
            cellPlantSupervisor.setCellValue(header.getMaterialPackageConsumption().getPlantSupervisor().getFirstName()
                    + " " + header.getMaterialPackageConsumption().getPlantSupervisor().getMiddleName()
                    + " " + header.getMaterialPackageConsumption().getPlantSupervisor().getLastName());
            HSSFRow row31 = sheet.getRow(30);
            HSSFCell cellTotalBags = row31.getCell(14);
            cellTotalBags.setCellFormula("SUM(L10:L19)");
            HSSFRow row23 = sheet.getRow(23);
            HSSFCell cellManipulatedBulk = row23.getCell(14);
            cellManipulatedBulk.setCellValue(header.getBaggingControl().getManipulatedBulk() != null ? header.getBaggingControl().getManipulatedBulk() : 0);

            HSSFRow row25 = sheet.getRow(25);
            HSSFCell cellBaggingBulk = row25.getCell(14);
            cellBaggingBulk.setCellFormula("(K10*L10)+(K11*L11)+(K12*L12)+(K13*L13)+(K14*L14)+(K15*L15)+(K16*L16)+(K17*L17)+(K18*L18)+(K19*L19)");

            HSSFRow row27 = sheet.getRow(27);
            HSSFCell cellMixtureLot = row27.getCell(14);
            cellMixtureLot.setCellValue(header.getBaggingOrder().getMixtureLot());


        }
        createXls(wb, out);
    }


    private void fillsActionAndCommentSection(HSSFSheet sheet, Collection<Bagging> collection) {
        StringBuffer action = new StringBuffer("");
        StringBuffer comment = new StringBuffer("");
        for (Bagging record : collection) {
            if (record.getMaterialPackageConsumption() != null
                && record.getMaterialPackageConsumption().getActions() != null
                && record.getMaterialPackageConsumption().getActions().trim().length() > 0) {
                if (action.length() > 0) {
                    action.append(",");
                }
                action.append(record.getMaterialPackageConsumption().getActions());
            }
            if (record.getMaterialPackageConsumption() != null
                && record.getMaterialPackageConsumption().getComments() != null
                && record.getMaterialPackageConsumption().getComments().trim().length() > 0) {
                if (comment.length() > 0) {
                    comment.append(",");
                }
                comment.append(record.getMaterialPackageConsumption().getComments());
            }
        }
        HSSFRow  row33 = sheet.getRow(34);
        HSSFCell cellAction = row33.getCell(9);
        cellAction.setCellValue(action.toString());

        HSSFRow  row38 = sheet.getRow(34);
        HSSFCell cellComment = row38.getCell(9);
        cellComment.setCellValue(comment.toString());
    }

   private void fillsChemicalConsumption(HSSFSheet sheet, int plantSeasonId, long order, int shift, Date date) {
        double totalMaxim = 0;
        double totalKobiol = 0;
        double totalPrecise = 0;
        double totalPoncho = 0;
        double totalBaytan = 0;
        double totalApron = 0;

        double totalColorant = 0;
        try {
           ChemicalConsumption consumption = chemicalConsumptionService.findByDateShiftOrder(plantSeasonId, date, shift, String.valueOf(order));
           if (consumption != null) {
               totalMaxim    += consumption.getMaxim();
               totalKobiol   += consumption.getKobiol();
               totalPrecise  += consumption.getPrecise();
               totalPoncho   += consumption.getPoncho();
               totalBaytan   += consumption.getBaytan();
               totalApron    += consumption.getApron();
               totalColorant += consumption.getGreenColorant() + consumption.getRedColorant();
           } else {
               System.out.println("BaggingControlReportServiceImpl:Es nulo:" + plantSeasonId + "-" + order + "-" + shift);
           }
        } catch (Exception e) {
            System.out.println("fillsChemicalConsumption: " + plantSeasonId + " - " + order);
        }
        HSSFRow row23 = sheet.getRow(23);
        HSSFCell cellMaxim = row23.getCell(12);
        cellMaxim.setCellValue(totalMaxim);

        HSSFRow row24 = sheet.getRow(24);
        HSSFCell cellKobiol = row24.getCell(12);
        cellKobiol.setCellValue(totalKobiol);

        HSSFRow row25 = sheet.getRow(25);
        HSSFCell cellPrecise = row25.getCell(12);
        cellPrecise.setCellValue(totalPrecise);

        HSSFRow row26 = sheet.getRow(26);
       HSSFCell cellPoncho = row26.getCell(12);
       cellPoncho.setCellValue(totalPoncho);

       HSSFRow row27 = sheet.getRow(27);
       HSSFCell cellBaytan = row27.getCell(12);
       cellBaytan.setCellValue(totalBaytan);

       HSSFRow row28 = sheet.getRow(28);
       HSSFCell cellApron = row28.getCell(12);
       cellApron.setCellValue(totalApron);

        HSSFRow row36 = sheet.getRow(29);
        HSSFCell cellColorant = row36.getCell(12);
        cellColorant.setCellValue(totalColorant);
    }

    private void fillsSnicsLabel(HSSFSheet sheet, Collection<Bagging> collection) {
        double total = 0;
        for (Bagging record : collection) {
            total += record.getSnicsLabel().getTotalSnics();
        }
        HSSFRow  row = sheet.getRow(28);
        HSSFCell cell = row.getCell(10);
        cell.setCellValue(total);
    }

    private void fillsAnaliticLabel(HSSFSheet sheet, Collection<Bagging> collection) {
        double total = 0;
        for (Bagging record : collection) {
            total += record.getMaterialPackageConsumption().getAnaliticalLab();
        }
        HSSFRow  row  = sheet.getRow(27);
        HSSFCell cell = row.getCell(10);
        cell.setCellValue(total);
    }

    private void fillsFuelleSection(HSSFSheet sheet, Collection<Bagging> collection) {
       Collection<BagConsumed> bagConsumedList = null;
       Collection<FuelleSapCode> fuelleSapCodeList = null;
       int currentRow = 23;
       String[] fuelleSizes = {"2\"", "3\"", "4 1/2\"", "6\""};
       try {
           for (String size : fuelleSizes) {
               double total = 0;
               for (Bagging record : collection) {
                   MaterialPackageConsumption mpc = record.getMaterialPackageConsumption();
                   //TAKES THE CURRENT SIZE, AND RETRIEVES THE DATA
                   bagConsumedList = bagConsumedService.findByMaterialPackageConsumption(mpc.getId());
                   fuelleSapCodeList = fuelleSapCodeService.findByBagType(mpc.getBagType(), mpc.getBrand());
                   if (bagConsumedList != null) {
                       if (fuelleSapCodeList != null) {
                           for (FuelleSapCode entry : fuelleSapCodeList) {
                               if (entry != null) {
                                   if (entry.getFuelle().getName().equalsIgnoreCase(size)) {
                                      total += getBagsByWeight(entry.getFuelle().getName(), bagConsumedList);
                                   }
                               }
                           }

                       }
                   } else {
                       System.out.println("bagConsumedList is null:" + mpc.getId());
                   }
               }
               HSSFRow  row = sheet.getRow(currentRow);
               HSSFCell cellQuantity  = row.getCell(10);
               cellQuantity.setCellValue(total);
               currentRow++;
           }
       } catch (Exception e) {
           System.out.println("Unable to retrieve fulle section:" + e.getMessage());
       }
    }

    private double getBagsByWeight(String fuelle, Collection<BagConsumed> bagConsumedList) {
        double bags = 0;
            for (BagConsumed savedBagConsumed : bagConsumedList) {
                if ((fuelle.equalsIgnoreCase(savedBagConsumed.getFuelleSapCode().getFuelle().getName()))) {
                    bags = savedBagConsumed.getBags();
                    break;
                }
            }
        return bags;
    }

    private void fillsGametSection(HSSFSheet sheet, Collection<Bagging> collection) {
        //FILLS GAMET SECTION
        int currentRow = 22;
        for (Bagging record : collection) {
            if (record.getGamet() != null) {
                HSSFRow  row22 = sheet.getRow(currentRow);
                HSSFCell cellGametTon = row22.getCell(1);
                cellGametTon.setCellValue(record.getGamet().getTons());

                HSSFCell cellGametFrecuency = row22.getCell(3);
                cellGametFrecuency.setCellValue(record.getGamet().getFrequency());

                HSSFCell cellGametPurge = row22.getCell(4);
                cellGametPurge.setCellValue(record.getGamet().getPurge() ? "SI" : "NO");

                HSSFCell cellGametOperation = row22.getCell(6);
                cellGametOperation.setCellValue(record.getGamet().getOperation() ? "OK" : "Falla");
                currentRow++;
            }
        }
    }

  /*  private void fillsPlantabilitySection(HSSFSheet sheet, Collection<Bagging> collection) {
        //FILLS PLANTABILITY TEST
        int currentRow = 22;
        for (Bagging record : collection) {
            if (record.getPlantabilityTest() != null) {
                HSSFRow  row = sheet.getRow(currentRow);
                HSSFCell cellPlate = row.getCell(1);
                cellPlate.setCellValue(record.getPlantabilityTest().getPlate().getCode());

                HSSFCell cellVerPlantability = row.getCell(2);
                cellVerPlantability.setCellValue(record.getPlantabilityTest().getVerification() ? "SI" : "NO");

                HSSFCell cellRep1 = row.getCell(3);
                cellRep1.setCellValue(record.getPlantabilityTest().getCounts1());

                HSSFCell cellRep2 = row.getCell(4);
                cellRep2.setCellValue(record.getPlantabilityTest().getCounts2());

                HSSFCell cellRep3 = row.getCell(6);
                cellRep3.setCellValue(record.getPlantabilityTest().getCounts3());

                HSSFCell cellAve  = row.getCell(8);
                cellAve.setCellValue(record.getPlantabilityTest().getCountsAvg());
                currentRow += 2;
            }
        }
    }     */

    private void fillsBaggingControlSection(HSSFSheet sheet, Collection<Bagging> col)
    {
        int currentRow = 9;
        for (Bagging record : col) {
                HSSFRow  row9 = sheet.getRow(currentRow);
                HSSFCell cellTolva = row9.getCell(1);
                cellTolva.setCellValue(record.getBaggingControl().getBin().getBinValue());

                HSSFCell cellSize  = row9.getCell(2);
                cellSize.setCellValue(record.getBaggingLot().getSeedSize());

                HSSFCell cellLot   = row9.getCell(3);
                cellLot.setCellValue(record.getBaggingLot().getDescription());

                HSSFCell cellCount1 = row9.getCell(4);
                cellCount1.setCellValue(record.getBaggingControl().getCounts1());

                HSSFCell cellCount2 = row9.getCell(5);
                cellCount2.setCellValue(record.getBaggingControl().getCounts2());

                HSSFCell cellCount3 = row9.getCell(6);
                cellCount3.setCellValue(record.getBaggingControl().getCounts3());

                HSSFCell cellAverage = row9.getCell(7);
                cellAverage.setCellValue(record.getBaggingControl().getCountsAvg());

                HSSFCell cellSeedsPerKg = row9.getCell(8);
                cellSeedsPerKg.setCellValue(record.getBaggingControl().getSeedKilogram());

                if (record.getBaggingControl() != null && record.getBaggingControl().getPresentation() != null) {
                   HSSFCell cellPresentation = row9.getCell(9);
                   cellPresentation.setCellValue(record.getBaggingControl().getPresentation().getValue());
                }

                HSSFCell cellWeightKg = row9.getCell(10);
                cellWeightKg.setCellValue(record.getBaggingControl().getLabeledWeigth());

                HSSFCell cellBaggedBags = row9.getCell(11);
                cellBaggedBags.setCellValue(record.getBaggingControl().getBaggedBags());

                HSSFCell cellFolioInitial = row9.getCell(12);
                cellFolioInitial.setCellValue(record.getSnicsLabel().getInitialFolio());

                HSSFCell cellFolioFinal   = row9.getCell(13);
                cellFolioFinal.setCellValue(record.getSnicsLabel().getFinalFolio());

               // HSSFCell cellTarima       = row9.getCell(14);
               // String tarima = (record.getBaggingControl().getTarima1()).intValue() + "/" + (record.getBaggingControl().getTarima2()).intValue()
                  //               + "  " + (record.getBaggingControl().getTarima3()).intValue() + "/" + (record.getBaggingControl().getTarima4()).intValue();
                //cellTarima.setCellValue(tarima);
                HSSFCell cellVerification = row9.getCell(15);
                cellVerification.setCellValue(record.getBaggingControl().getVerification() ? "SI" : "NO");
                currentRow++;
        }
    }

    private void createXls(HSSFWorkbook wb, OutputStream out) throws Exception {
        wb.write(out);
    }

}
