package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.BaggingControl;
import com.monsanto.mcs.model.hibernate.BaggingLot;

import java.util.Collection;


public interface BaggingControlService {

    BaggingControl save(BaggingControl baggingControl);

    BaggingControl update(BaggingControl baggingControl);

    void remove(BaggingControl baggingControl);

    Collection<BaggingControl> findAll() throws Exception;
}
