package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BaggingControlDao;
import com.monsanto.mcs.model.hibernate.BaggingControl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("baggingControlService")
@RemotingDestination
public class BaggingControlServiceImpl implements BaggingControlService {

    @Autowired
    BaggingControlDao baggingControlDao = null;


    @RemotingInclude
    public void remove(BaggingControl baggingControl) {
        baggingControlDao.delete(baggingControl);
    }

    @RemotingInclude
    public BaggingControl save(BaggingControl baggingControl) {
        return baggingControlDao.saveOrUpdate(baggingControl);
    }

    @RemotingInclude
    public BaggingControl update(BaggingControl baggingControl) {
        return baggingControlDao.saveOrUpdate(baggingControl);
    }

    @RemotingInclude
    public Collection<BaggingControl> findAll() throws Exception {
        Collection<BaggingControl> baggingControls = baggingControlDao.findAll();
        return baggingControls;
    }
}
