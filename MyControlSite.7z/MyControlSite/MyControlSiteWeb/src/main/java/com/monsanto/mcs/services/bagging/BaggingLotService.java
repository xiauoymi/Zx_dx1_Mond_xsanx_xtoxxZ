package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.BaggingLot;
import java.util.Collection;


public interface BaggingLotService {

    BaggingLot save(BaggingLot baggingLot);

    BaggingLot update(BaggingLot baggingLot);

    void remove(BaggingLot baggingLot);

    Collection<BaggingLot> findAll() throws Exception;
}
