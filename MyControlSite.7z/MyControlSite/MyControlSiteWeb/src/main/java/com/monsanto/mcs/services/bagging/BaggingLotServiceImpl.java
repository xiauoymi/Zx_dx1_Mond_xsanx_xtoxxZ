package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BaggingLotDao;
import com.monsanto.mcs.model.hibernate.BaggingLot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("baggingLotService")
@RemotingDestination
public class BaggingLotServiceImpl implements BaggingLotService {

    @Autowired
    BaggingLotDao baggingLotDao = null;


    @RemotingInclude
    public void remove(BaggingLot baggingLot) {
        baggingLotDao.delete(baggingLot);
    }

    @RemotingInclude
    public BaggingLot save(BaggingLot baggingLot) {
        return baggingLotDao.saveOrUpdate(baggingLot);
    }

    @RemotingInclude
    public BaggingLot update(BaggingLot baggingLot) {
        return baggingLotDao.saveOrUpdate(baggingLot);
    }

    @RemotingInclude
    public Collection<BaggingLot> findAll() throws Exception {
        Collection<BaggingLot> baggingLots = baggingLotDao.findAll();
        return baggingLots;
    }
}
