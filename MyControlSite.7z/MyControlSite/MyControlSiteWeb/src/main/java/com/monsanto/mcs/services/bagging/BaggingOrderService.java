package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.BaggingOrder;

import java.util.Collection;

public interface BaggingOrderService {

    BaggingOrder save(BaggingOrder baggingOrder);

    BaggingOrder update(BaggingOrder baggingOrder);

    void remove(BaggingOrder baggingOrder);

    Collection<BaggingOrder> findBaggingOrdersByLot(String lot) throws Exception;

    Collection<BaggingOrder> findAll() throws Exception;

    Collection<BaggingOrder> findBaggingOrdersByOrder(long orderNumber) throws Exception;

    Collection<BaggingOrder> findByOrderBaggingMixtureMaterial(long orderNumber,String baggingLot,String mixtureLot,long materialNumber) throws Exception;

    Collection<BaggingOrder> findUnfilteredBaggingOrders() throws Exception;

}
