package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BaggingOrderDao;
import com.monsanto.mcs.model.hibernate.BaggingOrder;
import com.monsanto.mcs.model.hibernate.SapBaggingOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

@Service("baggingOrderService")
@RemotingDestination
public class BaggingOrderServiceImpl implements BaggingOrderService {

    @Autowired
    BaggingOrderDao baggingOrderDao;

    @Autowired
    SapBaggingOrderService sapBaggingOrderService;

    @RemotingInclude
    public void remove(BaggingOrder baggingOrder) {
        baggingOrderDao.delete(baggingOrder);
    }

    @RemotingInclude
    public BaggingOrder save(BaggingOrder baggingOrder) {
        return baggingOrderDao.saveOrUpdate(baggingOrder);
    }

    @RemotingInclude
    public BaggingOrder update(BaggingOrder baggingOrder) {
        return baggingOrderDao.saveOrUpdate(baggingOrder);
    }

    @RemotingInclude
    public Collection<BaggingOrder> findAll() throws Exception {
        return baggingOrderDao.findAll();
    }

    @RemotingInclude
    public Collection<BaggingOrder> findBaggingOrdersByLot(String lot) throws Exception {
        return baggingOrderDao.findBaggingOrdersByLot(lot);
    }

    @RemotingInclude
    public Collection<BaggingOrder> findBaggingOrdersByOrder(long orderNumber) throws Exception {
        return baggingOrderDao.findBaggingOrdersByOrder(orderNumber);
    }

    @RemotingInclude
    public Collection<BaggingOrder> findByOrderBaggingMixtureMaterial(long orderNumber, String baggingLot, String mixtureLot, long materialNumber) throws Exception {
        return baggingOrderDao.findByOrderBaggingMixtureMaterial(orderNumber, baggingLot, mixtureLot, materialNumber);
    }

    @RemotingInclude
    public Collection<BaggingOrder> findUnfilteredBaggingOrders() throws Exception {
        Collection<BaggingOrder> baggingOrders = new ArrayList<BaggingOrder>();
        Collection<SapBaggingOrder> sapBaggingOrders = sapBaggingOrderService.findAllUnfilteredSapBaggingOrders();
        for (SapBaggingOrder sapBaggingOrder : sapBaggingOrders) {
            BaggingOrder baggingOrder = new BaggingOrder();
            baggingOrder.setBaggingLot(sapBaggingOrder.getBaggingLot());
            baggingOrder.setDescription(sapBaggingOrder.getDescription());
            baggingOrder.setHybrid(sapBaggingOrder.getHybrid());
            baggingOrder.setMaterialNumber(sapBaggingOrder.getMaterialNumber());
            baggingOrder.setMixtureLot(sapBaggingOrder.getMixtureLot());
            baggingOrder.setOrderNumber(sapBaggingOrder.getOrderNumber());
            baggingOrder.setPlantId(sapBaggingOrder.getPlantId());
            baggingOrder.setDate(sapBaggingOrder.getDate());
            baggingOrders.add(baggingOrder);
        }
        return baggingOrders;
    }

}
