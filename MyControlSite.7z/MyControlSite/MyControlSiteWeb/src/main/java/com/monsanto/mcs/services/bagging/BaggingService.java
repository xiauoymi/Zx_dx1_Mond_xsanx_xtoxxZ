package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Bagging;
import com.monsanto.mcs.model.hibernate.Shift;
import java.util.Collection;
import java.util.Date;

public interface BaggingService {

    Bagging save(Bagging bagging, String baggingDate) throws Exception;

    Bagging update(Bagging bagging);

    void remove(Bagging bagging);

    Collection<Bagging> findAll() throws Exception;

    Collection<Bagging> findByDateShiftOrder(int plantId,String date, Shift shift,long order);

    Collection<Bagging> findByDateShiftOrder(int plantId,String date, int shift,long order, int folio);

    Collection<Bagging> findBytOrderHybridLot(int plantId,String date, Shift shift,long order,String hybridName,String baggingLot);

    Collection<Bagging> findByFolio(int plantId,String date, Shift shift,long folio);

    Collection<Bagging> findByBaggingOrder(long baggingOrder);

    Bagging findFirstBaggingOrder(long baggingOrder);

    double getTotalPonchoBagged(Collection <Bagging> collection, String year, String month);

    Collection<Bagging> findByDateShiftOrderSeason(int plantId,String date, Shift shift,long order,int seasonId);

    Collection<Bagging> findByOrderHybridLotSeason(int plantId,String date, Shift shift,long order,String hybridName,String baggingLot,int seasonId);

    Collection<Bagging> findByFolioSeason(int plantId,String date, Shift shift,long folio,int seasonId);

    int findNextRecord(long orderNumber, String baggingDate, Shift shift);

}
