package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BaggingDao;
import com.monsanto.mcs.model.hibernate.Bagging;
import com.monsanto.mcs.model.hibernate.MaterialPackageConsumption;
import com.monsanto.mcs.model.hibernate.MixtureLot;
import com.monsanto.mcs.model.hibernate.Shift;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;

@Service("baggingService")
@RemotingDestination
public class BaggingServiceImpl implements BaggingService {

    @Autowired
    BaggingDao baggingDao = null;

    @Autowired
    MixtureLotService mixtureLotService = null;

    @Autowired
    MaterialPackageConsumptionService materialPackageConsumptionService = null;

    @RemotingInclude
    public void remove(Bagging bagging) {
        Collection<MixtureLot> mixtureLots = null;
        try {
            mixtureLots = mixtureLotService.findByBagging(bagging.getId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null != mixtureLots) {
            for (MixtureLot entry : mixtureLots) {
                mixtureLotService.remove(entry);
            }
        }
        baggingDao.delete(bagging);
    }

    @RemotingInclude
    public Bagging save(Bagging bagging, String baggingDate) throws Exception {
        Bagging saved = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        try {
            Date assignedDate = sdf.parse(baggingDate);
            if (null != bagging) {
                bagging.setDate(assignedDate);
                MaterialPackageConsumption savedMPC = materialPackageConsumptionService.save(bagging.getMaterialPackageConsumption());
                bagging.setMaterialPackageConsumption(savedMPC);
                saved = baggingDao.saveOrUpdate(bagging);
                if (bagging.getMixtureLots() != null) {
                    for (MixtureLot entry : (bagging.getMixtureLots())) {
                        entry.setBagging(saved);
                        mixtureLotService.save(entry);
                    }
                }
            }
        } catch (java.text.ParseException dfe) {
            throw new Exception("La fecha introducida es incorrecta.");

        } catch (Exception e) {
            e.printStackTrace();
            throw new Exception("Imposible to save");
        }
        return saved;
    }

    @RemotingInclude
    public Bagging update(Bagging bagging) {
        return baggingDao.saveOrUpdate(bagging);
    }

    @RemotingInclude
    public Collection<Bagging> findAll() throws Exception {
        return baggingDao.findAll();
    }

    @RemotingInclude
    public Collection<Bagging> findByDateShiftOrder(int plantId, String date, Shift shift, long order) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date processingDate = null;
        try {
            if (date != null && date.length() > 0) {
                processingDate = sdf.parse(date);
            }
        } catch (Exception e) {
            System.out.println("Error (findByDateShiftOrder):" + e.getMessage() + "-" + date + "-" + plantId + "-" + shift);
        }
        return baggingDao.findByDateShiftOrder(plantId, processingDate, shift, order);
    }

    @RemotingInclude
    public Collection<Bagging> findBytOrderHybridLot(int plantId, String date, Shift shift, long order, String hybridName, String baggingLot) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date processingDate = null;
        try {
            if (date != null && date.length() > 0) {
                processingDate = sdf.parse(date);
            }
        } catch (Exception e) {
            System.out.println("Error (findBytOrderHybridLot):" + e.getMessage() + "-" + date + "-" + plantId + "-" + shift);
        }
        return baggingDao.findByOrderHybridLot(plantId, processingDate, shift, order, hybridName, baggingLot);
    }

    @RemotingInclude
    public Collection<Bagging> findByFolio(int plantId, String date, Shift shift, long folio) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date processingDate = null;
        try {
            if (date != null && date.length() > 0) {
                processingDate = sdf.parse(date);
            }
        } catch (Exception e) {
            System.out.println("Error (findByFolio):" + e.getMessage() + "-" + date + "-" + plantId + "-" + shift);
        }
        return baggingDao.findByFolio(plantId, processingDate, shift, folio);
    }

    @RemotingInclude
    public Collection<Bagging> findByDateShiftOrder(int plantId, String date, int shift, long order, int folio) {
        Collection<Bagging> baggings = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date processingDate = null;
        try {
             if (date != null) {
                 processingDate = sdf.parse(date);
             }
             baggings = baggingDao.findByDateShiftOrder(plantId, processingDate, shift, order, folio);
        } catch (Exception e) {
            System.out.println("Error:" + e.getMessage() + " Values:" + plantId + "-" + date + "-" + shift + "-" + order + "-" + folio);
        }
        return baggings;
    }

    @RemotingInclude
    public Collection<Bagging> findByBaggingOrder(long baggingOrder) {
        return baggingDao.findByBaggingOrder(baggingOrder);
    }

    @RemotingInclude
    public Bagging findFirstBaggingOrder(long baggingOrder) {
        Bagging result = null;
        Collection<Bagging> baggings = baggingDao.findByBaggingOrder(baggingOrder);
        if (baggings != null && baggings.size() > 0) {
            result = baggings.iterator().next();
        }
        return result;
    }

    public double getTotalPonchoBagged(Collection<Bagging> collection, String year, String month) {
        double feedback = 0;
        if (collection == null) {
            return feedback;
        }
        for (Bagging record : collection) {
            String treatment = record.getBaggingLot().getTreatment().getName();
            if (treatment != null && treatment.trim().equalsIgnoreCase("PONCHO")) {
                if (dateInRange(record.getBaggingDate(), year, month)) {
                    feedback += record.getBaggingControl().getBagWeigth();
                }
            }
        }
        return feedback;
    }

    private boolean dateInRange(String date, String year, String month) {
        boolean feedback = false;
        if (date.substring(6, 10).equalsIgnoreCase(year)
            && date.substring(3, 5).equalsIgnoreCase(month)) {
            feedback = true;
        }
        return feedback;
    }

    @RemotingInclude
    public Collection<Bagging> findByDateShiftOrderSeason(int plantId, String date, Shift shift, long order, int seasonId) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date processingDate = null;
        try {
            if (date != null && date.length() > 0) {
                processingDate = sdf.parse(date);
            }
        } catch (Exception e) {
            System.out.println("Error (findByDateShiftOrder):" + e.getMessage() + "-" + date + "-" + plantId + "-" + shift);
        }
        return baggingDao.findByDateShiftOrderSeason(plantId, processingDate, shift, order, seasonId);
    }

    @RemotingInclude
    public Collection<Bagging> findByOrderHybridLotSeason(int plantId, String date, Shift shift, long order, String hybridName, String baggingLot, int seasonId) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date processingDate = null;
        try {
            if (date != null && date.length() > 0) {
                processingDate = sdf.parse(date);
            }
        } catch (Exception e) {
            System.out.println("Error (findByOrderHybridLot):" + e.getMessage() + "-" + date + "-" + plantId + "-" + shift);
        }
        return baggingDao.findByOrderHybridLotSeason(plantId, processingDate, shift, order, hybridName, baggingLot, seasonId);
    }

    @RemotingInclude
    public Collection<Bagging> findByFolioSeason(int plantId, String date, Shift shift, long folio, int seasonId) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date processingDate = null;
        try {
            if (date != null && date.length() > 0) {
                processingDate = sdf.parse(date);
            }
        } catch (Exception e) {
            System.out.println("Error (findByFolio):" + e.getMessage() + "-" + date + "-" + plantId + "-" + shift);
        }
        return baggingDao.findByFolioSeason(plantId, processingDate, shift, folio, seasonId);
    }

    @RemotingInclude
    public int findNextRecord(long orderNumber, String baggingDate, Shift shift) {
        int record = 0;
        try {
            DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
            Date date = df.parse(baggingDate);
            record = baggingDao.findNextRecord(orderNumber, date, shift);
        } catch (Exception e) {
            record = 1;
        }
        return record;
    }

}
