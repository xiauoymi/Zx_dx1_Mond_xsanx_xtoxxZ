package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.BaggingViewPKI;
import java.util.Collection;

public interface BaggingViewPKIService {

    Collection<BaggingViewPKI> findAll() throws Exception;

    Collection<BaggingViewPKI> findByPlantSeason(int idPlant, int idSeason) throws Exception;

    double getPonchoTotals(Collection <BaggingViewPKI> collection, String year, String month) throws Exception;

    double getBaggedUnits(Collection <BaggingViewPKI> collection, String year, String month) throws Exception;


}
