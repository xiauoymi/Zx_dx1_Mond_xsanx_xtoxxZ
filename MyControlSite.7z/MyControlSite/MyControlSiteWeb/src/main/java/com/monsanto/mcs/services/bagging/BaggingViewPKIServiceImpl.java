package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BaggingViewPKIDao;
import com.monsanto.mcs.model.hibernate.BaggingViewPKI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("baggingViewServicePKI")
@RemotingDestination
public class BaggingViewPKIServiceImpl implements BaggingViewPKIService {

    private static final String PONCHO = "PONCHO";

    @Autowired
    private BaggingViewPKIDao baggingViewPKIDao = null;

    public Collection<BaggingViewPKI> findAll() throws Exception {
        return baggingViewPKIDao.findAll();
    }

    public Collection<BaggingViewPKI> findByPlantSeason(int idPlant, int idSeason) throws Exception {
        return baggingViewPKIDao.findByPlantSeason(idPlant,idSeason);
    }

    public double getPonchoTotals(Collection <BaggingViewPKI> collection, String year, String month) throws Exception {
        // ONLY TREATMENT = PONCHO
        double feedback = 0;
        if (collection == null) {
            return 0;
        }
        for (BaggingViewPKI item : collection) {
            if (item.getBaggingDate() != null     && item.getBaggedBags() != null &&
                item.getPresentacionDsc() != null && item.getTreatment() != null  &&
                item.getTreatment().trim().equalsIgnoreCase(PONCHO) ) {
                if (dateInRange(item.getBaggingDate(), year, month)) {
                    feedback += getU80m(item.getPresentacionDsc(), item.getBaggedBags());
                }
            }
        }
        return feedback;
    }

    public double getBaggedUnits(Collection <BaggingViewPKI> collection, String year, String month) throws Exception {
        //ALL TREATMETS
        double feedback = 0;
        if (collection == null) {
            return 0;
        }
        for (BaggingViewPKI item : collection) {
            if (item.getBaggingDate() != null     && item.getBaggedBags() != null &&
                item.getPresentacionDsc() != null && item.getTreatment() != null) {

                if (dateInRange(item.getBaggingDate(), year, month)) {
                    feedback += getU80m(item.getPresentacionDsc(), item.getBaggedBags());
                }
            }
        }
        return feedback;
    }

    private boolean dateInRange(String date, String year, String month) {
        boolean feedback = false;
        if (date.substring(0, 4).equalsIgnoreCase(year) &&
            date.substring(5, 7).equalsIgnoreCase(month)) {
            feedback = true;
        }
        return feedback;
    }

    private double getU80m(double presentation, double baggedBags) {
        double feedback = 0;
        if (presentation == 20) {
            feedback = baggedBags;
        } else if (presentation == 10) {
            feedback = baggedBags / 2;
        } else {
            feedback = (baggedBags * presentation)  / 80000;
        }
        return feedback;
    }

}

