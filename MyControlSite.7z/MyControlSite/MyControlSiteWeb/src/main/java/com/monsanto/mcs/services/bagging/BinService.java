package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Bin;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 06:51:05 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BinService {


    Bin save(Bin bin);

    Bin update(Bin bin);

    void remove(Bin bin) throws Exception;

    Collection<Bin> findByPlant(int plant) throws Exception;

    Collection<Bin> findAll() throws Exception;

}
