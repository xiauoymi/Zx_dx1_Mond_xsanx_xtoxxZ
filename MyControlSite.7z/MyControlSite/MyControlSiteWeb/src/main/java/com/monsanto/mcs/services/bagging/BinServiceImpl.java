package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BinDao;
import com.monsanto.mcs.model.hibernate.Bin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 06:52:08 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("binService")
@RemotingDestination
public class BinServiceImpl implements BinService {

    @Autowired
    BinDao dao = null;

    @RemotingInclude
    public Bin save(Bin bin) {
        bin.setLastUpdate(new Date());
        Bin result = dao.saveOrUpdate(bin);
        return result;
    }

    @RemotingInclude
    public Bin update(Bin bin) {
        bin.setLastUpdate(new Date());
        Bin result = dao.saveOrUpdate(bin);
        return result;
    }

    @RemotingInclude
    public void remove(Bin bin) throws Exception {
        try {
           dao.delete(bin);
        }
        catch (Exception e) {
            throw new Exception ("Imposible to delete this record");
        }
    }

    @RemotingInclude
    public Collection<Bin> findByPlant(int plantId) throws Exception {
        Collection<Bin> results = dao.findByPlant(plantId);
        return results;
    }

    @RemotingInclude
    public Collection<Bin> findAll() throws Exception {
        Collection<Bin> results = dao.findAll();
        return results;
    }


}
