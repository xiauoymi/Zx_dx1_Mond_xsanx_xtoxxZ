package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Brand;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * To change this template use File | Settings | File Templates.
 */
public interface BrandService {

    Brand save(Brand brand);

    Brand update(Brand brand);

    void remove(Brand brand) throws Exception;

    Collection<Brand> findByName(String name) throws Exception;

    Collection<Brand> findAll() throws Exception;
}
