package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BrandDao;
import com.monsanto.mcs.model.hibernate.Brand;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingExclude;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * To change this template use File | Settings | File Templates.
 */
@Service("brandService")
@RemotingDestination
public class BrandServiceImpl implements BrandService {

    @Autowired
    BrandDao brandDao = null;


    @RemotingInclude
    public Collection<Brand> findByName(String name) throws Exception {
        Collection<Brand> results = brandDao.findByName(name);
        return results;

    }

    @RemotingInclude
    public void remove(Brand brand) throws Exception {
        try {
           brandDao.delete(brand);
        }
        catch (Exception e) {
           throw new Exception ("Imposible to delete this record");
        }
    }

    @RemotingInclude
    public Brand save(Brand brand) {
        brand.setLastUpdate(new Date());
        Brand result = brandDao.saveOrUpdate(brand);
        return result;
    }

    @RemotingInclude
    public Brand update(Brand brand) {
        Brand result = brandDao.saveOrUpdate(brand);
        brand.setLastUpdate(new Date());
        return result;
    }

    @RemotingInclude
    public Collection<Brand> findAll() throws Exception {
        Collection<Brand> brands = brandDao.findAll();
        return brands;
    }
}
