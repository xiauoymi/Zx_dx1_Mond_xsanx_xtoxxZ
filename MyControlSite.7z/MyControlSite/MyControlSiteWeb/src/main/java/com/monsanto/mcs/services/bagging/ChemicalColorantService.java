package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.ChemicalColorant;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 05:48:14 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ChemicalColorantService {

    ChemicalColorant save(ChemicalColorant chemicalColorant) throws Exception;

    ChemicalColorant update(ChemicalColorant chemicalColorant) throws Exception;

    void remove(ChemicalColorant chemicalColorant) throws Exception;

    Collection<ChemicalColorant> findByColorant(String colorant) throws Exception;

    Collection<ChemicalColorant> findByCode(String code) throws Exception;

    Collection<ChemicalColorant> findAll() throws Exception;


}
