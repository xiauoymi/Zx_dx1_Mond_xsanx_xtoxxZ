package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.ChemicalColorantDao;
import com.monsanto.mcs.model.hibernate.ChemicalColorant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 05:48:26 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("chemicalColorantService")
@RemotingDestination
public class ChemicalColorantServiceImpl implements ChemicalColorantService {

    @Autowired
    ChemicalColorantDao dao = null;

    @RemotingInclude
    public ChemicalColorant save(ChemicalColorant cc) throws Exception{
        ChemicalColorant result = null;
        try {
           cc.setLastUpdate(new Date());
           result = dao.saveOrUpdate(cc);
        }
        catch(Exception e) {
            throw new Exception("Imposible to create record.");
        }
        return result;
    }

    @RemotingInclude
    public ChemicalColorant update(ChemicalColorant cc) throws Exception {
        ChemicalColorant result = null;
        try {
           cc.setLastUpdate(new Date());
           result = dao.saveOrUpdate(cc);
        }
        catch (Exception e) {
            throw new Exception("Imposible to update record");
        }
        return result;
    }

    @RemotingInclude
    public void remove(ChemicalColorant cc) throws Exception {
        try {
           dao.delete(cc);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public Collection<ChemicalColorant> findByColorant(String colorant) throws Exception {
        Collection<ChemicalColorant> results = dao.findByColorant(colorant);
        return results;
    }

    @RemotingInclude
    public Collection<ChemicalColorant> findByCode(String code) throws Exception {
        Collection<ChemicalColorant> results = dao.findByCode(code);
        return results;
    }


    @RemotingInclude
    public Collection<ChemicalColorant> findAll() throws Exception {
        Collection<ChemicalColorant> results = dao.findAll();
        return results;
    }

}
