package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.ChemicalConsumption;
import com.monsanto.mcs.model.hibernate.Schedule;

import java.util.Collection;
import java.util.Date;

public interface ChemicalConsumptionService {

    ChemicalConsumption save(ChemicalConsumption chemicalConsumption);

    ChemicalConsumption update(ChemicalConsumption chemicalConsumption);

    void remove(ChemicalConsumption chemicalConsumption);

    Collection<ChemicalConsumption> findAll() throws Exception;

    Collection<ChemicalConsumption> findAllByPlantSeason(long plantSeasonId,String orderNumber) throws Exception;

    Collection<ChemicalConsumption> findAllByPlantSeason(long plantSeason, String orderNumber, int shift) throws Exception;

    ChemicalConsumption findByDateShiftOrder(long plantSeason, Date date, int shift,String orderNumber) throws Exception;

    ChemicalConsumption findByOrderNumber(String orderNumber) throws Exception;

    ChemicalConsumption getChemicalConsumption(Date date, Schedule schedule,String orderNumber,String hybrid,String treatmentName,int plantSeason,double ltsTons,double slurryReference,double ponchoReference,double preciseReference) throws Exception;

    double getColorantFactor(Collection <ChemicalConsumption> list, String year, String month, int colorant) throws Exception;    
}
