package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.ChemicalConsumptionDao;
import com.monsanto.mcs.dao.PlantTreatmentDao;
import com.monsanto.mcs.model.hibernate.*;
import com.monsanto.mcs.services.batch.HybridService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;

@Service("chemicalConsumptionService")
@RemotingDestination
public class ChemicalConsumptionServiceImpl implements ChemicalConsumptionService {

    private static final String APRON = "APRON";
    private static final String BAYTAN = "BAYTAN";
    private static final String DINASTY = "DINASTY";
    private static final String KOBIOL = "K-OBIOL";
    private static final String MAXIM = "MAXIM";
    private static final String PONCHO = "PONCHO";
    private static final String PRECISE = "PRECISE";
    private static final String GREEN_COLORANT_NAME = "GREEN";
    private static final String RED_COLORANT_NAME = "RED";

    private HashMap<Chemicals,Double> chemicalsConsumption;

    private static final int RED_COLORANT = 1;
    private static final int MAXIM_COLORANT = 2;
    private static final int KOBIOL_COLORANT = 2;

    @Autowired
    private ChemicalTreatmentService chemicalTreatmentService = null;

    @Autowired
    private ChemicalDensityDoseService chemicalDensityDoseService = null;

    @Autowired
    private TreatmentService treatmentService = null;

    @Autowired
    private ChemicalsService chemicalsService = null;

    @Autowired
    private ColorantHybridService colorantHybridService = null;

    @Autowired
    ChemicalConsumptionDao chemicalConsumptionDao = null;

    @Autowired
    private HybridService hybridService = null;

    public ChemicalConsumptionServiceImpl() throws Exception{
        chemicalsConsumption = new HashMap<Chemicals,Double>();
    }

    private void initializeChemicalsConsumption() throws Exception{
        chemicalsConsumption.put(chemicalsService.findByChemicalName(APRON).iterator().next(),0D);
        chemicalsConsumption.put(chemicalsService.findByChemicalName(BAYTAN).iterator().next(),0D);
        chemicalsConsumption.put(chemicalsService.findByChemicalName(DINASTY).iterator().next(),0D);
        chemicalsConsumption.put(chemicalsService.findByChemicalName(KOBIOL).iterator().next(),0D);
        chemicalsConsumption.put(chemicalsService.findByChemicalName(MAXIM).iterator().next(),0D);
        chemicalsConsumption.put(chemicalsService.findByChemicalName(PONCHO).iterator().next(),0D);
        chemicalsConsumption.put(chemicalsService.findByChemicalName(PRECISE).iterator().next(),0D);
        chemicalsConsumption.put(chemicalsService.findByChemicalName(GREEN_COLORANT_NAME).iterator().next(),0D);
        chemicalsConsumption.put(chemicalsService.findByChemicalName(RED_COLORANT_NAME).iterator().next(),0D);
    }

    @RemotingInclude
    public void remove(ChemicalConsumption chemicalConsumption) {
        chemicalConsumptionDao.delete(chemicalConsumption);
    }

    @RemotingInclude
    public ChemicalConsumption save(ChemicalConsumption chemicalConsumption) {
        chemicalConsumption.setLastUpdate(new Date());
        return chemicalConsumptionDao.saveOrUpdate(chemicalConsumption);
    }

    @RemotingInclude
    public ChemicalConsumption update(ChemicalConsumption chemicalConsumption) {
        chemicalConsumption.setLastUpdate(new Date());
        return chemicalConsumptionDao.saveOrUpdate(chemicalConsumption);
    }

    @RemotingInclude
    public Collection<ChemicalConsumption> findAll() throws Exception {
        return chemicalConsumptionDao.findAll();
    }

    @RemotingInclude
    public Collection<ChemicalConsumption> findAllByPlantSeason(long plantSeasonId,String orderNumber) throws Exception {
        return chemicalConsumptionDao.findAllByPlantSeason(plantSeasonId,orderNumber);
    }

    @RemotingInclude
    public Collection<ChemicalConsumption> findAllByPlantSeason(long plantSeason, String orderNumber, int shift) throws Exception {
        return chemicalConsumptionDao.findAllByPlantSeason(plantSeason,orderNumber, shift);
    }

    @RemotingInclude
    public ChemicalConsumption findByDateShiftOrder(long plantSeason, Date date, int shift,String orderNumber) throws Exception {
        return chemicalConsumptionDao.findByDateShiftOrder(plantSeason,date,shift,orderNumber);
    }

    @RemotingInclude
    public ChemicalConsumption findByOrderNumber(String orderNumber) throws Exception {
        ChemicalConsumption chemicalConsumption = chemicalConsumptionDao.findByOrderNumber(orderNumber);
        if (chemicalConsumption != null){
            populateChemicals(chemicalConsumption);
        }
        return chemicalConsumption;
    }

    @RemotingInclude
    public ChemicalConsumption getChemicalConsumption(Date date,Schedule schedule,String orderNumber,String hybrid,String treatmentName,int plantSeason,double ltsTons,double slurryReference,double ponchoReference,double preciseReference) throws Exception {
        ChemicalConsumption chemicalConsumption = new ChemicalConsumption();

        double tons = 30D;
        double ltsSol = tons * ltsTons;

        //Distibution
        double maximDistroLts = 0D;
        double maximDistroGrs = 0D;
        double kobiolDistroLts = 0D;
        double kobiolDistroGrs = 0D;
        double baytanDistroLts = 0D;
        double baytanDistroGrs = 0D;
        double apronDistroLts = 0D;
        double apronDistroGrs = 0D;
        double preciseDistroLts = 0D;
        double preciseDistroGrs = 0D;
        double ponchoDistroLts = 0D;
        double ponchoDistroGrs = 0D;
        double dinastyDistroLts = 0D;
        double dinastyDistroGrs = 0D;
        double colorantDistroLts = 0D;
        double colorantDistroGrs = 0D;
        double chemicalLts = 0D;
        double chemicalGrs = 0D;
        double waterLts = 0D;
        double waterGrs = 0D;

        //Density
        double apronDensity = 0D;
        double maximDensity = 0D;
        double kobiolDensity = 0D;
        double baytanDensity = 0D;
        double preciseDensity = 0D;
        double ponchoDensity = 0D;
        double dinastyDensity = 0D;
        double colorantDensity = 0D;

        //Consumption
        double apronConsumption = 0D;
        double maximConsumption = 0D;
        double kobiolConsumption = 0D;
        double baytanConsumption = 0D;
        double preciseConsumption = 0D;
        double ponchoConsumption = 0D;
        double dinastyConsumption = 0D;
        double colorantConsumption = 0D;

        //Special Chemicals
        Collection<Treatment> treatments = treatmentService.findByName(treatmentName);
        if (treatments == null || treatments.isEmpty()){
            throw (new Exception("No se encontr� Tratamiento: "+treatmentName + " para la planta seleccionada."));
        }
        Treatment treatment = treatments.iterator().next();
        ChemicalTreatment chemicalTreatment = chemicalTreatmentService.findByTreatmentId(treatment.getId());

        Chemicals chemical = null;
        ChemicalDensityDose chemicalDensityDose = null;

        if (chemicalTreatment.getApron()){
            Collection<Chemicals> chemicals = chemicalsService.findByChemicalName("APRON");
            if (chemicals == null || chemicals.isEmpty()){
                throw (new Exception("No se encontr� Qu�mico APRON"));
            }
            chemical = chemicals.iterator().next();
            Collection<ChemicalDensityDose> chemicalDensityDoses = chemicalDensityDoseService.findByChemicalId( ((Long)chemical.getId()).intValue());
            if (chemicalDensityDoses == null  || chemicalDensityDoses.isEmpty()){
                throw (new Exception("No se encontr� Densidad y Dosis para el Qu�mico APRON"));
            }
            chemicalDensityDose = chemicalDensityDoses.iterator().next();
            apronDistroLts = chemicalDensityDose.getDose() * tons;
            apronDistroGrs = apronDistroLts * chemicalDensityDose.getDensity();
            apronDensity = chemicalDensityDose.getDensity();
        }

        if (chemicalTreatment.getMaxim()){
            Collection<Chemicals> chemicals = chemicalsService.findByChemicalName("MAXIM");
            if (chemicals == null || chemicals.isEmpty()){
                throw (new Exception("No se encontr� Qu�mico MAXIM"));
            }
            chemical = chemicals.iterator().next();
            Collection<ChemicalDensityDose> chemicalDensityDoses = chemicalDensityDoseService.findByChemicalId( ((Long)chemical.getId()).intValue());
            if (chemicalDensityDoses == null || chemicalDensityDoses.isEmpty()){
                throw (new Exception("No se encontr� Densidad y Dosis para el Qu�mico MAXIM"));
            }
            chemicalDensityDose = chemicalDensityDoses.iterator().next();
            maximDistroLts = chemicalDensityDose.getDose() * tons;
            maximDistroGrs = maximDistroLts * chemicalDensityDose.getDensity();
            maximDensity = chemicalDensityDose.getDensity();
        }

        if (chemicalTreatment.getKobiol()){
            Collection<Chemicals> chemicals = chemicalsService.findByChemicalName("K-OBIOL");
            if (chemicals == null || chemicals.isEmpty()){
                throw (new Exception("No se encontr� Qu�mico K-OBIOL"));
            }
            chemical = chemicals.iterator().next();
            Collection<ChemicalDensityDose> chemicalDensityDoses = chemicalDensityDoseService.findByChemicalId( ((Long)chemical.getId()).intValue());
            if (chemicalDensityDoses == null || chemicalDensityDoses.isEmpty()){
                throw (new Exception("No se encontr� Densidad y Dosis para el Qu�mico K-OBIOL"));
            }
            chemicalDensityDose = chemicalDensityDoses.iterator().next();
            kobiolDistroLts = chemicalDensityDose.getDose() * tons;
            kobiolDistroGrs = kobiolDistroLts * chemicalDensityDose.getDensity();
            kobiolDensity = chemicalDensityDose.getDensity();
        }

        if (chemicalTreatment.getBaytan()){
            Collection<Chemicals> chemicals = chemicalsService.findByChemicalName("BAYTAN");
            if (chemicals == null || chemicals.isEmpty()){
                throw (new Exception("No se encontr� Qu�mico BAYTAN"));
            }
            chemical = chemicals.iterator().next();
            Collection<ChemicalDensityDose> chemicalDensityDoses = chemicalDensityDoseService.findByChemicalId( ((Long)chemical.getId()).intValue());
            if (chemicalDensityDoses == null || chemicalDensityDoses.isEmpty()){
                throw (new Exception("No se encontr� Densidad y Dosis para el Qu�mico BAYTAN"));
            }
            chemicalDensityDose = chemicalDensityDoses.iterator().next();
            baytanDistroLts = chemicalDensityDose.getDose() * tons;
            baytanDistroGrs = baytanDistroLts * chemicalDensityDose.getDensity();
            baytanDensity = chemicalDensityDose.getDensity();
        }

        if (chemicalTreatment.getPrecise()){
            //preciseReference = plantTreatmentDao.getPreciseReference(date,schedule,orderNumber);
            Collection<Chemicals> chemicals = chemicalsService.findByChemicalName("PRECISE");
            if (chemicals == null || chemicals.isEmpty()){
                throw (new Exception("No se encontr� Qu�mico PRECISE"));
            }
            chemical = chemicals.iterator().next();
            Collection<ChemicalDensityDose> chemicalDensityDoses = chemicalDensityDoseService.findByChemicalId( ((Long)chemical.getId()).intValue());
            if (chemicalDensityDoses == null || chemicalDensityDoses.isEmpty()){
                throw (new Exception("No se encontr� Densidad y Dosis para el Qu�mico PRECISE"));
            }
            chemicalDensityDose = chemicalDensityDoses.iterator().next();
            preciseDistroLts = chemicalDensityDose.getDose() * tons;
            preciseDistroGrs = preciseDistroLts * chemicalDensityDose.getDensity();
            preciseDensity = chemicalDensityDose.getDensity();
        }

        if (chemicalTreatment.getPoncho()){
            //ponchoReference = plantTreatmentDao.getPonchoReference(date,schedule,orderNumber);
            Collection<Chemicals> chemicals = chemicalsService.findByChemicalName("PONCHO");
            if (chemicals == null || chemicals.isEmpty()){
                throw (new Exception("No se encontr� Qu�mico PONCHO"));
            }
            chemical = chemicals.iterator().next();
            Collection<ChemicalDensityDose> chemicalDensityDoses = chemicalDensityDoseService.findByChemicalId( ((Long)chemical.getId()).intValue());
            if (chemicalDensityDoses == null || chemicalDensityDoses.isEmpty()){
                throw (new Exception("No se encontr� Densidad y Dosis para el Qu�mico PONCHO"));
            }
            chemicalDensityDose = chemicalDensityDoses.iterator().next();
            ponchoDistroLts = chemicalDensityDose.getDose() * tons;
            ponchoDistroGrs = ponchoDistroLts * chemicalDensityDose.getDensity();
            ponchoDensity = chemicalDensityDose.getDensity();
        }

        if (chemicalTreatment.getDinasty()){
            Collection<Chemicals> chemicals = chemicalsService.findByChemicalName("DINASTY");
            if (chemicals == null || chemicals.isEmpty()){
                throw (new Exception("No se encontr� Qu�mico DINASTY"));
            }
            chemical = chemicals.iterator().next();
            Collection<ChemicalDensityDose> chemicalDensityDoses = chemicalDensityDoseService.findByChemicalId( ((Long)chemical.getId()).intValue());
            if (chemicalDensityDoses == null || chemicalDensityDoses.isEmpty()){
                throw (new Exception("No se encontr� Densidad y Dosis para el Qu�mico DINASTY"));
            }
            chemicalDensityDose = chemicalDensityDoses.iterator().next();
            dinastyDistroLts = chemicalDensityDose.getDose() * tons;
            dinastyDistroGrs = dinastyDistroLts * chemicalDensityDose.getDensity();
            dinastyDensity = chemicalDensityDose.getDensity();
        }

        Collection<Hybrid> hybrids = (hybridService.findByNameExactMatch(hybrid,plantSeason,1));
        Hybrid currentHybrid = null;
        if (hybrids != null && hybrids.size() > 0 ){
            currentHybrid = (hybridService.findByNameExactMatch(hybrid,plantSeason,1)).iterator().next();
        }

        Collection<ColorantHybrid> colorantHybrids = colorantHybridService.findByPlantSeason(plantSeason,hybrid);
        if (colorantHybrids == null || colorantHybrids.size() ==0){
            throw (new Exception("No se encontr� Colorante para el H�brido seleccionado."));
        }
        ColorantHybrid colorantHybrid = colorantHybrids.iterator().next();
        Collection<Chemicals> chemicals = chemicalsService.findByChemicalName(colorantHybrid.getChemicalColorant().getColorant());
        if (chemicals == null || chemicals.isEmpty()){
            throw (new Exception("No se encontr� Qu�mico asociado al Colorante"));
        }
        chemical = chemicals.iterator().next();
        chemicalTreatment = chemicalTreatmentService.findByTreatmentId(treatment.getId());
        Collection<ChemicalDensityDose> chemicalDensityDoses = chemicalDensityDoseService.findByChemicalId( ((Long)chemical.getId()).intValue());
        if (chemicalDensityDoses == null || chemicalDensityDoses.isEmpty()){
            throw (new Exception("No se encontr� Densidad y Dosis para el Qu�mico asociado al Colorante"));
        }
        chemicalDensityDose = chemicalDensityDoses.iterator().next();
        colorantDistroLts = chemicalDensityDose.getDose() * tons;
        colorantDistroGrs = colorantDistroLts * chemicalDensityDose.getDensity();
        colorantDensity = chemicalDensityDose.getDensity();

        //chemicalGrs = maximDistroGrs + kobiolDistroGrs + apronDistroGrs + colorantDistroGrs + baytanDistroGrs + preciseDistroGrs + ponchoDistroGrs + dinastyDistroGrs;
        //chemicalLts = maximDistroLts + kobiolDistroLts + apronDistroLts + colorantDistroLts + baytanDistroLts + preciseDistroLts + ponchoDistroLts + dinastyDistroLts;
        
        chemicalGrs = maximDistroGrs + kobiolDistroGrs + apronDistroGrs + colorantDistroGrs + baytanDistroGrs + dinastyDistroGrs;
        chemicalLts = maximDistroLts + kobiolDistroLts + apronDistroLts + colorantDistroLts + baytanDistroLts + dinastyDistroLts;

        waterLts = ltsSol - chemicalLts;
        waterGrs = waterLts * 1000;

        double slurryGrs = waterGrs + chemicalGrs;

        maximConsumption = ( ( slurryReference * maximDistroGrs ) / slurryGrs ) / maximDensity;
        kobiolConsumption = ( ( slurryReference * kobiolDistroGrs ) / slurryGrs ) / kobiolDensity;
        colorantConsumption = ( ( slurryReference * colorantDistroGrs ) / slurryGrs ) / colorantDensity;
        apronConsumption = ( ( slurryReference * apronDistroGrs ) / slurryGrs ) / apronDensity;
        baytanConsumption = ( ( slurryReference * baytanDistroGrs ) / slurryGrs ) / baytanDensity;
        if (chemicalTreatment.getPoncho()){
            ponchoConsumption = ponchoReference / ponchoDensity;
        }
        if (chemicalTreatment.getPrecise()){
            preciseConsumption = preciseReference / preciseDensity;
        }        
        dinastyConsumption = ( ( slurryReference * dinastyDistroGrs ) / slurryGrs ) / dinastyDensity;

        chemicalConsumption.setApron(apronConsumption);
        chemicalConsumption.setKobiol(kobiolConsumption);
        chemicalConsumption.setMaxim(maximConsumption);
        if (colorantHybrid.getChemicalColorant().getId() == 1){
            chemicalConsumption.setRedColorant(colorantConsumption);
        }
        if (colorantHybrid.getChemicalColorant().getId() == 2){
            chemicalConsumption.setGreenColorant(colorantConsumption);
        }
        chemicalConsumption.setTons(30D);
        chemicalConsumption.setLtsTons(ltsTons);
        chemicalConsumption.setSlurry(slurryGrs);
        chemicalConsumption.setLastUpdate(new Date());
        chemicalConsumption.setShift(schedule.getShift());
        chemicalConsumption.setTreatment(treatment);
        chemicalConsumption.setDate(date);
        chemicalConsumption.setBaytan(baytanConsumption);
        chemicalConsumption.setDinasty(dinastyConsumption);
        chemicalConsumption.setPrecise(preciseConsumption);
        chemicalConsumption.setPoncho(ponchoConsumption);
        chemicalConsumption.setHybrid(currentHybrid);
        chemicalConsumption.setOrderNumber(String.valueOf(orderNumber));

        return chemicalConsumption;
    }

    public double getColorantFactor(Collection <ChemicalConsumption> list, String year, String month, int colorant) throws Exception {
        double totalTons = 0;
        double totalColorant = 0;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        for (ChemicalConsumption record : list) {
            if (record.getDate() != null) {
                String temporalDate = sdf.format(record.getDate());
                if (temporalDate.substring(0, 4).equalsIgnoreCase(year) &&
                    temporalDate.substring(5, 7).equalsIgnoreCase(month)) {
                    if (colorant == RED_COLORANT) {
                       totalColorant += record.getRedColorant();
                    }
                    else
                    if (colorant == MAXIM_COLORANT) {
                       totalColorant += record.getMaxim();
                    }
                    else
                    if (colorant == KOBIOL_COLORANT) {
                        totalColorant += record.getKobiol();
                    }
                    totalTons += record.getTons();
                }
            }
        }
        return (totalTons == 0 ? 0 : totalColorant / totalTons);
    }

    private void populateChemicals(ChemicalConsumption consumption) throws Exception{
        if (chemicalsConsumption.size() == 0){
            initializeChemicalsConsumption();
        }
        for (Chemicals chemical:chemicalsConsumption.keySet()){
            if (chemical.getChemical().startsWith(APRON)){
                chemicalsConsumption.put(chemical,consumption.getApron());
            }
            if (chemical.getChemical().startsWith(BAYTAN)){
                chemicalsConsumption.put(chemical,consumption.getBaytan());
            }
            if (chemical.getChemical().startsWith(DINASTY)){
                chemicalsConsumption.put(chemical,consumption.getDinasty());
            }
            if (chemical.getChemical().startsWith(KOBIOL)){
                chemicalsConsumption.put(chemical,consumption.getKobiol());
            }
            if (chemical.getChemical().startsWith(MAXIM)){
                chemicalsConsumption.put(chemical,consumption.getMaxim());
            }
            if (chemical.getChemical().startsWith(PONCHO)){
                chemicalsConsumption.put(chemical,consumption.getPoncho());
            }
            if (chemical.getChemical().startsWith(PRECISE)){
                chemicalsConsumption.put(chemical,consumption.getPrecise());
            }
            if (chemical.getChemical().startsWith(GREEN_COLORANT_NAME)){
                chemicalsConsumption.put(chemical,consumption.getGreenColorant());
            }
            if (chemical.getChemical().startsWith(RED_COLORANT_NAME)){
                chemicalsConsumption.put(chemical,consumption.getRedColorant());
            }
        }
        consumption.setChemicalsConsumption(chemicalsConsumption);
    }

}
