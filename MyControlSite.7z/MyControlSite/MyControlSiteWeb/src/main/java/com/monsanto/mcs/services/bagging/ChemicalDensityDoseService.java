package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.ChemicalDensityDose;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 11:57:07 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ChemicalDensityDoseService {

    ChemicalDensityDose save(ChemicalDensityDose cdd);

    ChemicalDensityDose update(ChemicalDensityDose cdd);

    void remove(ChemicalDensityDose cdd) throws Exception;

    Collection<ChemicalDensityDose> findByChemicalId(int id) throws Exception;

    Collection<ChemicalDensityDose> findAll() throws Exception;

}
