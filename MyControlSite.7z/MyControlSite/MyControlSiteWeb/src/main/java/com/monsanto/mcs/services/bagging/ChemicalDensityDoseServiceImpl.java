package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.ChemicalDensityDoseDao;
import com.monsanto.mcs.model.hibernate.ChemicalDensityDose;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 11:58:53 AM
 * To change this template use File | Settings | File Templates.
 */
@Service("chemicalDensityDoseService")
@RemotingDestination
public class ChemicalDensityDoseServiceImpl implements ChemicalDensityDoseService{

    @Autowired
    ChemicalDensityDoseDao dao = null;

    @RemotingInclude
    public ChemicalDensityDose save(ChemicalDensityDose cdd) {
        cdd.setLastUpdate(new Date());
        ChemicalDensityDose result = dao.saveOrUpdate(cdd);
        return result;
    }

    @RemotingInclude
    public ChemicalDensityDose update(ChemicalDensityDose bagType) {
        bagType.setLastUpdate(new Date());
        ChemicalDensityDose result = dao.saveOrUpdate(bagType);
        return result;
    }

    @RemotingInclude
    public void remove(ChemicalDensityDose bagType) throws Exception{
        try {
           dao.delete(bagType);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public Collection<ChemicalDensityDose> findByChemicalId(int id) throws Exception {
        Collection<ChemicalDensityDose> results = dao.findByChemicalId(id);
        return results;
    }


    @RemotingInclude
    public Collection<ChemicalDensityDose> findAll() throws Exception {
        Collection<ChemicalDensityDose> results = dao.findAll();
        return results;
    }

}
