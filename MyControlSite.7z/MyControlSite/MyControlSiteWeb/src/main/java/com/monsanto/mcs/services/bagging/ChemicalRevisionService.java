package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.ChemicalDensityDose;
import com.monsanto.mcs.model.hibernate.ChemicalRevision;

import java.util.Collection;


public interface ChemicalRevisionService {

    ChemicalRevision save(ChemicalRevision cr);

    ChemicalRevision update(ChemicalRevision cr);

    void remove(ChemicalRevision cr) throws Exception;

    Collection<ChemicalRevision> findAllByPlantSeason(long plantSeasonId, long orderNumber) throws Exception;


    ChemicalRevision findByOrderNumber(long plant, long season, long orderNumber) throws Exception;
}
