package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.ChemicalRevisionDao;
import com.monsanto.mcs.model.hibernate.ChemicalRevision;
import com.monsanto.mcs.model.hibernate.Chemicals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;
import java.util.HashMap;

@Service("chemicalRevisionService")
@RemotingDestination
public class ChemicalRevisionServiceImpl implements ChemicalRevisionService{

    private static final String APRON = "APRON";
    private static final String BAYTAN = "BAYTAN";
    private static final String DINASTY = "DINASTY";
    private static final String KOBIOL = "K-OBIOL";
    private static final String MAXIM = "MAXIM";
    private static final String PONCHO = "PONCHO";
    private static final String PRECISE = "PRECISE";
    private static final String GREEN_COLORANT = "GREEN";
    private static final String RED_COLORANT = "RED";

    private HashMap<Chemicals,Double> chemicalsRevision;

    @Autowired
    ChemicalRevisionDao dao = null;

    @Autowired
    ChemicalsService chemicalsService;

    public ChemicalRevisionServiceImpl() {
        chemicalsRevision = new HashMap<Chemicals,Double>();
    }

    private void initializeChemicalsRevision() throws Exception{
        chemicalsRevision.put(chemicalsService.findByChemicalName(APRON).iterator().next(),0D);
        chemicalsRevision.put(chemicalsService.findByChemicalName(BAYTAN).iterator().next(),0D);
        chemicalsRevision.put(chemicalsService.findByChemicalName(DINASTY).iterator().next(),0D);
        chemicalsRevision.put(chemicalsService.findByChemicalName(KOBIOL).iterator().next(),0D);
        chemicalsRevision.put(chemicalsService.findByChemicalName(MAXIM).iterator().next(),0D);
        chemicalsRevision.put(chemicalsService.findByChemicalName(PONCHO).iterator().next(),0D);
        chemicalsRevision.put(chemicalsService.findByChemicalName(PRECISE).iterator().next(),0D);
        chemicalsRevision.put(chemicalsService.findByChemicalName(GREEN_COLORANT).iterator().next(),0D);
        chemicalsRevision.put(chemicalsService.findByChemicalName(RED_COLORANT).iterator().next(),0D);
    }

    @RemotingInclude
    public ChemicalRevision save(ChemicalRevision cdd) {
        cdd.setLastUpdate(new Date());
        ChemicalRevision result = dao.saveOrUpdate(cdd);
        return result;
    }

    @RemotingInclude
    public ChemicalRevision update(ChemicalRevision chemicalRevision) {
        chemicalRevision.setLastUpdate(new Date());
        ChemicalRevision result = dao.saveOrUpdate(chemicalRevision);
        return result;
    }

    @RemotingInclude
    public void remove(ChemicalRevision chemicalRevision) throws Exception{
        try {
           dao.delete(chemicalRevision);
        }
        catch (Exception e) {
            throw new Exception("Impossible to delete this record.");
        }
    }

    private void populateChemicals(ChemicalRevision revision) throws Exception{
        if (revision == null){
            return;
        }
        if (chemicalsRevision.size() == 0){
            initializeChemicalsRevision();
        }
        for (Chemicals chemical:chemicalsRevision.keySet()){
            if (chemical.getChemical().startsWith(APRON)){
                chemicalsRevision.put(chemical,revision.getApron());
            }
            if (chemical.getChemical().startsWith(BAYTAN)){
                chemicalsRevision.put(chemical,revision.getBaytan());
            }
            if (chemical.getChemical().startsWith(DINASTY)){
                chemicalsRevision.put(chemical,revision.getDinasty());
            }
            if (chemical.getChemical().startsWith(KOBIOL)){
                chemicalsRevision.put(chemical,revision.getKobiol());
            }
            if (chemical.getChemical().startsWith(MAXIM)){
                chemicalsRevision.put(chemical,revision.getMaxim());
            }
            if (chemical.getChemical().startsWith(PONCHO)){
                chemicalsRevision.put(chemical,revision.getPoncho());
            }
            if (chemical.getChemical().startsWith(PRECISE)){
                chemicalsRevision.put(chemical,revision.getPrecise());
            }
            if (chemical.getChemical().startsWith(GREEN_COLORANT)){
                chemicalsRevision.put(chemical,revision.getGreenColorant());
            }
            if (chemical.getChemical().startsWith(RED_COLORANT)){
                chemicalsRevision.put(chemical,revision.getRedColorant());
            }
        }
        revision.setChemicalsRevision(chemicalsRevision);
    }

    @RemotingInclude
    public Collection<ChemicalRevision> findAllByPlantSeason(long plantSeasonId, long orderNumber) throws Exception {
        Collection<ChemicalRevision> results = dao.findAllByPlantSeason(plantSeasonId, orderNumber);
        return results;
    }


    @RemotingInclude
    public ChemicalRevision findByOrderNumber(long plant, long season, long orderNumber) throws Exception {
        ChemicalRevision feedback = dao.findByOrderNumber(plant, season, orderNumber);
        populateChemicals(feedback);
        return feedback;
    }


}
