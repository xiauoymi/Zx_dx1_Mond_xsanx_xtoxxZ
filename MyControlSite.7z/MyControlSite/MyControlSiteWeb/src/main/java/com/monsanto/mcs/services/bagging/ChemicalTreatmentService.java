package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.ChemicalTreatment;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 12:30:48 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ChemicalTreatmentService {

    ChemicalTreatment save(ChemicalTreatment ct);

    ChemicalTreatment update(ChemicalTreatment ct);

    void remove(ChemicalTreatment ct) throws Exception;

    Collection<ChemicalTreatment> findByTreatment(String name) throws Exception;

    Collection<ChemicalTreatment> findAll() throws Exception;

    ChemicalTreatment findById(long id) throws Exception;

    ChemicalTreatment findByTreatmentId(long id) throws Exception;


}
