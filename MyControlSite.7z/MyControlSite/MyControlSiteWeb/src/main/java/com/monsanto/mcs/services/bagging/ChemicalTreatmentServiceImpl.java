package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.ChemicalTreatmentDao;
import com.monsanto.mcs.model.hibernate.ChemicalTreatment;
import com.monsanto.mcs.model.hibernate.Chemicals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

@Service("chemicalTreatmentService")
@RemotingDestination
public class ChemicalTreatmentServiceImpl implements ChemicalTreatmentService {
    
    @Autowired
    ChemicalTreatmentDao dao = null;


    @RemotingInclude
    public Collection<ChemicalTreatment> findByTreatment(String name) throws Exception {
        Collection<ChemicalTreatment> results = dao.findByTreatment(name);
        return results;

    }

    @RemotingInclude
    public void remove(ChemicalTreatment chemicals) throws Exception {
        try {
           dao.delete(chemicals);
        }
        catch (Exception e) {
            throw new Exception ("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public ChemicalTreatment save(ChemicalTreatment chemicals) {
        chemicals.setLastUpdate(new Date());
        ChemicalTreatment result = dao.saveOrUpdate(chemicals);
        return result;
    }

    @RemotingInclude
    public ChemicalTreatment update(ChemicalTreatment chemicals) {
        ChemicalTreatment result = dao.saveOrUpdate(chemicals);
        chemicals.setLastUpdate(new Date());
        return result;
    }

    @RemotingInclude
    public Collection<ChemicalTreatment> findAll() throws Exception {
        Collection<ChemicalTreatment> chemicals = dao.findAll();
        return chemicals;
    }

    @RemotingInclude
    public ChemicalTreatment findById(long id) throws Exception {
        ChemicalTreatment result = dao.findByPrimaryKey(id);
        return result;
    }

    @RemotingInclude
    public ChemicalTreatment findByTreatmentId(long id) throws Exception {
        ChemicalTreatment result = dao.findByTreatmentId(id);
        return result;
    }

}
