package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Chemicals;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 05:22:08 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ChemicalsService {

    Chemicals save(Chemicals chemicals)throws Exception;

    Chemicals update(Chemicals chemicals) throws Exception;

    void remove(Chemicals chemicals) throws Exception;

    Collection<Chemicals> findByChemicalName(String chemicals) throws Exception;

    Collection<Chemicals> findAll() throws Exception;

}
