package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.ChemicalsDao;
import com.monsanto.mcs.model.hibernate.Chemicals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 05:24:10 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("chemicalsService")
@RemotingDestination
public class ChemicalsServiceImpl implements ChemicalsService {

    @Autowired
    ChemicalsDao chemicalsDao = null;


    @RemotingInclude
    public Collection<Chemicals> findByChemicalName(String name) throws Exception {
        Collection<Chemicals> results = chemicalsDao.findByChemicalName(name);
        return results;

    }

    @RemotingInclude
    public void remove(Chemicals chemicals) throws Exception{
        try {
           chemicalsDao.delete(chemicals);
        }
        catch(Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public Chemicals save(Chemicals chemicals) throws Exception {
        Chemicals result = null;
        try {
           chemicals.setLastUpdate(new Date());
           result = chemicalsDao.saveOrUpdate(chemicals);
        }
        catch(Exception e) {
            throw new Exception ("Imposible to create record");
        }
        return result;
    }

    @RemotingInclude
    public Chemicals update(Chemicals chemicals) throws Exception {
        Chemicals result = null;
        try {
           chemicals.setLastUpdate(new Date());
           result = chemicalsDao.saveOrUpdate(chemicals);
        }
        catch(Exception e) {
            throw new Exception("Imposible to update record");
        }
        return result;
    }

    @RemotingInclude
    public Collection<Chemicals> findAll() throws Exception {
        Collection<Chemicals> chemicals = chemicalsDao.findAll();
        return chemicals;
    }


}
