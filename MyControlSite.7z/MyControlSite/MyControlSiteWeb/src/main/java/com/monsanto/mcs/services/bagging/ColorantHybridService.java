package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.ColorantHybrid;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 10:54:07 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ColorantHybridService {

    ColorantHybrid save(ColorantHybrid ch) throws Exception;

    ColorantHybrid update(ColorantHybrid ch) throws Exception;

    void remove(ColorantHybrid ch)throws Exception;

    Collection<ColorantHybrid> findByPlantSeason(int idPlantSeason) throws Exception;

    Collection<ColorantHybrid> findByPlantSeason(int idPlantSeason, String hibrid) throws Exception;

    Collection<ColorantHybrid> findAll() throws Exception;

}
