package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.ColorantHybridDao;
import com.monsanto.mcs.model.hibernate.ColorantHybrid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 10:55:32 AM
 * To change this template use File | Settings | File Templates.
 */
@Service("colorantHybridService")
@RemotingDestination
public class ColorantHybridServiceImpl implements ColorantHybridService {

    @Autowired
    ColorantHybridDao dao = null;


    @RemotingInclude
    public Collection<ColorantHybrid> findByPlantSeason(int idPlantSeason) throws Exception {
        Collection<ColorantHybrid> results = dao.findByPlantSeason(idPlantSeason);
        return results;

    }

    @RemotingInclude
    public Collection<ColorantHybrid> findByPlantSeason(int idPlantSeason, String hybrid) throws Exception {
        Collection<ColorantHybrid> results = dao.findByPlantSeason(idPlantSeason, hybrid);
        return results;

    }

    @RemotingInclude
    public void remove(ColorantHybrid colorantHybrid) throws Exception{
        try {
           dao.delete(colorantHybrid);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public ColorantHybrid save(ColorantHybrid colorantHybrid) throws Exception{
        ColorantHybrid result = null;
        try {
           colorantHybrid.setLastUpdate(new Date());
           result = dao.saveOrUpdate(colorantHybrid);
        }
        catch (Exception e) {
            throw new Exception("Imposible to create this record");
        }
        return result;
    }

    @RemotingInclude
    public ColorantHybrid update(ColorantHybrid colorantHybrid) throws Exception{
        ColorantHybrid result = null;
        try {
            colorantHybrid.setLastUpdate(new Date());
            result = dao.saveOrUpdate(colorantHybrid);
        }
        catch (Exception e) {
            throw new Exception("Imposible to update this record");
        }
        return result;
    }

    @RemotingInclude
    public Collection<ColorantHybrid> findAll() throws Exception {
        Collection<ColorantHybrid> colorantHybrid = dao.findAll();
        return colorantHybrid;
    }


}
