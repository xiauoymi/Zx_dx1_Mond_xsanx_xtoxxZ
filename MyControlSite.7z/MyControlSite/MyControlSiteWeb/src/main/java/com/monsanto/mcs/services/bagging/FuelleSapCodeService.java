package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.BagType;
import com.monsanto.mcs.model.hibernate.Brand;
import com.monsanto.mcs.model.hibernate.FuelleSapCode;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:49:12 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FuelleSapCodeService {
    FuelleSapCode save(FuelleSapCode lsc) throws Exception;

    FuelleSapCode update(FuelleSapCode lsc) throws Exception;

    void remove(FuelleSapCode lsc) throws Exception;

    Collection<FuelleSapCode> findByName(String name) throws Exception;

    Collection<FuelleSapCode> findAll() throws Exception;

    Collection<FuelleSapCode> findByBagType(BagType bagType, Brand brand) throws Exception;

}
