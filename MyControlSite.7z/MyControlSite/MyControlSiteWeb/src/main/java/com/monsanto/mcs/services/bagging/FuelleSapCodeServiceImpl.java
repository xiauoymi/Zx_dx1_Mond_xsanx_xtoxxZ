package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.FuelleSapCodeDao;
import com.monsanto.mcs.model.hibernate.BagType;
import com.monsanto.mcs.model.hibernate.Brand;
import com.monsanto.mcs.model.hibernate.FuelleSapCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:50:33 PM
 * To change this template use File | Settings | File Templates.
 */

@Service("fuelleSapCodeService")
@RemotingDestination
public class FuelleSapCodeServiceImpl implements FuelleSapCodeService{
    @Autowired
    FuelleSapCodeDao fuelleSapCodeDao = null;

    @RemotingInclude
    public Collection<FuelleSapCode> findByName(String name) throws Exception {
        Collection<FuelleSapCode> results = fuelleSapCodeDao.findByName(name);
        return results;

    }

    @RemotingInclude
    public void remove(FuelleSapCode fuelleSapCode) throws Exception {
        try {
           fuelleSapCodeDao.delete(fuelleSapCode);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public FuelleSapCode save(FuelleSapCode fuelleSapCode) throws Exception{
        FuelleSapCode result;
        try {
           fuelleSapCode.setLastUpdate(new Date());
           result = fuelleSapCodeDao.saveOrUpdate(fuelleSapCode);
        }
        catch(Exception e) {
            throw new Exception ("Imposible to create record.");
        }
        return result;
    }

    @RemotingInclude
    public FuelleSapCode update(FuelleSapCode fuelleSapCode) throws Exception{
        FuelleSapCode result;
        try {
           fuelleSapCode.setLastUpdate(new Date());
           result = fuelleSapCodeDao.saveOrUpdate(fuelleSapCode);
        }
        catch (Exception e) {
            throw new Exception ("Imposible to update record");
        }
        return result;
    }

    @RemotingInclude
    public Collection<FuelleSapCode> findAll() throws Exception {
        Collection<FuelleSapCode> feedback = fuelleSapCodeDao.findAll();
        return feedback;
    }

    @RemotingInclude
    public Collection<FuelleSapCode> findByBagType(BagType bagType, Brand brand) throws Exception {
        Collection<FuelleSapCode> feedback = fuelleSapCodeDao.findByBagType(bagType,brand);
        return feedback;
    }

}
