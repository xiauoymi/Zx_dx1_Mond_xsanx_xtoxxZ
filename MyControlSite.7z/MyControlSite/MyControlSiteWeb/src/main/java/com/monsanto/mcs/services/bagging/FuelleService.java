package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Fuelle;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * To change this template use File | Settings | File Templates.
 */
public interface FuelleService {

    Fuelle save(Fuelle fuelle);

    Fuelle update(Fuelle fuelle);

    void remove(Fuelle fuelle) throws Exception;

    Collection<Fuelle> findByName(String name) throws Exception;

    Collection<Fuelle> findAll() throws Exception;
}
