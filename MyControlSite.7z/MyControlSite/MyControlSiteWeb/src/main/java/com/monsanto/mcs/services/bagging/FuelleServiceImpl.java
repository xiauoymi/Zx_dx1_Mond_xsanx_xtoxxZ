package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.FuelleDao;
import com.monsanto.mcs.model.hibernate.Fuelle;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingExclude;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * To change this template use File | Settings | File Templates.
 */
@Service("fuelleService")
@RemotingDestination
public class FuelleServiceImpl implements FuelleService {

    @Autowired
    FuelleDao fuelleDao = null;


    @RemotingInclude
    public Collection<Fuelle> findByName(String name) throws Exception {
        Collection<Fuelle> results = fuelleDao.findByName(name);
        return results;

    }

    @RemotingInclude
    public void remove(Fuelle fuelle) throws Exception{
        try {
           fuelleDao.delete(fuelle);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public Fuelle save(Fuelle fuelle) {
        fuelle.setLastUpdate(new Date());
        Fuelle result = fuelleDao.saveOrUpdate(fuelle);
        return result;
    }

    @RemotingInclude
    public Fuelle update(Fuelle fuelle) {
        Fuelle result = fuelleDao.saveOrUpdate(fuelle);
        fuelle.setLastUpdate(new Date());
        return result;
    }

    @RemotingInclude
    public Collection<Fuelle> findAll() throws Exception {
        Collection<Fuelle> fuelles = fuelleDao.findAll();
        return fuelles;
    }
}
