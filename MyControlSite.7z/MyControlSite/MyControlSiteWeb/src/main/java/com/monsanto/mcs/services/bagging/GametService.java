package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Gamet;
import java.util.Collection;

public interface GametService {

    Gamet save(Gamet gamet);

    Gamet update(Gamet gamet);

    void remove(Gamet gamet);

    Collection<Gamet> findAll() throws Exception;

}
