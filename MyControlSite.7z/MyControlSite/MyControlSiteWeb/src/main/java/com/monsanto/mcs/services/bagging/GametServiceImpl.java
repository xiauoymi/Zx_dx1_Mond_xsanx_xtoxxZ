package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BaggingControlDao;
import com.monsanto.mcs.dao.GametDao;
import com.monsanto.mcs.model.hibernate.BaggingControl;
import com.monsanto.mcs.model.hibernate.Gamet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("gametService")
@RemotingDestination
public class GametServiceImpl implements GametService {

    @Autowired
    GametDao gametDao = null;

    @RemotingInclude
    public void remove(Gamet gamet) {
        gametDao.delete(gamet);
    }

    @RemotingInclude
    public Gamet save(Gamet gamet) {
        return gametDao.saveOrUpdate(gamet);
    }

    @RemotingInclude
    public Gamet update(Gamet gamet) {
        return gametDao.saveOrUpdate(gamet);
    }

    @RemotingInclude
    public Collection<Gamet> findAll() throws Exception {
        Collection<Gamet> gamets = gametDao.findAll();
        return gamets;
    }
}
