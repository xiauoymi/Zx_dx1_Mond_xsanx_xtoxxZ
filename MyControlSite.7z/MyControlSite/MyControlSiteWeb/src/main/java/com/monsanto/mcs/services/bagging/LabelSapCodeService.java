package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.LabelSapCode;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:49:12 PM
 * To change this template use File | Settings | File Templates.
 */
public interface LabelSapCodeService {
    LabelSapCode save(LabelSapCode lsc) throws Exception;

    LabelSapCode update(LabelSapCode lsc) throws Exception;

    void remove(LabelSapCode lsc) throws Exception;

    Collection<LabelSapCode> findByName(String name) throws Exception;

    Collection<LabelSapCode> findAll() throws Exception;

    Collection<LabelSapCode> findByBrandName(String name) throws Exception;

    public Collection<LabelSapCode> findByLabelName(String name) throws Exception;

}
