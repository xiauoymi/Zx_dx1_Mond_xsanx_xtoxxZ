package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.LabelSapCodeDao;
import com.monsanto.mcs.model.hibernate.LabelSapCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:50:33 PM
 * To change this template use File | Settings | File Templates.
 */

@Service("labelSapCodeService")
@RemotingDestination
public class LabelSapCodeServiceImpl implements LabelSapCodeService{
    @Autowired
    LabelSapCodeDao labelSapCodeDao = null;

    @RemotingInclude
    public Collection<LabelSapCode> findByName(String name) throws Exception {
        Collection<LabelSapCode> results = labelSapCodeDao.findByName(name);
        return results;

    }

    @RemotingInclude
    public void remove(LabelSapCode labelSapCode) throws Exception {
        try {
           labelSapCodeDao.delete(labelSapCode);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public LabelSapCode save(LabelSapCode labelSapCode) throws Exception{
        LabelSapCode result;
        try {
           labelSapCode.setLastUpdate(new Date());
           result = labelSapCodeDao.saveOrUpdate(labelSapCode);
        }
        catch(Exception e) {
            throw new Exception ("Imposible to create record.");
        }
        return result;
    }

    @RemotingInclude
    public LabelSapCode update(LabelSapCode labelSapCode) throws Exception{
        LabelSapCode result;
        try {
           labelSapCode.setLastUpdate(new Date());
           result = labelSapCodeDao.saveOrUpdate(labelSapCode);
        }
        catch (Exception e) {
            throw new Exception ("Imposible to update record");
        }
        return result;
    }

    @RemotingInclude
    public Collection<LabelSapCode> findAll() throws Exception {
        Collection<LabelSapCode> specialist = labelSapCodeDao.findAll();
        return specialist;
    }

    @RemotingInclude
    public Collection<LabelSapCode> findByBrandName(String name) throws Exception {
        Collection<LabelSapCode> labels = labelSapCodeDao.findByBrandName(name);
        return labels;
    }

    @RemotingInclude
    public Collection<LabelSapCode> findByLabelName(String name) throws Exception {
        Collection<LabelSapCode> labels = labelSapCodeDao.findByLabelName(name);
        return labels;
    }

}
