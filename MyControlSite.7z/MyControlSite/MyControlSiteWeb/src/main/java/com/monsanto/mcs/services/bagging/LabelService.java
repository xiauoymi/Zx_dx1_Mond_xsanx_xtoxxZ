package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Label;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * To change this template use File | Settings | File Templates.
 */
public interface LabelService {

    Label save(Label label) throws Exception;

    Label update(Label label) throws Exception;

    void remove(Label label) throws Exception;

    Collection<Label> findByName(String name) throws Exception;

    Collection<Label> findAll() throws Exception;
}
