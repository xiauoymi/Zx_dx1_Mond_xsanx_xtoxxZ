package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.LabelDao;
import com.monsanto.mcs.model.hibernate.Label;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingExclude;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * To change this template use File | Settings | File Templates.
 */
@Service("labelService")
@RemotingDestination
public class LabelServiceImpl implements LabelService {

    @Autowired
    LabelDao labelDao = null;


    @RemotingInclude
    public Collection<Label> findByName(String name) throws Exception {
        Collection<Label> results = labelDao.findByName(name);
        return results;

    }

    @RemotingInclude
    public void remove(Label label) throws Exception {
        try {
           labelDao.delete(label);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public Label save(Label label) throws Exception{
        Label result = null;
        try {
           label.setLastUpdate(new Date());
           result = labelDao.saveOrUpdate(label);
        }
        catch(Exception e) {
            throw new Exception("Imposible to create this record");
        }
        return result;
    }

    @RemotingInclude
    public Label update(Label label) throws Exception {
        Label result = null;
        try {
           label.setLastUpdate(new Date());
           result = labelDao.saveOrUpdate(label);
        }
        catch(Exception e) {
            throw new Exception("Imposible to update this record");
        }
        return result;
    }

    @RemotingInclude
    public Collection<Label> findAll() throws Exception {
        Collection<Label> labels = labelDao.findAll();
        return labels;
    }
}
