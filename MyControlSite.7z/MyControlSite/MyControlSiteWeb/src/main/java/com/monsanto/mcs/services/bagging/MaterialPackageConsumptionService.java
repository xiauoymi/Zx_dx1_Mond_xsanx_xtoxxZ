package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.MaterialPackageConsumption;

import java.util.Collection;

public interface MaterialPackageConsumptionService {

    MaterialPackageConsumption save(MaterialPackageConsumption materialPackageConsumption);

    MaterialPackageConsumption update(MaterialPackageConsumption materialPackageConsumption);

    void remove(MaterialPackageConsumption materialPackageConsumption);

    Collection<MaterialPackageConsumption> findAll() throws Exception;

}
