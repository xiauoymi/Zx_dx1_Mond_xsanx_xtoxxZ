package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.MaterialPackageConsumptionDao;

import com.monsanto.mcs.model.hibernate.BagConsumed;
import com.monsanto.mcs.model.hibernate.MaterialPackageConsumption;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;


@Service("materialPackageConsumptionService")
@RemotingDestination
public class MaterialPackageConsumptionServiceImpl implements MaterialPackageConsumptionService {

    @Autowired
    MaterialPackageConsumptionDao materialPackageConsumptionDao = null;

    @Autowired
    BagConsumedService bagConsumedService = null;

    @RemotingInclude
    public void remove(MaterialPackageConsumption bagging) {

        Collection<BagConsumed> consumedBags = null;
        try {
            consumedBags = bagConsumedService.findByMaterialPackageConsumption(bagging.getId());
        }catch (Exception e){
            e.printStackTrace();
        }
        if (null != consumedBags) {
            for (BagConsumed entry:consumedBags){
                bagConsumedService.remove(entry);
            }
        }
        materialPackageConsumptionDao.delete(bagging);
    }

    @RemotingInclude
    public MaterialPackageConsumption save(MaterialPackageConsumption materialPackageConsumption) {
        MaterialPackageConsumption saved = materialPackageConsumptionDao.saveOrUpdate(materialPackageConsumption);
        if (materialPackageConsumption != null && materialPackageConsumption.getFuelleBagConsumption()!=null){
            for (BagConsumed entry : (materialPackageConsumption.getFuelleBagConsumption()) ) {
                entry.setMaterialPackageConsumption(saved);
                bagConsumedService.save(entry);
            }
        }
        return saved;
    }

    @RemotingInclude
    public MaterialPackageConsumption update(MaterialPackageConsumption materialPackageConsumption) {
        return materialPackageConsumptionDao.saveOrUpdate(materialPackageConsumption);
    }

    @RemotingInclude
    public Collection<MaterialPackageConsumption> findAll() throws Exception {
        Collection<MaterialPackageConsumption> results = materialPackageConsumptionDao.findAll();
        return results;
    }

}
