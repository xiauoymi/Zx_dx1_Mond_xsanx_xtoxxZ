package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.MaterialPackage;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 10:16:29 AM
 * To change this template use File | Settings | File Templates.
 */
public interface MaterialPackageService {

    MaterialPackage save(MaterialPackage mp);

    MaterialPackage update(MaterialPackage mp);

    void remove(MaterialPackage mp) throws Exception;

    Collection<MaterialPackage> findByPlantSeason(int idPlantSeason) throws Exception;

    Collection<MaterialPackage> findAll() throws Exception;

    public Collection<MaterialPackage> findByHybrid(int idHybrid) throws Exception;

}
