package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.MaterialPackageDao;
import com.monsanto.mcs.model.hibernate.MaterialPackage;
import com.sun.management.VMOption;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 10:19:10 AM
 * To change this template use File | Settings | File Templates.
 */
@Service("materialPackageService")
@RemotingDestination
public class MaterialPackageServiceImpl implements MaterialPackageService {

    @Autowired
    MaterialPackageDao dao = null;

    @RemotingInclude
    public Collection<MaterialPackage> findByPlantSeason(int idPlantSeason) throws Exception {
        Collection<MaterialPackage> results = dao.findByPlantSeason(idPlantSeason);
        return results;

    }

    @RemotingInclude
    public void remove(MaterialPackage origin) throws Exception {
        try {
           dao.delete(origin);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public MaterialPackage save(MaterialPackage origin) {
        origin.setLastUpdate(new Date());
        MaterialPackage result = dao.saveOrUpdate(origin);
        return result;
    }

    @RemotingInclude
    public MaterialPackage update(MaterialPackage origin) {
        MaterialPackage result = dao.saveOrUpdate(origin);
        origin.setLastUpdate(new Date());
        return result;
    }

    @RemotingInclude
    public Collection<MaterialPackage> findAll() throws Exception {
        Collection<MaterialPackage> feedback = dao.findAll();
        return feedback;
    }

    @RemotingInclude
    public Collection<MaterialPackage> findByHybrid(int idHybrid) throws Exception{
        Collection<MaterialPackage> feedback = dao.findByHybrid(idHybrid);
        return feedback;
    }

}
