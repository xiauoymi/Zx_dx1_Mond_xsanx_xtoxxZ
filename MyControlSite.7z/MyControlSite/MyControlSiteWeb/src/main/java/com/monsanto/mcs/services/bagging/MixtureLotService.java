package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.MixtureLot;
import java.util.Collection;


public interface MixtureLotService {

    MixtureLot save(MixtureLot mixtureLot);

    MixtureLot update(MixtureLot mixtureLot);

    void remove(MixtureLot mixtureLot);

    Collection<MixtureLot> findAll() throws Exception;

    Collection<MixtureLot> findByBagging(long baggingId) throws Exception; 
}
