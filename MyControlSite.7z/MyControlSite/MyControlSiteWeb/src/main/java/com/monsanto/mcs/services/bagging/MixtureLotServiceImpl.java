package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.MixtureLotDao;
import com.monsanto.mcs.model.hibernate.MixtureLot;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("mixtureLotService")
@RemotingDestination
public class MixtureLotServiceImpl implements MixtureLotService {

    @Autowired
    MixtureLotDao mixtureLotDao = null;


    @RemotingInclude
    public void remove(MixtureLot mixtureLot) {
        mixtureLotDao.delete(mixtureLot);
    }

    @RemotingInclude
    public MixtureLot save(MixtureLot mixtureLot) {
        return mixtureLotDao.saveOrUpdate(mixtureLot);
    }

    @RemotingInclude
    public MixtureLot update(MixtureLot mixtureLot) {
        return mixtureLotDao.saveOrUpdate(mixtureLot);
    }

    @RemotingInclude
    public Collection<MixtureLot> findAll() throws Exception {
        Collection<MixtureLot> mixtureLots = mixtureLotDao.findAll();
        return mixtureLots;
    }

    @RemotingInclude
    public Collection<MixtureLot> findByBagging(long baggingId) throws Exception {
        Collection<MixtureLot> bagsConsumed = mixtureLotDao.findByBagging(baggingId);
        return bagsConsumed;
    }

}
