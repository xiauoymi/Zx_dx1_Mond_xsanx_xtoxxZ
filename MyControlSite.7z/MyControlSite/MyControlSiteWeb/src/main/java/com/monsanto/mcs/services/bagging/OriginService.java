package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Origin;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 04:28:43 PM
 * To change this template use File | Settings | File Templates.
 */
public interface OriginService {

    Origin save(Origin origin);

    Origin update(Origin origin);

    void remove(Origin origin) throws Exception;

    Collection<Origin> findByName(String code) throws Exception;

    Collection<Origin> findAll() throws Exception;


}
