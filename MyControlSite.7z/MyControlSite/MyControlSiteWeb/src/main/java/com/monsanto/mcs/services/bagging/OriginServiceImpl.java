package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.OriginDao;
import com.monsanto.mcs.model.hibernate.Origin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 04:34:52 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("originService")
@RemotingDestination
public class OriginServiceImpl implements OriginService {

    @Autowired
    OriginDao dao = null;

    @RemotingInclude
    public Collection<Origin> findByName(String code) throws Exception {
        Collection<Origin> results = dao.findByName(code);
        return results;

    }

    @RemotingInclude
    public void remove(Origin origin) throws Exception{
        try {
           dao.delete(origin);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public Origin save(Origin origin) {
        origin.setLastUpdate(new Date());
        Origin result = dao.saveOrUpdate(origin);
        return result;
    }

    @RemotingInclude
    public Origin update(Origin origin) {
        Origin result = dao.saveOrUpdate(origin);
        origin.setLastUpdate(new Date());
        return result;
    }

    @RemotingInclude
    public Collection<Origin> findAll() throws Exception {
        Collection<Origin> feedback = dao.findAll();
        return feedback;
    }

}
