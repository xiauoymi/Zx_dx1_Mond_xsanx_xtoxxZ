package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.PlantSupervisor;
import com.sun.management.VMOption;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 02:50:47 PM
 * To change this template use File | Settings | File Templates.
 */
public interface PlantSupervisorService {

    PlantSupervisor save(PlantSupervisor ps) throws Exception;

    PlantSupervisor update(PlantSupervisor ps) throws Exception;

    void remove(PlantSupervisor ps) throws Exception;

    Collection<PlantSupervisor> findByPlant(int idPlant, String firstName) throws Exception;

    Collection<PlantSupervisor> findAll() throws Exception;

}
