package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.PlantSupervisorDao;
import com.monsanto.mcs.model.hibernate.PlantSupervisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 02:52:56 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("plantSupervisorService")
@RemotingDestination
public class PlantSupervisorServiceImpl implements PlantSupervisorService{

    @Autowired
    PlantSupervisorDao dao = null;

    @RemotingInclude
    public Collection<PlantSupervisor> findByPlant(int idPlant, String firstName) throws Exception {
        Collection<PlantSupervisor> results = dao.findByPlant(idPlant, firstName);
        return results;

    }

    @RemotingInclude
    public void remove(PlantSupervisor plantSupervisor) throws Exception {
        try {
           dao.delete(plantSupervisor);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public PlantSupervisor save(PlantSupervisor plantSupervisor) throws Exception {
        PlantSupervisor result = null;
        try {
           plantSupervisor.setLastUpdate(new Date());
           result = dao.saveOrUpdate(plantSupervisor);
        }
        catch(Exception e) {
            throw new Exception("Imposible to create this record.");
        }
        return result;
    }

    @RemotingInclude
    public PlantSupervisor update(PlantSupervisor plantSupervisor) throws Exception{
        PlantSupervisor result = null;
        try {
           plantSupervisor.setLastUpdate(new Date());
           result = dao.saveOrUpdate(plantSupervisor);
        }
        catch(Exception e) {
            throw new Exception("Imposible to update this record.");
        }

        return result;
    }

    @RemotingInclude
    public Collection<PlantSupervisor> findAll() throws Exception {
        Collection<PlantSupervisor> feedback = dao.findAll();
        return feedback;
    }


}
