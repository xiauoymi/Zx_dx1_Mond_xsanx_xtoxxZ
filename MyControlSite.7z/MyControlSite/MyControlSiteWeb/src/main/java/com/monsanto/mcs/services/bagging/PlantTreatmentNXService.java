package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.PlantTreatmentNX;
import com.monsanto.mcs.model.hibernate.PlantTreatmentVI;
import com.monsanto.mcs.model.hibernate.Schedule;

import java.util.Collection;
import java.util.Date;

public interface PlantTreatmentNXService {

    Collection<PlantTreatmentNX> findAll() throws Exception;

    Collection<PlantTreatmentNX> findAllByPlantDate(int plantId,Date date,String order) throws Exception;

    Double getTonsByOrder(Date date,Schedule schedule, String order) throws Exception;

    Double getSlurryReference(Date date,Schedule schedule, String order) throws Exception;

    Double getPonchoReference(Date date,Schedule schedule, String order) throws Exception;

    Double getPreciseReference(Date date,Schedule schedule, String order) throws Exception;

    Double getLtsTon(Date date,Schedule schedule, String order) throws Exception;

    Collection<PlantTreatmentNX> findByDateShiftOrder(Date date,Schedule schedule, String order) throws Exception;

}
