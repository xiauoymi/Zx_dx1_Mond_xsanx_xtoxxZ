package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.PlantTreatment;
import com.monsanto.mcs.model.hibernate.Schedule;
import java.util.Date;
import java.util.Collection;

public interface PlantTreatmentService {

    Collection<PlantTreatment> findAll() throws Exception;

    Collection<PlantTreatment> findAllByPlantDate(int plantId,Date date,String order) throws Exception;

    Double getTonsByOrder(Date date,Schedule schedule, String order) throws Exception;

    Double getSlurryReference(Date date,Schedule schedule, String order) throws Exception;

    Double getPonchoReference(Date date,Schedule schedule, String order) throws Exception;

    Double getPreciseReference(Date date,Schedule schedule, String order) throws Exception;

    Double getLtsTon(Date date,Schedule schedule, String order) throws Exception;

    Collection<PlantTreatment> findByDateShiftOrder(Date date,Schedule schedule, String order) throws Exception;

}
