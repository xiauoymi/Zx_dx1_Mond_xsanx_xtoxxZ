package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.PlantTreatmentVIDao;
import com.monsanto.mcs.model.hibernate.PlantTreatmentVI;
import com.monsanto.mcs.model.hibernate.Schedule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.*;

@Service("plantTreatmentVIService")
@RemotingDestination
public class PlantTreatmentServiceVIImpl implements PlantTreatmentVIService {

    @Autowired
    PlantTreatmentVIDao dao = null;

    @RemotingInclude
    public Collection<PlantTreatmentVI> findAll() throws Exception {
        return dao.findAll();
    }

    @RemotingInclude
    public Collection<PlantTreatmentVI> findAllByPlantDate(int plantId,Date date,String order) throws Exception {
        return dao.findByDateShiftOrder(date,null,order);
    }

    @RemotingInclude
    public Double getTonsByOrder(Date date,Schedule schedule, String order) throws Exception{
        return dao.getTonsByOrder(date,schedule,order);
    }

    @RemotingInclude
    public Double getSlurryReference(Date date,Schedule schedule, String order) throws Exception{
        return dao.getSlurryReference(date,schedule,order);
    }

    @RemotingInclude
    public Double getPonchoReference(Date date,Schedule schedule, String order) throws Exception{
        return dao.getPonchoReference(date,schedule,order);
    }

    @RemotingInclude
    public Double getPreciseReference(Date date,Schedule schedule, String order) throws Exception{
        return dao.getPreciseReference(date,schedule,order);
    }

    @RemotingInclude
    public Double getLtsTon(Date date,Schedule schedule, String order) throws Exception{
        Collection<PlantTreatmentVI> results = dao.findByDateShiftOrder(date,schedule,order);
        if (results == null){
            throw (new Exception("No se encontraron movimientos RSView para el criterio seleccionado."));
        }

        Map<Object,Double> tankRwMap = new HashMap();

        Map<Object,Double> tankRwGrsKgMap = new HashMap();

        Map<Object,Double> tankRwPercentMap = new HashMap();

        for (PlantTreatmentVI entry:results){
            if (!tankRwMap.keySet().contains(entry.getTank1RW())){
                if ( (Double)entry.getTank1TW() != 0 ){
                    tankRwMap.put(entry.getTank1RW(),(Double)entry.getWeight());
                }
            }else{
                if ( (Double)entry.getWeight() != 0 ){
                    Double tmp = tankRwMap.get(entry.getTank1RW());
                    tmp += (Double)entry.getWeight();
                    tankRwMap.put(entry.getTank1RW(),tmp);
                }
            }
        }
        Set keys = tankRwMap.keySet();
        Double ltsTons = 0D;
        for (Object key:keys){
            ltsTons += tankRwMap.get(key);
        }
        for (Object key:keys){
            tankRwPercentMap.put(key,( tankRwMap.get(key) / ltsTons ));
            Double tank1Rw = (Double) key;
            tankRwGrsKgMap.put(key,tank1Rw * (tankRwMap.get(key) / ltsTons));
        }
        ltsTons = 0D;
        for (Object key:keys){
            ltsTons += tankRwGrsKgMap.get(key);
        }
        ltsTons *= .991;
        return ltsTons;
    }

    @RemotingInclude
    public Collection<PlantTreatmentVI> findByDateShiftOrder(Date date,Schedule schedule, String order) throws Exception{
        Collection<PlantTreatmentVI> results = dao.findByDateShiftOrder(date,schedule,order);
        if (results == null){
            throw (new Exception("No se encontraron movimientos RSView para el criterio seleccionado."));
        }
        return results;
    }

}
