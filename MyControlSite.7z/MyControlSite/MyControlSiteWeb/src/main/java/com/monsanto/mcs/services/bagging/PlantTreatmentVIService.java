package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.PlantTreatment;
import com.monsanto.mcs.model.hibernate.PlantTreatmentVI;
import com.monsanto.mcs.model.hibernate.Schedule;

import java.util.Collection;
import java.util.Date;

public interface PlantTreatmentVIService {

    Collection<PlantTreatmentVI> findAll() throws Exception;

    Collection<PlantTreatmentVI> findAllByPlantDate(int plantId,Date date,String order) throws Exception;

    Double getTonsByOrder(Date date,Schedule schedule, String order) throws Exception;

    Double getSlurryReference(Date date,Schedule schedule, String order) throws Exception;

    Double getPonchoReference(Date date,Schedule schedule, String order) throws Exception;

    Double getPreciseReference(Date date,Schedule schedule, String order) throws Exception;

    Double getLtsTon(Date date,Schedule schedule, String order) throws Exception;

    Collection<PlantTreatmentVI> findByDateShiftOrder(Date date,Schedule schedule, String order) throws Exception;

}
