package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.BaggingControl;
import com.monsanto.mcs.model.hibernate.PlantabilityTest;

import java.util.Collection;


public interface PlantabilityTestService {

    PlantabilityTest save(PlantabilityTest plantabilityTest);

    PlantabilityTest update(PlantabilityTest plantabilityTest);

    void remove(PlantabilityTest plantabilityTest);

    Collection<PlantabilityTest> findAll() throws Exception;
}
