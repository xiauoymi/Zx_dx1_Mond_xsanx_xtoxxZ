package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.BaggingControlDao;
import com.monsanto.mcs.dao.PlantabilityTestDao;
import com.monsanto.mcs.model.hibernate.BaggingControl;
import com.monsanto.mcs.model.hibernate.PlantabilityTest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("plantabilityTestService")
@RemotingDestination
public class PlantabilityTestServiceImpl implements PlantabilityTestService {

    @Autowired
    PlantabilityTestDao plantabilityTestDao = null;


    @RemotingInclude
    public void remove(PlantabilityTest plantabilityTest) {
        plantabilityTestDao.delete(plantabilityTest);
    }

    @RemotingInclude
    public PlantabilityTest save(PlantabilityTest plantabilityTest) {
        return plantabilityTestDao.saveOrUpdate(plantabilityTest);
    }

    @RemotingInclude
    public PlantabilityTest update(PlantabilityTest plantabilityTest) {
        return plantabilityTestDao.saveOrUpdate(plantabilityTest);
    }

    @RemotingInclude
    public Collection<PlantabilityTest> findAll() throws Exception {
        Collection<PlantabilityTest> plantabilityTests = plantabilityTestDao.findAll();
        return plantabilityTests;
    }
}
