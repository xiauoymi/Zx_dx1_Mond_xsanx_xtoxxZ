package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Plate;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * To change this template use File | Settings | File Templates.
 */
public interface PlateService {

    Plate save(Plate plate) throws Exception;

    Plate update(Plate plate) throws Exception;

    void remove(Plate plate) throws Exception;

    Collection<Plate> findByName(String code) throws Exception;

    Collection<Plate> findAll() throws Exception;
}
