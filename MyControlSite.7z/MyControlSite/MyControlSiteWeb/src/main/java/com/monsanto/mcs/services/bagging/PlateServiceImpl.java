package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.PlateDao;
import com.monsanto.mcs.model.hibernate.Plate;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingExclude;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * To change this template use File | Settings | File Templates.
 */
@Service("plateService")
@RemotingDestination
public class PlateServiceImpl implements PlateService {

    @Autowired
    PlateDao plateDao = null;


    @RemotingInclude
    public Collection<Plate> findByName(String code) throws Exception {
        Collection<Plate> results = plateDao.findByName(code);
        return results;

    }

    @RemotingInclude
    public void remove(Plate plate) throws Exception{
        try {
           plateDao.delete(plate);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public Plate save(Plate plate) throws Exception{
        Plate result = null;
        try {
           plate.setLastUpdate(new Date());
           result = plateDao.saveOrUpdate(plate);
        }
        catch(Exception e) {
            throw new Exception("Imposible to create this record.");
        }
        return result;
    }

    @RemotingInclude
    public Plate update(Plate plate) throws Exception{
        Plate result = null;
        try {
           plate.setLastUpdate(new Date());
           result = plateDao.saveOrUpdate(plate);
        }
        catch(Exception e) {
            throw new Exception ("Imposible to update this record.");
        }

        return result;
    }

    @RemotingInclude
    public Collection<Plate> findAll() throws Exception {
        Collection<Plate> plates = plateDao.findAll();
        return plates;
    }
}
