package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Presentation;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 04:55:13 PM
 * To change this template use File | Settings | File Templates.
 */
public interface PresentationService {

    Presentation save(Presentation presentation);

    Presentation update(Presentation presentation);

    void remove(Presentation presentation) throws Exception;

    Collection<Presentation> findByName(String strValue) throws Exception;

    Collection<Presentation> findAll() throws Exception;

}
