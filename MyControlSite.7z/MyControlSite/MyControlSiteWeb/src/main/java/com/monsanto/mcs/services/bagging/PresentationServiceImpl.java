package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.PresentationDao;
import com.monsanto.mcs.model.hibernate.Presentation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 04:56:26 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("presentationService")
@RemotingDestination
public class PresentationServiceImpl implements PresentationService{
    
    @Autowired
    PresentationDao dao = null;

    @RemotingInclude
    public Collection<Presentation> findByName(String strValue) throws Exception {
        Collection<Presentation> results = dao.findByName(strValue);
        return results;
    }

    @RemotingInclude
    public void remove(Presentation presentation) throws Exception{
        try {
            dao.delete(presentation);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public Presentation save(Presentation presentation) {
        presentation.setLastUpdate(new Date());
        Presentation result = dao.saveOrUpdate(presentation);
        return result;
    }

    @RemotingInclude
    public Presentation update(Presentation shiftManager) {
        shiftManager.setLastUpdate(new Date());
        Presentation result = dao.saveOrUpdate(shiftManager);
        return result;
    }

    @RemotingInclude
    public Collection<Presentation> findAll() throws Exception {
        Collection<Presentation> shiftManagers = dao.findAll();
        return shiftManagers;
    }
    
    
    
}
