package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.SapBaggingOrder;

import java.util.Collection;


public interface SapBaggingOrderService {

    Collection<SapBaggingOrder> findAllSapBaggingOrders() throws Exception;

    Collection<SapBaggingOrder> findAllUnfilteredSapBaggingOrders() throws Exception;

}
