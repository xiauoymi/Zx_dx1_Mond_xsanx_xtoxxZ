package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.SapBaggingOrderDao;
import com.monsanto.mcs.model.hibernate.SapBaggingOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("sapBaggingOrderService")
@RemotingDestination
public class SapBaggingOrderServiceImpl implements SapBaggingOrderService {

    @Autowired
    SapBaggingOrderDao sapBaggingOrderDao;

    @RemotingInclude
    public Collection<SapBaggingOrder> findAllSapBaggingOrders()  throws Exception {
        return sapBaggingOrderDao.findAll();
    }

    @RemotingInclude
    public Collection<SapBaggingOrder> findAllUnfilteredSapBaggingOrders() throws Exception {
        return sapBaggingOrderDao.findAllUnfilteredSapBaggingOrders();
    }

}
