package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Shift;
import com.monsanto.mcs.model.util.SapMcsBaggingRevision;
import com.monsanto.mcs.model.util.SapMcsRevisionSummary;

import java.util.Collection;
import java.util.List;

public interface SapMcsBaggingRevisionService {

    Collection<SapMcsRevisionSummary> compare(long plantId, long seasonId, long order, Shift shift, String baggingDate, List<SapMcsBaggingRevision> sapRevision, int sapTimeDifference) throws Exception;

}
