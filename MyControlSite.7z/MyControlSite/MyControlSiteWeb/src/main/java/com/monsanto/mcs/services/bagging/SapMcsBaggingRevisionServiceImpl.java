package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Schedule;
import com.monsanto.mcs.model.hibernate.Shift;
import com.monsanto.mcs.model.util.SapMcsBaggingRevision;
import com.monsanto.mcs.model.util.SapMcsBaggingRevisionKey;
import com.monsanto.mcs.model.util.SapMcsRevisionSummary;
import com.monsanto.mcs.util.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;

import com.monsanto.mcs.model.hibernate.Bagging;

import java.text.SimpleDateFormat;
import java.util.*;

@Service("sapMcsBaggingRevisionService")
@RemotingDestination
public class SapMcsBaggingRevisionServiceImpl implements SapMcsBaggingRevisionService {

    @Autowired
    private BaggingService baggingService;

    @Autowired
    private ScheduleService scheduleService;

    private String getFormattedDate(Date date) {
        String DATE_FORMAT = "dd/MM/yyyy";
        SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
        return formatter.format(date);
    }

    private List<SapMcsBaggingRevision> filterByScheduleOrderBaggingDate(List<SapMcsBaggingRevision> sapRevision, Schedule schedule, String baggingDate, long order, int sapTimeDifference) throws Exception {
        DateTime baggingDateTime = new DateTime();
        baggingDateTime.setDate(baggingDate);
        Calendar startTime = new GregorianCalendar();
        startTime.setTime(baggingDateTime.getDateTime());
        startTime.set(Calendar.HOUR_OF_DAY, schedule.getInitialHour());
        startTime.set(Calendar.MINUTE, schedule.getInitialMinute());
        Calendar endTime = new GregorianCalendar();
        endTime.setTime(baggingDateTime.getDateTime());
        endTime.set(Calendar.HOUR_OF_DAY, schedule.getFinalHour());
        endTime.set(Calendar.MINUTE, schedule.getFinalMinute());
        if (schedule.getInitialHour() > schedule.getFinalHour()) {
            endTime.add(Calendar.DATE, 1);
        }
        List<SapMcsBaggingRevision> filteredSapRevision = new ArrayList<SapMcsBaggingRevision>();

        for (SapMcsBaggingRevision sapData : sapRevision) {
            if (!(sapData.getDocumentDate().trim().equals(getFormattedDate(startTime.getTime())) || sapData.getDocumentDate().trim().equals(getFormattedDate(endTime.getTime()))) || sapData.getOrder() != order) {
                continue;
            }
            String[] timeTokens = sapData.getTime().split(":");
            baggingDateTime.setDate(sapData.getDocumentDate());
            baggingDateTime.setHour(Integer.valueOf(timeTokens[0]));
            baggingDateTime.setMinute(Integer.valueOf(timeTokens[1]));
            Calendar baggingDateSAPCentralTime = getSapCentralTime(baggingDateTime, sapTimeDifference);
            baggingDateTime.setDate(baggingDateSAPCentralTime.getTime());
            baggingDateTime.setHour(baggingDateSAPCentralTime.get(Calendar.HOUR_OF_DAY));
            baggingDateTime.setMinute(baggingDateSAPCentralTime.get(Calendar.MINUTE));
            if ((baggingDateSAPCentralTime.getTime().compareTo(startTime.getTime()) >= 0 && baggingDateSAPCentralTime.getTime().compareTo(endTime.getTime()) < 0)) {
                filteredSapRevision.add(sapData);
            }
        }
        return filteredSapRevision;
    }

    private Calendar getSapCentralTime(DateTime baggingDateTime, int sapTimeDifference) {
        Calendar baggingDateSAPCentralTime = GregorianCalendar.getInstance();
        baggingDateSAPCentralTime.setTime(baggingDateTime.getDateTime());
        baggingDateSAPCentralTime.add(Calendar.HOUR_OF_DAY, sapTimeDifference);
        return baggingDateSAPCentralTime;
    }

    private HashMap<SapMcsBaggingRevisionKey, Integer> getSapConsumption(List<SapMcsBaggingRevision> sapRevision, long plantId, long order, Shift shift, String baggingDate, int sapTimeDifference) throws Exception {
        Schedule schedule = scheduleService.findByPlantShift((int) plantId, shift);
        sapRevision = filterByScheduleOrderBaggingDate(sapRevision, schedule, baggingDate, order, sapTimeDifference);
        HashMap<SapMcsBaggingRevisionKey, Integer> sum = new HashMap<SapMcsBaggingRevisionKey, Integer>();
        for (SapMcsBaggingRevision sapData : sapRevision) {
            Set<SapMcsBaggingRevisionKey> keySet = sum.keySet();
            SapMcsBaggingRevisionKey key = new SapMcsBaggingRevisionKey();
            key.setDocumentDate(baggingDate);
            key.setMaterial(sapData.getMaterial());
            key.setMaterialDescription(sapData.getMaterialDescription());
            key.setOrder(sapData.getOrder());
            key.setBatch(sapData.getBatch());
            if (keySet.contains(key)) {
                sum.put(key, (sum.get(key)) + sapData.getQuantityUne());
            } else {
                sum.put(key, sapData.getQuantityUne());
            }
        }
        return sum;
    }

    private Collection<SapMcsRevisionSummary> getMcsConsumption(HashMap<SapMcsBaggingRevisionKey, Integer> sapConsumption, Collection<Bagging> baggingConsumption, long plantId) {
        List<SapMcsRevisionSummary> summary = new ArrayList<SapMcsRevisionSummary>();
        Set<SapMcsBaggingRevisionKey> keySet = sapConsumption.keySet();
        Collection<Bagging> leftOvers = new ArrayList<Bagging>();

        Collection<Bagging> usedBaggingEntries = new ArrayList<Bagging>();
        for (SapMcsBaggingRevisionKey key : keySet) {
            double bags = 0;
            SapMcsRevisionSummary summaryItem = new SapMcsRevisionSummary();
            summaryItem.setPlant((int) plantId);
            summaryItem.setOrder(key.getOrder());
            summaryItem.setMaterial(key.getMaterial());
            summaryItem.setMaterialDescription(key.getMaterialDescription());
            summaryItem.setSapValue(sapConsumption.get(key));
            summaryItem.setBatch(key.getBatch());
            for (Bagging baggingEntry : baggingConsumption) {
                if (usedBaggingEntries.contains(baggingEntry)) {
                    if (sameDocumentDate(key, baggingEntry) && sameMaterial(key, baggingEntry) && sameBaggingOrder(key, baggingEntry) && sameBaggingLot(key, baggingEntry)) {
                        bags = bags + baggingEntry.getBaggingControl().getBaggedBags();
                    } else {
                        leftOvers.add(baggingEntry);
                        usedBaggingEntries.add(baggingEntry);
                    }
                }
            }
            summaryItem.setMcsValue(bags);
            summaryItem.setDifference(summaryItem.getMcsValue() - summaryItem.getSapValue());
            summary.add(summaryItem);
        }
        if (keySet.size() == 0) {
            leftOvers = baggingConsumption;
        }
        summary.addAll(getMcsConsumptionNotInSap(leftOvers));
        return summary;
    }

    private boolean sameBaggingLot(SapMcsBaggingRevisionKey key, Bagging baggingEntry) {
        return key.getBatch().equals(baggingEntry.getBaggingLot().getDescription());
    }

    private boolean sameBaggingOrder(SapMcsBaggingRevisionKey key, Bagging baggingEntry) {
        return key.getOrder() == baggingEntry.getBaggingOrder().getOrderNumber();
    }

    private boolean sameMaterial(SapMcsBaggingRevisionKey key, Bagging baggingEntry) {
        return key.getMaterial().equals(String.valueOf(baggingEntry.getBaggingOrder().getMaterialNumber()));
    }

    private boolean sameDocumentDate(SapMcsBaggingRevisionKey key, Bagging baggingEntry) {
        return key.getDocumentDate().equals(baggingEntry.getBaggingDate());
    }

    private Collection<SapMcsRevisionSummary> getMcsConsumptionNotInSap(Collection<Bagging> baggingConsumptionNotInSap) {
        Set<SapMcsRevisionSummary> summary = new HashSet<SapMcsRevisionSummary>();
        for (Bagging baggingEntry : baggingConsumptionNotInSap) {
            SapMcsRevisionSummary summaryItem = new SapMcsRevisionSummary();
            summaryItem.setPlant(baggingEntry.getBaggingLot().getPlant().getId().intValue());
            summaryItem.setOrder(baggingEntry.getBaggingOrder().getOrderNumber());
            summaryItem.setMaterial(baggingEntry.getBaggingOrder().getMaterialNumber().toString());
            summaryItem.setMaterialDescription(baggingEntry.getBaggingOrder().getDescription());
            summaryItem.setSapValue(0);
            summaryItem.setBatch(baggingEntry.getBaggingLot().getDescription());
            summaryItem.setMcsValue(baggingEntry.getBaggingControl().getBaggedBags());
            summaryItem.setDifference(summaryItem.getMcsValue() - summaryItem.getSapValue());
            if (summary.contains(summaryItem)) {
                SapMcsRevisionSummary tmpItem = getExistingSummaryItem(summary, summaryItem);
                summary.remove(tmpItem);
                summaryItem.setMcsValue(tmpItem.getMcsValue() + summaryItem.getMcsValue());
                summaryItem.setDifference(summaryItem.getMcsValue() - summaryItem.getSapValue());
            }
            summary.add(summaryItem);
        }
        return summary;
    }

    private SapMcsRevisionSummary getExistingSummaryItem(Set<SapMcsRevisionSummary> summary, SapMcsRevisionSummary summaryItem) {
        for (SapMcsRevisionSummary tmpItem : summary) {
            if (tmpItem.equals(summaryItem)) {
                return tmpItem;
            }
        }
        return null;
    }


    public Collection<SapMcsRevisionSummary> compare(long plantId, long seasonId, long order, Shift shift, String baggingDate, List<SapMcsBaggingRevision> sapRevision, int sapTimeDifference) throws Exception {
        Collection<Bagging> baggingConsumption = baggingService.findByDateShiftOrderSeason((int) plantId, baggingDate, shift, order, (int) seasonId);
        if (null == baggingConsumption) {
            return null;
        }
        HashMap<SapMcsBaggingRevisionKey, Integer> sapConsumption = getSapConsumption(sapRevision, plantId, order, shift, baggingDate, sapTimeDifference);
        return getMcsConsumption(sapConsumption, baggingConsumption, plantId);
    }

}
