package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.util.SapMcsChemicalRevision;
import com.monsanto.mcs.model.util.SapMcsRevisionSummary;

import java.util.Collection;
import java.util.List;

public interface SapMcsChemicalRevisionService {

    Collection<SapMcsRevisionSummary> compare(long plantId, long seasonId, long order, List<SapMcsChemicalRevision> sapConsumption) throws Exception;

}
