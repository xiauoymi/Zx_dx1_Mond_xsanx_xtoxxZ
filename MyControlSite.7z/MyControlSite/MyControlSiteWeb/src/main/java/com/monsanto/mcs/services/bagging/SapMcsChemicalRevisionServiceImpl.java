package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.util.SapMcsChemicalRevision;
import com.monsanto.mcs.model.util.SapMcsRevisionSummary;
import com.monsanto.mcs.model.hibernate.ChemicalRevision;
import com.monsanto.mcs.model.hibernate.Chemicals;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

@Service("sapMcsChemicalRevisionService")
@RemotingDestination
public class SapMcsChemicalRevisionServiceImpl implements SapMcsChemicalRevisionService{

    @Autowired
    private ChemicalRevisionService chemicalRevisionService;

    public Collection<SapMcsRevisionSummary> compare(long plantId, long seasonId, long order, List<SapMcsChemicalRevision> sapRevision) throws Exception{
        ChemicalRevision chemicalRevision = chemicalRevisionService.findByOrderNumber(plantId,seasonId,order);
        if (null == chemicalRevision){
            return null;
        }
        Set<Chemicals> chemicals = chemicalRevision.getChemicalsRevision().keySet();
        Collection<SapMcsRevisionSummary> summaryList = new ArrayList<SapMcsRevisionSummary>();
        for (SapMcsChemicalRevision sapData:sapRevision){
            SapMcsRevisionSummary summary = new SapMcsRevisionSummary();
            summary.setMaterial(sapData.getMaterial());
            summary.setOrder(order);
            summary.setPlant((int)plantId);
            for (Chemicals chemical:chemicals){
                if (chemical.getCode().equals(summary.getMaterial())){
                    summary.setMaterialDescription(chemical.getChemical());
                    summary.setMcsValue(chemicalRevision.getChemicalsRevision().get(chemical));
                    summary.setSapValue(sapData.getUnrestricted());
                    summary.setDifference(summary.getMcsValue() - summary.getSapValue());
                    break;
                }
            }
            summaryList.add(summary);
        }
        return summaryList;
    }
}
