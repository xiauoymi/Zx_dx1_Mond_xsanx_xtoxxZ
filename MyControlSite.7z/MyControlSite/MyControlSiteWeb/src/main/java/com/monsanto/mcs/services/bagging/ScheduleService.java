package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Schedule;
import com.monsanto.mcs.model.hibernate.Shift;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:49:12 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ScheduleService {
    Schedule save(Schedule lsc) throws Exception;

    Schedule update(Schedule lsc) throws Exception;

    void remove(Schedule lsc) throws Exception;

    Collection<Schedule> findByIdPlant(int idPlant) throws Exception;

    Collection<Schedule> findAll() throws Exception;

    Schedule findByDate(int idPlant, Date date) throws Exception;

    Schedule findByPlantShift(int plantId, Shift shift) throws Exception;


}
