package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.ScheduleDao;
import com.monsanto.mcs.model.hibernate.Schedule;
import com.monsanto.mcs.model.hibernate.Shift;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 24/01/2011
 * Time: 03:50:33 PM
 * To change this template use File | Settings | File Templates.
 */

@Service("scheduleService")
@RemotingDestination
public class ScheduleServiceImpl implements ScheduleService{
    @Autowired
    ScheduleDao scheduleDao = null;

    @RemotingInclude
    public Collection<Schedule> findByIdPlant(int idPlant) throws Exception {
        Collection<Schedule> results = scheduleDao.findByIdPlant(idPlant);
        return results;

    }

    @RemotingInclude
    public void remove(Schedule schedule) throws Exception {
        try {
            scheduleDao.delete(schedule);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public Schedule save(Schedule schedule) throws Exception{
        Schedule result;
        try {
           schedule.setLastUpdate(new Date());
           result = scheduleDao.saveOrUpdate(schedule);
        }
        catch(Exception e) {
            throw new Exception ("Imposible to create record.");
        }
        return result;
    }

    @RemotingInclude
    public Schedule update(Schedule schedule) throws Exception{
        Schedule result;
        try {
           schedule.setLastUpdate(new Date());
           result = scheduleDao.saveOrUpdate(schedule);
        }
        catch (Exception e) {
            throw new Exception ("Imposible to update record");
        }
        return result;
    }

    @RemotingInclude
    public Collection<Schedule> findAll() throws Exception {
        Collection<Schedule> specialist = scheduleDao.findAll();
        return specialist;
    }

    @RemotingInclude
    public Schedule findByDate(int idPlant,Date date) throws Exception{
        Collection<Schedule> schedules = scheduleDao.findByIdPlant(idPlant);
        Calendar currentDate = Calendar.getInstance();
        currentDate.setTime(date);
        for (Schedule schedule:schedules){
            Calendar shiftStart = new GregorianCalendar();
            shiftStart.setTime(date);
            shiftStart.set(Calendar.HOUR_OF_DAY,schedule.getInitialHour());
            shiftStart.set(Calendar.MINUTE,schedule.getInitialMinute());
            Calendar shiftEnd = new GregorianCalendar();
            shiftEnd.setTime(date);
            if (schedule.getInitialHour() > schedule.getFinalHour()){
                shiftEnd.add(Calendar.DATE,1);
                shiftStart.add(Calendar.DATE,-1);
            }
            shiftEnd.set(Calendar.HOUR_OF_DAY,schedule.getFinalHour());
            shiftEnd.set(Calendar.MINUTE,schedule.getFinalMinute());
            if (shiftStart.compareTo(currentDate)<=0 && shiftEnd.compareTo(currentDate)>0){
                return schedule;
            }
        }
        return null;
    }

    public Schedule findByPlantShift(int plantId, Shift shift) throws Exception{
        return scheduleDao.findByPlantShift(plantId,shift);
    }

}
