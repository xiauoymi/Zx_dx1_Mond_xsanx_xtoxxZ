package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.ShiftManager;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:51:03 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ShiftManagerService {
    ShiftManager save(ShiftManager sheller) throws Exception;

    ShiftManager update(ShiftManager sheller) throws Exception;

    void remove(ShiftManager sheller) throws Exception;

    Collection<ShiftManager> findByNameOrderedById(int idPlant, String name) throws Exception;

    Collection<ShiftManager> findByNameOrderedByName(int idPlant, String name) throws Exception;

    Collection<ShiftManager> findAll() throws Exception;     
}
