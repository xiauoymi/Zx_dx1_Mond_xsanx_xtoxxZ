package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.ShiftManagerDao;
import com.monsanto.mcs.model.hibernate.ShiftManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:51:15 AM
 * To change this template use File | Settings | File Templates.
 */

@Service("shiftManagerService")
@RemotingDestination
public class ShiftManagerServiceImpl implements ShiftManagerService{

    @Autowired
    ShiftManagerDao shiftManagerDao = null;

    @RemotingInclude
    public Collection<ShiftManager> findByNameOrderedById(int idPlant, String name) throws Exception {
        Collection<ShiftManager> results = shiftManagerDao.findByNameOrderedById(idPlant, name);
        return results;
    }

    @RemotingInclude
    public Collection<ShiftManager> findByNameOrderedByName(int idPlant, String name) throws Exception {
        Collection<ShiftManager> results = shiftManagerDao.findByNameOrderedByName(idPlant, name);
        return results;
    }

    @RemotingInclude
    public void remove(ShiftManager shiftManager) throws Exception {
        try {
           shiftManagerDao.delete(shiftManager);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public ShiftManager save(ShiftManager shiftManager) throws Exception{
        ShiftManager result = null;
        try {
           shiftManager.setLastUpdate(new Date());
           result = shiftManagerDao.saveOrUpdate(shiftManager);
        }
        catch(Exception e) {
            throw new Exception("Imposible to create this record");
        }
        return result;
    }

    @RemotingInclude
    public ShiftManager update(ShiftManager shiftManager) throws Exception{
        ShiftManager result = null;
        try {
           shiftManager.setLastUpdate(new Date());
           result = shiftManagerDao.saveOrUpdate(shiftManager);
        }
        catch(Exception e) {
            throw new Exception("Imposible to update this record");
        }
        return result;
    }

    @RemotingInclude
    public Collection<ShiftManager> findAll() throws Exception {
        Collection<ShiftManager> shiftManagers = shiftManagerDao.findAll();
        return shiftManagers;
    }
    

}
