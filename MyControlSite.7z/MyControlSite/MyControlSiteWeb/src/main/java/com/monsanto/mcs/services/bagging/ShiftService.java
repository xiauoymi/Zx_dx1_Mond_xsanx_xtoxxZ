package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Shift;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * To change this template use File | Settings | File Templates.
 */
public interface ShiftService {

    Shift save(Shift shift) throws Exception;

    Shift update(Shift shift) throws Exception;

    void remove(Shift shift) throws Exception;

    Collection<Shift> findByName(String name) throws Exception;

    Collection<Shift> findAll() throws Exception;
}
