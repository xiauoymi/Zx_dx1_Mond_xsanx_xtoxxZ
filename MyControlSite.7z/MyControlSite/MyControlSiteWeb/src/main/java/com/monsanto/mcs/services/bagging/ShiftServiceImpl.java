package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.ShiftDao;
import com.monsanto.mcs.model.hibernate.Shift;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingExclude;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * To change this template use File | Settings | File Templates.
 */
@Service("shiftService")
@RemotingDestination
public class ShiftServiceImpl implements ShiftService {

    @Autowired
    ShiftDao shiftDao = null;


    @RemotingInclude
    public Collection<Shift> findByName(String name) throws Exception {
        Collection<Shift> results = shiftDao.findByName(name);
        return results;

    }

    @RemotingInclude
    public void remove(Shift shift) throws Exception{
        try {
            shiftDao.delete(shift);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }

    }

    @RemotingInclude
    public Shift save(Shift shift) throws Exception{
        Shift result = null;
        try {
           shift.setLastUpdate(new Date());
           result = shiftDao.saveOrUpdate(shift);
        }
        catch(Exception e) {
            throw new Exception("Imposible to create this record.");
        }
        return result;
    }

    @RemotingInclude
    public Shift update(Shift shift) throws Exception{
        Shift result = null;
        try {
           shift.setLastUpdate(new Date());
           result = shiftDao.saveOrUpdate(shift);
        }
        catch(Exception e) {
            throw new Exception("Imposible to update this record");
        }

        return result;
    }

    @RemotingInclude
    public Collection<Shift> findAll() throws Exception {
        Collection<Shift> shifts = shiftDao.findAll();
        return shifts;
    }

}
