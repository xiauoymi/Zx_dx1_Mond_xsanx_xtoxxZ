package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.BaggingControl;
import com.monsanto.mcs.model.hibernate.SnicsLabel;

import java.util.Collection;


public interface SnicsLabelService {

    SnicsLabel save(SnicsLabel snicsLabel);

    SnicsLabel update(SnicsLabel snicsLabel);

    void remove(SnicsLabel snicsLabel);

    Collection<SnicsLabel> findAll() throws Exception;
}
