package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.SnicsLabelDao;
import com.monsanto.mcs.model.hibernate.SnicsLabel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("snicsLabelService")
@RemotingDestination
public class SnicsLabelServiceImpl implements SnicsLabelService {

    @Autowired
    SnicsLabelDao snicsLabelDao = null;


    @RemotingInclude
    public void remove(SnicsLabel snicsLabel) {
        snicsLabelDao.delete(snicsLabel);
    }

    @RemotingInclude
    public SnicsLabel save(SnicsLabel snicsLabel) {
        return snicsLabelDao.saveOrUpdate(snicsLabel);
    }

    @RemotingInclude
    public SnicsLabel update(SnicsLabel snicsLabel) {
        return snicsLabelDao.saveOrUpdate(snicsLabel);
    }

    @RemotingInclude
    public Collection<SnicsLabel> findAll() throws Exception {
        Collection<SnicsLabel> snicsLabels = snicsLabelDao.findAll();
        return snicsLabels;
    }
}
