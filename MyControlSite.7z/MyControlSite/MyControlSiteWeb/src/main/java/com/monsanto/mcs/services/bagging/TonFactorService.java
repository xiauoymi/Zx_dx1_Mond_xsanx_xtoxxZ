package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.TonFactor;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 09:49:39 AM
 * To change this template use File | Settings | File Templates.
 */
public interface TonFactorService {

    TonFactor save(TonFactor tf);

    TonFactor update(TonFactor tf);

    void remove(TonFactor tf) throws Exception;

    Collection<TonFactor> findByPlant(int idPlant) throws Exception;

    Collection<TonFactor> findAll() throws Exception;


}
