package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.TonFactorDao;
import com.monsanto.mcs.model.hibernate.TonFactor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 13/07/2011
 * Time: 09:53:38 AM
 * To change this template use File | Settings | File Templates.
 */
@Service("tonFactorService")
@RemotingDestination
public class TonFactorServiceImpl implements TonFactorService{
    
    @Autowired
    TonFactorDao dao = null;


    @RemotingInclude
    public Collection<TonFactor> findByPlant(int idPlant) throws Exception {
        Collection<TonFactor> results = dao.findByPlant(idPlant);
        return results;

    }

    @RemotingInclude
    public void remove(TonFactor tonFactor) throws Exception{
        try {
            dao.delete(tonFactor);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public TonFactor save(TonFactor tonFactor) {
        tonFactor.setLastUpdate(new Date());
        TonFactor result = dao.saveOrUpdate(tonFactor);
        return result;
    }

    @RemotingInclude
    public TonFactor update(TonFactor tonFactor) {
        TonFactor result = dao.saveOrUpdate(tonFactor);
        tonFactor.setLastUpdate(new Date());
        return result;
    }

    @RemotingInclude
    public Collection<TonFactor> findAll() throws Exception {
        Collection<TonFactor> tonFactors = dao.findAll();
        return tonFactors;
    }    
    
}
