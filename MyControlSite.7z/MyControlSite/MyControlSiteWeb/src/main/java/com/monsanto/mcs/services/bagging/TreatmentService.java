package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.model.hibernate.Treatment;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 03:57:56 PM
 * To change this template use File | Settings | File Templates.
 */
public interface TreatmentService {

    Treatment save(Treatment shift) throws Exception;

    Treatment update(Treatment shift) throws Exception;

    void remove(Treatment shift) throws Exception;

    Collection<Treatment> findByName(String name) throws Exception;

    Collection<Treatment> findAll() throws Exception;

}
