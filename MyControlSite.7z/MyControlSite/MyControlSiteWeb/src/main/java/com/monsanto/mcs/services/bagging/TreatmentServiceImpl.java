package com.monsanto.mcs.services.bagging;

import com.monsanto.mcs.dao.TreatmentDao;
import com.monsanto.mcs.model.hibernate.Treatment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 12/07/2011
 * Time: 03:59:11 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("treatmentService")
@RemotingDestination
public class TreatmentServiceImpl implements TreatmentService {


    @Autowired
    TreatmentDao dao = null;


    @RemotingInclude
    public Collection<Treatment> findByName(String name) throws Exception {
        Collection<Treatment> results = dao.findByNameOrderedById(name);
        return results;

    }

    @RemotingInclude
    public void remove(Treatment shift) throws Exception{
        try {
            dao.delete(shift);
        }
        catch (Exception e) {
            throw new Exception("Imposible to delete this record.");
        }
    }

    @RemotingInclude
    public Treatment save(Treatment treatment) throws Exception{
        Treatment result = null;
        try {
           treatment.setLastUpdate(new Date());
           result = dao.saveOrUpdate(treatment);
        }
        catch(Exception e) {
            throw new Exception("Imposible to create this record");
        }
        return result;
    }

    @RemotingInclude
    public Treatment update(Treatment shift) throws Exception{
        Treatment result = null;
        try {
           shift.setLastUpdate(new Date());
           result = dao.saveOrUpdate(shift);
        }
        catch(Exception e) {
            throw new Exception("Imposible to update this record.");
        }
        return result;
    }

    @RemotingInclude
    public Collection<Treatment> findAll() throws Exception {
        Collection<Treatment> shifts = dao.findAll();
        return shifts;
    }

}
