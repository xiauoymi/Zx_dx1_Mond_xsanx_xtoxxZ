package com.monsanto.mcs.services.fquality;

import com.monsanto.mcs.model.hibernate.Condition;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 28/12/2010
 * Time: 08:12:38 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ConditionService {

    void save(Condition condition);

    void update(Condition condition);

    void remove(Condition condition);

    Collection<Condition> findByName(String name, int idPlant);

    Collection<Condition> findAll();

    Collection<Condition> findByQuarantinedFieldStage(int fieldStageId);
}
