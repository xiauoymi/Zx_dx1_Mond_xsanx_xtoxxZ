package com.monsanto.mcs.services.fquality;

import com.monsanto.mcs.dao.ConditionDao;
import com.monsanto.mcs.model.hibernate.Condition;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FPALACI
 * Date: 28/12/2010
 * Time: 08:14:26 AM
 * To change this template use File | Settings | File Templates.
 */

@Service("conditionService")
@RemotingDestination
public class ConditionServiceImpl implements ConditionService {

    private static final Logger LOG = Logger.getLogger(ConditionServiceImpl.class);

    @Autowired
    private ConditionDao conditionDao;

    @RemotingInclude
    public Collection<Condition> findByName(String name, int idPlant){
        Collection<Condition> results = conditionDao.findByName(name, idPlant);
        return results;
    }

    @RemotingInclude
    public void remove(Condition condition) {
        conditionDao.delete(condition);
    }

    @RemotingInclude
    public void save(Condition condition) {
        conditionDao.saveOrUpdate(condition);
    }

    @RemotingInclude
    public void update(Condition condition) {
        conditionDao.saveOrUpdate(condition);
    }

    @RemotingInclude
    public Collection<Condition> findAll(){
        Collection<Condition> results = conditionDao.findAll();
        return results;
    }

    @RemotingInclude
    public Collection<Condition> findByQuarantinedFieldStage(int fieldStageId){
        Collection<Condition> results = conditionDao.findByQuarantinedFieldStage(fieldStageId);
        return results;
    }
}

