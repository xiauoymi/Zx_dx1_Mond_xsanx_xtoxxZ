package com.monsanto.mcs.services.fquality;

import com.monsanto.mcs.dao.ContaminationTypeDao;
import com.monsanto.mcs.model.hibernate.ContaminationType;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FFLABO
 * Date: Feb 3, 2011
 * Time: 1:57:50 PM
 * To change this template use File | Settings | File Templates.
 */

@Service("contaminationService")
@RemotingDestination
public class ContaminationTypeServiceImpl implements ContaminationTypeService{

    private static final Logger LOG = Logger.getLogger(ContaminationTypeServiceImpl.class);

    @Autowired
    private ContaminationTypeDao contaminationDao;

    @RemotingInclude
    public void save(ContaminationType contamination) {        
        contaminationDao.saveOrUpdate(contamination);     
    }

    @RemotingInclude
    public void update(ContaminationType contamination) {
        contaminationDao.saveOrUpdate(contamination);
    }

    @RemotingInclude
    public void remove(ContaminationType contamination) {
         contaminationDao.delete(contamination);         
    }

    @RemotingInclude
    public Collection<ContaminationType> findByType(String type, int plantId){
        Collection<ContaminationType> results = contaminationDao.findByType(type, plantId);
        return results;
    }

    @RemotingInclude
    public Collection<ContaminationType> findAll(){
        Collection<ContaminationType>  results = contaminationDao.findAll();
        return results;
    }
}
