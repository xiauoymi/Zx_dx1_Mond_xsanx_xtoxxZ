package com.monsanto.mcs.services.fquality;

import com.monsanto.mcs.model.hibernate.FloweringData;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FFLABO
 * Date: Feb 15, 2011
 * Time: 12:59:10 PM
 * To change this template use File | Settings | File Templates.
 */
public interface FloweringDataService {

    FloweringData save(FloweringData floweringData);

    FloweringData saveRecord(FloweringData floweringData);

    void update(FloweringData floweringData);

    void remove (FloweringData floweringData);

    Collection<FloweringData> findByBatch(int batchId);    

    Collection<FloweringData> findAll();

    Collection<FloweringData> findByPlantAndSeason(Integer plantSeasonId);

}
