package com.monsanto.mcs.services.fquality;

import com.monsanto.mcs.model.hibernate.FieldBatchRecord;
import com.monsanto.mcs.model.hibernate.FieldStage;
import com.monsanto.mcs.model.hibernate.GeneticResult;
import com.monsanto.mcs.model.hibernate.QuarantineLot;

import java.util.Collection;


public interface GeneticResultService {

    GeneticResult save(GeneticResult geneticResult) throws Exception;

    void update(GeneticResult geneticResult);

    void remove(GeneticResult geneticResult);

    public Collection<GeneticResult> findByBatch(int batchId);

    public Collection<GeneticResult> findByBatch(int batchId,int type);

    public Collection<GeneticResult> findByFieldStage(FieldStage fieldStage);

    public Collection<GeneticResult> findByFieldStage(FieldStage fieldStage,int type);

    public Collection<GeneticResult> findByFieldStageCondition(FieldStage fieldStage,int type,int conditionId);

    public Collection<GeneticResult> findAll();

    void emailGeneticResult(String userid, FieldBatchRecord fbr, QuarantineLot quarantineLot, long idPlant,GeneticResult geneticResult, boolean quarantined) throws Exception;

}
