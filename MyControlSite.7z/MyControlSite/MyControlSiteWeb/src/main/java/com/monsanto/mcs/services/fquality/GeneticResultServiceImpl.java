package com.monsanto.mcs.services.fquality;

import com.monsanto.mcs.dao.EmailToDao;
import com.monsanto.mcs.dao.GeneticResultDao;
import com.monsanto.mcs.email.EMail;
import com.monsanto.mcs.email.EMailer;
import com.monsanto.mcs.email.HtmlEmailDocumentCreator;
import com.monsanto.mcs.model.hibernate.*;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("geneticResultService")
@RemotingDestination
public class GeneticResultServiceImpl implements GeneticResultService{

    private static final Logger LOG = Logger.getLogger(GeneticResultServiceImpl.class);

    @Autowired
    private GeneticResultDao geneticResultDao;

    @Autowired
    private EmailToDao emailToDao = null;

    @RemotingInclude
    public GeneticResult save(GeneticResult result) throws Exception{
        GeneticResult geneticResult = geneticResultDao.saveOrUpdate(result);
        return geneticResult;
    }

    @RemotingInclude
    public void update(GeneticResult geneticResult) {
        geneticResultDao.saveOrUpdate(geneticResult);
    }

    @RemotingInclude
    public void remove(GeneticResult geneticResult) {
        geneticResultDao.delete(geneticResult);
    }

    @RemotingInclude
    public Collection<GeneticResult> findByBatch(int batchId){
        Collection<GeneticResult> results = geneticResultDao.findByBatch(batchId);
        return results;
    }

    @RemotingInclude
    public Collection<GeneticResult> findByBatch(int batchId,int type){
        Collection<GeneticResult> results = geneticResultDao.findByBatch(batchId);
        return results;
    }

    @RemotingInclude
    public Collection<GeneticResult> findByFieldStage(FieldStage fieldStage){
        Collection<GeneticResult> results = geneticResultDao.findByFieldStage(fieldStage);
        return results;
    }

    @RemotingInclude
    public Collection<GeneticResult> findByFieldStage(FieldStage fieldStage,int type){
        Collection<GeneticResult> results = geneticResultDao.findByFieldStage(fieldStage,type);
        return results;
    }

    @RemotingInclude
    public Collection<GeneticResult> findByFieldStageCondition(FieldStage fieldStage,int type,int conditionId){
        Collection<GeneticResult> results = geneticResultDao.findByFieldStageCondition(fieldStage,type,conditionId);
        return results;
    }

    @RemotingInclude
    public Collection<GeneticResult> findAll(){
        Collection<GeneticResult> results = geneticResultDao.findAll();
        return results;
    }

    @RemotingInclude
    public void emailGeneticResult(String userid, FieldBatchRecord fbr, QuarantineLot quarantineLot, long idPlant, GeneticResult geneticResult, boolean quarantined) throws Exception {
        EMailer eMailer = new EMailer(new HtmlEmailDocumentCreator());
        EMail eMail = null;
        StringBuffer body = new StringBuffer();
        String typeOfResult = (geneticResult.getType()==1?"Isoenzimas":"SNP");
        String subject = "";
        body.append("<H1>Notificaci&oacute;n del sistema  MyControlSite</H1><br>");
        if (quarantined) {
            subject = "MY CONTROL SITE - AVISO CONFIRMACION DE ACUERDO A RESULTADOS GENETICOS";
            // THE LOT IS QUARANTINED
            body.append("Esta es una notificaci&oacute;n de que el Lote de Campo descrito a continuaci&oacute;n se le confirma la cuarentena ");
            body.append("validado con los resultados gen&eacute;ticos de la prueba de " + typeOfResult);
        } else {
            subject = "MY CONTROL SITE - AVISO CAMBIO DE STATUS LOTE QUARENTENADO A LIBERADO P/ GENETICOS";
            // THE LOT IS RELEASED
            body.append("Esta es una notificaci&oacute;n de que el Lote de Campo descrito a continuaci&oacute;n cambi&oacute; de estatus cuarentenado a liberado ");
            body.append("validado con los resultados gen&eacute;ticos de la prueba de " + typeOfResult);
        }

        body.append(" <FONT COLOR='RED'><B>validado con los resultados gen&eacute;ticos.</B></FONT><br><br>");
        body.append("Hibrido:<B>"                  + fbr.getHybrid().getName() + "</B><BR>");
        body.append("No. Lote:" + "<B>"            + fbr.getLot() + "</B><BR>");
        body.append("Superficie (HAS):"            + fbr.getTotals()+ "<BR><BR>");
        if (quarantineLot == null) {
            body.append(">No hay datos del Lote Quarentenado***");
            body.append("Nombre de la prueba:"         + typeOfResult + "<BR>");
        }
        else {
            body.append("Etapa:"                       + quarantineLot.getFieldStage().getStage().getStageName() + "<BR>");
            body.append("Superficie de la etapa:"      + quarantineLot.getFieldStage().getHectares() + "<BR>");
            body.append("Superficie cuestionada:"      + quarantineLot.getSurface() + "<BR>");
            body.append("Nombre de la prueba:"         + typeOfResult + "<BR>");
            body.append("Tipo de cuarentena: <B>"      + quarantineLot.getQuarantine().getType() + "</B><BR>");
            body.append("Tipo de contaminante:<B>"     + quarantineLot.getContaminant().getType() + "</B><BR>");
            body.append("Tipo de contaminacion:"       + quarantineLot.getContaminationType().getType() + "<br><br>");
        }
        body.append("Tama&ntilde;o de la semilla:"   + geneticResult.getSeedSize().getSizeCode() + "<br><br>");
        body.append("Total selfs:"                 + geneticResult.getTselfs() + "<br><br>");
        body.append("% Total fuera de tipo:"       + geneticResult.getOffTypeT() + "<br><br>");
        body.append("Este es un mensaje generado autom&aacute;ticamente por el sistema, por favor no conteste este mensaje ya que es ");
        body.append("para fines informativos<BR><BR><BR>");
        Collection <EmailTo> listTos = emailToDao.findAllByMailType("GENETIC_RESULT", idPlant);
        for (EmailTo record : listTos) {
           eMail = createEMail(userid + "@monsanto.com", record.getAddress(), subject, body.toString());
            try{
           eMailer.send(eMail);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    };



    private EMail createEMail(String fromUser, String toUser, String subject, String body) {
        EMail email = new EMail();
        email.setSubject(subject);
        email.setFrom(fromUser);
        email.addTo(toUser);
        email.addBodyLine(body);
        return email;
    }

}
