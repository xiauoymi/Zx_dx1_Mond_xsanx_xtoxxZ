package com.monsanto.mcs.services.fquality;

import com.monsanto.mcs.model.hibernate.Quarantine;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FFLABO
 * Date: Feb 4, 2011
 * Time: 4:09:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface QuarantineService {

    void save(Quarantine contamination);

    void update(Quarantine contamination);

    void remove(Quarantine contamination);

    Collection<Quarantine> findByType(String type, int plantId);

    Collection<Quarantine> findAll();
}
