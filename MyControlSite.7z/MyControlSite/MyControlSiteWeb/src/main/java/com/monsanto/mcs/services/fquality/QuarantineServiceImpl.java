package com.monsanto.mcs.services.fquality;

import com.monsanto.mcs.dao.QuarantineDao;
import com.monsanto.mcs.model.hibernate.Quarantine;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: FFLABO
 * Date: Feb 4, 2011
 * Time: 4:23:04 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("quarantineService")
@RemotingDestination
public class QuarantineServiceImpl  implements QuarantineService{

    private static final Logger LOG = Logger.getLogger(QuarantineServiceImpl.class);

    @Autowired
    private QuarantineDao quarantineDao;

    @RemotingInclude
    public void save(Quarantine quarantine) {
        quarantineDao.saveOrUpdate(quarantine);
    }

    @RemotingInclude
    public void update(Quarantine quarantine) {
        quarantineDao.saveOrUpdate(quarantine);
    }

    @RemotingInclude
    public void remove(Quarantine quarantine) {
        quarantineDao.delete(quarantine);
    }
    @RemotingInclude
    public Collection<Quarantine> findByType(String type, int plantId){
        Collection<Quarantine> results = quarantineDao.findByType(type, plantId);
        return results;
    }

    @RemotingInclude
    public Collection<Quarantine> findAll(){
        Collection<Quarantine> results = quarantineDao.findAll();
        return results;
    }
}
