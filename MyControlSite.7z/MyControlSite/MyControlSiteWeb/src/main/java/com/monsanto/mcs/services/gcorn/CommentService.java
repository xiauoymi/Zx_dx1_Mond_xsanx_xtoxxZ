package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.Comment;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:51:03 AM
 * To change this template use File | Settings | File Templates.
 */
public interface CommentService {
    void save(Comment comment);

    void update(Comment comment);

    void remove(Comment comment);

    Collection<Comment> findByCommentOrderedById(int idPlant, String commentNumber) throws Exception;

    Collection<Comment> findAll() throws Exception;     
}
