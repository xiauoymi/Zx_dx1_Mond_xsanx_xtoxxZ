package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.CommentDao;
import com.monsanto.mcs.model.hibernate.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:51:15 AM
 * To change this template use File | Settings | File Templates.
 */
@Service("commentService")
@RemotingDestination
public class CommentServiceImpl implements CommentService{

    @Autowired
    private CommentDao commentDao = null;

    @RemotingInclude
    public Collection<Comment> findByCommentOrderedById(int idPlant, String commentValue) throws Exception {
        Collection<Comment> results = commentDao.findByCommentOrderedById(idPlant, commentValue);
        return results;
    }

    @RemotingInclude
    public void remove(Comment comment) {
        commentDao.delete(comment);
    }

    @RemotingInclude
    public void save(Comment comment) {
        comment.setLastUpdate(new Date());
        commentDao.saveOrUpdate(comment);
    }

    @RemotingInclude
    public void update(Comment comment) {
        comment.setLastUpdate(new Date());
        commentDao.saveOrUpdate(comment);
    }

    @RemotingInclude
    public Collection<Comment> findAll() throws Exception {
        Collection<Comment> comments = commentDao.findAll();
        return comments;
    }
    

}
