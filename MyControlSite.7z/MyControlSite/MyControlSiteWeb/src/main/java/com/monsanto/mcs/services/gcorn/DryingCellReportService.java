package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.DryingCellReport;

import java.util.Collection;

public interface DryingCellReportService {

    DryingCellReport findByFolio(int plant,Long folio) throws Exception;

    DryingCellReport findLastCellFolio(int plant,int cell) throws Exception;

    Collection<DryingCellReport> findAll() throws Exception;

    Collection<DryingCellReport> findAllByPlant(long plantId) throws Exception;

    Collection<DryingCellReport> findAllByPlantSeason(long plantSeasonId) throws Exception;

    DryingCellReport findByClossingCellId(int clossingCellId) throws Exception;

    Collection<DryingCellReport> findToDryAndShellByPlant(long plantId) throws Exception;

    Collection<DryingCellReport> findToDryAndShellByPlantSeason(long plantSeasonId) throws Exception;

    void remove(int plant,Long folio) throws Exception;

}
