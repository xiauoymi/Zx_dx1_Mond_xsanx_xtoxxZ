package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.DryingCellReportDao;
import com.monsanto.mcs.model.hibernate.DryingCellReport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("dryingCellReportService")
@RemotingDestination
public class DryingCellReportServiceImpl implements DryingCellReportService {

    @Autowired
    private DryingCellReportDao dryingCellReportDao = null;

    @RemotingInclude
    public DryingCellReport findByFolio(int plant,Long folio) throws Exception{
        DryingCellReport report = dryingCellReportDao.findByFolio(plant,folio);
        return report;
    }

    @RemotingInclude
    public DryingCellReport findLastCellFolio(int plant,int cell) throws Exception{
        DryingCellReport report = dryingCellReportDao.findLastCellFolio(plant,cell);
        return report;
    }

    @RemotingInclude
    public Collection<DryingCellReport> findAll() throws Exception{
        Collection<DryingCellReport> results = dryingCellReportDao.findAll();
        return results;
    }

    @RemotingInclude
    public Collection<DryingCellReport> findAllByPlant(long plantId) throws Exception {
        Collection<DryingCellReport> results = dryingCellReportDao.findAllByPlant(plantId);
        return results;
    }

    @RemotingInclude
    public DryingCellReport findByClossingCellId(int clossingCellId) throws Exception{
        DryingCellReport result = dryingCellReportDao.findByClossingCellId(clossingCellId);
        return result;
    }

    @RemotingInclude
    public Collection<DryingCellReport> findToDryAndShellByPlant(long plantId) throws Exception {
        Collection<DryingCellReport> results = dryingCellReportDao.findToDryAndShellByPlant(plantId);
        return results;
    }

    @RemotingInclude
    public Collection<DryingCellReport> findToDryAndShellByPlantSeason(long plantSeasonId) throws Exception {
        Collection<DryingCellReport> results = dryingCellReportDao.findToDryAndShellByPlantSeason(plantSeasonId);
        return results;
    }

    @RemotingInclude
    public void remove(int plant,Long folio) throws Exception {
        DryingCellReport dryingCellReport = this.findByFolio(plant, folio);
        dryingCellReportDao.delete(dryingCellReport);
    }

    @RemotingInclude
    public Collection<DryingCellReport> findAllByPlantSeason(long plantSeasonId) throws Exception {
        Collection<DryingCellReport> results = dryingCellReportDao.findAllByPlantSeason(plantSeasonId);
        return results;
    }

}
