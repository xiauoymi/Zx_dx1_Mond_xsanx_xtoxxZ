package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.DryingCell;

public interface DryingCellService {

    DryingCell getDryingCell(int plantSeasonId, int cell,int closingCellId) throws Exception;

}
