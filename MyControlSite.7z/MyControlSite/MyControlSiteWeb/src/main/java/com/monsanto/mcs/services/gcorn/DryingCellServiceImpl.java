package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.ReceiveLabelDao;
import com.monsanto.mcs.dao.ScaleDao;
import com.monsanto.mcs.model.DryingCell;
import com.monsanto.mcs.model.DryingCellEntry;
import com.monsanto.mcs.model.DryingCellFieldData;
import com.monsanto.mcs.model.DryingCellPlantData;
import com.monsanto.mcs.model.hibernate.ReceiveLabel;
import com.monsanto.mcs.model.hibernate.Scale;
import com.monsanto.mcs.model.hibernate.SendFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;

@Service("dryingCellService")
@RemotingDestination
public class DryingCellServiceImpl implements DryingCellService{

    @Autowired
    private ReceiveLabelDao receiveLabelDao = null;

    @Autowired
    private ScaleDao scaleDao = null;

    public DryingCell getDryingCell(int plantSeasonId,int cellId,int closingCellId) throws Exception {
        return getDryingCellByStatus(plantSeasonId,cellId,true,closingCellId);
    }

    @RemotingInclude
    public DryingCell getDryingCellByStatus(int plantSeasonId,int cellId,boolean status,int closingCellId) throws Exception {
        DryingCell cell = new DryingCell();
        DryingCellFieldData fieldData = null;
        DryingCellPlantData plantData = null;
        DryingCellEntry entry = null;
        SendFormat sendFormat = null;

        Collection<Scale> scales = scaleDao.findByPlantCell(plantSeasonId,0L,"",cellId,0,status,closingCellId);

        //BUSINESS RULE: Send Format Records not registered in Unload and Scale should not appear in the Report
        if (scales == null){
            return null;
        }
        for (Scale scale : scales) {
            fieldData = new DryingCellFieldData();
            plantData = new DryingCellPlantData();

            cell.setCell(cellId);
            cell.setStatus(!(scale.getClosed().equals(0L)));

            sendFormat = scale.getSendFormat();

            ReceiveLabel receiveLabel = receiveLabelDao.findBySendFormat(sendFormat.getSendFormatFolio());
            //BUSINESS RULE: Send Format Records not registered in Receive Label should not appear in the Report
            if (receiveLabel == null) {
                continue;
            }
            cell.setHybrid(sendFormat.getFieldBatchRecord().getHybrid().getName());

            fieldData.setSendFormatFolio(sendFormat.getSendFormatFolio());
            fieldData.setPlates(sendFormat.getTransport().getPlates());
            fieldData.setTable(sendFormat.getFieldBatchRecord().getLocation().getLocationName());
            if (sendFormat.getHarvestedFieldStage() != null && sendFormat.getHarvestedFieldStage().getQuarantineType() != null && sendFormat.getHarvestedFieldStage().getQuarantined()) {
                fieldData.setLot(String.valueOf(sendFormat.getFieldBatchRecord().getLot()) + sendFormat.getHarvestedFieldStage().getQuarantineType().getType());
            } else {
                fieldData.setLot(String.valueOf(sendFormat.getFieldBatchRecord().getLot()));
            }
            fieldData.setWeight(sendFormat.getHarvestedFieldStage().getFieldTons());
            fieldData.setHumidity(sendFormat.getHarvestedFieldStage().getFieldHumidity());

            plantData.setHumidity(receiveLabel.getPlantHumidity());
            plantData.setWeigth(scale.getReceivedWeigth());
            plantData.setUnloadStart(scale.getUnload().getUnloadStartDate());
            plantData.setUnloadEnd(scale.getUnload().getUnloadEndDate());

            entry = new DryingCellEntry();
            entry.setEntryDate(new Date());
            entry.setFieldData(fieldData);
            entry.setPlantData(plantData);

            cell.addEntry(entry);
        }

        return cell;

    }

}
