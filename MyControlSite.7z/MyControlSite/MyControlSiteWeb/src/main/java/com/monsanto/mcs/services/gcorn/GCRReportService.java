package com.monsanto.mcs.services.gcorn;

import java.io.InputStream;
import java.io.OutputStream;

public interface GCRReportService {

    public void createXls(InputStream in, OutputStream out, int plant,int season) throws Exception; 

}
