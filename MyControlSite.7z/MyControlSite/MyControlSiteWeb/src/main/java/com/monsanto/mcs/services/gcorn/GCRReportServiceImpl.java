package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import com.monsanto.mcs.model.hibernate.ReleaseByLotHybrid;
import com.monsanto.mcs.reports.GCRReportWorkbook;
import com.monsanto.mcs.services.reports.XlsTemplateBasedReport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Collection;

@Service("gcrReportService")
@RemotingDestination
public class GCRReportServiceImpl extends XlsTemplateBasedReport implements GCRReportService {

    @Autowired
    GreenCornReceiveService greenCornReceiveService;

    @Autowired
    ReleaseByLotHybridService releaseByLotHybridService;

    private Collection<GreenCornReceive> getGreenCornReceive(int plant,int season) throws Exception{
        return greenCornReceiveService.findByPlantSeason(plant, season);
    }

    private Collection<ReleaseByLotHybrid> getReleaseByHybrid(int plant,int season) throws Exception{
        return releaseByLotHybridService.findByPlantSeason(plant, season);
    }

    public void createXls(InputStream in, OutputStream out, int plant,int season) throws Exception{
        checkIOStreams(in,out);
        GCRReportWorkbook wb = new GCRReportWorkbook(in);
        wb.populateWorkbook(getReleaseByHybrid(plant,season),getGreenCornReceive(plant,season));
        wb.writeWorkbook(out);
    }

}
