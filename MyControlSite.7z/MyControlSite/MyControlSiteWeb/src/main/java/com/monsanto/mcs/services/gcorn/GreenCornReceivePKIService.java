package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import com.monsanto.mcs.model.hibernate.GreenCornReceivePKI;

import java.util.Collection;

public interface GreenCornReceivePKIService {

    Collection<GreenCornReceivePKI> findAll() throws Exception;

    Collection<GreenCornReceivePKI> findByPlantSeason(int idPlant, int idSeason) throws Exception;

    double getReceivedWeightByYearMonth(int plant, int season, String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception;

    double  getGreenCornLessThan25Humidity(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception;

    double  getGreenCornGreatherThan28Humidity(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception;

    double  getTotalCornWithTemperatureGreatherThan40InDataQuality(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception;

    double  getGreenSeedLoses(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception;

    double  getDryingRateAvg(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception;

    double  getDryingRateStdDev(String year, String month, Collection <GreenCornReceivePKI> collection, double average) throws Exception;

    double  getDryingRateHoursPerPoint(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception;

    double  getGranelConversionPercent(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception;

}
