package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.GreenCornReceiveDao;
import com.monsanto.mcs.dao.GreenCornReceivePKIDao;
import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import com.monsanto.mcs.model.hibernate.GreenCornReceivePKI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Service("greenCornReceiveServicePKI")
@RemotingDestination
public class GreenCornReceivePKIServiceImpl implements GreenCornReceivePKIService {

    class DryingRate {
        private int folio;
        private double dryingRate;
        private int cell;

        public int getFolio() {
            return folio;
        }

        public void setFolio(int folio) {
            this.folio = folio;
        }

        public double getDryingRate() {
            return dryingRate;
        }

        public void setDryingRate(double rate) {
            this.dryingRate = rate;
        }

        public int getCell() {
            return cell;
        }

        public void setCell(int cell) {
            this.cell = cell;
        }
    }

    public class GranelDetail {
        private int folio;
        private double kgsMazorca;
        private double kgsDesgrane;
        private int cell;

        public int getFolio() {
            return folio;
        }

        public void setFolio(int folio) {
            this.folio = folio;
        }

        public double getKgsMazorca() {
            return kgsMazorca;
        }

        public void setKgsMazorca(double kgsMazorca) {
            this.kgsMazorca = kgsMazorca;
        }

        public double getKgsDesgrane() {
            return kgsDesgrane;
        }

        public void setKgsDesgrane(double kgsDesgrane) {
            this.kgsDesgrane = kgsDesgrane;
        }

        public int getCell() {
            return cell;
        }

        public void setCell(int cell) {
            this.cell = cell;
        }
    }

    @Autowired
    private GreenCornReceivePKIDao greenCornReceivePKIDao = null;

    private static final double HUMIDITY_25PERCENT = 25;
    private static final double HUMIDITY_28PERCENT = 28;
    private static final double TEMPERATURE_QUALITY = 40;
    private static final double MIN_HOURS_PER_POINT = 2;
    private static final double MAX_HOURS_PER_POINT = 5;


    @RemotingInclude
    public Collection<GreenCornReceivePKI> findAll() throws Exception {
        return greenCornReceivePKIDao.findAll();
    }

    @RemotingInclude
    public Collection<GreenCornReceivePKI> findByPlantSeason(int idPlant, int idSeason) throws Exception {
        return greenCornReceivePKIDao.findByPlantSeason(idPlant,idSeason);
    }

    public double  getReceivedWeightByYearMonth(int plant, int season, String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception {
        double totalWeight = 0;
        int totalRecords = 0;
        if (collection == null){
            return 0;
        }
        for (GreenCornReceivePKI item : collection) {
            String outPlantDate = item.getOutPlantDate();
            if (outPlantDate != null) {
                if (dateInRange(outPlantDate, year, month)) {
                    totalWeight+= item.getReceivedWeight();
                    totalRecords++;
                }
            }
        }
        return totalWeight;
    }

    public double  getGreenCornLessThan25Humidity(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception {
        double totalWeightLessThan25 = 0;
        if (collection == null) {
            return 0;
        }
        for (GreenCornReceivePKI item : collection) {
            if (item.getOutPlantDate() != null && item.getPlantHumidity() != null) {
                if (dateInRange(item.getOutPlantDate(), year, month) && item.getPlantHumidity() < HUMIDITY_25PERCENT) {
                   totalWeightLessThan25+= item.getReceivedWeight();
                }
            }
        }
        return totalWeightLessThan25;
    }

    public double  getGreenCornGreatherThan28Humidity(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception {
        double totalWeightGreatherThan28 = 0;
        if (collection == null) {
            return 0;
        }
        for (GreenCornReceivePKI item : collection) {
            if (item.getOutPlantDate() != null && item.getPlantHumidity() != null) {
                if (dateInRange(item.getOutPlantDate(), year, month) && item.getPlantHumidity() > HUMIDITY_28PERCENT) {
                   totalWeightGreatherThan28+= item.getReceivedWeight();
                }
            }
        }
        return totalWeightGreatherThan28;
    }

    public double  getTotalCornWithTemperatureGreatherThan40InDataQuality(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception {
        double totalCorn = 0;
        if (collection == null) {
            return 0;
        }
        for (GreenCornReceivePKI item : collection) {
            if (item.getOutPlantDate() != null && item.getTemperature() != null) {
                if (dateInRange(item.getOutPlantDate(), year, month) && item.getTemperature() > TEMPERATURE_QUALITY) {
                   totalCorn+= item.getReceivedWeight();
                }
            }
        }
        return totalCorn;
    }

    public double  getGreenSeedLoses(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception {
        double totalMerma = 0;
        double merma = 0;
        int totalRecords = 0;
        if (collection == null) {
            return 0;
        }

        for (GreenCornReceivePKI item : collection) {
            if (item.getOutPlantDate() != null && item.getKgSampleManual() != null && item.getKgSampleMech() != null) {
                if (dateInRange(item.getOutPlantDate(), year, month)) {
                    merma = 0;
                    if (item.getKgSampleMech() != 0) {
                       merma = ((item.getKgSampleManual() / item.getKgSampleMech()) - 1) * 100;
                    }
                    if (merma >= 0) {
                       totalMerma+= merma;
                       totalRecords++;
                    }
                }
            }
        }
        return (totalRecords == 0 ? 0 : totalMerma / totalRecords);
    }

    public double  getDryingRateAvg(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception {
        double totalDryingRate = 0;
        if (collection == null) {
            return 0;
        }
        Set<DryingRate> listItems = getDryingRateListByEndDate(collection, year, month);
        for (Object element : listItems) {
            DryingRate record = (DryingRate) element;
            totalDryingRate+= record.getDryingRate();
        }
        return (listItems.size() == 0 ? 0 : totalDryingRate / listItems.size());
    }

    public double  getDryingRateStdDev(String year, String month, Collection <GreenCornReceivePKI> collection, double average) throws Exception {
        double powerTotal = 0;
        if (collection == null || average == 0) {
            return 0;
        }
        Set<DryingRate> listItems = getDryingRateListByEndDate(collection, year, month);
        for (Object item: listItems) {
            DryingRate element = (DryingRate) item;
            powerTotal+= Math.pow(element.getDryingRate() - average, 2);
        }
        return (listItems.size() == 0 ? 0 : Math.sqrt(powerTotal / average));
    }
    
    public double  getDryingRateHoursPerPoint(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception {
        double totalItems = 0;
        if (collection == null) {
            return 0;
        }
        Set<DryingRate> listItems = getDryingRateListByEndDate(collection, year, month);
        for (Object item: listItems) {
            DryingRate element = (DryingRate) item;
            if (element.getDryingRate() >= MIN_HOURS_PER_POINT && element.getDryingRate() <= MAX_HOURS_PER_POINT ) {
                totalItems++;
            }
        }
        return (listItems.size() == 0 ? 0 : (totalItems / listItems.size()) * 100);
    }

    public double  getGranelConversionPercent(String year, String month, Collection <GreenCornReceivePKI> collection) throws Exception {
        double totalMazorca = 0;
        double totalDesgrane = 0;
        if (collection == null) {
            return 0;
        }
        Set<GranelDetail> listItems = getGranelDetailList(collection, year, month);
        for (Object item: listItems) {
            GranelDetail element = (GranelDetail) item;
            totalMazorca+= element.getKgsMazorca();
            totalDesgrane+= element.getKgsDesgrane();
        }
        return (totalMazorca == 0 ? 0: (totalDesgrane / totalMazorca) * 100);
    }

    private Set <DryingRate> getDryingRateListByEndDate(Collection <GreenCornReceivePKI> collection, String year, String month) {
        Set listItems = new HashSet();
        //Obtiene valores unicos por CELDA, FOLIO y TASA (DEL MES  Y ANIO EN PROCESO
        for (GreenCornReceivePKI item : collection) {
            if (item.getDryingEndDate() != null       && item.getDryingRate() != null &&
                item.getPk().getDryingFolio()!= null && item.getPk().getCell() != null) {
                if (dateInRange(item.getDryingEndDate(), year, month)) {

                    DryingRate record = new DryingRate();
                    record.setCell(item.getPk().getCell());
                    record.setFolio(item.getPk().getDryingFolio());
                    record.setDryingRate(item.getDryingRate());
                    listItems.add(record);

                }
            }
        }
        return listItems;
    }

    private Set <GranelDetail> getGranelDetailList(Collection <GreenCornReceivePKI> collection, String year, String month) {
        Set listItems = new HashSet();
        //Obtiene valores unicos por CELDA, FOLIO y TASA (DEL MES  Y ANIO EN PROCESO
        for (GreenCornReceivePKI item : collection) {
            if (item.getDryingStartDate() != null       && item.getDryingRate() != null &&
                item.getPk().getDryingFolio()!= null && item.getPk().getCell() != null) {
                if (dateInRange(item.getDryingStartDate(), year, month)) {

                    GranelDetail record = new GranelDetail();
                    record.setCell(item.getPk().getCell());
                    record.setFolio(item.getPk().getDryingFolio());
                    record.setKgsDesgrane(item.getShellingKg());
                    record.setKgsMazorca(item.getShellingOrder());
                    listItems.add(record);

                }
            }
        }
        return listItems;
    }

    private boolean dateInRange(String date, String year, String month) {
        boolean feedback = false;
        if (date != null && year != null & month != null) {
            if (date.substring(6, 10).equalsIgnoreCase(year) &&
                date.substring(3, 5).equalsIgnoreCase(month)) {
                feedback = true;
            }
        }
        return feedback;
    }



}


