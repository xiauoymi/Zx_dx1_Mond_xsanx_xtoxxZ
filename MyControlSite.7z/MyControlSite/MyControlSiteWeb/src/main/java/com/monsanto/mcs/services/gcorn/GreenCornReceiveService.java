package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.GreenCornReceive;

import java.util.Collection;

public interface GreenCornReceiveService {
    void save(GreenCornReceive greenCornReceive);

    void update(GreenCornReceive greenCornReceive);

    void remove(GreenCornReceive greenCornReceive);

    Collection<GreenCornReceive> findAll() throws Exception;

    Collection<GreenCornReceive> findByPlantSeason(int idPlant, int idSeason) throws Exception;

}
