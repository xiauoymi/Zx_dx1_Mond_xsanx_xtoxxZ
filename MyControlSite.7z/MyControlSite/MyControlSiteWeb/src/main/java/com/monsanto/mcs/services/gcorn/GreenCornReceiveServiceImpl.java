package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.GreenCornReceiveDao;
import com.monsanto.mcs.model.hibernate.GreenCornReceive;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("greenCornReceiveService")
@RemotingDestination
public class GreenCornReceiveServiceImpl implements GreenCornReceiveService{

    @Autowired
    private GreenCornReceiveDao greenCornReceiveDao = null;

    @RemotingInclude
    public void remove(GreenCornReceive comment) {
        greenCornReceiveDao.delete(comment);
    }

    @RemotingInclude
    public void save(GreenCornReceive comment) {
        greenCornReceiveDao.saveOrUpdate(comment);
    }

    @RemotingInclude
    public void update(GreenCornReceive comment) {
        greenCornReceiveDao.saveOrUpdate(comment);
    }

    @RemotingInclude
    public Collection<GreenCornReceive> findAll() throws Exception {
        Collection<GreenCornReceive> collection = greenCornReceiveDao.findAll();
        return collection;
    }

    @RemotingInclude
    public Collection<GreenCornReceive> findByPlantSeason(int idPlant, int idSeason) throws Exception {
        Collection<GreenCornReceive> collection = greenCornReceiveDao.findByPlantSeason(idPlant,idSeason);
        return collection;
    }
    

}
