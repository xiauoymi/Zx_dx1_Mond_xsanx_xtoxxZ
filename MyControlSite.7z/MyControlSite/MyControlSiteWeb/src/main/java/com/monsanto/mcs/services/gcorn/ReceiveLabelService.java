package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.ReceiveLabel;

import java.util.Collection;

public interface ReceiveLabelService {

    ReceiveLabel save(ReceiveLabel label);

    ReceiveLabel update(ReceiveLabel label);

    void remove(ReceiveLabel label);

    ReceiveLabel findBySendFormat(String sendFormatFolio) throws Exception;

    Collection<ReceiveLabel> findAll(int plantId) throws Exception;

    Collection<ReceiveLabel> findByDestinationPlantAndSeason(long destinationPlantId, long seasonId) throws Exception;

    Boolean checkReceiveLabelForSF(Collection<String> sendFormatFolios) throws Exception;

}
