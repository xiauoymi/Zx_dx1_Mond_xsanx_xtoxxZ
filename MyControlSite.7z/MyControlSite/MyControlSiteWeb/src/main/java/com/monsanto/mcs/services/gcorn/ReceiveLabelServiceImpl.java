package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.ReceiveLabelDao;
import com.monsanto.mcs.model.hibernate.ReceiveLabel;
import com.monsanto.mcs.model.hibernate.SendFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

@Service("receiveLabelService")
@RemotingDestination
public class ReceiveLabelServiceImpl implements ReceiveLabelService{

    @Autowired
    private ReceiveLabelDao receiveLabelDao = null;

    @RemotingInclude
    public void remove(ReceiveLabel label) {
        receiveLabelDao.delete(label);
    }

    @RemotingInclude
    public ReceiveLabel save(ReceiveLabel label) {
        label.setLastUpdate(new Date());
        ReceiveLabel saved = receiveLabelDao.saveOrUpdate(label);
        return saved;
    }

    @RemotingInclude
    public ReceiveLabel update(ReceiveLabel label) {
        label.setLastUpdate(new Date());
        ReceiveLabel updated = receiveLabelDao.saveOrUpdate(label);
        return updated;
    }

    @RemotingInclude
    public ReceiveLabel findBySendFormat(String sendFormatFolio) throws Exception {
        ReceiveLabel format = receiveLabelDao.findBySendFormat(sendFormatFolio);
        return format;
    }

    @RemotingInclude
    public Boolean checkReceiveLabelForSF(Collection<String> sendFormatFolios) throws Exception{
        for (String sfFolio:sendFormatFolios){
            ReceiveLabel receiveLabel = this.findBySendFormat(sfFolio);
            if (receiveLabel == null){
                return false;
            }
        }
        return true;
    }

    @RemotingInclude
    public Collection<ReceiveLabel> findAll(int plantId) throws Exception {
        Collection<ReceiveLabel>  results= receiveLabelDao.findAll(plantId);
        return results;
    }

    @RemotingInclude
    public Collection<ReceiveLabel> findByDestinationPlantAndSeason(long destinationPlantId, long seasonId) throws Exception {
        Collection<ReceiveLabel>  results= receiveLabelDao.findByDestinationPlantAndSeason(destinationPlantId, seasonId);
        return results;
    }



}
