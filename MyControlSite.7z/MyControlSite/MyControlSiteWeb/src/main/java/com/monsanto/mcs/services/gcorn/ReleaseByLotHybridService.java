package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.ReleaseByLotHybrid;

import java.util.Collection;

public interface ReleaseByLotHybridService {

    Collection<ReleaseByLotHybrid> findAll() throws Exception;

    Collection<ReleaseByLotHybrid> findByPlantSeason(int plant,int season) throws Exception;

}
