package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.ReleaseByLotHybridDao;
import com.monsanto.mcs.model.hibernate.ReleaseByLotHybrid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service("releaseByLotHybridService")
@RemotingDestination
public class ReleaseByLotHybridServiceImpl implements ReleaseByLotHybridService {

    @Autowired
    ReleaseByLotHybridDao dao = null;

    public Collection<ReleaseByLotHybrid> findAll() throws Exception{
        return dao.findAll();
    }

    public Collection<ReleaseByLotHybrid> findByPlantSeason(int plant,int season) throws Exception{
        return dao.findByPlantSeason(plant,season);
    }

}
