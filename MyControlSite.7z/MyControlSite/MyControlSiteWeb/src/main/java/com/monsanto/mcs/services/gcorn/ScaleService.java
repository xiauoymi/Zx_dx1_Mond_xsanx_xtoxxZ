package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.*;

import java.util.Collection;

public interface ScaleService {

    Scale save(Scale unloadScale);

    Scale update(Scale format);

    Scale updateBillAssignment(Scale format);

    void updateMultipleBillAssignment(Collection <Scale> format, String billNumber);

    void remove(Scale format);

    Scale findByPrimaryKey(Long id) throws Exception;

    Scale findBySendFormat(String id) throws Exception;

    Collection<Scale> findAllByPlant(int option, int idPlantTo, int idSeason, long lot, String folio, int cell, int transport, String billNumber) throws Exception;

    public Collection <Scale> findByPlantCell(int idPlantSeason, long lot, String folio, int cell, int transport, boolean closed,int closingCellId) throws Exception;

    public Collection<Scale> findByTransportSupplier(int plantTo, int seasonId, String transportSupplier) throws Exception;

    ClosingCellLog closeCell(Collection <Scale> col, long plantSeasonId, String username,int cell) throws Exception;

    Collection<Scale> findAllByLot(long lot) throws Exception;

    public Collection <Scale> findByClosingCellLog(Collection<DryingCellReport> cells,long lotId, String sendFormatFolio, int cell) throws Exception;

    public int removefromClosingCell(Collection <Scale> col, ClosingCellLog closingCellLog, boolean openCell) throws Exception;

    public Collection <Scale> findByClosingCellLog(long closingCellId) throws Exception;

}
