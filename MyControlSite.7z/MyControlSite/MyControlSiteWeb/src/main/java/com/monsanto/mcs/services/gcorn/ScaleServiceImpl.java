package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.*;
import com.monsanto.mcs.model.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

@Service("scaleService")
@RemotingDestination
public class ScaleServiceImpl implements ScaleService {

    @Autowired
    private ScaleDao scaleDao = null;

    @Autowired
    private ClosingCellLogDao cclDao = null;

    @Autowired
    private DryingCellReportDao reportDao = null;

    @Autowired
    private PlantSeasonDao plantSeasonDao = null;

    @RemotingInclude
    public void remove(Scale scale) {
        scaleDao.delete(scale);
    }

    @RemotingInclude
    public Scale save(Scale scale) {
        scale.setLastUpdate(new Date());
        return scaleDao.saveOrUpdate(scale);
    }

    @RemotingInclude
    public Scale update(Scale scale) {
        scale.setLastUpdate(new Date());
        return scaleDao.saveOrUpdate(scale);
    }
    @RemotingInclude 
    public Scale updateBillAssignment(Scale scale) {
        scale.setBillAssignedDate(new Date());
        return scaleDao.saveOrUpdate(scale);
    }

    @RemotingInclude
    public void updateMultipleBillAssignment(Collection<Scale> lista, String billNumber) {
        for (Scale record : lista) {
            record.setBillAssignedDate(new Date());
            record.setBillNumber(billNumber);
            scaleDao.saveOrUpdate(record);
        }
    }

    @RemotingInclude
    public Scale findByPrimaryKey(Long id) throws Exception {
        return scaleDao.findByPrimaryKey(id);
    }

    @RemotingInclude
    public Scale findBySendFormat(String sendFormatFolio) throws Exception {
        return scaleDao.findBySendFormat(sendFormatFolio);
    }

    @RemotingInclude
    public Collection<Scale> findAllByPlant(int option, int idPlantTo, int idSeason, long lot, String folio, int cell, int transport, String billNumber) throws Exception {
       return scaleDao.findByPlant(option, idPlantTo, idSeason, lot, folio, cell, transport, billNumber);
    }

    @RemotingInclude
    public Collection<Scale> findByPlantCell(int idPlantSeason, long lot, String folio, int cell, int transport, boolean closed, int closingCellId) throws Exception {
       return scaleDao.findByPlantCell(idPlantSeason, lot, folio, cell, transport, closed, closingCellId);
    }

    @RemotingInclude
    public ClosingCellLog closeCell(Collection<Scale> col, long plantSeasonId, String username, int cell) throws Exception {
       ClosingCellLog feedback = null;
       try {
           if (col == null || col.size() == 0) {
               throw new Exception();
           }
           ClosingCellLog record = new ClosingCellLog();
           record.setPlantSeasonId(plantSeasonId);
           record.setUserId(username);
           record.setLastUpdate(new Date());
           record.setCell(col.iterator().next().getCell());
           record.setCell(cell);
           feedback = cclDao.saveOrUpdate(record);
           if (feedback != null) {
               for (Scale item : col) {
                   item.setClosed(feedback.getId());
                   scaleDao.saveOrUpdate(item);
               }
           }
           DryingCellReport dryingCellReport = new DryingCellReport();
           dryingCellReport.setClosingCellLog(feedback);
           PlantSeason plantSeason = plantSeasonDao.findByPrimaryKey(plantSeasonId);
           dryingCellReport.setPlant(plantSeason.getPlant());
           try {
               reportDao.saveOrUpdate(dryingCellReport);
           } catch (Exception re) {
               throw new Exception("Impossible to generate Drying Cell Report Folio.");
           }
       }
       catch (Exception e) {
           throw new Exception("Impossible to close cell.");
       }
       return feedback;
    }

    @RemotingInclude
    public int removefromClosingCell(Collection<Scale> col, ClosingCellLog closingCellLog, boolean openCell) throws Exception {
       int itemsRemoved = 0;
       try {
           if (col == null || col.size() == 0) {
               throw new Exception();
           }
           itemsRemoved = col.size();
           for (Scale item : col) {
               item.setClosed(0L);
               item.setCell(0);
               scaleDao.saveOrUpdate(item);
           }
           if (openCell) {
               cclDao.delete(closingCellLog);
           }
       }
       catch (Exception e) {
           e.printStackTrace();
           throw new Exception("Impossible to remove items from the specified cell.");
       }
       return itemsRemoved;
    }

    @RemotingInclude
    public Collection<Scale> findByTransportSupplier(int plantTo, int seasonId, String transportSupplier) throws Exception {
        return scaleDao.findByTransportSupplier(plantTo, seasonId, transportSupplier);
    }

    @RemotingInclude
    public Collection<Scale> findAllByLot(long lot) throws Exception {
        return scaleDao.findAllByLot(lot);
    }

    @RemotingInclude
    public Collection<Scale> findByClosingCellLog(Collection<DryingCellReport> cells, long lotId, String sendFormatFolio, int cell) throws Exception {
        return scaleDao.findByClosingCellLog(cells, lotId, sendFormatFolio, cell);
    }

    @RemotingInclude
    public Collection<Scale> findByClosingCellLog(long closingCellId) throws Exception {
        return scaleDao.findByClosingCellLog(closingCellId);
    }

}
