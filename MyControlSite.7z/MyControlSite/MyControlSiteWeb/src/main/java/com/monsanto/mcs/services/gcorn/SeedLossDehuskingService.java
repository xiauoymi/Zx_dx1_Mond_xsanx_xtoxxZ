package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.SeedLossDehusking;

import java.util.Collection;

public interface SeedLossDehuskingService {

    SeedLossDehusking save(SeedLossDehusking loss);

    SeedLossDehusking update(SeedLossDehusking loss);

    void remove(SeedLossDehusking loss);

    SeedLossDehusking findBySendFormat(String sendFormatFolio) throws Exception;

    Collection<SeedLossDehusking> findAll(int plantId) throws Exception;

    Collection<SeedLossDehusking> findByDestinationPlantAndSeason(long destinationPlantId, long seasonId) throws Exception;

}
