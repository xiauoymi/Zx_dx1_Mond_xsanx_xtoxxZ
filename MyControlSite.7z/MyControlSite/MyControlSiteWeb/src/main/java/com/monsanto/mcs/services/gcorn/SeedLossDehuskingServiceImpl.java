package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.ReceiveLabelDao;
import com.monsanto.mcs.dao.SeedLossDehuskingDao;
import com.monsanto.mcs.model.hibernate.ReceiveLabel;
import com.monsanto.mcs.model.hibernate.SeedLossDehusking;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

@Service("seedLossDehuskingService")
@RemotingDestination
public class SeedLossDehuskingServiceImpl implements SeedLossDehuskingService{

    @Autowired
    private SeedLossDehuskingDao seedLossDehuskingDao = null;

    @RemotingInclude
    public void remove(SeedLossDehusking loss) {
        seedLossDehuskingDao.delete(loss);
    }

    @RemotingInclude
    public SeedLossDehusking save(SeedLossDehusking loss) {
        SeedLossDehusking saved = null;
        if (existsSeedLossDehuskingForSendFormat(loss)){
            saved = update(loss);
        } else {
            loss.setLastUpdate(new Date());
            saved= seedLossDehuskingDao.saveOrUpdate(loss);
        }
        return saved;
    }

    private boolean existsSeedLossDehuskingForSendFormat(SeedLossDehusking loss) {
        try {
            return seedLossDehuskingDao.findBySendFormat(loss.getSendFormat().getSendFormatFolio())==null;
        } catch (Exception e) {
            return false;
        }
    }

    @RemotingInclude
    public SeedLossDehusking update(SeedLossDehusking loss) {
        loss.setLastUpdate(new Date());
        SeedLossDehusking updated = seedLossDehuskingDao.saveOrUpdate(loss);
        return updated;
    }

    @RemotingInclude
    public SeedLossDehusking findBySendFormat(String sendFormatFolio) throws Exception {
        SeedLossDehusking loss = seedLossDehuskingDao.findBySendFormat(sendFormatFolio);
        return loss;
    }

    @RemotingInclude
    public Collection<SeedLossDehusking> findAll(int plantId) throws Exception {
        Collection<SeedLossDehusking>  results= seedLossDehuskingDao.findAll(plantId);
        return results;
    }

    @RemotingInclude
    public Collection<SeedLossDehusking> findByDestinationPlantAndSeason(long destinationPlantId, long seasonId) throws Exception {
        Collection<SeedLossDehusking>  results= seedLossDehuskingDao.findByDestinationPlantAndSeason(destinationPlantId, seasonId);
        return results;
    }


}
