package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.Comment;
import com.monsanto.mcs.model.hibernate.FieldBatchRecord;
import com.monsanto.mcs.model.hibernate.SendFormat;

import java.util.Collection;

public interface SendFormatService {

    int save(SendFormat format) throws Exception;

    int update(SendFormat format) throws Exception;

    void remove(SendFormat format);

    SendFormat findBySendFormat(String sendFormatFolio) throws Exception;

    Collection <SendFormat> findAllByPlant(long idPlantTo, long idSeason, long lot, String folio) throws Exception;

    void email(String userid, FieldBatchRecord fbr, long idPlant) throws Exception;

    int deleteSendFormat(SendFormat sendFormat) throws Exception;

    public Collection <SendFormat> findAllByLot(long lot) throws Exception;

    public Collection <SendFormat> findAllBySendFormatFolio(String sendFormatFolio) throws Exception;

}


