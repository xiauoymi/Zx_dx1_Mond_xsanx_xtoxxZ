package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.*;
import com.monsanto.mcs.email.EMail;
import com.monsanto.mcs.email.EMailer;
import com.monsanto.mcs.email.HtmlEmailDocumentCreator;
import com.monsanto.mcs.model.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

@Service("sendFormatService")
@RemotingDestination
public class SendFormatServiceImpl implements SendFormatService {

    @Autowired
    private LocationZoneDao locZoneDao = null;

    @Autowired
    private WarantyWeightDao wwDao = null;

    @Autowired
    private CostTonDao costTonDao = null;


    @Autowired
    private SendFormatDao sendFormatDao = null;

    @Autowired
    private EmailToDao emailToDao = null;

    @Autowired
    private SeedLossDehuskingDao sld = null;

    @Autowired
    private ReceiveLabelDao rld = null;

    @Autowired
    private ScaleDao scaleDao = null;


    @RemotingInclude
    public void remove(SendFormat format) {
        sendFormatDao.delete(format);
    }

    @RemotingInclude
    public int save(SendFormat format) throws Exception {

        try {
            //GET ZONE
            long locationId = format.getFieldBatchRecord().getLocation().getId();
            LocationZone locZone = locZoneDao.findZoneByLocation(locationId);

            //LOCATION HAS NOT BEEN ASSIGNED TO A ZONE
            if (locZone == null) {
                return 1;
            }
            Zone zone = locZone.getZone();
            TransportType transportType = format.getWarantyWeight().getTransportType();
            TransportSupplier transportSupplier = format.getWarantyWeight().getTransportSupplier();
            Plant plantTo = format.getPlantTo();

            // THIS TRANSPORT SUPPLIER HAS NOT A WARRANTY WEIGHT FOR THE GIVEN ZONE AND TRANSPORT TYPE
            WarantyWeight ww = wwDao.findWarrantyForSendFormat(format.getFieldBatchRecord().getPlantSeason().getId(), transportType.getId(), transportSupplier.getId(), zone.getId(), plantTo.getId());
            if (ww == null) {
                return 2;
            }

            // THIS TRANSPORT SUPPLIER HAS NOT A COST TONE FOR THE GIVEN ZONE AND TRANSPORT TYPE
            CostTon ct = costTonDao.findCostTonForSendFormat(format.getFieldBatchRecord().getPlantSeason().getId(), transportType.getId(), transportSupplier.getId(), zone.getId(), plantTo.getId());
            if (ct == null) {
                return 3;
            }
            format.setLastUpdate(new Date());
            format.setCostTon(ct);
            format.setWarantyWeight(ww);


            SendFormat saved = sendFormatDao.saveOrUpdate(format);
            if (saved == null) {
                return 4;
            } else {
                return 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    @RemotingInclude
    public int update(SendFormat format) throws Exception {
        //GET ZONE
        long locationId = format.getFieldBatchRecord().getLocation().getId();
        LocationZone locZone = locZoneDao.findZoneByLocation(locationId);

        //LOCATION HAS NOT BEEN ASSIGNED TO A ZONE
        if (locZone == null) {
            return 1;
        }
        Zone zone = locZone.getZone();
        TransportType transportType = format.getWarantyWeight().getTransportType();
        TransportSupplier transportSupplier = format.getWarantyWeight().getTransportSupplier();
        Plant plantTo = format.getPlantTo();


        // THIS TRANSPORT SUPPLIER HAS NOT A WARRANTY WEIGHT FOR THE GIVEN ZONE AND TRANSPORT TYPE
        WarantyWeight ww = wwDao.findWarrantyForSendFormat(format.getFieldBatchRecord().getPlantSeason().getId(), transportType.getId(), transportSupplier.getId(), zone.getId(), plantTo.getId());
        if (ww == null) {
            return 2;
        }

        // THIS TRANSPORT SUPPLIER HAS NOT A COST TONE FOR THE GIVEN ZONE AND TRANSPORT TYPE
        CostTon ct = costTonDao.findCostTonForSendFormat(format.getFieldBatchRecord().getPlantSeason().getId(), transportType.getId(), transportSupplier.getId(), zone.getId(), plantTo.getId());
        if (ct == null) {
            return 3;
        }

        format.setLastUpdate(new Date());
        format.setWarantyWeight(ww);
        format.setCostTon(ct);
        SendFormat saved = sendFormatDao.saveOrUpdate(format);
        if (saved == null)
            return 4;
        else
            return 0;
    }

    @RemotingInclude
    public SendFormat findBySendFormat(String sendFormatFolio) throws Exception {
        return sendFormatDao.findBySendFormat(sendFormatFolio);
    }

    @RemotingInclude
    public Collection<SendFormat> findAllBySendFormatFolio(String sendFormatFolio) throws Exception {
        return sendFormatDao.findAllBySendFormatFolio(sendFormatFolio);
    }


    @RemotingInclude
    public Collection<SendFormat> findAllByPlant(long idPlantTo, long idSeason, long lot, String folio) throws Exception {
        return sendFormatDao.findByPlant(idPlantTo, idSeason, lot, folio);
    }

    @RemotingInclude
    public void email(String userid, FieldBatchRecord fbr, long idPlant) {
        EMailer eMailer = new EMailer(new HtmlEmailDocumentCreator());
        EMail eMail = null;
        String body = "<H1>Notificaci&oacute;n del sistema  MyControlSite</H1><br>" +
                "Esta es una notificaci&oacute;n de que el Lote de Campo descrito a continuaci&oacute;n fu&eacute; cosechado en su totalidad.<br><br>" +
                "Hibrido:<B>" + fbr.getHybrid().getName() + "</B><BR>" +
                "No. Lote:" + "<B>" + fbr.getLot() + "</B><BR>" +
                "Productor:<B>" + fbr.getGrower().getName() + "</B><BR>" +
                "Tabla:<B>" + fbr.getTableName() + "</B><BR>" +
                "Superficie (Has):" + fbr.getTotals() + "<BR><BR><BR>" +
                "Este es un mensaje generado autom&aacute;ticamente por el sistema, por favor no conteste este mensaje ya que es " +
                "para fines informativos<BR><BR><BR>";

        String subject = "MY CONTROL SITE - AVISO LOTE DE CAMPO COSECHADO COMPLETAMENTE";
        Collection<EmailTo> listTos = emailToDao.findAllByMailType("SENDFORMAT", idPlant);
        for (EmailTo record : listTos) {
            eMail = createEMail(userid + "@monsanto.com", record.getAddress(), subject, body);
            eMailer.send(eMail);
        }
    }


    private EMail createEMail(String fromUser, String toUser, String subject, String body) {
        EMail email = new EMail();
        email.setSubject(subject);
        email.setFrom(fromUser);
        email.addTo(toUser);
        email.addBodyLine(body);
        return email;
    }

    @RemotingInclude
    public int deleteSendFormat(SendFormat sendFormatFolio) throws Exception {
        int feedback = 0;
        if (scaleDao.findBySendFormat(sendFormatFolio.getSendFormatFolio()) != null) {
            return 1;
        } else if (rld.findBySendFormat(sendFormatFolio.getSendFormatFolio()) != null) {
            return 2;
        } else if (sld.findBySendFormat(sendFormatFolio.getSendFormatFolio()) != null) {
            return 3;
        } else {
            sendFormatDao.delete(sendFormatFolio);
        }
        return feedback;
    }

    @RemotingInclude
    public Collection<SendFormat> findAllByLot(long lot) throws Exception {
        return sendFormatDao.findAllByLot(lot);
    }


}
