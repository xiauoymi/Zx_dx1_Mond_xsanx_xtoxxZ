package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.Sheller;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:51:03 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ShellerService {
    void save(Sheller sheller);

    void update(Sheller sheller);

    void remove(Sheller sheller);

    Collection<Sheller> findByNameOrderedById(int idPlant, String name) throws Exception;

    Collection<Sheller> findAll() throws Exception;     
}
