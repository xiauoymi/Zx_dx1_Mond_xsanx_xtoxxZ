package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.ShellerDao;
import com.monsanto.mcs.model.hibernate.Sheller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:51:15 AM
 * To change this template use File | Settings | File Templates.
 */
@Service("shellerService")
@RemotingDestination
public class ShellerServiceImpl implements ShellerService{

    @Autowired
    private ShellerDao shellerDao = null;

    @RemotingInclude
    public Collection<Sheller> findByNameOrderedById(int idPlant, String name) throws Exception {
        Collection<Sheller> results = shellerDao.findByNameOrderedById(idPlant, name);
        return results;
    }

    @RemotingInclude
    public void remove(Sheller sheller) {
        shellerDao.delete(sheller);
    }

    @RemotingInclude
    public void save(Sheller sheller) {
        sheller.setLastUpdate(new Date());
        shellerDao.saveOrUpdate(sheller);
    }

    @RemotingInclude
    public void update(Sheller sheller) {
        sheller.setLastUpdate(new Date());
        shellerDao.saveOrUpdate(sheller);
    }

    @RemotingInclude
    public Collection<Sheller> findAll() throws Exception {
        Collection<Sheller> shellers = shellerDao.findAll();
        return shellers;
    }
    

}
