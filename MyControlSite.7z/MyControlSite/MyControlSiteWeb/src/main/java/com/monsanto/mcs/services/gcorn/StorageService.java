package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.Storage;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 8/02/2011
 * Time: 05:58:07 PM
 * To change this template use File | Settings | File Templates.
 */
public interface StorageService {
    void save(Storage storage);

    void update(Storage storage);

    void remove(Storage storage);

    Collection<Storage> findByNameOrderedById(int idPlant, String name) throws Exception;

    Collection<Storage> findAll() throws Exception;    
}
