package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.StorageDao;
import com.monsanto.mcs.model.hibernate.Storage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 8/02/2011
 * Time: 05:58:25 PM
 * To change this template use File | Settings | File Templates.
 */
@Service("storageService")
@RemotingDestination
public class StorageServiceImpl implements StorageService{

    @Autowired
    private StorageDao storageDao = null;


    @RemotingInclude
    public Collection<Storage> findByNameOrderedById(int idPlant, String name) throws Exception {
        Collection<Storage> results = storageDao.findByNameOrderedById(idPlant, name);
        return results;

    }

    @RemotingInclude
    public void remove(Storage storage) {
        storageDao.delete(storage);
    }

    @RemotingInclude
    public void save(Storage storage) {
        storageDao.saveOrUpdate(storage);
    }

    @RemotingInclude
    public void update(Storage storage) {
        storageDao.saveOrUpdate(storage);
    }

    @RemotingInclude
    public Collection<Storage> findAll() throws Exception {
        Collection<Storage> storages = storageDao.findAll();
        return storages;
    }

}
