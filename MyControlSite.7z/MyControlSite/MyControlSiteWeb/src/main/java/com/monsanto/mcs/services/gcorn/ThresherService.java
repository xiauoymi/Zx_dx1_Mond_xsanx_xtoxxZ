package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.model.hibernate.Thresher;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:51:03 AM
 * To change this template use File | Settings | File Templates.
 */
public interface ThresherService {
    void save(Thresher thresher);

    void update(Thresher thresher);

    void remove(Thresher thresher);

    Collection<Thresher> findByNumberOrderedById(int idPlant, String thresherNumber) throws Exception;

    Collection<Thresher> findAll() throws Exception;     
}
