package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.ThresherDao;
import com.monsanto.mcs.model.hibernate.Thresher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:51:15 AM
 * To change this template use File | Settings | File Templates.
 */
@Service("thresherService")
@RemotingDestination
public class ThresherServiceImpl implements ThresherService{

    @Autowired
    private ThresherDao thresherDao = null;

    @RemotingInclude
    public Collection<Thresher> findByNumberOrderedById(int idPlant, String thresherNumber) throws Exception {

        int value = 0;
        try {
           value = Integer.parseInt(thresherNumber);
        }
        catch(Exception e) {
            value = 0;
        }
        Collection<Thresher> results = thresherDao.findByNameOrderedById(idPlant, value);
        return results;

    }

    @RemotingInclude
    public void remove(Thresher thresher) {
        thresherDao.delete(thresher);
    }

    @RemotingInclude
    public void save(Thresher thresher) {
        thresher.setLastUpdate(new Date());
        thresherDao.saveOrUpdate(thresher);
    }

    @RemotingInclude
    public void update(Thresher thresher) {
        thresher.setLastUpdate(new Date());
        thresherDao.saveOrUpdate(thresher);
    }

    @RemotingInclude
    public Collection<Thresher> findAll() throws Exception {
        Collection<Thresher> threshers = thresherDao.findAll();
        return threshers;
    }
    

}
