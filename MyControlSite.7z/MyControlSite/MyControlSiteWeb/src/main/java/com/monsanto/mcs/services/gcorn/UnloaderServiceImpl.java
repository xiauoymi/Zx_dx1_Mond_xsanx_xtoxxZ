package com.monsanto.mcs.services.gcorn;

import com.monsanto.mcs.dao.UnloaderDao;
import com.monsanto.mcs.model.hibernate.Unloader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 22/03/2011
 * Time: 10:51:15 AM
 * To change this template use File | Settings | File Templates.
 */
@Service("unloaderService")
@RemotingDestination
public class UnloaderServiceImpl implements UnloaderService{

    @Autowired
    private UnloaderDao unloaderDao = null;

    @RemotingInclude
    public Collection<Unloader> findByNameOrderedById(int idPlant, String name) throws Exception {
        Collection<Unloader> results = unloaderDao.findByNameOrderedById(idPlant, name);
        return results;
    }

    @RemotingInclude
    public Collection<Unloader> findByNameOrderedByName(int idPlant, String name) throws Exception {
        Collection<Unloader> results = unloaderDao.findByNameOrderedByName(idPlant, name);
        return results;
    }

    @RemotingInclude
    public void remove(Unloader unloader) {
        unloaderDao.delete(unloader);
    }

    @RemotingInclude
    public void save(Unloader unloader) {
        unloader.setLastUpdate(new Date());
        unloaderDao.saveOrUpdate(unloader);
    }

    @RemotingInclude
    public void update(Unloader unloader) {
        unloader.setLastUpdate(new Date());
        unloaderDao.saveOrUpdate(unloader);
    }

    @RemotingInclude
    public Collection<Unloader> findAll() throws Exception {
        Collection<Unloader> unloaders = unloaderDao.findAll();
        return unloaders;
    }
    

}
