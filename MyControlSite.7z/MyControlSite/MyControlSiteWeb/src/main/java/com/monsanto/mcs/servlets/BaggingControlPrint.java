package com.monsanto.mcs.servlets;

import com.monsanto.mcs.model.hibernate.Plant;
import com.monsanto.mcs.services.admin.PlantService;
import com.monsanto.mcs.services.bagging.BaggingControlReportService;
import com.monsanto.mcs.services.dshelling.CellStatusReportService;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;

import com.monsanto.mcs.model.hibernate.Plant;
import com.monsanto.mcs.services.admin.PlantService;
import com.monsanto.mcs.services.dshelling.CellStatusReportService;

import java.util.Date;

public class BaggingControlPrint extends HttpServlet {

    private BaggingControlReportService service = null;

    private PlantService plantService = null;


     public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
     {
        res.setContentType("application/vnd.ms-excel");
        res.setHeader("Content-disposition",
                   "attachment; filename=" +
                   "BAGRPT.xls" );
        InputStream in = getServletContext().getResourceAsStream("/WEB-INF/BAGRPT.xls");

        ServletOutputStream  out = res.getOutputStream();

        String dateSelected = req.getParameter("date");
        int shift         = Integer.parseInt(req.getParameter("shift"));
        int plantId       = Integer.parseInt(req.getParameter("plantId"));
        long orderNumber  = Long.parseLong(req.getParameter("orderNumber"));
        int folioNumber   = Integer.parseInt(req.getParameter("folioNumber"));
        int plantSeasonId = Integer.parseInt(req.getParameter("plantSeasonId"));

        try{
           service = (BaggingControlReportService) getServletContext().getAttribute("BCR");
           service.createXls(out, in, plantId, dateSelected, shift, orderNumber, folioNumber, plantSeasonId);
        }catch(Exception e){
           e.printStackTrace();
        }
        return;
     }
}