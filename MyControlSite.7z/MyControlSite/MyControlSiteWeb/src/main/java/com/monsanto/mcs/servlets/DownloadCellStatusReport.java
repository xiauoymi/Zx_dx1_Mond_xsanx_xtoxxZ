package com.monsanto.mcs.servlets;

import com.monsanto.mcs.model.hibernate.Plant;
import com.monsanto.mcs.services.admin.PlantService;
import com.monsanto.mcs.services.dshelling.CellStatusReportService;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

public class DownloadCellStatusReport extends HttpServlet{

    private CellStatusReportService service = null;

    private PlantService plantService = null;

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
        res.setContentType("application/vnd.ms-excel");
        res.setHeader("Content-disposition",
                   "attachment; filename=" +
                   "DryingReport.xls" );
        ServletOutputStream  out = res.getOutputStream();
        int plantParam = Integer.valueOf(req.getParameter("plant"));
        try{
            plantService = (PlantService) getServletContext().getAttribute("plantService");
            Plant plant = plantService.findByPrimaryKey(plantParam);
            InputStream in = getServletContext().getResourceAsStream("/WEB-INF/"+plant.getAbbreviation()+"DryingReport.xls");
            if (plant.getAbbreviation().equals("VI")){
                service = (CellStatusReportService) getServletContext().getAttribute("CellStatusReport");
            }else if (plant.getAbbreviation().equals("NEX")){
                service = (CellStatusReportService) getServletContext().getAttribute("CellStatusReportNX");
            }else if (plant.getAbbreviation().equals("LM")){
                service = (CellStatusReportService) getServletContext().getAttribute("CellStatusReportMO");
            }
            service.createXls(out,in,plantParam);
        }catch(Exception e){
           e.printStackTrace();
        }
        return;
    }

}
