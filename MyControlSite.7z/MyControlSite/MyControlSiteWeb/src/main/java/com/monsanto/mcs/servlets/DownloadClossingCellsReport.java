package com.monsanto.mcs.servlets;

import com.monsanto.mcs.services.dshelling.ClosingCellReportService;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;

public class DownloadClossingCellsReport extends HttpServlet{

     private ClosingCellReportService service = null;

     public void doGet(HttpServletRequest req, HttpServletResponse res)
       throws ServletException, IOException
     {
        res.setContentType("application/vnd.ms-excel");
        res.setHeader("Content-disposition",
                   "attachment; filename=" +
                   "RE-SE-PP-03.xls" );
        ServletOutputStream  out = res.getOutputStream();
        InputStream in = getServletContext().getResourceAsStream("/WEB-INF/RE-SE-PP-03.xls");
        int plantSeasonParam = Integer.valueOf(req.getParameter("plantSeason"));
        int cellParam = Integer.valueOf(req.getParameter("cell"));
        int closingCellIdParam = Integer.valueOf(req.getParameter("closingCellLog"));
        try{
           service = (ClosingCellReportService) getServletContext().getAttribute("ClossingCellsReport");
           service.createXls(in,out,plantSeasonParam,cellParam,closingCellIdParam);
        }catch(Exception e){
           e.printStackTrace();
        }
        return;
     }

}
