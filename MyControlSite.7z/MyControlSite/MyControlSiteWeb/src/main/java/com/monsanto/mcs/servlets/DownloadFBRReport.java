package com.monsanto.mcs.servlets;

import com.monsanto.mcs.services.preports.FBRProvisionalReportService;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class DownloadFBRReport extends HttpServlet{

    private FBRProvisionalReportService service = null;

     public void doGet(HttpServletRequest req, HttpServletResponse res)
       throws ServletException, IOException
     {
        res.setContentType("application/vnd.ms-excel");
        res.setHeader("Content-disposition",
                   "attachment; filename=" +
                   "FBRProvisionalReport.xls" );
        ServletOutputStream  out = res.getOutputStream();
        try{
           service = (FBRProvisionalReportService) getServletContext().getAttribute("FBRPR");
           Integer plantSeasonId = Integer.parseInt(req.getParameter("plantSeasonId"));
           service.createXls(out,plantSeasonId);
        }catch(Exception e){
           e.printStackTrace();
        }
        return;
     }
}
