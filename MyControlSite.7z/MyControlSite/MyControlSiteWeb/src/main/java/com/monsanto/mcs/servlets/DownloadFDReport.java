package com.monsanto.mcs.servlets;

import com.monsanto.mcs.services.preports.FDProvisionalReportService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

public class DownloadFDReport extends HttpServlet{

    public void doGet(HttpServletRequest request, HttpServletResponse response)
       throws ServletException, IOException
     {
        Integer plantSeasonId = Integer.parseInt(request.getParameter("plantSeasonId"));

        FDProvisionalReportService service = (FDProvisionalReportService) getServletContext().getAttribute("FDPR");
         try {
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-disposition", "attachment; filename=FDProvisionalReport.xls");
            service.createXls(response.getOutputStream(), plantSeasonId);
         } catch (Exception exception) {
            Writer result = new StringWriter();
            PrintWriter printWriter = new PrintWriter(result);
            exception.printStackTrace(printWriter);
            response.reset();
            response.sendError(500, "<PRE>" + result.toString() + "</PRE>");
         }
     }
}
