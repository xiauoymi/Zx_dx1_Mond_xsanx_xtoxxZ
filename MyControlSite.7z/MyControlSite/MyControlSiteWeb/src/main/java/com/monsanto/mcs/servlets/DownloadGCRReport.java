package com.monsanto.mcs.servlets;

import com.monsanto.mcs.services.gcorn.GCRReportService;

import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;

public class DownloadGCRReport extends HttpServlet{

    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException{
        res.setContentType("application/vnd.ms-excel");
        res.setHeader("Content-disposition",
                   "attachment; filename=" +
                   "GCR.xls" );
        ServletOutputStream  out = res.getOutputStream();
        int plantParam = Integer.valueOf(req.getParameter("plant"));
        int seasonParam = Integer.valueOf(req.getParameter("season"));
        try{
            GCRReportService service = (GCRReportService) getServletContext().getAttribute("GCRRS");
            InputStream in = getServletContext().getResourceAsStream("/WEB-INF/BlankReleaseByHibrid.xls");
            service.createXls(in,out,plantParam,seasonParam);
        }catch(Exception e){
           e.printStackTrace();
        }
        return;
    }

}
