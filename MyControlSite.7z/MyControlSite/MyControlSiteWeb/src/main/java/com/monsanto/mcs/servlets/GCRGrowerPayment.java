package com.monsanto.mcs.servlets;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 2/06/2011
 * Time: 04:46:41 PM
 * To change this template use File | Settings | File Templates.
 */
import com.monsanto.mcs.services.plantq.GCRGrowerPaymentReportService;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;


public class GCRGrowerPayment  extends HttpServlet {

    private GCRGrowerPaymentReportService service = null;

     public void doGet(HttpServletRequest req, HttpServletResponse res)
       throws ServletException, IOException
     {
        res.setContentType("application/vnd.ms-excel");
        res.setHeader("Content-disposition",
                   "attachment; filename=" +
                   "RE-SE-QL-24.xls" );
        InputStream in = getServletContext().getResourceAsStream("/WEB-INF/RE-SE-QL-24.xls");
        ServletOutputStream  out = res.getOutputStream();
        String folio  = req.getParameter("folio");
        int  plantTo  = new Integer(req.getParameter("plantTo")).intValue();
        int  seasonId = new Integer(req.getParameter("seasonId")).intValue();
        try{
           service = (GCRGrowerPaymentReportService) getServletContext().getAttribute("GCRGP");
           service.createXls(out, in, plantTo, seasonId, folio);
        }catch(Exception e){
           e.printStackTrace();
        }
        return;
     }

}
