package com.monsanto.mcs.servlets;

import com.monsanto.mcs.services.plantq.GrowerPaymentReportService;

import javax.servlet.http.HttpServlet;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 29/06/2011
 * Time: 11:57:25 AM
 * To change this template use File | Settings | File Templates.
 */

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class GrowerPaymentReport extends HttpServlet {

    private GrowerPaymentReportService service = null;

     public void doGet(HttpServletRequest req, HttpServletResponse res)
       throws ServletException, IOException
     {
        res.setContentType("application/vnd.ms-excel");
        res.setHeader("Content-disposition",
                   "attachment; filename=" +
                   "GrowerPaymentReport.xls" );
        InputStream in = getServletContext().getResourceAsStream("/WEB-INF/GrowerPaymentReport.xls");
        ServletOutputStream  out = res.getOutputStream();
        long lot      = new Long(req.getParameter("lot")).longValue();
        int  seasonId = new Integer(req.getParameter("seasonId")).intValue();
        try{
           service = (GrowerPaymentReportService) getServletContext().getAttribute("GPR");
           service.createXls(out, in, seasonId, lot);
        }catch(Exception e){
           e.printStackTrace();
        }
        return;
     }


}
