package com.monsanto.mcs.servlets;

import com.monsanto.mcs.services.plantq.KPIReportService;

import javax.servlet.http.HttpServlet;

/**
 * Created by IntelliJ IDEA.
 * User: AROJAS5
 * Date: 29/06/2011
 * Time: 11:57:25 AM
 * To change this template use File | Settings | File Templates.
 */

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class KPIReport extends HttpServlet {

    private KPIReportService service = null;

    public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException{
        res.setContentType("application/vnd.ms-excel");
        res.setHeader("Content-disposition",
                   "attachment; filename=" +
                   "KPIReport.xls" );
        InputStream in = getServletContext().getResourceAsStream("/WEB-INF/KPIReport.xls");
        ServletOutputStream  out = res.getOutputStream();
        String year   = req.getParameter("year");
        int plant     = Integer.parseInt(req.getParameter("plant"));
        int season    = Integer.parseInt(req.getParameter("season"));
        int plantSeasonId = Integer.parseInt(req.getParameter("plantSeasonId"));
        try{
           service = (KPIReportService) getServletContext().getAttribute("KPIReport");
           service.createXls(in,out,plant,season,year,plantSeasonId);
        }catch(Exception e){
           e.printStackTrace();
        }
        return;
     }

}
