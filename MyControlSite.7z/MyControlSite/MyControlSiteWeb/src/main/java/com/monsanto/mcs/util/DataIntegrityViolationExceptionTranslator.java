package com.monsanto.mcs.util;

import flex.messaging.MessageException;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.flex.core.ExceptionTranslator;

import java.util.List;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 5/11/12
 * Time: 10:09 PM
 */
public class DataIntegrityViolationExceptionTranslator implements ExceptionTranslator {

    private String defaultErrorCode;

    private List<ExceptionCodeResolver> exceptionCodeResolvers;

    public boolean handles(Class<?> clazz) {
        return DataIntegrityViolationException.class.isAssignableFrom( clazz );
    }

    public MessageException translate(Throwable throwable) {
        MessageException messageException = new MessageException();
        StringBuilder    errorCode = new StringBuilder( defaultErrorCode );

        messageException.setStackTrace( throwable.getStackTrace() );
        messageException.setMessage(throwable.getMessage());
        messageException.setRootCause(throwable);
        messageException.setDetails(throwable.getMessage());

        for ( ExceptionCodeResolver resolver : exceptionCodeResolvers ){

            if( resolver.canBeResolved( throwable ) ){

                errorCode.append( '.' ).append( resolver.resolveCode( throwable ) );
                break;
            }
        }
        messageException.setCode( errorCode.toString() );

        return messageException;
    }

    @Required
    public void setExceptionCodeResolvers(List<ExceptionCodeResolver> exceptionCodeResolvers) {
        this.exceptionCodeResolvers = exceptionCodeResolvers;
    }

    @Required
    public void setDefaultErrorCode(String defaultErrorCode) {
        this.defaultErrorCode = defaultErrorCode;
    }
}
