package com.monsanto.mcs.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateTime {

    private static final String AM = "AM";
    private static final String PM = "PM";
    private static final String DATE_FORMAT = "dd/MM/yyyy";

    private Date date;
    private int hour;
    private int minute;
    private String amPm;

    public String getAmPm() {
        return amPm;
    }

    public void setAmPm(int amPm) {
        if (amPm == Calendar.AM)
            this.amPm = DateTime.AM;
        else
            this.amPm = DateTime.PM;
    }

    public String getDate() {
        DateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
        return formatter.format(this.date);
    }

    public Date getDateTime() {
        Calendar calendar = GregorianCalendar.getInstance();
        calendar.setTime(this.date);
        calendar.set(Calendar.HOUR,this.hour);
        calendar.set(Calendar.MINUTE,this.minute);
        return calendar.getTime();
    }

    private Date parseDate(String date) throws ParseException {
        DateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
        return formatter.parse(date);
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setDate(String date) throws ParseException {
        this.date = parseDate(date);
    }

    public int getHour() {
        return hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int getMinute() {
        return minute;
    }

    public void setMinute(int minute) {
        this.minute = minute;
    }

    public String toString(){
        return   this.getDate() + " " + this.getHour() + ":" + this.getMinute() + " " + this.getAmPm();
    }

}
