package com.monsanto.mcs.util;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 6/11/12
 * Time: 06:29 PM
 */
public interface ExceptionCodeResolver {

    /**
     * returns true if the throwable can be resolved to an appropiate message code
     * @param throwable
     * @return
     */
    boolean canBeResolved( Throwable throwable );

    /**
     * Resolves the appropiate message code based on the exception data
     *
     * Always should be called after canBeResolved()
     *
     * @param throwable
     * @return
     */
    String resolveCode( Throwable throwable );
}
