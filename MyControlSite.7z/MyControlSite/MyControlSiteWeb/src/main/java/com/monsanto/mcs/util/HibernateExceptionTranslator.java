package com.monsanto.mcs.util;

import org.hibernate.JDBCException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.support.SQLErrorCodeSQLExceptionTranslator;

import javax.sql.DataSource;
import java.sql.SQLException;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 6/11/12
 * Time: 09:24 PM
 */
public class HibernateExceptionTranslator extends SQLErrorCodeSQLExceptionTranslator{

    public HibernateExceptionTranslator(DataSource dataSource) {
        super( dataSource );
    }

    @Override
    public DataAccessException translate(String task, String sql, SQLException sqle) throws RuntimeException {
        DataAccessException dae = super.translate( task, sql, sqle );
        // para las data integrity violation preservamos el SQL que originó la falla para poder mandar mensajes amigables
        if( dae instanceof DataIntegrityViolationException ){
            return new DataIntegrityViolationException( dae.getMessage(), new JDBCException( task + sqle.getMessage(), sqle, sql ) );
        }
        return dae;
    }
}
