package com.monsanto.mcs.util;

import org.hibernate.JDBCException;
import org.springframework.beans.factory.annotation.Required;

import java.text.MessageFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Monsanto
 * Author: Luis Miguel Arteaga Rios (lmarte@monsanto.com)
 * Date: 6/11/12
 * Time: 06:39 PM
 */
public class JDBCErrorCodeResolver implements ExceptionCodeResolver{

    private Pattern sqlPattern;
    private int     tablenameGroup;
    private String  codeFormat;

    public boolean canBeResolved(Throwable throwable) {

        JDBCException jdbce = lookupJDBCException(throwable);

        if( jdbce != null ){

            String sql = jdbce.getSQL();

            return ( sql != null ) && sqlPattern.matcher( sql ).matches();
        }
        return false;
    }

    public String resolveCode(Throwable throwable) {

        JDBCException jdbce   = lookupJDBCException(throwable);
        Matcher       matcher = sqlPattern.matcher( jdbce.getSQL() );

        matcher.find();

        return MessageFormat.format( codeFormat, matcher.group( tablenameGroup ) );
    }

    private static JDBCException lookupJDBCException( Throwable exception ) {

        if( JDBCException.class.isInstance( exception ) ){

            return (JDBCException) exception;
        }
        else if( exception != null ){

            return lookupJDBCException(exception.getCause());
        }
        return null;
    }

    @Required
    public void setSqlPatternStr(String sqlPatternStr) {
        this.sqlPattern = Pattern.compile( sqlPatternStr );
    }

    @Required
    public void setTablenameGroup(int tablenameGroup) {
        this.tablenameGroup = tablenameGroup;
    }

    @Required
    public void setCodeFormat(String codeFormat) {
        this.codeFormat = codeFormat;
    }
}
