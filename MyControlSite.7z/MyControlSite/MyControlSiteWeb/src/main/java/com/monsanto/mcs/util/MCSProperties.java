package com.monsanto.mcs.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.ResourceBundle;

@Service("mcsConfigurationService")
@RemotingDestination
public class MCSProperties {

    @Autowired
    private Schema schema;

    private static MCSProperties instance = new MCSProperties();
    public static final String CONFIG_FILE_NAME = "mcs";

    private MCSProperties() {

    }

    public static MCSProperties getInstance() {
        return instance;
    }

    @RemotingInclude
    public static String getVersion() {
        String version = "To be defined";
        try {
            ResourceBundle mcsProperties = ResourceBundle.getBundle(CONFIG_FILE_NAME);
            version = mcsProperties.getString("version");
        } catch (Exception e) {
            version = e.getMessage();
        }
        return version;
    }

    @RemotingInclude
    public static String getReleaseDate() {
        String releaseDate = "To be defined";
        try {
            ResourceBundle mcsProperties = ResourceBundle.getBundle(CONFIG_FILE_NAME);
            releaseDate = mcsProperties.getString("releaseDate");
        } catch (Exception e) {
            releaseDate = e.getMessage();
        }
        return releaseDate;
    }

    @RemotingInclude
    public String setDefaultSchema() {
        String defaultSchema = SchemaEnum.LEGACY.toString();
        schema.setName(defaultSchema);
        return defaultSchema;
    }

    @RemotingInclude
    public void changeSchema(String newSchema) {
        schema.setName(newSchema);
    }

    @RemotingInclude
    public static Collection<Company> getCompanies() {
        Collection<Company> companies = new ArrayList<Company>();
        companies.add(new Company(SchemaEnum.LEGACY.toString()));
        companies.add(new Company(SchemaEnum.HISTORICAL.toString()));
        return companies;
    }

}
