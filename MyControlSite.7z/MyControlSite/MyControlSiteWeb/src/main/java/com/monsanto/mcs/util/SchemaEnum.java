package com.monsanto.mcs.util;

public enum SchemaEnum {

    LEGACY {
        public String toString() {
            return "GRAIN";
        }
    },

    HISTORICAL {
        public String toString() {
            return "SAMSA";
        }
    }
}
