package com.monsanto.prisma.core.domain;

/**
 * Account for each enviroment.
 */
public class ApplicationAccount {

    private String name;
    private String password;
    private String domain;

    public ApplicationAccount(String domain, String name, String password) {
        this.name = name;
        this.password = password;
        this.domain = domain;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDomain() {
        return domain;
    }
}
