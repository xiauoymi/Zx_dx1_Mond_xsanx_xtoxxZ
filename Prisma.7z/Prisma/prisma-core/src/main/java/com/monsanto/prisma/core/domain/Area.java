package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by PGSETT on 15/05/2014.
 */
@Entity
@Table(name = "AREA")
public class Area implements Serializable {

    @Id
    @Column(name = "AREA_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_AREA")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "NAME")
    private String name;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
