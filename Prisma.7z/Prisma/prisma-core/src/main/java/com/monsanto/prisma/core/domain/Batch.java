package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by BSBUON on 21/07/2014.
 */
@Entity
@Table(name = "BATCH")
public class Batch implements IBatch {

    @Id
    @Column(name = "BATCH_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_BATCH")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "NAME", unique = true, nullable = false)
    private String name;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CAMPAIGN_ID")
    private Campaign campaign;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "HYBRID_ID")
    private Hybrid hybrid;

    @Column(name = "KG_DS")
    private Float kgDS;

    @Column(name = "KG_FNG")
    private Float kgFNG;

    @Column(name = "BAG_PRODUCED")
    private Integer bagProduced;

    @Column(name = "ACTUAL_KG_FNG")
    private Float actualKgFNG;

    @Column(name = "ACTUAL_KG_BAG")
    private Float actualKgBag;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "pk.batch")
    private List<LotBatch> lotBatches = new LinkedList<LotBatch>();

    @Column(name = "REAL_FNG_INIT")
    private Date realFngInit;

    @Column(name = "REAL_FNG_END")
    private Date realFngEnd;

    @Column(name = "TOTAL_KG_CULL_TOWER")
    private Float totalKgCullTower;

    public Float getTotalKgCullTower() {
        return totalKgCullTower;
    }

    public void setTotalKgCullTower(Float totalKgCullTower) {
        this.totalKgCullTower = totalKgCullTower;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public Hybrid getHybrid() {
        return hybrid;
    }

    public void setHybrid(Hybrid hybrid) {
        this.hybrid = hybrid;
    }

    public Float getKgDS() {
        return kgDS;
    }

    public void setKgDS(Float kgDS) {
        this.kgDS = kgDS;
    }

    public Float getKgFNG() {
        return kgFNG;
    }

    public void setKgFNG(Float kgFNG) {
        this.kgFNG = kgFNG;
    }

    public Integer getBagProduced() {
        return bagProduced;
    }

    public void setBagProduced(Integer bagProduced) {
        this.bagProduced = bagProduced;
    }

    public Float getActualKgFNG() {
        return actualKgFNG;
    }

    public void setActualKgFNG(Float actualKgFNG) {
        this.actualKgFNG = actualKgFNG;
    }

    public Float getActualKgBag() {
        return actualKgBag;
    }

    public void setActualKgBag(Float actualKgBag) {
        this.actualKgBag = actualKgBag;
    }

    public List<LotBatch> getLotBatches() {
        return lotBatches;
    }

    public void setLotBatches(List<LotBatch> lotBatches) {
        this.lotBatches = lotBatches;
    }

    public Date getRealFngInit() {
        return realFngInit;
    }

    public void setRealFngInit(Date realFngInit) {
        this.realFngInit = realFngInit;
    }

    public Date getRealFngEnd() {
        return realFngEnd;
    }

    public void setRealFngEnd(Date realFngEnd) {
        this.realFngEnd = realFngEnd;
    }

    public LotBatch containsLot(String lotCode) {
        for (LotBatch lotBatch : this.getLotBatches()) {
            if (lotBatch.containsLot(lotCode)) {
                return lotBatch;
            }
        }
        return null;
    }


    @Override
    public List<Integer> getAssociatedLotIds() {
        List<Integer> result = new LinkedList<Integer>();
        for (LotBatch lotBatch : lotBatches) {
            result.add(lotBatch.getLot().getId());
        }
        return result;
    }


}
