package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.exception.CampaignException;
import com.monsanto.prisma.core.exception.CampaignUnableToChangeException;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Campaign Entity, core object of the application.
 */
@Entity
@Table(name = "CAMPAIGN")
public class Campaign implements Serializable {

    @Id
    @Column(name = "CAMPAIGN_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_CAMPAIGN")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CROP_ID")
    private Crop crop;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "SEASON_ID")
    private Season season;

    @Column(name = "CODE")
    private String code;

    @Column(name = "NAME")
    private String name;

    @Column(name = "IS_ACTIVE")
    private Boolean isActive;

    @Column(name = "IS_REAL")
    private Boolean isReal;

    @Column(name = "FILE_PATH")
    private String filePath;

    @Column(name = "OBSERVATIONS")
    private String observations;

    @Column(name = "IS_DELETED")
    private Boolean isDeleted;

    public Campaign() {

    }

    public Campaign(String name, String code, Boolean isActive, Boolean isReal, String filePath, String observations) {
        this.name = name;
        this.code = code;
        this.isActive = isActive;
        this.isReal = isReal;
        this.filePath = filePath;
        this.observations = observations;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Boolean getIsReal() {
        return isReal;
    }

    public void setIsReal(Boolean isReal) {
        this.isReal = isReal;
    }

    public Season getSeason() {
        return season;
    }

    public void setSeason(Season season) {
        this.season = season;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }

    public Boolean getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public void validateUpdate(Campaign toChange) throws CampaignException {
        if(!this.getCrop().equals(toChange.getCrop())) throw new CampaignUnableToChangeException();
        if(!this.getSeason().equals(toChange.getSeason())) throw new CampaignUnableToChangeException();
        if(!this.getCode().equals(toChange.getCode())) throw new CampaignUnableToChangeException();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Campaign campaign = (Campaign) o;

        if (id != null ? !id.equals(campaign.id) : campaign.id != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
