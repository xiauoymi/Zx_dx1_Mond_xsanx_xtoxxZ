package com.monsanto.prisma.core.domain;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 08/05/14
 * Time: 12:05
 * To change this template use File | Settings | File Templates.
 */
public enum CampaignState {
    CREATE(1),
    DELETE(2);

    private Integer state;

    CampaignState(Integer state){
        this.state = state;
    }

    public Integer getState(){
        return this.state;
    }
}
