package com.monsanto.prisma.core.domain;

/**
 * Types of Campaigns (Real, fictional)
 */
public enum CampaignType {
    REAL,
    FICTIONAL
}
