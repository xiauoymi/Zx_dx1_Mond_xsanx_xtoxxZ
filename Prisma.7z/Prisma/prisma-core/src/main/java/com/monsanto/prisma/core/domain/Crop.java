package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Crop Entity
 */
@Entity
@Table(name = "CROP")
public class Crop implements Serializable {

    @Id
    @Column(name = "CROP_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_CROP")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "WORKFLOW_NAME")
    private String workFlowName;

    public Crop() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWorkFlowName() {
        return workFlowName;
    }

    public void setWorkFlowName(String workFlowName) {
        this.workFlowName = workFlowName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Crop crop = (Crop) o;

        if (id != null ? !id.equals(crop.id) : crop.id != null) return false;
        if (name != null ? !name.equals(crop.name) : crop.name != null) return false;
        if (!workFlowName.equals(crop.workFlowName)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + workFlowName.hashCode();
        return result;
    }
}
