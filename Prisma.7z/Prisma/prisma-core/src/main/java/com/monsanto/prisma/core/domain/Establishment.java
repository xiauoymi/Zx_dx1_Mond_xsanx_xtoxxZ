package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by PGSETT on 15/05/2014.
 */
@Entity
@Table(name = "ESTABLISHMENT")
public class Establishment implements Serializable {

    @Id
    @Column(name = "ESTABLISHMENT_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_ESTABLISHMENT")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "NAME")
    private String name;

    @OneToOne
    @JoinColumn(name = "ZONE_ID")
    private Zone zone;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Zone getZone() {
        return zone;
    }

    public void setZone(Zone zone) {
        this.zone = zone;
    }
}
