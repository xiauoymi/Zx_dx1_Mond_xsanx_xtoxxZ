package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.FilterDTO;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * Created by EPESTE on 22/05/2014.
 */
@Entity
@Table(name = "FILTER")
public class Filter implements Serializable {
    @Id
    @Column(name = "FILTER_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_FILTER")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generate_seq")
    private Integer idFilter;

    @Column(name = "LOT_FILTER_ID")
    private Integer field;

    private String value;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_FILTER_ID")
    private UserFilter userFilter;

    public Filter() {
    }

    public Filter(FilterDTO filterDTO) {
        setField(filterDTO.getField());
        setValue(filterDTO.getValue());
    }

    public Integer getIdFilter() {
        return idFilter;
    }

    public void setIdFilter(Integer idFilter) {
        this.idFilter = idFilter;
    }

    public Integer getField() {
        return field;
    }

    public void setField(Integer field) {
        this.field = field;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public UserFilter getUserFilter() {
        return userFilter;
    }

    public void setUserFilter(UserFilter userFilter) {
        this.userFilter = userFilter;
    }
}
