package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.dto.ForecastDTO;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by EPESTE on 04/12/2014.
 */
@Entity
@Table(name = "FORECAST")
public class Forecast implements Serializable {
    @Id
    @Column(name = "FORECAST_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_FORECAST")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generate_seq")
    private Integer id;

    @Column(name = "CAMPAIGN_ID")
    private Integer campaignId;

    @Column(name = "DAYS_RW")
    private Integer daysRw;

    @Column(name = "DAYS_DS")
    private Integer daysDs;

    public Forecast() {
    }

    public Forecast(Integer campaignId) {
        this.campaignId = campaignId;
        this.daysRw = 1;
        this.daysDs = 4;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public Integer getDaysRw() {
        return daysRw;
    }

    public void setDaysRw(Integer daysRw) {
        this.daysRw = daysRw;
    }

    public Integer getDaysDs() {
        return daysDs;
    }

    public void setDaysDs(Integer daysDs) {
        this.daysDs = daysDs;
    }

    public void update(ForecastDTO forecastDTO) {
        this.daysRw = forecastDTO.getDaysRw();
        this.daysDs = forecastDTO.getDaysDs();
    }
}
