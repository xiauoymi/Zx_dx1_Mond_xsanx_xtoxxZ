package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by PGSETT on 26/06/2014.
 */
@Entity
@Table(name = "HUMIDITY_RANGE")
public class HumidityRange implements Serializable {

    @Id
    @Column(name = "HUMIDITY_RANGE_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_HUMIDITY_RANGE")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "HUMIDITY_MIN")
    private Double humidityMin;

    @Column(name = "HUMIDITY_MAX")
    private Double humidityMax;

    @OneToOne
    @JoinColumn(name = "HYBRID_ID")
    private Hybrid hybrid;

    @OneToOne
    @JoinColumn(name = "ZONE_ID")
    private Zone zone;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getHumidityMin() {
        return humidityMin;
    }

    public void setHumidityMin(Double humidityMin) {
        this.humidityMin = humidityMin;
    }

    public Double getHumidityMax() {
        return humidityMax;
    }

    public void setHumidityMax(Double humidityMax) {
        this.humidityMax = humidityMax;
    }

    public Hybrid getHybrid() {
        return hybrid;
    }

    public void setHybrid(Hybrid hybrid) {
        this.hybrid = hybrid;
    }

    public Zone getZone() {
        return zone;
    }

    public void setZone(Zone zone) {
        this.zone = zone;
    }
}
