package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by EPESTE on 21/08/2014.
 */

@Entity
@Table(name = "HUMIDITY_REPORT")
public class HumidityReport implements Serializable {
    @Id
    @Column(name = "HUM_REPORT_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_HUM_REPORT")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "CAMPAIGN_ID")
    private Integer campaignId;

    @Column(name = "PATH_FILE")
    private String pathFile;

    @Column(name = "DATE_PROCCESS")
    private Date dateProccess;

    @Column(name = "MODIFIED")
    private int modified;

    @Column(name = "OMITTED")
    private int omitted;

    public void addOmitted(){
        this.omitted++;
    }

    public void addModified(){
        this.modified++;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public String getPathFile() {
        return pathFile;
    }

    public void setPathFile(String pathFile) {
        this.pathFile = pathFile;
    }

    public Date getDateProccess() {
        return dateProccess;
    }

    public void setDateProccess(Date dateProccess) {
        this.dateProccess = dateProccess;
    }

    public int getModified() {
        return modified;
    }

    public void setModified(int modified) {
        this.modified = modified;
    }

    public int getOmitted() {
        return omitted;
    }

    public void setOmitted(int omitted) {
        this.omitted = omitted;
    }
}
