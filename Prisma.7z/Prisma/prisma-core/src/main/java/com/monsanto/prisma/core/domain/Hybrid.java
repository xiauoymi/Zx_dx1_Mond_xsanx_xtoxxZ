package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by PGSETT on 15/05/2014.
 */
@Entity
@Table(name = "HYBRID")
public class Hybrid implements Serializable {

    @Id
    @Column(name = "HYBRID_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_HIBRID")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "NAME")
    private String name;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HYBRID_TYPE_ID")
    private HybridType hybridType;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CROP_ID")
    private Crop crop;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public HybridType getHybridType() {
        return hybridType;
    }

    public void setHybridType(HybridType hybridType) {
        this.hybridType = hybridType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }
}
