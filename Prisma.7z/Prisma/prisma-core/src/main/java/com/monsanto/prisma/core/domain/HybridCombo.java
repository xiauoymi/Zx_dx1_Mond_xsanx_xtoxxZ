package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by BSBUON on 22/09/2014.
 */
@Entity
@Table(name = "HYBRID")
public class HybridCombo implements Serializable{

    @Id
    @Column(name = "HYBRID_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_HIBRID")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "NAME")
    private String name;

    public HybridCombo(){

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
