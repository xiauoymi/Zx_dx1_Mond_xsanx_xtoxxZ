package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by PGSETT on 15/05/2014.
 */
@Entity
@Table(name = "HYBRID_TYPE")
public class HybridType implements Serializable {

    @Id
    @Column(name = "HYBRID_TYPE_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_HIBRIP_TYPE")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "NAME")
    private String name;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
