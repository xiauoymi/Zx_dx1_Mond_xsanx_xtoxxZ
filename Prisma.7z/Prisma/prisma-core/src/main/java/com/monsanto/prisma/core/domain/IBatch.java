package com.monsanto.prisma.core.domain;

import java.io.Serializable;
import java.util.List;

/**
 * Created by BSBUON on 01/08/2014.
 */
public interface IBatch extends Serializable{

    public List<Integer> getAssociatedLotIds();
}
