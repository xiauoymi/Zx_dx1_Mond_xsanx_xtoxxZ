package com.monsanto.prisma.core.domain;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 08/05/14
 * Time: 12:09
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(name = "LOT")
public class Lot implements Serializable {

    @Id
    @Column(name = "LOT_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_LOT")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generate_seq")
    private Integer id;

    @Column(name = "LOT_CODE")
    private String lotCode;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ESTABLISHMENT_ID")
    private Establishment establishment;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HYBRID_ID")
    private Hybrid hybrid;
    @Column(name = "REGISTERED_HAS")
    private Float registeredHas;
    @Column(name = "HARVESTABLE_HAS")
    private Float harvestableHas;
    @Column(name = "CERTIFICATION")
    private String certification;
    @Column(name = "EXPEDIENTE")
    private String expediente;
    @Column(name = "PROGRAM")
    private String program;
    @Column(name = "COLOR")
    private String color;
    @Column(name = "PLANTING_WEEK")
    private Integer plantingWeek;
    @Column(name = "SOURCE_LOT_FILE")
    private String sourceLotFile;
    @Column(name = "SOURCE_MASTER_FILE")
    private String sourceMasterfile;
    @Column(name = "IS_REPLACED")
    private Boolean isReplaced;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "USER_ID")
    private User user;

    @Column(name = "TARGET_KG_BAG")
    private Float targetKgBag;

    @Column(name = "TARGET_RW_TO_DS")
    private Float targetRwToDs;

    @Column(name = "TARGET_DS_TO_FNG")
    private Float targetDsToFng;

    @Column(name = "TARGET_BAG_HA")
    private Float targetBagHa;

    @Column(name = "TARGET_BAG_LOT")
    private Float targetBagLot;

    @Column(name = "DIAS_FLOR_COS")
    private Float diasFlorCos;
    @Column(name = "ESTIMATED_HARVEST_DATE")
    private Date estimatedHarvestDate;
    @Column(name = "TARGET_TN_RW_LOT")
    private Float targetTnRwLot;
    @Column(name = "TARGET_TN_DS_LOT")
    private Float targetTnDsLot;
    @Column(name = "TARGET_KGS_DS_HA")
    private Float targetKgsDsHa;
    @Column(name = "POR_ACTUAL_OBJ_TAR_DS")
    private Float porcActualObjetiveTargetDs;
    @Column(name = "HARV_KG_FNG_EST_LOT_RW")
    private Float harvKgFngEstLotRw;
    @Column(name = "ACTUAL_TN_DS_LOT")
    private Float actualTnDsLot;
    @Column(name = "ACTUAL_TN_FNG_LOT")
    private Float actualTnFngLot;
    @Column(name = "EFICIENCIA_EST_UN_FIELD")
    private Float eficienciaEstUnField;
    @Column(name = "HARV_KG_DS_LOT_EST_RW")
    private Float harvKgDsLotEstRw;
    @Column(name = "HARV_KG_DS_HA_EST_RW")
    private Float harvKgDsHaEstRw;
    @Column(name = "ACTUAL_TN_RW_LOT")
    private Float actualTnRwLot;
    @Column(name = "TARGET_LOT")
    private Float targetLot;
    @Column(name = "POR_ACT_OBJ_UN_TAR")
    private Float porcentActualObjectiveUnTarget;
    @Column(name = "ESTIMATED_PLANTING_DATE")
    private Date estimatedPlantingDate;
    @Column(name = "REAL_PLANTING_DATE")
    private Date realPlantingDate;
    @Column(name = "GDU")
    private Integer gdu;
    @Column(name = "ESTIMATED_FLOWERING_DATE")
    private Date estimatedFloweringDate;
    @Column(name = "HARVEST_DATE_FOR_HUMIDITY")
    private Date harvestDateForHumidity;
    @Column(name = "RW")
    private Integer rw;
    @Column(name = "OBSERVATION")
    private String observation;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "CAMPAIGN_ID")
    private Campaign campaign;
    @Column(name = "REAL_FLOWERING_DATE")
    private Date realFloweringDate;
    @Column(name = "REAL_HARVEST_DATE")
    private Date realHarvestDate;
    @Column(name = "FLOWERING_DATE")
    private Date floweringDate;
    @Column(name = "HARVEST_DATE")
    private Date harvestDate;
    @Column(name = "HARVEST_WEEK")
    private Float harvestWeek;
    @Column(name = "ESTIMATED_KG_DS_HA")
    private Float estimatedKgDsHa;
    @Column(name = "OBS_ESTIMATED_KG_DS_HA")
    private String obsEstimatedKgDsHa;
    @Column(name = "STATE")
    private Boolean state;
    @Column(name = "ACTUAL_KG_DS_HA")
    private Float actualKgDsHa;
    @Column(name = "ACTUAL_BAG_LOT")
    private Float actualBagLot;
    @Column(name = "PLANT_FLOW_DAYS")
    private Integer plantFlowDays;
    @Column(name = "FLOW_HARV_DAYS")
    private Integer flowHarvDays;
    @Column(name = "FILES")
    private String file;
    @Column(name = "harvest_Kg_RW_Lot")
    private Float harvestKgRWLot;
    @Column(name = "harvest_rw_to_ds")
    private Float harvestRwToDs;
    @Column(name = "tn_rw_lot")
    private Float tnRwLot;
    @Column(name = "bag_peso")
    private Float bagPeso;
    @Column(name = "kg_Fng_Ha")
    private Float kgFngHa;
    @Column(name = "PLANTING_DATE")
    private Date plantingDate;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "previousLotPK.actualLot", orphanRemoval = true)
    @Cascade(CascadeType.ALL)
    private List<PreviousLot> previousLot = new ArrayList<PreviousLot>();

    @Column(name = "OBS_HARVEST_RW_TO_DS")
    private String obsHarvestRwToDs;
    @Column(name = "TRUCKS")
    private Integer trucks;
    @Column(name = "WEIGHT_AVERAGE_TRUCK")
    private Float weightAverageTruck;
    @Column(name = "RECEPTION_PLANT")
    private String receptionPlant;
    @Column(name = "HUSKING_KG_DS_LOT")
    private Float huskingKgDsLot;
    @Column(name = "OBS_HUSKING_KG_DS_LOT")
    private String obsHuskingKgDsLot;
    @Column(name = "HUSKING_KG_DS_HA")
    private Float huskingKgDsHa;
    @Column(name = "QUALITY_KG_FNG_LOT")
    private Float qualityKgFngLot;
    @Column(name = "GREEN_CONVERSION")
    private Float greenConversion;
    @Column(name = "EFICIENCIA_RW_TO_DS")
    private Float eficienciaRwToDs;
    @Column(name = "ACTUAL_KG_DS_LOT")
    private Float actualKgDsLot;
    @Column(name = "ACTUAL_TN_DS_HA")
    private Float actualTnDsHa;
    @Column(name = "QUALITY_DS_TO_FNG")
    private Float qualityDsToFng;
    @Column(name = "QUALITY_WEIGHT_BAG")
    private Float qualityWeightBag;
    @Column(name = "BULK_BAG_EST")
    private Float bulkBagEst;
    @Column(name = "BULK_BAG_HA_EST")
    private Float bulkBagHaEst;
    @Column(name = "BULK_KG_FNG_HA")
    private Float bulkKgFNGHa;
    @Column(name = "QUALITY_OBS")
    private String qualityObs;
    @Column(name = "ACTUAL_KG_DS_BALANCE")
    private Float actualKgDsBalance;

    @Column(name = "EFICIENCIA_DS_TO_FNG")
    private Float eficienciaDsToFng;
    @Column(name = "WAREHOUSE_UNIT")
    private String warehouseUnit;
    @Column(name = "ACTUAL_KG_FNG_LOT")
    private Float actualKgFngLot;
    @Column(name = "PLS_LOT")
    private Float plsLot;
    @Column(name = "INDEX_LOT")
    private Float indexLot;
    @Column(name = "PL_LOT")
    private Float plLot;
    @Column(name = "BULK_CONVERSION")
    private Float bulkConversion;
    @Column(name = "EFICIENCIA_KG_DESCARTE")
    private Float eficienciaKgDescarte;
    @Column(name = "HUMIDITY")
    private Float humidity;
    @Column(name = "SAMPLE_DATE_HUMIDITY")
    private Date sampleDateHumidity;

    @Column(name = "ACTUAL_WEIGHT_BAG_LOT")
    private Float actualWeightBagLot;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "pk.lot")
    private List<LotBatch> lotBatches = new LinkedList<LotBatch>();

    @Column(name = "OBS_LINE")
    private String obsLine;
    @Column(name = "GENERAL_OBS")
    private String generalObs;

    @Column(name = "AVERAGE_HUMIDITY")
    private Float averageHumidity;

    @Column(name = "COUNT_ESTIMATED_KG_DS_HA")
    private Integer countEstimatedKgDsHa;

    @Column(name = "TOTAL_KG_CULL_TOWER")
    private Float totalKgCullTower;

    private String megazone;

    private String client;

    private String germoplasma;

    @Column(name = "GRAN_PROGRAM")
    private String granProgram;

    @Column(name = "REAL_RW_RECEIPT_DATE")
    private Date realRwReceiptDate;

    @Column(name = "ESTIMATED_RW")
    private Date estimatedRwDate;

    @Column(name = "REAL_DS_DATE")
    private Date realDsDate;

    @Column(name = "ESTIMATED_DS_DATE")
    private Date estimatedDsDate;

    @Column(name = "ESTIMATED_FNG_INIT")
    private Date estimatedFngInit;

    @Column(name = "ESTIMATED_FNG_END")
    private Date estimatedFngEnd;

    @Column(name = "REAL_FNG_INIT")
    private Date realFngInit;

    @Column(name = "REAL_FNG_END")
    private Date realFngEnd;

    @Column(name = "FIRST_BATCH_ID")
    private Integer firstBatchId;

    @Column(name = "ESTIMATED_TN_FNG_LOT")
    private Float estimatedTnFngLot;

    public Date getRealDsDate() {
        return realDsDate;
    }

    public void setRealDsDate(Date realDsDate) {
        this.realDsDate = realDsDate;
    }

    public Date getEstimatedDsDate() {
        return estimatedDsDate;
    }

    public void setEstimatedDsDate(Date estimatedDsDate) {
        this.estimatedDsDate = estimatedDsDate;
    }

    public Date getRealRwReceiptDate() {
        return realRwReceiptDate;
    }

    public void setRealRwReceiptDate(Date realRwReceiptDate) {
        this.realRwReceiptDate = realRwReceiptDate;
    }

    public Integer getCountEstimatedKgDsHa() {
        return countEstimatedKgDsHa;
    }

    public void setCountEstimatedKgDsHa(Integer countEstimatedKgDsHa) {
        this.countEstimatedKgDsHa = countEstimatedKgDsHa;
    }

    public String getObsLine() {
        return obsLine;
    }

    public void setObsLine(String obsLine) {
        this.obsLine = obsLine;
    }

    public String getGeneralObs() {
        return generalObs;
    }

    public void setGeneralObs(String generalObs) {
        this.generalObs = generalObs;
    }

    public Date getSampleDateHumidity() {
        return sampleDateHumidity;
    }

    public void setSampleDateHumidity(Date sampleDateHumidity) {
        this.sampleDateHumidity = sampleDateHumidity;
    }

    public Float getHumidity() {
        return humidity;
    }

    public void setHumidity(Float humidity) {
        this.humidity = humidity;
    }

    public Float getBulkConversion() {
        return bulkConversion;
    }

    public void setBulkConversion(Float bulkConversion) {
        this.bulkConversion = bulkConversion;
    }

    public Float getEficienciaKgDescarte() {
        return eficienciaKgDescarte;
    }

    public void setEficienciaKgDescarte(Float eficienciaKgDescarte) {
        this.eficienciaKgDescarte = eficienciaKgDescarte;
    }

    public Float getPlLot() {
        return plLot;
    }

    public void setPlLot(Float plLot) {
        this.plLot = plLot;
    }

    public Float getIndexLot() {
        return indexLot;
    }

    public void setIndexLot(Float indexLot) {
        this.indexLot = indexLot;
    }

    public Float getPlsLot() {
        return plsLot;
    }

    public void setPlsLot(Float plsLot) {
        this.plsLot = plsLot;
    }

    public Float getActualKgFngLot() {
        return actualKgFngLot;
    }

    public void setActualKgFngLot(Float actualKgFngLot) {
        this.actualKgFngLot = actualKgFngLot;
    }

    public String getWarehouseUnit() {
        return warehouseUnit;
    }

    public void setWarehouseUnit(String warehouseUnit) {
        this.warehouseUnit = warehouseUnit;
    }

    public Float getEficienciaDsToFng() {
        return eficienciaDsToFng;
    }

    public void setEficienciaDsToFng(Float eficienciaDsToFng) {
        this.eficienciaDsToFng = eficienciaDsToFng;
    }

    public Float getQualityDsToFng() {
        return qualityDsToFng;
    }

    public void setQualityDsToFng(Float qualityDsToFng) {
        this.qualityDsToFng = qualityDsToFng;
    }

    public Float getActualTnDsHa() {
        return actualTnDsHa;
    }

    public void setActualTnDsHa(Float actualTnDsHa) {
        this.actualTnDsHa = actualTnDsHa;
    }

    public Float getActualKgDsLot() {
        return actualKgDsLot;
    }

    public void setActualKgDsLot(Float actualKgDsLot) {
        this.actualKgDsLot = actualKgDsLot;
    }

    public Float getHuskingKgDsLot() {
        return huskingKgDsLot;
    }

    public void setHuskingKgDsLot(Float huskingKgDsLot) {
        this.huskingKgDsLot = huskingKgDsLot;
    }

    public String getObsHuskingKgDsLot() {
        return obsHuskingKgDsLot;
    }

    public void setObsHuskingKgDsLot(String obsHuskingKgDsLot) {
        this.obsHuskingKgDsLot = obsHuskingKgDsLot;
    }

    public Float getHuskingKgDsHa() {
        return huskingKgDsHa;
    }

    public void setHuskingKgDsHa(Float huskingKgDsHa) {
        this.huskingKgDsHa = huskingKgDsHa;
    }

    public Float getQualityKgFngLot() {
        return qualityKgFngLot;
    }

    public void setQualityKgFngLot(Float qualityKgFngLot) {
        this.qualityKgFngLot = qualityKgFngLot;
    }

    public Float getGreenConversion() {
        return greenConversion;
    }

    public void setGreenConversion(Float greenConversion) {
        this.greenConversion = greenConversion;
    }

    public Float getEficienciaRwToDs() {
        return eficienciaRwToDs;
    }

    public void setEficienciaRwToDs(Float eficienciaRwToDs) {
        this.eficienciaRwToDs = eficienciaRwToDs;
    }

    public String getObsHarvestRwToDs() {
        return obsHarvestRwToDs;
    }

    public void setObsHarvestRwToDs(String obsHarvestRwToDs) {
        this.obsHarvestRwToDs = obsHarvestRwToDs;
    }

    public Date getPlantingDate() {
        return plantingDate;
    }

    public void setPlantingDate(Date plantingDate) {
        this.plantingDate = plantingDate;
    }

    public List<PreviousLot> getPreviousLot() {
        return previousLot;
    }

    public void setPreviousLot(List<PreviousLot> previousLot) {
        this.previousLot = previousLot;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public Integer getFlowHarvDays() {
        return flowHarvDays;
    }

    public void setFlowHarvDays(Integer flowHarvDays) {
        this.flowHarvDays = flowHarvDays;
    }

    public Integer getPlantFlowDays() {
        return plantFlowDays;
    }

    public void setPlantFlowDays(Integer plantFlowDays) {
        this.plantFlowDays = plantFlowDays;
    }

    public String getObsEstimatedKgDsHa() {
        return obsEstimatedKgDsHa;
    }

    public void setObsEstimatedKgDsHa(String obsEstimatedKgDsHa) {
        this.obsEstimatedKgDsHa = obsEstimatedKgDsHa;
    }

    public Float getActualKgDsHa() {
        return actualKgDsHa;
    }

    public void setActualKgDsHa(Float actualKgDsHa) {
        this.actualKgDsHa = actualKgDsHa;
    }

    public Float getActualBagLot() {
        return actualBagLot;
    }

    public void setActualBagLot(Float actualBagLot) {
        this.actualBagLot = actualBagLot;
    }

    public Date getHarvestDate() {
        return harvestDate;
    }

    public void setHarvestDate(Date harvestDate) {
        this.harvestDate = harvestDate;
    }

    public Date getFloweringDate() {
        return floweringDate;
    }

    public void setFloweringDate(Date floweringDate) {
        this.floweringDate = floweringDate;
    }

    public Date getRealFloweringDate() {
        return realFloweringDate;
    }

    public void setRealFloweringDate(Date realFloweringDate) {
        this.realFloweringDate = realFloweringDate;
    }

    public Date getRealHarvestDate() {
        return realHarvestDate;
    }

    public void setRealHarvestDate(Date realHarvestDate) {
        this.realHarvestDate = realHarvestDate;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public Establishment getEstablishment() {
        return establishment;
    }

    public void setEstablishment(Establishment establishment) {
        this.establishment = establishment;
    }

    public Hybrid getHybrid() {
        return hybrid;
    }

    public void setHybrid(Hybrid hybrid) {
        this.hybrid = hybrid;
    }

    public Float getRegisteredHas() {
        return registeredHas;
    }

    public void setRegisteredHas(Float registeredHas) {
        this.registeredHas = registeredHas;
    }

    public Float getHarvestableHas() {
        return harvestableHas;
    }

    public void setHarvestableHas(Float harvestableHas) {
        this.harvestableHas = harvestableHas;
    }

    public String getCertification() {
        return certification;
    }

    public void setCertification(String certification) {
        this.certification = certification;
    }

    public String getExpediente() {
        return expediente;
    }

    public void setExpediente(String expediente) {
        this.expediente = expediente;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getPlantingWeek() {
        return plantingWeek;
    }

    public void setPlantingWeek(Integer plantingWeek) {
        this.plantingWeek = plantingWeek;
    }

    public String getSourceLotFile() {
        return sourceLotFile;
    }

    public void setSourceLotFile(String sourceLotFile) {
        this.sourceLotFile = sourceLotFile;
    }

    public String getSourceMasterfile() {
        return sourceMasterfile;
    }

    public void setSourceMasterfile(String sourceMasterfile) {
        this.sourceMasterfile = sourceMasterfile;
    }

    public Boolean getIsReplaced() {
        return isReplaced;
    }

    public void setIsReplaced(Boolean isReplaced) {
        this.isReplaced = isReplaced;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }


    public Date getEstimatedHarvestDate() {
        return estimatedHarvestDate;
    }

    public void setEstimatedHarvestDate(Date estimatedHarvestDate) {
        this.estimatedHarvestDate = estimatedHarvestDate;
    }


    public Date getEstimatedPlantingDate() {
        return estimatedPlantingDate;
    }

    public void setEstimatedPlantingDate(Date estimatedPlantingDate) {
        this.estimatedPlantingDate = estimatedPlantingDate;
    }

    public Date getRealPlantingDate() {
        return realPlantingDate;
    }

    public void setRealPlantingDate(Date realPlantingDate) {
        this.realPlantingDate = realPlantingDate;
    }

    public Integer getGdu() {
        return gdu;
    }

    public void setGdu(Integer gdu) {
        this.gdu = gdu;
    }

    public Date getEstimatedFloweringDate() {
        return estimatedFloweringDate;
    }

    public void setEstimatedFloweringDate(Date estimatedFloweringDate) {
        this.estimatedFloweringDate = estimatedFloweringDate;
    }

    public Date getHarvestDateForHumidity() {
        return harvestDateForHumidity;
    }

    public void setHarvestDateForHumidity(Date harvestDateForHumidity) {
        this.harvestDateForHumidity = harvestDateForHumidity;
    }

    public Integer getRw() {
        return rw;
    }

    public void setRw(Integer rw) {
        this.rw = rw;
    }

    public String getObservation() {
        return observation;
    }

    public void setObservation(String observation) {
        this.observation = observation;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public Boolean getState() {
        return state;
    }

    public void setState(Boolean state) {
        this.state = state;
    }

    public Float getTargetKgBag() {
        return targetKgBag;
    }

    public void setTargetKgBag(Float targetKgBag) {
        this.targetKgBag = targetKgBag;
    }

    public Float getTargetRwToDs() {
        return targetRwToDs;
    }

    public void setTargetRwToDs(Float targetRwToDs) {
        this.targetRwToDs = targetRwToDs;
    }

    public Float getTargetDsToFng() {
        return targetDsToFng;
    }

    public void setTargetDsToFng(Float targetDsToFng) {
        this.targetDsToFng = targetDsToFng;
    }

    public Float getTargetBagHa() {
        return targetBagHa;
    }

    public void setTargetBagHa(Float targetBagHa) {
        this.targetBagHa = targetBagHa;
    }

    public Float getTargetBagLot() {
        return targetBagLot;
    }

    public void setTargetBagLot(Float targetBagLot) {
        this.targetBagLot = targetBagLot;
    }

    public Float getDiasFlorCos() {
        return diasFlorCos;
    }

    public void setDiasFlorCos(Float diasFlorCos) {
        this.diasFlorCos = diasFlorCos;
    }

    public Float getTargetTnRwLot() {
        return targetTnRwLot;
    }

    public void setTargetTnRwLot(Float targetTnRwLot) {
        this.targetTnRwLot = targetTnRwLot;
    }

    public Float getTargetTnDsLot() {
        return targetTnDsLot;
    }

    public void setTargetTnDsLot(Float targetTnDsLot) {
        this.targetTnDsLot = targetTnDsLot;
    }

    public Float getTargetKgsDsHa() {
        return targetKgsDsHa;
    }

    public void setTargetKgsDsHa(Float targetKgsDsHa) {
        this.targetKgsDsHa = targetKgsDsHa;
    }

    public Float getPorcActualObjetiveTargetDs() {
        return porcActualObjetiveTargetDs;
    }

    public void setPorcActualObjetiveTargetDs(Float porcActualObjetiveTargetDs) {
        this.porcActualObjetiveTargetDs = porcActualObjetiveTargetDs;
    }

    public Float getHarvKgFngEstLotRw() {
        return harvKgFngEstLotRw;
    }

    public void setHarvKgFngEstLotRw(Float harvKgFngEstLotRw) {
        this.harvKgFngEstLotRw = harvKgFngEstLotRw;
    }

    public Float getActualTnDsLot() {
        return actualTnDsLot;
    }

    public void setActualTnDsLot(Float actualTnDsLot) {
        this.actualTnDsLot = actualTnDsLot;
    }

    public Float getActualTnFngLot() {
        return actualTnFngLot;
    }

    public void setActualTnFngLot(Float actualTnFngLot) {
        this.actualTnFngLot = actualTnFngLot;
    }

    public Float getEficienciaEstUnField() {
        return eficienciaEstUnField;
    }

    public void setEficienciaEstUnField(Float eficienciaEstUnField) {
        this.eficienciaEstUnField = eficienciaEstUnField;
    }

    public Float getHarvKgDsLotEstRw() {
        return harvKgDsLotEstRw;
    }

    public void setHarvKgDsLotEstRw(Float harvKgDsLotEstRw) {
        this.harvKgDsLotEstRw = harvKgDsLotEstRw;
    }

    public Float getHarvKgDsHaEstRw() {
        return harvKgDsHaEstRw;
    }

    public void setHarvKgDsHaEstRw(Float harvKgDsHaEstRw) {
        this.harvKgDsHaEstRw = harvKgDsHaEstRw;
    }

    public Float getActualTnRwLot() {
        return actualTnRwLot;
    }

    public void setActualTnRwLot(Float actualTnRwLot) {
        this.actualTnRwLot = actualTnRwLot;
    }

    public Float getTargetLot() {
        return targetLot;
    }

    public void setTargetLot(Float targetLot) {
        this.targetLot = targetLot;
    }

    public Float getPorcentActualObjectiveUnTarget() {
        return porcentActualObjectiveUnTarget;
    }

    public void setPorcentActualObjectiveUnTarget(Float porcentActualObjectiveUnTarget) {
        this.porcentActualObjectiveUnTarget = porcentActualObjectiveUnTarget;
    }

    public Float getHarvestWeek() {
        return harvestWeek;
    }

    public void setHarvestWeek(Float harvestWeek) {
        this.harvestWeek = harvestWeek;
    }

    public Float getEstimatedKgDsHa() {
        return estimatedKgDsHa;
    }

    public void setEstimatedKgDsHa(Float estimatedKgDsHa) {
        this.estimatedKgDsHa = estimatedKgDsHa;
    }

    public Float getHarvestKgRWLot() {
        return harvestKgRWLot;
    }

    public void setHarvestKgRWLot(Float harvestKgRWLot) {
        this.harvestKgRWLot = harvestKgRWLot;
    }

    public Float getHarvestRwToDs() {
        return harvestRwToDs;
    }

    public void setHarvestRwToDs(Float harvestRwToDs) {
        this.harvestRwToDs = harvestRwToDs;
    }

    public Float getTnRwLot() {
        return tnRwLot;
    }

    public void setTnRwLot(Float tnRwLot) {
        this.tnRwLot = tnRwLot;
    }

    public Float getBagPeso() {
        return bagPeso;
    }

    public void setBagPeso(Float bagPeso) {
        this.bagPeso = bagPeso;
    }

    public Float getKgFngHa() {
        return kgFngHa;
    }

    public void setKgFngHa(Float kgFngHa) {
        this.kgFngHa = kgFngHa;
    }

    public boolean isHarvested() {
        return (getHarvestKgRWLot() != null && getHarvestKgRWLot() > 0) || getRealHarvestDate() != null;
    }

    public boolean isPlanted() {
        return getRealPlantingDate() != null;
    }

    public Integer getTrucks() {
        return trucks;
    }

    public void setTrucks(Integer trucks) {
        this.trucks = trucks;
    }

    public Float getWeightAverageTruck() {
        return weightAverageTruck;
    }

    public void setWeightAverageTruck(Float weightAverageTruck) {
        this.weightAverageTruck = weightAverageTruck;
    }

    public String getReceptionPlant() {
        return receptionPlant;
    }

    public void setReceptionPlant(String receptionPlant) {
        this.receptionPlant = receptionPlant;
    }

    public Float getQualityWeightBag() {
        return qualityWeightBag;
    }

    public void setQualityWeightBag(Float qualityWeightBag) {
        this.qualityWeightBag = qualityWeightBag;
    }

    public Float getBulkBagEst() {
        return bulkBagEst;
    }

    public void setBulkBagEst(Float bulkBagEst) {
        this.bulkBagEst = bulkBagEst;
    }

    public Float getBulkBagHaEst() {
        return bulkBagHaEst;
    }

    public void setBulkBagHaEst(Float bulkBagHaEst) {
        this.bulkBagHaEst = bulkBagHaEst;
    }

    public Float getBulkKgFNGHa() {
        return bulkKgFNGHa;
    }

    public void setBulkKgFNGHa(Float bulkKgFNGHa) {
        this.bulkKgFNGHa = bulkKgFNGHa;
    }

    public String getQualityObs() {
        return qualityObs;
    }

    public void setQualityObs(String qualityObs) {
        this.qualityObs = qualityObs;
    }

    public Float getActualKgDsBalance() {
        return actualKgDsBalance;
    }

    public void setActualKgDsBalance(Float actualKgDsBalance) {
        this.actualKgDsBalance = actualKgDsBalance;
    }

    public Float getActualWeightBagLot() {
        return actualWeightBagLot;
    }

    public void setActualWeightBagLot(Float actualWeightBagLot) {
        this.actualWeightBagLot = actualWeightBagLot;
    }

    public List<LotBatch> getLotBatches() {
        return lotBatches;
    }

    public void setLotBatches(List<LotBatch> lotBatches) {
        this.lotBatches = lotBatches;
    }

    public void calculate() {
        Float sumKgFngLotAssigned = 0F;
        Float sumBagLotAssigned = 0F;
        Float sumKgDsLotAssigned = 0F;
        for (LotBatch lotBatch : this.lotBatches) {
            sumKgFngLotAssigned = sumKgFngLotAssigned + lotBatch.getKgFNGLotAssigned();
            sumBagLotAssigned = sumBagLotAssigned + lotBatch.getBagLotAssigned();
            sumKgDsLotAssigned = sumKgDsLotAssigned + lotBatch.getKgDSLotAssigned();
        }
        if (this.lotBatches.size() > 0) {
            this.actualKgFngLot = sumKgFngLotAssigned;
            this.actualBagLot = sumBagLotAssigned;
            this.actualTnFngLot = this.actualKgFngLot / 1000F;
            this.actualWeightBagLot = this.actualKgFngLot / this.actualBagLot;
            this.actualKgDsBalance = this.actualKgDsLot - sumKgDsLotAssigned;
        } else {
            this.actualKgFngLot = 0f;
            this.actualBagLot = 0f;
            this.actualTnFngLot = 0f;
            this.actualWeightBagLot = 0f;
            this.actualKgDsBalance = this.actualKgDsLot;
        }
    }

    /**
     * The Lot is Husked when huskingKgDsLot > 0
     *
     * @return
     */
    public boolean isHusked() {
        return (this.huskingKgDsLot != null && this.huskingKgDsLot > 0);
    }

    /**
     * The Lot is Qualified when it is associated to any batch.
     *
     * @return
     */
    public boolean isQualified() {
        return this.getActualKgDsBalance() != null && this.getActualKgDsBalance() < this.getHuskingKgDsLot();
    }

    public Float getAverageHumidity() {
        return averageHumidity;
    }

    public void setAverageHumidity(Float averageHumidity) {
        this.averageHumidity = averageHumidity;
    }

    public String getMegazone() {
        return megazone;
    }

    public void setMegazone(String megazone) {
        this.megazone = megazone;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getGermoplasma() {
        return germoplasma;
    }

    public void setGermoplasma(String germoplasma) {
        this.germoplasma = germoplasma;
    }

    public boolean isPlant() {
        return !(this.getActualKgDsBalance() != null && this.getActualKgDsBalance() < this.getHuskingKgDsLot()) &&
                ((getHarvestKgRWLot() != null && getHarvestKgRWLot() > 0) || getRealHarvestDate() != null);
    }

    public boolean isBagging() {
        return (this.getActualKgDsBalance() != null && this.getActualKgDsBalance() < this.getHuskingKgDsLot()) &&
                ((getHarvestKgRWLot() != null && getHarvestKgRWLot() > 0) || getRealHarvestDate() != null);
    }

    public Float getTotalKgCullTower() {
        return totalKgCullTower;
    }

    public void setTotalKgCullTower(Float totalKgCullTower) {
        this.totalKgCullTower = totalKgCullTower;
    }

    public String getGranProgram() {
        return granProgram;
    }

    public void setGranProgram(String granProgram) {
        this.granProgram = granProgram;
    }

    public Date getEstimatedRwDate() {
        return estimatedRwDate;
    }

    public void setEstimatedRwDate(Date estimatedRwDate) {
        this.estimatedRwDate = estimatedRwDate;
    }

    public Date getEstimatedFngInit() {
        return estimatedFngInit;
    }

    public void setEstimatedFngInit(Date estimatedFngInit) {
        this.estimatedFngInit = estimatedFngInit;
    }

    public Date getEstimatedFngEnd() {
        return estimatedFngEnd;
    }

    public void setEstimatedFngEnd(Date estimatedFngEnd) {
        this.estimatedFngEnd = estimatedFngEnd;
    }

    public Date getRealFngInit() {
        return realFngInit;
    }

    public void setRealFngInit(Date realFngInit) {
        this.realFngInit = realFngInit;
    }

    public Date getRealFngEnd() {
        return realFngEnd;
    }

    public void setRealFngEnd(Date realFngEnd) {
        this.realFngEnd = realFngEnd;
    }

    public Integer getFirstBatchId() {
        return firstBatchId;
    }

    public void setFirstBatchId(Integer firstBatchId) {
        this.firstBatchId = firstBatchId;
    }

    public Float getEstimatedTnFngLot() {
        return estimatedTnFngLot;
    }

    public void setEstimatedTnFngLot(Float estimatedTnFngLot) {
        this.estimatedTnFngLot = estimatedTnFngLot;
    }
}
