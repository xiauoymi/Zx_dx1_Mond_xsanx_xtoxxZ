package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by BSBUON on 23/07/2014.
 */
@Entity
@Table(name = "LOT_BATCH")
@AssociationOverrides({
        @AssociationOverride(name = "pk.lot",
                joinColumns = @JoinColumn(name = "LOT_ID")),
        @AssociationOverride(name = "pk.batch",
                joinColumns = @JoinColumn(name = "BATCH_ID"))})
public class LotBatch implements Serializable {

    @EmbeddedId
    private LotBatchId pk = new LotBatchId();

    @Column(name = "KG_DS_LOT_ASSIGNED")
    private Float kgDSLotAssigned;

    @Column(name = "KG_FNG_LOT_ASSIGNED")
    private Float kgFNGLotAssigned;

    @Column(name = "BAG_LOT_ASSIGNED")
    private Float bagLotAssigned;

    @Column(name = "KG_CULL_TOWER")
    private Float kgCullTower;

    public LotBatchId getPk() {
        return pk;
    }

    public void setPk(LotBatchId pk) {
        this.pk = pk;
    }

    @Transient
    public Batch getBatch() {
        return this.getPk().getBatch();
    }

    public void setBatch(Batch batch) {
        this.getPk().setBatch(batch);
    }

    @Transient
    public Lot getLot() {
        return this.getPk().getLot();
    }

    public Float getKgCullTower() {
        return kgCullTower;
    }

    public void setKgCullTower(Float kgCullTower) {
        this.kgCullTower = kgCullTower;
    }

    public void setLot(Lot lot) {
        this.getPk().setLot(lot);
    }

    public Float getKgDSLotAssigned() {
        return kgDSLotAssigned;
    }

    public void setKgDSLotAssigned(Float kgDSLotAssigned) {
        this.kgDSLotAssigned = kgDSLotAssigned;
    }

    public Float getKgFNGLotAssigned() {
        return kgFNGLotAssigned;
    }

    public void setKgFNGLotAssigned(Float kgFNGLotAssigned) {
        this.kgFNGLotAssigned = kgFNGLotAssigned;
    }

    public Float getBagLotAssigned() {
        return bagLotAssigned;
    }

    public void setBagLotAssigned(Float bagLotAssigned) {
        this.bagLotAssigned = bagLotAssigned;
    }

    public boolean containsLot(String lotCode) {
        return this.getLot().getLotCode().toUpperCase().equals(lotCode.toUpperCase());
    }

    public void calculateLots(Float kgDS, Float kgFNG, Integer bagProduced) {

        Float numerator = (this.kgDSLotAssigned / kgDS);

        this.kgFNGLotAssigned = (numerator) * kgFNG;
        this.bagLotAssigned = (numerator) * bagProduced;
        this.getLot().setActualKgDsBalance(this.getLot().getActualKgDsBalance() - this.kgDSLotAssigned);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LotBatch lotBatch = (LotBatch) o;

        if (pk != null ? !pk.equals(lotBatch.pk) : lotBatch.pk != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return pk != null ? pk.hashCode() : 0;
    }
}
