package com.monsanto.prisma.core.domain;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Created by BSBUON on 23/07/2014.
 */
@Embeddable
public class LotBatchId implements Serializable {

    @ManyToOne
    private Lot lot;
    @ManyToOne
    private Batch batch;

    public LotBatchId(){

    }

    public LotBatchId(Lot lot, Batch batch){
        this.lot = lot;
        this.batch = batch;
    }

    public Lot getLot() {
        return lot;
    }

    public void setLot(Lot lot) {
        this.lot = lot;
    }


    public Batch getBatch() {
        return batch;
    }

    public void setBatch(Batch batch) {
        this.batch = batch;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LotBatchId that = (LotBatchId) o;

        if (batch != null ? !batch.equals(that.batch) : that.batch != null) return false;
        if (lot != null ? !lot.equals(that.lot) : that.lot != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = lot != null ? lot.hashCode() : 0;
        result = 31 * result + (batch != null ? batch.hashCode() : 0);
        return result;
    }
}
