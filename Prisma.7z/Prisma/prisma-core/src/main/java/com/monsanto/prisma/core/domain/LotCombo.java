package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by BSBUON on 22/09/2014.
 */
@Entity
@Table(name = "LOT")
public class LotCombo implements Serializable{

    @Id
    @Column(name = "LOT_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_LOT")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generate_seq")
    private Integer id;

    @Column(name = "LOT_CODE")
    private String lotCode;

    public LotCombo() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LotCombo lotCombo = (LotCombo) o;

        if (id != null ? !id.equals(lotCombo.id) : lotCombo.id != null) return false;
        if (lotCode != null ? !lotCode.equals(lotCombo.lotCode) : lotCombo.lotCode != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (lotCode != null ? lotCode.hashCode() : 0);
        return result;
    }
}
