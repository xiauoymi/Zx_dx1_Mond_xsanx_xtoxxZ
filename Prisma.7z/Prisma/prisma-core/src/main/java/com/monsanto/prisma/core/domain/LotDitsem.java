package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.dto.LotDTO;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by EPESTE on 29/05/2014.
 */
@Entity
@Table(name = "LOT_DITSEM")
public class LotDitsem implements Serializable {
    @Id
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_LOT_DITSEM")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    @Column(name = "LOT_DITSEM_ID")
    private Integer id;

    @Column(name = "CAMPAIGN_ID")
    private Integer campaignId;

    @Column(name = "PATH_FILE")
    private String pathFile;

    @Column(name = "DATE_PROCCESS")
    private Date dateProccess;

    @Column(name = "IMPORTED")
    private int imported;

    @Column(name = "OMITTED")
    private int omitted;

    @Transient
    private List<LotDTO> lotDTOs;

    @Transient
    private List<LotDTO> lotsWithOmissions;

    public LotDitsem() {
    }

    public LotDitsem(Campaign campaign, String pathFile) {
        this.campaignId = campaign.getId();
        this.pathFile = campaign.getFilePath() + pathFile;
        this.imported = 0;
        this.omitted = 0;
        this.dateProccess = new Date();
        this.lotDTOs = new ArrayList<LotDTO>();
        this.lotsWithOmissions = new ArrayList<LotDTO>();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public String getPathFile() {
        return pathFile;
    }

    public void setPathFile(String pathFile) {
        this.pathFile = pathFile;
    }

    public Date getDateProccess() {
        return dateProccess;
    }

    public void setDateProccess(Date dateProccess) {
        this.dateProccess = dateProccess;
    }

    public int getImported() {
        return imported;
    }

    public void setImported(int imported) {
        this.imported = imported;
    }

    public int getOmitted() {
        return omitted;
    }

    public void setOmitted(int omitted) {
        this.omitted = omitted;
    }

    public List<LotDTO> getLotDTOs() {
        return lotDTOs;
    }

    public void setLotDTOs(List<LotDTO> lotDTOs) {
        this.lotDTOs = lotDTOs;
    }

    public void setLotsWithOmissions(List<LotDTO> lotsWithOmissions) {
        this.lotsWithOmissions = lotsWithOmissions;
    }

    public List<LotDTO> getLotsWithOmissions() {
        return lotsWithOmissions;
    }

    public void addOmitted() {
        this.omitted++;
    }

    public void addImported() {
        this.imported++;
    }

    public void addLotDTO(LotDTO  lotDTO) {
        this.lotDTOs.add(lotDTO);
    }

    public void addLotWithOmission(LotDTO lotDTO){
        this.lotsWithOmissions.add(lotDTO);
    }
}
