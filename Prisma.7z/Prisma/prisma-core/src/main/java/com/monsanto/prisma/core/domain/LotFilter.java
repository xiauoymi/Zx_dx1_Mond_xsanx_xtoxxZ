package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by epeste on 29/10/2014.
 */
@Entity
@Table(name = "LOT_FILTER")
public class LotFilter implements Serializable{
    @Id
    @Column(name = "LOT_FILTER_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_LOT_FILTER")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generate_seq")
    private Integer id;

    @Column(name = "FIELD")
    private String field;

    @Column(name = "FROM_QUERY")
    private String fromQuery;

    @Column(name = "FILTER_QUERY")
    private String filterQuery;

    @Column(name = "TYPE_FIELD")
    private Integer typeField;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getFilterQuery() {
        return filterQuery;
    }

    public void setFilterQuery(String filterQuery) {
        this.filterQuery = filterQuery;
    }

    public Integer getTypeField() {
        return typeField;
    }

    public void setTypeField(Integer typeField) {
        this.typeField = typeField;
    }

    public String getFromQuery() {
        return fromQuery;
    }

    public void setFromQuery(String fromQuery) {
        this.fromQuery = fromQuery;
    }
}
