package com.monsanto.prisma.core.domain;


import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by EPESTE on 12/06/2014.
 */
@Entity
@Table(name = "LOT_HISTORY")
public class LotHistory implements Serializable {
    @Id
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_LOT_HISTORY")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    @Column(name = "LOT_HISTORY_ID")
    private Integer id;

    @Column(name = "date_transaction")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateTransaction;

    @Column(name = "action")
    private String action;

    @Column(name = "LOT_ID")
    private Integer lotId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_ID")
    private User user;

    @Column(name = "hybrid_name")
    private String hybridName;

    @Column(name = "HARVESTABLE_HAS")
    private Float harvestableHas;

    @Column(name = "estimated_Planting_Date")
    private Date estimatedPlantingDate;

    @Column(name = "estimated_Flowering_Date")
    private Date estimatedFloweringDate;

    @Column(name = "estimated_Harvest_Date")
    private Date estimatedHarvestDate;

    @Column(name = "HARVEST_DATE_FOR_HUMIDITY")
    private Date harvestDateForHumidity;

    @Column(name = "estimated_Ds_Ha")
    private Float estimatedDsHa;

    @Column(name = "target_Rwt_To_Ds")
    private Float targetRwToDs;

    @Column(name = "target_Ds_to_FNG")
    private Float targetDSToFNG;

    @Column(name = "target_Kg_Bag")
    private Float targetKgBag;

    @Column(name = "target_Bag_Ha")
    private Float targetBagHa;

    @Column(name = "flow_Harv_Days")
    private Integer flowHarvDays;

    @Column(name = "harvest_Kg_RW_Lot")
    private Float harvestKgRWLot;

    @Column(name = "harvest_RW_to_DS")
    private Float harvestRWtoDS;

    @Column(name = "planting_Date")
    private Date plantingDate;

    @Column(name = "flowering_Date")
    private Date floweringDate;

    @Column(name = "harvest_Date")
    private Date harvestDate;

    @Column(name = "tn_Rw_lot")
    private Float tnRwlot;

    @Column(name = "tn_Ds_Lot")
    private Float tnDsLot;

    @Column(name = "tn_Fng_Lot")
    private Float tnFngLot;

    @Column(name = "bag_Total_Lot")
    private Float bagTotalLot;

    @Column(name = "bag_Peso")
    private Float bagPeso;

    @Column(name = "kg_DS_Ha")
    private Float kgDSHa;

    @Column(name = "kg_Fng_Ha")
    private Float kgFngHa;

    @Column(name = "Bag_Has")
    private Float bagHas;


    @Column(name = "ACTUAL_TN_DS_LOT")
    private Float actualTnDsLot;
    @Column(name = "ACTUAL_TN_RW_LOT")
    private Float actualTnRwLot;
    @Column(name = "OBS_HARVEST_RW_TO_DS")
    private String obsHarvestRwToDs;
    @Column(name = "TRUCKS")
    private Integer trucks;
    @Column(name = "WEIGHT_AVERAGE_TRUCK")
    private Float weightAverageTruck;
    @Column(name = "RECEPTION_PLANT")
    private String receptionPlant;
    @Column(name = "HUSKING_KG_DS_LOT")
    private Float huskingKgDsLot;
    @Column(name = "OBS_HUSKING_KG_DS_LOT")
    private String obsHuskingKgDsLot;
    @Column(name = "HUSKING_KG_DS_HA")
    private Float huskingKgDsHa;
    @Column(name = "QUALITY_KG_FNG_LOT")
    private Float qualityKgFngLot;
    @Column(name = "GREEN_CONVERSION")
    private Float greenConversion;
    @Column(name = "EFICIENCIA_RW_TO_DS")
    private Float eficienciaRwToDs;
    @Column(name = "ACTUAL_KG_DS_LOT")
    private Float actualKgDsLot;
    @Column(name = "ACTUAL_TN_DS_HA")
    private Float actualTnDsHa;
    @Column(name = "QUALITY_DS_TO_FNG")
    private Float qualityDsToFng;
    @Column(name = "QUALITY_WEIGHT_BAG")
    private Float qualityWeightBag;
    @Column(name = "BULK_BAG_EST")
    private Float bulkBagEst;
    @Column(name = "BULK_BAG_HA_EST")
    private Float bulkBagHaEst;
    @Column(name = "BULK_KG_FNG_HA")
    private Float bulkKgFNGHa;
    @Column(name = "QUALITY_OBS")
    private String qualityObs;
    @Column(name = "EFICIENCIA_DS_TO_FNG")
    private Float eficienciaDsToFng;
    @Column(name = "WAREHOUSE_UNIT")
    private String warehouseUnit;
    @Column(name = "ACTUAL_KG_FNG_LOT")
    private Float actualKgFngLot;
    @Column(name = "PLS_LOT")
    private Float plsLot;
    @Column(name = "INDEX_LOT")
    private Float indexLot;
    @Column(name = "PL_LOT")
    private Float plLot;
    @Column(name = "BULK_CONVERSION")
    private Float bulkConversion;
    @Column(name = "EFICIENCIA_KG_DESCARTE")
    private Float eficienciaKgDescarte;
    @Column(name = "HUMIDITY")
    private Float humidity;
    @Column(name = "SAMPLE_DATE_HUMIDITY")
    private Date sampleDateHumidity;

    @Column(name = "OBS_LINE")
    private String obsLine;
    @Column(name = "GENERAL_OBS")
    private String generalObs;


    @Column(name = "real_Planting_Date")
    private Date realPlantingDate;

    @Column(name = "real_Flowering_Date")
    private Date realFloweringDate;

    @Column(name = "real_Harvest_Date")
    private Date realHarvestDate;

    @Column(name = "TARGET_TN_RW_LOT")
    private Float targetTnRwLot;

    @Column(name = "TARGET_TN_DS_LOT")
    private Float targetTnDsLot;

    @Column(name = "TARGET_BAG_LOT")
    private Float targetBagLot;

    @Column(name = "REAL_RW_RECEIPT_DATE")
    private Date realRwReceiptDate;

    @Column(name = "REAL_DS_RECEIPT_DATE")
    private Date realDsDate;

    @Column(name = "ESTIMATED_DS_DATE")
    private Date estimatedDsDate;

    @Column(name = "ESTIMATED_FNG_INIT")
    private Date estimatedFngInit;

    @Column(name = "ESTIMATED_FNG_END")
    private Date estimatedFngEnd;

    @Column(name = "MEGAZONE")
    private String megazone;

    public LotHistory() {
    }


    public LotHistory(Lot lot, String action) {
        this.lotId = lot.getId();
        this.hybridName = lot.getHybrid().getName();
        this.harvestableHas = lot.getHarvestableHas();
        this.estimatedPlantingDate = lot.getEstimatedPlantingDate();
        this.estimatedFloweringDate = lot.getEstimatedFloweringDate();
        this.estimatedHarvestDate = lot.getEstimatedHarvestDate();
        this.harvestDateForHumidity = lot.getHarvestDateForHumidity();
        this.estimatedDsHa = lot.getEstimatedKgDsHa();
        this.targetRwToDs = lot.getTargetRwToDs();
        this.targetDSToFNG = lot.getTargetDsToFng();
        this.targetKgBag = lot.getTargetKgBag();
        this.targetBagHa = lot.getTargetBagHa();
        this.flowHarvDays = lot.getFlowHarvDays();
        this.harvestKgRWLot = lot.getHarvestKgRWLot();
        this.plantingDate = lot.getRealPlantingDate();
        this.floweringDate = lot.getRealFloweringDate();
        this.harvestDate = lot.getHarvestDate();
        this.tnRwlot = lot.getTnRwLot();
        this.tnDsLot = lot.getActualTnDsLot();
        this.tnFngLot = lot.getActualTnFngLot();
        this.bagTotalLot = lot.getActualBagLot();
        this.bagPeso = lot.getBagPeso();
        this.kgDSHa = lot.getActualKgDsHa();
        this.kgFngHa = lot.getKgFngHa();
        this.bagHas = lot.getTargetBagHa();

        this.harvestRWtoDS = lot.getHarvestRwToDs();
        this.actualTnDsLot = lot.getActualTnDsLot();
        this.actualTnRwLot = lot.getActualTnRwLot();
        this.obsHarvestRwToDs = lot.getObsHarvestRwToDs();
        this.huskingKgDsLot = lot.getHuskingKgDsLot();
        this.obsHuskingKgDsLot = lot.getObsHuskingKgDsLot();
        this.huskingKgDsHa = lot.getHuskingKgDsHa();
        this.qualityKgFngLot = lot.getQualityKgFngLot();
        this.greenConversion = lot.getGreenConversion();
        this.eficienciaRwToDs = lot.getEficienciaRwToDs();
        this.actualKgDsLot = lot.getActualKgDsLot();
        this.actualTnDsHa = lot.getActualTnDsHa();
        this.qualityDsToFng = lot.getQualityDsToFng();
        this.qualityWeightBag = lot.getQualityWeightBag();
        this.qualityObs = lot.getQualityObs();
        this.eficienciaDsToFng = lot.getEficienciaDsToFng();
        this.warehouseUnit = lot.getWarehouseUnit();
        this.actualKgFngLot = lot.getActualKgFngLot();
        this.plsLot = lot.getPlsLot();
        this.indexLot = lot.getIndexLot();
        this.plLot = lot.getPlLot();
        this.bulkConversion = lot.getBulkConversion();
        this.eficienciaKgDescarte = lot.getEficienciaKgDescarte();

        this.humidity = lot.getHumidity();
        this.sampleDateHumidity = lot.getSampleDateHumidity();
        this.action = action;
        this.setDateTransaction(new Date(System.currentTimeMillis()));
        this.obsLine = lot.getObsLine();
        this.generalObs = lot.getGeneralObs();
        this.realFloweringDate = lot.getRealFloweringDate();
        this.realHarvestDate = lot.getRealHarvestDate();
        this.realPlantingDate = lot.getRealPlantingDate();

        this.targetTnRwLot = lot.getTargetTnRwLot();
        this.targetTnDsLot = lot.getTargetTnDsLot();
        this.targetBagLot = lot.getTargetBagLot();
        this.realRwReceiptDate = lot.getRealRwReceiptDate();
        this.realDsDate = lot.getRealDsDate();
        this.estimatedDsDate = lot.getEstimatedDsDate();
        this.estimatedFngInit = lot.getEstimatedFngInit();
        this.estimatedFngEnd = lot.getEstimatedFngEnd();
        this.megazone = lot.getMegazone();
    }

    public String getMegazone() {
        return megazone;
    }

    public void setMegazone(String megazone) {
        this.megazone = megazone;
    }

    public Date getRealDsDate() {
        return realDsDate;
    }

    public Date getEstimatedFngInit() {
        return estimatedFngInit;
    }

    public void setEstimatedFngInit(Date estimatedFngInit) {
        this.estimatedFngInit = estimatedFngInit;
    }

    public Date getEstimatedFngEnd() {
        return estimatedFngEnd;
    }

    public void setEstimatedFngEnd(Date estimatedFngEnd) {
        this.estimatedFngEnd = estimatedFngEnd;
    }

    public void setRealDsDate(Date realDsDate) {
        this.realDsDate = realDsDate;
    }

    public Date getEstimatedDsDate() {
        return estimatedDsDate;
    }

    public void setEstimatedDsDate(Date estimatedDsDate) {
        this.estimatedDsDate = estimatedDsDate;
    }

    public Date getRealRwReceiptDate() {
        return realRwReceiptDate;
    }

    public void setRealRwReceiptDate(Date realRwReceiptDate) {
        this.realRwReceiptDate = realRwReceiptDate;
    }

    public Float getTargetBagLot() {
        return targetBagLot;
    }

    public void setTargetBagLot(Float targetBagLot) {
        this.targetBagLot = targetBagLot;
    }

    public Float getTargetTnDsLot() {
        return targetTnDsLot;
    }

    public void setTargetTnDsLot(Float targetTnDsLot) {
        this.targetTnDsLot = targetTnDsLot;
    }

    public Float getTargetTnRwLot() {
        return targetTnRwLot;
    }

    public void setTargetTnRwLot(Float targetTnRwLot) {
        this.targetTnRwLot = targetTnRwLot;
    }

    public Date getRealPlantingDate() {
        return realPlantingDate;
    }

    public void setRealPlantingDate(Date realPlantingDate) {
        this.realPlantingDate = realPlantingDate;
    }

    public Date getRealFloweringDate() {
        return realFloweringDate;
    }

    public void setRealFloweringDate(Date realFloweringDate) {
        this.realFloweringDate = realFloweringDate;
    }

    public Date getRealHarvestDate() {
        return realHarvestDate;
    }

    public void setRealHarvestDate(Date realHarvestDate) {
        this.realHarvestDate = realHarvestDate;
    }

    public String getObsLine() {
        return obsLine;
    }

    public void setObsLine(String obsLine) {
        this.obsLine = obsLine;
    }

    public String getGeneralObs() {
        return generalObs;
    }

    public void setGeneralObs(String generalObs) {
        this.generalObs = generalObs;
    }

    public Date getSampleDateHumidity() {
        return sampleDateHumidity;
    }

    public void setSampleDateHumidity(Date sampleDateHumidity) {
        this.sampleDateHumidity = sampleDateHumidity;
    }

    public Float getHumidity() {
        return humidity;
    }

    public void setHumidity(Float humidity) {
        this.humidity = humidity;
    }

    public Float getActualTnDsLot() {
        return actualTnDsLot;
    }

    public void setActualTnDsLot(Float actualTnDsLot) {
        this.actualTnDsLot = actualTnDsLot;
    }

    public Float getActualTnRwLot() {
        return actualTnRwLot;
    }

    public void setActualTnRwLot(Float actualTnRwLot) {
        this.actualTnRwLot = actualTnRwLot;
    }

    public String getObsHarvestRwToDs() {
        return obsHarvestRwToDs;
    }

    public void setObsHarvestRwToDs(String obsHarvestRwToDs) {
        this.obsHarvestRwToDs = obsHarvestRwToDs;
    }

    public Integer getTrucks() {
        return trucks;
    }

    public void setTrucks(Integer trucks) {
        this.trucks = trucks;
    }

    public Float getWeightAverageTruck() {
        return weightAverageTruck;
    }

    public void setWeightAverageTruck(Float weightAverageTruck) {
        this.weightAverageTruck = weightAverageTruck;
    }

    public String getReceptionPlant() {
        return receptionPlant;
    }

    public void setReceptionPlant(String receptionPlant) {
        this.receptionPlant = receptionPlant;
    }

    public Float getHuskingKgDsLot() {
        return huskingKgDsLot;
    }

    public void setHuskingKgDsLot(Float huskingKgDsLot) {
        this.huskingKgDsLot = huskingKgDsLot;
    }

    public String getObsHuskingKgDsLot() {
        return obsHuskingKgDsLot;
    }

    public void setObsHuskingKgDsLot(String obsHuskingKgDsLot) {
        this.obsHuskingKgDsLot = obsHuskingKgDsLot;
    }

    public Float getHuskingKgDsHa() {
        return huskingKgDsHa;
    }

    public void setHuskingKgDsHa(Float huskingKgDsHa) {
        this.huskingKgDsHa = huskingKgDsHa;
    }

    public Float getQualityKgFngLot() {
        return qualityKgFngLot;
    }

    public void setQualityKgFngLot(Float qualityKgFngLot) {
        this.qualityKgFngLot = qualityKgFngLot;
    }

    public Float getGreenConversion() {
        return greenConversion;
    }

    public void setGreenConversion(Float greenConversion) {
        this.greenConversion = greenConversion;
    }

    public Float getEficienciaRwToDs() {
        return eficienciaRwToDs;
    }

    public void setEficienciaRwToDs(Float eficienciaRwToDs) {
        this.eficienciaRwToDs = eficienciaRwToDs;
    }

    public Float getActualKgDsLot() {
        return actualKgDsLot;
    }

    public void setActualKgDsLot(Float actualKgDsLot) {
        this.actualKgDsLot = actualKgDsLot;
    }

    public Float getActualTnDsHa() {
        return actualTnDsHa;
    }

    public void setActualTnDsHa(Float actualTnDsHa) {
        this.actualTnDsHa = actualTnDsHa;
    }

    public Float getQualityDsToFng() {
        return qualityDsToFng;
    }

    public void setQualityDsToFng(Float qualityDsToFng) {
        this.qualityDsToFng = qualityDsToFng;
    }

    public Float getQualityWeightBag() {
        return qualityWeightBag;
    }

    public void setQualityWeightBag(Float qualityWeightBag) {
        this.qualityWeightBag = qualityWeightBag;
    }

    public Float getBulkBagEst() {
        return bulkBagEst;
    }

    public void setBulkBagEst(Float bulkBagEst) {
        this.bulkBagEst = bulkBagEst;
    }

    public Float getBulkBagHaEst() {
        return bulkBagHaEst;
    }

    public void setBulkBagHaEst(Float bulkBagHaEst) {
        this.bulkBagHaEst = bulkBagHaEst;
    }

    public Float getBulkKgFNGHa() {
        return bulkKgFNGHa;
    }

    public void setBulkKgFNGHa(Float bulkKgFNGHa) {
        this.bulkKgFNGHa = bulkKgFNGHa;
    }

    public String getQualityObs() {
        return qualityObs;
    }

    public void setQualityObs(String qualityObs) {
        this.qualityObs = qualityObs;
    }

    public Float getEficienciaDsToFng() {
        return eficienciaDsToFng;
    }

    public void setEficienciaDsToFng(Float eficienciaDsToFng) {
        this.eficienciaDsToFng = eficienciaDsToFng;
    }

    public String getWarehouseUnit() {
        return warehouseUnit;
    }

    public void setWarehouseUnit(String warehouseUnit) {
        this.warehouseUnit = warehouseUnit;
    }

    public Float getActualKgFngLot() {
        return actualKgFngLot;
    }

    public void setActualKgFngLot(Float actualKgFngLot) {
        this.actualKgFngLot = actualKgFngLot;
    }

    public Float getPlsLot() {
        return plsLot;
    }

    public void setPlsLot(Float plsLot) {
        this.plsLot = plsLot;
    }

    public Float getIndexLot() {
        return indexLot;
    }

    public void setIndexLot(Float indexLot) {
        this.indexLot = indexLot;
    }

    public Float getPlLot() {
        return plLot;
    }

    public void setPlLot(Float plLot) {
        this.plLot = plLot;
    }

    public Float getBulkConversion() {
        return bulkConversion;
    }

    public void setBulkConversion(Float bulkConversion) {
        this.bulkConversion = bulkConversion;
    }

    public Float getEficienciaKgDescarte() {
        return eficienciaKgDescarte;
    }

    public void setEficienciaKgDescarte(Float eficienciaKgDescarte) {
        this.eficienciaKgDescarte = eficienciaKgDescarte;
    }

    public LotHistory(Lot lot, String action, User user) {
        this(lot, action);
        this.user = user;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Float getHarvestableHas() {
        return harvestableHas;
    }

    public void setHarvestableHas(Float harvestableHas) {
        this.harvestableHas = harvestableHas;
    }

    public Date getEstimatedPlantingDate() {
        return estimatedPlantingDate;
    }

    public void setEstimatedPlantingDate(Date estimatedPlantingDate) {
        this.estimatedPlantingDate = estimatedPlantingDate;
    }

    public Date getEstimatedFloweringDate() {
        return estimatedFloweringDate;
    }

    public void setEstimatedFloweringDate(Date estimatedFloweringDate) {
        this.estimatedFloweringDate = estimatedFloweringDate;
    }

    public Date getEstimatedHarvestDate() {
        return estimatedHarvestDate;
    }

    public void setEstimatedHarvestDate(Date estimatedHarvestDate) {
        this.estimatedHarvestDate = estimatedHarvestDate;
    }

    public Date getHarvestDateForHumidity() {
        return harvestDateForHumidity;
    }

    public void setHarvestDateForHumidity(Date harvestDateForHumidity) {
        this.harvestDateForHumidity = harvestDateForHumidity;
    }

    public Float getEstimatedDsHa() {
        return estimatedDsHa;
    }

    public void setEstimatedDsHa(Float estimatedDsHa) {
        this.estimatedDsHa = estimatedDsHa;
    }

    public Float getTargetRwToDs() {
        return targetRwToDs;
    }

    public void setTargetRwToDs(Float targetRwToDs) {
        this.targetRwToDs = targetRwToDs;
    }

    public Float getTargetDSToFNG() {
        return targetDSToFNG;
    }

    public void setTargetDSToFNG(Float targetDSToFNG) {
        this.targetDSToFNG = targetDSToFNG;
    }

    public Float getTargetKgBag() {
        return targetKgBag;
    }

    public void setTargetKgBag(Float targetKgBag) {
        this.targetKgBag = targetKgBag;
    }

    public Float getTargetBagHa() {
        return targetBagHa;
    }

    public void setTargetBagHa(Float targetBagHa) {
        this.targetBagHa = targetBagHa;
    }

    public Integer getFlowHarvDays() {
        return flowHarvDays;
    }

    public void setFlowHarvDays(Integer flowHarvDays) {
        this.flowHarvDays = flowHarvDays;
    }

    public Float getHarvestKgRWLot() {
        return harvestKgRWLot;
    }

    public void setHarvestKgRWLot(Float harvestKgRWLot) {
        this.harvestKgRWLot = harvestKgRWLot;
    }

    public Float getHarvestRWtoDS() {
        return harvestRWtoDS;
    }

    public void setHarvestRWtoDS(Float harvestRWtoDS) {
        this.harvestRWtoDS = harvestRWtoDS;
    }

    public Date getPlantingDate() {
        return plantingDate;
    }

    public void setPlantingDate(Date plantingDate) {
        this.plantingDate = plantingDate;
    }

    public Date getFloweringDate() {
        return floweringDate;
    }

    public void setFloweringDate(Date floweringDate) {
        this.floweringDate = floweringDate;
    }

    public Date getHarvestDate() {
        return harvestDate;
    }

    public void setHarvestDate(Date harvestDate) {
        this.harvestDate = harvestDate;
    }

    public Float getTnRwlot() {
        return tnRwlot;
    }

    public void setTnRwlot(Float tnRwlot) {
        this.tnRwlot = tnRwlot;
    }

    public Float getTnDsLot() {
        return tnDsLot;
    }

    public void setTnDsLot(Float tnDsLot) {
        this.tnDsLot = tnDsLot;
    }

    public Float getTnFngLot() {
        return tnFngLot;
    }

    public void setTnFngLot(Float tnFngLot) {
        this.tnFngLot = tnFngLot;
    }

    public Float getBagTotalLot() {
        return bagTotalLot;
    }

    public void setBagTotalLot(Float bagTotalLot) {
        this.bagTotalLot = bagTotalLot;
    }

    public Float getBagPeso() {
        return bagPeso;
    }

    public void setBagPeso(Float bagPeso) {
        this.bagPeso = bagPeso;
    }

    public Float getKgDSHa() {
        return kgDSHa;
    }

    public void setKgDSHa(Float kgDSHa) {
        this.kgDSHa = kgDSHa;
    }

    public Float getKgFngHa() {
        return kgFngHa;
    }

    public void setKgFngHa(Float kgFngHa) {
        this.kgFngHa = kgFngHa;
    }

    public Float getBagHas() {
        return bagHas;
    }

    public void setBagHas(Float bagHas) {
        this.bagHas = bagHas;
    }

    public Date getDateTransaction() {
        return dateTransaction;
    }

    public void setDateTransaction(Date dateTransaction) {
        this.dateTransaction = dateTransaction;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public Integer getLotId() {
        return lotId;
    }

    public void setLotId(Integer lotId) {
        this.lotId = lotId;
    }
}
