package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by PGSETT on 16/05/2014.
 */
@Entity
@Table(name = "LOT_HUMIDITY")
public class LotHumidity implements Serializable {

    @Id
    @Column(name = "LOT_HUMIDITY_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_LOT_HUMIDITY")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "HUMIDITY")
    private Float humidity;
    @Column(name = "SAMPLE_DATE")
    private Date sampleDate;

    @ManyToOne
    @JoinColumn(name = "LOT_ID")
    private Lot lot;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Float getHumidity() {
        return humidity;
    }

    public void setHumidity(Float humidity) {
        this.humidity = humidity;
    }

    public Date getSampleDate() {
        return sampleDate;
    }

    public void setSampleDate(Date sampleDate) {
        this.sampleDate = sampleDate;
    }

    public Lot getLot() {
        return lot;
    }

    public void setLot(Lot lot) {
        this.lot = lot;
    }
}
