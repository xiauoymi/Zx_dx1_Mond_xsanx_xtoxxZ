package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.dto.CellOmittedDTO;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;


/**
 * Created by EPESTE on 04/06/2014.
 */
@Entity
@Table(name = "LOT_MASTERDATA")
public class LotMasterdata implements Serializable {
    @Id
    @Column(name = "LOT_MASTERDATA_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_LOT_MASTERDATA")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer idLotMasterdata;

    @Column(name = "CAMPAIGN_ID")
    @JoinColumn(name = "CAMPAIGN_ID")
    private Integer campaign;

    @Column(name = "PATH_FILE")
    private String file;

    @Column(name = "DATE_PROCESS")
    private Date dateCreation;

    private int imported;

    private int omitted;

    @Transient
    private String causes;

    @Transient
    private String hybridName;

    @Column(name = "MEGAZONE")
    private String megazone;

    @Transient
    private List<CellOmittedDTO> cellsOmitted;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HYBRID_ID")
    private Hybrid hybrid;

    @Column(name = "DS_RW")
    private Float dsRw;

    @Column(name = "FNG_DS")
    private Float fngDs;

    @Column(name = "KG_BLS")
    private Float kgBls;

    @Column(name = "UN_HA")
    private Float unHa;

    @Column(name = "DIAS_FLOR_COS")
    private Integer diasFlorCos;

    @Column(name = "DIAS_SIEMBRA_COS")
    private Integer diasSiembraCos;


    public LotMasterdata() {
    }

    public LotMasterdata(Masterdata masterdata, Hybrid hybrid, Integer campaignId, int lotsImported, int lotsOmitted, String path) {
        this.setHybrid(hybrid);
        this.setHybridName(hybrid.getName());
        this.setCampaign(campaignId);
        this.setDateCreation(new Date());
        this.setDsRw(masterdata.getDsRw());
        this.setFngDs(masterdata.getFngDs());
        this.setKgBls(masterdata.getKgBls());
        this.setUnHa(masterdata.getUnHa());
        this.setDiasFlorCos(masterdata.getFlowHarvDays());
//        this.setDiasSiembraCos(masterdata.getPlantFlowDays());
        this.setImported(lotsImported);
        this.setOmitted(lotsOmitted);
        this.setFile(path);
        this.setCauses("");
        setMegazone(masterdata.getMegaZone());
    }

    public LotMasterdata(Masterdata masterdata, Hybrid hybrid, Integer campaignId, int lotsImported, int lotsOmitted, String path, String causes) {
        this.setHybrid(hybrid);
        this.setCampaign(campaignId);
        this.setDateCreation(new Date());
        this.setDsRw(masterdata.getDsRw());
        this.setFngDs(masterdata.getFngDs());
        this.setKgBls(masterdata.getKgBls());
        this.setUnHa(masterdata.getUnHa());
        this.setDiasFlorCos(masterdata.getFlowHarvDays());
//        this.setDiasSiembraCos(masterdata.getPlantFlowDays());
        this.setImported(lotsImported);
        this.setOmitted(lotsOmitted);
        this.setFile(path);
        this.setHybridName(hybrid.getName());
        this.setCauses(causes);
        setMegazone(masterdata.getMegaZone());
    }

    public LotMasterdata(String hybrid, String megazone, int lotsImported, int lotsOmitted, String causes) {
        this.setHybridName(hybrid);
        this.setImported(lotsImported);
        this.setOmitted(lotsOmitted);
        this.setCauses(causes);
        setMegazone(megazone);
    }

    public Integer getIdLotMasterdata() {
        return idLotMasterdata;
    }

    public void setIdLotMasterdata(Integer idLotMasterdata) {
        this.idLotMasterdata = idLotMasterdata;
    }

    public Integer getCampaign() {
        return campaign;
    }

    public void setCampaign(Integer campaign) {
        this.campaign = campaign;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public int getImported() {
        return imported;
    }

    public void setImported(int imported) {
        this.imported = imported;
    }

    public int getOmitted() {
        return omitted;
    }

    public void setOmitted(int omitted) {
        this.omitted = omitted;
    }

    public Float getDsRw() {
        return dsRw;
    }

    public void setDsRw(Float dsRw) {
        this.dsRw = dsRw;
    }

    public Float getFngDs() {
        return fngDs;
    }

    public void setFngDs(Float fngDs) {
        this.fngDs = fngDs;
    }

    public Float getKgBls() {
        return kgBls;
    }

    public void setKgBls(Float kgBls) {
        this.kgBls = kgBls;
    }

    public Float getUnHa() {
        return unHa;
    }

    public void setUnHa(Float unHa) {
        this.unHa = unHa;
    }

    public Integer getDiasFlorCos() {
        return diasFlorCos;
    }

    public void setDiasFlorCos(Integer diasFlorCos) {
        this.diasFlorCos = diasFlorCos;
    }

    public Integer getDiasSiembraCos() {
        return diasSiembraCos;
    }

    public void setDiasSiembraCos(Integer diasSiembraCos) {
        this.diasSiembraCos = diasSiembraCos;
    }

    public Hybrid getHybrid() {
        return hybrid;
    }

    public void setHybrid(Hybrid hybrid) {
        this.hybrid = hybrid;
    }

    public String getCauses() {
        return causes;
    }

    public void setCauses(String causes) {
        this.causes = causes;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public List<CellOmittedDTO> getCellsOmitted() {
        return cellsOmitted;
    }

    public void setCellsOmitted(List<CellOmittedDTO> cellsOmitted) {
        this.cellsOmitted = cellsOmitted;
    }

    public void addImported() {
        this.imported++;
    }

    public void addOmitted() {
        this.omitted++;
    }

    public String getMegazone() {
        return megazone;
    }

    public void setMegazone(String megazone) {
        this.megazone = megazone;
    }
}
