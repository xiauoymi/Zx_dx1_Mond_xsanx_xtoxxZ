package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by EPESTE on 19/06/2014.
 */
@Entity
@Table(name = "MASTERDATA")
public class Masterdata implements Serializable {

    @Id
    @Column(name = "MASTERDATA_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_MASTERDATA")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generate_seq")
    private Integer id;

    @Column(name = "PROGRAM")
    private String program;

    @Column(name = "CERTIFICATION")
    private String certification;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "HYBRID_TYPE_ID")
    private HybridType hybridType;

    @Column(name = "DESTINATION")
    private String destination;

    @Column(name = "MANUFACTURE_CODE")
    private String manufactureCode;

    @Column(name = "FLOW_HARV_DAYS")
    private Integer flowHarvDays;

    @Column(name = "REL_PLANT_GROOVES")
    private String relationPlantGrooves;

    @Column(name = "PERCENTAGE_FEMALE")
    private Float percentageFemale;

    @Column(name = "TYPE_PROGRAM_UNIT")
    private String typeProgramUnit;//UM_PROGRAM

    @Column(name = "PROGRAM_UNIT")
    private Float programUnit;

    @Column(name = "TOTAL_UNIT")
    private Float totalUnit;


    @Column(name = "AREA_TOTAL")
    private Float areaTotal;

    @Column(name = "UN_HA")
    private Float unHa;


    @Column(name = "KG_RW_HA")
    private Float kgRWHa;

    @Column(name = "KG_DS_HA")
    private Float kgDSHa;

    @Column(name = "KG_FNG_HA")
    private Float kgFNGHa;

    @Column(name = "KG_BLS")
    private Float kgBls;

    @Column(name = "DS_RW")
    private Float dsRw;

    @Column(name = "FNG_DS")
    private Float fngDs;

    @Column(name = "BAGGING")
    private String bagging;

    @Column(name = "COMMERCIAL_UNIT")
    private String commercialUnit;

    @Column(name = "GRAN_PROGRAM")
    private String granProgram;

    @Column(name = "GERMOPLASMA")
    private String germoplasma;

    @ManyToOne
    @JoinColumn(name = "CAMPAIGN_ID")
    private Campaign campaign;

    @Column(name = "MEGA_ZONE")
    private String megaZone;

    @Column(name = "GDU50")
    private Float gdu50;

    @Column(name = "BRAND_CUSTOMER")
    private String brandCustomer;

    public String getMegaZone() {
        return megaZone;
    }

    public void setMegaZone(String megaZone) {
        this.megaZone = megaZone;
    }

    public Float getGdu50() {
        return gdu50;
    }

    public void setGdu50(Float gdu50) {
        this.gdu50 = gdu50;
    }

    public String getBrandCustomer() {
        return brandCustomer;
    }

    public void setBrandCustomer(String brandCustomer) {
        this.brandCustomer = brandCustomer;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public String getBagging() {
        return bagging;
    }

    public void setBagging(String bagging) {
        this.bagging = bagging;
    }

    public String getCommercialUnit() {
        return commercialUnit;
    }

    public void setCommercialUnit(String commercialUnit) {
        this.commercialUnit = commercialUnit;
    }

    public String getGranProgram() {
        return granProgram;
    }

    public void setGranProgram(String granProgram) {
        this.granProgram = granProgram;
    }

    public String getGermoplasma() {
        return germoplasma;
    }

    public void setGermoplasma(String germoplasma) {
        this.germoplasma = germoplasma;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public String getCertification() {
        return certification;
    }

    public void setCertification(String certification) {
        this.certification = certification;
    }

    public HybridType getHybridType() {
        return hybridType;
    }

    public void setHybridType(HybridType hybridType) {
        this.hybridType = hybridType;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getManufactureCode() {
        return manufactureCode;
    }

    public void setManufactureCode(String manufactureCode) {
        this.manufactureCode = manufactureCode;
    }

    public Integer getFlowHarvDays() {
        return flowHarvDays;
    }

    public void setFlowHarvDays(Integer flowHarvDays) {
        this.flowHarvDays = flowHarvDays;
    }


    public String getRelationPlantGrooves() {
        return relationPlantGrooves;
    }

    public void setRelationPlantGrooves(String relationPlantGrooves) {
        this.relationPlantGrooves = relationPlantGrooves;
    }

    public Float getPercentageFemale() {
        return percentageFemale;
    }

    public void setPercentageFemale(Float percentageFemale) {
        this.percentageFemale = percentageFemale;
    }

    public String getTypeProgramUnit() {
        return typeProgramUnit;
    }

    public void setTypeProgramUnit(String typeProgramUnit) {
        this.typeProgramUnit = typeProgramUnit;
    }

    public Float getProgramUnit() {
        return programUnit;
    }

    public void setProgramUnit(Float programUnit) {
        this.programUnit = programUnit;
    }

    public Float getTotalUnit() {
        return totalUnit;
    }

    public void setTotalUnit(Float totalUnit) {
        this.totalUnit = totalUnit;
    }


    public Float getAreaTotal() {
        return areaTotal;
    }

    public void setAreaTotal(Float areaTotal) {
        this.areaTotal = areaTotal;
    }

    public Float getUnHa() {
        return unHa;
    }

    public void setUnHa(Float unHa) {
        this.unHa = unHa;
    }


    public Float getKgRWHa() {
        return kgRWHa;
    }

    public void setKgRWHa(Float kgRWHa) {
        this.kgRWHa = kgRWHa;
    }

    public Float getKgDSHa() {
        return kgDSHa;
    }

    public void setKgDSHa(Float kgDSHa) {
        this.kgDSHa = kgDSHa;
    }

    public Float getKgFNGHa() {
        return kgFNGHa;
    }

    public void setKgFNGHa(Float kgFNGHa) {
        this.kgFNGHa = kgFNGHa;
    }

    public Float getKgBls() {
        return kgBls;
    }

    public void setKgBls(Float kgBls) {
        this.kgBls = kgBls;
    }

    public Float getDsRw() {
        return dsRw;
    }

    public void setDsRw(Float dsRw) {
        this.dsRw = dsRw;
    }

    public Float getFngDs() {
        return fngDs;
    }

    public void setFngDs(Float fngDs) {
        this.fngDs = fngDs;
    }

}
