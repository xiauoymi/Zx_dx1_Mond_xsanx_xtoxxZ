package com.monsanto.prisma.core.domain;


import javax.persistence.*;
import java.io.Serializable;

/**
 * Plant entity
 */
@Entity
@Table(name = "PLANT")
public class Plant implements Serializable {

    @Id
    @Column(name = "PLANT_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_PLANT")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "NAME")
    private String name;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "COUNTRY_ID")
    private Country country;

    public Plant() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }
}
