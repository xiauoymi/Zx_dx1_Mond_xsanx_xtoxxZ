package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.dto.LotHumidityDTO;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 07/07/2014.
 */
@Entity
@Table(name = "PREHARVEST_HUMIDITY")
public class PreHarvestHumidity {
    @Id
    @Column(name = "PREHARVEST_HUMIDITY_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_PREHARVEST_HUMIDITY")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "SOURCE_HUMIDITY_FILE")
    private String sourceHumidityFile;

    @Column(name = "DATE_PROCESS")
    private Date dateCreation;

    @Column(name = "CAMPAIGN_ID")
    @JoinColumn(name = "CAMPAIGN_ID")
    private Integer campaign;

    @Column(name = "IMPORTED")
    private int imported;
    @Column(name = "OMITTED")
    private int omitted;

    @Transient
    private List<LotHumidityDTO> lotHumidityDTOs;

    public List<LotHumidityDTO> getLotHumidityDTOs() {
        return lotHumidityDTOs;
    }

    public void setLotHumidityDTOs(List<LotHumidityDTO> lotHumidityDTOs) {
        this.lotHumidityDTOs = lotHumidityDTOs;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSourceHumidityFile() {
        return sourceHumidityFile;
    }

    public void setSourceHumidityFile(String sourceHumidityFile) {
        this.sourceHumidityFile = sourceHumidityFile;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public Integer getCampaign() {
        return campaign;
    }

    public void setCampaign(Integer campaign) {
        this.campaign = campaign;
    }

    public int getImported() {
        return imported;
    }

    public void setImported(int imported) {
        this.imported = imported;
    }

    public int getOmitted() {
        return omitted;
    }

    public void setOmitted(int omitted) {
        this.omitted = omitted;
    }
}
