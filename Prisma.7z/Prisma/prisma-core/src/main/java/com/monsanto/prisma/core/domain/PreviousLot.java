package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by PGSETT on 12/06/2014.
 */
@Entity
@Table(name = "PREVIOUS_LOT")
public class PreviousLot implements Serializable {
    @EmbeddedId
    private PreviousLotPK previousLotPK;

    public PreviousLot() {
        this.previousLotPK = new PreviousLotPK();
    }

    public Integer getActualLot() {
        return previousLotPK.getActualLot();
    }

    public void setActualLot(Integer actualLot) {
        previousLotPK.setActualLot(actualLot);
    }

    public Integer getPreviousLot() {
        return previousLotPK.getPreviousLot();
    }

    public void setPreviousLot(Integer previousLot) {
        previousLotPK.setPreviousLot(previousLot);
    }
}
