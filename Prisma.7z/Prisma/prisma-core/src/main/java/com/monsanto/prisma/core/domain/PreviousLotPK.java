package com.monsanto.prisma.core.domain;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class PreviousLotPK implements Serializable {

    @Column(name = "ACTUAL_ID")
    private Integer actualLot;

    @Column(name = "PREVIOUS_ID")
    private Integer previousLot;

    PreviousLotPK() {
    }

    PreviousLotPK(Integer actualLot, Integer previousLot) {
        this.actualLot = actualLot;
        this.previousLot = previousLot;
    }

    public Integer getActualLot() {
        return actualLot;
    }

    public void setActualLot(Integer actualLot) {
        this.actualLot = actualLot;
    }

    public Integer getPreviousLot() {
        return previousLot;
    }

    public void setPreviousLot(Integer previousLot) {
        this.previousLot = previousLot;
    }
}