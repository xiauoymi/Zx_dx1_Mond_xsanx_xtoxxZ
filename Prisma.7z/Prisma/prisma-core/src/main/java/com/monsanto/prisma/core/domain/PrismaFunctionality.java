package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by EPESTE on 10/09/2014.
 */
@Entity
@Table(name = "PRISMA_FUNCTIONALITY")
public class PrismaFunctionality implements Serializable {
    @Id
    @Column(name = "PRISMA_FUNCTIONALITY_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_PRISMA_FUNCTIONALITY")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "FUNCTIONALITY")
    private String functionality;

    @Column(name = "ACTION")
    private String action;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFunctionality() {
        return functionality;
    }

    public void setFunctionality(String functionality) {
        this.functionality = functionality;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}
