package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.dto.ProfileDTO;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * Created by EPESTE on 10/09/2014.
 */
@Entity
@Table(name = "PROFILE")
public class Profile implements Serializable {
    @Id
    @Column(name = "PROFILE_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_PROFILE")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "NAME")
    private String name;

    @Column(name = "ENABLED")
    private Boolean enabled;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinTable(name = "PROFILE_PRISMA_FUNCTIONALITY",
            joinColumns = {@JoinColumn(name = "PROFILE_ID", referencedColumnName = "PROFILE_ID", nullable = false, updatable = false)},
            inverseJoinColumns = {@JoinColumn(name = "PRISMA_FUNCTIONALITY_ID", referencedColumnName = "PRISMA_FUNCTIONALITY_ID", nullable = false, updatable = false)})
    private List<PrismaFunctionality> prismaFunctionalityList;

    public Profile() {
    }

    public Profile(ProfileDTO profileDTO) {
        setId(profileDTO.getId());
        setName(profileDTO.getName());
        setEnabled(profileDTO.getEnabled());
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public List<PrismaFunctionality> getPrismaFunctionalityList() {
        return prismaFunctionalityList;
    }

    public void setPrismaFunctionalityList(List<PrismaFunctionality> prismaFunctionalityList) {
        this.prismaFunctionalityList = prismaFunctionalityList;
    }
}
