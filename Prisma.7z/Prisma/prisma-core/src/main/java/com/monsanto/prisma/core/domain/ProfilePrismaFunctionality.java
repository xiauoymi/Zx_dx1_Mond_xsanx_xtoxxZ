package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by EPESTE on 10/09/2014.
 */
@Entity
@Table(name = "PROFILE_PRISMA_FUNCTIONALITY")
public class ProfilePrismaFunctionality implements Serializable {
    @EmbeddedId
    private ProfilePrismaFunctionalityPk profilePrismaFunctionalityPk;

    public ProfilePrismaFunctionality() {
    }

    public ProfilePrismaFunctionality(Integer profileId, Integer prismaFunctionalityId) {
        this.profilePrismaFunctionalityPk = new ProfilePrismaFunctionalityPk(profileId, prismaFunctionalityId);
    }

    public ProfilePrismaFunctionalityPk getProfilePrismaFunctionalityPk() {
        return profilePrismaFunctionalityPk;
    }

    public void setProfilePrismaFunctionalityPk(ProfilePrismaFunctionalityPk profilePrismaFunctionalityPk) {
        this.profilePrismaFunctionalityPk = profilePrismaFunctionalityPk;
    }
}
