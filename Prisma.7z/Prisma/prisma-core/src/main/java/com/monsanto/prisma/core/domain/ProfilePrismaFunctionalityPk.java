package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by EPESTE on 10/09/2014.
 */
@Embeddable
public class ProfilePrismaFunctionalityPk implements Serializable {
    @Column(name = "PROFILE_ID")
    private Integer profile;

    @Column(name = "PRISMA_FUNCTIONALITY_ID")
    private Integer prismaFunctionality;

    public ProfilePrismaFunctionalityPk() {
    }

    public ProfilePrismaFunctionalityPk(Integer profile, Integer prismaFunctionality) {
        this.profile = profile;
        this.prismaFunctionality = prismaFunctionality;
    }

    public Integer getProfile() {
        return profile;
    }

    public void setProfile(Integer profile) {
        this.profile = profile;
    }

    public Integer getPrismaFunctionality() {
        return prismaFunctionality;
    }

    public void setPrismaFunctionality(Integer prismaFunctionality) {
        this.prismaFunctionality = prismaFunctionality;
    }
}
