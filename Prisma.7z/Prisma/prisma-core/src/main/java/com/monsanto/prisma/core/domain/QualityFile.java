package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.dto.LotDTO;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by EPESTE on 29/07/2014.
 */
@Entity
@Table(name = "TAB_QUALITY")
public class QualityFile {

    @Id
    @Column(name = "TAB_QUALITY_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_TAB_QUALITY")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "CAMPAIGN_ID")
    private Integer campaignId;

    @Column(name = "PATH_FILE")
    private String pathFile;

    @Column(name = "DATE_PROCCESS")
    private Date dateProcess;

    @Column(name = "MODIFIED")
    private Integer lotsModified;

    @Column(name = "OMITTED")
    private Integer lotsNotModified;

    @Transient
    private List<LotDTO> lotDTOs;

    public QualityFile() {
        this.lotsModified = 0;
        this.lotsNotModified = 0;
        this.lotDTOs = new ArrayList<LotDTO>();
    }

    public void addLotModified() {
        this.lotsModified++;
    }

    public void addLotNotModified(String lotCode, String causes) {
        this.lotsNotModified++;
        this.lotDTOs.add(new LotDTO(lotCode, causes));
    }

    public void addLotNotModified(String lotCode, String causes, String rowCell) {
        this.lotsNotModified++;
        this.lotDTOs.add(new LotDTO(lotCode, causes, rowCell));
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPathFile() {
        return pathFile;
    }

    public void setPathFile(String pathFile) {
        this.pathFile = pathFile;
    }

    public Date getDateProcess() {
        return dateProcess;
    }

    public void setDateProcess(Date dateProcess) {
        this.dateProcess = dateProcess;
    }

    public Integer getLotsModified() {
        return lotsModified;
    }

    public void setLotsModified(Integer lotsModified) {
        this.lotsModified = lotsModified;
    }

    public Integer getLotsNotModified() {
        return lotsNotModified;
    }

    public void setLotsNotModified(Integer lotsNotModified) {
        this.lotsNotModified = lotsNotModified;
    }

    public List<LotDTO> getLotDTOs() {
        return lotDTOs;
    }

    public void setLotDTOs(List<LotDTO> lotDTOs) {
        this.lotDTOs = lotDTOs;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }
}
