package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.dto.LotDTO;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by EPESTE on 21/07/2014.
 */
@Entity
@Table(name = "REPORT1")
public class Report1 implements Serializable {

    @Id
    @Column(name = "REPORT1_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_REPORT1")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "CAMPAIGN_ID")
    private Integer campaignId;

    @Column(name = "PATH_FILE")
    private String pathFile;

    @Column(name = "DATE_PROCCESS")
    private Date dateProccess;

    @Column(name = "MODIFIED")
    private int modified;

    @Column(name = "OMITTED")
    private int omitted;

    @Transient
    private List<LotDTO> lotDTOs;

    public Report1() {
        lotDTOs = new ArrayList<LotDTO>();
    }

    public void addLotModified() {
        this.modified++;
    }

    public void addLotOmitted(String lotCode, String causes) {
        this.omitted++;
        lotDTOs.add(new LotDTO(lotCode, causes));
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public String getPathFile() {
        return pathFile;
    }

    public void setPathFile(String pathFile) {
        this.pathFile = pathFile;
    }

    public Date getDateProccess() {
        return dateProccess;
    }

    public void setDateProccess(Date dateProccess) {
        this.dateProccess = dateProccess;
    }

    public int getModified() {
        return modified;
    }

    public void setModified(int modified) {
        this.modified = modified;
    }

    public int getOmitted() {
        return omitted;
    }

    public void setOmitted(int omitted) {
        this.omitted = omitted;
    }

    public List<LotDTO> getLotDTOs() {
        return lotDTOs;
    }

    public void setLotDTOs(List<LotDTO> lotDTOs) {
        this.lotDTOs = lotDTOs;
    }
}
