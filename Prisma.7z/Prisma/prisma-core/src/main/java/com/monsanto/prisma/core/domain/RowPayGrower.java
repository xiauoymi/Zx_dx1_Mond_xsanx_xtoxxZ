package com.monsanto.prisma.core.domain;

/**
 * Created by PGSETT on 31/07/2014.
 */
public class RowPayGrower {
    private String lotCode;
    private Float pl;
    private Float pls;

    public RowPayGrower() {
        this.pl = new Float(0);
        this.pls = new Float(0);
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public Float getPl() {
        return pl;
    }

    public void setPl(Float pl) {
        this.pl = pl;
    }

    public Float getPls() {
        return pls;
    }

    public void setPls(Float pls) {
        this.pls = pls;
    }
}
