package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.utils.utilities.Constants;

import java.util.Date;

/**
 * Created by EPESTE on 22/07/2014.
 */
public class RowReport1 {
    private String lotCode;

    private Float harvestKgRwLot;

    private int trucks;

    private Integer center;

    private Date realRwReceiptDate;

    private String lastTruck;

    private String endLot;

    public RowReport1() {
        harvestKgRwLot = new Float(0);
    }

    public Date getRealRwReceiptDate() {
        return realRwReceiptDate;
    }

    public void setRealRwReceiptDate(Date realRwReceiptDate) {
        this.realRwReceiptDate = realRwReceiptDate;
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public Float getHarvestKgRwLot() {
        return harvestKgRwLot;
    }

    public void setHarvestKgRwLot(Float harvestKgRwLot) {
        this.harvestKgRwLot = harvestKgRwLot;
    }

    public int getTrucks() {
        return trucks;
    }

    public void setTrucks(int trucks) {
        this.trucks = trucks;
    }

    public Integer getCenter() {
        return center;
    }

    public void setCenter(Integer center) {
        this.center = center;
    }

    public Boolean getIsLotToProcess() {
        if (lastTruck != null && endLot != null && lastTruck.equals(Constants.REPORT_1_END_PROCESS_LOT) && endLot.equals(Constants.REPORT_1_END_PROCESS_LOT)) {
            return true;
        }
        return false;
    }

    public String getLastTruck() {
        return lastTruck;
    }

    public void setLastTruck(String lastTruck) {
        this.lastTruck = lastTruck;
    }

    public String getEndLot() {
        return endLot;
    }

    public void setEndLot(String endLot) {
        this.endLot = endLot;
    }
}
