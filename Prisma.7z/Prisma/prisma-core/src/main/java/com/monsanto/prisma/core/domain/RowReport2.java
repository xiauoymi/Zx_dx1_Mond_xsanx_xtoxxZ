package com.monsanto.prisma.core.domain;

import java.util.Date;

/**
 * Created by PGSETT on 28/07/2014.
 */
public class RowReport2 {
    private String lotCode;
    private Float huskingKgDsLot;
    private String warehouseUnitName;
    private Date realDsDate;
    private Boolean isLotToProcess;

    public RowReport2() {
        this.huskingKgDsLot = new Float(0);
        this.warehouseUnitName = "";
        this.isLotToProcess = false;
    }

    public Boolean getIsLotToProcess() {
        return isLotToProcess;
    }

    public void setIsLotToProcess(Boolean isLotToProcess) {
        this.isLotToProcess = isLotToProcess;
    }

    public Date getRealDsDate() {
        return realDsDate;
    }

    public void setRealDsDate(Date realDsDate) {
        this.realDsDate = realDsDate;
    }

    public String getWarehouseUnitName() {
        return warehouseUnitName;
    }

    public void setWarehouseUnitName(String warehouseUnitName) {
        this.warehouseUnitName = warehouseUnitName;
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public Float getHuskingKgDsLot() {
        return huskingKgDsLot;
    }

    public void setHuskingKgDsLot(Float huskingKgDsLot) {
        this.huskingKgDsLot = huskingKgDsLot;
    }
}
