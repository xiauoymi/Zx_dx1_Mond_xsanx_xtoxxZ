package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by BSBUON on 5/19/2014.
 */
@Entity
@Table(name = "SEASON")
public class Season implements Serializable {

    @Id
    @Column(name = "SEASON_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_SEASON")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "COUNTRY_ID")
    private Country country;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "CROP_ID")
    private Crop crop;

    @Column(name = "NAME")
    private String name;

    @Column(name = "MAX_CAMPAIGNS")
    private Integer maxCampaigns;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getMaxCampaigns() {
        return maxCampaigns;
    }

    public void setMaxCampaigns(Integer maxCampaigns) {
        this.maxCampaigns = maxCampaigns;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Season season = (Season) o;

        if (!country.equals(season.country)) return false;
        if (!crop.equals(season.crop)) return false;
        if (!id.equals(season.id)) return false;
        if (!maxCampaigns.equals(season.maxCampaigns)) return false;
        if (!name.equals(season.name)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id.hashCode();
        result = 31 * result + country.hashCode();
        result = 31 * result + crop.hashCode();
        result = 31 * result + name.hashCode();
        result = 31 * result + maxCampaigns.hashCode();
        return result;
    }
}
