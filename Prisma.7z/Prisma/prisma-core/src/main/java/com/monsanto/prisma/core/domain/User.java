package com.monsanto.prisma.core.domain;

import com.monsanto.prisma.core.dto.UserDTO;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * User Entity
 */
@Entity
@Table(name = "USERS")
public class User implements Serializable {

    @Id
    @Column(name = "USER_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_USERS")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Long id;

    @Column(name = "USER_NAME")
    private String userName;

    @Column(name = "ENABLED")
    private Boolean enabled;

    @Column(name = "FULL_NAME")
    private String fullName;

    @ManyToMany(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
    @JoinTable(name = "USERS_REGION", joinColumns = {
            @JoinColumn(name = "USER_ID", nullable = false, updatable = false)},
            inverseJoinColumns = {
                    @JoinColumn(name = "REGION_ID", nullable = false, updatable = false)})
    private List<Region> regions;

    @ManyToMany(cascade = CascadeType.DETACH)
    @LazyCollection(LazyCollectionOption.FALSE)
    @JoinTable(
            name = "USER_PROFILE",
            joinColumns = {@JoinColumn(name = "USER_ID", referencedColumnName = "USER_ID", nullable = false, updatable = false)},
            inverseJoinColumns = {@JoinColumn(name = "PROFILE_ID", referencedColumnName = "PROFILE_ID", nullable = false, updatable = false)})
    private List<Profile> profiles;

    public User() {

    }

    public User(UserDTO userDTO) {
        setUserName(userDTO.getUserName());
        setFullName(userDTO.getFullName());
        setEnabled(userDTO.getEnabled());
    }

    public User(String userName) {
        this.userName = userName;
        this.enabled = true;
    }

    /**
     * Creates a new user instance.
     */
    public User(Long id) {
        this.setId(id);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public List<Region> getRegions() {
        return regions;
    }

    public void setRegions(List<Region> regions) {
        this.regions = regions;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        User user = (User) o;

        if (enabled != null ? !enabled.equals(user.enabled) : user.enabled != null) return false;
        if (fullName != null ? !fullName.equals(user.fullName) : user.fullName != null) return false;
        if (!id.equals(user.id)) return false;
        if (userName != null ? !userName.equals(user.userName) : user.userName != null) return false;

        return true;
    }

    public List<Profile> getProfiles() {
        return profiles;
    }

    public void setProfiles(List<Profile> profiles) {
        this.profiles = profiles;
    }
}
