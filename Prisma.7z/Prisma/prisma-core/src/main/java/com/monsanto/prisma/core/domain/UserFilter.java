package com.monsanto.prisma.core.domain;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.dto.FilterDTO;
import com.monsanto.prisma.core.dto.UserFilterDTO;

import javax.annotation.Nullable;
import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by epeste on 29/10/2014.
 */
@Entity
@Table(name = "USER_FILTER")
public class UserFilter implements Serializable {
    @Id
    @Column(name = "USER_FILTER_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_USER_FILTER")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "generate_seq")
    private Integer id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "USER_ID")
    private User user;

    private String name;

    private String description;

    @OneToMany(mappedBy = "userFilter", fetch = FetchType.EAGER, orphanRemoval = true)
    private List<Filter> filterList;

    public UserFilter() {
    }

    public UserFilter(UserFilterDTO userFilterDTO) {
        setName(userFilterDTO.getName());
        setDescription(userFilterDTO.getDescription());
        this.filterList = Lists.transform(userFilterDTO.getFilterList(), new Function<FilterDTO, Filter>() {
            @Nullable
            @Override
            public Filter apply(@Nullable FilterDTO filterDTO) {
                return new Filter(filterDTO);
            }
        });
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Filter> getFilterList() {
        return filterList;
    }

    public void setFilterList(List<Filter> filterList) {
        this.filterList = filterList;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
