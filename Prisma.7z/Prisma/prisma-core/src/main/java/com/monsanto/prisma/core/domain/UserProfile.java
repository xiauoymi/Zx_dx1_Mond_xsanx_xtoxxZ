package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by EPESTE on 10/09/2014.
 */
@Entity
@Table(name = "USER_PROFILE")
public class UserProfile implements Serializable {
    @EmbeddedId
    private UserProfilePk userProfilePk;

    public UserProfile() {
    }

    public UserProfile(Integer userId, Integer profileId) {
        userProfilePk = new UserProfilePk(userId, profileId);
    }

    public UserProfilePk getUserProfilePk() {
        return userProfilePk;
    }

    public void setUserProfilePk(UserProfilePk userProfilePk) {
        this.userProfilePk = userProfilePk;
    }
}
