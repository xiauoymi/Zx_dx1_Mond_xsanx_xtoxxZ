package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by EPESTE on 10/09/2014.
 */
@Embeddable
public class UserProfilePk implements Serializable {
    @Column(name = "USER_ID")
    private Integer user;

    @Column(name = "PROFILE_ID")
    private Integer profile;

    public UserProfilePk() {
    }

    public UserProfilePk(Integer user, Integer profile) {
        setUser(user);
        setProfile(profile);
    }

    public Integer getUser() {
        return user;
    }

    public void setUser(Integer user) {
        this.user = user;
    }

    public Integer getProfile() {
        return profile;
    }

    public void setProfile(Integer profile) {
        this.profile = profile;
    }
}
