package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by EPESTE on 12/09/2014.
 */
@Entity
@Table(name = "USERS_REGION")
public class UsersRegion implements Serializable {

    @Id
    @Column(name = "USER_REGION_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_USERS_REGION")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;

    @Column(name = "USER_ID")
    private Integer user;

    @Column(name = "REGION_ID")
    private Integer region;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUser() {
        return user;
    }

    public void setUser(Integer user) {
        this.user = user;
    }

    public Integer getRegion() {
        return region;
    }

    public void setRegion(Integer region) {
        this.region = region;
    }
}
