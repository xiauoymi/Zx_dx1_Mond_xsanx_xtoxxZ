package com.monsanto.prisma.core.domain;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by PGSETT on 15/05/2014.
 */
@Entity
@Table(name = "ZONE")
public class Zone implements Serializable {

    @Id
    @Column(name = "ZONE_ID")
    @SequenceGenerator(name = "generate_seq", sequenceName = "SEQ_ZONE")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "generate_seq")
    private Integer id;
    @Column(name = "CODE")
    private String code;
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "AREA_ID")
    private Area area;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }
}
