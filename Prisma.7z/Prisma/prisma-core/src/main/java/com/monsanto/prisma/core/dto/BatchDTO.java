package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.Batch;
import com.monsanto.prisma.core.domain.IBatch;
import com.monsanto.prisma.core.domain.LotBatch;
import org.apache.log4j.Logger;
import org.hibernate.LazyInitializationException;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;


/**
 * Created by BSBUON on 22/07/2014.
 */
public class BatchDTO implements IBatch {

    private static Logger log = Logger.getLogger(BatchDTO.class);

    private Integer id;
    private Integer campaignId;
    private String campaignName;
    private Integer hybridId;
    private String hybridName;
    private String name;
    private Float kgDS;
    private Float kgFNG;
    private Integer bagProduced;
    private List<LotBatchDTO> lotBatches;
    private Date realFngInit;
    private Date realFngEnd;
    private Float totalKgCullTower;

    public BatchDTO() {
        this.id = null;
        this.campaignId = null;
        this.campaignName = "";
        this.hybridId = null;
        this.hybridName = "";
        this.name = "";
        this.kgDS = 0F;
        this.kgFNG = 0F;
        this.bagProduced = 0;
        this.lotBatches = new ArrayList<LotBatchDTO>();
    }


    public BatchDTO(Batch batch) {
        this(batch, false);
    }

    public BatchDTO(Batch batch, boolean withChildren) {
        this.id = batch.getId();
        this.name = batch.getName();
        this.campaignId = batch.getCampaign().getId();
        this.campaignName = batch.getCampaign().getName();
        this.hybridId = batch.getHybrid().getId();
        this.hybridName = batch.getHybrid().getName();
        this.kgDS = batch.getKgDS();
        this.kgFNG = batch.getKgFNG();
        this.bagProduced = batch.getBagProduced();
        this.realFngInit = batch.getRealFngInit();
        this.realFngEnd = batch.getRealFngEnd();
        this.lotBatches = new ArrayList<LotBatchDTO>();
        this.totalKgCullTower = batch.getTotalKgCullTower();
        try {
            if (withChildren) {
                for (LotBatch lotBatch : batch.getLotBatches()) {
                    LotBatchDTO lotBatchDTO = new LotBatchDTO(lotBatch);
                    this.lotBatches.add(lotBatchDTO);
                }
            }
        } catch (LazyInitializationException e) {
            log.warn("This query contains lazy lots associated.");
        }
    }

    public Float getTotalKgCullTower() {
        return totalKgCullTower;
    }

    public void setTotalKgCullTower(Float totalKgCullTower) {
        this.totalKgCullTower = totalKgCullTower;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public String getCampaignName() {
        return campaignName;
    }

    public void setCampaignName(String campaignName) {
        this.campaignName = campaignName;
    }

    public Integer getHybridId() {
        return hybridId;
    }

    public void setHybridId(Integer hybridId) {
        this.hybridId = hybridId;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Float getKgDS() {
        return kgDS;
    }

    public void setKgDS(Float kgDS) {
        this.kgDS = kgDS;
    }

    public Float getKgFNG() {
        return kgFNG;
    }

    public void setKgFNG(Float kgFNG) {
        this.kgFNG = kgFNG;
    }

    public Integer getBagProduced() {
        return bagProduced;
    }

    public void setBagProduced(Integer bagProduced) {
        this.bagProduced = bagProduced;
    }

    public List<LotBatchDTO> getLotBatches() {
        return lotBatches;
    }

    public void setLotBatches(List<LotBatchDTO> lotBatches) {
        this.lotBatches = lotBatches;
    }

    public Date getRealFngInit() {
        return realFngInit;
    }

    public void setRealFngInit(Date realFngInit) {
        this.realFngInit = realFngInit;
    }

    public Date getRealFngEnd() {
        return realFngEnd;
    }

    public void setRealFngEnd(Date realFngEnd) {
        this.realFngEnd = realFngEnd;
    }

    @Override
    public List<Integer> getAssociatedLotIds() {
        List<Integer> result = new LinkedList<Integer>();
        for (LotBatchDTO lotBatchDTO : lotBatches) {
            result.add(lotBatchDTO.getLot().getId());
        }
        return result;
    }
}
