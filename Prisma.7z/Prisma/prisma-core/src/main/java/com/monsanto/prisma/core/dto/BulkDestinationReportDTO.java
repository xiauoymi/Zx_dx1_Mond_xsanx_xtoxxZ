package com.monsanto.prisma.core.dto;

/**
 * Created by PGSETT on 08/09/2014.
 */
public class BulkDestinationReportDTO {

    private String warehouseUnit;
    private String hybridName;
    private Double huskingKgDsLot;

    public BulkDestinationReportDTO(Object[] objects) {
        this.warehouseUnit = (String) objects[0];
        this.hybridName = (String) objects[1];
        this.huskingKgDsLot = (Double) objects[2];
    }

    public String getWarehouseUnit() {
        return warehouseUnit;
    }

    public void setWarehouseUnit(String warehouseUnit) {
        this.warehouseUnit = warehouseUnit;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public Double getHuskingKgDsLot() {
        return huskingKgDsLot;
    }

    public void setHuskingKgDsLot(Double huskingKgDsLot) {
        this.huskingKgDsLot = huskingKgDsLot;
    }
}
