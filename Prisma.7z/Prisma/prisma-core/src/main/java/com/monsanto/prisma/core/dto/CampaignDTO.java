package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.Campaign;

import java.io.Serializable;

/**
 * DTO of Campaign
 * User: BSBUON
 * Date: 12/05/14
 * Time: 13:40
 * To change this template use File | Settings | File Templates.
 */
public class CampaignDTO implements Serializable {

    private Integer id;
    private Integer regionId;
    private String regionCode;
    private Integer countryId;
    private String countryName;
    private Integer cropId;
    private String cropName;
    private String name;
    private String campaignCode;
    private Boolean isActive;
    private Boolean isReal;
    private String filePath;
    private String observations;
    private Boolean containsLots;

    public CampaignDTO(Integer id, Integer regionId, String regionCode, Integer countryId, String countryName, Integer cropId, String cropName, String name, String campaignCode, Boolean isActive, Boolean isReal) {
        this.id = id;
        this.regionId = regionId;
        this.regionCode = regionCode;
        this.countryId = countryId;
        this.countryName = countryName;
        this.cropId = cropId;
        this.cropName = cropName;
        this.name = name;
        this.campaignCode = campaignCode;
        this.isActive = isActive;
        this.isReal = isReal;
    }

    public CampaignDTO(Campaign campaign, Boolean containsLots){
        this(campaign);
        this.containsLots = containsLots;
    }

    public CampaignDTO(Campaign campaign) {
        this.id = campaign.getId();
        this.regionId = campaign.getSeason().getCountry().getRegion().getId();
        this.regionCode = campaign.getSeason().getCountry().getRegion().getName();
        this.countryId = campaign.getSeason().getCountry().getId();
        this.countryName = campaign.getSeason().getCountry().getName();
        this.cropId = campaign.getCrop().getId();
        this.cropName = campaign.getCrop().getName();
        this.name = campaign.getName();
        this.campaignCode = campaign.getCode();
        this.isActive = campaign.getIsActive();
        this.isReal = campaign.getIsReal();
        this.filePath = campaign.getFilePath();
        this.observations = campaign.getObservations()!=null ? campaign.getObservations() : "";
    }

    public CampaignDTO() {

    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRegionId() {
        return regionId;
    }

    public void setRegionId(Integer regionId) {
        this.regionId = regionId;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public Integer getCountryId() {
        return countryId;
    }

    public void setCountryId(Integer countryId) {
        this.countryId = countryId;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public Integer getCropId() {
        return cropId;
    }

    public void setCropId(Integer cropId) {
        this.cropId = cropId;
    }

    public String getCropName() {
        return cropName;
    }

    public void setCropName(String cropName) {
        this.cropName = cropName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCampaignCode() {
        return campaignCode;
    }

    public void setCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Boolean getIsReal() {
        return isReal;
    }

    public void setIsReal(Boolean isReal) {
        this.isReal = isReal;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }

    public Boolean getContainsLots() {
        return containsLots;
    }

    public void setContainsLots(Boolean containsLots) {
        this.containsLots = containsLots;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CampaignDTO that = (CampaignDTO) o;

        if (campaignCode != null ? !campaignCode.equals(that.campaignCode) : that.campaignCode != null) return false;
        if (countryId != null ? !countryId.equals(that.countryId) : that.countryId != null) return false;
        if (countryName != null ? !countryName.equals(that.countryName) : that.countryName != null) return false;
        if (cropId != null ? !cropId.equals(that.cropId) : that.cropId != null) return false;
        if (cropName != null ? !cropName.equals(that.cropName) : that.cropName != null) return false;
        if (filePath != null ? !filePath.equals(that.filePath) : that.filePath != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (isActive != null ? !isActive.equals(that.isActive) : that.isActive != null) return false;
        if (isReal != null ? !isReal.equals(that.isReal) : that.isReal != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (observations != null ? !observations.equals(that.observations) : that.observations != null) return false;
        if (regionCode != null ? !regionCode.equals(that.regionCode) : that.regionCode != null) return false;
        if (regionId != null ? !regionId.equals(that.regionId) : that.regionId != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (regionId != null ? regionId.hashCode() : 0);
        result = 31 * result + (regionCode != null ? regionCode.hashCode() : 0);
        result = 31 * result + (countryId != null ? countryId.hashCode() : 0);
        result = 31 * result + (countryName != null ? countryName.hashCode() : 0);
        result = 31 * result + (cropId != null ? cropId.hashCode() : 0);
        result = 31 * result + (cropName != null ? cropName.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (campaignCode != null ? campaignCode.hashCode() : 0);
        result = 31 * result + (isActive != null ? isActive.hashCode() : 0);
        result = 31 * result + (isReal != null ? isReal.hashCode() : 0);
        result = 31 * result + (filePath != null ? filePath.hashCode() : 0);
        result = 31 * result + (observations != null ? observations.hashCode() : 0);
        return result;
    }
}
