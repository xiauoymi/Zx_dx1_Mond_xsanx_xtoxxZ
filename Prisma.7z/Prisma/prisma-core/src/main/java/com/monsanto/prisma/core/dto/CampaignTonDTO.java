package com.monsanto.prisma.core.dto;

import java.util.Date;

/**
 * Created by EPESTE on 26/08/2014.
 */
public class CampaignTonDTO {
    private Integer establishmentId;

    private Integer zoneId;
    private String zoneName;

    private Float harvestRealWeekFrom;

    private Date harvestDateFrom;

    private Float harvestRealWeekTo;

    private Date harvestDateTo;

    private String program;

    private Integer hybridId;
    private String hybridName;

    private Integer campaignId;

    private String warehouseUnit;

    private String lotCode;

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public String getZoneName() {
        return zoneName;
    }

    public void setZoneName(String zoneName) {
        this.zoneName = zoneName;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public String getWarehouseUnit() {
        return warehouseUnit;
    }

    public void setWarehouseUnit(String warehouseUnit) {
        this.warehouseUnit = warehouseUnit;
    }

    public Integer getHybridId() {
        return hybridId;
    }

    public void setHybridId(Integer hybridId) {
        this.hybridId = hybridId;
    }

    public Float getHarvestRealWeekFrom() {
        return harvestRealWeekFrom;
    }

    public Float getHarvestRealWeekTo() {
        return harvestRealWeekTo;
    }

    public void setHarvestRealWeekFrom(Float harvestRealWeekFrom) {
        this.harvestRealWeekFrom = harvestRealWeekFrom;
    }

    public void setHarvestRealWeekTo(Float harvestRealWeekTo) {
        this.harvestRealWeekTo = harvestRealWeekTo;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public Integer getEstablishmentId() {
        return establishmentId;
    }

    public void setEstablishmentId(Integer establishmentId) {
        this.establishmentId = establishmentId;
    }

    public Integer getZoneId() {
        return zoneId;
    }

    public void setZoneId(Integer zoneId) {
        this.zoneId = zoneId;
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public Date getHarvestDateFrom() {
        return harvestDateFrom;
    }

    public void setHarvestDateFrom(Date harvestDateFrom) {
        this.harvestDateFrom = harvestDateFrom;
    }

    public Date getHarvestDateTo() {
        return harvestDateTo;
    }

    public void setHarvestDateTo(Date harvestDateTo) {
        this.harvestDateTo = harvestDateTo;
    }
}
