package com.monsanto.prisma.core.dto;

import java.util.List;

/**
 * Created by AFREI on 09/09/2014.
 */
public class CellOmittedDTO {

    private String cellName;

    private String cause;

    public CellOmittedDTO(String cellName, String cause) {
        this.cellName = cellName;
        this.cause = cause;
    }

    public String getCellName() {
        return cellName;
    }

    public void setCellName(String cellName) {
        this.cellName = cellName;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }
}
