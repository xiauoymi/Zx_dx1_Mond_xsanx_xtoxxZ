package com.monsanto.prisma.core.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by EPESTE on 11/12/2014.
 */
public class DataReportForecastDTO implements Serializable {
    private String granProgram;

    private String realDate;

    private Double totalReal;

    private String estimatedDate;

    private Double totalEstimated;

    public DataReportForecastDTO(Object[] object) {
        this.granProgram = (String) object[0];
        if (object[1] != null) {
            this.realDate = (String) object[1];
        }
        if (object[2] != null) {
            this.totalReal = (Double) object[2];
        }
        if (object[3] != null) {
            this.estimatedDate = (String) object[3];
        }
        if (object[4] != null) {
            this.totalEstimated = (Double) object[4];
        }
    }

    public String getGranProgram() {
        return granProgram;
    }

    public void setGranProgram(String granProgram) {
        this.granProgram = granProgram;
    }

    public String getRealDate() {
        return realDate;
    }

    public void setRealDate(String realDate) {
        this.realDate = realDate;
    }

    public Double getTotalReal() {
        return totalReal;
    }

    public void setTotalReal(Double totalReal) {
        this.totalReal = totalReal;
    }

    public String getEstimatedDate() {
        return estimatedDate;
    }

    public void setEstimatedDate(String estimatedDate) {
        this.estimatedDate = estimatedDate;
    }

    public Double getTotalEstimated() {
        return totalEstimated;
    }

    public void setTotalEstimated(Double totalEstimated) {
        this.totalEstimated = totalEstimated;
    }
}
