package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.Establishment;

import java.io.Serializable;

/**
 * Created by BSBUON on 7/7/2014.
 */
public class EstablishmentDTO implements Serializable{

    private Integer id;
    private String name;

    public EstablishmentDTO() {

    }

    public EstablishmentDTO(Establishment establishment) {
        this.id = establishment.getId();
        this.name = establishment.getName();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
