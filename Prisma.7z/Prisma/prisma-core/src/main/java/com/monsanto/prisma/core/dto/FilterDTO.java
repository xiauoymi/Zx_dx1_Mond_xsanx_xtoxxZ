package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.Filter;

import java.io.Serializable;

/**
 * Created by EPESTE on 31/10/2014.
 */
public class FilterDTO implements Serializable {

    private Integer id;

    private Integer field;

    private String value;

    private Integer typeField;

    public FilterDTO() {
    }

    public FilterDTO(Filter filter) {
        this.id = filter.getIdFilter();
        this.field = filter.getField();
        this.value = filter.getValue();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getField() {
        return field;
    }

    public void setField(Integer field) {
        this.field = field;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public Integer getTypeField() {
        return typeField;
    }

    public void setTypeField(Integer typeField) {
        this.typeField = typeField;
    }

    public String appyTypeToValue() {

        if (value.isEmpty()) {
            return value;
        }

        if (this.typeField == 2) {
            return "TO_NUMBER('" + value + "')";
        }

        if (this.typeField == 3) {
            return "TO_DATE('" + value + "','DD/MM/YY')";
        }

        return this.value;
    }
}
