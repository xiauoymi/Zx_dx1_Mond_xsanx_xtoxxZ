package com.monsanto.prisma.core.dto;

import java.io.Serializable;

/**
 * Created by EPESTE on 04/12/2014.
 */
public class ForecastDTO implements Serializable {
    private Integer campaign;

    private Integer daysRw;

    private Integer daysDs;

    public Integer getCampaign() {
        return campaign;
    }

    public void setCampaign(Integer campaign) {
        this.campaign = campaign;
    }

    public Integer getDaysRw() {
        return daysRw;
    }

    public void setDaysRw(Integer daysRw) {
        this.daysRw = daysRw;
    }

    public Integer getDaysDs() {
        return daysDs;
    }

    public void setDaysDs(Integer daysDs) {
        this.daysDs = daysDs;
    }
}
