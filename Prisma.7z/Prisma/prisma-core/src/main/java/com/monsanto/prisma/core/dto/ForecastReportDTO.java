package com.monsanto.prisma.core.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by EPESTE on 10/12/2014.
 */
public class ForecastReportDTO implements Serializable {
    private List<Date> range;

    private List<DataReportForecastDTO> rwForecastDTOs;

    private List<DataReportForecastDTO> dsForecastDTOs;

    private List<DataReportForecastDTO> fngForecastDTOs;

    public List<Date> getRange() {
        return range;
    }

    public void setRange(List<Date> range) {
        this.range = range;
    }

    public List<DataReportForecastDTO> getRwForecastDTOs() {
        return rwForecastDTOs;
    }

    public void setRwForecastDTOs(List<DataReportForecastDTO> rwForecastDTOs) {
        this.rwForecastDTOs = rwForecastDTOs;
    }

    public List<DataReportForecastDTO> getDsForecastDTOs() {
        return dsForecastDTOs;
    }

    public void setDsForecastDTOs(List<DataReportForecastDTO> dsForecastDTOs) {
        this.dsForecastDTOs = dsForecastDTOs;
    }

    public List<DataReportForecastDTO> getFngForecastDTOs() {
        return fngForecastDTOs;
    }

    public void setFngForecastDTOs(List<DataReportForecastDTO> fngForecastDTOs) {
        this.fngForecastDTOs = fngForecastDTOs;
    }
}

