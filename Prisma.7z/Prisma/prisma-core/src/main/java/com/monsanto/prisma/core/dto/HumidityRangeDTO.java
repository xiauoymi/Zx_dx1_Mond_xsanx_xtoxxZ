package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.HumidityRange;

import java.io.Serializable;

/**
 * Created by PGSETT on 26/06/2014.
 */
public class HumidityRangeDTO implements Serializable {

    private Integer id;
    private Double humidityMin;
    private Double humidityMax;
    private Integer hybridId;
    private String hybridName;
    private Integer zoneId;
    private String zoneCode;

    public HumidityRangeDTO() {
    }

    public HumidityRangeDTO(HumidityRange humidityRange) {
        this.id = humidityRange.getId();
        this.humidityMin = humidityRange.getHumidityMin();
        this.humidityMax = humidityRange.getHumidityMax();
        if (humidityRange.getHybrid() != null) {
            this.hybridId = humidityRange.getHybrid().getId();
            this.hybridName = humidityRange.getHybrid().getName();
        }
        if (humidityRange.getZone() != null) {
            this.zoneId = humidityRange.getZone().getId();
            this.zoneCode = humidityRange.getZone().getCode();
        }
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Double getHumidityMin() {
        return humidityMin;
    }

    public void setHumidityMin(Double humidityMin) {
        this.humidityMin = humidityMin;
    }

    public Double getHumidityMax() {
        return humidityMax;
    }

    public void setHumidityMax(Double humidityMax) {
        this.humidityMax = humidityMax;
    }

    public Integer getHybridId() {
        return hybridId;
    }

    public void setHybridId(Integer hybridId) {
        this.hybridId = hybridId;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public Integer getZoneId() {
        return zoneId;
    }

    public void setZoneId(Integer zoneId) {
        this.zoneId = zoneId;
    }

    public String getZoneCode() {
        return zoneCode;
    }

    public void setZoneCode(String zoneCode) {
        this.zoneCode = zoneCode;
    }
}
