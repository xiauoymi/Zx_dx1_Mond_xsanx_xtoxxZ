package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.HumidityReport;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by EPESTE on 22/08/2014.
 */
public class HumidityReportDTO implements Serializable {
    private String pathFile;

    private Date dateProccess;

    private int modified;

    private int omitted;

    public HumidityReportDTO() {
    }

    public HumidityReportDTO(HumidityReport humidityReport) {
        this.pathFile = humidityReport.getPathFile();
        this.dateProccess = humidityReport.getDateProccess();
        this.modified = humidityReport.getModified();
        this.omitted = humidityReport.getOmitted();
    }

    public String getPathFile() {
        return pathFile;
    }

    public Date getDateProccess() {
        return dateProccess;
    }

    public int getModified() {
        return modified;
    }

    public int getOmitted() {
        return omitted;
    }
}
