package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.Crop;
import com.monsanto.prisma.core.domain.Hybrid;
import com.monsanto.prisma.core.domain.HybridType;

import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Created by EPESTE on 23/06/2014.
 */
public class HybridDTO implements Serializable {
    private Integer id;

    private String name;

    private HybridType hybridType;

    private Crop crop;

    public HybridDTO() {
    }

    public HybridDTO(Hybrid hybrid) {
        this.id = hybrid.getId();
        this.name = hybrid.getName();
        this.hybridType = hybrid.getHybridType();
        this.crop = hybrid.getCrop();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public HybridType getHybridType() {
        return hybridType;
    }

    public void setHybridType(HybridType hybridType) {
        this.hybridType = hybridType;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
