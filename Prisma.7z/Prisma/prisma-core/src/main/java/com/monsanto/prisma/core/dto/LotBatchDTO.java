package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.LotBatch;

import java.io.Serializable;

/**
 * Created by BSBUON on 23/07/2014.
 */
public class LotBatchDTO implements Serializable {

    private LotDTO lot;
    private BatchDTO batch;
    private Float kgDSLotAssigned;
    private Float kgFNGLotAssigned;
    private Float bagLotAssigned;
    private Boolean isDeleted;
    private Float kgCullTower;

    public LotBatchDTO() {
    }

    public LotBatchDTO(LotBatch lotbatch) {
        this.lot = new LotDTO(lotbatch.getLot(), false);
        if (lotbatch.getBatch() != null) {
            this.batch = new BatchDTO(lotbatch.getBatch());
        } else {
            this.batch = new BatchDTO();
        }
        this.kgDSLotAssigned = lotbatch.getKgDSLotAssigned();
        this.kgFNGLotAssigned = lotbatch.getKgFNGLotAssigned();
        this.bagLotAssigned = lotbatch.getBagLotAssigned();
        this.kgCullTower = lotbatch.getKgCullTower();
    }

    public Float getKgCullTower() {
        return kgCullTower;
    }

    public void setKgCullTower(Float kgCullTower) {
        this.kgCullTower = kgCullTower;
    }

    public LotDTO getLot() {
        return lot;
    }

    public void setLot(LotDTO lot) {
        this.lot = lot;
    }

    public BatchDTO getBatch() {
        return batch;
    }

    public void setBatch(BatchDTO batch) {
        this.batch = batch;
    }

    public Float getKgDSLotAssigned() {
        return kgDSLotAssigned;
    }

    public void setKgDSLotAssigned(Float kgDSLotAssigned) {
        this.kgDSLotAssigned = kgDSLotAssigned;
    }

    public Float getKgFNGLotAssigned() {
        return kgFNGLotAssigned;
    }

    public void setKgFNGLotAssigned(Float kgFNGLotAssigned) {
        this.kgFNGLotAssigned = kgFNGLotAssigned;
    }

    public Boolean isDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Boolean isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Float getBagLotAssigned() {
        return bagLotAssigned;
    }

    public void setBagLotAssigned(Float bagLotAssigned) {
        this.bagLotAssigned = bagLotAssigned;
    }

}
