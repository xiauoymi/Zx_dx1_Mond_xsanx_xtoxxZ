package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.domain.LotCombo;

import java.io.Serializable;

/**
 * Created by BSBUON on 12/09/2014.
 */
public class LotComboDTO implements Serializable {

    private Integer id;
    private Integer hybridId;
    private String lotCode;
    private Float actualKgDsBalance;

    public LotComboDTO (){

    }

    public LotComboDTO(Lot lot){
        this.id = lot.getId();
        this.hybridId = lot.getHybrid().getId();
        this.lotCode = lot.getLotCode();
        this.actualKgDsBalance = lot.getActualKgDsBalance();
    }

    public LotComboDTO(LotCombo lot){
        this.id = lot.getId();
        this.lotCode = lot.getLotCode();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getHybridId() {
        return hybridId;
    }

    public void setHybridId(Integer hybridId) {
        this.hybridId = hybridId;
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public Float getActualKgDsBalance() {
        return actualKgDsBalance;
    }

    public void setActualKgDsBalance(Float actualKgDsBalance) {
        this.actualKgDsBalance = actualKgDsBalance;
    }
}
