package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.domain.PreviousLot;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 14/05/2014.
 */
public class LotDTO implements Serializable {
    private Integer id;
    private String lotCode;
    private Integer establishmentId;
    private String establishmentName;
    private String zoneCode;

    private Integer hybridId;
    private String hybridName;
    private String hybridTypeName;
    private Float registeredHas;
    private Float harvestableHas;
    private String certification;
    private String expediente;
    private String program;
    private String color;
    private Integer plantingWeek;
    private String sourceLotFile;
    private String sourceMasterfile;
    private Boolean isReplaced;
    private String user;
    private Float targetKgBag;

    private Float targetRwToDs;
    private Float targetDsToFng;
    private Float targetBagLot;
    private Float targetBagHa;
    private Float diasFlorCos;

    private Date estimatedHarvestDate;
    private Float targetTnRwLot;
    private Float targetTnDsLot;
    private Float targetKgsDsHa;
    private Float porcActualObjetiveTargetDs;
    private Float harvKgFngEstLotRw;
    private Float actualTnDsLot;
    private Float actualTnFngLot;
    private Float eficienciaEstUnField;
    private Float harvKgDsLotEstRw;
    private Float harvKgDsHaEstRw;
    private Float actualTnRwLot;
    private Float targetLot;
    private Float porcentActualObjectiveUnTarget;
    private Date plantingDate;
    private Date estimatedPlantingDate;
    private Date realPlantingDate;
    private Integer gdu;
    private Date estimatedFloweringDate;
    private Date harvestDateForHumidity;
    private Integer rw;
    private String observation;
    private String campaignName;
    private Date realFloweringDate;
    private Date realHarvestDate;
    private Date floweringDate;
    private Date harvestDate;
    private Float harvestWeek;
    private Float estimatedKgDsHa;
    private String obsEstimatedKgDsHa;
    private Float actualKgDsHa;
    private Float actualBagLot;
    private Integer plantFlowDays;
    private Integer flowHarvDays;
    private String file;
    private List<LotSelectedDTO> selectedLots;
    private List<Integer> previousLot;
    private Float harvestKgRWLot;
    private String causes;
    private Float harvestRwToDs;
    private String obsHarvestRwToDs;
    private Float huskingKgDsLot;
    private String obsHuskingKgDsLot;
    private Float huskingKgDsHa;
    private Float qualityKgFngLot;
    private Float greenConversion;
    private Float eficienciaRwToDs;
    private Float actualKgDsLot;
    private Float actualTnDsHa;
    private Float qualityDsToFng;
    private String qualityObs;
    private Float qualityWeightBag;
    private Float eficienciaDsToFng;
    private String warehouseUnit;
    private Float actualKgFngLot;
    private Float plsLot;
    private Float indexLot;
    private Float plLot;
    private Float bulkConversion;
    private Float eficienciaKgDescarte;
    private Float humidity;
    private Float actualKgDsBalance;
    private Date sampleDateHumidity;
    private Float actualWeightBagLot;
    private String obsLine;
    private String generalObs;

    private Float bulkBagEst;

    private Boolean isHybridModified;
    private Boolean isMegazoneModified;
    private String errorDetail;

    List<CellOmittedDTO> omittedCells;

    private Integer countEstimatedKgDsHa;

//    private List<LotBatchDTO> lotBatches;

    private Integer trucks;

    private Float averageHumidity;

    private Float weightAverageTruck;

    private String receptionPlant;

    private String megazone;

    private Float totalKgCullTower;

    private String client;

    private String germoplasma;

    private String granProgram;

    private Date realRwReceiptDate;
    private Date realDsDate;
    private Date estimatedRwDate;
    private Date estimatedDsDate;

    private Date estimatedFngInit;

    private Date estimatedFngEnd;

    private Date realFngInit;
    private Date realFngEnd;

    public LotDTO() {
    }

    public LotDTO(Lot lot) {
        this(lot, true);
    }

    public LotDTO(Lot lot, Boolean withPreviousLots) {
        this.id = lot.getId();
        this.lotCode = lot.getLotCode();
        this.establishmentId = lot.getEstablishment().getId();
        this.establishmentName = lot.getEstablishment().getName();
        this.zoneCode = lot.getEstablishment().getZone().getCode();

        this.hybridId = lot.getHybrid().getId();
        this.hybridName = lot.getHybrid().getName();
        this.hybridTypeName = lot.getHybrid().getHybridType().getName();
        this.registeredHas = lot.getRegisteredHas();
        this.harvestableHas = lot.getHarvestableHas();
        this.certification = lot.getCertification();
        this.expediente = lot.getExpediente();
        this.program = lot.getProgram();
        this.color = lot.getColor();
        this.plantingWeek = lot.getPlantingWeek();
        this.sourceLotFile = lot.getSourceLotFile();
        this.sourceMasterfile = lot.getSourceMasterfile();
        this.isReplaced = lot.getIsReplaced();

        this.user = lot.getUser() != null ? lot.getUser().getUserName() : null;

        this.targetKgBag = lot.getTargetKgBag();
        this.targetRwToDs = lot.getTargetRwToDs();
        this.targetBagLot = lot.getTargetBagLot();
        this.targetDsToFng = lot.getTargetDsToFng();
        this.targetBagHa = lot.getTargetBagHa();
        this.diasFlorCos = lot.getDiasFlorCos();
        this.estimatedHarvestDate = lot.getEstimatedHarvestDate();
        this.targetTnRwLot = lot.getTargetTnRwLot();
        this.targetTnDsLot = lot.getTargetTnDsLot();
        this.targetKgsDsHa = lot.getTargetKgsDsHa();
        this.porcActualObjetiveTargetDs = lot.getPorcActualObjetiveTargetDs();
        this.harvKgFngEstLotRw = lot.getHarvKgFngEstLotRw();
        this.actualTnDsLot = lot.getActualTnDsLot();
        this.actualTnFngLot = lot.getActualTnFngLot();
        this.eficienciaEstUnField = lot.getEficienciaEstUnField();
        this.harvKgDsLotEstRw = lot.getHarvKgDsLotEstRw();
        this.harvKgDsHaEstRw = lot.getHarvKgDsHaEstRw();
        this.actualTnRwLot = lot.getActualTnRwLot();
        this.targetLot = lot.getTargetLot();
        this.porcentActualObjectiveUnTarget = lot.getPorcentActualObjectiveUnTarget();
        this.estimatedPlantingDate = lot.getEstimatedPlantingDate();
        this.realPlantingDate = lot.getRealPlantingDate();
        this.gdu = lot.getGdu();
        this.estimatedFloweringDate = lot.getEstimatedFloweringDate();
        this.harvestDateForHumidity = lot.getHarvestDateForHumidity();
        this.rw = lot.getRw();
        this.observation = lot.getObservation();
        if (lot.getCampaign() != null) {
            this.campaignName = lot.getCampaign().getName();
        }
        this.plantingDate = lot.getPlantingDate();
        this.realFloweringDate = lot.getRealFloweringDate();
        this.realHarvestDate = lot.getRealHarvestDate();
        this.floweringDate = lot.getFloweringDate();
        this.harvestDate = lot.getHarvestDate();
        this.harvestWeek = lot.getHarvestWeek();
        this.estimatedKgDsHa = lot.getEstimatedKgDsHa();
        this.obsEstimatedKgDsHa = lot.getObsEstimatedKgDsHa();
        this.actualKgDsHa = lot.getActualKgDsHa();
        this.actualBagLot = lot.getActualBagLot();
        this.plantFlowDays = lot.getPlantFlowDays();
        this.flowHarvDays = lot.getFlowHarvDays();
        this.file = lot.getFile();
        this.harvestKgRWLot = lot.getHarvestKgRWLot();
        this.harvestRwToDs = lot.getHarvestRwToDs();
        List<PreviousLot> prevList = lot.getPreviousLot();
        this.previousLot = new ArrayList<Integer>();
        if (withPreviousLots) {
            for (PreviousLot prev : prevList) {
                this.previousLot.add(prev.getPreviousLot());
            }
        }
        this.obsHarvestRwToDs = lot.getObsHarvestRwToDs();
        this.huskingKgDsLot = lot.getHuskingKgDsLot();
        this.obsHuskingKgDsLot = lot.getObsHuskingKgDsLot();
        this.huskingKgDsHa = lot.getHuskingKgDsHa();
        this.qualityKgFngLot = lot.getQualityKgFngLot();
        this.greenConversion = lot.getGreenConversion();
        this.eficienciaRwToDs = lot.getEficienciaRwToDs();
        this.actualKgDsLot = lot.getActualKgDsLot();
        this.actualTnDsHa = lot.getActualTnDsHa();
        this.qualityDsToFng = lot.getQualityDsToFng();
        this.qualityWeightBag = lot.getQualityWeightBag();
        this.qualityObs = lot.getQualityObs();
        this.eficienciaDsToFng = lot.getEficienciaDsToFng();
        this.qualityWeightBag = lot.getQualityWeightBag();
        this.qualityObs = lot.getQualityObs();
        this.eficienciaDsToFng = lot.getEficienciaDsToFng();
        this.warehouseUnit = lot.getWarehouseUnit();
        this.actualKgFngLot = lot.getActualKgFngLot();
        this.plsLot = lot.getPlsLot();
        this.indexLot = lot.getIndexLot();
        this.plLot = lot.getPlLot();
        this.bulkConversion = lot.getBulkConversion();
        this.eficienciaKgDescarte = lot.getEficienciaKgDescarte();
        this.indexLot = lot.getIndexLot();
        this.actualKgDsBalance = lot.getActualKgDsBalance();
        this.humidity = lot.getHumidity();
        this.sampleDateHumidity = lot.getSampleDateHumidity();
        this.actualWeightBagLot = lot.getActualWeightBagLot();
        this.obsLine = lot.getObsLine();
        this.generalObs = lot.getGeneralObs();

        this.bulkBagEst = lot.getBulkBagEst();
        this.countEstimatedKgDsHa = lot.getCountEstimatedKgDsHa();
        this.trucks = lot.getTrucks();
        this.averageHumidity = lot.getAverageHumidity();
        this.weightAverageTruck = lot.getWeightAverageTruck();
        this.receptionPlant = lot.getReceptionPlant();
        this.megazone = lot.getMegazone();
        this.totalKgCullTower = lot.getTotalKgCullTower();
        this.germoplasma = lot.getGermoplasma();
        this.client = lot.getClient();
        this.granProgram = lot.getGranProgram();
        this.realRwReceiptDate = lot.getRealRwReceiptDate();
        this.estimatedRwDate = lot.getEstimatedRwDate();
        this.realDsDate = lot.getRealDsDate();
        this.estimatedDsDate = lot.getEstimatedDsDate();
        this.estimatedFngInit = lot.getEstimatedFngInit();
        this.estimatedFngEnd = lot.getEstimatedFngEnd();
        this.realFngInit = lot.getRealFngInit();
        this.realFngEnd = lot.getRealFngEnd();
    }


    public LotDTO(Lot lot, String causes) {
        this.id = lot.getId();
        this.lotCode = lot.getLotCode();

        if (lot.getEstablishment() != null) {
            this.establishmentName = lot.getEstablishment().getName();
            if (lot.getEstablishment().getZone() != null) {
                this.zoneCode = lot.getEstablishment().getZone().getCode();
            }
        }
        if (lot.getHybrid() != null) {
            this.hybridName = lot.getHybrid().getName();
            this.hybridTypeName = lot.getHybrid().getHybridType().getName();
        }
        this.sourceLotFile = lot.getSourceLotFile();
        this.sourceMasterfile = lot.getSourceMasterfile();
        this.isReplaced = lot.getIsReplaced();
        if (lot.getUser() == null) {
            this.user = null;
        } else {
            this.user = lot.getUser().getUserName();
        }
        this.causes = causes;
    }


    public LotDTO(String lotCode, String causes) {
        this.lotCode = lotCode;
        this.causes = causes;
    }

    public LotDTO(String lotCode, String causes, String errorDetail) {
        this.lotCode = lotCode;
        this.causes = causes;
        this.errorDetail = errorDetail;
    }

    public LotDTO(RowImportDTO<Lot> rowDto) {
        this(rowDto.getData(), false);
        this.omittedCells = rowDto.getOmittedCells();
    }

    public Integer getCountEstimatedKgDsHa() {
        return countEstimatedKgDsHa;
    }

    public void setCountEstimatedKgDsHa(Integer countEstimatedKgDsHa) {
        this.countEstimatedKgDsHa = countEstimatedKgDsHa;
    }

    public Date getRealDsDate() {
        return realDsDate;
    }

    public void setRealDsDate(Date realDsDate) {
        this.realDsDate = realDsDate;
    }

    public Date getEstimatedDsDate() {
        return estimatedDsDate;
    }

    public void setEstimatedDsDate(Date estimatedDsDate) {
        this.estimatedDsDate = estimatedDsDate;
    }

    public Date getRealRwReceiptDate() {
        return realRwReceiptDate;
    }

    public void setRealRwReceiptDate(Date realRwReceiptDate) {
        this.realRwReceiptDate = realRwReceiptDate;
    }

    public String getMegazone() {
        return megazone;
    }

    public void setMegazone(String megazone) {
        this.megazone = megazone;
    }

    public String getObsLine() {
        return obsLine;
    }

    public void setObsLine(String obsLine) {
        this.obsLine = obsLine;
    }

    public String getGeneralObs() {
        return generalObs;
    }

    public void setGeneralObs(String generalObs) {
        this.generalObs = generalObs;
    }

    public Date getSampleDateHumidity() {
        return sampleDateHumidity;
    }

    public void setSampleDateHumidity(Date sampleDateHumidity) {
        this.sampleDateHumidity = sampleDateHumidity;
    }

    public Float getHumidity() {
        return humidity;
    }

    public void setHumidity(Float humidity) {
        this.humidity = humidity;
    }


    public Float getBulkConversion() {
        return bulkConversion;
    }

    public void setBulkConversion(Float bulkConversion) {
        this.bulkConversion = bulkConversion;
    }

    public Float getEficienciaKgDescarte() {
        return eficienciaKgDescarte;
    }

    public void setEficienciaKgDescarte(Float eficienciaKgDescarte) {
        this.eficienciaKgDescarte = eficienciaKgDescarte;
    }

    public Float getPlLot() {
        return plLot;
    }

    public void setPlLot(Float plLot) {
        this.plLot = plLot;
    }

    public Float getIndexLot() {
        return indexLot;
    }

    public void setIndexLot(Float indexLot) {
        this.indexLot = indexLot;
    }

    public Float getPlsLot() {
        return plsLot;
    }

    public void setPlsLot(Float plsLot) {
        this.plsLot = plsLot;
    }

    public Float getActualKgFngLot() {
        return actualKgFngLot;
    }

    public void setActualKgFngLot(Float actualKgFngLot) {
        this.actualKgFngLot = actualKgFngLot;
    }

    public String getWarehouseUnit() {
        return warehouseUnit;
    }

    public void setWarehouseUnit(String warehouseUnit) {
        this.warehouseUnit = warehouseUnit;
    }

    public Float getActualTnDsHa() {
        return actualTnDsHa;
    }

    public Float getEficienciaDsToFng() {
        return eficienciaDsToFng;
    }

    public void setEficienciaDsToFng(Float eficienciaDsToFng) {
        this.eficienciaDsToFng = eficienciaDsToFng;
    }

    public Float getQualityDsToFng() {
        return qualityDsToFng;
    }

    public void setQualityDsToFng(Float qualityDsToFng) {
        this.qualityDsToFng = qualityDsToFng;
    }

    public void setActualTnDsHa(Float actualTnDsHa) {
        this.actualTnDsHa = actualTnDsHa;
    }

    public Float getHuskingKgDsLot() {
        return huskingKgDsLot;
    }

    public Float getActualKgDsLot() {
        return actualKgDsLot;
    }

    public void setActualKgDsLot(Float actualKgDsLot) {
        this.actualKgDsLot = actualKgDsLot;
    }

    public void setHuskingKgDsLot(Float huskingKgDsLot) {
        this.huskingKgDsLot = huskingKgDsLot;
    }

    public String getObsHuskingKgDsLot() {
        return obsHuskingKgDsLot;
    }

    public void setObsHuskingKgDsLot(String obsHuskingKgDsLot) {
        this.obsHuskingKgDsLot = obsHuskingKgDsLot;
    }

    public Float getHuskingKgDsHa() {
        return huskingKgDsHa;
    }

    public void setHuskingKgDsHa(Float huskingKgDsHa) {
        this.huskingKgDsHa = huskingKgDsHa;
    }

    public Float getQualityKgFngLot() {
        return qualityKgFngLot;
    }

    public void setQualityKgFngLot(Float qualityKgFngLot) {
        this.qualityKgFngLot = qualityKgFngLot;
    }

    public Float getGreenConversion() {
        return greenConversion;
    }

    public void setGreenConversion(Float greenConversion) {
        this.greenConversion = greenConversion;
    }

    public Float getEficienciaRwToDs() {
        return eficienciaRwToDs;
    }

    public void setEficienciaRwToDs(Float eficienciaRwToDs) {
        this.eficienciaRwToDs = eficienciaRwToDs;
    }

    public String getObsHarvestRwToDs() {
        return obsHarvestRwToDs;
    }

    public void setObsHarvestRwToDs(String obsHarvestRwToDs) {
        this.obsHarvestRwToDs = obsHarvestRwToDs;
    }

    public Float getHarvestRwToDs() {
        return harvestRwToDs;
    }

    public void setHarvestRwToDs(Float harvestRwToDs) {
        this.harvestRwToDs = harvestRwToDs;
    }

    public Float getHarvestKgRWLot() {
        return harvestKgRWLot;
    }

    public void setHarvestKgRWLot(Float harvestKgRWLot) {
        this.harvestKgRWLot = harvestKgRWLot;
    }

    public List<Integer> getPreviousLot() {
        return previousLot;
    }

    public void setPreviousLot(List<Integer> previousLot) {
        this.previousLot = previousLot;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public List<LotSelectedDTO> getSelectedLots() {
        return selectedLots;
    }

    public void setSelectedLots(List<LotSelectedDTO> selectedLots) {
        this.selectedLots = selectedLots;
    }

    public Integer getPlantFlowDays() {
        return plantFlowDays;
    }

    public void setPlantFlowDays(Integer plantFlowDays) {
        this.plantFlowDays = plantFlowDays;
    }

    public Integer getFlowHarvDays() {
        return flowHarvDays;
    }

    public void setFlowHarvDays(Integer flowHarvDays) {
        this.flowHarvDays = flowHarvDays;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public String getEstablishmentName() {
        return establishmentName;
    }

    public void setEstablishmentName(String establishmentName) {
        this.establishmentName = establishmentName;
    }

    public String getZoneCode() {
        return zoneCode;
    }

    public void setZoneCode(String zoneCode) {
        this.zoneCode = zoneCode;
    }

    public Integer getHybridId() {
        return hybridId;
    }

    public void setHybridId(Integer hybridId) {
        this.hybridId = hybridId;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public String getHybridTypeName() {
        return hybridTypeName;
    }

    public void setHybridTypeName(String hybridTypeName) {
        this.hybridTypeName = hybridTypeName;
    }

    public Float getRegisteredHas() {
        return registeredHas;
    }

    public void setRegisteredHas(Float registeredHas) {
        this.registeredHas = registeredHas;
    }

    public Float getHarvestableHas() {
        return harvestableHas;
    }

    public void setHarvestableHas(Float harvestableHas) {
        this.harvestableHas = harvestableHas;
    }

    public String getCertification() {
        return certification;
    }

    public void setCertification(String certification) {
        this.certification = certification;
    }

    public String getExpediente() {
        return expediente;
    }

    public void setExpediente(String expediente) {
        this.expediente = expediente;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public Integer getPlantingWeek() {
        return plantingWeek;
    }

    public void setPlantingWeek(Integer plantingWeek) {
        this.plantingWeek = plantingWeek;
    }

    public String getSourceLotFile() {
        return sourceLotFile;
    }

    public void setSourceLotFile(String sourceLotFile) {
        this.sourceLotFile = sourceLotFile;
    }

    public String getSourceMasterfile() {
        return sourceMasterfile;
    }

    public void setSourceMasterfile(String sourceMasterfile) {
        this.sourceMasterfile = sourceMasterfile;
    }

    public Boolean getIsReplaced() {
        return isReplaced;
    }

    public void setIsReplaced(Boolean isReplaced) {
        this.isReplaced = isReplaced;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public Float getTargetKgBag() {
        return targetKgBag;
    }

    public void setTargetKgBag(Float targetKgBag) {
        this.targetKgBag = targetKgBag;
    }

    public Float getTargetRwToDs() {
        return targetRwToDs;
    }

    public void setTargetRwToDs(Float targetRwToDs) {
        this.targetRwToDs = targetRwToDs;
    }

    public Float getTargetDsToFng() {
        return targetDsToFng;
    }

    public void setTargetDsToFng(Float targetDsToFng) {
        this.targetDsToFng = targetDsToFng;
    }

    public Float getTargetBagLot() {
        return targetBagLot;
    }

    public void setTargetBagLot(Float targetBagLot) {
        this.targetBagLot = targetBagLot;
    }

    public Float getTargetBagHa() {
        return targetBagHa;
    }

    public void setTargetBagHa(Float targetBagHa) {
        this.targetBagHa = targetBagHa;
    }

    public Float getDiasFlorCos() {
        return diasFlorCos;
    }

    public void setDiasFlorCos(Float diasFlorCos) {
        this.diasFlorCos = diasFlorCos;
    }

    public Date getEstimatedHarvestDate() {
        return estimatedHarvestDate;
    }

    public void setEstimatedHarvestDate(Date estimatedHarvestDate) {
        this.estimatedHarvestDate = estimatedHarvestDate;
    }

    public Float getTargetTnRwLot() {
        return targetTnRwLot;
    }

    public void setTargetTnRwLot(Float targetTnRwLot) {
        this.targetTnRwLot = targetTnRwLot;
    }

    public Float getTargetTnDsLot() {
        return targetTnDsLot;
    }

    public void setTargetTnDsLot(Float targetTnDsLot) {
        this.targetTnDsLot = targetTnDsLot;
    }

    public Float getTargetKgsDsHa() {
        return targetKgsDsHa;
    }

    public void setTargetKgsDsHa(Float targetKgsDsHa) {
        this.targetKgsDsHa = targetKgsDsHa;
    }

    public Float getPorcActualObjetiveTargetDs() {
        return porcActualObjetiveTargetDs;
    }

    public void setPorcActualObjetiveTargetDs(Float porcActualObjetiveTargetDs) {
        this.porcActualObjetiveTargetDs = porcActualObjetiveTargetDs;
    }

    public Float getHarvKgFngEstLotRw() {
        return harvKgFngEstLotRw;
    }

    public void setHarvKgFngEstLotRw(Float harvKgFngEstLotRw) {
        this.harvKgFngEstLotRw = harvKgFngEstLotRw;
    }

    public Float getActualTnDsLot() {
        return actualTnDsLot;
    }

    public void setActualTnDsLot(Float actualTnDsLot) {
        this.actualTnDsLot = actualTnDsLot;
    }

    public Float getActualTnFngLot() {
        return actualTnFngLot;
    }

    public void setActualTnFngLot(Float actualTnFngLot) {
        this.actualTnFngLot = actualTnFngLot;
    }

    public Float getEficienciaEstUnField() {
        return eficienciaEstUnField;
    }

    public void setEficienciaEstUnField(Float eficienciaEstUnField) {
        this.eficienciaEstUnField = eficienciaEstUnField;
    }

    public Float getHarvKgDsLotEstRw() {
        return harvKgDsLotEstRw;
    }

    public void setHarvKgDsLotEstRw(Float harvKgDsLotEstRw) {
        this.harvKgDsLotEstRw = harvKgDsLotEstRw;
    }

    public Float getHarvKgDsHaEstRw() {
        return harvKgDsHaEstRw;
    }

    public void setHarvKgDsHaEstRw(Float harvKgDsHaEstRw) {
        this.harvKgDsHaEstRw = harvKgDsHaEstRw;
    }

    public Float getActualTnRwLot() {
        return actualTnRwLot;
    }

    public void setActualTnRwLot(Float actualTnRwLot) {
        this.actualTnRwLot = actualTnRwLot;
    }

    public Float getTargetLot() {
        return targetLot;
    }

    public void setTargetLot(Float targetLot) {
        this.targetLot = targetLot;
    }

    public Float getPorcentActualObjectiveUnTarget() {
        return porcentActualObjectiveUnTarget;
    }

    public void setPorcentActualObjectiveUnTarget(Float porcentActualObjectiveUnTarget) {
        this.porcentActualObjectiveUnTarget = porcentActualObjectiveUnTarget;
    }

    public Date getEstimatedPlantingDate() {
        return estimatedPlantingDate;
    }

    public void setEstimatedPlantingDate(Date estimatedPlantingDate) {
        this.estimatedPlantingDate = estimatedPlantingDate;
    }

    public Date getRealPlantingDate() {
        return realPlantingDate;
    }

    public void setRealPlantingDate(Date realPlantingDate) {
        this.realPlantingDate = realPlantingDate;
    }

    public Integer getGdu() {
        return gdu;
    }

    public void setGdu(Integer gdu) {
        this.gdu = gdu;
    }

    public Date getEstimatedFloweringDate() {
        return estimatedFloweringDate;
    }

    public void setEstimatedFloweringDate(Date estimatedFloweringDate) {
        this.estimatedFloweringDate = estimatedFloweringDate;
    }

    public Date getHarvestDateForHumidity() {
        return harvestDateForHumidity;
    }

    public void setHarvestDateForHumidity(Date harvestDateForHumidity) {
        this.harvestDateForHumidity = harvestDateForHumidity;
    }

    public Integer getRw() {
        return rw;
    }

    public void setRw(Integer rw) {
        this.rw = rw;
    }

    public String getObservation() {
        return observation;
    }

    public void setObservation(String observation) {
        this.observation = observation;
    }

    public String getCampaignName() {
        return campaignName;
    }

    public void setCampaignName(String campaignName) {
        this.campaignName = campaignName;
    }

    public Date getRealFloweringDate() {
        return realFloweringDate;
    }

    public void setRealFloweringDate(Date realFloweringDate) {
        this.realFloweringDate = realFloweringDate;
    }

    public Date getRealHarvestDate() {
        return realHarvestDate;
    }

    public void setRealHarvestDate(Date realHarvestDate) {
        this.realHarvestDate = realHarvestDate;
    }

    public Date getFloweringDate() {
        return floweringDate;
    }

    public void setFloweringDate(Date floweringDate) {
        this.floweringDate = floweringDate;
    }

    public Date getHarvestDate() {
        return harvestDate;
    }

    public void setHarvestDate(Date harvestDate) {
        this.harvestDate = harvestDate;
    }

    public Float getHarvestWeek() {
        return harvestWeek;
    }

    public void setHarvestWeek(Float harvestWeek) {
        this.harvestWeek = harvestWeek;
    }

    public Float getEstimatedKgDsHa() {
        return estimatedKgDsHa;
    }

    public void setEstimatedKgDsHa(Float estimatedKgDsHa) {
        this.estimatedKgDsHa = estimatedKgDsHa;
    }

    public String getObsEstimatedKgDsHa() {
        return obsEstimatedKgDsHa;
    }

    public void setObsEstimatedKgDsHa(String obsEstimatedKgDsHa) {
        this.obsEstimatedKgDsHa = obsEstimatedKgDsHa;
    }

    public Float getActualKgDsHa() {
        return actualKgDsHa;
    }

    public void setActualKgDsHa(Float actualKgDsHa) {
        this.actualKgDsHa = actualKgDsHa;
    }

    public Float getActualBagLot() {
        return actualBagLot;
    }

    public void setActualBagLot(Float actualBagLot) {
        this.actualBagLot = actualBagLot;
    }

    public String getCauses() {
        return causes;
    }

    public void setCauses(String causes) {
        this.causes = causes;
    }

    public Date getPlantingDate() {
        return plantingDate;
    }

    public void setPlantingDate(Date plantingDate) {
        this.plantingDate = plantingDate;
    }

    public Integer getEstablishmentId() {
        return establishmentId;
    }

    public void setEstablishmentId(Integer establishmentId) {
        this.establishmentId = establishmentId;
    }

    @Override
    public String toString() {
        return lotCode;
    }

    public String getQualityObs() {
        return qualityObs;
    }

    public void setQualityObs(String qualityObs) {
        this.qualityObs = qualityObs;
    }

    public Float getQualityWeightBag() {
        return qualityWeightBag;
    }

    public void setQualityWeightBag(Float qualityWeightBag) {
        this.qualityWeightBag = qualityWeightBag;
    }

    public boolean isHarvested() {
        return (getHarvestKgRWLot() != null && getHarvestKgRWLot() > 0) || getRealHarvestDate() != null;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LotDTO lotDTO = (LotDTO) o;

        if (megazone != null ? !megazone.equals(lotDTO.megazone) : lotDTO.megazone != null)
            return false;
        if (actualBagLot != null ? !actualBagLot.equals(lotDTO.actualBagLot) : lotDTO.actualBagLot != null)
            return false;
        if (actualKgDsBalance != null ? !actualKgDsBalance.equals(lotDTO.actualKgDsBalance) : lotDTO.actualKgDsBalance != null)
            return false;
        if (actualKgDsHa != null ? !actualKgDsHa.equals(lotDTO.actualKgDsHa) : lotDTO.actualKgDsHa != null)
            return false;
        if (actualKgDsLot != null ? !actualKgDsLot.equals(lotDTO.actualKgDsLot) : lotDTO.actualKgDsLot != null)
            return false;
        if (actualKgFngLot != null ? !actualKgFngLot.equals(lotDTO.actualKgFngLot) : lotDTO.actualKgFngLot != null)
            return false;
        if (actualTnDsHa != null ? !actualTnDsHa.equals(lotDTO.actualTnDsHa) : lotDTO.actualTnDsHa != null)
            return false;
        if (actualTnDsLot != null ? !actualTnDsLot.equals(lotDTO.actualTnDsLot) : lotDTO.actualTnDsLot != null)
            return false;
        if (actualTnFngLot != null ? !actualTnFngLot.equals(lotDTO.actualTnFngLot) : lotDTO.actualTnFngLot != null)
            return false;
        if (actualTnRwLot != null ? !actualTnRwLot.equals(lotDTO.actualTnRwLot) : lotDTO.actualTnRwLot != null)
            return false;
        if (actualWeightBagLot != null ? !actualWeightBagLot.equals(lotDTO.actualWeightBagLot) : lotDTO.actualWeightBagLot != null)
            return false;

        if (averageHumidity != null ? !averageHumidity.equals(lotDTO.averageHumidity) : lotDTO.averageHumidity != null)
            return false;
        if (bulkBagEst != null ? !bulkBagEst.equals(lotDTO.bulkBagEst) : lotDTO.bulkBagEst != null) return false;
        if (bulkConversion != null ? !bulkConversion.equals(lotDTO.bulkConversion) : lotDTO.bulkConversion != null)
            return false;
        if (campaignName != null ? !campaignName.equals(lotDTO.campaignName) : lotDTO.campaignName != null)
            return false;
        if (causes != null ? !causes.equals(lotDTO.causes) : lotDTO.causes != null) return false;
        if (certification != null ? !certification.equals(lotDTO.certification) : lotDTO.certification != null)
            return false;
        if (color != null ? !color.equals(lotDTO.color) : lotDTO.color != null) return false;
        if (countEstimatedKgDsHa != null ? !countEstimatedKgDsHa.equals(lotDTO.countEstimatedKgDsHa) : lotDTO.countEstimatedKgDsHa != null)
            return false;
        if (diasFlorCos != null ? !diasFlorCos.equals(lotDTO.diasFlorCos) : lotDTO.diasFlorCos != null) return false;
        if (eficienciaDsToFng != null ? !eficienciaDsToFng.equals(lotDTO.eficienciaDsToFng) : lotDTO.eficienciaDsToFng != null)
            return false;
        if (eficienciaEstUnField != null ? !eficienciaEstUnField.equals(lotDTO.eficienciaEstUnField) : lotDTO.eficienciaEstUnField != null)
            return false;
        if (eficienciaKgDescarte != null ? !eficienciaKgDescarte.equals(lotDTO.eficienciaKgDescarte) : lotDTO.eficienciaKgDescarte != null)
            return false;
        if (eficienciaRwToDs != null ? !eficienciaRwToDs.equals(lotDTO.eficienciaRwToDs) : lotDTO.eficienciaRwToDs != null)
            return false;
        if (errorDetail != null ? !errorDetail.equals(lotDTO.errorDetail) : lotDTO.errorDetail != null) return false;
        if (establishmentId != null ? !establishmentId.equals(lotDTO.establishmentId) : lotDTO.establishmentId != null)
            return false;
        if (establishmentName != null ? !establishmentName.equals(lotDTO.establishmentName) : lotDTO.establishmentName != null)
            return false;
        if (estimatedFloweringDate != null ? !estimatedFloweringDate.equals(lotDTO.estimatedFloweringDate) : lotDTO.estimatedFloweringDate != null)
            return false;
        if (estimatedHarvestDate != null ? !estimatedHarvestDate.equals(lotDTO.estimatedHarvestDate) : lotDTO.estimatedHarvestDate != null)
            return false;
        if (estimatedKgDsHa != null ? !estimatedKgDsHa.equals(lotDTO.estimatedKgDsHa) : lotDTO.estimatedKgDsHa != null)
            return false;
        if (estimatedPlantingDate != null ? !estimatedPlantingDate.equals(lotDTO.estimatedPlantingDate) : lotDTO.estimatedPlantingDate != null)
            return false;
        if (expediente != null ? !expediente.equals(lotDTO.expediente) : lotDTO.expediente != null) return false;
        if (file != null ? !file.equals(lotDTO.file) : lotDTO.file != null) return false;
        if (flowHarvDays != null ? !flowHarvDays.equals(lotDTO.flowHarvDays) : lotDTO.flowHarvDays != null)
            return false;
        if (floweringDate != null ? !floweringDate.equals(lotDTO.floweringDate) : lotDTO.floweringDate != null)
            return false;
        if (gdu != null ? !gdu.equals(lotDTO.gdu) : lotDTO.gdu != null) return false;
        if (generalObs != null ? !generalObs.equals(lotDTO.generalObs) : lotDTO.generalObs != null) return false;
        if (greenConversion != null ? !greenConversion.equals(lotDTO.greenConversion) : lotDTO.greenConversion != null)
            return false;
        if (harvKgDsHaEstRw != null ? !harvKgDsHaEstRw.equals(lotDTO.harvKgDsHaEstRw) : lotDTO.harvKgDsHaEstRw != null)
            return false;
        if (harvKgDsLotEstRw != null ? !harvKgDsLotEstRw.equals(lotDTO.harvKgDsLotEstRw) : lotDTO.harvKgDsLotEstRw != null)
            return false;
        if (harvKgFngEstLotRw != null ? !harvKgFngEstLotRw.equals(lotDTO.harvKgFngEstLotRw) : lotDTO.harvKgFngEstLotRw != null)
            return false;
        if (harvestDate != null ? !harvestDate.equals(lotDTO.harvestDate) : lotDTO.harvestDate != null) return false;
        if (harvestDateForHumidity != null ? !harvestDateForHumidity.equals(lotDTO.harvestDateForHumidity) : lotDTO.harvestDateForHumidity != null)
            return false;
        if (harvestKgRWLot != null ? !harvestKgRWLot.equals(lotDTO.harvestKgRWLot) : lotDTO.harvestKgRWLot != null)
            return false;
        if (harvestRwToDs != null ? !harvestRwToDs.equals(lotDTO.harvestRwToDs) : lotDTO.harvestRwToDs != null)
            return false;
        if (harvestWeek != null ? !harvestWeek.equals(lotDTO.harvestWeek) : lotDTO.harvestWeek != null) return false;
        if (harvestableHas != null ? !harvestableHas.equals(lotDTO.harvestableHas) : lotDTO.harvestableHas != null)
            return false;
        if (humidity != null ? !humidity.equals(lotDTO.humidity) : lotDTO.humidity != null) return false;
        if (huskingKgDsHa != null ? !huskingKgDsHa.equals(lotDTO.huskingKgDsHa) : lotDTO.huskingKgDsHa != null)
            return false;
        if (huskingKgDsLot != null ? !huskingKgDsLot.equals(lotDTO.huskingKgDsLot) : lotDTO.huskingKgDsLot != null)
            return false;
        if (hybridId != null ? !hybridId.equals(lotDTO.hybridId) : lotDTO.hybridId != null) return false;
        if (hybridName != null ? !hybridName.equals(lotDTO.hybridName) : lotDTO.hybridName != null) return false;
        if (hybridTypeName != null ? !hybridTypeName.equals(lotDTO.hybridTypeName) : lotDTO.hybridTypeName != null)
            return false;
        if (id != null ? !id.equals(lotDTO.id) : lotDTO.id != null) return false;
        if (indexLot != null ? !indexLot.equals(lotDTO.indexLot) : lotDTO.indexLot != null) return false;
        if (isHybridModified != null ? !isHybridModified.equals(lotDTO.isHybridModified) : lotDTO.isHybridModified != null)
            return false;
        if (isMegazoneModified!= null ? !isMegazoneModified.equals(lotDTO.isMegazoneModified) : lotDTO.isMegazoneModified != null)
            return false;
        if (isReplaced != null ? !isReplaced.equals(lotDTO.isReplaced) : lotDTO.isReplaced != null) return false;
        if (lotCode != null ? !lotCode.equals(lotDTO.lotCode) : lotDTO.lotCode != null) return false;
        if (obsEstimatedKgDsHa != null ? !obsEstimatedKgDsHa.equals(lotDTO.obsEstimatedKgDsHa) : lotDTO.obsEstimatedKgDsHa != null)
            return false;
        if (obsHarvestRwToDs != null ? !obsHarvestRwToDs.equals(lotDTO.obsHarvestRwToDs) : lotDTO.obsHarvestRwToDs != null)
            return false;
        if (obsHuskingKgDsLot != null ? !obsHuskingKgDsLot.equals(lotDTO.obsHuskingKgDsLot) : lotDTO.obsHuskingKgDsLot != null)
            return false;
        if (obsLine != null ? !obsLine.equals(lotDTO.obsLine) : lotDTO.obsLine != null) return false;
        if (observation != null ? !observation.equals(lotDTO.observation) : lotDTO.observation != null) return false;
        if (omittedCells != null ? !omittedCells.equals(lotDTO.omittedCells) : lotDTO.omittedCells != null)
            return false;
        if (plLot != null ? !plLot.equals(lotDTO.plLot) : lotDTO.plLot != null) return false;
        if (plantFlowDays != null ? !plantFlowDays.equals(lotDTO.plantFlowDays) : lotDTO.plantFlowDays != null)
            return false;
        if (plantingDate != null ? !plantingDate.equals(lotDTO.plantingDate) : lotDTO.plantingDate != null)
            return false;
        if (plantingWeek != null ? !plantingWeek.equals(lotDTO.plantingWeek) : lotDTO.plantingWeek != null)
            return false;
        if (plsLot != null ? !plsLot.equals(lotDTO.plsLot) : lotDTO.plsLot != null) return false;
        if (porcActualObjetiveTargetDs != null ? !porcActualObjetiveTargetDs.equals(lotDTO.porcActualObjetiveTargetDs) : lotDTO.porcActualObjetiveTargetDs != null)
            return false;
        if (porcentActualObjectiveUnTarget != null ? !porcentActualObjectiveUnTarget.equals(lotDTO.porcentActualObjectiveUnTarget) : lotDTO.porcentActualObjectiveUnTarget != null)
            return false;
        if (previousLot != null ? !previousLot.equals(lotDTO.previousLot) : lotDTO.previousLot != null) return false;
        if (program != null ? !program.equals(lotDTO.program) : lotDTO.program != null) return false;
        if (qualityDsToFng != null ? !qualityDsToFng.equals(lotDTO.qualityDsToFng) : lotDTO.qualityDsToFng != null)
            return false;
        if (qualityKgFngLot != null ? !qualityKgFngLot.equals(lotDTO.qualityKgFngLot) : lotDTO.qualityKgFngLot != null)
            return false;
        if (qualityObs != null ? !qualityObs.equals(lotDTO.qualityObs) : lotDTO.qualityObs != null) return false;
        if (qualityWeightBag != null ? !qualityWeightBag.equals(lotDTO.qualityWeightBag) : lotDTO.qualityWeightBag != null)
            return false;
        if (realFloweringDate != null ? !realFloweringDate.equals(lotDTO.realFloweringDate) : lotDTO.realFloweringDate != null)
            return false;
        if (realHarvestDate != null ? !realHarvestDate.equals(lotDTO.realHarvestDate) : lotDTO.realHarvestDate != null)
            return false;
        if (realPlantingDate != null ? !realPlantingDate.equals(lotDTO.realPlantingDate) : lotDTO.realPlantingDate != null)
            return false;
        if (receptionPlant != null ? !receptionPlant.equals(lotDTO.receptionPlant) : lotDTO.receptionPlant != null)
            return false;
        if (registeredHas != null ? !registeredHas.equals(lotDTO.registeredHas) : lotDTO.registeredHas != null)
            return false;
        if (rw != null ? !rw.equals(lotDTO.rw) : lotDTO.rw != null) return false;
        if (sampleDateHumidity != null ? !sampleDateHumidity.equals(lotDTO.sampleDateHumidity) : lotDTO.sampleDateHumidity != null)
            return false;
        if (selectedLots != null ? !selectedLots.equals(lotDTO.selectedLots) : lotDTO.selectedLots != null)
            return false;
        if (sourceLotFile != null ? !sourceLotFile.equals(lotDTO.sourceLotFile) : lotDTO.sourceLotFile != null)
            return false;
        if (sourceMasterfile != null ? !sourceMasterfile.equals(lotDTO.sourceMasterfile) : lotDTO.sourceMasterfile != null)
            return false;
        if (targetBagHa != null ? !targetBagHa.equals(lotDTO.targetBagHa) : lotDTO.targetBagHa != null) return false;
        if (targetBagLot != null ? !targetBagLot.equals(lotDTO.targetBagLot) : lotDTO.targetBagLot != null)
            return false;
        if (targetDsToFng != null ? !targetDsToFng.equals(lotDTO.targetDsToFng) : lotDTO.targetDsToFng != null)
            return false;
        if (targetKgBag != null ? !targetKgBag.equals(lotDTO.targetKgBag) : lotDTO.targetKgBag != null) return false;
        if (targetKgsDsHa != null ? !targetKgsDsHa.equals(lotDTO.targetKgsDsHa) : lotDTO.targetKgsDsHa != null)
            return false;
        if (targetLot != null ? !targetLot.equals(lotDTO.targetLot) : lotDTO.targetLot != null) return false;
        if (targetRwToDs != null ? !targetRwToDs.equals(lotDTO.targetRwToDs) : lotDTO.targetRwToDs != null)
            return false;
        if (targetTnDsLot != null ? !targetTnDsLot.equals(lotDTO.targetTnDsLot) : lotDTO.targetTnDsLot != null)
            return false;
        if (targetTnRwLot != null ? !targetTnRwLot.equals(lotDTO.targetTnRwLot) : lotDTO.targetTnRwLot != null)
            return false;
        if (trucks != null ? !trucks.equals(lotDTO.trucks) : lotDTO.trucks != null) return false;
        if (user != null ? !user.equals(lotDTO.user) : lotDTO.user != null) return false;
        if (warehouseUnit != null ? !warehouseUnit.equals(lotDTO.warehouseUnit) : lotDTO.warehouseUnit != null)
            return false;
        if (weightAverageTruck != null ? !weightAverageTruck.equals(lotDTO.weightAverageTruck) : lotDTO.weightAverageTruck != null)
            return false;
        if (zoneCode != null ? !zoneCode.equals(lotDTO.zoneCode) : lotDTO.zoneCode != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (lotCode != null ? lotCode.hashCode() : 0);
        result = 31 * result + (megazone != null ? megazone.hashCode() : 0);
        result = 31 * result + (establishmentId != null ? establishmentId.hashCode() : 0);
        result = 31 * result + (establishmentName != null ? establishmentName.hashCode() : 0);
        result = 31 * result + (zoneCode != null ? zoneCode.hashCode() : 0);

        result = 31 * result + (hybridId != null ? hybridId.hashCode() : 0);
        result = 31 * result + (hybridName != null ? hybridName.hashCode() : 0);
        result = 31 * result + (hybridTypeName != null ? hybridTypeName.hashCode() : 0);
        result = 31 * result + (registeredHas != null ? registeredHas.hashCode() : 0);
        result = 31 * result + (harvestableHas != null ? harvestableHas.hashCode() : 0);
        result = 31 * result + (certification != null ? certification.hashCode() : 0);
        result = 31 * result + (expediente != null ? expediente.hashCode() : 0);
        result = 31 * result + (program != null ? program.hashCode() : 0);
        result = 31 * result + (color != null ? color.hashCode() : 0);
        result = 31 * result + (plantingWeek != null ? plantingWeek.hashCode() : 0);
        result = 31 * result + (sourceLotFile != null ? sourceLotFile.hashCode() : 0);
        result = 31 * result + (sourceMasterfile != null ? sourceMasterfile.hashCode() : 0);
        result = 31 * result + (isReplaced != null ? isReplaced.hashCode() : 0);
        result = 31 * result + (user != null ? user.hashCode() : 0);
        result = 31 * result + (targetKgBag != null ? targetKgBag.hashCode() : 0);
        result = 31 * result + (targetRwToDs != null ? targetRwToDs.hashCode() : 0);
        result = 31 * result + (targetDsToFng != null ? targetDsToFng.hashCode() : 0);
        result = 31 * result + (targetBagLot != null ? targetBagLot.hashCode() : 0);
        result = 31 * result + (targetBagHa != null ? targetBagHa.hashCode() : 0);
        result = 31 * result + (diasFlorCos != null ? diasFlorCos.hashCode() : 0);
        result = 31 * result + (estimatedHarvestDate != null ? estimatedHarvestDate.hashCode() : 0);
        result = 31 * result + (targetTnRwLot != null ? targetTnRwLot.hashCode() : 0);
        result = 31 * result + (targetTnDsLot != null ? targetTnDsLot.hashCode() : 0);
        result = 31 * result + (targetKgsDsHa != null ? targetKgsDsHa.hashCode() : 0);
        result = 31 * result + (porcActualObjetiveTargetDs != null ? porcActualObjetiveTargetDs.hashCode() : 0);
        result = 31 * result + (harvKgFngEstLotRw != null ? harvKgFngEstLotRw.hashCode() : 0);
        result = 31 * result + (actualTnDsLot != null ? actualTnDsLot.hashCode() : 0);
        result = 31 * result + (actualTnFngLot != null ? actualTnFngLot.hashCode() : 0);
        result = 31 * result + (eficienciaEstUnField != null ? eficienciaEstUnField.hashCode() : 0);
        result = 31 * result + (harvKgDsLotEstRw != null ? harvKgDsLotEstRw.hashCode() : 0);
        result = 31 * result + (harvKgDsHaEstRw != null ? harvKgDsHaEstRw.hashCode() : 0);
        result = 31 * result + (actualTnRwLot != null ? actualTnRwLot.hashCode() : 0);
        result = 31 * result + (targetLot != null ? targetLot.hashCode() : 0);
        result = 31 * result + (porcentActualObjectiveUnTarget != null ? porcentActualObjectiveUnTarget.hashCode() : 0);
        result = 31 * result + (plantingDate != null ? plantingDate.hashCode() : 0);
        result = 31 * result + (estimatedPlantingDate != null ? estimatedPlantingDate.hashCode() : 0);
        result = 31 * result + (realPlantingDate != null ? realPlantingDate.hashCode() : 0);
        result = 31 * result + (gdu != null ? gdu.hashCode() : 0);
        result = 31 * result + (estimatedFloweringDate != null ? estimatedFloweringDate.hashCode() : 0);
        result = 31 * result + (harvestDateForHumidity != null ? harvestDateForHumidity.hashCode() : 0);
        result = 31 * result + (rw != null ? rw.hashCode() : 0);
        result = 31 * result + (observation != null ? observation.hashCode() : 0);
        result = 31 * result + (campaignName != null ? campaignName.hashCode() : 0);
        result = 31 * result + (realFloweringDate != null ? realFloweringDate.hashCode() : 0);
        result = 31 * result + (realHarvestDate != null ? realHarvestDate.hashCode() : 0);
        result = 31 * result + (floweringDate != null ? floweringDate.hashCode() : 0);
        result = 31 * result + (harvestDate != null ? harvestDate.hashCode() : 0);
        result = 31 * result + (harvestWeek != null ? harvestWeek.hashCode() : 0);
        result = 31 * result + (estimatedKgDsHa != null ? estimatedKgDsHa.hashCode() : 0);
        result = 31 * result + (obsEstimatedKgDsHa != null ? obsEstimatedKgDsHa.hashCode() : 0);
        result = 31 * result + (actualKgDsHa != null ? actualKgDsHa.hashCode() : 0);
        result = 31 * result + (actualBagLot != null ? actualBagLot.hashCode() : 0);
        result = 31 * result + (plantFlowDays != null ? plantFlowDays.hashCode() : 0);
        result = 31 * result + (flowHarvDays != null ? flowHarvDays.hashCode() : 0);
        result = 31 * result + (file != null ? file.hashCode() : 0);
        result = 31 * result + (selectedLots != null ? selectedLots.hashCode() : 0);
        result = 31 * result + (previousLot != null ? previousLot.hashCode() : 0);
        result = 31 * result + (harvestKgRWLot != null ? harvestKgRWLot.hashCode() : 0);
        result = 31 * result + (causes != null ? causes.hashCode() : 0);
        result = 31 * result + (harvestRwToDs != null ? harvestRwToDs.hashCode() : 0);
        result = 31 * result + (obsHarvestRwToDs != null ? obsHarvestRwToDs.hashCode() : 0);
        result = 31 * result + (huskingKgDsLot != null ? huskingKgDsLot.hashCode() : 0);
        result = 31 * result + (obsHuskingKgDsLot != null ? obsHuskingKgDsLot.hashCode() : 0);
        result = 31 * result + (huskingKgDsHa != null ? huskingKgDsHa.hashCode() : 0);
        result = 31 * result + (qualityKgFngLot != null ? qualityKgFngLot.hashCode() : 0);
        result = 31 * result + (greenConversion != null ? greenConversion.hashCode() : 0);
        result = 31 * result + (eficienciaRwToDs != null ? eficienciaRwToDs.hashCode() : 0);
        result = 31 * result + (actualKgDsLot != null ? actualKgDsLot.hashCode() : 0);
        result = 31 * result + (actualTnDsHa != null ? actualTnDsHa.hashCode() : 0);
        result = 31 * result + (qualityDsToFng != null ? qualityDsToFng.hashCode() : 0);
        result = 31 * result + (qualityObs != null ? qualityObs.hashCode() : 0);
        result = 31 * result + (qualityWeightBag != null ? qualityWeightBag.hashCode() : 0);
        result = 31 * result + (eficienciaDsToFng != null ? eficienciaDsToFng.hashCode() : 0);
        result = 31 * result + (warehouseUnit != null ? warehouseUnit.hashCode() : 0);
        result = 31 * result + (actualKgFngLot != null ? actualKgFngLot.hashCode() : 0);
        result = 31 * result + (plsLot != null ? plsLot.hashCode() : 0);
        result = 31 * result + (indexLot != null ? indexLot.hashCode() : 0);
        result = 31 * result + (plLot != null ? plLot.hashCode() : 0);
        result = 31 * result + (bulkConversion != null ? bulkConversion.hashCode() : 0);
        result = 31 * result + (eficienciaKgDescarte != null ? eficienciaKgDescarte.hashCode() : 0);
        result = 31 * result + (humidity != null ? humidity.hashCode() : 0);
        result = 31 * result + (actualKgDsBalance != null ? actualKgDsBalance.hashCode() : 0);
        result = 31 * result + (sampleDateHumidity != null ? sampleDateHumidity.hashCode() : 0);
        result = 31 * result + (actualWeightBagLot != null ? actualWeightBagLot.hashCode() : 0);
        result = 31 * result + (obsLine != null ? obsLine.hashCode() : 0);
        result = 31 * result + (generalObs != null ? generalObs.hashCode() : 0);
        result = 31 * result + (bulkBagEst != null ? bulkBagEst.hashCode() : 0);
        result = 31 * result + (isHybridModified != null ? isHybridModified.hashCode() : 0);
        result = 31 * result + (isMegazoneModified != null ? isMegazoneModified.hashCode() : 0);
        result = 31 * result + (errorDetail != null ? errorDetail.hashCode() : 0);
        result = 31 * result + (omittedCells != null ? omittedCells.hashCode() : 0);
        result = 31 * result + (countEstimatedKgDsHa != null ? countEstimatedKgDsHa.hashCode() : 0);
        result = 31 * result + (trucks != null ? trucks.hashCode() : 0);
        result = 31 * result + (averageHumidity != null ? averageHumidity.hashCode() : 0);
        result = 31 * result + (weightAverageTruck != null ? weightAverageTruck.hashCode() : 0);
        result = 31 * result + (receptionPlant != null ? receptionPlant.hashCode() : 0);
        return result;
    }

    public Float getActualKgDsBalance() {
        return actualKgDsBalance;
    }

    public void setActualKgDsBalance(Float actualKgDsBalance) {
        this.actualKgDsBalance = actualKgDsBalance;
    }

    public Float getActualWeightBagLot() {
        return actualWeightBagLot;
    }

    public void setActualWeightBagLot(Float actualWeightBagLot) {
        this.actualWeightBagLot = actualWeightBagLot;
    }

    public Boolean getIsHybridModified() {
        return isHybridModified;
    }

    public void setIsHybridModified(Boolean isHybridModified) {
        this.isHybridModified = isHybridModified;
    }

    public Boolean getIsMegazoneModified() {
        return isMegazoneModified;
    }

    public void setIsMegazoneModified(Boolean isMegazoneModified) {
        this.isMegazoneModified = isMegazoneModified;
    }

    public Float getBulkBagEst() {
        return bulkBagEst;
    }

    public void setBulkBagEst(Float bulkBagEst) {
        this.bulkBagEst = bulkBagEst;
    }

    public void setErrorDetail(String errorDetail) {
        this.errorDetail = errorDetail;
    }

    public String getErrorDetail() {
        return errorDetail;
    }

    public List<CellOmittedDTO> getOmittedCells() {
        return omittedCells;
    }

    public Integer getTrucks() {
        return trucks;
    }

    public void setTrucks(Integer trucks) {
        this.trucks = trucks;
    }

    public Float getAverageHumidity() {
        return averageHumidity;
    }

    public void setAverageHumidity(Float averageHumidity) {
        this.averageHumidity = averageHumidity;
    }

    public Float getWeightAverageTruck() {
        return weightAverageTruck;
    }

    public void setWeightAverageTruck(Float weightAverageTruck) {
        this.weightAverageTruck = weightAverageTruck;
    }

    public String getReceptionPlant() {
        return receptionPlant;
    }

    public void setReceptionPlant(String receptionPlant) {
        this.receptionPlant = receptionPlant;
    }

    public void setOmittedCells(List<CellOmittedDTO> omittedCells) {
        this.omittedCells = omittedCells;
    }

    public Float getTotalKgCullTower() {
        return totalKgCullTower;
    }

    public void setTotalKgCullTower(Float totalKgCullTower) {
        this.totalKgCullTower = totalKgCullTower;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    public String getGermoplasma() {
        return germoplasma;
    }

    public void setGermoplasma(String germoplasma) {
        this.germoplasma = germoplasma;
    }

    public String getGranProgram() {
        return granProgram;
    }

    public void setGranProgram(String granProgram) {
        this.granProgram = granProgram;
    }

    public Date getEstimatedRwDate() {
        return estimatedRwDate;
    }

    public void setEstimatedRwDate(Date estimatedRwDate) {
        this.estimatedRwDate = estimatedRwDate;
    }

    public Date getEstimatedFngInit() {
        return estimatedFngInit;
    }

    public void setEstimatedFngInit(Date estimatedFngInit) {
        this.estimatedFngInit = estimatedFngInit;
    }

    public Date getEstimatedFngEnd() {
        return estimatedFngEnd;
    }

    public void setEstimatedFngEnd(Date estimatedFngEnd) {
        this.estimatedFngEnd = estimatedFngEnd;
    }
}
