package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.LotHistory;

import java.io.Serializable;
import java.util.Date;

/**
 * Created by BSBUON on 7/10/2014.
 */
public class LotHistoryDTO implements Serializable {

    private Integer id;
    private Date dateTransaction;
    private String action;
    private Integer lotId;
    private String userName;
    private String hybridName;
    private Float harvestableHas;
    private Date estimatedPlantingDate;
    private Date estimatedFloweringDate;
    private Date estimatedHarvestDate;
    private Date realPlantingDate;
    private Date realFloweringDate;
    private Date realHarvestDate;
    private Date harvestDateForHumidity;
    private Float estimatedDsHa;
    private Float targetRwToDs;
    private Float targetDSToFNG;
    private Float targetKgBag;
    private Float targetBagHa;
    private Integer flowHarvDays;
    private Float harvestKgRWLot;
    private Float harvestRWtoDS;
    private Date plantingDate;
    private Date floweringDate;
    private Date harvestDate;
    private Float tnRwlot;
    private Float tnDsLot;
    private Float tnFngLot;
    private Float bagTotalLot;
    private Float bagPeso;
    private Float kgDSHa;
    private Float kgFngHa;
    private Float bagHas;

    private Float harvestRwToDs;
    private Float actualTnDsLot;
    private Float actualTnRwLot;
    private String obsHarvestRwToDs;
    private Integer trucks;
    private Float weightAverageTruck;
    private String receptionPlant;
    private Float huskingKgDsLot;
    private String obsHuskingKgDsLot;
    private Float huskingKgDsHa;
    private Float qualityKgFngLot;
    private Float greenConversion;
    private Float eficienciaRwToDs;
    private Float actualKgDsLot;
    private Float actualTnDsHa;
    private Float qualityDsToFng;
    private Float qualityWeightBag;
    private Float bulkBagEst;
    private Float bulkBagHaEst;
    private Float bulkKgFNGHa;
    private String qualityObs;
    private Float eficienciaDsToFng;
    private String warehouseUnit;
    private Float actualKgFngLot;
    private Float plsLot;
    private Float indexLot;
    private Float plLot;
    private Float bulkConversion;
    private Float eficienciaKgDescarte;
    private Float humidity;
    private Date sampleDateHumidity;
    private String obsLine;
    private String generalObs;
    private Float targetTnRwLot;
    private Float targetTnDsLot;
    private Float targetBagLot;

    private String megazone;

    public LotHistoryDTO(LotHistory lotHistory) {
        this.lotId = lotHistory.getId();
        this.hybridName = lotHistory.getHybridName();
        this.harvestableHas = lotHistory.getHarvestableHas();
        this.estimatedPlantingDate = lotHistory.getEstimatedPlantingDate();
        this.estimatedFloweringDate = lotHistory.getEstimatedFloweringDate();
        this.estimatedHarvestDate = lotHistory.getEstimatedHarvestDate();
        this.harvestDateForHumidity = lotHistory.getHarvestDateForHumidity();
        this.estimatedDsHa = lotHistory.getEstimatedDsHa();
        this.targetRwToDs = lotHistory.getTargetRwToDs();
        this.targetDSToFNG = lotHistory.getTargetDSToFNG();
        this.targetKgBag = lotHistory.getTargetKgBag();
        this.targetBagHa = lotHistory.getTargetBagHa();
        this.flowHarvDays = lotHistory.getFlowHarvDays();
        this.harvestKgRWLot = lotHistory.getHarvestKgRWLot();
        this.harvestRWtoDS = lotHistory.getHarvestRWtoDS();
        this.plantingDate = lotHistory.getPlantingDate();
        this.floweringDate = lotHistory.getFloweringDate();
        this.harvestDate = lotHistory.getHarvestDate();
        this.tnRwlot = lotHistory.getTnRwlot();
        this.tnDsLot = lotHistory.getTnDsLot();
        this.tnFngLot = lotHistory.getTnFngLot();
        this.bagTotalLot = lotHistory.getBagTotalLot();
        this.bagPeso = lotHistory.getBagPeso();
        this.kgDSHa = lotHistory.getKgDSHa();
        this.kgFngHa = lotHistory.getKgFngHa();
        this.bagHas = lotHistory.getTargetBagHa();

        this.actualTnDsLot = lotHistory.getActualTnDsLot();
        this.actualTnRwLot = lotHistory.getActualTnRwLot();
        this.obsHarvestRwToDs = lotHistory.getObsHarvestRwToDs();
        this.huskingKgDsLot = lotHistory.getHuskingKgDsLot();
        this.obsHuskingKgDsLot = lotHistory.getObsHuskingKgDsLot();
        this.huskingKgDsHa = lotHistory.getHuskingKgDsHa();
        this.qualityKgFngLot = lotHistory.getQualityKgFngLot();
        this.greenConversion = lotHistory.getGreenConversion();
        this.eficienciaRwToDs = lotHistory.getEficienciaRwToDs();
        this.actualKgDsLot = lotHistory.getActualKgDsLot();
        this.actualTnDsHa = lotHistory.getActualTnDsHa();
        this.qualityDsToFng = lotHistory.getQualityDsToFng();
        this.qualityWeightBag = lotHistory.getQualityWeightBag();
        this.qualityObs = lotHistory.getQualityObs();
        this.eficienciaDsToFng = lotHistory.getEficienciaDsToFng();
        this.warehouseUnit = lotHistory.getWarehouseUnit();
        this.actualKgFngLot = lotHistory.getActualKgFngLot();
        this.plsLot = lotHistory.getPlsLot();
        this.indexLot = lotHistory.getIndexLot();
        this.plLot = lotHistory.getPlLot();
        this.bulkConversion = lotHistory.getBulkConversion();
        this.eficienciaKgDescarte = lotHistory.getEficienciaKgDescarte();

        this.humidity = lotHistory.getHumidity();
        this.sampleDateHumidity = lotHistory.getSampleDateHumidity();
        this.action = lotHistory.getAction();
        this.userName = lotHistory.getUser() != null ? lotHistory.getUser().getUserName() : "";
        this.dateTransaction = lotHistory.getDateTransaction();
        this.obsLine = lotHistory.getObsLine();
        this.generalObs = lotHistory.getGeneralObs();

        this.realFloweringDate = lotHistory.getRealFloweringDate();
        this.realHarvestDate = lotHistory.getRealHarvestDate();
        this.realPlantingDate = lotHistory.getRealPlantingDate();

        this.targetTnRwLot = lotHistory.getTargetTnRwLot();
        this.targetTnDsLot = lotHistory.getTargetTnDsLot();
        this.targetBagLot = lotHistory.getTargetBagLot();
        this.megazone = lotHistory.getMegazone();
    }

    public String getMegazone() {
        return megazone;
    }

    public void setMegazone(String megazone) {
        this.megazone = megazone;
    }

    public Float getTargetBagLot() {
        return targetBagLot;
    }

    public void setTargetBagLot(Float targetBagLot) {
        this.targetBagLot = targetBagLot;
    }

    public Float getTargetTnDsLot() {
        return targetTnDsLot;
    }

    public void setTargetTnDsLot(Float targetTnDsLot) {
        this.targetTnDsLot = targetTnDsLot;
    }

    public Float getTargetTnRwLot() {
        return targetTnRwLot;
    }

    public void setTargetTnRwLot(Float targetTnRwLot) {
        this.targetTnRwLot = targetTnRwLot;
    }

    public Date getRealPlantingDate() {
        return realPlantingDate;
    }

    public void setRealPlantingDate(Date realPlantingDate) {
        this.realPlantingDate = realPlantingDate;
    }

    public Date getRealFloweringDate() {
        return realFloweringDate;
    }

    public void setRealFloweringDate(Date realFloweringDate) {
        this.realFloweringDate = realFloweringDate;
    }

    public Date getRealHarvestDate() {
        return realHarvestDate;
    }

    public void setRealHarvestDate(Date realHarvestDate) {
        this.realHarvestDate = realHarvestDate;
    }

    public String getObsLine() {
        return obsLine;
    }

    public void setObsLine(String obsLine) {
        this.obsLine = obsLine;
    }

    public String getGeneralObs() {
        return generalObs;
    }

    public void setGeneralObs(String generalObs) {
        this.generalObs = generalObs;
    }

    public Date getSampleDateHumidity() {
        return sampleDateHumidity;
    }

    public void setSampleDateHumidity(Date sampleDateHumidity) {
        this.sampleDateHumidity = sampleDateHumidity;
    }

    public Float getHumidity() {
        return humidity;
    }

    public void setHumidity(Float humidity) {
        this.humidity = humidity;
    }


    public Float getHarvestRwToDs() {
        return harvestRwToDs;
    }

    public void setHarvestRwToDs(Float harvestRwToDs) {
        this.harvestRwToDs = harvestRwToDs;
    }

    public Float getActualTnDsLot() {
        return actualTnDsLot;
    }

    public void setActualTnDsLot(Float actualTnDsLot) {
        this.actualTnDsLot = actualTnDsLot;
    }

    public Float getActualTnRwLot() {
        return actualTnRwLot;
    }

    public void setActualTnRwLot(Float actualTnRwLot) {
        this.actualTnRwLot = actualTnRwLot;
    }

    public String getObsHarvestRwToDs() {
        return obsHarvestRwToDs;
    }

    public void setObsHarvestRwToDs(String obsHarvestRwToDs) {
        this.obsHarvestRwToDs = obsHarvestRwToDs;
    }

    public Integer getTrucks() {
        return trucks;
    }

    public void setTrucks(Integer trucks) {
        this.trucks = trucks;
    }

    public Float getWeightAverageTruck() {
        return weightAverageTruck;
    }

    public void setWeightAverageTruck(Float weightAverageTruck) {
        this.weightAverageTruck = weightAverageTruck;
    }

    public String getReceptionPlant() {
        return receptionPlant;
    }

    public void setReceptionPlant(String receptionPlant) {
        this.receptionPlant = receptionPlant;
    }

    public Float getHuskingKgDsLot() {
        return huskingKgDsLot;
    }

    public void setHuskingKgDsLot(Float huskingKgDsLot) {
        this.huskingKgDsLot = huskingKgDsLot;
    }

    public String getObsHuskingKgDsLot() {
        return obsHuskingKgDsLot;
    }

    public void setObsHuskingKgDsLot(String obsHuskingKgDsLot) {
        this.obsHuskingKgDsLot = obsHuskingKgDsLot;
    }

    public Float getHuskingKgDsHa() {
        return huskingKgDsHa;
    }

    public void setHuskingKgDsHa(Float huskingKgDsHa) {
        this.huskingKgDsHa = huskingKgDsHa;
    }

    public Float getQualityKgFngLot() {
        return qualityKgFngLot;
    }

    public void setQualityKgFngLot(Float qualityKgFngLot) {
        this.qualityKgFngLot = qualityKgFngLot;
    }

    public Float getGreenConversion() {
        return greenConversion;
    }

    public void setGreenConversion(Float greenConversion) {
        this.greenConversion = greenConversion;
    }

    public Float getEficienciaRwToDs() {
        return eficienciaRwToDs;
    }

    public void setEficienciaRwToDs(Float eficienciaRwToDs) {
        this.eficienciaRwToDs = eficienciaRwToDs;
    }

    public Float getActualKgDsLot() {
        return actualKgDsLot;
    }

    public void setActualKgDsLot(Float actualKgDsLot) {
        this.actualKgDsLot = actualKgDsLot;
    }

    public Float getActualTnDsHa() {
        return actualTnDsHa;
    }

    public void setActualTnDsHa(Float actualTnDsHa) {
        this.actualTnDsHa = actualTnDsHa;
    }

    public Float getQualityDsToFng() {
        return qualityDsToFng;
    }

    public void setQualityDsToFng(Float qualityDsToFng) {
        this.qualityDsToFng = qualityDsToFng;
    }

    public Float getQualityWeightBag() {
        return qualityWeightBag;
    }

    public void setQualityWeightBag(Float qualityWeightBag) {
        this.qualityWeightBag = qualityWeightBag;
    }

    public Float getBulkBagEst() {
        return bulkBagEst;
    }

    public void setBulkBagEst(Float bulkBagEst) {
        this.bulkBagEst = bulkBagEst;
    }

    public Float getBulkBagHaEst() {
        return bulkBagHaEst;
    }

    public void setBulkBagHaEst(Float bulkBagHaEst) {
        this.bulkBagHaEst = bulkBagHaEst;
    }

    public Float getBulkKgFNGHa() {
        return bulkKgFNGHa;
    }

    public void setBulkKgFNGHa(Float bulkKgFNGHa) {
        this.bulkKgFNGHa = bulkKgFNGHa;
    }

    public String getQualityObs() {
        return qualityObs;
    }

    public void setQualityObs(String qualityObs) {
        this.qualityObs = qualityObs;
    }

    public Float getEficienciaDsToFng() {
        return eficienciaDsToFng;
    }

    public void setEficienciaDsToFng(Float eficienciaDsToFng) {
        this.eficienciaDsToFng = eficienciaDsToFng;
    }

    public String getWarehouseUnit() {
        return warehouseUnit;
    }

    public void setWarehouseUnit(String warehouseUnit) {
        this.warehouseUnit = warehouseUnit;
    }

    public Float getActualKgFngLot() {
        return actualKgFngLot;
    }

    public void setActualKgFngLot(Float actualKgFngLot) {
        this.actualKgFngLot = actualKgFngLot;
    }

    public Float getPlsLot() {
        return plsLot;
    }

    public void setPlsLot(Float plsLot) {
        this.plsLot = plsLot;
    }

    public Float getIndexLot() {
        return indexLot;
    }

    public void setIndexLot(Float indexLot) {
        this.indexLot = indexLot;
    }

    public Float getPlLot() {
        return plLot;
    }

    public void setPlLot(Float plLot) {
        this.plLot = plLot;
    }

    public Float getBulkConversion() {
        return bulkConversion;
    }

    public void setBulkConversion(Float bulkConversion) {
        this.bulkConversion = bulkConversion;
    }

    public Float getEficienciaKgDescarte() {
        return eficienciaKgDescarte;
    }

    public void setEficienciaKgDescarte(Float eficienciaKgDescarte) {
        this.eficienciaKgDescarte = eficienciaKgDescarte;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getDateTransaction() {
        return dateTransaction;
    }

    public void setDateTransaction(Date dateTransaction) {
        this.dateTransaction = dateTransaction;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Integer getLotId() {
        return lotId;
    }

    public void setLotId(Integer lotId) {
        this.lotId = lotId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public Float getHarvestableHas() {
        return harvestableHas;
    }

    public void setHarvestableHas(Float harvestableHas) {
        this.harvestableHas = harvestableHas;
    }

    public Date getEstimatedPlantingDate() {
        return estimatedPlantingDate;
    }

    public void setEstimatedPlantingDate(Date estimatedPlantingDate) {
        this.estimatedPlantingDate = estimatedPlantingDate;
    }

    public Date getEstimatedFloweringDate() {
        return estimatedFloweringDate;
    }

    public void setEstimatedFloweringDate(Date estimatedFloweringDate) {
        this.estimatedFloweringDate = estimatedFloweringDate;
    }

    public Date getEstimatedHarvestDate() {
        return estimatedHarvestDate;
    }

    public void setEstimatedHarvestDate(Date estimatedHarvestDate) {
        this.estimatedHarvestDate = estimatedHarvestDate;
    }

    public Date getHarvestDateForHumidity() {
        return harvestDateForHumidity;
    }

    public void setHarvestDateForHumidity(Date harvestDateForHumidity) {
        this.harvestDateForHumidity = harvestDateForHumidity;
    }

    public Float getEstimatedDsHa() {
        return estimatedDsHa;
    }

    public void setEstimatedDsHa(Float estimatedDsHa) {
        this.estimatedDsHa = estimatedDsHa;
    }

    public Float getTargetRwToDs() {
        return targetRwToDs;
    }

    public void setTargetRwToDs(Float targetRwToDs) {
        this.targetRwToDs = targetRwToDs;
    }

    public Float getTargetDSToFNG() {
        return targetDSToFNG;
    }

    public void setTargetDSToFNG(Float targetDSToFNG) {
        this.targetDSToFNG = targetDSToFNG;
    }

    public Float getTargetKgBag() {
        return targetKgBag;
    }

    public void setTargetKgBag(Float targetKgBag) {
        this.targetKgBag = targetKgBag;
    }

    public Float getTargetBagHa() {
        return targetBagHa;
    }

    public void setTargetBagHa(Float targetBagHa) {
        this.targetBagHa = targetBagHa;
    }

    public Integer getFlowHarvDays() {
        return flowHarvDays;
    }

    public void setFlowHarvDays(Integer flowHarvDays) {
        this.flowHarvDays = flowHarvDays;
    }

    public Float getHarvestKgRWLot() {
        return harvestKgRWLot;
    }

    public void setHarvestKgRWLot(Float harvestKgRWLot) {
        this.harvestKgRWLot = harvestKgRWLot;
    }

    public Float getHarvestRWtoDS() {
        return harvestRWtoDS;
    }

    public void setHarvestRWtoDS(Float harvestRWtoDS) {
        this.harvestRWtoDS = harvestRWtoDS;
    }

    public Date getPlantingDate() {
        return plantingDate;
    }

    public void setPlantingDate(Date plantingDate) {
        this.plantingDate = plantingDate;
    }

    public Date getFloweringDate() {
        return floweringDate;
    }

    public void setFloweringDate(Date floweringDate) {
        this.floweringDate = floweringDate;
    }

    public Date getHarvestDate() {
        return harvestDate;
    }

    public void setHarvestDate(Date harvestDate) {
        this.harvestDate = harvestDate;
    }

    public Float getTnRwlot() {
        return tnRwlot;
    }

    public void setTnRwlot(Float tnRwlot) {
        this.tnRwlot = tnRwlot;
    }

    public Float getTnDsLot() {
        return tnDsLot;
    }

    public void setTnDsLot(Float tnDsLot) {
        this.tnDsLot = tnDsLot;
    }

    public Float getTnFngLot() {
        return tnFngLot;
    }

    public void setTnFngLot(Float tnFngLot) {
        this.tnFngLot = tnFngLot;
    }

    public Float getBagTotalLot() {
        return bagTotalLot;
    }

    public void setBagTotalLot(Float bagTotalLot) {
        this.bagTotalLot = bagTotalLot;
    }

    public Float getBagPeso() {
        return bagPeso;
    }

    public void setBagPeso(Float bagPeso) {
        this.bagPeso = bagPeso;
    }

    public Float getKgDSHa() {
        return kgDSHa;
    }

    public void setKgDSHa(Float kgDSHa) {
        this.kgDSHa = kgDSHa;
    }

    public Float getKgFngHa() {
        return kgFngHa;
    }

    public void setKgFngHa(Float kgFngHa) {
        this.kgFngHa = kgFngHa;
    }

    public Float getBagHas() {
        return bagHas;
    }

    public void setBagHas(Float bagHas) {
        this.bagHas = bagHas;
    }
}
