package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.LotHumidity;

import java.util.Date;

/**
 * Created by PGSETT on 08/07/2014.
 */
public class LotHumidityDTO {
    private Integer id;
    private Float humidity;
    private Date sampleDate;
    private LotDTO lot;

    public LotHumidityDTO() {
    }


    public LotHumidityDTO(LotHumidity lotHumidity, LotDTO lotDTO) {

        this.id = lotHumidity.getId();
        this.humidity = lotHumidity.getHumidity();
        this.sampleDate = lotHumidity.getSampleDate();

        this.lot = lotDTO;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Float getHumidity() {
        return humidity;
    }

    public void setHumidity(Float humidity) {
        this.humidity = humidity;
    }

    public Date getSampleDate() {
        return sampleDate;
    }

    public void setSampleDate(Date sampleDate) {
        this.sampleDate = sampleDate;
    }

    public LotDTO getLot() {
        return lot;
    }

    public void setLot(LotDTO lot) {
        this.lot = lot;
    }
}
