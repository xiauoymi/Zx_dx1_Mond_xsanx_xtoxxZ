package com.monsanto.prisma.core.dto;

/**
 * Created by EPESTE on 02/07/2014.
 */
public class LotSelectedDTO {
    private String lotCode;

    private Integer lotId;

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public Integer getLotId() {
        return lotId;
    }

    public void setLotId(Integer lotId) {
        this.lotId = lotId;
    }
}
