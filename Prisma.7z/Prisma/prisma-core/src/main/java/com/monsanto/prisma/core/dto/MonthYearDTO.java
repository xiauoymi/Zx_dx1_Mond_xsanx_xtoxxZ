package com.monsanto.prisma.core.dto;

/**
 * Created by PGSETT on 11/12/2014.
 */
public class MonthYearDTO {
    private Integer month;
    private Integer year;

    public MonthYearDTO(Integer month, Integer year) {
        this.month = month;
        this.year = year;
    }

    public MonthYearDTO() {
    }

    public Integer getMonth() {
        return month;
    }

    public void setMonth(Integer month) {
        this.month = month;
    }

    public Integer getYear() {
        return year;
    }

    public void setYear(Integer year) {
        this.year = year;
    }
}
