package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.PreHarvestHumidity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 07/07/2014.
 */
public class PreHarvestHumidityDTO implements Serializable {

    private Integer id;

    private String sourceHumidityFile;
    private Double humidity;
    private Date sampleDate;
    private Date dateCreation;
    private Integer campaign;
    private int imported;
    private int omitted;
    private List<LotHumidityDTO> lotHumidityDTOs;

    public PreHarvestHumidityDTO(PreHarvestHumidity preHarvestHumidity) {
        this.id = preHarvestHumidity.getId();
        this.sourceHumidityFile = preHarvestHumidity.getSourceHumidityFile();
        this.dateCreation = preHarvestHumidity.getDateCreation();
        this.campaign = preHarvestHumidity.getCampaign();
        this.imported = preHarvestHumidity.getImported();
        this.omitted = preHarvestHumidity.getOmitted();
        this.lotHumidityDTOs = preHarvestHumidity.getLotHumidityDTOs();

    }

    public List<LotHumidityDTO> getLotHumidityDTOs() {
        return lotHumidityDTOs;
    }

    public void setLotHumidityDTOs(List<LotHumidityDTO> lotHumidityDTOs) {
        this.lotHumidityDTOs = lotHumidityDTOs;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSourceHumidityFile() {
        return sourceHumidityFile;
    }

    public void setSourceHumidityFile(String sourceHumidityFile) {
        this.sourceHumidityFile = sourceHumidityFile;
    }

    public Double getHumidity() {
        return humidity;
    }

    public void setHumidity(Double humidity) {
        this.humidity = humidity;
    }

    public Date getSampleDate() {
        return sampleDate;
    }

    public void setSampleDate(Date sampleDate) {
        this.sampleDate = sampleDate;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public Integer getCampaign() {
        return campaign;
    }

    public void setCampaign(Integer campaign) {
        this.campaign = campaign;
    }

    public int getImported() {
        return imported;
    }

    public void setImported(int imported) {
        this.imported = imported;
    }

    public int getOmitted() {
        return omitted;
    }

    public void setOmitted(int omitted) {
        this.omitted = omitted;
    }
}
