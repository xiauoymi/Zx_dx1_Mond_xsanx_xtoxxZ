package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.LotCombo;
import com.monsanto.prisma.core.domain.PreviousLot;
import com.monsanto.prisma.core.domain.PreviousLotPK;

import java.io.Serializable;
import java.util.List;

/**
 * Created by PGSETT on 18/11/2014.
 */
public class PreviousLotDTO implements Serializable{

    private Integer id;
    private String lotCode;
    private Boolean isPreviousLot;

    public PreviousLotDTO(LotCombo lotCombo,List<PreviousLot> previousLots) {
        this.id = lotCombo.getId();
        this.lotCode = lotCombo.getLotCode();
        this.isPreviousLot = false;
        for (PreviousLot prev : previousLots){
            if (prev.getPreviousLot().equals(lotCombo.getId())){
                this.isPreviousLot = true;
            }
        }
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public Boolean getIsPreviousLot() {
        return isPreviousLot;
    }

    public void setIsPreviousLot(Boolean isPreviousLot) {
        this.isPreviousLot = isPreviousLot;
    }
}
