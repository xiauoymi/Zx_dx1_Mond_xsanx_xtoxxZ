package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.PrismaFunctionality;

import java.io.Serializable;

/**
 * Created by EPESTE on 22/09/2014.
 */
public class PrismaFunctionalityDTO implements Serializable {
    private Integer id;

    private String functionality;

    private String action;

    private Boolean selected;

    public PrismaFunctionalityDTO() {
    }

    public PrismaFunctionalityDTO(PrismaFunctionality prismaFunctionality) {
        setId(prismaFunctionality.getId());
        setFunctionality(prismaFunctionality.getFunctionality());
        setAction(prismaFunctionality.getAction());
        setSelected(Boolean.FALSE);
    }

    public PrismaFunctionalityDTO(PrismaFunctionality prismaFunctionality, Boolean selected) {
        setId(prismaFunctionality.getId());
        setFunctionality(prismaFunctionality.getFunctionality());
        setAction(prismaFunctionality.getAction());
        setSelected(selected);
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFunctionality() {
        return functionality;
    }

    public void setFunctionality(String functionality) {
        this.functionality = functionality;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public Boolean getSelected() {
        return selected;
    }

    public void setSelected(Boolean selected) {
        this.selected = selected;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        PrismaFunctionalityDTO prismaFunctionality = (PrismaFunctionalityDTO) obj;
        if (this.functionality.equals(prismaFunctionality.getFunctionality())) {
            if (this.action.equals(prismaFunctionality.getAction())) {
                if (this.selected == prismaFunctionality.getSelected()) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }

        return false;
    }
}
