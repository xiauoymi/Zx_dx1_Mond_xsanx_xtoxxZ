package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.PrismaFunctionality;
import com.monsanto.prisma.core.domain.Profile;

import java.io.Serializable;
import java.util.List;

/**
 * Created by EPESTE on 12/09/2014.
 */
public class ProfileDTO implements Serializable {
    private Integer id;

    private String name;

    private Boolean enabled;

    private List<PrismaFunctionality> functionalities;

    public ProfileDTO() {
    }

    public ProfileDTO(Integer id) {
        setId(id);
    }

    public ProfileDTO(Profile profile) {
        setId(profile.getId());
        setName(profile.getName());
        setEnabled(profile.getEnabled());
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public List<PrismaFunctionality> getFunctionalities() {
        return functionalities;
    }

    public void setFunctionalities(List<PrismaFunctionality> functionalities) {
        this.functionalities = functionalities;
    }
}
