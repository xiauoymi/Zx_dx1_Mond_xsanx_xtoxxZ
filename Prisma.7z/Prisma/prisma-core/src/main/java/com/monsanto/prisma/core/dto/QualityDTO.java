package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.QualityFile;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by EPESTE on 29/07/2014.
 */
public class QualityDTO implements Serializable {

    private String pathFile;

    private Date dateProcess;

    private Integer lotsModified;

    private Integer lotsNotModified;

    private List<LotDTO> lotDTOs;

    public String getPathFile() {
        return pathFile;
    }

    public QualityDTO(QualityFile qualityFile) {
        this.pathFile = qualityFile.getPathFile();
        this.dateProcess = qualityFile.getDateProcess();
        this.lotsModified = qualityFile.getLotsModified();
        this.lotsNotModified = qualityFile.getLotsNotModified();
        this.lotDTOs = qualityFile.getLotDTOs();
    }

    public void setPathFile(String pathFile) {
        this.pathFile = pathFile;
    }

    public Date getDateProcess() {
        return dateProcess;
    }

    public void setDateProcess(Date dateProcess) {
        this.dateProcess = dateProcess;
    }

    public Integer getLotsModified() {
        return lotsModified;
    }

    public void setLotsModified(Integer lotsModified) {
        this.lotsModified = lotsModified;
    }

    public Integer getLotsNotModified() {
        return lotsNotModified;
    }

    public void setLotsNotModified(Integer lotsNotModified) {
        this.lotsNotModified = lotsNotModified;
    }

    public List<LotDTO> getLotDTOs() {
        return lotDTOs;
    }

    public void setLotDTOs(List<LotDTO> lotDTOs) {
        this.lotDTOs = lotDTOs;
    }
}

