package com.monsanto.prisma.core.dto;

import java.io.Serializable;

/**
 * Created by EPESTE on 27/08/2014.
 */
public class ReceiveTonsDTO implements Serializable {

    private String hybridName;

    private String zoneCode;

    private String lotCode;

    private String program;

    private Float harvestWeek;

    private int year;

    private Float sumActualTnRwLot;


    public ReceiveTonsDTO() {
    }

    public ReceiveTonsDTO(Object[] objects, Boolean isHybridOrZone) {

        if (isHybridOrZone) {
            this.zoneCode = (String) objects[0];
            this.hybridName = (String) objects[0];
        } else {
            this.lotCode = (String) objects[0];
            this.program = (String) objects[0];
        }
        this.harvestWeek = (Float) objects[1];
        this.year = new Integer((String) objects[2]);
        Double sumTnRw = (Double) objects[3];
        this.sumActualTnRwLot = sumTnRw != null ? new Float(sumTnRw) : null;
    }


    public ReceiveTonsDTO(Float harvestWeek, Integer year) {
        setHarvestWeek(harvestWeek);
        setYear(year);
    }

    public String getZoneCode() {
        return zoneCode;
    }

    public void setZoneCode(String zoneCode) {
        this.zoneCode = zoneCode;
    }

    public Float getHarvestWeek() {
        return harvestWeek;
    }

    public void setHarvestWeek(Float harvestWeek) {
        this.harvestWeek = harvestWeek;
    }

    public Float getSumActualTnRwLot() {
        return sumActualTnRwLot;
    }

    public void setSumActualTnRwLot(Float sumActualTnRwLot) {
        this.sumActualTnRwLot = sumActualTnRwLot;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }
}
