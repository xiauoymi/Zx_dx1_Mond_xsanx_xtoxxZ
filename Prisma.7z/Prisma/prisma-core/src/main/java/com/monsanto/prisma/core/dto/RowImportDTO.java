package com.monsanto.prisma.core.dto;

import java.util.List;

/**
 * Created by AFREI on 09/09/2014.
 */
public class RowImportDTO<DATA extends Object> {

    DATA data;
    List<CellOmittedDTO> omittedCells;

    public void setData(DATA data) {
        this.data = data;
    }

    public DATA getData() {
        return data;
    }

    public List<CellOmittedDTO> getOmittedCells() {
        return omittedCells;
    }

    public void setOmittedCells(List<CellOmittedDTO> omittedCells) {
        this.omittedCells = omittedCells;
    }
}
