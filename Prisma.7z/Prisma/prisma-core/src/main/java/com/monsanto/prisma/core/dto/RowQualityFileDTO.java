package com.monsanto.prisma.core.dto;

/**
 * Created by EPESTE on 29/07/2014.
 */
public class RowQualityFileDTO {
    private String lotCode;

    private Float qualityDsToFng;

    private Float qualityWeightBag;

    public RowQualityFileDTO() {
        this.qualityDsToFng = new Float(0);
        this.qualityWeightBag = new Float(0);
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public Float getQualityDsToFng() {
        return qualityDsToFng;
    }

    public void setQualityDsToFng(Float qualityDsToFng) {
        this.qualityDsToFng = qualityDsToFng;
    }

    public Float getQualityWeightBag() {
        return qualityWeightBag;
    }

    public void setQualityWeightBag(Float qualityWeightBag) {
        this.qualityWeightBag = qualityWeightBag;
    }
}
