package com.monsanto.prisma.core.dto;

/**
 * Created by PGSETT on 29/08/2014.
 */
public class StatusReportDTO {

    private String plantName;
    private String program;
    private String hybridName;
    private String umProgram;
    private Double actual;
    private Double baggingStatus;
    private Double initialProgram;
    private Double field;
    private Double plant;
    private Double bagging;
    private String embolse;
    private String unidadComercial;
    private Double bolsasComerciales;
    private Double tnDs;
    private String granProgram;
    private String germoplasma;


    public StatusReportDTO(Object[] objects) {
        this.hybridName = (String) objects[0];
        this.actual = (Double) objects[1];
        this.tnDs = (Double) objects[2];
        this.field = 0D;
        this.plant = 0D;
        this.bagging = 0D;
    }



    public String getPlantName() {
        return plantName;
    }

    public void setPlantName(String plantName) {
        this.plantName = plantName;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }





    public Double getInitialProgram() {
        return initialProgram;
    }

    public void setInitialProgram(Double initialProgram) {
        this.initialProgram = initialProgram;
    }

    public Double getField() {
        return field;
    }

    public void setField(Double field) {
        this.field = field;
    }

    public Double getPlant() {
        return plant;
    }

    public void setPlant(Double plant) {
        this.plant = plant;
    }

    public Double getBagging() {
        return bagging;
    }

    public void setBagging(Double bagging) {
        this.bagging = bagging;
    }

    public String getEmbolse() {
        return embolse;
    }

    public void setEmbolse(String embolse) {
        this.embolse = embolse;
    }

    public String getUmProgram() {
        return umProgram;
    }

    public void setUmProgram(String umProgram) {
        this.umProgram = umProgram;
    }

    public String getUnidadComercial() {
        return unidadComercial;
    }

    public void setUnidadComercial(String unidadComercial) {
        this.unidadComercial = unidadComercial;
    }

    public Double getBolsasComerciales() {
        return bolsasComerciales;
    }

    public void setBolsasComerciales(Double bolsasComerciales) {
        this.bolsasComerciales = bolsasComerciales;
    }

    public String getGranProgram() {
        return granProgram;
    }

    public void setGranProgram(String granProgram) {
        this.granProgram = granProgram;
    }

    public String getGermoplasma() {
        return germoplasma;
    }

    public void setGermoplasma(String germoplasma) {
        this.germoplasma = germoplasma;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }


    public Double getActual() {
        return actual;
    }

    public void setActual(Double actual) {
        this.actual = actual;
    }

    public Double getBaggingStatus() {
        return baggingStatus;
    }

    public void setBaggingStatus(Double baggingStatus) {
        this.baggingStatus = baggingStatus;
    }


    public Double getTnDs() {
        return tnDs;
    }

    public void setTnDs(Double tnDs) {
        this.tnDs = tnDs;
    }

}
