package com.monsanto.prisma.core.dto;

/**
 * Created by PGSETT on 29/08/2014.
 */
public class TonsToHostDTO {

    private String hybridName;

    private String zoneCode;

    private String lotCode;

    private String program;

    private Float harvestWeek;

    private int year;

    private Double sumActualTnDSLot;

    public TonsToHostDTO() {
    }

    public TonsToHostDTO(Object[] objects, Boolean isHybridOrZone) {
        if (isHybridOrZone) {
            this.zoneCode = (String) objects[0];
            this.hybridName = (String) objects[0];
        } else {
            this.lotCode = (String) objects[0];
            this.program = (String) objects[0];
        }
        this.harvestWeek = (Float) objects[1];
        this.year = new Integer((String) objects[2]);
        this.sumActualTnDSLot = (Double) objects[3];
    }

    public TonsToHostDTO(Float harvestWeek, Integer year) {
        setHarvestWeek(harvestWeek);
        setYear(year);
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }

    public String getZoneCode() {
        return zoneCode;
    }

    public void setZoneCode(String zoneCode) {
        this.zoneCode = zoneCode;
    }

    public String getLotCode() {
        return lotCode;
    }

    public void setLotCode(String lotCode) {
        this.lotCode = lotCode;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public Float getHarvestWeek() {
        return harvestWeek;
    }

    public void setHarvestWeek(Float harvestWeek) {
        this.harvestWeek = harvestWeek;
    }

    public Double getSumActualTnDSLot() {
        return sumActualTnDSLot;
    }

    public void setSumActualTnDSLot(Double sumActualTnDSLot) {
        this.sumActualTnDSLot = sumActualTnDSLot;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}
