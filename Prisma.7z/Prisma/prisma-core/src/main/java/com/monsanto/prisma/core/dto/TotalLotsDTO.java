package com.monsanto.prisma.core.dto;

/**
 * Created by PGSETT on 23/10/2014.
 */
public class TotalLotsDTO {

    private Long totalLots;
    private Double totalRegisteredHas;
    private Double totalHarvestableHas;

    public TotalLotsDTO(Object[] objects) {
        this.totalLots = (Long) objects[0];
        this.totalRegisteredHas = (Double) objects[1];
        this.totalHarvestableHas = (Double) objects[2];
    }

    public TotalLotsDTO(Long totalLots, Double totalRegisteredHas, Double totalHarvestableHas) {
        setTotalLots(totalLots);
        setTotalRegisteredHas(totalRegisteredHas);
        setTotalHarvestableHas(totalHarvestableHas);
    }

    public Long getTotalLots() {
        return totalLots;
    }

    public void setTotalLots(Long totalLots) {
        this.totalLots = totalLots;
    }

    public Double getTotalRegisteredHas() {
        return totalRegisteredHas;
    }

    public void setTotalRegisteredHas(Double totalRegisteredHas) {
        this.totalRegisteredHas = totalRegisteredHas;
    }

    public Double getTotalHarvestableHas() {
        return totalHarvestableHas;
    }

    public void setTotalHarvestableHas(Double totalHarvestableHas) {
        this.totalHarvestableHas = totalHarvestableHas;
    }
}
