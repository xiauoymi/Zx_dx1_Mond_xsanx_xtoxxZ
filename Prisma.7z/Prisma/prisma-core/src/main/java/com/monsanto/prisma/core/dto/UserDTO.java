package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.Profile;
import com.monsanto.prisma.core.domain.Region;
import com.monsanto.prisma.core.domain.User;

import java.io.Serializable;
import java.util.List;

public class UserDTO implements Serializable {

    private Long id;
    private String userName;
    private Boolean enabled;
    private String fullName;
    private List<Profile> profiles;
    private List<Region> regions;

    public UserDTO() {

    }

    public UserDTO(User user) {
        setId(user.getId());
        setUserName(user.getUserName());
        setEnabled(user.getEnabled());
        setFullName(user.getFullName());
        setProfiles(user.getProfiles());
        setRegions(user.getRegions());
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public User getUser() {
        User user = new User();
        user.setId(this.getId());
        user.setUserName(this.getUserName());
        user.setEnabled(this.getEnabled());
        user.setFullName(this.getFullName());
        return user;
    }

    public List<Profile> getProfiles() {
        return profiles;
    }

    public void setProfiles(List<Profile> profiles) {
        this.profiles = profiles;
    }

    public List<Region> getRegions() {
        return regions;
    }

    public void setRegions(List<Region> regions) {
        this.regions = regions;
    }
}
