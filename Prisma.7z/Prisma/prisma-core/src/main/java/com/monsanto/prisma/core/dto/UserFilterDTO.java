package com.monsanto.prisma.core.dto;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.Filter;
import com.monsanto.prisma.core.domain.UserFilter;

import javax.annotation.Nullable;
import javax.persistence.Column;
import javax.persistence.OneToMany;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by epeste on 31/10/2014.
 */
public class UserFilterDTO implements Serializable {
    private Integer id;

    private String name;

    private String description;

    private List<FilterDTO> filterList;

    public UserFilterDTO() {
    }

    public UserFilterDTO(UserFilter userFilter) {
        setId(userFilter.getId());
        setName(userFilter.getName());
        setDescription(userFilter.getDescription());
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<FilterDTO> getFilterList() {
        return filterList;
    }

    public void setFilterList(List<FilterDTO> filterList) {
        this.filterList = filterList;
    }
}
