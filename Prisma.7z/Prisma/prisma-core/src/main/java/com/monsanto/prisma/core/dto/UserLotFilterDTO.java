package com.monsanto.prisma.core.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by epeste on 10/11/2014.
 */
public class UserLotFilterDTO implements Serializable {
    private Integer campaignId;

    private List<FilterDTO> filters;

    public UserLotFilterDTO() {
        filters = new ArrayList<FilterDTO>();
    }

    public Integer getCampaignId() {
        return campaignId;
    }

    public List<FilterDTO> getFilters() {
        return filters;
    }

    public void setCampaignId(Integer campaignId) {
        this.campaignId = campaignId;
    }

    public void setFilters(List<FilterDTO> filters) {
        this.filters = filters;
    }


}
