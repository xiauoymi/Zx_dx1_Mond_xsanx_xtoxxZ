package com.monsanto.prisma.core.dto;

import com.monsanto.prisma.core.domain.Zone;

import java.io.Serializable;

/**
 * Created by EPESTE on 25/08/2014.
 */
public class ZoneDTO implements Serializable {

    private Integer id;

    private String code;

    public ZoneDTO(Zone zone) {
        this.id = zone.getId();
        this.code = zone.getCode();
    }

    public ZoneDTO(Object[] obj) {
        this.id = (Integer)obj[0];
        this.code = (String)obj[1];
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
