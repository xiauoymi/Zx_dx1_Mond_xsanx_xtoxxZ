package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 24/07/2014.
 */
public class BatchException extends Exception {

    public BatchException(Exception e){
        super(e);
    }

    public BatchException(){
        super();
    }
}
