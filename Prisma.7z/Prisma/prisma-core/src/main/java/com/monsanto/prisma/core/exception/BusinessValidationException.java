package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 7/16/2014.
 */
public class BusinessValidationException extends Exception {

    public BusinessValidationException(){
        super();
    }

    public BusinessValidationException(String message){
        super(message);
    }
}
