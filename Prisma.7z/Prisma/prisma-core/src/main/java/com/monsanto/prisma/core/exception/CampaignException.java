package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 5/14/2014.
 */
public class CampaignException extends Exception {

    public CampaignException() {
        super();
    }

    public CampaignException(String message) {
        super(message);
    }

    public CampaignException(Throwable e) {
        super(e);
    }

    public CampaignException(String message, Throwable e) {
        super(message, e);
    }
}
