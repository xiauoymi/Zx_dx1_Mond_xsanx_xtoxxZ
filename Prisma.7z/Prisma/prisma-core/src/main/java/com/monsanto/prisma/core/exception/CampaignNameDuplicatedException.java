package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 27/08/2014.
 */
public class CampaignNameDuplicatedException extends CampaignException {

    public CampaignNameDuplicatedException() {
        super();
    }
}
