package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 6/17/2014.
 */
public class CampaignUnableToChangeException extends CampaignException {

    public CampaignUnableToChangeException() {
        super();
    }
}
