package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 26/08/2014.
 */
public class ExistsBatchWithNameException extends BatchException {

    public ExistsBatchWithNameException(){
        super();
    }
}
