package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 5/28/2014.
 */
public class ExistsLotsForThisCampaignException extends CampaignException {

    public ExistsLotsForThisCampaignException() {
        super();
    }
}
