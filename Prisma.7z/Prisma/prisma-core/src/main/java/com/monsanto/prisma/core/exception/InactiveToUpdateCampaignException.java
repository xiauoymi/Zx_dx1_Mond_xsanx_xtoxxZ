package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 6/16/2014.
 */
public class InactiveToUpdateCampaignException extends CampaignException {

    public InactiveToUpdateCampaignException() {
        super();
    }
}
