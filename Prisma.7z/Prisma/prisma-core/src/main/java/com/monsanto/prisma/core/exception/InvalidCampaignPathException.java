package com.monsanto.prisma.core.exception;

/**
 * Created by AFREI on 16/07/2014.
 */
public class InvalidCampaignPathException extends CampaignException {
    public InvalidCampaignPathException(String message) {
        super(message);
    }

    public InvalidCampaignPathException(BusinessException e) {
        super(e);
    }

    public InvalidCampaignPathException(String message, BusinessException e) {
        super(message, e);
    }
}
