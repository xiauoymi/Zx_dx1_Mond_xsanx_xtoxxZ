package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 20/08/2014.
 */
public class KgDsAssignedInvalidException extends BatchException {

    public KgDsAssignedInvalidException(){
        super();
    }
}
