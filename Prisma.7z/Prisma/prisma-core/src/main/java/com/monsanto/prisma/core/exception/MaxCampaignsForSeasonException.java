package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 5/28/2014.
 */
public class MaxCampaignsForSeasonException extends CampaignException {

    public MaxCampaignsForSeasonException(String message) {
        super(message);
    }
}
