package com.monsanto.prisma.core.exception;

import org.apache.poi.ss.usermodel.Row;

/**
 * Created by AFREI on 09/09/2014.
 */
public class ParserRowException extends BusinessException {
    private final Row row;
    private final int index;

    public ParserRowException(Row row, int index) {
        super();
        this.row = row;
        this.index = index;
    }

    public ParserRowException(Row row, int index, Exception e) {
        super(e);
        this.row = row;
        this.index = index;
    }

    public Row getRow() {
        return row;
    }

    public int getIndex() {
        return index;
    }


}
