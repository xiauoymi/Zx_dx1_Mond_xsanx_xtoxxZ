package com.monsanto.prisma.core.exception;

/**
 * Created by BSBUON on 5/29/2014.
 */
public class SeasonNotExistsException extends CampaignException {

    public SeasonNotExistsException() {
        super();
    }
}
