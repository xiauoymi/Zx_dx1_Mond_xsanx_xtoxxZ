package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Area;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by EPESTE on 19/05/2014.
 */
public interface AreaRepository extends CrudRepository<Area, Integer> {
}
