package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Batch;
import com.monsanto.prisma.core.domain.Campaign;
import com.monsanto.prisma.core.domain.LotBatch;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface BatchRepository extends CrudRepository<Batch,Integer> {

    public static final String FIND_BY_CAMPAIGN_ID = "SELECT ba FROM Batch ba " +
                                                    " join fetch ba.campaign " +
                                                    " join fetch ba.hybrid " +
                                                    " WHERE ba.campaign.id = :campaignId" +
                                                    " ORDER BY ba.id desc";

    public static final String FIND_BY_ID = "SELECT b FROM Batch b " +
                                            " join fetch b.campaign c " +
                                            " join fetch b.hybrid h " +
                                            " WHERE b.id = :batchId";

    public static final String FIND_BY_ID_WITH_LOTS ="SELECT b FROM Batch b " +
                                                    " join fetch b.campaign c " +
                                                    " join fetch b.hybrid h " +
                                                    " left join fetch b.lotBatches lb " +
                                                    " WHERE b.id = :batchId";

    public static final String FIND_ASSOCIATED_LOTS = "SELECT distinct b.lotBatches from Batch b " +
                                                    " left outer join b.lotBatches " +
                                                    " WHERE b.id = :batchId";

    @Query(FIND_BY_CAMPAIGN_ID)
    @Transactional(readOnly = true)
    public List<Batch> findByCampaignId(@Param("campaignId")Integer campaignId);

    @Query(FIND_BY_ID)
    @Transactional(readOnly = true)
    public Batch findByBatchId(@Param("batchId") Integer id);

    @Query(FIND_BY_ID_WITH_LOTS)
    @Transactional(readOnly = true)
    public Batch findByIdWithLots(@Param("batchId")Integer id);

    @Query(FIND_ASSOCIATED_LOTS)
    @Transactional(readOnly = true)
    public List<LotBatch> findAssociatedLots(@Param("batchId") Integer batchId);

    @Transactional(readOnly = true)
    public Batch findByNameAndCampaign(String name, Campaign campaign);
}
