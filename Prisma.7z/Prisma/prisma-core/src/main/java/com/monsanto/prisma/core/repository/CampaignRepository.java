package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Campaign;
import com.monsanto.prisma.core.domain.Region;
import com.monsanto.prisma.core.domain.Season;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * CampaignRepository
 */
@Repository
public interface CampaignRepository extends CrudRepository<Campaign, Integer> {

    public final static String FIND_ALL_CAMPAIGNS = "SELECT distinct c " +
            " FROM Campaign c" +
            " join fetch c.crop " +
            " join fetch c.season se" +
            " join fetch se.country co" +
            " join fetch co.region re" +
            " WHERE c.isDeleted is null or c.isDeleted = False" +
            " order by c.id desc";

    public final static String CAMPAIGN_BY_ID = "SELECT distinct c " +
            " FROM Campaign c" +
            " join fetch c.crop " +
            " join fetch c.season se" +
            " join fetch se.crop" +
            " join fetch se.country co" +
            " join fetch co.region re" +
            " WHERE c.id = :campaignId and (c.isDeleted is null or c.isDeleted = False)";

    public final static String CAMPAIGN_BY_IS_ACTIVE = "SELECT distinct c " +
            " FROM Campaign c" +
            " join fetch c.crop " +
            " join fetch c.season se" +
            " join fetch se.country co" +
            " join fetch co.region re" +
            " WHERE c.isActive = :isActive and (c.isDeleted is null or c.isDeleted = False)";

    public final static String CAMPAIGN_BY_SEASON_AND_IS_ACTIVE = "SELECT distinct c " +
            " FROM Campaign c" +
            " join fetch c.crop " +
            " join fetch c.season se" +
            " join fetch se.country co" +
            " join fetch co.region re" +
            " WHERE c.isActive = :isActive and " +
            " (c.isDeleted is null or c.isDeleted = False) " +
            " AND c.season = :season";

    public static final String CAMPAIGN_BY_REGIONS_AND_ACTIVED = "SELECT distinct c " +
            " FROM Campaign c" +
            " join fetch c.crop " +
            " join fetch c.season se" +
            " join fetch se.country co" +
            " join fetch co.region re" +
            " WHERE c.isActive = true and " +
            " (c.isDeleted is null or c.isDeleted = False) " +
            " AND co.region in :regions";

    public static final String CAMPAIGN_BY_REGION = "SELECT c " +
            " FROM Campaign c" +
            " join fetch c.crop " +
            " join fetch c.season se" +
            " join fetch se.country co" +
            " join fetch co.region re" +
            " WHERE (c.isDeleted is null or c.isDeleted = False) " +
            " AND co.region in :regions";



    public static final String FILTER_STATUS_REPORT = "select  distinct h.name,   " +
            "    sum(l.actualBagLot),  sum(l.huskingKgDsLot)  " +
            "  from  Hybrid h,  Lot l   where  l.campaign.id = :campaignId" +
            "        and ( h.id=:hybridId  or :hybridId is null ) and ( l.program=:program  or :program is null ) " +
            "  and  l.hybrid.id = h.id  and l.state = true " +
            "    group by  h.name " +
            "    order by  h.name";

    public static final String FILTER_STATUS_REPORT_WITH_BATCH = "select  distinct sum(lb.bagLotAssigned), sum(lb.kgFNGLotAssigned)  " +
            "  from Lot l, LotBatch lb  where  l.campaign.id = :campaignId" +
            "        and  l.hybrid.name = :hybridName   " +
            "  and  l = lb.pk.lot  and l.state = true " +
            "    group by  l.hybrid ";


    public static final String FILTER_BULK_DESTINATION_REPORT = "select l.warehouseUnit, h.name, " +
            " sum(l.huskingKgDsLot) from Lot l,  " +
            "      Campaign c, " +
            "      Hybrid h " +
            " WHERE c.id = :campaignId " +
            " and l.campaign.id = c.id and l.hybrid.id = h.id" +
            " and (h.id = :hybridId or :hybridId is null) " +
            " and l.warehouseUnit like concat(:warehouseUnit, '%') " +
            " and l.state = true  " +
            " group by l.warehouseUnit,h.name  " +
            " order by l.warehouseUnit";

    @Transactional(readOnly = true)
    public Campaign findByName(String name);

    @Transactional(readOnly = true)
    @Query(FIND_ALL_CAMPAIGNS)
    public List<Campaign> findAllCampaigns();

    @Transactional(readOnly = true)
    @Query(CAMPAIGN_BY_ID)
    public Campaign findById(@Param("campaignId") Integer campaignId);

    @Transactional(readOnly = true)
    @Query(CAMPAIGN_BY_IS_ACTIVE)
    public List<Campaign> findByIsActive(@Param("isActive") Boolean isActive);

    @Transactional(readOnly = true)
    @Query(CAMPAIGN_BY_SEASON_AND_IS_ACTIVE)
    public List<Campaign> findBySeasonAndByIsActive(@Param("season") Season season, @Param("isActive") Boolean isActive);

    @Transactional(readOnly = true)
    @Query(CAMPAIGN_BY_REGIONS_AND_ACTIVED)
    public List<Campaign> findByRegionsAndActived(@Param("regions") List<Region> regions);

    @Transactional(readOnly = true)
    @Query(CAMPAIGN_BY_REGION)
    public List<Campaign> findByRegion(@Param("regions") List<Region> regions);

    @Transactional(readOnly = true)
    @Query(FILTER_BULK_DESTINATION_REPORT)
    public List<Object[]> filterBulkDestinationReport(@Param("warehouseUnit") String warehouseUnit, @Param("hybridId") Integer hybridId,
                                                      @Param("campaignId") Integer campaignId);

    @Transactional(readOnly = true)
    @Query(FILTER_STATUS_REPORT)
    public List<Object[]> filterStatusReport(@Param("hybridId") Integer hybridId, @Param("program") String program, @Param("campaignId") Integer campaignId);

    @Transactional(readOnly = true)
    @Query(FILTER_STATUS_REPORT_WITH_BATCH)
    public List<Object[]> filterStatusReportWithBatch(@Param("hybridName") String hybridName, @Param("campaignId") Integer campaignId);

}
