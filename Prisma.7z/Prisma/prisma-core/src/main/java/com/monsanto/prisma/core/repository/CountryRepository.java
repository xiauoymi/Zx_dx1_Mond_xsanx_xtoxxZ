package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Country;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by BSBUON on 5/19/2014.
 */
public interface CountryRepository extends CrudRepository<Country,Integer>{

    public static final String FIND_BY_REGION_ID = "SELECT c from Country c " +
            "join fetch c.region r " +
            "WHERE r.id = :id";

    @Transactional(readOnly = true)
    @Query(FIND_BY_REGION_ID)
    public List<Country> findByRegionId(@Param("id")Integer regionId);

}
