package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Crop;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by BSBUON on 5/15/2014.
 */
@Repository
public interface CropRepository extends CrudRepository<Crop, Integer> {

    public Crop findByName(String name);
}
