package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Establishment;
import com.monsanto.prisma.core.domain.Zone;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * ZoneRepository
 */
@Repository
public interface EstablishmentRepository extends CrudRepository<Establishment, Integer> {

    String FIND_BY_NAME_AND_ZONE = "SELECT e FROM Establishment e " +
            " JOIN e.zone z" +
            " WHERE e.name = :establishmentName and z.code = :zoneCode";


    Establishment findByName(String name);


    @Transactional(readOnly = true)
    @Query(FIND_BY_NAME_AND_ZONE)
    Establishment findByNameAndZone(@Param("establishmentName") String establishmentName, @Param("zoneCode") String zoneCode);
}
