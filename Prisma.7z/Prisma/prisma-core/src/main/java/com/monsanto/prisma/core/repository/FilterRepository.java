package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Filter;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by EPESTE on 31/10/2014.
 */
public interface FilterRepository extends CrudRepository<Filter, Integer> {
}
