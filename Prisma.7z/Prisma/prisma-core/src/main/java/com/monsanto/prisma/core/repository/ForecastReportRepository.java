package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.dto.ForecastReportDTO;

import java.util.List;

/**
 * Created by EPESTE on 10/12/2014.
 */
public interface ForecastReportRepository {
    List findMaxMinDatesRwDsFng(Integer campaignId);

    List findEstimatedRealRwByGranProgram(Integer campaignId);

    List findEstimatedRealDsByGranProgram(Integer campaignId);

    List findEstimatedRealFngByGranProgram(Integer campaignId);
}
