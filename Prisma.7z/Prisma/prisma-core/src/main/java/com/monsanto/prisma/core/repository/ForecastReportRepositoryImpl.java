package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.dto.ForecastReportDTO;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.*;

/**
 * Created by EPESTE on 10/12/2014.
 */
@Repository
public class ForecastReportRepositoryImpl implements ForecastReportRepository {

    @PersistenceContext
    private EntityManager em;

    private static final String QUERY_ESTIMATED_REAL_RW_BY_GRAN_PROGRAM =
            "select l.granProgram, to_char(l.realRwReceiptDate, 'YYYY/MM'), sum(l.harvestKgRWLot), to_char(l.estimatedRwDate, 'YYYY/MM'), sum(l.targetTnRwLot) " +
                    "from Lot l, Campaign c where l.campaign = c.id and c.id = %d " +
                    "group by l.granProgram, to_char(l.realRwReceiptDate, 'YYYY/MM'), to_char(l.estimatedRwDate, 'YYYY/MM') " +
                    " order by l.granProgram";

    private static final String QUERY_ESTIMATED_REAL_DS_BY_GRAN_PROGRAM =
            "select l.granProgram, to_char(l.realDsDate, 'YYYY/MM'), sum(l.actualTnDsLot), to_char(l.estimatedDsDate, 'YYYY/MM'), sum(l.targetTnDsLot) " +
                    "from Lot l, Campaign c where l.campaign = c.id and c.id = %d " +
                    "group by l.granProgram, to_char(l.realDsDate, 'YYYY/MM'), to_char(l.estimatedDsDate, 'YYYY/MM') " +
                    " order by l.granProgram";

    private static final String QUERY_ESTIMATED_REAL_FNG_BY_GRAN_PROGRAM =
            "select l.granProgram, to_char(l.realFngEnd, 'YYYY/MM'), sum(l.actualTnFngLot), to_char(l.estimatedFngEnd, 'YYYY/MM'), sum(l.estimatedTnFngLot) " +
                    "from Lot l, Campaign c where l.campaign = c.id and c.id = %d " +
                    "group by l.granProgram, to_char(l.realFngEnd, 'YYYY/MM'), to_char(l.estimatedFngEnd, 'YYYY/MM') " +
                    " order by l.granProgram";

    @Override
    public List findMaxMinDatesRwDsFng(Integer campaignId) {

        String queryMinMaxMonth = "select max(l.realRwReceiptDate), max(l.estimatedRwDate), max(l.realDsDate), max(l.estimatedDsDate), max(l.realFngEnd), max(l.estimatedFngEnd) "
                + ", min(l.realRwReceiptDate), min(l.estimatedRwDate), min(l.realDsDate), min(l.estimatedDsDate), min(l.realFngEnd), min(l.estimatedFngEnd) "
                + "from Lot l, Campaign c where l.campaign = c.id and c.id = " + campaignId;

        Query query = em.createQuery(queryMinMaxMonth);
        return Arrays.asList((Object[]) query.getSingleResult());
    }

    @Override
    public List findEstimatedRealRwByGranProgram(Integer campaignId) {
        Query query = em.createQuery(String.format(QUERY_ESTIMATED_REAL_RW_BY_GRAN_PROGRAM, campaignId));
        return query.getResultList();
    }

    @Override
    public List findEstimatedRealDsByGranProgram(Integer campaignId) {
        Query query = em.createQuery(String.format(QUERY_ESTIMATED_REAL_DS_BY_GRAN_PROGRAM, campaignId));
        return query.getResultList();
    }

    @Override
    public List findEstimatedRealFngByGranProgram(Integer campaignId) {
        Query query = em.createQuery(String.format(QUERY_ESTIMATED_REAL_FNG_BY_GRAN_PROGRAM, campaignId));
        return query.getResultList();
    }
}
