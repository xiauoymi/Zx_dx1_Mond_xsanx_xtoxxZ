package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Forecast;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by EPESTE on 04/12/2014.
 */
public interface ForecastRepository extends CrudRepository<Forecast, Integer> {

    Forecast findByCampaignId(Integer campaignId);

    @Modifying
    @Transactional
    @Query("update Lot l set l.estimatedRwDate = l.harvestDate + :daysRw where l.campaign.id = :campaign")
    void updateEstimatedRwDate(@Param(value = "daysRw") Double daysRw, @Param(value = "campaign") Integer campaign);
}
