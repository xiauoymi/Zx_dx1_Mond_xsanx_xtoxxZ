package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.HumidityRange;
import com.monsanto.prisma.core.domain.Zone;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by PGSETT on 26/06/2014.
 */
public interface HumidityRangeRepository extends CrudRepository<HumidityRange, Integer> {

    public static final String FILTER_HUMIDITY_RANGES = "select hr from HumidityRange hr where  hr.hybrid.name like %:hybridName%";
    public static final String FIND_BY_HYBRID_ZONE = "select hr from HumidityRange hr where  hr.hybrid.name = :hybridName and hr.zone.code = :zoneCode";

    List<HumidityRange> findAll();

    HumidityRange findById(Integer id);

    @Transactional(readOnly = true)
    @Query(FILTER_HUMIDITY_RANGES)
    List<HumidityRange> findByHybrid(@Param("hybridName") String hybridName);

    @Transactional(readOnly = true)
    @Query(FIND_BY_HYBRID_ZONE)
    HumidityRange findByHybridZone(@Param("hybridName") String hybridName, @Param("zoneCode") String zoneCode);

    List<HumidityRange> findByZone(Zone zone);
}
