package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.HumidityReport;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by EPESTE on 21/08/2014.
 */
public interface HumidityReportRepository extends CrudRepository<HumidityReport, Integer> {
}
