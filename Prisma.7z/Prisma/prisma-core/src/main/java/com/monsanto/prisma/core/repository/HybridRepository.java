package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Hybrid;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by EPESTE on 19/05/2014.
 */
public interface HybridRepository extends CrudRepository<Hybrid, Integer> {

    String FIND_BY_CAMPAIGN_ID = "SELECT distinct l.hybrid FROM Lot l " +
            " JOIN l.hybrid " +
            " WHERE l.campaign.id = :campaignId";

    Hybrid findById(Integer id);

    Hybrid findByName(String name);

    @Transactional(readOnly = true)
    @Query(FIND_BY_CAMPAIGN_ID)
    List<Hybrid> findByCampaignId(@Param("campaignId") Integer campaignId);
}
