package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Batch;
import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.domain.LotBatch;
import com.monsanto.prisma.core.domain.LotBatchId;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by BSBUON on 30/07/2014.
 */
@Repository
public interface LotBatchRepository extends CrudRepository<LotBatch, LotBatchId> {

    public static final String FIND_BY_LOT_ID = "Select lb from LotBatch lb " +
                                                        " join fetch lb.pk.batch batch " +
                                                        " where lb.pk.lot.id = :lotId";

    @Transactional(readOnly = true)
    @Query(FIND_BY_LOT_ID)
    public List<LotBatch> findByLotId(@Param("lotId") Integer lotId);

}
