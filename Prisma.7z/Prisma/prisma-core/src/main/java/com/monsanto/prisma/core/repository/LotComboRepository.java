package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.LotCombo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by BSBUON on 22/09/2014.
 */
public interface LotComboRepository extends JpaRepository<LotCombo, Integer> {

    @Transactional(readOnly = true)
    @Query("select l from LotCombo l ")
    public List<LotCombo> findAll();
}
