package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.LotDate;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by PGSETT on 28/10/2014.
 */
public interface LotDateImportRepository extends CrudRepository<LotDate, Integer> {
}
