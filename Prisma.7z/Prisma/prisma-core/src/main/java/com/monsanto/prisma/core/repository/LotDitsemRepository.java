package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.LotDitsem;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by EPESTE on 29/05/2014.
 */
public interface LotDitsemRepository extends CrudRepository<LotDitsem, Integer> {
}
