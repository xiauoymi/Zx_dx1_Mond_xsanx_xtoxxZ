package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.domain.LotFilter;
import com.monsanto.prisma.core.dto.FilterDTO;

import java.util.List;

/**
 * Created by epeste on 29/10/2014.
 */
public interface LotFilterRepository {

    List<LotFilter> findAll();

    List<Lot> findLots(Integer campaignId, List<FilterDTO> filters);
}
