package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.FilterDTO;
import com.monsanto.prisma.core.service.*;
import com.monsanto.prisma.core.utils.utilities.Constants;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by epeste on 10/11/2014.
 */
@Repository
public class LotFilterRepositoryImpl implements LotFilterRepository {

    @PersistenceContext
    private EntityManager entityManager;

    private static Logger log = Logger.getLogger(LotFilterRepositoryImpl.class);

    private LotFilter findById(Integer lotFilterId) {
        return entityManager.createQuery("from LotFilter lf where lf.id = " + lotFilterId, LotFilter.class).getSingleResult();
    }

    @Override
    public List<LotFilter> findAll() {
        return entityManager.createQuery("from LotFilter lf", LotFilter.class).getResultList();
    }

    @Override
    public List<Lot> findLots(Integer campaignId, List<FilterDTO> filters) {
        List<Lot> lots = new ArrayList<Lot>();
        String queryFilter = createFilterQuery(campaignId, filters);

        try {
            Query q = entityManager.createQuery(queryFilter);
            lots = q.getResultList();
        } catch (Exception e) {
            log.warn(e.getMessage());
            return lots;
        }
        return lots;
    }

    private String createFilterQuery(Integer campaignId, List<FilterDTO> filters) {
        String querySelect = "select distinct lot from Lot lot, Campaign c";
        String queryWhere = " where ";

        for (FilterDTO filterDTO : filters) {
            GenericFilter filter = createOptionByFilter(filterDTO.getTypeField());
            LotFilter lotFilter = findById(filterDTO.getId());

            querySelect = filter.createFromQuery(querySelect, lotFilter, filterDTO);
            queryWhere = filter.generateConditionQuery(queryWhere, lotFilter, filterDTO);
        }

        return querySelect + queryWhere + " lot.campaign = c.id and c.id = " + campaignId;
    }

    public GenericFilter createOptionByFilter(int optionType) {
        switch (optionType) {
            case Constants.FILTER_DATE: return new DateFilter();
            case Constants.FILTER_NUMBER: return new NumberFilter();
            case Constants.FILTER_ZONE: return new ZoneFilter();
            case Constants.FILTER_HARVESTED: return new HarvestedFilter();
            default: return new GenericFilter();
        }
    }
}
