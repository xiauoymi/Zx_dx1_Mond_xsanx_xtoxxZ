package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.LotHistory;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by EPESTE on 12/06/2014.
 */
public interface LotHistoryRepository extends CrudRepository<LotHistory, Integer> {

    public static final String BY_LOT_ID = "SELECT lh from LotHistory lh " +
                                            " JOIN FETCH lh.user " +
                                            " WHERE lh.lotId = :lotId " +
                                            " ORDER BY lh.dateTransaction DESC";

    @Transactional(readOnly = true)
    @Query(BY_LOT_ID)
    List<LotHistory> findByLotId(@Param("lotId") Integer lotId);
}
