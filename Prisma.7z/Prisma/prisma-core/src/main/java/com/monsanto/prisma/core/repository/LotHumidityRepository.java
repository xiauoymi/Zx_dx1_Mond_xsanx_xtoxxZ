package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Hybrid;
import com.monsanto.prisma.core.domain.LotHumidity;
import com.monsanto.prisma.core.domain.Zone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 24/06/2014.
 */
public interface LotHumidityRepository extends JpaRepository<LotHumidity, Integer> {

    public static final String FIND_BY_HYBRID_ZONE = " select lh from LotHumidity lh " +
            " join fetch lh.lot l " +
            " join fetch l.hybrid h " +
            " join fetch l.establishment e " +
            " join fetch e.zone z " +
            " where h = :hybrid and z = :zone ";

    public static final String FIND_BY_LOT_DATE_HUMIDITY = " select lh from LotHumidity lh " +
            " join fetch lh.lot l " +
            " where l.id = :lotId and lh.sampleDate = :sampleDate and lh.humidity = :humidity ";

    public static final String FIND_BY_LOTS_MAX_DATE = "select  lh from LotHumidity lh " +
            " join fetch lh.lot l " +
            " where lh.sampleDate in (select max(lh.sampleDate) from LotHumidity lh where  lh.lot.id = :lotId ) and l.id = :lotId and l.campaign.id = :campaignId";

    public static final String FIND_BY_LOT = "select  lh from LotHumidity lh " +
            " join fetch lh.lot l " +
            " where  l.id = :lotId order by lh.sampleDate";

    public static final String FIND_BY_LOT_HUMIDITY_Lot_DATE = "select lh from LotHumidity lh    " +
                                "   where lh.sampleDate = :sampleDate and lh.lot.id = :lotId ";


    @Transactional(readOnly = true)
    @Query(FIND_BY_HYBRID_ZONE)
    public List<LotHumidity> findByHybridZone(@Param("hybrid") Hybrid hybrid, @Param("zone") Zone zone);

    @Transactional(readOnly = true)
    @Query(FIND_BY_LOT_DATE_HUMIDITY)
    public List<LotHumidity> findByLotDateHumidity(@Param("lotId") Integer id, @Param("sampleDate") Date sampleDate, @Param("humidity") Float humidity);

    @Transactional(readOnly = true)
    @Query(FIND_BY_LOTS_MAX_DATE)
    public LotHumidity findByLotMaxDate(@Param("lotId") Integer id, @Param("campaignId") Integer campaignId);


    @Transactional(readOnly = true)
    @Query(FIND_BY_LOT)
    public List<LotHumidity> findByLot(@Param("lotId") Integer id);

    @Transactional(readOnly = true)
    @Query(FIND_BY_LOT_HUMIDITY_Lot_DATE)
    public LotHumidity  findByLotHumidityByLotAndDate(@Param("lotId") Integer id, @Param("sampleDate") Date sampleDate);


}
