package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.LotMasterdata;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by EPESTE on 04/06/2014.
 */
public interface LotMasterdataRepository extends JpaRepository<LotMasterdata, Integer>{
}
