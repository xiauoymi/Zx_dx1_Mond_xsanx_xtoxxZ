package com.monsanto.prisma.core.repository;


import com.monsanto.prisma.core.domain.Campaign;
import com.monsanto.prisma.core.domain.Hybrid;
import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.domain.PreviousLot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by PGSETT on 14/05/2014.
 */
@Repository
public interface LotRepository extends JpaRepository<Lot, Integer> {

    public static final String FIND_ACTIVE_LOTS_BY_CAMPAIGN_ID_PAGE = "SELECT l FROM Lot l " +
            "WHERE l.campaign.id = :id and l.state = true";


    public static final String FIND_ACTIVE_LOTS_BY_CAMPAIGN_ID = "SELECT l FROM Lot l " +
            "JOIN FETCH l.campaign c " +
            "JOIN FETCH c.season se  " +
            "JOIN FETCH se.country co  " +
            "JOIN FETCH se.crop crop1  " +
            "JOIN FETCH c.crop crop2  " +
            "WHERE l.campaign.id = :id and l.state = true";

    public static final String FIND_ONLY_ACTIVE_LOTS_BY_CAMPAIGN_ID = "SELECT l FROM Lot l " +
            "WHERE l.campaign.id = :campaignId " +
            "and l.hybrid.id = :hybridId " +
            "and l.state = true";

    public static final String FIND_LOTS_BY_CAMPAIGN_ID = "SELECT l FROM Lot l " +
            "JOIN FETCH l.campaign c " +
            "JOIN FETCH c.season se  " +
            "JOIN FETCH se.country co  " +
            "JOIN FETCH se.crop crop1  " +
            "JOIN FETCH c.crop crop2  " +
            "WHERE l.campaign.id = :id";

    public static final String FILTER_LOTS = "select l from Lot l, Campaign c where c.isActive = true and " +
            " c.id = l.campaign.id and l.state = true and c.id = :campaignId and l.lotCode like %:lotCode%";

    public static final String COUNT_LOT_BY_CODE_AND_DIFF_ID = "select count(l.id) from Lot l, Campaign c where c.isActive = true and " +
            " c.id = l.campaign.id and l.state = true and l.lotCode = :lotCode and l.id <> :lotId and c.id = (select c.id from Lot l, Campaign c where l.campaign.id = c.id and l.id = :lotId)";

    public static final String FIND_BY_ID = "select l from Lot l " +
            " join fetch l.campaign c " +
            " join fetch c.season s " +
            " join fetch s.country co " +
            " join fetch co.region r " +
            " left join fetch l.previousLot pl " +
            "where l.state = true and l.id = :lotId";

    public static final String FIND_BY_ID_WITH_BATCH = "select l from Lot l " +
            " left outer join fetch l.lotBatches lb " +
            "where l.state = true and l.id = :lotId";

    public static final String COUNT_CAMPAIGN_ACTIVE_LOTS = "select count(l.id) from Lot l where l.campaign.id = :id and l.state = true";

    public static final String FILTER_LOTS_MASTERDATA_RECALC = "select l from Lot l " +
            " JOIN FETCH l.campaign c " +
            " JOIN FETCH c.season se  " +
            " JOIN FETCH se.country co  " +
            " JOIN FETCH se.crop crop1  " +
            " JOIN FETCH c.crop crop2  " +
            " WHERE c = :campaign " +
            " and l.hybrid = :hybrid and l.state = true " +
            " and l.megazone = :megazone ";
//            " and l.targetRwToDs is null " +
//            " and l.targetDsToFng is null " +
//            " and l.targetKgBag is null " +
//            " and l.targetBagHa is null " +
//            " and l.flowHarvDays is null " +
//            " and l.plantFlowDays is null ";

    public static final String FILTER_LOTS_REPORT_1 = "select l from Lot l " +
            " JOIN FETCH l.campaign c " +
            " WHERE l.lotCode = :lotCode " +
            " and c = :campaign  ";

    public static final String FILTER_ACTIVE_LOT_BY_CAMPAIGN = "select l from Lot l " +
            " JOIN FETCH l.campaign c " +
            " WHERE l.lotCode = :lotCode " +
            " and c = :campaign  " +
            " and l.state = true  ";


    public static final String FIND_PREVIOUS_LOT_BY_LOT_ID = "select pl from PreviousLot pl " +
            " where pl.previousLotPK.actualLot = :lotId";


    public static final String FILTER_LOTS_BY_HYBRID_CAMPAIGN = "select l from Lot l " +
            " JOIN FETCH l.campaign c " +
            " JOIN FETCH l.hybrid h " +
            " WHERE c.id = :campaignId " +
            "   and h.name = :hybridName and l.state = true";

    public static final String FIND_TOTAL_LOTS_AND_HAS = "select count(l.id), sum(l.registeredHas),sum(l.harvestableHas) from Lot l  " +
            " WHERE  l.campaign.id = :campaignId  " +
            " and l.state = true ";


    @Transactional(readOnly = true)
    @Query(COUNT_CAMPAIGN_ACTIVE_LOTS)
    public Integer countCampaignActiveLots(@Param("id") Integer campaignId);

    @Transactional(readOnly = true)
    @Query(FIND_LOTS_BY_CAMPAIGN_ID)
    public List<Lot> findLotsByCampaignId(@Param("id") Integer campaignId);

    @Transactional(readOnly = true)
    @Query(FIND_ACTIVE_LOTS_BY_CAMPAIGN_ID)
    public List<Lot> findActiveLotsByCampaignId(@Param("id") Integer campaignId);

    @Transactional(readOnly = true)
    @Query(FIND_ONLY_ACTIVE_LOTS_BY_CAMPAIGN_ID)
    public List<Lot> findOnlyActiveLotsByHybridIdAndCampaignId(@Param("hybridId") Integer hybridId, @Param("campaignId") Integer campaignId);

    @Transactional(readOnly = true)
    public Lot findByLotCode(String lotCode);

    @Transactional(readOnly = true)
    public Lot findByLotCodeAndCampaign(String lotCode, Campaign campaign);

    @Transactional(readOnly = true)
    @Query(FILTER_LOTS)
    //public Page<Lot> findByStateAndLotCodeContaining(@Param("campaignId") Integer campaignId, @Param("lotCode") String lotCode, Pageable pageable);
    public List<Lot> findByStateAndLotCodeContaining(@Param("campaignId") Integer campaignId, @Param("lotCode") String lotCode);

    @Transactional(readOnly = true)
    @Query(FIND_BY_ID)
    public Lot findById(@Param("lotId") Integer id);

    @Transactional(readOnly = true)
    @Query(FILTER_LOTS_MASTERDATA_RECALC)
    List<Lot> findByHybridAndCampaignForMasterDataRecalculate(@Param("hybrid") Hybrid hybrid, @Param("campaign") Campaign campaign, @Param("megazone") String megazone);

    @Transactional(readOnly = true)
    @Query(COUNT_LOT_BY_CODE_AND_DIFF_ID)
    Integer countLotByCodeAndDiffLotId(@Param("lotCode") String lotCode, @Param("lotId") Integer id);

    @Transactional(readOnly = true)
    @Query(FILTER_LOTS_REPORT_1)
    Lot findByLotCodeForReport1(@Param("lotCode") String lotCode, @Param("campaign") Campaign campaign);

    @Transactional(readOnly = true)
    @Query(FIND_PREVIOUS_LOT_BY_LOT_ID)
    List<PreviousLot> findPreviousLotsByLotId(@Param("lotId") Integer id);

    @Transactional
    @Query(FILTER_ACTIVE_LOT_BY_CAMPAIGN)
    Lot filterActiveLotByLotCodeAndCampaign(@Param("lotCode") String lotCode, @Param("campaign") Campaign campaign);

    @Transactional(readOnly = true)
    @Query(FIND_BY_ID_WITH_BATCH)
    public Lot findByIdWithBatch(@Param("lotId") Integer id);


    @Transactional(readOnly = true)
    @Query(FILTER_LOTS_BY_HYBRID_CAMPAIGN)
    List<Lot> findByHybridAndCampaign(@Param("hybridName") String hybridName, @Param("campaignId") Integer campaignId);

    @Transactional(readOnly = true)
    @Query(FIND_TOTAL_LOTS_AND_HAS)
    public Object[] findTotalLotsAndHas(@Param("campaignId") Integer campaignId);
}
