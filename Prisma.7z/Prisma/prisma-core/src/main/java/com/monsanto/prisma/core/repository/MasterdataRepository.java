package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Campaign;
import com.monsanto.prisma.core.domain.HybridType;
import com.monsanto.prisma.core.domain.Masterdata;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by EPESTE on 19/06/2014.
 */
public interface MasterdataRepository extends JpaRepository<Masterdata, Integer> {

    public static final String FIND_BY_MANUFACTURE_CODE_AND_CAMPAIGN = "select m from Masterdata m " +
            "where m.manufactureCode = :manufactureCode " +
            " and m.megaZone = :megazone " +
            " and m.campaign.id = :campaignId order by m.id desc";

    public static final String FIND_BY_ALL_MANUFACTURE_CODE_AND_CAMPAIGN = "select m from Masterdata m " +
            "where (m.manufactureCode = :manufactureCode  or :manufactureCode is null)" +
            " and m.campaign.id = :campaignId order by m.id desc";


    List<Masterdata> findByHybridType(HybridType hybridType);

    @Transactional(readOnly = true)
    @Query(FIND_BY_MANUFACTURE_CODE_AND_CAMPAIGN)
    List<Masterdata> findByManufactureCodeAndCampaign(@Param("manufactureCode") String manufactureCode, @Param("megazone") String megazone, @Param("campaignId") Integer campaignId);

    @Transactional(readOnly = true)
    @Query(FIND_BY_ALL_MANUFACTURE_CODE_AND_CAMPAIGN)
    List<Masterdata> findByAllManufactureCodeAndCampaign(@Param("manufactureCode") String manufactureCode, @Param("campaignId") Integer campaignId);

    List<Masterdata> findByCampaign(Campaign campaign);

}
