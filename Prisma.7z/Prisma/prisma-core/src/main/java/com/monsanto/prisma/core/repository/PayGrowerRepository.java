package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.PayGrower;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by PGSETT on 31/07/2014.
 */
public interface PayGrowerRepository extends CrudRepository<PayGrower, Integer> {
}
