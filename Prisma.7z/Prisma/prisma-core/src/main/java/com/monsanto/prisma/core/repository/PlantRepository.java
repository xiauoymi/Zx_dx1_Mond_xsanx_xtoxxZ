package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Plant;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by BSBUON on 5/15/2014.
 */
@Repository
public interface PlantRepository extends CrudRepository<Plant, Integer> {

    public static final String PLANT_BY_ID_JOINED = "Select p " +
            " from Plant p " +
            " join fetch p.country c " +
            " join fetch c.region " +
            " where p.id like :plantId";

    @Transactional(readOnly = true)
    public Plant findByName(String name);

    @Transactional(readOnly = true)
    @Query(PLANT_BY_ID_JOINED)
    public Plant findById(@Param("plantId") Integer id);
}
