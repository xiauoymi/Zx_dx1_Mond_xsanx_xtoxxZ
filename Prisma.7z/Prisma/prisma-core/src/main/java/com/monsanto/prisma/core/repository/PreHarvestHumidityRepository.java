package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.PreHarvestHumidity;
import com.monsanto.prisma.core.exception.DataAccessException;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by PGSETT on 07/07/2014.
 */
public interface PreHarvestHumidityRepository extends CrudRepository<PreHarvestHumidity, Integer> {


    List<PreHarvestHumidity> findAll();

    PreHarvestHumidity findById(Integer id) throws DataAccessException;
}
