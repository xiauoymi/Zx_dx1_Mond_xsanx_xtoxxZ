package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.PrismaFunctionality;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by EPESTE on 22/09/2014.
 */
public interface PrismaFunctionalityRepository extends CrudRepository<PrismaFunctionality, Integer> {

    public static final String FIND_ALL_ORDER_BY_FUNCTIONALITY_ACTION = "Select p " +
            " from PrismaFunctionality p " +
            " order by p.functionality, p.action";

    @Query(FIND_ALL_ORDER_BY_FUNCTIONALITY_ACTION)
    List<PrismaFunctionality> findAllOrderByFunctionalityAction();
}
