package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.ProfilePrismaFunctionality;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by EPESTE on 22/09/2014.
 */
public interface ProfilePrismaFunctionalityRepository extends CrudRepository<ProfilePrismaFunctionality, Integer> {
}
