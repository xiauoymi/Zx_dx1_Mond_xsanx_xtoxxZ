package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Profile;
import com.monsanto.prisma.core.domain.ProfilePrismaFunctionality;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by EPESTE on 12/09/2014.
 */
public interface ProfileRepository extends CrudRepository<Profile, Integer> {

    public static final String FIND_PROFILE_WITH_FUNCTIONALITY_ACTION = "" +
            "Select p from Profile p " +
            " left join fetch p.prismaFunctionalityList ppf " +
            " where p.id = :profileId";


    @Query(FIND_PROFILE_WITH_FUNCTIONALITY_ACTION)
    Profile findProfileWithFunctionalityAction(@Param(value = "profileId") Integer profileId);

    List<Profile> findByEnabled(Boolean enabled);


}
