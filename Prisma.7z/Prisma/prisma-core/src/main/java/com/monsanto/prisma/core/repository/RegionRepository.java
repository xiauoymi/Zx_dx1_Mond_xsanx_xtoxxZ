package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Region;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by BSBUON on 5/15/2014.
 */
@Repository
public interface RegionRepository extends CrudRepository<Region, Integer> {

    @Transactional(readOnly = true)
    public Region findByName(String name);
}
