package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Report1;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by EPESTE on 23/07/2014.
 */
public interface Report1Repository extends CrudRepository<Report1, Integer> {
}
