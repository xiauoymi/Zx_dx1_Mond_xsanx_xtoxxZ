package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Report2;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by PGSETT on 28/07/2014.
 */
public interface Report2Repository extends CrudRepository<Report2, Integer> {
}
