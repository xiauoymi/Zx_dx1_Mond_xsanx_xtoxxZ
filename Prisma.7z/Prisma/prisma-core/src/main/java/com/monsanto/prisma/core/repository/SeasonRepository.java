package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Country;
import com.monsanto.prisma.core.domain.Crop;
import com.monsanto.prisma.core.domain.Season;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by BSBUON on 5/21/2014.
 */
@Repository
public interface SeasonRepository extends CrudRepository<Season, Integer> {

    public static final String FIND_BY_CROP_AND_COUNTRY = "select s " +
            "from Season s " +
            "join fetch s.crop " +
            "join fetch s.country " +
            "WHERE s.country = :country " +
            "and s.crop = :crop";


    @Transactional(readOnly = true)
    @Query(FIND_BY_CROP_AND_COUNTRY)
    public Season findByCropAndCountry(@Param("crop") Crop crop, @Param("country") Country country);
}
