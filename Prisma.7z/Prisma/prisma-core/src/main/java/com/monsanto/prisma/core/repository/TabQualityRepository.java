package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.QualityFile;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by EPESTE on 01/08/2014.
 */
public interface TabQualityRepository extends CrudRepository<QualityFile, Integer> {
}
