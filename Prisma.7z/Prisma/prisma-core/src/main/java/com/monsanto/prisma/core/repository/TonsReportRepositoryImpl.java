package com.monsanto.prisma.core.repository;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.dto.ReceiveTonsDTO;
import com.monsanto.prisma.core.dto.TonsToHostDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import org.springframework.stereotype.Repository;

import javax.annotation.Nullable;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 17/11/2014.
 */
@Repository
public class TonsReportRepositoryImpl implements TonsReportRepository {
    @PersistenceContext
    private EntityManager em;

    public EntityManager getEntityManager() {
        return em;
    }

    @Override
    public List<ReceiveTonsDTO> findReceiveTons(Integer campaignId, String field, String value, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strValue = value != null ? String.format(" and (%s = '%s')", field, value) : "";
        String campaignReceivingTons = String.format("select %s, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY'), sum(l.actualTnRwLot) " +
                        "            from Lot l," +
                        "            Campaign c" +
                        "            where l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.campaign = c.id" + strValue +
                        "            and c.id = %d" +
                        "            group by  %s, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY')" +
                        "            order by  %s, to_char(l.realHarvestDate, 'YYYY'), l.harvestWeek", field, dateFormat.format(harvestDateFrom),
                dateFormat.format(harvestDateTo), campaignId, field, field
        );

        Query q = getEntityManager().createQuery(campaignReceivingTons);

        Function<Object[], ReceiveTonsDTO> receiveTonsDTOFunction = new Function<Object[], ReceiveTonsDTO>() {
            @Nullable
            @Override
            public ReceiveTonsDTO apply(@Nullable Object[] object) {
                return new ReceiveTonsDTO(object, false);
            }
        };
        List<ReceiveTonsDTO> receiveTonsDTOs = Lists.transform(q.getResultList(), receiveTonsDTOFunction);

        return receiveTonsDTOs;
    }

    @Override
    public List<ReceiveTonsDTO> findWeeksReceivingTons(Integer campaignId, String field, String value, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strValue = value != null ? String.format(" and (%s = '%s')", field, value) : "";
        String campaignReceivingTonsWeeks = String.format("select distinct l.harvestWeek, to_char(l.realHarvestDate, 'YYYY') " +
                        "            from Lot l," +
                        "            Campaign c" +
                        "            where l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.campaign = c.id" + strValue +
                        "            and c.id = %d" +
                        "            order by to_char(l.realHarvestDate, 'YYYY') asc, l.harvestWeek", dateFormat.format(harvestDateFrom),
                dateFormat.format(harvestDateTo), campaignId
        );

        Query q = getEntityManager().createQuery(campaignReceivingTonsWeeks);
        List<ReceiveTonsDTO> receiveTonsDTOList = Lists.transform(q.getResultList(), new Function<Object[], ReceiveTonsDTO>() {
            @Nullable
            @Override
            public ReceiveTonsDTO apply(@Nullable Object[] objects) {
                return new ReceiveTonsDTO((Float) objects[0], Integer.valueOf((String) objects[1]));
            }
        });
        return receiveTonsDTOList;
    }

    @Override
    public List<ReceiveTonsDTO> findReceivingTonsByZone(Integer campaignId, Integer zoneId, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strZoneId = zoneId != null ? String.format(" and (z.id = %d)", zoneId) : "";
        String campaignReceivingTonsByZone = String.format("select z.code, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY'), sum(l.actualTnRwLot) " +
                "            from Lot l," +
                "            Establishment e," +
                "            Zone z," +
                "            Campaign c" +
                "            where l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY')" +
                "            and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY')" +
                "            and l.campaign = c.id" +
                "            and l.establishment = e.id" +
                "            and e.zone = z.id" +
                strZoneId +
                "            and c.id = %d" +
                "            group by  z.code, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY')" +
                "            order by z.code, to_char(l.realHarvestDate, 'YYYY'), l.harvestWeek", dateFormat.format(harvestDateFrom), dateFormat.format(harvestDateTo), campaignId);

        Query q = getEntityManager().createQuery(campaignReceivingTonsByZone);


        Function<Object[], ReceiveTonsDTO> receiveTonsDTOFunction = new Function<Object[], ReceiveTonsDTO>() {
            @Nullable
            @Override
            public ReceiveTonsDTO apply(@Nullable Object[] object) {
                return new ReceiveTonsDTO(object, true);
            }
        };

        List<ReceiveTonsDTO> receiveTonsDTOs = Lists.transform(q.getResultList(), receiveTonsDTOFunction);

        return receiveTonsDTOs;
    }

    @Override
    public List<ReceiveTonsDTO> findWeeksReceivingTonsByZone(Integer campaignId, Integer zoneId, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strZoneId = zoneId != null ? String.format(" and (z.id = %d)", zoneId) : "";
        String campaignReceivingTonsWeeksByZone = String.format("select distinct l.harvestWeek, to_char(l.realHarvestDate, 'YYYY') " +
                        "            from Lot l," +
                        "            Establishment e," +
                        "            Zone z," +
                        "            Campaign c" +
                        "            where l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.campaign = c.id" +
                        "            and l.establishment = e.id" +
                        "            and e.zone = z.id" + strZoneId +
                        "            and c.id = %d" +
                        "            order by to_char(l.realHarvestDate, 'YYYY') asc, l.harvestWeek", dateFormat.format(harvestDateFrom),
                dateFormat.format(harvestDateTo), campaignId
        );
        Query q = getEntityManager().createQuery(campaignReceivingTonsWeeksByZone);

        List<ReceiveTonsDTO> receiveTonsDTOList = Lists.transform(q.getResultList(), new Function<Object[], ReceiveTonsDTO>() {
            @Nullable
            @Override
            public ReceiveTonsDTO apply(@Nullable Object[] objects) {
                return new ReceiveTonsDTO((Float) objects[0], Integer.valueOf((String) objects[1]));
            }
        });

        return receiveTonsDTOList;
    }

    @Override
    public List<ReceiveTonsDTO> findReceivingTonsByHybrid(Integer campaignId, Integer hybridId, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strHybridId = hybridId != null ? String.format(" and (h.id = %d)", hybridId) : "";
        String campaignReceivingTonsByHybrid = String.format("select h.name, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY'), sum(l.actualTnRwLot) " +
                        "            from Lot l," +
                        "            Hybrid h," +
                        "            Campaign c" +
                        "            where l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.campaign = c.id" +
                        "            and l.hybrid = h.id" + strHybridId +
                        "            and c.id = %d" +
                        "            group by  h.name, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY')" +
                        "            order by  h.name, to_char(l.realHarvestDate, 'YYYY'), l.harvestWeek", dateFormat.format(harvestDateFrom),
                dateFormat.format(harvestDateTo), campaignId
        );


        Query q = getEntityManager().createQuery(campaignReceivingTonsByHybrid);


        Function<Object[], ReceiveTonsDTO> receiveTonsDTOFunction = new Function<Object[], ReceiveTonsDTO>() {
            @Nullable
            @Override
            public ReceiveTonsDTO apply(@Nullable Object[] object) {
                return new ReceiveTonsDTO(object, true);
            }
        };
        List<ReceiveTonsDTO> receiveTonsDTOs = Lists.transform(q.getResultList(), receiveTonsDTOFunction);

        return receiveTonsDTOs;
    }

    @Override
    public List<ReceiveTonsDTO> findWeeksReceivingTonsByHybrid(Integer campaignId, Integer hybridId, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strHybridId = hybridId != null ? String.format(" and (h.id = %d)", hybridId) : "";
        String campaignReceivingTonsWeeksByHybrid = String.format("select distinct l.harvestWeek, to_char(l.realHarvestDate, 'YYYY') " +
                "            from Lot l," +
                "            Hybrid h," +
                "            Campaign c" +
                "            where l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY')" +
                "            and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY')" +
                "            and l.campaign = c.id" +
                "            and l.hybrid = h.id" + strHybridId +
                "            and c.id = %d" +
                "            order by to_char(l.realHarvestDate, 'YYYY') asc, l.harvestWeek", dateFormat.format(harvestDateFrom), dateFormat.format(harvestDateTo), campaignId);

        Query q = getEntityManager().createQuery(campaignReceivingTonsWeeksByHybrid);

        List<ReceiveTonsDTO> receiveTonsDTOList = Lists.transform(q.getResultList(), new Function<Object[], ReceiveTonsDTO>() {
            @Nullable
            @Override
            public ReceiveTonsDTO apply(@Nullable Object[] objects) {
                return new ReceiveTonsDTO((Float) objects[0], Integer.valueOf((String) objects[1]));
            }
        });

        return receiveTonsDTOList;
    }

    @Override
    public List<TonsToHostDTO> filterTonsToHostReport(Integer campaignId, String field, String value, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strValue = value != null ? String.format(" and (%s = '%s')", field, value) : "";
        String filterTonsToHostReport = String.format("select  %s, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY'), " +
                        " sum(l.actualTnDsLot) from Lot l,  " +
                        "      Campaign c " +
                        " WHERE c.id = %d " +
                        strValue +
                        " and l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY') " +
                        " and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY') " +
                        " and l.campaign = c.id " +
                        " and l.state = true  " +
                        " group by %s,l.harvestWeek, to_char(l.realHarvestDate, 'YYYY')" +
                        " order by %s, to_char(l.realHarvestDate, 'YYYY'), l.harvestWeek", field,
                campaignId, dateFormat.format(harvestDateFrom),
                dateFormat.format(harvestDateTo), field, field
        );

        Query q = getEntityManager().createQuery(filterTonsToHostReport);

        List<TonsToHostDTO> tonsDTOs;
        tonsDTOs = Lists.transform(q.getResultList(), new Function<Object[], TonsToHostDTO>() {
            @Nullable
            @Override
            public TonsToHostDTO apply(@Nullable Object[] object) {
                return new TonsToHostDTO(object, false);
            }
        });

        return tonsDTOs;
    }

    @Override
    public List<TonsToHostDTO> filterWeekTonsToHostReport(Integer campaignId, String field, String value, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strValue = value != null ? String.format(" and (%s = '%s')", field, value) : "";
        String filterWeekTonsToHostReport = String.format("select  distinct l.harvestWeek, to_char(l.realHarvestDate, 'YYYY') " +
                        " from Lot l,  " +
                        "      Campaign c " +
                        " WHERE c.id = %d " + strValue +
                        " and l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY') " +
                        " and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY') " +
                        " and l.campaign = c.id " +
                        " and l.state = true  " +
                        " order by to_char(l.realHarvestDate, 'YYYY') asc, l.harvestWeek", campaignId, dateFormat.format(harvestDateFrom),
                dateFormat.format(harvestDateTo)
        );

        Query q = getEntityManager().createQuery(filterWeekTonsToHostReport);
        List<TonsToHostDTO> tonsToHostDTOs = Lists.transform(q.getResultList(), new Function<Object[], TonsToHostDTO>() {
            @Nullable
            @Override
            public TonsToHostDTO apply(@Nullable Object[] objects) {
                return new TonsToHostDTO((Float) objects[0], Integer.valueOf((String) objects[1]));
            }
        });
        return tonsToHostDTOs;
    }

    @Override
    public List<TonsToHostDTO> filterTonsToHostReportByZone(Integer campaignId, Integer zoneId, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strZoneId = zoneId != null ? String.format(" and (z.id = %d)", zoneId) : "";
        String campaignReceivingTonsByZone = String.format("select z.code, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY'), sum(l.actualTnDsLot) " +
                "            from Lot l," +
                "            Establishment e," +
                "            Zone z," +
                "            Campaign c" +
                "            where l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY')" +
                "            and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY')" +
                "            and l.campaign = c.id" +
                "            and l.establishment = e.id" +
                "            and e.zone = z.id" +
                strZoneId +
                "            and c.id = %d" +
                "            group by  z.code, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY')" +
                "            order by z.code, to_char(l.realHarvestDate, 'YYYY'), l.harvestWeek", dateFormat.format(harvestDateFrom), dateFormat.format(harvestDateTo), campaignId);

        Query q = getEntityManager().createQuery(campaignReceivingTonsByZone);

        List<TonsToHostDTO> tonsDTOs;
        tonsDTOs = Lists.transform(q.getResultList(), new Function<Object[], TonsToHostDTO>() {
            @Nullable
            @Override
            public TonsToHostDTO apply(@Nullable Object[] object) {
                return new TonsToHostDTO(object, true);
            }
        });

        return tonsDTOs;
    }

    @Override
    public List<TonsToHostDTO> filterWeekTonsToHostReportByZone(Integer campaignId, Integer zoneId, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strZoneId = zoneId != null ? String.format(" and (z.id = %d)", zoneId) : "";
        String campaignReceivingTonsWeeksByZone = String.format("select distinct l.harvestWeek, to_char(l.realHarvestDate, 'YYYY') " +
                        "            from Lot l," +
                        "            Establishment e," +
                        "            Zone z," +
                        "            Campaign c" +
                        "            where l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.campaign = c.id" +
                        "            and l.establishment = e.id" +
                        "            and e.zone = z.id" + strZoneId +
                        "            and c.id = %d" +
                        "            order by to_char(l.realHarvestDate, 'YYYY') asc, l.harvestWeek", dateFormat.format(harvestDateFrom),
                dateFormat.format(harvestDateTo), campaignId
        );
        Query q = getEntityManager().createQuery(campaignReceivingTonsWeeksByZone);
        List<TonsToHostDTO> tonsToHostDTOs = Lists.transform(q.getResultList(), new Function<Object[], TonsToHostDTO>() {
            @Nullable
            @Override
            public TonsToHostDTO apply(@Nullable Object[] objects) {
                return new TonsToHostDTO((Float) objects[0], Integer.valueOf((String) objects[1]));
            }
        });
        return tonsToHostDTOs;
    }

    @Override
    public List<TonsToHostDTO> filterTonsToHostReportByHybrid(Integer campaignId, Integer hybridId, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strHybridId = hybridId != null ? String.format(" and (h.id = %d)", hybridId) : "";
        String campaignReceivingTonsByHybrid = String.format("select h.name, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY'), sum(l.actualTnDsLot) " +
                        "            from Lot l," +
                        "            Hybrid h," +
                        "            Campaign c" +
                        "            where l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY')" +
                        "            and l.campaign = c.id" +
                        "            and l.hybrid = h.id" + strHybridId +
                        "            and c.id = %d" +
                        "            group by  h.name, l.harvestWeek, to_char(l.realHarvestDate, 'YYYY')" +
                        "            order by  h.name, to_char(l.realHarvestDate, 'YYYY'), l.harvestWeek", dateFormat.format(harvestDateFrom),
                dateFormat.format(harvestDateTo), campaignId
        );


        Query q = getEntityManager().createQuery(campaignReceivingTonsByHybrid);

        List<TonsToHostDTO> tonsDTOs;
        tonsDTOs = Lists.transform(q.getResultList(), new Function<Object[], TonsToHostDTO>() {
            @Nullable
            @Override
            public TonsToHostDTO apply(@Nullable Object[] object) {
                return new TonsToHostDTO(object, true);
            }
        });

        return tonsDTOs;
    }

    @Override
    public List<TonsToHostDTO> filterWeekTonsToHostReportByHybrid(Integer campaignId, Integer hybridId, Date harvestDateFrom, Date harvestDateTo) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_FORMAT);
        String strHybridId = hybridId != null ? String.format(" and (h.id = %d)", hybridId) : "";
        String campaignReceivingTonsWeeksByHybrid = String.format("select distinct l.harvestWeek, to_char(l.realHarvestDate, 'YYYY') " +
                "            from Lot l," +
                "            Hybrid h," +
                "            Campaign c" +
                "            where l.realHarvestDate >= to_date('%s', 'DD/MM/YYYY')" +
                "            and l.realHarvestDate <= to_date('%s', 'DD/MM/YYYY')" +
                "            and l.campaign = c.id" +
                "            and l.hybrid = h.id" + strHybridId +
                "            and c.id = %d" +
                "            order by to_char(l.realHarvestDate, 'YYYY') asc, l.harvestWeek", dateFormat.format(harvestDateFrom), dateFormat.format(harvestDateTo), campaignId);

        Query q = getEntityManager().createQuery(campaignReceivingTonsWeeksByHybrid);
        List<TonsToHostDTO> tonsToHostDTOs = Lists.transform(q.getResultList(), new Function<Object[], TonsToHostDTO>() {
            @Nullable
            @Override
            public TonsToHostDTO apply(@Nullable Object[] objects) {
                return new TonsToHostDTO((Float) objects[0], Integer.valueOf((String) objects[1]));
            }
        });
        return tonsToHostDTOs;
    }

}
