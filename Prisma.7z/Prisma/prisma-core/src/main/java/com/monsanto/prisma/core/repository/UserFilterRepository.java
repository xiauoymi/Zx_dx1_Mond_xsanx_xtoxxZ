package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.domain.UserFilter;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

/**
 * Created by epeste on 29/10/2014.
 */
public interface UserFilterRepository extends CrudRepository<UserFilter, Integer> {

    List<UserFilter> findByUser(User user);

    UserFilter findByUserAndId(User user, Integer id);
}
