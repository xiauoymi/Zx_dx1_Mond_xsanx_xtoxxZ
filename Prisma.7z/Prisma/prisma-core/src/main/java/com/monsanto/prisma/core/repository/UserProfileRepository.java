package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.UserProfile;
import com.monsanto.prisma.core.domain.UserProfilePk;
import org.springframework.data.repository.CrudRepository;

/**
 * Created by EPESTE on 15/09/2014.
 */
public interface UserProfileRepository extends CrudRepository<UserProfile, UserProfilePk> {
}
