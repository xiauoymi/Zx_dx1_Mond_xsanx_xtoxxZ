package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {

    public static final String FIND_BY_USER_NAME = "" +
            "select u from User u " +
            " join fetch u.regions " +
            " where u.userName like :userName";

    public static final String FIND_AUTHORITIES_BY_USER_NAME = "SELECT distinct (r.name) " +
            " FROM User u," +
            "      Profile r," +
            "      PrismaFunctionality pf," +
            "      UserProfile ur," +
            "      ProfilePrismaFunctionality rpf" +
            " WHERE " +
            "      pf.id = rpf.profilePrismaFunctionalityPk.prismaFunctionality AND" +
            "      r.id = ur.userProfilePk.profile and " +
            "      rpf.profilePrismaFunctionalityPk.profile = ur.userProfilePk.profile AND" +
            "      ur.userProfilePk.user = u.id AND" +
            "      u.userName = :username";

    @Transactional(readOnly = true)
    @Query(FIND_BY_USER_NAME)
    public User findByUserName(@Param(value = "userName") String userName);

    @Transactional(readOnly = true)
    @Query(FIND_AUTHORITIES_BY_USER_NAME)
    List<String> findAuthoritiesByUserName(@Param(value = "username") String username);

}
