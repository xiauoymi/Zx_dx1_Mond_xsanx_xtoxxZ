package com.monsanto.prisma.core.repository;

import com.monsanto.prisma.core.domain.Zone;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * ZoneRepository
 */
@Repository
public interface ZoneRepository extends CrudRepository<Zone, Integer> {

    String FIND_BY_CAMPAIGN_ID = "SELECT z.id,z.code FROM Zone z, Establishment e, Lot l, Campaign c " +
            " WHERE z.id = e.zone.id and e.id = l.establishment.id and c.id=l.campaign.id and c.id = :campaignId " +
            " group by z.id,z.code order by z.code";


    Zone findByCode(String code);

    @Transactional(readOnly = true)
    @Query(FIND_BY_CAMPAIGN_ID)
    List<Object[]> findByCampaign(@Param("campaignId") Integer campaignId);
}
