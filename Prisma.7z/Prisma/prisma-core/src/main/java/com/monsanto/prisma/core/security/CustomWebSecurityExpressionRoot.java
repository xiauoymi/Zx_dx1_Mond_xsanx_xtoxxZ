package com.monsanto.prisma.core.security;

import com.monsanto.prisma.core.domain.PrismaFunctionality;
import com.monsanto.prisma.core.domain.Profile;
import com.monsanto.prisma.core.domain.User;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.expression.WebSecurityExpressionRoot;

import java.util.List;

/**
 * Created by EPESTE on 06/10/2014.
 */
public class CustomWebSecurityExpressionRoot extends WebSecurityExpressionRoot {

    private static final String CONCAT_FUNCTIONALITY_ACTION = "-";


    public CustomWebSecurityExpressionRoot(Authentication a, FilterInvocation fi) {
        super(a, fi);
    }

    public boolean hasPermission(String functionality) {
        User user = ((UserDetailsImpl) getPrincipal()).getUser();

        for (Profile profile : user.getProfiles()) {
            for (PrismaFunctionality prismaFunctionality : profile.getPrismaFunctionalityList()) {
                if ((prismaFunctionality.getFunctionality() + CONCAT_FUNCTIONALITY_ACTION + prismaFunctionality.getAction()).matches(functionality)) {
                    return true;
                }
            }
        }

        return false;

    }


    public boolean hasPermission(List<String> functionalities) {
        User user = ((UserDetailsImpl) getPrincipal()).getUser();

        for (Profile profile : user.getProfiles()) {
            for (PrismaFunctionality prismaFunctionality : profile.getPrismaFunctionalityList()) {
                for (String functionality : functionalities) {
                    if ((prismaFunctionality.getFunctionality() + CONCAT_FUNCTIONALITY_ACTION + prismaFunctionality.getAction()).matches(functionality)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

}
