package com.monsanto.prisma.core.security;

import com.monsanto.prisma.core.domain.User;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;


/**
* Created with IntelliJ IDEA.
* User: BSBUON
* Date: 05/05/14
* Time: 12:28
* To change this template use File | Settings | File Templates.
*/
public class UserDetailsImpl implements UserDetails, UserWrapper {

    private User user;
    private Collection<? extends GrantedAuthority> authorities;

    public UserDetailsImpl(){
        super();
        this.user = null;
        this.authorities = new ArrayList<GrantedAuthority>();
    }

    public UserDetailsImpl(User user, Collection<? extends GrantedAuthority> authorities){
        super();
        this.user = user;
        this.authorities = authorities;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities;
    }

    @Override
    public String getPassword() {
        return null;  //TODO implements this
    }

    @Override
    public String getUsername() {
        return user.getUserName();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;  //TODO implements this
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;  //TODO implements this
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;  //TODO implements this
    }

    @Override
    public boolean isEnabled() {
        return user.getEnabled();
    }

    @Override
    public User getUser() {
        return user;
    }

}
