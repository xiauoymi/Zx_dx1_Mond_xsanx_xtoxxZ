package com.monsanto.prisma.core.security;

import com.monsanto.prisma.core.domain.User;

/**
 * Allow access to wrapped user
 */
public interface UserWrapper {
    User getUser();
}
