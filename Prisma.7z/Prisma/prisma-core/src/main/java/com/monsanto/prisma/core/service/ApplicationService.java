package com.monsanto.prisma.core.service;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.prisma.core.domain.ApplicationAccount;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Service;

/**
 * Created by BSBUON on 7/16/2014.
 */
@Service
public class ApplicationService {

    public static final String DEFAULT_EXTERNAL_STORAGE_PROPERTY = "MONCRYPTJV";
    public static final String STAGE_DOMAIN = "stage.domain.";
    public static final String STAGE_USER = "stage.user.";
    public static final String STAGE_PASSWORD = "stage.password.";
    public static final String FOLDER_NAME_SUFIX  = "appFolderName.";
    public static final String KEY_FILE_SUFIX = "keyFile.";
    public static final String ENCRYPTED_FILE_SUFIX = "encryptedFile.";
    public static final String ENVIROMENT_PARAMETER = "lsi.function";

    private static Logger log = Logger.getLogger(ApplicationAccount.class);

    @Autowired
    @Qualifier("appMessageSource")
    private ResourceBundleMessageSource appMessageResource;

    public ApplicationAccount getApplicationAccount() throws EncryptorException {
        String environment = getEnviromentParameter();

        log.info("Getting application properties for environment: " + environment);

        String domain = getEnvironmentSpecificProperty(STAGE_DOMAIN,environment);
        String name = getEnvironmentSpecificProperty(STAGE_USER,environment);
        String password = getDecryptedEnvironmentSpecificProperty(STAGE_PASSWORD, environment);


        log.info(STAGE_DOMAIN + environment + ": " + domain);
        log.info(STAGE_USER + environment + ": " + name);

        return new ApplicationAccount(domain, name, password);
    }

    public String getMessage(String key) {
        return appMessageResource.getMessage(key, null, LocaleContextHolder.getLocale());
    }

    public String getEnviromentParameter() {
        return System.getProperty(ENVIROMENT_PARAMETER);
    }


    public String getDecryptedEnvironmentSpecificProperty(String property, String defaultEnvironment) throws EncryptorException {

        String decrypted = null;
        String propertyToDecrypt = property;

        String appFolderName = getEnvironmentSpecificProperty(
                propertyToDecrypt+FOLDER_NAME_SUFIX, defaultEnvironment);

        String encryptedFile = getEnvironmentSpecificProperty(
                propertyToDecrypt+ ENCRYPTED_FILE_SUFIX, defaultEnvironment);

        String keyFile = getEnvironmentSpecificProperty(
                propertyToDecrypt+KEY_FILE_SUFIX, defaultEnvironment);

        try {
            decrypted = EncryptionUtils
                    .GetDecryptedStringFromExternalStorage(DEFAULT_EXTERNAL_STORAGE_PROPERTY,
                            appFolderName, encryptedFile, keyFile);

        } catch (EncryptorException e) {
            log.error("Could not decrypt string: "+property, e);
            throw e;
        }

        return decrypted;
    }

    private String getEnvironmentSpecificProperty(String property, String defaultEnvironment) {
        return getMessage(property + defaultEnvironment);
    }
}
