package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Area;

import java.util.List;

/**
 * Created by EPESTE on 19/05/2014.
 */
public interface AreaService {

    List<Area> findAll();
}
