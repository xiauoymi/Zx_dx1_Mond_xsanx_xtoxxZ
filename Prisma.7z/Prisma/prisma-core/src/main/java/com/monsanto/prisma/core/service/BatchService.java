package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.dto.BatchDTO;
import com.monsanto.prisma.core.dto.LotBatchDTO;
import com.monsanto.prisma.core.exception.BatchException;
import com.monsanto.prisma.core.exception.KgDsAssignedInvalidException;

import java.util.List;

/**
 * Created by BSBUON on 22/07/2014.
 */
public interface BatchService {

    List<BatchDTO> findByCampaignId(Integer campaignId);

    BatchDTO findById(Integer batchId);

    List<LotBatchDTO> findLotsAssociated(Integer batchId);

    BatchDTO save(BatchDTO batchDTO) throws BatchException;

    void delete(Integer id) throws BatchException;

    LotBatchDTO addLot(Integer lotId, Float kgDsLotAssigned, Float kgDS, Float kgFNG, Integer bagProduced) throws KgDsAssignedInvalidException;
}
