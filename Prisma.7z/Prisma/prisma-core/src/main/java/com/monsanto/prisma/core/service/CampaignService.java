package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Campaign;
import com.monsanto.prisma.core.domain.Region;
import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.dto.BulkDestinationReportDTO;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.StatusReportDTO;
import com.monsanto.prisma.core.exception.CampaignException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.exception.SeasonNotExistsException;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 08/05/14
 * Time: 14:21
 * To change this template use File | Settings | File Templates.
 */
public interface CampaignService {

    Campaign findById(Integer campaignId);

    CampaignDTO findByIdAndActiveLots(Integer campaignId);

    List<Campaign> findAll();

    Campaign save(CampaignDTO newCampaignDTO) throws CampaignException, SeasonNotExistsException;

    Campaign update(CampaignDTO campaignDTO) throws CampaignException, SeasonNotExistsException;

    Campaign delete(Integer id) throws CampaignException;

    List<Campaign> findByRegionsAndActived(List<Region> regions);

    List<Campaign> findByRegion(List<Region> regions);

    List<Campaign> findByIsActive();

    List<StatusReportDTO> filterToStatusReport(CampaignTonDTO campaignTonDTO, Integer campaignId) throws DataAccessException;

    List<BulkDestinationReportDTO> filterBulkDestinationReport(CampaignTonDTO campaignTonDTO, Integer campaignId);

    void changeState(Integer id);

    Campaign findCampaignActiveByUser(User user) throws DataAccessException;
}
