package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Country;

import java.util.List;

/**
 * Created by BSBUON on 5/19/2014.
 */
public interface CountryService {

    List<Country> findAll();

    Country findById(Integer countryId);

    List<Country> findByRegionId(Integer regionId);

}
