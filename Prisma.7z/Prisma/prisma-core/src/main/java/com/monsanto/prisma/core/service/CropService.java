package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Crop;

import java.util.List;

/**
 * Created by BSBUON on 5/15/2014.
 */
public interface CropService {

    Crop findByName(String name);

    List<Crop> findAll();

    Crop findById(Integer id);
}
