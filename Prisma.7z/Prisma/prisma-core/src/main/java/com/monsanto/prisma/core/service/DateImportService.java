package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.LotDate;
import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.exception.BusinessException;

/**
 * Created by PGSETT on 28/10/2014.
 */
public interface DateImportService {
    LotDate updateLotFromDateImport(Integer campaignId, User user) throws BusinessException;
}
