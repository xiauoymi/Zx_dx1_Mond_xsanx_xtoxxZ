package com.monsanto.prisma.core.service;


import com.monsanto.prisma.core.domain.LotDitsem;
import com.monsanto.prisma.core.exception.BusinessException;

/**
 * Created by PGSETT on 14/05/2014.
 */
public interface DitsemService {
    LotDitsem addLotFromDitsem(Integer campaignId) throws BusinessException;
}
