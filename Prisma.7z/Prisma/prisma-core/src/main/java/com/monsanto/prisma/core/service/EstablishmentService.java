package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Establishment;

import java.util.List;

/**
 * Created by EPESTE on 19/05/2014.
 */
public interface EstablishmentService {
    List<Establishment> findAll();
}
