package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.exception.BusinessException;
import jcifs.smb.SmbException;

import java.io.InputStream;
import java.net.MalformedURLException;

/**
 * Created by AFREI on 16/07/2014.
 */
public interface FileImportService {

    void copyProcessedFile(String filePath, String fileName) throws MalformedURLException, SmbException, BusinessException;

    InputStream processFile(String filePath, String fileName) throws BusinessException;

    void validatePath(String filePath) throws BusinessException;

}
