package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Filter;
import com.monsanto.prisma.core.domain.UserFilter;

import java.util.List;

/**
 * Created by EPESTE on 31/10/2014.
 */
public interface FilterService {
    void save(UserFilter userFilter);
}
