package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Forecast;
import com.monsanto.prisma.core.dto.ForecastDTO;
import com.monsanto.prisma.core.dto.ForecastReportDTO;
import com.monsanto.prisma.core.exception.BusinessException;

/**
 * Created by EPESTE on 04/12/2014.
 */
public interface ForecastService {
    Forecast findByCampaignId(Integer campaignId);

    Forecast save(Forecast forecast);

    Forecast update(ForecastDTO forecastDTO) throws BusinessException;

    ForecastReportDTO getReportInformation(Integer campaignId);
}
