package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.LotFilter;
import com.monsanto.prisma.core.dto.FilterDTO;

/**
 * Created by EPESTE on 06/01/2015.
 */
public class GenericFilter {

    public String createFromQuery(String query, LotFilter lotFilter, FilterDTO filterDTO) {
        if (lotFilter.getFromQuery() != null) {
            query = query.concat(", " + lotFilter.getFromQuery());
        }

        return query;
    }

    public String generateConditionQuery(String query, LotFilter lotFilter, FilterDTO filterDTO) {
        String valueLotField = filterDTO.appyTypeToValue();

        if (valueLotField.isEmpty()) {
            return query + lotFilter.getFilterQuery() + " IS NULL AND ";
        }

        return query + lotFilter.getFilterQuery() + " like '%" + filterDTO.appyTypeToValue().toUpperCase() + "%' AND ";
    }

}
