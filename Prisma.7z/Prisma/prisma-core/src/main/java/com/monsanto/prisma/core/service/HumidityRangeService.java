package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.HumidityRange;
import com.monsanto.prisma.core.domain.Zone;
import com.monsanto.prisma.core.exception.DataAccessException;

import java.util.List;

/**
 * Created by PGSETT on 26/06/2014.
 */
public interface HumidityRangeService {
    List<HumidityRange> findAll() throws DataAccessException;

    HumidityRange findById(Integer id) throws DataAccessException;

    List<HumidityRange> findByHybrid(String hybridName) throws DataAccessException;

    List<HumidityRange> findByZone(Zone zone) throws DataAccessException;

    void update(HumidityRange humidityRange) throws DataAccessException;

    void delete(Integer id) throws DataAccessException;

    HumidityRange findByHybridZone(String hybridName, String zoneCode) throws DataAccessException;
}
