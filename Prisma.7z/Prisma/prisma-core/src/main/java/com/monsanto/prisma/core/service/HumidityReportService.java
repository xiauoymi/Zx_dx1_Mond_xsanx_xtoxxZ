package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.HumidityReport;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.IOException;

/**
 * Created by EPESTE on 21/08/2014.
 */
public interface HumidityReportService {

    HumidityReport importFile(Integer campaignId) throws BusinessException, IOException, InvalidFormatException, DataAccessException;
}
