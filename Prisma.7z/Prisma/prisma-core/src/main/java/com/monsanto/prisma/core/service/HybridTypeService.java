package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.HybridType;

import java.util.List;

/**
 * Created by EPESTE on 19/05/2014.
 */
public interface HybridTypeService {
    List<HybridType> findAll();
}
