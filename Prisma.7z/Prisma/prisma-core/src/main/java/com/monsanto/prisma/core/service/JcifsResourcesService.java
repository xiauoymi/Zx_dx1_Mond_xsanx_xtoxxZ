package com.monsanto.prisma.core.service;

import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

/**
 * Created by AFREI on 17/07/2014.
 */
public interface JcifsResourcesService {

    NtlmPasswordAuthentication getNtlmPasswordAuthentication() throws EncryptorException;

    SmbFile getSbmFile(String url, NtlmPasswordAuthentication auth) throws MalformedURLException;

    InputStream getInputStream(SmbFile fileToGet) throws MalformedURLException, UnknownHostException, SmbException;
}
