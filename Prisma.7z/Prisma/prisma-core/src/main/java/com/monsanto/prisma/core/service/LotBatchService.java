package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.dto.LotBatchDTO;

import java.util.List;

/**
 * Created by BSBUON on 21/08/2014.
 */
public interface LotBatchService {
    List<LotBatchDTO> findByLotId(Integer lotId);
}
