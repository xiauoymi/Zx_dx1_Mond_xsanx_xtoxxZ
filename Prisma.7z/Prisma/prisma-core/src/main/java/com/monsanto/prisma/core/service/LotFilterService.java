package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.LotFilter;

import java.util.List;

/**
 * Created by epeste on 29/10/2014.
 */
public interface LotFilterService {
    List<LotFilter> findAll();
}
