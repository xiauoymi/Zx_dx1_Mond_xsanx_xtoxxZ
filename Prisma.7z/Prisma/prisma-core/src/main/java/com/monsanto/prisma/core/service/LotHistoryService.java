package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Lot;

/**
 * Created by EPESTE on 23/10/2014.
 */
public interface LotHistoryService {
    void save(Lot lot);
}
