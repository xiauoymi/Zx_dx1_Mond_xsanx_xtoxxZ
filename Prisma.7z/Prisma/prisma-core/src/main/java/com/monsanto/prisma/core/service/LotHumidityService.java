package com.monsanto.prisma.core.service;


import com.monsanto.prisma.core.domain.Hybrid;
import com.monsanto.prisma.core.domain.LotHumidity;
import com.monsanto.prisma.core.domain.Zone;
import com.monsanto.prisma.core.exception.DataAccessException;

import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 24/06/2014.
 */
public interface LotHumidityService {
    List<LotHumidity> findByHybridZone(Hybrid hybrid, Zone zone) throws DataAccessException;

    LotHumidity findByLotMaxDate(Integer id, Integer campaignId) throws DataAccessException;

    List<LotHumidity> findByLot(Integer id) throws DataAccessException;

    LotHumidity findByLotHumidityByLotAndDate(Integer id, Date sampleDate) throws DataAccessException;
}
