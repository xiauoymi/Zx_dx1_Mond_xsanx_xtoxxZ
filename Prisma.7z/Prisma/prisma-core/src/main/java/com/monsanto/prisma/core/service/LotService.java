package com.monsanto.prisma.core.service;


import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.FilterDTO;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.dto.PreviousLotDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * Created by PGSETT on 14/05/2014.
 */
public interface LotService {

    List<LotCombo> findAll() throws DataAccessException;

    List<Lot> findByFilter(Integer campaignId, List<FilterDTO> filters) throws DataAccessException;

    List<Lot> findActiveLotsForCurrentActiveCampaign() throws DataAccessException;

    void update(Lot lot) throws DataAccessException;

    Boolean isHarvested(String lotCode) throws DataAccessException;

    Lot deleteLogical(Integer lotId) throws DataAccessException;

    Lot findById(Integer id) throws DataAccessException;

    Lot recalculate(LotDTO lotDTO, Integer idTab, String operation, User user) throws BusinessException;

    Lot updatePrevLot(LotDTO lotDTO, User user) throws BusinessException;

    List<Lot> findLotsByCampaignId(Integer campaignId);

    List<Lot> findActiveLotsByCampaignId(Integer campaignId);

    List<LotHistory> getLotHistory(Integer lotId);

    Integer countLotByCodeAndDiffLotId(String lotCode, Integer lotId);

    List<PreviousLotDTO> findPreviousLotsByLotId(Integer id);

    List<Lot> findActiveAndHuskedLotsByHybridIdAndCampaignId(Integer hybridId, Integer campaignId);

    Lot filterActiveLotByLotCodeAndCampaign(String lotCode, Campaign campaign);

    TotalLotsDTO  findTotalLotsAndHas(Integer idCampaign);


}
