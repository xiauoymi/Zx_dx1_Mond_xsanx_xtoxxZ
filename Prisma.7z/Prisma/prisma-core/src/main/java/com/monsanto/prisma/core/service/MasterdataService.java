package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.HybridType;
import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.domain.LotMasterdata;
import com.monsanto.prisma.core.domain.Masterdata;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by EPESTE on 19/06/2014.
 */
public interface MasterdataService {

    ArrayList<LotMasterdata> refreshFromMasterdata(Integer campaignId) throws BusinessException, DataAccessException;

    List<Masterdata> findByHybridType(HybridType hybridType) throws DataAccessException;

    Lot processMasterdata(Lot lot) throws DataAccessException, BusinessException;

    Lot updateLotFromMasterdata(Lot lot) throws DataAccessException, BusinessException;


}
