package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Plant;

import java.util.List;

/**
 * Created by BSBUON on 5/15/2014.
 */
public interface PlantService {

    Plant findByName(String name);

    Plant findById(Integer id);

    List<Plant> findAll();
}
