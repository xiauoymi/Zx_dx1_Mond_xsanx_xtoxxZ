package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.PreHarvestHumidity;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;

import java.util.List;

/**
 * Created by PGSETT on 07/07/2014.
 */
public interface PreHarvestHumidityService {

    PreHarvestHumidity refreshFromPreHarvest(Integer campaignId) throws BusinessException;

    List<PreHarvestHumidity> findAll() throws DataAccessException;

    PreHarvestHumidity findById(Integer id) throws DataAccessException;

    void update(PreHarvestHumidity humidityRange) throws DataAccessException;

    void delete(Integer id) throws DataAccessException;

}
