package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.PrismaFunctionality;

import java.util.List;

/**
 * Created by EPESTE on 22/09/2014.
 */
public interface PrismaFunctionalityService {
    List<PrismaFunctionality> findAll();
}
