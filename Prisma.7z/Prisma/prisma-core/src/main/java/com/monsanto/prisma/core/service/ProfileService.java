package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Profile;
import com.monsanto.prisma.core.dto.ProfileDTO;

import java.util.List;

/**
 * Created by EPESTE on 12/09/2014.
 */
public interface ProfileService {
    List<Profile> findAll();

    Profile findById(Integer id);

    Profile update(ProfileDTO profileDTO);

    Profile add(ProfileDTO profileDTO);

    void delete(Integer profileId);

    List<Profile> findByEnabled(Boolean enabled);
}
