package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.QualityFile;
import com.monsanto.prisma.core.exception.BusinessException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.IOException;

/**
 * Created by EPESTE on 29/07/2014.
 */
public interface QualityService {
    QualityFile importFromFile(Integer campaignId) throws BusinessException, IOException, InvalidFormatException;
}
