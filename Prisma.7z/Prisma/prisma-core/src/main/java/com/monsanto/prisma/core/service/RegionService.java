package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Region;

import java.util.List;

/**
 * Created by BSBUON on 5/15/2014.
 */
public interface RegionService {

    Region findByName(String name);

    List<Region> findAll();
}
