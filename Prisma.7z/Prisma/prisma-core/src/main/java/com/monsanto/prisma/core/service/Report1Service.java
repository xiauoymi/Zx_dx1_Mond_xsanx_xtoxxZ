package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Report1;
import com.monsanto.prisma.core.exception.BusinessException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.IOException;
import java.text.ParseException;

/**
 * Created by EPESTE on 21/07/2014.
 */
public interface Report1Service {
    Report1 importFile(Integer campaignId) throws BusinessException, IOException, InvalidFormatException, ParseException;
}
