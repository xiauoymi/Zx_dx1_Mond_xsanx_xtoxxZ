package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Report2;
import com.monsanto.prisma.core.exception.BusinessException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.IOException;
import java.text.ParseException;

/**
 * Created by PGSETT on 28/07/2014.
 */
public interface Report2Service {
    Report2 importFile(Integer campaignId) throws BusinessException, IOException, InvalidFormatException, ParseException;
}
