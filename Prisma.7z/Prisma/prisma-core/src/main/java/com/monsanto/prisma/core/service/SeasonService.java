package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Country;
import com.monsanto.prisma.core.domain.Crop;
import com.monsanto.prisma.core.domain.Season;

/**
 * Created by BSBUON on 5/21/2014.
 */
public interface SeasonService {

    Season findByCropAndCountry(Crop crop, Country country);
}
