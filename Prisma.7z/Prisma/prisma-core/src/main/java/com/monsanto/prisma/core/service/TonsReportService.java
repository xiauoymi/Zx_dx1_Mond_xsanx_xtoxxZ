package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.dto.ReceiveTonsDTO;
import com.monsanto.prisma.core.dto.TonsToHostDTO;

import java.util.Date;
import java.util.List;

/**
 * Created by EPESTE on 25/09/2014.
 */
public interface TonsReportService {
    List<ReceiveTonsDTO> findReceiveTons(Integer campaignId, String field, String value, Date harvestDateFrom, Date harvestDateTo);

    List<ReceiveTonsDTO> findWeeksReceivingTons(Integer campaignId, String field,
                                                String value,
                                                Date harvestDateFrom,
                                                Date harvestDateTo);

    List<ReceiveTonsDTO> findReceivingTonsByZone(Integer campaignId,
                                                 Integer zoneId,
                                                 Date harvestDateFrom,
                                                 Date harvestDateTo);


    List<ReceiveTonsDTO> findWeeksReceivingTonsByZone(Integer campaignId, Integer zoneId,
                                                      Date harvestDateFrom,
                                                      Date harvestDateTo);


    List<ReceiveTonsDTO> findReceivingTonsByHybrid(Integer campaignId,
                                                   Integer hybridId,
                                                   Date harvestDateFrom,
                                                   Date harvestDateTo);


    List<ReceiveTonsDTO> findWeeksReceivingTonsByHybrid(Integer campaignId, Integer hybridId,
                                                        Date harvestDateFrom,
                                                        Date harvestDateTo);

    List<TonsToHostDTO> filterTonsToHostReport(Integer campaignId, String field,
                                               String value,
                                               Date harvestDateFrom,
                                               Date harvestDateTo);

    List<TonsToHostDTO> filterWeekTonsToHostReport(Integer campaignId, String field, String value,
                                                   Date harvestDateFrom, Date harvestDateTo);

    List<TonsToHostDTO> filterTonsToHostReportByZone(Integer campaignId, Integer zoneId,
                                                     Date harvestDateFrom,
                                                     Date harvestDateTo);

    List<TonsToHostDTO> filterWeekTonsToHostReportByZone(Integer campaignId, Integer zoneId,
                                                         Date harvestDateFrom,
                                                         Date harvestDateTo);


    List<TonsToHostDTO> filterTonsToHostReportByHybrid(Integer campaignId, Integer hybridId,
                                                       Date harvestDateFrom,
                                                       Date harvestDateTo);

    List<TonsToHostDTO> filterWeekTonsToHostReportByHybrid(Integer campaignId, Integer hybridId,
                                                           Date harvestDateFrom,
                                                           Date harvestDateTo);
}
