package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.domain.UserFilter;

import java.util.List;

/**
 * Created by epeste on 29/10/2014.
 */
public interface UserFilterService {
    UserFilter save(UserFilter userFilter);

    List<UserFilter> findAllByUser(User user);

    UserFilter findByUserAndId(User user, Integer id);

    UserFilter delete(Integer userFilterId);
}
