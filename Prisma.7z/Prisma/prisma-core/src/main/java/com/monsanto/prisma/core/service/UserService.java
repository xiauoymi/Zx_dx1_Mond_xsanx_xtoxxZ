package com.monsanto.prisma.core.service;

//import com.monsanto.prisma.core.domain.User;
//import org.springframework.web.multipart.MultipartFile;
//
//import java.io.IOException;

import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.dto.UserDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.UserNotFoundException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.List;

/**
 * User Services
 * User: BSBUON
 * Date: 23/04/14
 * Time: 16:02
 * To change this template use File | Settings | File Templates.
 */
public interface UserService {
    List<User> findAll();

    User update(UserDTO userDTO) throws BusinessException;

    User newUser(UserDTO userDTO) throws BusinessException;

    User delete(Integer id) throws UserNotFoundException;

    User findByUserName(String userName) throws UserNotFoundException;

    List<SimpleGrantedAuthority> findAuthoritiesByUserName(String username);
}
