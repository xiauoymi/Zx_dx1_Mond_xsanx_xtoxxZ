package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.LotFilter;
import com.monsanto.prisma.core.dto.FilterDTO;

import java.util.Arrays;
import java.util.List;

/**
 * Created by EPESTE on 06/01/2015.
 */
public class ZoneFilter extends GenericFilter {

    @Override
    public String generateConditionQuery(String query, LotFilter lotFilter, FilterDTO filterDTO) {
        String valueLotField = filterDTO.appyTypeToValue();

        if (valueLotField.isEmpty()) {
            return query + lotFilter.getFilterQuery() + " IS NULL AND ";
        }

        query += lotFilter.getFilterQuery() + " in (";
        List<String> stringList = Arrays.asList(filterDTO.appyTypeToValue().split(","));
        for (String value : stringList) {
            query += "'" + value + "', ";
        }
        return query.substring(0, query.length() - 2) + ") AND ";
    }
}
