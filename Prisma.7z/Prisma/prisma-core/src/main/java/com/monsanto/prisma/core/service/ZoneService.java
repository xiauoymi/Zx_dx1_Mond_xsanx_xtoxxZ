package com.monsanto.prisma.core.service;

import com.monsanto.prisma.core.domain.Zone;
import com.monsanto.prisma.core.dto.ZoneDTO;

import java.util.List;

/**
 * Created by EPESTE.
 */
public interface ZoneService {
    Zone findById(Integer zoneId);

    Zone findByCode(String code);

    List<Zone> findAll();

    List<ZoneDTO> findByCampaign(Integer campaignId);
}
