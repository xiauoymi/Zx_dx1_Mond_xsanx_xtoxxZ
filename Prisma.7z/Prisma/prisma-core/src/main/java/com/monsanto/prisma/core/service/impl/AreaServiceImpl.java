package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Area;
import com.monsanto.prisma.core.repository.AreaRepository;
import com.monsanto.prisma.core.service.AreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by EPESTE on 19/05/2014.
 */
@Service
public class AreaServiceImpl implements AreaService {

    @Autowired
    private AreaRepository areaRepository;

    @Override
    public List<Area> findAll() {
        return (List<Area>) areaRepository.findAll();
    }
}
