package com.monsanto.prisma.core.service.impl;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.BatchDTO;
import com.monsanto.prisma.core.dto.LotBatchDTO;
import com.monsanto.prisma.core.exception.BatchException;
import com.monsanto.prisma.core.exception.ExistsBatchWithNameException;
import com.monsanto.prisma.core.exception.KgDsAssignedInvalidException;
import com.monsanto.prisma.core.repository.*;
import com.monsanto.prisma.core.service.BatchService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Created by BSBUON on 21/07/2014.
 */
@Service
public class BatchServiceImpl implements BatchService {

    private static Logger log = Logger.getLogger(BatchServiceImpl.class);

    @Autowired
    @Qualifier("batchRepository")
    private BatchRepository batchRepository;

    @Autowired
    @Qualifier("hybridRepository")
    private HybridRepository hybridRepository;

    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;

    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;


    @Autowired
    @Qualifier("lotBatchRepository")
    private LotBatchRepository lotBatchRepository;

    @Override
    public List<BatchDTO> findByCampaignId(Integer campaignId) {
        return Lists.transform(batchRepository.findByCampaignId(campaignId), new Function<Batch, BatchDTO>() {
            @Nullable
            @Override
            public BatchDTO apply(@Nullable Batch batch) {
                return new BatchDTO(batch);
            }
        });
    }

    public BatchDTO findById(Integer id) {
        Batch batch = batchRepository.findByBatchId(id);
        return batch != null ? new BatchDTO(batch) : new BatchDTO();
    }

    @Override
    public List<LotBatchDTO> findLotsAssociated(Integer batchId) {
        return Lists.transform(batchRepository.findAssociatedLots(batchId), new Function<LotBatch, LotBatchDTO>() {
            @Nullable
            @Override
            public LotBatchDTO apply(@Nullable LotBatch lotBatch) {
                return new LotBatchDTO(lotBatch);
            }
        });
    }

    @Override
    public BatchDTO save(BatchDTO batchDTO) throws BatchException {
        //Generate Batch Entity with Lots Associated
        Batch batch = parse(batchDTO);
        //calculate Lots
        recalculateLotsWithBatch(batchDTO.getAssociatedLotIds(), batchDTO, batch);
        return new BatchDTO(batch, false);
    }

    private void recalculateLotsWithBatch(List<Integer> lotIds, BatchDTO batchDTO, Batch batch) {
        for (Integer lotId : lotIds) {
            Lot lot = lotRepository.findByIdWithBatch(lotId);
            log.debug("recalculate lot: " + lot.getLotCode());
            lot.calculate();
            if (lot.getFirstBatchId() == null) {
                lot.setRealFngInit(batchDTO.getRealFngInit());
                lot.setRealFngEnd(batchDTO.getRealFngEnd());
                lot.setFirstBatchId(batch.getId());
            } else {
                if (lot.getFirstBatchId() == batch.getId()) {
                    lot.setRealFngInit(batchDTO.getRealFngInit());
                    lot.setRealFngEnd(batchDTO.getRealFngEnd());
                }
            }

            log.debug("saving lot...");
            lotRepository.save(lot);
        }
    }

    private void recalculateLots(List<Integer> lotIds, Integer batchId) {
        for (Integer lotId : lotIds) {
            Lot lot = lotRepository.findByIdWithBatch(lotId);
            if (lot.getFirstBatchId() == batchId) {
                lot.setRealFngInit(null);
                lot.setRealFngEnd(null);
                lot.setFirstBatchId(null);
                if (lot.getLotBatches().size() > 0) {
                    LotBatch lotBatch = lot.getLotBatches().get(0);
                    lot.setFirstBatchId(lotBatch.getBatch().getId());
                    lot.setRealFngInit(lotBatch.getBatch().getRealFngInit());
                    lot.setRealFngEnd(lotBatch.getBatch().getRealFngEnd());
                }
            }
            log.debug("recalculate lot: " + lot.getLotCode());
            lot.calculate();
            log.debug("saving lot...");
            lotRepository.save(lot);
        }
    }

    @Override
    public void delete(Integer id) throws BatchException {
        try {
            log.debug("finding batch id: " + id);
            Batch batch = batchRepository.findByIdWithLots(id);
            //first get the associated lots to the batch before delete it
            log.debug("search associated lots...");
            List<Integer> lotIds = batch.getAssociatedLotIds();
            log.debug("associated lots: " + lotIds.toArray().toString());


            for (LotBatch lotBatch : batch.getLotBatches()) {
                log.debug("desassociated lot: " + lotBatch.getLot().getLotCode());
                lotBatchRepository.delete(lotBatch.getPk());
            }
            batch.getLotBatches().clear();
            //delete batch
            log.debug("deleted batch...");
            batchRepository.delete(id);
            //finally recalculate associatedLots to deleted Batch.
            log.debug("recalculate lots...");
            recalculateLots(lotIds, id);
        } catch (Exception e) {
            log.error(e);
            throw new BatchException(e);
        }

    }

    @Override
    public LotBatchDTO addLot(Integer lotId, Float kgDsLotAssigned, Float kgDS, Float kgFNG, Integer bagProduced) throws KgDsAssignedInvalidException {
        Lot lot = lotRepository.findById(lotId);
        LotBatch lotBatch = new LotBatch();
        lotBatch.setLot(lot);
        lotBatch.setKgDSLotAssigned(kgDsLotAssigned);

        lotBatch.calculateLots(kgDS, kgFNG, bagProduced);

        return new LotBatchDTO(lotBatch);
    }

    private Batch parse(BatchDTO batchDTO) throws ExistsBatchWithNameException {
        log.debug("parsing batch: " + batchDTO.getName());
        Batch batch = new Batch();
        if (batchDTO.getId() != null && batchDTO.getId() > 0) {
            batch = batchRepository.findByIdWithLots(batchDTO.getId());
        } else {
            Campaign campaign = campaignRepository.findById(batchDTO.getCampaignId());
            Batch aux = batchRepository.findByNameAndCampaign(batchDTO.getName(), campaign);
            if (aux != null) {
                throw new ExistsBatchWithNameException();
            }
        }
        batch.setId(batchDTO.getId());
        batch.setName(batchDTO.getName());
        batch.setKgDS(batchDTO.getKgDS());
        batch.setKgFNG(batchDTO.getKgFNG());
        batch.setBagProduced(batchDTO.getBagProduced());
        batch.setRealFngInit(batchDTO.getRealFngInit());
        batch.setRealFngEnd(batchDTO.getRealFngEnd());
        batch.setTotalKgCullTower(batchDTO.getTotalKgCullTower());
        if (batch.getHybrid() == null || !batch.getHybrid().getId().equals(batchDTO.getHybridId())) {
            Hybrid hybrid = hybridRepository.findById(batchDTO.getHybridId());
            batch.setHybrid(hybrid);
        }

        if (batch.getCampaign() == null || !batch.getCampaign().getId().equals(batchDTO.getCampaignId())) {
            Campaign campaign = campaignRepository.findById(batchDTO.getCampaignId());
            batch.setCampaign(campaign);
        }

        try {
            batchRepository.save(batch);
        } catch (DataIntegrityViolationException ex) {
            throw new ExistsBatchWithNameException();
        }
        log.debug("bach saved.");
        processLots(batchDTO, batch);

        return batch;
    }

    private void processLots(BatchDTO batchDTO, Batch batch) {
        log.debug("processing Lots...");
        for (LotBatchDTO lotBatchDTO : batchDTO.getLotBatches()) {
            LotBatch lotBatch = batch.containsLot(lotBatchDTO.getLot().getLotCode());
            if (lotBatch == null) {
                log.debug("add new lot to batch.");
                lotBatch = new LotBatch();
                Lot lot = lotRepository.findById(lotBatchDTO.getLot().getId());
                lotBatch.getPk().setLot(lot);
                lotBatch.getPk().setBatch(batch);
            }
            parseLotBatch(lotBatch, lotBatchDTO, batch);
        }
    }

    private void parseLotBatch(LotBatch lotBatch, LotBatchDTO dto, Batch batch) {
        log.debug("parse lotBatch...");
        if (dto.isDeleted() != null && dto.isDeleted()) {
            if (lotBatchRepository.exists(lotBatch.getPk())) {
                lotBatchRepository.delete(lotBatch);
                batch.getLotBatches().remove(lotBatch);
                log.debug("deleted lotBatch.");
            }
        } else {
            lotBatch.setKgDSLotAssigned(dto.getKgDSLotAssigned());
            lotBatch.setKgCullTower(dto.getKgCullTower());
            lotBatch.calculateLots(batch.getKgDS(), batch.getKgFNG(), batch.getBagProduced());

            lotBatchRepository.save(lotBatch);
            batch.getLotBatches().add(lotBatch);

            Float totalKgCullTower = lotBatch.getLot().getTotalKgCullTower() + dto.getKgCullTower();
            Lot lot = lotBatch.getLot();
            lot.setTotalKgCullTower(totalKgCullTower);
            if (lot.getFirstBatchId() == null) {
                lot.setFirstBatchId(batch.getId());
                lot.setRealFngInit(batch.getRealFngInit());
                lot.setRealFngEnd(batch.getRealFngEnd());
            }
            lotRepository.save(lot);

            log.debug("saved lotBatch.");
        }
    }
}
