package com.monsanto.prisma.core.service.impl;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.BulkDestinationReportDTO;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.StatusReportDTO;
import com.monsanto.prisma.core.exception.*;
import com.monsanto.prisma.core.repository.*;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.ForecastService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 */
@Service
public class CampaignServiceImpl implements CampaignService {

    private static Logger log = Logger.getLogger(CampaignServiceImpl.class);

    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;


    @Autowired
    @Qualifier("masterdataRepository")
    private MasterdataRepository masterdataRepository;


    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;

    @Autowired
    @Qualifier("cropRepository")
    private CropRepository cropRepository;

    @Autowired
    @Qualifier("countryRepository")
    private CountryRepository countryRepository;

    @Autowired
    @Qualifier("seasonRepository")
    private SeasonRepository seasonRepository;

    @Autowired
    private FileImportService fileImportService;

    @Autowired
    private ForecastService forecastService;

    @Override
    public Campaign findById(Integer campaignId) {
        return campaignRepository.findById(campaignId);
    }

    public CampaignDTO findByIdAndActiveLots(Integer campaignId) {
        Campaign campaign = campaignRepository.findById(campaignId);

        if (campaign == null) {
            return null;
        }

        Integer cant = lotRepository.countCampaignActiveLots(campaign.getId());
        //verify if the campaign contains associated lots.
        return new CampaignDTO(campaign, cant != null && cant > 0 ? true : false);
    }

    @Override
    public List<Campaign> findAll() {
        return campaignRepository.findAllCampaigns();
    }

    @Override
    public Campaign save(CampaignDTO newCampaignDTO) throws CampaignException {
        Campaign campaign = parseCampaign(new Campaign(), newCampaignDTO);
        validateSave(campaign);
        Campaign campaignSave = campaignRepository.save(campaign);
        campaign.setId(campaignSave.getId());

        Forecast forecast = new Forecast(campaignSave.getId());
        forecastService.save(forecast);

        return campaign;
    }

    @Override
    public Campaign update(CampaignDTO campaignDTO) throws CampaignException {
        Campaign campaign = campaignRepository.findById(campaignDTO.getId());
        campaign = parseCampaign(campaign, campaignDTO);
        validateUpdate(campaign);
        campaignRepository.save(campaign);

        return campaign;
    }

    @Override
    public Campaign delete(Integer id) throws CampaignException {
        validateDelete(id);
        Campaign campaign = campaignRepository.findById(id);
        campaign.setIsDeleted(Boolean.TRUE);
        campaignRepository.save(campaign);

        return campaign;
    }

    @Override
    public List<Campaign> findByIsActive() {
        return campaignRepository.findByIsActive(true);
    }

    @Override
    public List<StatusReportDTO> filterToStatusReport(CampaignTonDTO campaignTonDTO, Integer campaignId) throws DataAccessException {
        List<Object[]> statusReportList = campaignRepository.filterStatusReport(campaignTonDTO.getHybridId(), campaignTonDTO.getProgram(), campaignId);
        List<StatusReportDTO> statusReportDTOList = Lists.transform(statusReportList, new Function<Object[], StatusReportDTO>() {
            @Nullable
            @Override
            public StatusReportDTO apply(@Nullable Object[] object) {
                return new StatusReportDTO(object);
            }
        });
        if (campaignTonDTO.getHybridName().equals("")) {
            campaignTonDTO.setHybridName(null);
        }


        List<StatusReportDTO> tonsDTOList = new ArrayList<StatusReportDTO>();
        for (StatusReportDTO statusReportDTO : statusReportDTOList) {


            List<Masterdata> masterdataList = masterdataRepository.findByAllManufactureCodeAndCampaign(statusReportDTO.getHybridName(), campaignId);
            if (masterdataList != null && masterdataList.size() > 0) {
                Masterdata masterdata = masterdataList.get(0);
                statusReportDTO.setGranProgram(masterdata.getGranProgram());
                statusReportDTO.setGermoplasma(masterdata.getGermoplasma());
                statusReportDTO.setProgram(masterdata.getProgram());
                statusReportDTO.setUmProgram(masterdata.getTypeProgramUnit());
                Float umProgram = Utilities.convertStringToNumber(masterdata.getTypeProgramUnit());
                if (statusReportDTO.getActual() != null && statusReportDTO.getUmProgram() != null && umProgram > 0) {
                    statusReportDTO.setInitialProgram(statusReportDTO.getActual() / umProgram);
                }

                statusReportDTO.setEmbolse(masterdata.getBagging());
                statusReportDTO.setUnidadComercial(masterdata.getCommercialUnit());

                Float commercialUnit = Utilities.convertStringToNumber(statusReportDTO.getUnidadComercial());

                if (commercialUnit != null && statusReportDTO.getActual() != null && umProgram != null && commercialUnit > 0) {
                    statusReportDTO.setBolsasComerciales((statusReportDTO.getActual() * umProgram) / commercialUnit);
                }

                List<Object[]> statusReportWithBatch = campaignRepository.filterStatusReportWithBatch(statusReportDTO.getHybridName(), campaignId);
                if (statusReportWithBatch != null && statusReportWithBatch.size() > 0) {
                    Object[] item = statusReportWithBatch.get(0);
                    Object sumBagLotAssigned = item[0];
                    statusReportDTO.setBaggingStatus((Double) sumBagLotAssigned);

                    if (masterdata.getCommercialUnit().toUpperCase().trim().equals(Constants.JB)) {
                        Object kgFngLotAssigned = item[1];
                        statusReportDTO.setTnDs((Double) kgFngLotAssigned);
                    }
                }

            }

            tonsDTOList = calculatePercents(statusReportDTO, campaignId, tonsDTOList);
        }

        return tonsDTOList;
    }

    @Override
    public List<BulkDestinationReportDTO> filterBulkDestinationReport(CampaignTonDTO campaignTonDTO, Integer campaignId) {
        List<Object[]> bulkDestinationReport = campaignRepository.filterBulkDestinationReport(campaignTonDTO.getWarehouseUnit(), campaignTonDTO.getHybridId(), campaignId);
        List<BulkDestinationReportDTO> bulkDTOs;
        bulkDTOs = Lists.transform(bulkDestinationReport, new Function<Object[], BulkDestinationReportDTO>() {
            @Nullable
            @Override
            public BulkDestinationReportDTO apply(@Nullable Object[] object) {
                return new BulkDestinationReportDTO(object);
            }
        });
        return bulkDTOs;
    }

    @Override
    public void changeState(Integer id) {
        Campaign campaign = campaignRepository.findById(id);
        campaign.setIsActive(!campaign.getIsActive());
        campaignRepository.save(campaign);
    }

    @Override
    public Campaign findCampaignActiveByUser(User user) throws DataAccessException {
        List<Campaign> campaigns = (user == null ? campaignRepository.findByIsActive(true) :
                campaignRepository.findByRegionsAndActived(user.getRegions()));

        Campaign actived = null;
        if (campaigns.size() > 0) {
            actived = campaigns.get(0);
        }
        return actived;
    }

    private List<StatusReportDTO> calculatePercents(StatusReportDTO statusReportDTO, Integer campaignId, List<StatusReportDTO> tonsDTOList) {

        List<Lot> lots = lotRepository.findByHybridAndCampaign(statusReportDTO.getHybridName(), campaignId);
        if (lots != null && lots.size() > 0) {
            statusReportDTO.setPlantName(lots.get(0).getReceptionPlant());
        }

        List<Lot> lotsNotHarvested = FluentIterable.from(lots).filter(new Predicate<Lot>() {
            @Override
            public boolean apply(@Nullable Lot lot) {
                return !lot.isHarvested();
            }
        }).toList();
        List<Lot> lotsPlant = FluentIterable.from(lots).filter(new Predicate<Lot>() {
            @Override
            public boolean apply(@Nullable Lot lot) {
                return lot.isPlant();
            }
        }).toList();
        List<Lot> lotsBagging = FluentIterable.from(lots).filter(new Predicate<Lot>() {
            @Override
            public boolean apply(@Nullable Lot lot) {
                return lot.isBagging();
            }
        }).toList();


        if (lots != null && lotsNotHarvested != null && lots.size() > 0) {
            statusReportDTO.setField(new Double(lotsNotHarvested.size()) / new Double(lots.size()) * Constants.ONE_HUNDRED);
        } else {
            statusReportDTO.setField(0D);
        }

        if (lots != null && lotsPlant != null && lots.size() > 0) {
            statusReportDTO.setPlant(new Double(lotsPlant.size()) / new Double(lots.size()) * Constants.ONE_HUNDRED);
        } else {
            statusReportDTO.setPlant(0D);
        }
        if (lots != null && lotsBagging != null && lots.size() > 0) {
            statusReportDTO.setBagging(new Double(lotsBagging.size()) / new Double(lots.size()) * Constants.ONE_HUNDRED);
        } else {
            statusReportDTO.setBagging(0D);
        }
        tonsDTOList.add(statusReportDTO);
        return tonsDTOList;
    }


    @Override
    public List<Campaign> findByRegionsAndActived(List<Region> regions) {
        if (regions.size() > 0) {
            return campaignRepository.findByRegionsAndActived(regions);
        } else {
            return new ArrayList<Campaign>();
        }
    }

    @Override
    public List<Campaign> findByRegion(List<Region> regions) {
        if (regions.size() > 0) {
            return campaignRepository.findByRegion(regions);
        } else {
            return new ArrayList<Campaign>();
        }
    }

    /**
     * Validate if the campaigns contains associated lots.
     *
     * @param campaignId
     * @throws CampaignException
     */
    private void validateDelete(Integer campaignId) throws CampaignException {
        Integer lotCount = lotRepository.countCampaignActiveLots(campaignId);
        if (lotCount != null && lotCount.intValue() > 0) {
            throw new ExistsLotsForThisCampaignException();
        }
    }

    /**
     * Validations for Save:
     * - the max campaigns actives by Season is not exceeded.
     * - campaign path exists and application account has access to it
     *
     * @param campaign
     * @throws CampaignException
     */
    private void validateSave(Campaign campaign) throws CampaignException {
        if (campaign.getIsActive()) {
            Integer maxCampaigns = campaign.getSeason().getMaxCampaigns();
            List<Campaign> campaigns = campaignRepository.findBySeasonAndByIsActive(campaign.getSeason(), Boolean.TRUE);

            if (campaigns.size() >= maxCampaigns && !campaigns.contains(campaign)) {
                throw new MaxCampaignsForSeasonException(" actual: " + campaigns.size() + " max: " + maxCampaigns);
            }
        }

        try {
            fileImportService.validatePath(campaign.getFilePath());
        } catch (BusinessException e) {
            log.error(e.getMessage(), e);
            throw new InvalidCampaignPathException(e.getMessage(), e);
        }
    }

    /**
     * Validations for Update:
     * - the max campaigns actives by Season is not exceeded.
     * - the campaign can't be changed if it's inactived.
     *
     * @param toChange
     * @throws CampaignException
     */
    private void validateUpdate(Campaign toChange) throws CampaignException {
        Campaign persisted = campaignRepository.findById(toChange.getId());
        if (!persisted.getIsActive() && !toChange.getIsActive()) {
            throw new InactiveToUpdateCampaignException();
        } else {
            Integer lotCount = lotRepository.countCampaignActiveLots(toChange.getId());
            if (lotCount > 0) {
                persisted.validateUpdate(toChange);
            }
        }
        validateSave(toChange);
    }

    /**
     * @param campaign
     * @param campaignDTO
     * @return
     * @throws Exception
     */
    private Campaign parseCampaign(Campaign campaign, CampaignDTO campaignDTO) throws SeasonNotExistsException, CampaignNameDuplicatedException {
        Campaign campaignAux = campaignRepository.findByName(campaignDTO.getName());
        if (campaignAux != null &&
                (campaign.getId() == null || !(campaign.equals(campaignAux)))) {
            throw new CampaignNameDuplicatedException();
        }
        campaign.setName(campaignDTO.getName());
        campaign.setCode(campaignDTO.getCampaignCode());
        campaign.setIsActive(campaignDTO.getIsActive());
        campaign.setIsReal(campaignDTO.getIsReal());
        campaign.setFilePath(campaignDTO.getFilePath());
        campaign.setObservations(campaignDTO.getObservations());

        Crop crop = cropRepository.findOne(campaignDTO.getCropId());
        campaign.setCrop(crop);

        Country country = countryRepository.findOne(campaignDTO.getCountryId());

        Season season = seasonRepository.findByCropAndCountry(crop, country);
        if (season == null) {
            throw new SeasonNotExistsException();
        }
        campaign.setSeason(season);

        return campaign;
    }
}
