package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Country;
import com.monsanto.prisma.core.repository.CountryRepository;
import com.monsanto.prisma.core.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by BSBUON on 5/19/2014.
 */
@Service
public class CountryServiceImpl implements CountryService{

    @Autowired
    private CountryRepository countryRepository;

    @Override
    public List<Country> findAll() {
        return (List<Country>) countryRepository.findAll();
    }

    @Override
    public Country findById(Integer countryId) {
        return countryRepository.findOne(countryId);
    }

    @Override
    public List<Country> findByRegionId(Integer regionId) {
        return countryRepository.findByRegionId(regionId);
    }
}
