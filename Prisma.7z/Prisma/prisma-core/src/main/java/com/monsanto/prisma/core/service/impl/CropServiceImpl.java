package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Crop;
import com.monsanto.prisma.core.repository.CropRepository;
import com.monsanto.prisma.core.service.CropService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by BSBUON on 5/15/2014.
 */
@Service
public class CropServiceImpl implements CropService {

    @Autowired
    @Qualifier("cropRepository")
    private CropRepository cropRepository;

    @Override
    public Crop findByName(String name) {
        return cropRepository.findByName(name);
    }

    @Override
    public List<Crop> findAll() {
        return (List<Crop>) cropRepository.findAll();
    }

    @Override
    public Crop findById(Integer id) {
        return cropRepository.findOne(id);
    }
}
