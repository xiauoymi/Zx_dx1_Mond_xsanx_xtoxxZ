package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.CellOmittedDTO;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.dto.RowImportDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.ParserRowException;
import com.monsanto.prisma.core.repository.*;
import com.monsanto.prisma.core.service.DateImportService;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.ForecastService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.joda.time.DateTime;
import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 28/10/2014.
 */
@Service
@Transactional
public class DateImportServiceImpl implements DateImportService {

    private static Logger log = Logger.getLogger(DitsemServiceImpl.class);

    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;
    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;
    @Autowired
    private HybridRepository hybridRepository;
    @Autowired
    private LotHistoryRepository lotHistoryRepository;
    @Autowired
    private FileImportService fileImportService;
    @Autowired
    private LotDateImportRepository lotDateImportRepository;

    @Autowired
    private ForecastService forecastService;

    private String messageCampaignNotExits = "prisma.campaign.notExists";
    private String messageImportErrorCell = "prisma.import.errorCell";
    private String messageImportUnexpectedError = "prisma.import.unexpectedError";
    private String messageHybridNotExits = "prisma.hybrid.notExists";
    private String messageLotNotExists = "prisma.lot.notExists";

    private static final String UNEXPECTED_ERROR = "Unexpected error:";

    @Override
    public LotDate updateLotFromDateImport(Integer campaignId, User user) throws BusinessException {
        Campaign campaign = campaignRepository.findById(campaignId);
        if (campaign == null) {
            throw new BusinessException(messageCampaignNotExits);
        }
        String fileName = "FECHAS.xlsx";
        InputStream inputStream = fileImportService.processFile(campaign.getFilePath(), fileName);
        return processDateImport(campaign, inputStream, fileName, user);
    }

    private LotDate processDateImport(Campaign campaign, InputStream inputStream, String fileName, User user) throws BusinessException {
        LotDate lotDate = new LotDate(campaign, fileName);
        try {
            Workbook wb = WorkbookFactory.create(inputStream);
            Sheet sheet = wb.getSheetAt(Constants.INT_ZERO);
            for (int i = Constants.ONE; i <= sheet.getLastRowNum(); i++) {
                Row rowDate = (Row) sheet.getRow(i);
                if (rowDate != null) {
                    String fieldCode = Utilities.getStringValue(rowDate, Constants.INT_ZERO, Whitelist.basic());
                    if (fieldCode != null) {
                        fieldCode = Jsoup.clean(fieldCode, Whitelist.basic());

                        Lot lot = lotRepository.filterActiveLotByLotCodeAndCampaign(fieldCode, campaign);
                        if (lot != null) {
                            try {
                                RowImportDTO<Lot> rowDto = processRowDate(fieldCode, rowDate, lot);
                                lot = rowDto.getData();
                                updateLot(campaign, lot, lotDate, rowDto, user);
                                createLotDTOFromLotWithoutHybrid(rowDate, lot, lotDate);
                            } catch (ParserRowException e) {
                                createLotDTOFromParserRowError(e, rowDate, fieldCode, lotDate);
                            } catch (Exception e) {
                                log.debug("Error to procces row date import. ", e);
                                createLotDTOFromException(rowDate, fieldCode, lotDate);
                            }
                        } else {
                            setLotDateWhenNotExistLot(lotDate, rowDate, fieldCode);
                        }
                    }
                }
            }
            lotDateImportRepository.save(lotDate);
            fileImportService.copyProcessedFile(campaign.getFilePath(), fileName);
        } catch (InvalidFormatException e) {
            throw new BusinessException(UNEXPECTED_ERROR + InvalidFormatException.class.getName(), e);
        } catch (IOException e) {
            throw new BusinessException(UNEXPECTED_ERROR + IOException.class.getName(), e);
        }
        return lotDate;
    }

    private void setLotDateWhenNotExistLot(LotDate lotDate, Row rowDate, String fieldCode) {
        Lot lotNotExist = new Lot();
        lotNotExist.setLotCode(fieldCode);
        String hybridName = Utilities.getStringValue(rowDate, Constants.ONE, Whitelist.basic());
        LotDTO lotDTO = new LotDTO(lotNotExist, messageLotNotExists);
        lotDTO.setHybridName(hybridName);
        lotDate.addLotDTO(lotDTO);
        lotDate.addOmitted();
    }

    private RowImportDTO<Lot> processRowDate(String fieldCode, Row rowDate, Lot lot) throws ParserRowException {
        List<CellOmittedDTO> omittedCells = new ArrayList<CellOmittedDTO>();
        lot.setLotCode(fieldCode);
        String hybridName = Utilities.getStringValue(rowDate, Constants.ONE, Whitelist.basic());

        if (hybridName == null) {
            throw new ParserRowException(rowDate, Constants.ONE);
        }

        Hybrid hybrid = hybridRepository.findByName(Utilities.getStringValue(rowDate, Constants.ONE, Whitelist.basic(), omittedCells));
        lot.setHybrid(hybrid);

        lot = calculateDates(rowDate, lot, omittedCells);

        RowImportDTO<Lot> rowImportDTO = new RowImportDTO<Lot>();
        rowImportDTO.setData(lot);
        rowImportDTO.setOmittedCells(omittedCells);
        return rowImportDTO;
    }

    private Lot calculateDates(Row rowDate, Lot lot, List<CellOmittedDTO> omittedCells) {
        Date estimatedPlantingDate = Utilities.getDateValue(rowDate, Constants.TWO, omittedCells);
        Date realPlantingDate = Utilities.getDateValue(rowDate, Constants.THREE, omittedCells);
        Date estimatedFloweringDate = Utilities.getDateValue(rowDate, Constants.FOUR, omittedCells);
        Date realFloweringDate = Utilities.getDateValue(rowDate, Constants.FIVE, omittedCells);
        Date estimatedHarvestDate = Utilities.getDateValue(rowDate, Constants.SIX, omittedCells);
        Date realHarvestDate = Utilities.getDateValue(rowDate, Constants.SEVEN, omittedCells);

        updatePlantingDate(lot, estimatedPlantingDate, realPlantingDate);
        updateFloweringDate(lot, estimatedFloweringDate, realFloweringDate);
        updateHarvestDate(lot, estimatedHarvestDate, realHarvestDate);

        return lot;
    }

    private void updatePlantingDate(Lot lot, Date estimatedPlantingDate, Date realPlantingDate) {
        lot.setEstimatedPlantingDate(estimatedPlantingDate);
        lot.setRealPlantingDate(realPlantingDate);
        lot.setPlantingDate(lot.getRealPlantingDate() == null ? lot.getEstimatedPlantingDate() : lot.getRealPlantingDate());
    }

    private void updateFloweringDate(Lot lot, Date estimatedFloweringDate, Date realFloweringDate) {
        lot.setEstimatedFloweringDate(estimatedFloweringDate);
        lot.setRealFloweringDate(realFloweringDate);
        lot.setFloweringDate(lot.getRealFloweringDate() == null ? lot.getEstimatedFloweringDate() : lot.getRealFloweringDate());
    }

    private void updateHarvestDate(Lot lot, Date estimatedHarvestDate, Date realHarvestDate) {
        lot.setEstimatedHarvestDate(estimatedHarvestDate);
        lot.setRealHarvestDate(realHarvestDate);
        lot.setHarvestDate(lot.getRealHarvestDate() == null ? lot.getEstimatedHarvestDate() : lot.getRealHarvestDate());
        DateTime dateTime = new DateTime(lot.getHarvestDate());
        lot.setHarvestWeek(new Float(dateTime.getWeekOfWeekyear()));

        if (lot.getHarvestDate() != null) {
            Forecast forecast = forecastService.findByCampaignId(lot.getCampaign().getId());
            dateTime = new DateTime(lot.getHarvestDate());
            Date estimatedRwDate = dateTime.plusDays(forecast.getDaysRw()).toDate();
            lot.setEstimatedRwDate(estimatedRwDate);
            DateTime estimatedRwDateTime = new DateTime(estimatedRwDate);
            lot.setEstimatedDsDate(estimatedRwDateTime.plusDays(forecast.getDaysDs()).toDate());
            DateTime estimatedDsDate = null;
            if (lot.getRealRwReceiptDate() != null) {
                estimatedDsDate = new DateTime(lot.getRealRwReceiptDate());
            } else {
                estimatedDsDate = new DateTime(estimatedRwDateTime);
            }
            lot.setEstimatedDsDate(estimatedDsDate.plusDays(forecast.getDaysDs()).toDate());
        }

    }

    private void updateLot(Campaign campaign, Lot lot, LotDate lotDate, RowImportDTO<Lot> rowDto, User user) throws ParserRowException {
        if (lot.getHybrid() != null) {
            lot.setSourceLotFile(campaign.getFilePath());
            lot.setCampaign(campaign);

            lot = lotRepository.save(lot);
            LotHistory lotHistory = new LotHistory(lot, Constants.LOT_HISTORY_UPDATE, user);
            lotHistoryRepository.save(lotHistory);

            lotDate.addImported();
            if (!rowDto.getOmittedCells().isEmpty()) {
                lotDate.addLotWithOmission(new LotDTO(rowDto));
            }
        }
    }

    private void createLotDTOFromLotWithoutHybrid(Row rowDate, Lot lot, LotDate lotDate) throws ParserRowException {
        if (lot.getHybrid() == null) {
            String hybrid = Utilities.getStringValue(rowDate, Constants.ONE, Whitelist.basic());
            if (hybrid == null) {
                throw new ParserRowException(rowDate, Constants.ONE);
            }
            LotDTO lotDTO = new LotDTO(lot, messageHybridNotExits);
            lotDTO.setHybridName(Jsoup.clean(hybrid, Whitelist.basic()));
            lotDate.addLotDTO(lotDTO);
            lotDate.addOmitted();
        }
    }

    private void createLotDTOFromException(Row rowDate, String fieldCode, LotDate lotDate) {
        LotDTO lotDTO = new LotDTO(fieldCode, messageImportUnexpectedError);
        lotDTO.setHybridName(Utilities.getStringValue(rowDate, Constants.ONE, Whitelist.basic()));
        lotDate.addLotDTO(lotDTO);
        lotDate.addOmitted();
    }

    private void createLotDTOFromParserRowError(ParserRowException parerRowException, Row rowDate, String fieldCode, LotDate lotDate) {
        String colString = CellReference.convertNumToColString(parerRowException.getIndex());
        int rowNum = parerRowException.getRow().getRowNum() + 1;
        String cell = colString + rowNum;
        log.debug("Error to procces row date import at cell " + cell + ": " + parerRowException.getMessage(), parerRowException);
        LotDTO lotDTO = new LotDTO(fieldCode, messageImportErrorCell);
        lotDTO.setHybridName(Utilities.getStringValue(rowDate, Constants.ONE, Whitelist.basic()));
        lotDTO.setErrorDetail(cell);
        lotDate.addLotDTO(lotDTO);
        lotDate.addOmitted();
    }

}
