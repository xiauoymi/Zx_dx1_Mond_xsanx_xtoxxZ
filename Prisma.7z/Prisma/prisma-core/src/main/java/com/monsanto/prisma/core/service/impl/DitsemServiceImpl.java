package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.CellOmittedDTO;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.dto.RowImportDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.exception.ParserRowException;
import com.monsanto.prisma.core.repository.*;
import com.monsanto.prisma.core.service.DitsemService;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.LotHistoryService;
import com.monsanto.prisma.core.service.MasterdataService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by PGSETT on 14/05/2014.
 */
@Service
@Transactional
public class DitsemServiceImpl implements DitsemService {

    private static Logger log = Logger.getLogger(DitsemServiceImpl.class);

    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;

    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;

    @Autowired
    @Qualifier("zoneRepository")
    private ZoneRepository zoneRepository;

    @Autowired
    @Qualifier("establishmentRepository")
    private EstablishmentRepository establishmentRepository;

    @Autowired
    private HybridRepository hybridRepository;

    @Autowired
    private LotDitsemRepository lotDitsemRepository;

    private String messageCampaignNotExits = "prisma.campaign.notExists";
    private String messageImportErrorCell = "prisma.import.errorCell";
    private String messageImportUnexpectedError = "prisma.import.unexpectedError";
    private String messageHybridNotExits = "prisma.hybrid.notExists";
    private String messageZoneNotExits = "prisma.zone.notExists";
    private String messageEstablishmentNotExits = "prisma.establishment.notExists";
    private String messageLotExists = "prisma.lot.exists";

    @Autowired
    private LotHistoryService lotHistoryService;

    @Autowired
    private FileImportService fileImportService;

    @Autowired
    private MasterdataService masterdataService;

    private LotDitsem processDitsem(Campaign campaign, InputStream inputStream, String fileName, Boolean importManual) throws BusinessException {
        LotDitsem lotDitsem = new LotDitsem(campaign, fileName);

        try {
            Workbook wb = WorkbookFactory.create(inputStream);
            Sheet sheet = wb.getSheetAt(0);

            for (int i = Constants.ONE; i <= sheet.getLastRowNum(); i++) {
                Row rowDitsem = (Row) sheet.getRow(i);
                if (rowDitsem != null) {
                    String fieldCode = Utilities.getStringValue(rowDitsem, Constants.FOUR, Whitelist.basic());
                    if (fieldCode != null) {
                        fieldCode = Jsoup.clean(fieldCode, Whitelist.basic());

                        Lot lot = lotRepository.filterActiveLotByLotCodeAndCampaign(fieldCode, campaign);
                        if (lot == null) {
                            try {
                                RowImportDTO<Lot> rowDto = processRowDitSem(fieldCode, rowDitsem);
                                lot = rowDto.getData();
                                updateLotFromMasterdata(campaign, lot, lotDitsem, rowDto);
                                createLotDTOFromLotWithoutEstablishment(rowDitsem, lot, lotDitsem);
                                createLotDTOFromLotWithoutZone(rowDitsem, lot, lotDitsem);
                                createLotDTOFromLotWithoutHybrid(rowDitsem, lot, lotDitsem);
                            } catch (ParserRowException e) {
                                createLotDTOFromParserRowError(e, rowDitsem, fieldCode, lotDitsem);
                            } catch (Exception e) {
                                log.debug("Error to procces row ditsem. ", e);
                                createLotDTOFromException(rowDitsem, e, fieldCode, lotDitsem);
                            }
                        } else {
                            lotDitsem.addLotDTO(new LotDTO(lot, messageLotExists));
                            lotDitsem.addOmitted();
                        }
                    }
                }
            }

            lotDitsemRepository.save(lotDitsem);
            if (!importManual) {
                fileImportService.copyProcessedFile(campaign.getFilePath(), fileName);
            }
        } catch (InvalidFormatException e) {
            throw new BusinessException("Unexpected error: InvalidFormatException", e);
        } catch (IOException e) {
            throw new BusinessException("Unexpected error: IOException", e);
        }
        return lotDitsem;
    }

    private void createLotDTOFromException(Row rowDitsem, Exception e, String fieldCode, LotDitsem lotDitsem) {
        LotDTO lotDTO = new LotDTO(fieldCode, messageImportUnexpectedError);
        lotDTO.setEstablishmentName(Utilities.getStringValue(rowDitsem, Constants.THREE, Whitelist.basic()));
        lotDTO.setZoneCode(Utilities.getStringValue(rowDitsem, Constants.TWO, Whitelist.basic()));
        lotDTO.setHybridName(Utilities.getStringValue(rowDitsem, Constants.NINETEEN, Whitelist.basic()));
        lotDitsem.addLotDTO(lotDTO);
        lotDitsem.addOmitted();
    }

    private void createLotDTOFromParserRowError(ParserRowException parerRowException, Row rowDitsem, String fieldCode, LotDitsem lotDitsem) {
        String colString = CellReference.convertNumToColString(parerRowException.getIndex());
        int rowNum = parerRowException.getRow().getRowNum() + 1;
        String cell = colString + rowNum;
        log.debug("Error to procces row ditsem at cell " + cell + ": " + parerRowException.getMessage(), parerRowException);
        LotDTO lotDTO = new LotDTO(fieldCode, messageImportErrorCell);
        lotDTO.setEstablishmentName(Utilities.getStringValue(rowDitsem, Constants.THREE, Whitelist.basic()));
        lotDTO.setZoneCode(Utilities.getStringValue(rowDitsem, Constants.TWO, Whitelist.basic()));
        lotDTO.setHybridName(Utilities.getStringValue(rowDitsem, Constants.NINETEEN, Whitelist.basic()));
        lotDTO.setErrorDetail(cell);
        lotDitsem.addLotDTO(lotDTO);
        lotDitsem.addOmitted();
    }

    private void createLotDTOFromLotWithoutHybrid(Row rowDitsem, Lot lot, LotDitsem lotDitsem) throws ParserRowException {
        if (lot.getHybrid() == null) {
            String hybrid = Utilities.getStringValue(rowDitsem, Constants.NINETEEN, Whitelist.basic());
            if (hybrid == null) {
                throw new ParserRowException(rowDitsem, Constants.NINETEEN);
            }
            LotDTO lotDTO = new LotDTO(lot, messageHybridNotExits);
            lotDTO.setHybridName(Jsoup.clean(hybrid, Whitelist.basic()));
            lotDitsem.addLotDTO(lotDTO);
            lotDitsem.addOmitted();
        }
    }

    private void createLotDTOFromLotWithoutZone(Row rowDitsem, Lot lot, LotDitsem lotDitsem) throws ParserRowException {
        if (lot.getEstablishment() != null) {
            if (lot.getEstablishment().getZone() == null) {
                String zone = Utilities.getStringValue(rowDitsem, Constants.TWO, Whitelist.basic());
                if (zone == null) {
                    throw new ParserRowException(rowDitsem, Constants.TWO);
                }
                LotDTO lotDTO = new LotDTO(lot, messageZoneNotExits);
                lotDTO.setZoneCode(Jsoup.clean(zone, Whitelist.basic()));
                lotDitsem.addLotDTO(lotDTO);
                lotDitsem.addOmitted();
            }
        }
    }

    private void createLotDTOFromLotWithoutEstablishment(Row rowDitsem, Lot lot, LotDitsem lotDitsem) throws ParserRowException {
        if (lot.getEstablishment() == null) {
            String establishment = Utilities.getStringValue(rowDitsem, Constants.THREE, Whitelist.basic());
            if (establishment == null) {
                throw new ParserRowException(rowDitsem, Constants.THREE);
            }
            String zone = Utilities.getStringValue(rowDitsem, Constants.TWO, Whitelist.basic());
            if (zone == null) {
                throw new ParserRowException(rowDitsem, Constants.TWO);
            }
            LotDTO lotDTO = new LotDTO(lot, messageEstablishmentNotExits);
            lotDTO.setEstablishmentName(Jsoup.clean(establishment, Whitelist.basic()));
            lotDTO.setZoneCode(Jsoup.clean(zone, Whitelist.basic()));
            lotDitsem.addLotDTO(lotDTO);
            lotDitsem.addOmitted();
        }
    }

    private void updateLotFromMasterdata(Campaign campaign, Lot lot, LotDitsem lotDitsem, RowImportDTO<Lot> rowDto) throws DataAccessException, BusinessException {
        if (lot.getHybrid() != null && lot.getEstablishment() != null && lot.getEstablishment().getZone() != null) {
            lot.setSourceLotFile(campaign.getFilePath());
            lot.setCampaign(campaign);

            lot = masterdataService.updateLotFromMasterdata(lot);

            lot = lotRepository.save(lot);
            lotHistoryService.save(lot);

            lotDitsem.addImported();
            if (!rowDto.getOmittedCells().isEmpty()) {
                lotDitsem.addLotWithOmission(new LotDTO(rowDto));
            }
        }
    }

    @Override
    public LotDitsem addLotFromDitsem(Integer campaignId) throws BusinessException {
        Campaign campaign = campaignRepository.findById(campaignId);

        if (campaign == null) {
            throw new BusinessException(messageCampaignNotExits);
        }

        String fileName = "DITSEM.xlsx";

        InputStream inputStream = fileImportService.processFile(campaign.getFilePath(), fileName);

        return processDitsem(campaign, inputStream, fileName, false);
    }

    private RowImportDTO<Lot> processRowDitSem(String fieldCode, Row rowDitsem) throws ParserRowException {
        List<CellOmittedDTO> omittedCells = new ArrayList<CellOmittedDTO>();
        Lot lot = new Lot();
        lot.setLotCode(fieldCode);

        lot.setTotalKgCullTower(0f);
        lot.setCountEstimatedKgDsHa(0);
        lot.setIndexLot(1.0275f);
        setEstablishment(rowDitsem, lot, omittedCells);
        setHybrid(rowDitsem, lot, omittedCells);
        setHas(rowDitsem, lot, omittedCells);
        setDates(rowDitsem, lot, omittedCells);

        lot.setIsReplaced(Boolean.FALSE);
        lot.setState(Boolean.TRUE);
        lot.setMegazone(Utilities.getStringValue(rowDitsem, Constants.TWENTY, Whitelist.none(), omittedCells));
        lot.setClient(Utilities.getStringValue(rowDitsem, Constants.TWENTY_TWO, Whitelist.none(), omittedCells));
        lot.setGermoplasma(Utilities.getStringValue(rowDitsem, Constants.TWENTY_THREE, Whitelist.none(), omittedCells));

        RowImportDTO<Lot> rowImportDTO = new RowImportDTO<Lot>();
        rowImportDTO.setData(lot);
        rowImportDTO.setOmittedCells(omittedCells);
        return rowImportDTO;
    }

    private void setEstablishment(Row rowDitsem, Lot lot, List<CellOmittedDTO> omittedCells) {
        Zone zone = zoneRepository.findByCode(Utilities.getStringValue(rowDitsem, Constants.TWO, Whitelist.basic(), omittedCells));

        if (zone != null) {
            Establishment establishment = establishmentRepository.findByNameAndZone(Utilities.getStringValue(rowDitsem, Constants.THREE, Whitelist.basic(), omittedCells), zone.getCode());
            lot.setEstablishment(establishment);
        }
    }

    private void setHybrid(Row rowDitsem, Lot lot, List<CellOmittedDTO> omittedCells) throws ParserRowException {
        String hybridName = Utilities.getStringValue(rowDitsem, Constants.NINETEEN, Whitelist.basic(), omittedCells);

        if (hybridName == null) {
            throw new ParserRowException(rowDitsem, Constants.NINETEEN);
        }

        Hybrid hybrid = hybridRepository.findByName(hybridName);
        lot.setHybrid(hybrid);
    }

    private void setDates(Row rowDitsem, Lot lot, List<CellOmittedDTO> omittedCells) {
        lot.setPlantingWeek(Utilities.getIntegerValue(rowDitsem, Constants.TWENTY_EIGHT, omittedCells));
        lot.setEstimatedPlantingDate(Utilities.getDateFromNumberWeek(rowDitsem, Constants.TWENTY_EIGHT, omittedCells));
        lot.setPlantingDate(lot.getEstimatedPlantingDate());
    }

    private void setHas(Row rowDitsem, Lot lot, List<CellOmittedDTO> omittedCells) {
        lot.setRegisteredHas(Utilities.getFloatValue(rowDitsem, Constants.TWENTY_SEVEN, omittedCells));
        lot.setHarvestableHas(Utilities.getFloatValue(rowDitsem, Constants.FIVE, omittedCells));
    }

}
