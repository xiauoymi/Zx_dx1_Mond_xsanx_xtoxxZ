package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Establishment;
import com.monsanto.prisma.core.repository.EstablishmentRepository;
import com.monsanto.prisma.core.service.EstablishmentService;
import org.hibernate.Hibernate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by EPESTE on 19/05/2014.
 */
@Service
public class EstablishmentServiceImpl implements EstablishmentService {

    @Autowired
    @Qualifier("establishmentRepository")
    private EstablishmentRepository establishmentRepository;

    @Override
    public List<Establishment> findAll() {
        return (List<Establishment>) establishmentRepository.findAll();
    }
}
