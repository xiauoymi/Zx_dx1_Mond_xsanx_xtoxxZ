package com.monsanto.prisma.core.service.impl;

import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.JcifsResourcesService;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

/**
 * Created by AFREI on 16/07/2014.
 */
@Service
public class FileImportServiceImpl implements FileImportService {

    private static Logger log = Logger.getLogger(FileImportServiceImpl.class);

    private String messageFileNotFound = "prisma.file.notFound";

    private String messagePathNotFound = "prisma.file.path.notExists";

    private String messageNoAccessToPath = "prisma.file.path.notAccess";

    private String messageInvalidPath = "prisma.file.path.invalid";

    private String messageSmbError = "prisma.smb.error";

    private String messageFileUsedByAnotherProcess = "prisma.file.open";

    private String messageEncryption = "prisma.file.encryption";

    @Autowired
    private JcifsResourcesService jcifsResourcesService;

    public void copyProcessedFile(String filePath, String fileName) throws BusinessException {
        String campaignPath = filePath.replace("\\", "/");
        String url = "smb:" + campaignPath;
        try {
            NtlmPasswordAuthentication auth = jcifsResourcesService.getNtlmPasswordAuthentication();

            SmbFile fileToGet = getFile(url, fileName, auth);

            copyFile(url, fileName, fileToGet, auth);

            fileToGet.delete();
        } catch (MalformedURLException e) {
            log.error(messageInvalidPath, e);
            throw new BusinessException(messageInvalidPath, e);
        } catch (SmbException e) {
            log.error(e);
            throw new BusinessException(messageFileUsedByAnotherProcess, e);
        } catch (EncryptorException e) {
            log.error(e);
            throw new BusinessException(messageEncryption, e);
        }
    }

    private void copyFile(String url, String fileName, SmbFile fileToGet, NtlmPasswordAuthentication auth) throws MalformedURLException, SmbException, BusinessException {
        String urlCopy = url + "processed/";
        String urlFileCopy = urlCopy + fileName + "_Process" + getDateHour();
        SmbFile dirCopy = jcifsResourcesService.getSbmFile(urlCopy, auth);
        SmbFile fileToCopy = jcifsResourcesService.getSbmFile(urlFileCopy, auth);

        if (!dirCopy.exists()) {
            dirCopy.mkdir();
        }

        if (!dirCopy.canWrite()) {
            throw new BusinessException(messageNoAccessToPath);
        }

        fileToGet.copyTo(fileToCopy);
    }

    private SmbFile getFile(String url, String fileName, NtlmPasswordAuthentication auth) throws MalformedURLException, BusinessException, SmbException {
        SmbFile dir = jcifsResourcesService.getSbmFile(url, auth);
        SmbFile fileToGet = jcifsResourcesService.getSbmFile(url + fileName, auth);

        if (!dir.exists()) {
            throw new BusinessException(messagePathNotFound);
        }

        if (!dir.canRead()) {
            throw new BusinessException(messageNoAccessToPath);
        }

        if (!fileToGet.exists()) {
            throw new BusinessException(messageFileNotFound);
        }

        return fileToGet;
    }

    private String getDateHour() {
        DateTime dateTime = DateTime.now();
        Integer date = dateTime.getDayOfMonth();
        Integer time = dateTime.getHourOfDay();
        return date.toString() + time.toString();
    }

    public InputStream processFile(String filePath, String fileName) throws BusinessException {
        String campaignPath = filePath.replace("\\", "/");
        String url = "smb:" + campaignPath;
        InputStream inputStream = null;
        try {
            NtlmPasswordAuthentication auth = jcifsResourcesService.getNtlmPasswordAuthentication();

            SmbFile fileToGet = getFile(url, fileName, auth);

            if (!fileToGet.exists()) {
                throw new BusinessException(messageFileNotFound);
            }

            inputStream = jcifsResourcesService.getInputStream(fileToGet);
        } catch (MalformedURLException e) {
            log.error(messageInvalidPath, e);
            throw new BusinessException(messageInvalidPath, e);
        } catch (UnknownHostException e) {
            log.error(messageInvalidPath, e);
            throw new BusinessException(messageInvalidPath, e);
        } catch (SmbException e) {
            log.error(e);
            throw new BusinessException(messageSmbError, e);
        } catch (EncryptorException e) {
            log.error(e);
            throw new BusinessException(messageEncryption, e);
        }


        return inputStream;
    }

    public void validatePath(String filePath) throws BusinessException {
        String path = filePath.replace("\\", "/");

        String url = "smb:" + path;
        try {
            NtlmPasswordAuthentication auth = jcifsResourcesService.getNtlmPasswordAuthentication();

            SmbFile dir = jcifsResourcesService.getSbmFile(url, auth);
            if (!dir.exists()) {
                throw new BusinessException(messagePathNotFound);
            }

            if (!dir.canRead()) {
                throw new BusinessException(messageNoAccessToPath);
            }
        } catch (MalformedURLException e) {
            log.error(messageInvalidPath, e);
            throw new BusinessException(messageInvalidPath, e);
        } catch (SmbException e) {
            log.error(e);
            throw new BusinessException(messageSmbError, e);
        } catch (EncryptorException e) {
            log.error(e);
            throw new BusinessException(messageEncryption, e);
        }


    }
}
