package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Filter;
import com.monsanto.prisma.core.domain.UserFilter;
import com.monsanto.prisma.core.repository.FilterRepository;
import com.monsanto.prisma.core.service.FilterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by EPESTE on 31/10/2014.
 */
@Service
public class FilterServiceImpl implements FilterService {

    @Autowired
    private FilterRepository filterRepository;

    @Override
    public void save(UserFilter userFilter) {
        for (Filter filter : userFilter.getFilterList()) {
            filter.setUserFilter(userFilter);
            filterRepository.save(filter);
        }
    }
}
