package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Forecast;
import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.DataReportForecastDTO;
import com.monsanto.prisma.core.dto.ForecastDTO;
import com.monsanto.prisma.core.dto.ForecastReportDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.repository.ForecastReportRepository;
import com.monsanto.prisma.core.repository.ForecastRepository;
import com.monsanto.prisma.core.repository.LotRepository;
import com.monsanto.prisma.core.service.ForecastService;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by EPESTE on 04/12/2014.
 */
@Service
public class ForecastServiceImpl implements ForecastService {

    @Autowired
    private ForecastRepository forecastRepository;

    @Autowired
    private ForecastReportRepository forecastReportRepository;

    @Autowired
    private LotRepository lotRepository;

    private static Logger log = Logger.getLogger(ForecastServiceImpl.class);

    @Override
    public Forecast findByCampaignId(Integer campaignId) {
        return forecastRepository.findByCampaignId(campaignId);
    }

    @Override
    public Forecast save(Forecast forecast) {
        return forecastRepository.save(forecast);
    }

    @Override
    public Forecast update(ForecastDTO forecastDTO) throws BusinessException {
        Forecast forecast = forecastRepository.findByCampaignId(forecastDTO.getCampaign());
        forecast.update(forecastDTO);
        try {
            forecast = forecastRepository.save(forecast);

            forecastRepository.updateEstimatedRwDate(forecast.getDaysRw().doubleValue(), forecastDTO.getCampaign());
            updateEstimatedDsDate(forecastDTO.getCampaign(), forecast.getDaysDs());
        } catch (Exception e) {
            log.error("Error in update the forecast.", e);
            throw new BusinessException();
        }

        return forecast;
    }

    public void updateEstimatedDsDate(Integer campaignId, Integer daysDs) {
        List<Lot> lots = lotRepository.findLotsByCampaignId(campaignId);
        for (Lot lot : lots) {
            DateTime estimatedDsDateTime;
            if (lot.getRealRwReceiptDate() != null) {
                estimatedDsDateTime = new DateTime(lot.getRealRwReceiptDate());
                lot.setEstimatedDsDate(estimatedDsDateTime.plusDays(daysDs).toDate());
            } else if (lot.getEstimatedRwDate() != null) {
                estimatedDsDateTime = new DateTime(lot.getEstimatedRwDate());
                lot.setEstimatedDsDate(estimatedDsDateTime.plusDays(daysDs).toDate());
            }
            lotRepository.save(lot);
        }
    }

    public void setDatesForecastByCampaign(Integer campaignId, ForecastReportDTO forecastReportDTO) {
        List maxDates = getMaxMinDatesList(campaignId);
        generateRangeOfDates(forecastReportDTO, maxDates);
    }

    private List getMaxMinDatesList(Integer campaignId) {
        return forecastReportRepository.findMaxMinDatesRwDsFng(campaignId);
    }

    private void generateRangeOfDates(ForecastReportDTO forecastReportDTO, List maxDates) {
        List<Date> dates = new ArrayList<Date>();

        DateTime maxDate = getMaxDateFromRange(maxDates);
        DateTime minDate = getMinDateFromRange(maxDates);

        if (minDate != null && maxDate != null) {
            DateTime aux = minDate;
            while (aux.compareTo(maxDate) < 1) {
                dates.add(aux.toDate());
                aux = aux.plusMonths(1);
            }
        }
        forecastReportDTO.setRange(dates);
    }


    public DateTime getMaxDateFromRange(List<Date> listDates) {
        DateTime maxDate = null;

        for (Date date : listDates) {
            if (date != null) {
                if (maxDate == null) {
                    maxDate = new DateTime(date);
                } else if (date.after(maxDate.toDate())) {
                    maxDate = new DateTime(date);
                }
            }
        }

        return maxDate;
    }

    public DateTime getMinDateFromRange(List<Date> listDates) {
        DateTime maxDate = null;

        for (Date date : listDates) {
            if (date != null) {
                if (maxDate == null) {
                    maxDate = new DateTime(date);
                } else if (date.before(maxDate.toDate())) {
                    maxDate = new DateTime(date);
                }
            }
        }

        return maxDate;
    }

    @Override
    public ForecastReportDTO getReportInformation(Integer campaignId) {
        List<DataReportForecastDTO> reportList = new ArrayList<DataReportForecastDTO>();
        ForecastReportDTO forecastReportDTO = new ForecastReportDTO();
        List estimatedRealList = null;

        setDatesForecastByCampaign(campaignId, forecastReportDTO);

        estimatedRealList = forecastReportRepository.findEstimatedRealRwByGranProgram(campaignId);
        for (Object objects : estimatedRealList) {
            reportList.add(new DataReportForecastDTO((Object[]) objects));
        }
        forecastReportDTO.setRwForecastDTOs(reportList);

        estimatedRealList = forecastReportRepository.findEstimatedRealDsByGranProgram(campaignId);
        reportList = new ArrayList<DataReportForecastDTO>();
        for (Object objects : estimatedRealList) {
            reportList.add(new DataReportForecastDTO((Object[]) objects));
        }
        forecastReportDTO.setDsForecastDTOs(reportList);

        estimatedRealList = forecastReportRepository.findEstimatedRealFngByGranProgram(campaignId);
        reportList = new ArrayList<DataReportForecastDTO>();
        for (Object objects : estimatedRealList) {
            reportList.add(new DataReportForecastDTO((Object[]) objects));
        }
        forecastReportDTO.setFngForecastDTOs(reportList);

        return forecastReportDTO;
    }

}
