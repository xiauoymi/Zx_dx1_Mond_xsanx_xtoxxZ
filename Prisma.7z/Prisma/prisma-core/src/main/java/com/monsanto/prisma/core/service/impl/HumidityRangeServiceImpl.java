package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.HumidityRange;
import com.monsanto.prisma.core.domain.Zone;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.repository.HumidityRangeRepository;
import com.monsanto.prisma.core.service.HumidityRangeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Created by PGSETT on 26/06/2014.
 */
@Service
@Transactional
public class HumidityRangeServiceImpl implements HumidityRangeService {

    @Autowired
    @Qualifier("humidityRangeRepository")
    private HumidityRangeRepository humidityRangeRepository;

    @Override
    public List<HumidityRange> findAll() throws DataAccessException {
        return humidityRangeRepository.findAll();
    }

    @Override
    public HumidityRange findById(Integer id) throws DataAccessException {
        return humidityRangeRepository.findById(id);
    }

    @Override
    public List<HumidityRange> findByHybrid(String hybridName) throws DataAccessException {
        return humidityRangeRepository.findByHybrid(hybridName);
    }

    @Override
    public List<HumidityRange> findByZone(Zone zone) throws DataAccessException {
        return humidityRangeRepository.findByZone(zone);
    }

    @Override
    public void update(HumidityRange humidityRange) throws DataAccessException {
        humidityRangeRepository.save(humidityRange);
    }

    @Override
    public void delete(Integer id) throws DataAccessException {
        humidityRangeRepository.delete(id);
    }

    @Override
    public HumidityRange findByHybridZone(String hybridName, String zoneCode) throws DataAccessException {
        return humidityRangeRepository.findByHybridZone(hybridName, zoneCode);
    }


}
