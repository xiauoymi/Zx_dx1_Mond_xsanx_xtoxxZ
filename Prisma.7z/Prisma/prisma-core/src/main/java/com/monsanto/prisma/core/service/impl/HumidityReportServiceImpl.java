package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Campaign;
import com.monsanto.prisma.core.domain.HumidityReport;
import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.repository.HumidityReportRepository;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.HumidityReportService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

/**
 * Created by EPESTE on 21/08/2014.
 */
@Service
public class HumidityReportServiceImpl implements HumidityReportService {

    private static Logger log = Logger.getLogger(HumidityReportServiceImpl.class);

    @Autowired
    private HumidityReportRepository humidityReportRepository;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private FileImportService fileImportService;

    @Autowired
    private LotService lotService;

    private String messageCampaignNotExists = "prisma.campaign.notExists";

    @Override
    public HumidityReport importFile(Integer campaignId) throws BusinessException, IOException, InvalidFormatException, DataAccessException {
        log.debug("Init - importFile :: CampaignId: " + campaignId);

        Campaign campaign = campaignService.findById(campaignId);
        if (campaign == null) {
            throw new BusinessException(messageCampaignNotExists);
        }

        return processHumidityReport(campaign);
    }

    private HumidityReport processHumidityReport(Campaign campaign) throws BusinessException, IOException, InvalidFormatException, DataAccessException {
        InputStream inputStream;
        Workbook wb;
        Sheet sheet;
        Row row;
        String lotCode = null;
        String lotCodeActual;
        Integer countLots = 0;
        Float humidityLot = new Float(0);
        Float humidityActual;

        HumidityReport humidityReport = new HumidityReport();

        inputStream = fileImportService.processFile(campaign.getFilePath(), Constants.FILE_IMPORT_AVERAGE_HUMIDITY);
        wb = WorkbookFactory.create(inputStream);
        sheet = wb.getSheetAt(0);

        for (int i = Constants.NINE; i < sheet.getLastRowNum(); i++) {
            row = (Row) sheet.getRow(i);
            if (row == null) {
                break;
            }

            lotCodeActual = Utilities.getStringValue(row, Constants.THREE, Whitelist.basic());
            humidityActual = Utilities.getFloatValue(row, Constants.NINE);

            if (isNewLot(lotCode, lotCodeActual)) {
                if (lotCode != null) {
                    updateAverageHumidityLot(campaign, lotCode, humidityLot, countLots, humidityReport);
                }
                lotCode = lotCodeActual;
                humidityLot = humidityActual;
                countLots = 1;
            } else if (humidityActual != null) {
                humidityLot = humidityLot + humidityActual;
                countLots++;
            }
        }

        updateAverageHumidityLot(campaign, lotCode, humidityLot, countLots, humidityReport);

        saveHumidityReport(humidityReport, campaign);

        fileImportService.copyProcessedFile(campaign.getFilePath(), Constants.FILE_IMPORT_AVERAGE_HUMIDITY);
        return humidityReport;
    }

    public void saveHumidityReport(HumidityReport humidityReport, Campaign campaign) {
        humidityReport.setCampaignId(campaign.getId());
        humidityReport.setDateProccess(new Date());
        humidityReport.setPathFile(campaign.getFilePath() + "\\" + Constants.FILE_IMPORT_AVERAGE_HUMIDITY);
        humidityReportRepository.save(humidityReport);
    }

    private void updateAverageHumidityLot(Campaign campaign, String lotCode, Float humidityLot, Integer countLots, HumidityReport humidityReport) throws DataAccessException {
        if (lotCode == null) {
            return;
        }
        
        Lot lot = lotService.filterActiveLotByLotCodeAndCampaign(lotCode, campaign);
        if (lot == null) {
            humidityReport.addOmitted();
            return;
        }

        humidityReport.addModified();
        lot.setAverageHumidity(humidityLot / countLots);
        lotService.update(lot);
    }

    private boolean isNewLot(String lotCode, String lotCodeActual) {
        if (lotCode == null) {
            return true;
        }

        return !lotCode.equals(lotCodeActual);
    }
}
