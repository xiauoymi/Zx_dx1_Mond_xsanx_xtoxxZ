package com.monsanto.prisma.core.service.impl;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.Hybrid;
import com.monsanto.prisma.core.dto.HybridDTO;
import com.monsanto.prisma.core.repository.HybridRepository;
import com.monsanto.prisma.core.service.HybridService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Created by EPESTE on 19/05/2014.
 */
@Service
public class HybridServiceImpl implements HybridService {

    @Autowired
    private HybridRepository hybridRepository;

    @Override
    public List<Hybrid> findAll() {
        return (List<Hybrid>) hybridRepository.findAll();
    }

    @Override
    public Hybrid findById(Integer id) {
        return hybridRepository.findById(id);
    }

    @Override
    public Hybrid findByName(String name) {
        return hybridRepository.findByName(name);
    }

    @Override
    public List<HybridDTO> findByCampaignId(Integer campaignId) {
        List<Hybrid> hybrids = hybridRepository.findByCampaignId(campaignId);

        return Lists.transform(hybrids, new Function<Hybrid, HybridDTO>() {
            @Nullable
            @Override
            public HybridDTO apply(@Nullable Hybrid hybrid) {
                return new HybridDTO(hybrid);
            }
        });
    }
}
