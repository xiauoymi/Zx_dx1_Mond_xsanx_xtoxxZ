package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.HybridType;
import com.monsanto.prisma.core.repository.HybridTypeRepository;
import com.monsanto.prisma.core.service.HybridTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by EPESTE on 19/05/2014.
 */
@Service
public class HybridTypeServiceImpl implements HybridTypeService {

    @Autowired
    private HybridTypeRepository hybridTypeRepository;

    @Override
    public List<HybridType> findAll() {
        return (List<HybridType>) hybridTypeRepository.findAll();
    }
}
