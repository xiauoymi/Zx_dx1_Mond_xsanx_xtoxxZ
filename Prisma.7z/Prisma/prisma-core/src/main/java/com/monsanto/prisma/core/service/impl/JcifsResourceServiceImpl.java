package com.monsanto.prisma.core.service.impl;

import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.prisma.core.service.ApplicationService;
import com.monsanto.prisma.core.service.JcifsResourcesService;
import jcifs.smb.NtlmPasswordAuthentication;
import jcifs.smb.SmbException;
import jcifs.smb.SmbFile;
import jcifs.smb.SmbFileInputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.UnknownHostException;

/**
 * Created by AFREI on 17/07/2014.
 */
@Service
public class JcifsResourceServiceImpl implements JcifsResourcesService{

    @Override
    public NtlmPasswordAuthentication getNtlmPasswordAuthentication() throws EncryptorException {
        return new NtlmPasswordAuthentication(applicationService.getApplicationAccount().getDomain(), applicationService.getApplicationAccount().getName(), applicationService.getApplicationAccount().getPassword());
    }

    @Autowired
    private ApplicationService applicationService;

    @Override
    public SmbFile getSbmFile(String url, NtlmPasswordAuthentication auth) throws MalformedURLException {
        return new SmbFile(url,auth);
    }

    @Override
    public InputStream getInputStream(SmbFile fileToGet) throws MalformedURLException, UnknownHostException, SmbException {
        return new SmbFileInputStream(fileToGet);
    }
}
