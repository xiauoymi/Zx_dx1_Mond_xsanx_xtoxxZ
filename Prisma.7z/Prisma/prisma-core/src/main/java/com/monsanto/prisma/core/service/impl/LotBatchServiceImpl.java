package com.monsanto.prisma.core.service.impl;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.LotBatch;
import com.monsanto.prisma.core.dto.LotBatchDTO;
import com.monsanto.prisma.core.repository.LotBatchRepository;
import com.monsanto.prisma.core.service.LotBatchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Created by BSBUON on 21/08/2014.
 */
@Service
public class LotBatchServiceImpl implements LotBatchService {

    @Autowired
    @Qualifier("lotBatchRepository")
    private LotBatchRepository lotBatchRepository;

    @Override
    public List<LotBatchDTO> findByLotId(Integer lotId) {
        return Lists.transform(lotBatchRepository.findByLotId(lotId), new Function<LotBatch, LotBatchDTO>() {
            @Nullable
            @Override
            public LotBatchDTO apply(@Nullable LotBatch lotBatch) {
                return new LotBatchDTO(lotBatch);
            }
        });
    }
}
