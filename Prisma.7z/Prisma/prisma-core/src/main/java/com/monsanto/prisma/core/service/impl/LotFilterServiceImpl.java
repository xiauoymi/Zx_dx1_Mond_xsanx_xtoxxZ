package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.LotFilter;
import com.monsanto.prisma.core.repository.LotFilterRepository;
import com.monsanto.prisma.core.service.LotFilterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by epeste on 29/10/2014.
 */
@Service
public class LotFilterServiceImpl implements LotFilterService {

    @Autowired
    private LotFilterRepository lotFilterRepository;

    @Override
    public List<LotFilter> findAll() {
        return (List<LotFilter>) lotFilterRepository.findAll();
    }
}
