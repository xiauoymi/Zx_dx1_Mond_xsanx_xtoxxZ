package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.domain.LotHistory;
import com.monsanto.prisma.core.repository.LotHistoryRepository;
import com.monsanto.prisma.core.service.LotHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by EPESTE on 23/10/2014.
 */
@Service
public class LotHistoryServiceImpl implements LotHistoryService {
    @Autowired
    private LotHistoryRepository  lotHistoryRepository;

    @Override
    public void save(Lot lot) {
        LotHistory lotHistory = new LotHistory(lot, "new");
        lotHistoryRepository.save(lotHistory);
    }
}
