package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Hybrid;
import com.monsanto.prisma.core.domain.LotHumidity;
import com.monsanto.prisma.core.domain.Zone;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.repository.LotHumidityRepository;
import com.monsanto.prisma.core.service.LotHumidityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 24/06/2014.
 */
@Service
@Transactional
public class LotHumidityServiceImpl implements LotHumidityService {

    @Autowired
    private LotHumidityRepository lotHumidityRepository;

    @Override
    public List<LotHumidity> findByHybridZone(Hybrid hybrid, Zone zone) throws DataAccessException {
        return lotHumidityRepository.findByHybridZone(hybrid, zone);
    }

    @Override
    public LotHumidity findByLotMaxDate(Integer id, Integer campaignId) throws DataAccessException {
        return lotHumidityRepository.findByLotMaxDate(id, campaignId);
    }

    @Override
    public List<LotHumidity> findByLot(Integer id) throws DataAccessException {
        return lotHumidityRepository.findByLot(id);
    }

    @Override
    public LotHumidity findByLotHumidityByLotAndDate(Integer id, Date sampleDate) throws DataAccessException {
        return lotHumidityRepository.findByLotHumidityByLotAndDate(id, sampleDate);
    }
}
