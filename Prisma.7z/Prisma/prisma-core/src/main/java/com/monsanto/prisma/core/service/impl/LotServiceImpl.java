package com.monsanto.prisma.core.service.impl;

import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.FilterDTO;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.dto.PreviousLotDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.repository.*;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.ApplicationProcessManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;


/**
 * Created by PGSETT on 14/05/2014.
 */
@Service
public class LotServiceImpl implements LotService {

    private static Logger log = Logger.getLogger(LotServiceImpl.class);

    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;

    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;

    @Autowired
    private ApplicationProcessManager processManager;

    @Autowired
    private LotHistoryRepository lotHistoryRepository;

    @Autowired
    private LotComboRepository lotComboRepository;

    @Autowired
    private LotFilterRepository lotFilterRepository;

    @Override
    public List<LotCombo> findAll() throws DataAccessException {
        return lotComboRepository.findAll();
    }


    @Override
    @Transactional
    public List<Lot> findByFilter(Integer campaignId, List<FilterDTO> filters) throws DataAccessException {
        List<Lot> lots = new ArrayList<Lot>();

        lots = lotFilterRepository.findLots(campaignId, filters);

        return lots;
    }

    @Override
    public List<Lot> findActiveLotsForCurrentActiveCampaign() throws DataAccessException {
        //TODO Fix list of campaign
        Campaign campaign = campaignRepository.findByIsActive(Boolean.TRUE).get(0);
        return lotRepository.findActiveLotsByCampaignId(campaign.getId());
    }

    @Override
    public Boolean isHarvested(String lotCode) throws DataAccessException {
        return lotRepository.findByLotCode(lotCode).getHarvestableHas() > 0;
    }

    @Override
    public Lot deleteLogical(Integer lotId) throws DataAccessException {
        Lot lot = lotRepository.findById(lotId);
        if (!lot.isHarvested()) {
            lot.setState(Boolean.FALSE);
            lotRepository.save(lot);
        }
        return lot;
    }


    @Override
    public Lot recalculate(LotDTO lotDTO, Integer idTab, String operation, User user) throws BusinessException {
        LotHistory lotHistory;

        Lot lot = lotRepository.findById(lotDTO.getId());

        processManager.process(operation, lot, lotDTO);

        lotHistory = new LotHistory(lot, Constants.LOT_HISTORY_UPDATE, user);
        lotHistoryRepository.save(lotHistory);
        return lot;
    }
    @Override
    public Lot updatePrevLot(LotDTO lotDTO,  User user) throws BusinessException {
        LotHistory lotHistory;
        Lot lot = lotRepository.findById(lotDTO.getId());
        parsePreviousLot(lot, lotDTO);
        lotRepository.save(lot);
        lotHistory = new LotHistory(lot, Constants.LOT_HISTORY_UPDATE, user);
        lotHistoryRepository.save(lotHistory);
        return lot;
    }

    private void parsePreviousLot(Lot lot, LotDTO lotDTO) {
        if (lotDTO.getPreviousLot() != null) {
            List<PreviousLot> prevLotList = new ArrayList<PreviousLot>();
            for (Integer val : lotDTO.getPreviousLot()) {
                PreviousLot prev = new PreviousLot();
                prev.setActualLot(lot.getId());
                prev.setPreviousLot(val);
                prevLotList.add(prev);
            }
            lot.setPreviousLot(prevLotList);
        }
    }

    public List<PreviousLotDTO> findPreviousLotsByLotId(Integer id) {
        List<LotCombo> lots = lotComboRepository.findAll();
        List<PreviousLot> previousLots = lotRepository.findPreviousLotsByLotId(id);
        List<PreviousLotDTO> previousLotDTOs = new ArrayList<PreviousLotDTO>();
        for (LotCombo lot : lots) {
            PreviousLotDTO previousLotDTO = new PreviousLotDTO(lot, previousLots);
            previousLotDTOs.add(previousLotDTO);
        }
        return previousLotDTOs;
    }

    @Override
    public List<Lot> findActiveAndHuskedLotsByHybridIdAndCampaignId(Integer hybridId, Integer campaignId) {
        return FluentIterable.from(lotRepository.findOnlyActiveLotsByHybridIdAndCampaignId(hybridId, campaignId)).filter(new Predicate<Lot>() {
            @Override
            public boolean apply(@Nullable Lot lot) {
                return lot.isHusked();
            }
        }).toList();
    }


    @Override
    public Lot filterActiveLotByLotCodeAndCampaign(String lotCode, Campaign campaign) {
        return lotRepository.filterActiveLotByLotCodeAndCampaign(lotCode, campaign);
    }

    @Override
    public TotalLotsDTO findTotalLotsAndHas(Integer idCampaign) {
        Object[] list = lotRepository.findTotalLotsAndHas(idCampaign);
        return new TotalLotsDTO(list);
    }


    @Override
    public void update(Lot lot) throws DataAccessException {
        lotRepository.save(lot);
    }

    @Override
    public List<Lot> findLotsByCampaignId(Integer campaignId) {
        return lotRepository.findLotsByCampaignId(campaignId);
    }

    @Override
    public List<Lot> findActiveLotsByCampaignId(Integer campaignId) {
        return lotRepository.findActiveLotsByCampaignId(campaignId);
    }

    /*
    * ESTO CORRESPONDE A LA PAGINACION
    * */
//    @Override
//    public Page<Lot> findActiveLotsByCampaignIdWithPage(Integer campaignId, Pageable pageable) {
//        return lotRepository.findActiveLotsByCampaignIdWithPage(campaignId, pageable);
//    }

    @Override
    public List<LotHistory> getLotHistory(Integer lotId) {
        return lotHistoryRepository.findByLotId(lotId);
    }

    @Override
    public Integer countLotByCodeAndDiffLotId(String lotCode, Integer lotId) {
        return lotRepository.countLotByCodeAndDiffLotId(lotCode, lotId);
    }

    public Lot findById(Integer id) throws DataAccessException {
        return lotRepository.findById(id);
    }

}
