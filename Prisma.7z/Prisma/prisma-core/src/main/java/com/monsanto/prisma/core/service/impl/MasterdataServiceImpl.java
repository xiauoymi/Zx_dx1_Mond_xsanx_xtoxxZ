package com.monsanto.prisma.core.service.impl;

import com.google.common.base.Predicate;
import com.google.common.collect.FluentIterable;
import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.CellOmittedDTO;
import com.monsanto.prisma.core.dto.RowImportDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.repository.*;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.MasterdataService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import com.monsanto.prisma.core.workflow.ApplicationProcessManager;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.joda.time.DateTime;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Nullable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by EPESTE on 19/06/2014.
 */
@Service
@Transactional
public class MasterdataServiceImpl implements MasterdataService {

    private static Logger log = Logger.getLogger(MasterdataServiceImpl.class);

    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;

    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;

    @Autowired
    private HybridRepository hybridRepository;

    @Autowired
    private ApplicationProcessManager processManager;

    @Autowired
    private LotMasterdataRepository lotMasterdataRepository;

    private String messageCampaignNotExits = "prisma.campaign.notExists";

    @Autowired
    private MasterdataRepository masterdataRepository;

    @Autowired
    private FileImportService fileImportService;

    /**
     * Process lot to automatic import
     *
     * @param campaignId
     * @return
     * @throws com.monsanto.prisma.core.exception.BusinessException
     */
    @Override
    public ArrayList<LotMasterdata> refreshFromMasterdata(Integer campaignId) throws BusinessException, DataAccessException {
        Campaign campaign = campaignRepository.findById(campaignId);

        if (campaign == null) {
            throw new BusinessException(messageCampaignNotExits);
        }

        String fileName = "MASTERDATA.xlsx";


        log.debug("get inputStream - ini -");

        InputStream inputStream = fileImportService.processFile(campaign.getFilePath(), fileName);

        log.debug("get inputStream - fin -");

        ArrayList<LotMasterdata> lotMasterdata = processMasterData(campaign, inputStream, fileName, false);

        return lotMasterdata;
    }

    @Override
    public List<Masterdata> findByHybridType(HybridType hybridType) throws DataAccessException {
        return masterdataRepository.findByHybridType(hybridType);
    }

    @Override
    public Lot processMasterdata(Lot lot) throws DataAccessException, BusinessException {
        if (lot.getHybrid() != null) {
            List<Masterdata> masterdataList = masterdataRepository.findByManufactureCodeAndCampaign(lot.getHybrid().getName(), lot.getMegazone(), lot.getCampaign().getId());

            if (masterdataList.size() > 0) {
                Masterdata masterdata = masterdataList.get(masterdataList.size() - 1);

                lot.setTargetRwToDs(masterdata.getDsRw());
                lot.setHarvestRwToDs(lot.getTargetRwToDs());
                lot.setTargetDsToFng(masterdata.getFngDs());
                lot.setTargetKgBag(masterdata.getKgBls());
                lot.setTargetBagHa(masterdata.getUnHa());
                lot.setFlowHarvDays(masterdata.getFlowHarvDays());
//                lot.setPlantFlowDays(masterdata.getPlantFlowDays());
                lot.setActualWeightBagLot(lot.getTargetKgBag());
            }
        } else {
            throw new BusinessException("El lote no posee hybrido.");
        }
        return lot;
    }

    @Override
    public Lot updateLotFromMasterdata(Lot lot) throws DataAccessException, BusinessException {
        List<Masterdata> masterdatas = masterdataRepository.findByManufactureCodeAndCampaign(lot.getHybrid().getName(), lot.getMegazone(), lot.getCampaign().getId());

        if (masterdatas.size() > 0) {
            Masterdata masterdata = masterdatas.get(masterdatas.size() - 1);
            lot.setTargetRwToDs(masterdata.getDsRw());
            lot.setHarvestRwToDs(lot.getTargetRwToDs());
            lot.setTargetDsToFng(masterdata.getFngDs());
            lot.setTargetKgBag(masterdata.getKgBls());
            lot.setTargetBagHa(masterdata.getUnHa());
            lot.setFlowHarvDays(masterdata.getFlowHarvDays());
//            lot.setPlantFlowDays(masterdata.getPlantFlowDays());
            lot.setActualWeightBagLot(lot.getTargetKgBag());
            processManager.process("ditsemImport", lot);
        }

        return lot;
    }

    private ArrayList<LotMasterdata> processMasterData(Campaign campaign, InputStream inputStream, String fileName, Boolean importManual) throws BusinessException, DataAccessException {
        ArrayList<LotMasterdata> lotMasterdataList = new ArrayList<LotMasterdata>();
        try {
            log.debug("WorkbookFactory.create(inputStream) - ini -");
            Workbook wb = WorkbookFactory.create(inputStream);
            log.debug("WorkbookFactory.create(inputStream) - fin -");
            Sheet sheet = wb.getSheetAt(0);

            log.debug("Procesar archivo - ini -");
            for (int i = Constants.FIVE_INT; i <= sheet.getLastRowNum(); i++) {
                Row rowMasterdata = (Row) sheet.getRow(i);

                String hybridName = Utilities.getStringValue(rowMasterdata, Constants.SIX, Whitelist.basic());
                if (hybridName != null) {
                    RowImportDTO<Masterdata> rowImportDTO = getMasterdataFromRow(rowMasterdata);
                    Masterdata masterdata = rowImportDTO.getData();

                    masterdata.setCampaign(campaign);
                    if (masterdata.getMegaZone() != null) {
                        Hybrid hybrid = hybridRepository.findByName(hybridName);
                        LotMasterdata lotMasterdata = new LotMasterdata();
                        if (hybrid != null) {

                            lotMasterdata.setOmitted(processLotWithMasterdata(campaign, lotMasterdata, hybrid, masterdata));

                            saveLotMasterdata(campaign, fileName, lotMasterdataList, lotMasterdata.getImported(), lotMasterdata.getOmitted(), hybrid, rowImportDTO, masterdata);
                        } else {
                            log.error("processMasterData: Hibryd " + hybridName + "not found. Hibryd ommited.");
                            lotMasterdata = new LotMasterdata(hybridName, masterdata.getMegaZone(), lotMasterdata.getImported(), lotMasterdata.getOmitted(), "prisma.hybrid.notExists");
                            lotMasterdataList.add(lotMasterdata);
                        }
                    }
                }
            }

            log.debug("Procesar archivo - fin -");

            if (!importManual) {
                log.debug("copiar archivo - ini -");
                fileImportService.copyProcessedFile(campaign.getFilePath(), fileName);
                log.debug("copiar archivo - fin -");
            }

        } catch (FileNotFoundException e) {
            throw new BusinessException("Error inesperado: FileNotFoundException", e);
        } catch (InvalidFormatException e) {
            throw new BusinessException("Error inesperado: InvalidFormatException", e);
        } catch (IOException e) {
            throw new BusinessException("Error inesperado: IOException", e);
        }
        return lotMasterdataList;

    }

    private int processLotWithMasterdata(Campaign campaign, LotMasterdata lotMasterdata, Hybrid hybrid, Masterdata masterdata) throws DataAccessException, BusinessException {
        masterdata.setHybridType(hybrid.getHybridType());
        masterdataRepository.save(masterdata);

        List<Lot> lots = lotRepository.findByHybridAndCampaignForMasterDataRecalculate(hybrid, campaign, masterdata.getMegaZone());

        List<Lot> lotsFilterNull = getLotFilterNull(lots);
        List<Lot> lotsFilterNotNull = getLotFilterNotNull(lots);

        for (Lot lot : lotsFilterNull) {
            processApplicationManager(lot, masterdata, lotMasterdata);
        }

        if (lotsFilterNotNull.size() > 0) {
            lotMasterdata.setOmitted(lotsFilterNotNull.size());
        }
        return lotMasterdata.getOmitted();
    }

    private void saveLotMasterdata(Campaign campaign, String fileName, ArrayList<LotMasterdata> lotMasterdataList, int lotsImported, int lotsOmitted, Hybrid hybrid, RowImportDTO<Masterdata> rowImportDTO, Masterdata masterdata) {
        LotMasterdata lotMasterdata = null;
        if (lotsImported == 0 && lotsOmitted == 0) {
            lotMasterdata = new LotMasterdata(masterdata, hybrid, campaign.getId(), lotsImported, lotsOmitted, campaign.getFilePath() + fileName, "prisma.hybrid.lot.notExists");
        } else {
            lotMasterdata = new LotMasterdata(masterdata, hybrid, campaign.getId(), lotsImported, lotsOmitted, campaign.getFilePath() + fileName);
        }

        lotMasterdataRepository.save(lotMasterdata);

        lotMasterdata.setCellsOmitted(rowImportDTO.getOmittedCells());

        lotMasterdataList.add(lotMasterdata);
    }

    private void processApplicationManager(Lot lot, Masterdata masterdata, LotMasterdata lotMasterdata) throws DataAccessException, BusinessException {
        lot.setTargetRwToDs(masterdata.getDsRw());
        lot.setHarvestRwToDs(lot.getTargetRwToDs());
        lot.setTargetDsToFng(masterdata.getFngDs());
        lot.setTargetKgBag(masterdata.getKgBls());
        lot.setTargetBagHa(masterdata.getUnHa());
        lot.setFlowHarvDays(masterdata.getFlowHarvDays());
        lot.setActualTnRwLot(lot.getTargetTnRwLot());
        lot.setActualTnDsLot(lot.getTargetTnDsLot());
        if (lot.getTargetDsToFng() != null && lot.getActualTnDsLot() != null) {
            lot.setEstimatedTnFngLot(lot.getActualTnDsLot() * lot.getTargetDsToFng());
        }
        lot.setActualWeightBagLot(lot.getTargetKgBag());
        lot.setGermoplasma(masterdata.getGermoplasma());
        lot.setClient(masterdata.getBrandCustomer());
        lot.setGranProgram(masterdata.getGranProgram());
        lot.setCertification(masterdata.getCertification());
        try {
            processManager.process(Constants.LOT_PROCESS_BEAN_ID, lot);
            lotMasterdata.addImported();
        } catch (ProcessWithErrorException ex) {
            log.debug("Lot omitted - " + ex.getMessage(), ex);
            lotMasterdata.addOmitted();
        }
    }

    private List<Lot> getLotFilterNotNull(List<Lot> lots) {
        return FluentIterable.from(lots).filter(new Predicate<Lot>() {
            @Override
            public boolean apply(@Nullable Lot lot) {
                return lot.getTargetRwToDs() != null && lot.getTargetDsToFng() != null
                        && lot.getTargetKgBag() != null && lot.getTargetBagHa() != null && lot.getFlowHarvDays() != null
                        && lot.getPlantFlowDays() != null;
            }
        }).toList();
    }

    private List<Lot> getLotFilterNull(List<Lot> lots) {
        return FluentIterable.from(lots).filter(new Predicate<Lot>() {
            @Override
            public boolean apply(@Nullable Lot lot) {
                return lot.getTargetRwToDs() == null && lot.getTargetDsToFng() == null
                        && lot.getTargetKgBag() == null && lot.getTargetBagHa() == null && lot.getFlowHarvDays() == null
                        && lot.getPlantFlowDays() == null;
            }
        }).toList();
    }


    private RowImportDTO<Masterdata> getMasterdataFromRow(Row rowMasterdata) {
        Masterdata masterdata = new Masterdata();
        List<CellOmittedDTO> cellOmittedDTOList = new ArrayList<CellOmittedDTO>();

        masterdata.setGranProgram(Utilities.getStringValue(rowMasterdata, Constants.ONE, Whitelist.basic(), cellOmittedDTOList));
        masterdata.setGermoplasma(Utilities.getStringValue(rowMasterdata, Constants.TWO, Whitelist.basic(), cellOmittedDTOList));

        masterdata.setProgram(masterdata.getGranProgram() + " " + masterdata.getGermoplasma());
        masterdata.setCertification(Utilities.getStringValue(rowMasterdata, Constants.FIVE, Whitelist.basic(), cellOmittedDTOList));
        masterdata.setDestination(Utilities.getStringValue(rowMasterdata, Constants.FOUR, Whitelist.basic(), cellOmittedDTOList));
        masterdata.setManufactureCode(Utilities.getStringValue(rowMasterdata, Constants.SIX, Whitelist.basic(), cellOmittedDTOList));
        masterdata.setFlowHarvDays(Utilities.getIntegerValue(rowMasterdata, Constants.THIRTY_FOUR, cellOmittedDTOList));
        masterdata.setRelationPlantGrooves(Utilities.getStringValue(rowMasterdata, Constants.THIRTEEN, Whitelist.basic(), cellOmittedDTOList));
        masterdata.setPercentageFemale(Utilities.getFloatValue(rowMasterdata, Constants.FOURTEEN, cellOmittedDTOList));
        masterdata.setTypeProgramUnit(Utilities.getStringValue(rowMasterdata, Constants.FIFTEEN, Whitelist.basic(), cellOmittedDTOList));
        masterdata.setProgramUnit(Utilities.getFloatValue(rowMasterdata, Constants.SIXTEEN, cellOmittedDTOList));
        masterdata.setTotalUnit(Utilities.getFloatValue(rowMasterdata, Constants.SIXTEEN, cellOmittedDTOList));
        masterdata.setAreaTotal(Utilities.getFloatValue(rowMasterdata, Constants.EIGHTEEN, cellOmittedDTOList));
        masterdata.setUnHa(Utilities.getFloatValue(rowMasterdata, Constants.SEVENTEEN, cellOmittedDTOList));
        masterdata.setKgRWHa(Utilities.getFloatValue(rowMasterdata, Constants.TWENTY_EIGHT, cellOmittedDTOList));
        masterdata.setKgDSHa(Utilities.getFloatValue(rowMasterdata, Constants.TWENTY_NINE, cellOmittedDTOList));
        masterdata.setKgFNGHa(Utilities.getFloatValue(rowMasterdata, Constants.THIRTY, cellOmittedDTOList));
        masterdata.setKgBls(Utilities.getFloatValue(rowMasterdata, Constants.THIRTY_ONE, cellOmittedDTOList));
        masterdata.setDsRw(Utilities.getFloatValue(rowMasterdata, Constants.THIRTY_TWO, cellOmittedDTOList));
        masterdata.setFngDs(Utilities.getFloatValue(rowMasterdata, Constants.THIRTY_THREE, cellOmittedDTOList));

        masterdata.setBagging(Utilities.getStringValue(rowMasterdata, Constants.THIRTY_SIX, Whitelist.basic(), cellOmittedDTOList));
        masterdata.setCommercialUnit(Utilities.getStringValue(rowMasterdata, Constants.TWENTY_FIVE, Whitelist.basic(), cellOmittedDTOList));

        masterdata.setMegaZone(Utilities.getStringValue(rowMasterdata, Constants.ELEVEN, Whitelist.basic(), cellOmittedDTOList));
        masterdata.setBrandCustomer(Utilities.getStringValue(rowMasterdata, Constants.THREE, Whitelist.basic(), cellOmittedDTOList));
        masterdata.setGdu50(Utilities.getFloatValue(rowMasterdata, Constants.THIRTY_FIVE, cellOmittedDTOList));


        RowImportDTO<Masterdata> rowImportDTO = new RowImportDTO<Masterdata>();
        rowImportDTO.setData(masterdata);
        rowImportDTO.setOmittedCells(cellOmittedDTOList);

        return rowImportDTO;
    }
}
