package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.repository.CampaignRepository;
import com.monsanto.prisma.core.repository.LotHistoryRepository;
import com.monsanto.prisma.core.repository.LotRepository;
import com.monsanto.prisma.core.repository.PayGrowerRepository;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.PayGrowerService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import com.monsanto.prisma.core.workflow.process.payGrower.PayGrowerProcess;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

/**
 * Created by PGSETT on 31/07/2014.
 */
@Service
public class PayGrowerServiceImpl implements PayGrowerService {

    private static Logger log = Logger.getLogger(Report2ServiceImpl.class);

    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;

    @Autowired
    private FileImportService fileImportService;

    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;

    @Autowired
    private PayGrowerProcess payGrowerProcess;
    @Autowired
    private LotHistoryRepository lotHistoryRepository;
    @Autowired
    private PayGrowerRepository payGrowerRepository;

    private String messageCampaignNotExits = "prisma.campaign.notExists";
    private String messageLotNotExist = "prisma.lot.notExists";
    private String messageErrorPayGrowerProcessRecalculate = "prisma.recalculate.error";
    private String messageLotExistInformation = "prisma.lot.withInformation";

    @Override
    public PayGrower importFile(Integer campaignId) throws BusinessException, IOException, InvalidFormatException, ParseException {
        Campaign campaign = campaignRepository.findById(campaignId);

        if (campaign == null) {
            throw new BusinessException(messageCampaignNotExits);
        }
        return processPayGrower(campaign);
    }

    private PayGrower processPayGrower(Campaign campaign) throws IOException, InvalidFormatException, BusinessException, ParseException {

        RowPayGrower rowPayGrower;
        InputStream inputStream;
        Workbook wb;
        Sheet sheet;
        String fieldLotCode;
        PayGrower payGrower = new PayGrower();

        inputStream = fileImportService.processFile(campaign.getFilePath(), Constants.PAY_GROWER);
        wb = WorkbookFactory.create(inputStream);
        sheet = wb.getSheetAt(0);

        for (int i = Constants.EIGHT; i <= sheet.getLastRowNum(); i++) {
            Row row = (Row) sheet.getRow(i);
            if (row == null) {
                break;
            }
            fieldLotCode = Utilities.getStringValue(row, Constants.ONE, Whitelist.basic());
            if (fieldLotCode != null) {
                rowPayGrower = new RowPayGrower();
                setDataNewLot(row, rowPayGrower);
                updateLotFromRowPayGrower(rowPayGrower, payGrower, campaign);
            }
        }

        payGrower.setCampaignId(campaign.getId());
        payGrower.setPathFile(campaign.getFilePath() + Constants.PAY_GROWER);
        payGrower.setDateProccess(new Date());
        payGrowerRepository.save(payGrower);

        fileImportService.copyProcessedFile(campaign.getFilePath(), Constants.PAY_GROWER);

        return payGrower;
    }

    private void updateLotFromRowPayGrower(RowPayGrower rowPayGrower, PayGrower payGrower, Campaign campaign) {
        try {
            if (rowPayGrower != null) {
                Lot lot = lotRepository.filterActiveLotByLotCodeAndCampaign(rowPayGrower.getLotCode(), campaign);
                if (lot != null) {
                    if (lot.getPlLot() != null && lot.getPlsLot() != null) {
                        payGrower.addLotOmitted(rowPayGrower.getLotCode(), messageLotExistInformation);
                    } else {
                        lot.setPlsLot(rowPayGrower.getPls());
                        lot.setPlLot(rowPayGrower.getPl());
                        recalculatePayGrower(lot);
                        lotRepository.save(lot);
                        lotHistoryRepository.save(new LotHistory(lot, "modify"));
                        payGrower.addLotModified();
                    }
                } else {
                    payGrower.addLotOmitted(rowPayGrower.getLotCode(), messageLotNotExist);
                }
            }
        } catch (ProcessWithErrorException e) {
            log.warn("Error in the pay grower process recalculate.", e);
            payGrower.addLotOmitted(rowPayGrower.getLotCode(), messageErrorPayGrowerProcessRecalculate);
        }
    }

    private void recalculatePayGrower(Lot lot) {
        payGrowerProcess.doProcess(lot);
    }

    private void setDataNewLot(Row row, RowPayGrower rowPayGrower) {
        rowPayGrower.setLotCode(Utilities.getStringValue(row, Constants.ONE, Whitelist.basic()));
        rowPayGrower.setPl(Utilities.getFloatValue(row, Constants.TWELVE));
        rowPayGrower.setPls(Utilities.getFloatValue(row, Constants.THIRTEEN));
    }

}
