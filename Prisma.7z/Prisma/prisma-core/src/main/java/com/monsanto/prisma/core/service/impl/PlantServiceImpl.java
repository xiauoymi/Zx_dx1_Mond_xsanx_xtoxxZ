package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Plant;
import com.monsanto.prisma.core.repository.PlantRepository;
import com.monsanto.prisma.core.service.PlantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by BSBUON on 5/15/2014.
 */
@Service
public class PlantServiceImpl implements PlantService {

    @Autowired
    @Qualifier("plantRepository")
    private PlantRepository plantRepository;

    @Override
    public Plant findByName(String name) {
        return plantRepository.findByName(name);
    }

    @Override
    public Plant findById(Integer id) {
        return plantRepository.findById(id);
    }

    @Override
    public List<Plant> findAll() {
        return (List<Plant>) plantRepository.findAll();
    }
}
