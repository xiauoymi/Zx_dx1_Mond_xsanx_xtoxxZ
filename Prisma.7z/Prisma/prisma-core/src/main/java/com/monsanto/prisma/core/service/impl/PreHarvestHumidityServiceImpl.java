package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.dto.LotHumidityDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.repository.*;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.PreHarvestHumidityService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 07/07/2014.
 */
@Service
@Transactional
public class PreHarvestHumidityServiceImpl implements PreHarvestHumidityService {

    private static final Logger LOG = Logger.getLogger(PreHarvestHumidityServiceImpl.class);

    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;

    @Autowired
    @Qualifier("humidityRangeRepository")
    private HumidityRangeRepository humidityRangeRepository;

    @Autowired
    @Qualifier("zoneRepository")
    private ZoneRepository zoneRepository;

    @Autowired
    private HybridRepository hybridRepository;

    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;

    @Autowired
    private LotHumidityRepository lotHumidityRepository;

    private static final String MESSAGE_CAMPAIGN_NOT_EXITS = "prisma.campaign.notExists";

    private static final String MESSAGE_HUMIDITY_RANGE_NOT_EXITS = "prisma.humidityRange.notExists";

    private static final String MESSAGE_ZONE_NOT_EXITS = "prisma.zone.notExists";

    private static final String MESSAGE_HYBRID_NOT_EXITS = "prisma.hybrid.notExists";

    private static final String MESSAGE_LOT_NOT_EXITS = "prisma.lot.notExists";

    private static final String MESSAGE_LOT_EXITS = "prisma.lot.withInformation";

    @Autowired
    private LotHistoryRepository lotHistoryRepository;


    @Autowired
    @Qualifier("preHarvestHumidityRepository")
    private PreHarvestHumidityRepository preHarvestHumidityRepository;

    @Autowired
    private FileImportService fileImportService;

    @Override
    public List<PreHarvestHumidity> findAll() throws DataAccessException {
        return preHarvestHumidityRepository.findAll();
    }

    @Override
    public PreHarvestHumidity findById(Integer id) throws DataAccessException {
        return preHarvestHumidityRepository.findById(id);
    }

    @Override
    public void update(PreHarvestHumidity humidityRange) throws DataAccessException {
        preHarvestHumidityRepository.save(humidityRange);
    }

    @Override
    public void delete(Integer id) throws DataAccessException {
        preHarvestHumidityRepository.delete(id);
    }


    @Override
    public PreHarvestHumidity refreshFromPreHarvest(Integer campaignId) throws BusinessException {
        Campaign campaign = campaignRepository.findById(campaignId);

        if (campaign == null) {
            LOG.error(MESSAGE_CAMPAIGN_NOT_EXITS);
            throw new BusinessException(MESSAGE_CAMPAIGN_NOT_EXITS);
        }

        InputStream inputStream = fileImportService.processFile(campaign.getFilePath(), Constants.HUMIDITY_IMPORT);

        return processPreHarvest(campaign, inputStream, Constants.HUMIDITY_IMPORT, false);
    }


    private PreHarvestHumidity processPreHarvest(Campaign campaign, InputStream inputStream, String fileName, Boolean importManual) throws BusinessException {
        try {
            List<LotHumidityDTO> omittedLotHumidityDTOs = new ArrayList<LotHumidityDTO>();

            int lotsProcessed = 0;

            Workbook wb = WorkbookFactory.create(inputStream);
            Sheet sheet = wb.getSheetAt(0);

            for (int i = Constants.ONE; i <= sheet.getLastRowNum(); i++) {
                Row rowPreHarvest = sheet.getRow(i);
                if (rowPreHarvest == null) {
                    break;
                }

                String fieldCode = Utilities.getStringValue(rowPreHarvest, Constants.THREE, Whitelist.basic());
                if (fieldCode == null) {
                    break;
                }

                LotHumidityDTO omittedLotHumidityDTO = processRowPreHarvest(rowPreHarvest, campaign, Jsoup.clean(fieldCode, Whitelist.basic()));
                if (omittedLotHumidityDTO != null) {
                    omittedLotHumidityDTOs.add(omittedLotHumidityDTO);
                }
                lotsProcessed++;
            }

            PreHarvestHumidity preHarvestHumidity = getPreHarvestHumidity(campaign, fileName, omittedLotHumidityDTOs, lotsProcessed);
            preHarvestHumidityRepository.save(preHarvestHumidity);

            if (!importManual) {
                fileImportService.copyProcessedFile(campaign.getFilePath(), fileName);
            }

            return preHarvestHumidity;
        } catch (InvalidFormatException e) {
            LOG.error("Error inesperado: InvalidFormatException " + e.getMessage());
            throw new BusinessException("Error inesperado: InvalidFormatException", e);
        } catch (IOException e) {
            LOG.error("Error inesperado: IOException " + e.getMessage());
            throw new BusinessException("Error inesperado: IOException", e);
        }
    }

    private PreHarvestHumidity getPreHarvestHumidity(Campaign campaign, String fileName, List<LotHumidityDTO> omittedLotHumidityDTOs, int lotsProcessed) {
        PreHarvestHumidity preHarvestHumidity = new PreHarvestHumidity();
        preHarvestHumidity.setCampaign(campaign.getId());
        preHarvestHumidity.setSourceHumidityFile(campaign.getFilePath() + fileName);
        preHarvestHumidity.setDateCreation(new Date());
        preHarvestHumidity.setImported(lotsProcessed - omittedLotHumidityDTOs.size());
        preHarvestHumidity.setOmitted(omittedLotHumidityDTOs.size());
        preHarvestHumidity.setLotHumidityDTOs(omittedLotHumidityDTOs);
        return preHarvestHumidity;
    }


    private LotHumidityDTO processRowPreHarvest(Row rowPreHarvest, Campaign campaign, String fieldCode) {
        LotHumidityDTO omittedLotHumidityDTO = null;
        Lot lot = lotRepository.filterActiveLotByLotCodeAndCampaign(fieldCode, campaign);
        if (lot != null) {
            omittedLotHumidityDTO = processLot(rowPreHarvest, lot, fieldCode);
        } else {
            omittedLotHumidityDTO = setLotHumidityOmitted(fieldCode, "-", "-", 0F, MESSAGE_LOT_NOT_EXITS);
        }

        return omittedLotHumidityDTO;
    }

    private LotHumidityDTO processLot(Row rowPreHarvest, Lot lot, String fieldCode) {
        LotHumidityDTO omittedLotHumidityDTO = validateLotHumidity(rowPreHarvest, lot, fieldCode);

        if (omittedLotHumidityDTO == null) {
            Date sampleDate = Utilities.getDateValue(rowPreHarvest, Constants.SHORT_ZERO);
            Float sampleHumidity = Utilities.getFloatValue(rowPreHarvest, Constants.SIX);
            LotHumidity lotHumidity = processRowLotHumidity(rowPreHarvest, lot);
            String zoneName = Utilities.getStringValue(rowPreHarvest, Constants.ONE, Whitelist.basic());
            String hybridName = Utilities.getStringValue(rowPreHarvest, Constants.TWO, Whitelist.basic());

            if (lot.getHarvestDateForHumidity() == null) {
                HumidityRange humidityRange = humidityRangeRepository.findByHybridZone(hybridName, zoneName);
                if ((humidityRange != null) && (sampleHumidity >= humidityRange.getHumidityMin() && sampleHumidity <= humidityRange.getHumidityMax())) {
                    lot.setHarvestDateForHumidity(sampleDate);
                }
            }
            //busco en lot_humidity la humedad con fecha mayor agrupada por lote.
            lotHumidity.setLot(lot);
            LotHumidity lotHumidityFromDB = lotHumidityRepository.findByLotHumidityByLotAndDate(lot.getId(), lotHumidity.getSampleDate());
            if (lotHumidityFromDB != null) {
                lotHumidity.setId(lotHumidityFromDB.getId());
                lotHumidity.setSampleDate(sampleDate);
            }
            lotHumidityRepository.save(lotHumidity);
            LotHumidity lotHum = lotHumidityRepository.findByLotMaxDate(lotHumidity.getLot().getId(), lot.getCampaign().getId());
            lot.setHumidity(lotHum.getHumidity());
            lot.setSampleDateHumidity(lotHumidity.getSampleDate());
            lotRepository.save(lot);
            LotHistory lotHistory = new LotHistory(lotHumidity.getLot(), "new");
            lotHistoryRepository.save(lotHistory);
        }

        return omittedLotHumidityDTO;
    }

    private LotHumidityDTO validateLotHumidity(Row rowPreHarvest, Lot lot, String fieldCode) {
        LotHumidityDTO omittedLotHumidityDTO = null;

        Date sampleDate = Utilities.getDateValue(rowPreHarvest, Constants.SHORT_ZERO);
        Float sampleHumidity = Utilities.getFloatValue(rowPreHarvest, Constants.SIX);

        if (lotHumidityRepository.findByLotDateHumidity(lot.getId(), sampleDate, sampleHumidity).size() != 0) {
            LotDTO lotDTO = new LotDTO(lot, MESSAGE_LOT_EXITS);
            omittedLotHumidityDTO = new LotHumidityDTO();
            omittedLotHumidityDTO.setLot(lotDTO);
            omittedLotHumidityDTO.setHumidity(sampleHumidity);
            omittedLotHumidityDTO.setSampleDate(sampleDate);
        } else {

            LotHumidity lotHumidity = processRowLotHumidity(rowPreHarvest, lot);
            String zoneName = Utilities.getStringValue(rowPreHarvest, Constants.ONE, Whitelist.basic());
            String hybridName = Utilities.getStringValue(rowPreHarvest, Constants.TWO, Whitelist.basic());

            if (lotHumidity.getLot().getEstablishment().getZone() == null) {
                omittedLotHumidityDTO = setLotHumidityOmitted(fieldCode, zoneName, hybridName, sampleHumidity, MESSAGE_ZONE_NOT_EXITS);
            } else if (lotHumidity.getLot().getHybrid() == null) {
                omittedLotHumidityDTO = setLotHumidityOmitted(fieldCode, zoneName, hybridName, sampleHumidity, MESSAGE_HYBRID_NOT_EXITS);
            } else if (lotHumidity.getHumidity() == null) {
                LotDTO lotDTO = new LotDTO(lot, MESSAGE_HUMIDITY_RANGE_NOT_EXITS);
                omittedLotHumidityDTO = new LotHumidityDTO(lotHumidity, lotDTO);
                omittedLotHumidityDTO.setHumidity(sampleHumidity);
            }
        }

        return omittedLotHumidityDTO;
    }

    private LotHumidityDTO setLotHumidityOmitted(String lotCode, String zone, String hybrid, Float humidity, String mensaje) {
        LotDTO lotDTO = new LotDTO();
        lotDTO.setLotCode(lotCode);
        lotDTO.setZoneCode(zone);
        lotDTO.setHybridName(hybrid);
        lotDTO.setCauses(mensaje);
        LotHumidityDTO lotHumidityDTO = new LotHumidityDTO();
        lotHumidityDTO.setHumidity(humidity);
        lotHumidityDTO.setLot(lotDTO);
        return lotHumidityDTO;
    }

    private LotHumidity processRowLotHumidity(Row rowPreHarvest, Lot lot) {
        LotHumidity lotHumidity = new LotHumidity();

        Date sampleDate = Utilities.getDateValue(rowPreHarvest, Constants.SHORT_ZERO);
        String zoneName = Utilities.getStringValue(rowPreHarvest, Constants.ONE, Whitelist.basic());
        String hybridName = Utilities.getStringValue(rowPreHarvest, Constants.TWO, Whitelist.basic());
        Float sampleHumidity = Utilities.getFloatValue(rowPreHarvest, Constants.SIX);

        lotHumidity.setSampleDate(sampleDate);
        lotHumidity.setHumidity(sampleHumidity);
        lotHumidity.setLot(lot);


        Zone zone = zoneRepository.findByCode(zoneName);
        Hybrid hybrid = hybridRepository.findByName(hybridName);
        if ((zone == null) || !(lot.getEstablishment() == null || lot.getEstablishment().getZone() == null || lot.getEstablishment().getZone().getId().equals(zone.getId()))) {
            lotHumidity.getLot().getEstablishment().setZone(null);
        }
        if ((hybrid == null) || (lot.getHybrid() == null) || (!lot.getHybrid().getId().equals(hybrid.getId()))) {
            lotHumidity.getLot().setHybrid(null);
        }

        return lotHumidity;
    }
}
