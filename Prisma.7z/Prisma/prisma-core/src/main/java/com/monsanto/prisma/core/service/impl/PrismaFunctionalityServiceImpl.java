package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.PrismaFunctionality;
import com.monsanto.prisma.core.repository.PrismaFunctionalityRepository;
import com.monsanto.prisma.core.service.PrismaFunctionalityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by EPESTE on 22/09/2014.
 */
@Service
public class PrismaFunctionalityServiceImpl implements PrismaFunctionalityService {

    @Autowired
    private PrismaFunctionalityRepository prismaFunctionalityRepository;

    @Override
    public List<PrismaFunctionality> findAll() {
        return (List<PrismaFunctionality>) getPrismaFunctionalityRepository().findAllOrderByFunctionalityAction();
    }

    public PrismaFunctionalityRepository getPrismaFunctionalityRepository() {
        return prismaFunctionalityRepository;
    }

}
