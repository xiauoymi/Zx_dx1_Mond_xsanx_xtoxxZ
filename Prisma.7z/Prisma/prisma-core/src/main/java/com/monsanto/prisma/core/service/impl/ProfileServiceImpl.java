package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.PrismaFunctionality;
import com.monsanto.prisma.core.domain.Profile;
import com.monsanto.prisma.core.domain.ProfilePrismaFunctionality;
import com.monsanto.prisma.core.dto.ProfileDTO;
import com.monsanto.prisma.core.repository.ProfilePrismaFunctionalityRepository;
import com.monsanto.prisma.core.repository.ProfileRepository;
import com.monsanto.prisma.core.service.ProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by EPESTE on 12/09/2014.
 */
@Service
public class ProfileServiceImpl implements ProfileService {

    @Autowired
    private ProfileRepository profileRepository;

    @Autowired
    private ProfilePrismaFunctionalityRepository profilePrismaFunctionalityRepository;

    @Override
    public List<Profile> findAll() {
        return (List<Profile>) profileRepository.findAll();
    }

    @Override
    public List<Profile> findByEnabled(Boolean enabled) {
        return profileRepository.findByEnabled(enabled);
    }

    @Override
    public Profile findById(Integer id) {
        return profileRepository.findProfileWithFunctionalityAction(id);
    }

    @Override
    public Profile update(ProfileDTO profileDTO) {
        Profile profile = new Profile(profileDTO);
        profile.setPrismaFunctionalityList(profileDTO.getFunctionalities());
        profile = profileRepository.save(profile);

        return profile;
    }

    @Override
    public Profile add(ProfileDTO profileDTO) {
        Profile profile = new Profile(profileDTO);
        profile = profileRepository.save(profile);
        profile.setPrismaFunctionalityList(profileDTO.getFunctionalities());
        profileRepository.save(profile);
        return profile;
    }

    @Override
    public void delete(Integer profileId) {
        Profile profile = profileRepository.findProfileWithFunctionalityAction(profileId);
        for (PrismaFunctionality prismaFunctionality: profile.getPrismaFunctionalityList()){
            profilePrismaFunctionalityRepository.delete(new ProfilePrismaFunctionality(profileId, prismaFunctionality.getId()));
        }

        profile.setPrismaFunctionalityList(null);
        profileRepository.delete(profile);

    }


}
