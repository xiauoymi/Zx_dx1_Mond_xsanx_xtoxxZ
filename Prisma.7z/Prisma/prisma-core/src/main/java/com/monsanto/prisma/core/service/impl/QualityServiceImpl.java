package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Campaign;
import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.domain.QualityFile;
import com.monsanto.prisma.core.dto.RowQualityFileDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.ParserRowException;
import com.monsanto.prisma.core.repository.CampaignRepository;
import com.monsanto.prisma.core.repository.LotRepository;
import com.monsanto.prisma.core.repository.TabQualityRepository;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.QualityService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import com.monsanto.prisma.core.workflow.process.quality.QualityProcess;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

/**
 * Created by EPESTE on 29/07/2014.
 */
@Service
public class QualityServiceImpl implements QualityService {
    private static Logger log = Logger.getLogger(QualityServiceImpl.class);
    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;
    @Autowired
    private FileImportService fileImportService;
    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;
    @Autowired
    private QualityProcess qualityProcess;
    @Autowired
    private TabQualityRepository tabQualityRepository;
    private String messageCampaignNotExits = "prisma.campaign.notExists";
    private String messageLotNotExists = "prisma.lot.notExists";
    private String messageLotWithThisInformation = "prisma.lot.withInformation";
    private String messageUnexpectedError = "prisma.lot.unexpectedError";
    private String messageErrorCell = "prisma.import.errorCell";

    @Override
    public QualityFile importFromFile(Integer campaignId) throws IOException, InvalidFormatException, BusinessException {
        QualityFile qualityFile;
        try {
            Campaign campaign = campaignRepository.findById(campaignId);
            if (campaign == null) {
                throw new BusinessException(messageCampaignNotExits);
            }
            qualityFile = readQualityFile(campaign);
        } catch (IOException e) {
            throw new BusinessException(messageUnexpectedError, e);
        } catch (InvalidFormatException e) {
            throw new BusinessException(messageUnexpectedError, e);
        }
        return qualityFile;
    }

    private QualityFile readQualityFile(Campaign campaign) throws BusinessException, IOException, InvalidFormatException {
        InputStream inputStream = fileImportService.processFile(campaign.getFilePath(), Constants.QUALITY_BULK_FILE);
        Workbook wb = WorkbookFactory.create(inputStream);
        Sheet sheet = wb.getSheetAt(0);
        QualityFile qualityFile = processQualityFile(sheet, campaign);
        qualityFile.setPathFile(campaign.getFilePath() + Constants.QUALITY_BULK_FILE);
        qualityFile.setDateProcess(new Date());
        qualityFile.setCampaignId(campaign.getId());
        tabQualityRepository.save(qualityFile);
        fileImportService.copyProcessedFile(campaign.getFilePath(), Constants.QUALITY_BULK_FILE);
        return qualityFile;
    }

    private QualityFile processQualityFile(Sheet sheet, Campaign campaign) {
        RowQualityFileDTO rowQualityFileDTO = null;
        QualityFile qualityFile = new QualityFile();
        String fieldLotCode = null;
        for (int i = Constants.ONE; i <= sheet.getLastRowNum(); i++) {
            try {
                Row row = (Row) sheet.getRow(i);
                if (row == null) {
                    updateLotWithNewQuality(rowQualityFileDTO, qualityFile, campaign);
                    break;
                }
                fieldLotCode = Utilities.getStringValue(row, Constants.TWO, Whitelist.basic());
                if (fieldLotCode == null) {
                    throw new ParserRowException(row, Constants.TWO);
                }
                if (isNewLot(fieldLotCode, rowQualityFileDTO)) {
                    updateLotWithNewQuality(rowQualityFileDTO, qualityFile, campaign);
                    rowQualityFileDTO = new RowQualityFileDTO();
                    rowQualityFileDTO.setLotCode(fieldLotCode);
                }
                getQualityDataFromRow(row, rowQualityFileDTO);
                if (i == sheet.getLastRowNum()) {
                    updateLotWithNewQuality(rowQualityFileDTO, qualityFile, campaign);
                }
            } catch (ParserRowException e) {
                qualityFile.addLotNotModified(fieldLotCode, messageErrorCell, createParserRowErrorMessage(e));
            } catch (Exception e) {
                qualityFile.addLotNotModified(fieldLotCode, messageErrorCell);
            }
        }
        return qualityFile;
    }

    private String createParserRowErrorMessage(ParserRowException e) {
        String colString = CellReference.convertNumToColString(e.getIndex());
        int rowNum = e.getRow().getRowNum() + 1;
        String cell = rowNum + "-" + colString;

        return cell;
    }

    private void updateLotWithNewQuality(RowQualityFileDTO rowQualityFileDTO, QualityFile qualityFile, Campaign campaign) {
        Lot lot = null;
        if (rowQualityFileDTO == null) {
            return;
        }
        lot = lotRepository.filterActiveLotByLotCodeAndCampaign(rowQualityFileDTO.getLotCode(), campaign);
        if (lot != null) {
            if (lot.getQualityDsToFng() != null && lot.getQualityWeightBag() != null) {
                qualityFile.addLotNotModified(lot.getLotCode(), messageLotWithThisInformation);
            } else {
                lot.setQualityDsToFng(rowQualityFileDTO.getQualityDsToFng() / Constants.ONE_HUNDRED);
                lot.setQualityWeightBag(rowQualityFileDTO.getQualityWeightBag());
                qualityProcess.doProcess(lot);
                lotRepository.save(lot);
                qualityFile.addLotModified();
            }
        } else {
            qualityFile.addLotNotModified(rowQualityFileDTO.getLotCode(), messageLotNotExists);
        }
    }

    private boolean isNewLot(String lotCode, RowQualityFileDTO rowQualityFileDTO) {
        if (rowQualityFileDTO == null) {
            return true;
        }
        if (lotCode == null) {
            return true;
        }
        return !rowQualityFileDTO.getLotCode().equals(lotCode);
    }

    private void getQualityDataFromRow(Row row, RowQualityFileDTO rowQualityFileDTO) throws ParserRowException {
        Float qualityDsToFng = Utilities.getFloatValue(row, Constants.TWENTY_EIGHT);
        if (qualityDsToFng == null) {
            throw new ParserRowException(row, Constants.TWENTY_NINE);
        }
        rowQualityFileDTO.setQualityDsToFng(qualityDsToFng + rowQualityFileDTO.getQualityDsToFng());
        Float kgBolPonde = Utilities.getFloatValue(row, Constants.THIRTY);
        if (kgBolPonde == null) {
            Float kgBolsaBase = Utilities.getFloatValue(row, Constants.TWENTY_NINE);
            if (kgBolsaBase == null) {
                throw new ParserRowException(row, Constants.TWENTY_NINE);
            }
            Float qualityWeightBag = rowQualityFileDTO.getQualityWeightBag() + kgBolsaBase;
            rowQualityFileDTO.setQualityWeightBag(qualityWeightBag);
        } else {
            kgBolPonde = rowQualityFileDTO.getQualityWeightBag() + kgBolPonde;
            rowQualityFileDTO.setQualityWeightBag(kgBolPonde);
        }
    }
}