package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Region;
import com.monsanto.prisma.core.repository.RegionRepository;
import com.monsanto.prisma.core.service.RegionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by BSBUON on 5/15/2014.
 */
@Service
public class RegionServiceImpl implements RegionService {

    @Autowired
    @Qualifier("regionRepository")
    private RegionRepository regionRepository;

    @Override
    public Region findByName(String name) {
        return regionRepository.findByName(name);
    }

    @Override
    public List<Region> findAll() {
        return (List<Region>) regionRepository.findAll();
    }
}
