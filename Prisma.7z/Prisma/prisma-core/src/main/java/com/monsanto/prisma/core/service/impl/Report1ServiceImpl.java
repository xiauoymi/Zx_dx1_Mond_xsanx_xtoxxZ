package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.repository.CampaignRepository;
import com.monsanto.prisma.core.repository.LotHistoryRepository;
import com.monsanto.prisma.core.repository.LotRepository;
import com.monsanto.prisma.core.repository.Report1Repository;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.ForecastService;
import com.monsanto.prisma.core.service.Report1Service;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import com.monsanto.prisma.core.workflow.process.harvest.HarvestKgRwProcess;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.joda.time.DateTime;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

/**
 * Created by EPESTE on 21/07/2014.
 */
@Service
public class Report1ServiceImpl implements Report1Service {

    private static Logger log = Logger.getLogger(Report1ServiceImpl.class);

    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;

    @Autowired
    private FileImportService fileImportService;

    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;

    @Autowired
    private HarvestKgRwProcess harvestKgRwProcess;

    @Autowired
    private ForecastService forecastService;

    private String messageCampaignNotExits = "prisma.campaign.notExists";

    private String messageLotNotExists = "prisma.lot.notExists";

    private String messageLotKgRwLot = "prisma.lot.kgRwLot";

    private String messageLotNotHarvested = "prisma.lot.notHarvested";

    private String messageLotTrucksPending = "prisma.trucks.pending";

    private String messageErrorHarvestKgRwLotRecalculate = "prisma.recalculate.error";
    private String messageErrorException = "prisma.lot.unexpectedError";
    @Autowired
    private LotHistoryRepository lotHistoryRepository;

    @Autowired
    private Report1Repository report1Repository;

    private static final String RECEPTION_PLANT_MEU = "MEU";
    private static final String RECEPTION_PLANT_PP = "PP";

    private Integer countTrucks = 0;

    @Override
    public Report1 importFile(Integer campaignId) throws BusinessException, IOException, InvalidFormatException, ParseException {
        Campaign campaign = campaignRepository.findById(campaignId);

        if (campaign == null) {
            throw new BusinessException(messageCampaignNotExits);
        }
        Report1 report1;
        try {
            report1 = processReporte1(campaign);
        } catch (Exception e) {
            throw new BusinessException(messageErrorException);
        }
        return report1;
    }

    private Report1 processReporte1(Campaign campaign) throws IOException, InvalidFormatException, BusinessException, ParseException {
        RowReport1 rowReport1 = null;
        InputStream inputStream;
        Workbook wb;
        Sheet sheet;
        String fieldLotCode;
        Report1 report1 = new Report1();

        inputStream = fileImportService.processFile(campaign.getFilePath(), Constants.REPORT_1);
        wb = WorkbookFactory.create(inputStream);
        sheet = wb.getSheetAt(Constants.INT_ZERO);

        for (int i = Constants.FIVE; i <= sheet.getLastRowNum(); i++) {
            Row row = (Row) sheet.getRow(i);

            if (row == null) {
                updateLotFromRowReport1(rowReport1, report1, campaign);
                break;
            }

            fieldLotCode = Utilities.getStringValue(row, Constants.TWO, Whitelist.basic());
            if (fieldLotCode != null) {
                if (isNewLot(row, rowReport1)) {
                    countTrucks = 0;
                    updateLotFromRowReport1(rowReport1, report1, campaign);
                    rowReport1 = new RowReport1();
                    setDataNewLot(row, rowReport1);
                }
                getDataFromRow(row, rowReport1);
                if (i == sheet.getLastRowNum()) {
                    updateLotFromRowReport1(rowReport1, report1, campaign);
                }
            }
        }

        report1.setCampaignId(campaign.getId());
        report1.setPathFile(campaign.getFilePath() + Constants.REPORT_1);
        report1.setDateProccess(new Date());
        report1Repository.save(report1);

        fileImportService.copyProcessedFile(campaign.getFilePath(), Constants.REPORT_1);

        return report1;
    }

    private void updateLotFromRowReport1(RowReport1 rowReport1, Report1 report1, Campaign campaign) {
        try {
            if (rowReport1 != null) {
                if (rowReport1.getIsLotToProcess()) {
                    Lot lot = lotRepository.filterActiveLotByLotCodeAndCampaign(rowReport1.getLotCode(), campaign);
                    if (lot != null) {
                        if (lot.getHarvestKgRWLot() == null && lot.isHarvested()) {
                            updateLotWhenIsHarvested(rowReport1, lot);
                            report1.addLotModified();
                        } else {
                            if (lot.getHarvestKgRWLot() != null) {
                                report1.addLotOmitted(rowReport1.getLotCode(), messageLotKgRwLot);
                            } else if (!lot.isHarvested()) {
                                report1.addLotOmitted(rowReport1.getLotCode(), messageLotNotHarvested);
                            }
                        }
                    } else {
                        report1.addLotOmitted(rowReport1.getLotCode(), messageLotNotExists);
                    }
                } else {
                    report1.addLotOmitted(rowReport1.getLotCode(), messageLotTrucksPending);
                }
            }
        } catch (ProcessWithErrorException e) {
            report1.addLotOmitted(rowReport1.getLotCode(), messageErrorHarvestKgRwLotRecalculate);
        }
    }

    private void updateLotWhenIsHarvested(RowReport1 rowReport1, Lot lot) {
        lot.setHarvestKgRWLot(rowReport1.getHarvestKgRwLot());
        lot.setTrucks(rowReport1.getTrucks());
        lot.setWeightAverageTruck(rowReport1.getHarvestKgRwLot() / rowReport1.getTrucks());
        lot.setRealRwReceiptDate(rowReport1.getRealRwReceiptDate());
        Forecast forecast = forecastService.findByCampaignId(lot.getCampaign().getId());
        DateTime dateTime = new DateTime(lot.getRealRwReceiptDate());
        lot.setEstimatedDsDate(dateTime.plusDays(forecast.getDaysDs()).toDate());
        if (rowReport1.getCenter() == 1086) {
            lot.setReceptionPlant(RECEPTION_PLANT_MEU);
        } else {
            lot.setReceptionPlant(RECEPTION_PLANT_PP);
        }
        recalculateHarvestKgRwLot(lot);
        lotRepository.save(lot);
        lotHistoryRepository.save(new LotHistory(lot, "modify"));
    }

    private void setDataNewLot(Row row, RowReport1 rowReport1) {
        rowReport1.setLotCode(Utilities.getStringValue(row, Constants.TWO, Whitelist.basic()));
        rowReport1.setCenter(Utilities.getIntegerValue(row, Constants.TWENTY_EIGHT));
        String lastTruck = Utilities.getStringValue(row, Constants.NINE, Whitelist.basic());
        String endLot = Utilities.getStringValue(row, Constants.TEN, Whitelist.basic());
        if (lastTruck != null){
            rowReport1.setLastTruck(lastTruck);
        }

        if (endLot != null) {
            rowReport1.setEndLot(endLot);
        }
    }

    private boolean isNewLot(Row row, RowReport1 rowReport1) {
        String fieldLotCode = Utilities.getStringValue(row, Constants.TWO, Whitelist.basic());

        if (rowReport1 == null) {
            return true;
        }

        if (rowReport1.getLotCode().equals(fieldLotCode)) {
            return false;
        }

        return true;
    }

    private void getDataFromRow(Row row, RowReport1 rowReport1) throws ParseException {
        String lastTruck = Utilities.getStringValue(row, Constants.NINE, Whitelist.basic());
        String endLot = Utilities.getStringValue(row, Constants.TEN, Whitelist.basic());
        if (lastTruck != null){
            rowReport1.setLastTruck(lastTruck);
        }

        if (endLot != null) {
            rowReport1.setEndLot(endLot);
        }

        Integer trucks = Utilities.getIntegerValue(row, Constants.FOUR);
        if (trucks != null) {
            rowReport1.setTrucks(countTrucks++);
        }else{
            rowReport1.setTrucks(countTrucks);
        }

        if (lastTruck != null && lastTruck.equals(Constants.REPORT_1_END_PROCESS_LOT)) {
            rowReport1.setRealRwReceiptDate(Utilities.getDateValue(row, Constants.SEVENTEEN));
        }
        Float harvestKgRwLot = Utilities.getFloatValue(row, Constants.EIGHT);
        rowReport1.setHarvestKgRwLot(rowReport1.getHarvestKgRwLot() + harvestKgRwLot);
    }

    private void recalculateHarvestKgRwLot(Lot lot) {
        getHarvestKgRwProcess().doProcess(lot);
    }

    public void setCampaignRepository(CampaignRepository campaignRepository) {
        this.campaignRepository = campaignRepository;
    }

    public void setLotRepository(LotRepository lotRepository) {
        this.lotRepository = lotRepository;
    }

    public void setFileImportService(FileImportService fileImportService) {
        this.fileImportService = fileImportService;
    }

    public HarvestKgRwProcess getHarvestKgRwProcess() {
        return harvestKgRwProcess;
    }

    public void setHarvestKgRwProcess(HarvestKgRwProcess harvestKgRwProcess) {
        this.harvestKgRwProcess = harvestKgRwProcess;
    }

    public void setLotHistoryRepository(LotHistoryRepository lotHistoryRepository) {
        this.lotHistoryRepository = lotHistoryRepository;
    }

    public void setReport1Repository(Report1Repository report1Repository) {
        this.report1Repository = report1Repository;
    }
}
