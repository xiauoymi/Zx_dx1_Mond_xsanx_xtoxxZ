package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.repository.CampaignRepository;
import com.monsanto.prisma.core.repository.LotHistoryRepository;
import com.monsanto.prisma.core.repository.LotRepository;
import com.monsanto.prisma.core.repository.Report2Repository;
import com.monsanto.prisma.core.service.FileImportService;
import com.monsanto.prisma.core.service.Report2Service;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import com.monsanto.prisma.core.workflow.process.husking.HuskingProcess;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.jsoup.safety.Whitelist;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.text.ParseException;
import java.util.Date;

/**
 * Created by PGSETT on 28/07/2014.
 */
@Service
public class Report2ServiceImpl implements Report2Service {
    private static Logger log = Logger.getLogger(Report2ServiceImpl.class);

    @Autowired
    @Qualifier("campaignRepository")
    private CampaignRepository campaignRepository;

    @Autowired
    private FileImportService fileImportService;

    @Autowired
    @Qualifier("lotRepository")
    private LotRepository lotRepository;

    @Autowired
    private HuskingProcess huskingProcess;
    private String messageCampaignNotExits = "prisma.campaign.notExists";
    private String messageLotNotExists = "prisma.lot.notExists";
    private String messageErrorHuskingProcessRecalculate = "prisma.recalculate.error";
    private String messageLotExistInformation = "prisma.lot.withInformation";

    private String messageErrorException = "prisma.lot.unexpectedError";

    @Autowired
    private LotHistoryRepository lotHistoryRepository;

    @Autowired
    private Report2Repository report2Repository;


    @Override
    public Report2 importFile(Integer campaignId) throws BusinessException, IOException, InvalidFormatException, ParseException {
        Campaign campaign = campaignRepository.findById(campaignId);

        if (campaign == null) {
            throw new BusinessException(messageCampaignNotExits);
        }
        Report2 report2;
        try {
            report2 = processReporte2(campaign);
        } catch (Exception e) {
            throw new BusinessException(messageErrorException);
        }
        return report2;
    }

    private Report2 processReporte2(Campaign campaign) throws IOException, InvalidFormatException, BusinessException, ParseException {
        RowReport2 rowReport2 = null;
        InputStream inputStream;
        Workbook wb;
        Sheet sheet;
        String fieldLotCode;
        Report2 report2 = new Report2();

        inputStream = fileImportService.processFile(campaign.getFilePath(), Constants.REPORT_2);
        wb = WorkbookFactory.create(inputStream);
        sheet = wb.getSheetAt(0);
        Date maxDate = null;
        int countEmptyRow = 0;
        for (int i = Constants.FIVE; i <= sheet.getLastRowNum(); i++) {
            Row row = (Row) sheet.getRow(i);
            if (row == null) {
                updateLotFromRowReport2(rowReport2, report2, campaign);
                countEmptyRow++;
                if (countEmptyRow > 1) {
                    break;
                }
            } else {
                fieldLotCode = Utilities.getStringValue(row, Constants.FIVE, Whitelist.basic());
                String subTotalField = Utilities.getStringValue(row, Constants.ONE, Whitelist.basic());

                if (fieldLotCode != null && subTotalField == null) {
                    if (isNewLot(row, rowReport2)) {
                        updateLotFromRowReport2(rowReport2, report2, campaign);
                        rowReport2 = new RowReport2();
                        setDataNewLot(row, rowReport2);
                        maxDate = null;
                    }

                    maxDate = getDataFromRow(row, rowReport2, maxDate);
                    rowReport2.setRealDsDate(maxDate);
                }
                if (i == sheet.getLastRowNum()) {
                    updateLotFromRowReport2(rowReport2, report2, campaign);
                }
            }
        }

        report2.setCampaignId(campaign.getId());
        report2.setPathFile(campaign.getFilePath() + Constants.REPORT_2);
        report2.setDateProccess(new Date());
        report2Repository.save(report2);

        fileImportService.copyProcessedFile(campaign.getFilePath(), Constants.REPORT_2);

        return report2;
    }

    private void updateLotFromRowReport2(RowReport2 rowReport2, Report2 report2, Campaign campaign) {
        try {
            if (rowReport2 != null) {
                if (rowReport2.getIsLotToProcess()) {
                    Lot lot = lotRepository.filterActiveLotByLotCodeAndCampaign(rowReport2.getLotCode(), campaign);
                    if (lot != null) {
                        if (lot.getHuskingKgDsLot() != null && lot.getHuskingKgDsLot().equals(rowReport2.getHuskingKgDsLot()) && lot.getWarehouseUnit() != null && lot.getWarehouseUnit().equals(rowReport2.getWarehouseUnitName())) {
                            report2.addLotOmitted(rowReport2.getLotCode(), messageLotExistInformation);
                        } else {
                            if (lot.getHuskingKgDsLot() == null) {
                                lot.setHuskingKgDsLot(rowReport2.getHuskingKgDsLot());
                                lot.setWarehouseUnit(rowReport2.getWarehouseUnitName());
                                lot.setActualKgDsBalance(lot.getHuskingKgDsLot());
                                lot.setActualKgDsLot(lot.getHuskingKgDsLot());
                                lot.setRealDsDate(rowReport2.getRealDsDate());
                            }
                            recalculateHuskingProcess(lot);
                            lotRepository.save(lot);
                            lotHistoryRepository.save(new LotHistory(lot, "modify"));
                            report2.addLotModified();
                        }
                    } else {
                        report2.addLotOmitted(rowReport2.getLotCode(), messageLotNotExists);
                    }
                }
            }
        } catch (ProcessWithErrorException e) {
            log.warn("Error in the husking process recalculate.", e);
            report2.addLotOmitted(rowReport2.getLotCode(), messageErrorHuskingProcessRecalculate);
        }
    }

    private void setDataNewLot(Row row, RowReport2 rowReport2) {
        rowReport2.setLotCode(Utilities.getStringValue(row, Constants.FIVE, Whitelist.basic()));
        rowReport2.setWarehouseUnitName(Utilities.getStringValue(row, Constants.FOURTEEN, Whitelist.basic()));
        String endLot = Utilities.getStringValue(row, Constants.FIFTEEN, Whitelist.basic());
        if (endLot != null && endLot.equals(Constants.REPORT_1_END_PROCESS_LOT)) {
            rowReport2.setIsLotToProcess(Boolean.TRUE);
        }
    }

    private boolean isNewLot(Row row, RowReport2 rowReport2) {
        String fieldLotCode = Utilities.getStringValue(row, Constants.FIVE, Whitelist.basic());

        if (rowReport2 == null) {
            return true;
        }

        if (rowReport2.getLotCode().equals(fieldLotCode)) {
            return false;
        }

        return true;
    }

    private Date getDataFromRow(Row row, RowReport2 rowReport2, Date maxDate) throws ParseException {
        String endLot = Utilities.getStringValue(row, Constants.FIFTEEN, Whitelist.basic());
        if (endLot != null && endLot.equals(Constants.REPORT_1_END_PROCESS_LOT)) {
            rowReport2.setIsLotToProcess(Boolean.TRUE);
        }
        rowReport2.setLotCode(Utilities.getStringValue(row, Constants.FIVE, Whitelist.basic()));
        rowReport2.setWarehouseUnitName(Utilities.getStringValue(row, Constants.FOURTEEN, Whitelist.basic()));
        rowReport2.setHuskingKgDsLot(rowReport2.getHuskingKgDsLot() + Utilities.parseStringToFloat(Utilities.getStringValue(row, Constants.SEVEN, Whitelist.basic())));
        rowReport2.setRealDsDate(Utilities.getDateValue(row, Constants.ELEVEN));
        if (maxDate != null && rowReport2.getRealDsDate().after(maxDate)) {
            maxDate = rowReport2.getRealDsDate();
        } else if (maxDate == null) {
            maxDate = rowReport2.getRealDsDate();
        }
        return maxDate;
    }

    private void recalculateHuskingProcess(Lot lot) {
        getHuskingProcess().doProcess(lot);
    }

    public HuskingProcess getHuskingProcess() {
        return huskingProcess;
    }

    public void setHuskingProcess(HuskingProcess huskingProcess) {
        this.huskingProcess = huskingProcess;
    }
}
