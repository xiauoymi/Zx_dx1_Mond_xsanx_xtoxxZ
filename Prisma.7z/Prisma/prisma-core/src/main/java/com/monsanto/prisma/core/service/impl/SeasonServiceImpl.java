package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Country;
import com.monsanto.prisma.core.domain.Crop;
import com.monsanto.prisma.core.domain.Season;
import com.monsanto.prisma.core.repository.SeasonRepository;
import com.monsanto.prisma.core.service.SeasonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * Created by BSBUON on 5/21/2014.
 */
@Service
public class SeasonServiceImpl implements SeasonService {

    @Qualifier("seasonRepository")
    @Autowired
    private SeasonRepository seasonRepository;

    @Override
    public Season findByCropAndCountry(Crop crop, Country country) {
        return seasonRepository.findByCropAndCountry(crop, country);
    }
}
