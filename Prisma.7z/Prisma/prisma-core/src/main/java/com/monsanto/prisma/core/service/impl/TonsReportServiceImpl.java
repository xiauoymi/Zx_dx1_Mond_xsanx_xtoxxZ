package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.dto.ReceiveTonsDTO;
import com.monsanto.prisma.core.dto.TonsToHostDTO;
import com.monsanto.prisma.core.repository.TonsReportRepository;
import com.monsanto.prisma.core.service.TonsReportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * Created by EPESTE on 25/09/2014.
 */
@Service
public class TonsReportServiceImpl implements TonsReportService {

    @Autowired
    private TonsReportRepository tonsReportRepository;


    @Override
    public List<ReceiveTonsDTO> findReceiveTons(Integer campaignId, String field, String value, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.findReceiveTons(campaignId, field, value, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<ReceiveTonsDTO> findWeeksReceivingTons(Integer campaignId, String field, String value, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.findWeeksReceivingTons(campaignId, field, value, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<ReceiveTonsDTO> findReceivingTonsByZone(Integer campaignId, Integer zoneId, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.findReceivingTonsByZone(campaignId, zoneId, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<ReceiveTonsDTO> findWeeksReceivingTonsByZone(Integer campaignId, Integer zoneId, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.findWeeksReceivingTonsByZone(campaignId, zoneId, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<ReceiveTonsDTO> findReceivingTonsByHybrid(Integer campaignId, Integer hybridId, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.findReceivingTonsByHybrid(campaignId, hybridId, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<ReceiveTonsDTO> findWeeksReceivingTonsByHybrid(Integer campaignId, Integer hybridId, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.findWeeksReceivingTonsByHybrid(campaignId, hybridId, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<TonsToHostDTO> filterTonsToHostReport(Integer campaignId, String field, String value, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.filterTonsToHostReport(campaignId, field, value, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<TonsToHostDTO> filterWeekTonsToHostReport(Integer campaignId, String field, String value, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.filterWeekTonsToHostReport(campaignId, field, value, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<TonsToHostDTO> filterTonsToHostReportByZone(Integer campaignId, Integer zoneId, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.filterTonsToHostReportByZone(campaignId, zoneId, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<TonsToHostDTO> filterWeekTonsToHostReportByZone(Integer campaignId, Integer zoneId, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.filterWeekTonsToHostReportByZone(campaignId, zoneId, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<TonsToHostDTO> filterTonsToHostReportByHybrid(Integer campaignId, Integer hybridId, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.filterTonsToHostReportByHybrid(campaignId, hybridId, harvestDateFrom, harvestDateTo);
    }

    @Override
    public List<TonsToHostDTO> filterWeekTonsToHostReportByHybrid(Integer campaignId, Integer hybridId, Date harvestDateFrom, Date harvestDateTo) {
        return tonsReportRepository.filterWeekTonsToHostReportByHybrid(campaignId, hybridId, harvestDateFrom, harvestDateTo);
    }
}
