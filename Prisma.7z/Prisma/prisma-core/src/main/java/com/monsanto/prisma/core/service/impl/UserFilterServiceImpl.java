package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.domain.UserFilter;
import com.monsanto.prisma.core.repository.UserFilterRepository;
import com.monsanto.prisma.core.service.FilterService;
import com.monsanto.prisma.core.service.UserFilterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created by epeste on 29/10/2014.
 */
@Service
public class UserFilterServiceImpl implements UserFilterService {
    @Autowired
    private UserFilterRepository userFilterRepository;

    @Autowired
    private FilterService filterService;

    @Override
    public UserFilter save(UserFilter userFilter) {
        userFilter = userFilterRepository.save(userFilter);
        filterService.save(userFilter);
        return userFilter;
    }

    @Override
    public List<UserFilter> findAllByUser(User user) {
        return userFilterRepository.findByUser(user);
    }

    @Override
    public UserFilter findByUserAndId(User user, Integer id) {
        return userFilterRepository.findByUserAndId(user, id);
    }

    @Override
    public UserFilter delete(Integer userFilterId) {
        UserFilter userFilter = userFilterRepository.findOne(userFilterId);
        userFilterRepository.delete(userFilter);
        return userFilter;
    }
}
