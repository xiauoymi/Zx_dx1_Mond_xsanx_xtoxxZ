package com.monsanto.prisma.core.service.impl;

import com.monsanto.prisma.core.domain.Profile;
import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.domain.UserProfile;
import com.monsanto.prisma.core.domain.UserProfilePk;
import com.monsanto.prisma.core.dto.UserDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.UserNotFoundException;
import com.monsanto.prisma.core.repository.UserProfileRepository;
import com.monsanto.prisma.core.repository.UserRepository;
import com.monsanto.prisma.core.service.ProfileService;
import com.monsanto.prisma.core.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    @Qualifier("userRepository")
    private UserRepository userRepository;

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private ProfileService profileService;

    @Override
    public List<User> findAll() {
        return (List<User>) userRepository.findAll();
    }

    @Override
    public User update(UserDTO userDTO) throws BusinessException {
        List<Profile> profiles = new ArrayList<Profile>();

        User user = userRepository.findOne(userDTO.getId());
        user.setUserName(userDTO.getUserName());
        user.setFullName(userDTO.getFullName());
        user.setEnabled(userDTO.getEnabled());

        for (Profile profileUser : userDTO.getProfiles()){
            Profile profile = profileService.findById(profileUser.getId());
            profiles.add(profile);
        }
        user.setProfiles(profiles);
        user.setRegions(userDTO.getRegions());

        try {
            user = userRepository.save(user);
        } catch (DataIntegrityViolationException ex) {
            throw new BusinessException(ex);
        }

        return user;
    }

    @Override
    public User newUser(UserDTO userDTO) throws BusinessException {
        User user = new User(userDTO);
        try {
            user = userRepository.save(user);
        } catch (DataAccessException ex) {
            throw new BusinessException(ex);
        }

        user.setProfiles(userDTO.getProfiles());
        user.setRegions(userDTO.getRegions());
        user = userRepository.save(user);

        return user;
    }

    @Override
    public User delete(Integer id) throws UserNotFoundException {
        User user = userRepository.findOne(new Long(id));
        if (user == null) {
            throw new UserNotFoundException();
        }
        for (Profile profile : user.getProfiles()) {
            UserProfilePk userProfilePk = new UserProfilePk(id, profile.getId());
            UserProfile userProfile = userProfileRepository.findOne(userProfilePk);
            userProfileRepository.delete(userProfile);
        }
        user.setProfiles(null);

        userRepository.delete(user);

        return user;
    }

    @Override
    public User findByUserName(String userName) throws UserNotFoundException {
        if (userName == null || userName.isEmpty()) {
            throw new UserNotFoundException();
        }
        return userRepository.findByUserName(userName.toLowerCase());
    }

    @Override
    public List<SimpleGrantedAuthority> findAuthoritiesByUserName(String username) {
        List<SimpleGrantedAuthority> grantedAuthorities = new ArrayList<SimpleGrantedAuthority>();
        List<String> authorities = userRepository.findAuthoritiesByUserName(username);

        for (String authority : authorities) {
            SimpleGrantedAuthority simpleGrantedAuthority = new SimpleGrantedAuthority(authority);
            grantedAuthorities.add(simpleGrantedAuthority);
        }

        return grantedAuthorities;

    }
}
