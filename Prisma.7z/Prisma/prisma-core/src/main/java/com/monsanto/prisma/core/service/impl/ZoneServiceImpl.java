package com.monsanto.prisma.core.service.impl;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.Zone;
import com.monsanto.prisma.core.dto.ZoneDTO;
import com.monsanto.prisma.core.repository.ZoneRepository;
import com.monsanto.prisma.core.service.ZoneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Created by EPESTE on 19/05/2014.
 */
@Service
public class ZoneServiceImpl implements ZoneService {


    @Autowired
    @Qualifier("zoneRepository")
    private ZoneRepository zoneRepository;

    @Override
    public Zone findById(Integer zoneId) {
        return zoneRepository.findOne(zoneId);
    }

    @Override
    public Zone findByCode(String code) {
        return zoneRepository.findByCode(code);
    }

    @Override
    public List<Zone> findAll() {
        return (List<Zone>) zoneRepository.findAll();
    }

    @Override
    public List<ZoneDTO> findByCampaign(Integer campaignId) {
        List<Object[]> zones = zoneRepository.findByCampaign(campaignId);

        List<ZoneDTO> zonesList = Lists.transform(zones, new Function<Object[], ZoneDTO>() {
            @Nullable
            @Override
            public ZoneDTO apply(@Nullable Object[] object) {
                return new ZoneDTO(object);
            }
        });
        return zonesList;
    }
}
