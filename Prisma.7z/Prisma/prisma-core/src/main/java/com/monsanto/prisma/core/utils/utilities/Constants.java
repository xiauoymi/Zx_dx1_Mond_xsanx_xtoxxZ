package com.monsanto.prisma.core.utils.utilities;

/**
 * Created by PGSETT on 04/06/2014.
 */
public abstract class Constants {

    public static final String LOT_PROCESS_BEAN_ID = "lotWorkFlow";
    public static final String TARGET_PROCESS_BEAN_ID = "targetWorkFlow";
    public static final String ESTIMATE_PROCESS_BEAN_ID = "estimateWorkFlow";

    public static final String REAL_PLANTING_DATE_PROCESS_BEAN_ID = "realPlantingDateWorkFlow";
    public static final String FLOWERING_DATE_PROCESS_BEAN_ID = "floweringDateWorkFlow";
    public static final String FLOWERING_HARVEST_DAY_PROCESS_BEAN_ID = "flowHarvDaysWorkFlow";
    public static final String ESTIMATE_FLOWERING_DATE_PROCESS_BEAN_ID = "estimatedFloweringDateWorkFlow";
    public static final String REAL_HARVEST_DATE_PROCESS_BEAN_ID = "realHarvestDateWorkFlow";
    public static final String HARVEST_KG_RW_PROCESS_BEAN_ID = "harvestKgRwWorkFlow";
    public static final String HARVEST_RW_TO_DS_PROCESS_BEAN_ID = "harvestRwToDsWorkFlow";
    public static final String QUALITY_PROCESS_BEAN_ID = "qualityWorkFlow";
    public static final String HUSKING_PROCESS_BEAN_ID = "huskingWorkFlow";

    public static final String LOT_HISTORY_NEW = "new";
    public static final String LOT_HISTORY_UPDATE = "update";
    public static final String LOT_HISTORY_DELETE = "delete";

    public static final Integer NUMBER_MIL = 1000;
    public static final Float ZERO = 0F;

    public static final short SHORT_ZERO = 0;
    public static final int INT_ZERO = 0;
    public static final int ONE = 1;
    public static final int TWO = 2;
    public static final int THREE = 3;
    public static final int FOUR = 4;
    public static final int FIVE = 5;
    public static final int SIX = 6;
    public static final int SEVEN = 7;
    public static final int EIGHT = 8;
    public static final int NINE = 9;
    public static final int TEN = 10;
    public static final int ELEVEN = 11;
    public static final int TWELVE = 12;
    public static final int THIRTEEN = 13;
    public static final int FOURTEEN = 14;
    public static final int FIFTEEN = 15;
    public static final int SIXTEEN = 16;
    public static final int SEVENTEEN = 17;
    public static final int EIGHTEEN = 18;
    public static final int NINETEEN = 19;
    public static final int TWENTY = 20;
    public static final int TWENTY_ONE = 21;
    public static final int TWENTY_TWO = 22;
    public static final int TWENTY_THREE = 23;
    public static final int TWENTY_FOUR = 24;
    public static final int TWENTY_FIVE = 25;
    public static final int TWENTY_SIX = 26;
    public static final int TWENTY_SEVEN = 27;
    public static final int TWENTY_EIGHT = 28;
    public static final int TWENTY_NINE = 29;
    public static final int THIRTY = 30;
    public static final int THIRTY_ONE = 31;
    public static final int THIRTY_TWO = 32;
    public static final int THIRTY_THREE = 33;
    public static final int THIRTY_FOUR = 34;
    public static final int THIRTY_FIVE = 35;
    public static final int THIRTY_SIX = 36;
    public static final int THIRTY_SEVEN = 37;
    public static final int THIRTY_EIGHT = 38;
    public static final int THIRTY_NINE = 39;
    public static final int FORTY = 40;
    public static final int FORTY_ONE = 41;
    public static final int FORTY_TWO = 42;
    public static final int FORTY_TRHEE = 43;
    public static final int FORTY_FOUR = 44;
    public static final int FORTY_FIVE = 45;
    public static final int FORTY_SIX = 46;
    public static final int FORTY_SEVEN = 47;
    public static final int FORTY_EIGHT = 48;
    public static final int FORTY_NINE = 49;
    public static final int FIFTY = 50;
    public static final int FIFTY_ONE = 51;
    public static final int FIFTY_TWO = 53;
    public static final int FIFTY_THREE = 54;
    public static final int ONE_HUNDRED = 100;
    public static final int FIVE_INT = 5;

    public static final int ID_TAB_ONE = 1;
    public static final int ID_TAB_TWO = 2;
    public static final int ID_TAB_THREE = 3;
    public static final int ID_TAB_FOUR = 4;
    public static final int ID_TAB_FIVE = 5;
    public static final int ID_TAB_SIX = 6;
    public static final int ID_TAB_SEVEN = 7;

    public static final String REPORT_1_END_PROCESS_LOT = "X";
    public static final String REPORT_1 = "REPORTE1.xlsx";
    public static final String PAGE_REPORT_1 = "report1";

    public static final String PAGE_IMPORT_QUALITY = "quality";
    public static final String QUALITY_BULK_FILE = "SOLAPA_CALIDAD.xlsx";

    public static final String REPORT_2 = "REPORTE2.xls";
    public static final String PAGE_REPORT_2 = "report2";

    public static final String PAY_GROWER = "REPORTE3.xls";
    public static final String PAGE_PAY_GROWER = "payGrower";


    public static final String SHEET_NAME = "BASESTIM";

    public static final String EXCEL_HEADER_LOT = "LOTE";
    public static final String EXCEL_HEADER_ZONE = "ZONA";
    public static final String EXCEL_HEADER_FIELD = "CAMPO";
    public static final String EXCEL_HEADER_HYBRID = "HIBRIDO";
    public static final String EXCEL_HEADER_HAS_REG = "HAS INSCRIPTAS";
    public static final String EXCEL_HEADER_HAS_HARV = "HAS COSECHADAS";
    public static final String EXCEL_HEADER_COMMENT = "COMENTARIOS";
    public static final String EXCEL_HEADER_AREA = "AREA";
    public static final String EXCEL_HEADER_CERT = "CERTIFICACION";
    public static final String EXCEL_HEADER_EXP = "EXPEDIENTE";
    public static final String EXCEL_HEADER_HYBRID_TYPE = "TIPO HIBRIDO";
    public static final String EXCEL_HEADER_PROGRAM = "PROGRAMA";
    public static final String EXCEL_HEADER_COLOR = "COLOR";

    public static final String EXCEL_HEADER_PLANTING_WEEK = "SEMANA SIEMBRA";
    public static final String EXCEL_HEADER_PLANTING_EST = "SIEMBRA ESTIMADA";
    public static final String EXCEL_HEADER_PLANTING_REAL = "SIEMBRA REAL";
    public static final String EXCEL_HEADER_PLANTING = "SIEMBRA";
    public static final String EXCEL_HEADER_FLOW_EST = "FLORACION ESTIMADA";
    public static final String EXCEL_HEADER_FLOW_REAL = "FLORACION REAL";
    public static final String EXCEL_HEADER_FLOW = "FLORACION";
    public static final String EXCEL_HEADER_HARVEST_EST = "COSECHA ESTIMADA";
    public static final String EXCEL_HEADER_HARVEST_HUMIDITY = "COSECHA S/ HUMEDAD";
    public static final String EXCEL_HEADER_HARVEST = "COSECHA ACTUAL";
    public static final String EXCEL_HEADER_HARVEST_WEEK = "SEMANA COSECHA";
    public static final String EXCEL_HEADER_HARVESTED = "COSECHADO SI/NO";

    public static final String EXCEL_HEADER_TARGET_TN_RW = "TN RW lote target";
    public static final String EXCEL_HEADER_TARGET_TN_DS = "TN DS lote target";
    public static final String EXCEL_HEADER_TARGET_LOT = "LOTE TARGET";
    public static final String EXCEL_HEADER_TARGET_RW_DS = "RW->DS";
    public static final String EXCEL_HEADER_TARGET_DS_FNG = "DS-FNG";
    public static final String EXCEL_HEADER_TARGET_KG_BAG = "kg bolsa target";
    public static final String EXCEL_HEADER_TARGET_UN_HA = "un/ha target";
    public static final String EXCEL_HEADER_TARGET_KW_DS_HA = "kg DS/ha target";

    public static final String EXCEL_HEADER_EST = "Estimaciones DS/ha";
    public static final String EXCEL_HEADER_EST_COMMENT = "Comentarios";

    public static final String EXCEL_HEADER_HARVEST_KG_RW = "kg RW por lote";
    public static final String EXCEL_HEADER_HARVEST_TN_DS_ACTUAL = "Tn DS lote actual";
    public static final String EXCEL_HEADER_HARVEST_TN_RW_ACTUAL = "Tn RW lote actual";
    public static final String EXCEL_HEADER_HARVEST_RW_DS = "RW->DS";
    public static final String EXCEL_HEADER_HUSKING_KG_DS = "kg DS por lote";
    public static final String EXCEL_HEADER_HUSKING_WAREHOUSE_UNIT = "Destino de almacenaje";
    public static final String EXCEL_HEADER_HUSKING_OBS = "Observaciones";

    public static final String EXCEL_HEADER_QUALITY_ACTUAL_KG_DS = "Actual KgDsLot";
    public static final String EXCEL_HEADER_QUALITY_APROV_DS_FNG = "% aprov Calidad DS-->FNG";
    public static final String EXCEL_HEADER_QUALITY_PESO_X_BOLSA = "Peso x bolsa pond Calidad";
    public static final String EXCEL_HEADER_QUALITY_KG_FNG_EST = "kg FNG por lote estimados por Calidad";
    public static final String EXCEL_HEADER_QUALITY_OBS = "Observaciones";
    public static final String EXCEL_HEADER_PREHARVEST_SAMPLE_DATE = "Fecha muestra";
    public static final String EXCEL_HEADER_PREHARVEST_HUMIDITY = "H°";
    public static final String EXCEL_HEADER_MEGA_ZONE = "Mega Zona";
    public static final String EXCEL_HEADER_GERMOPLASMA = "Germoplasma";
    public static final String EXCEL_HEADER_CLIENT = "Cliente";
    public static final String EXCEL_HEADER_GRAN_PROGRAM = "Gran programa";

    public static final String PAGE_IMPORT_AVERAGE_HUMIDITY = "importAverageHumidity";
    public static final String FILE_IMPORT_AVERAGE_HUMIDITY = "Reporte calidad.xls";


    public static final String PAGE_TONS_TO_HOST_REPORT = "tonsToHostReport";
    public static final String PAGE_STATUS_REPORT = "statusReport";
    public static final String PAGE_RECEIVING_TONS_REPORT = "receivingTonsReport";
    public static final String PAGE_BULK_DESTINATION_REPORT = "bulkDestinationReport";

    public static final String EXCEL_HEADER_ESTABLISHMENT = "Nombre de Planta";

    public static final String RECEIVE_TONS_EXPORT_XLS = "receiveTonsReportXls";

    public static final String RECEIVE_TONS_EXPORT_PDF = "receiveTonsReportPdf";

    public static final String HUMIDITY_IMPORT = "HUMIDITY.xls";

    public static final Integer ALL_ZONES = -1;

    public static final String CAMPAIGN_TON_WEEKS = "campaignTonWeeks";

    public static final String DATE_FORMAT = "dd/MM/yyyy";

    public static final String BLANK = "";

    public static final String OPTION_FILTER = "_optionFilter";

    public static final Integer OPTION_LOT_CODE = 1;
    public static final Integer OPTION_ZONE = 2;
    public static final Integer OPTION_HYBRID = 3;
    public static final String JB = "JB";

    public static final int FILTER_DATE = 3;
    public static final int FILTER_NUMBER = 2;
    public static final int FILTER_ZONE = 4;
    public static final int FILTER_HARVESTED = 5;
}




