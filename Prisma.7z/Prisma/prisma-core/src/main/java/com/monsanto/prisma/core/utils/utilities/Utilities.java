package com.monsanto.prisma.core.utils.utilities;


import com.lowagie.text.BadElementException;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.monsanto.prisma.core.dto.CellOmittedDTO;
import com.monsanto.prisma.core.dto.MonthYearDTO;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.jsoup.Jsoup;
import org.jsoup.safety.Whitelist;

import java.text.*;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 08/07/2014.
 */
public abstract class Utilities {
    private static Logger log = Logger.getLogger(Utilities.class);
    private static final String INVALID_DATA_TYPE = "Invalid Data type";

    public static Date getDateFromNumberWeek(int numberWeek) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.WEEK_OF_YEAR, numberWeek);
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        return calendar.getTime();
    }

    public static String getStringValue(Row row, int index, Whitelist whitelist, List<CellOmittedDTO> omittedCells) {
        String value = null;

        Cell cell = row.getCell(index, Row.CREATE_NULL_AS_BLANK);
        if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
            return null;
        }

        try {
            value = cell.getStringCellValue();
            if (value != null) {
                value = getStringValueClean(value, whitelist);
            }
        } catch (IllegalStateException e) {
            String colString = CellReference.convertNumToColString(index);
            int rowNum = row.getRowNum() + 1;
            String cellName = colString + rowNum;
            if (omittedCells != null)
                omittedCells.add(new CellOmittedDTO(cellName, e.getMessage()));
            log.error(INVALID_DATA_TYPE, e);
        } catch (NullPointerException e) {
            String colString = CellReference.convertNumToColString(index);
            int rowNum = row.getRowNum() + 1;
            String cellName = colString + rowNum;
            if (omittedCells != null)
                omittedCells.add(new CellOmittedDTO(cellName, e.getMessage()));
            log.debug(e.getMessage(), e);
        }

        return value;

    }

    public static String getStringValue(Row row, int index, Whitelist whitelist) {
        return getStringValue(row, index, whitelist, null);
    }

    public static String getStringValueClean(String value, Whitelist whitelist) {
        String valueClean = Jsoup.clean(value, whitelist);
        valueClean = valueClean.replaceAll("&aacute;", "á");
        valueClean = valueClean.replaceAll("&Aacute;", "Á");
        valueClean = valueClean.replaceAll("&eacute;", "é");
        valueClean = valueClean.replaceAll("&Eacute;", "É");
        valueClean = valueClean.replaceAll("&iacute;", "í");
        valueClean = valueClean.replaceAll("&Iacute;", "Í");
        valueClean = valueClean.replaceAll("&oacute;", "ó");
        valueClean = valueClean.replaceAll("&Oacute;", "Ó");
        valueClean = valueClean.replaceAll("&uacute;", "ú");
        valueClean = valueClean.replaceAll("&Uacute;", "Ú");
        valueClean = valueClean.replaceAll("&Ntilde;", "Ñ");
        valueClean = valueClean.replaceAll("&ntilde;", "ñ");

        return valueClean;
    }

    public static Integer getIntegerValue(Row row, int index, List<CellOmittedDTO> omittedCells) {
        Integer value = null;

        Cell cell = row.getCell(index, Row.CREATE_NULL_AS_BLANK);
        if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
            return null;
        }

        try {
            value = new Double(cell.getNumericCellValue()).intValue();
        } catch (IllegalStateException e) {
            String colString = CellReference.convertNumToColString(index);
            int rowNum = row.getRowNum() + 1;
            String cellName = colString + rowNum;
            if (omittedCells != null)
                omittedCells.add(new CellOmittedDTO(cellName, e.getMessage()));
            log.error(INVALID_DATA_TYPE, e);
        }

        return value;
    }

    public static Integer getIntegerValue(Row row, int index) {
        return getIntegerValue(row, index, null);
    }

    public static Float getFloatValue(Row row, int index, List<CellOmittedDTO> omittedCells) {
        Float value = null;

        Cell cell = row.getCell(index, Row.CREATE_NULL_AS_BLANK);
        if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
            return null;
        }

        try {
            value = new Float(cell.getNumericCellValue());
        } catch (IllegalStateException e) {
            String colString = CellReference.convertNumToColString(index);
            int rowNum = row.getRowNum() + 1;
            String cellName = colString + rowNum;
            if (omittedCells != null)
                omittedCells.add(new CellOmittedDTO(cellName, e.getMessage()));
            log.error(INVALID_DATA_TYPE, e);
        }
        return value;
    }

    public static Float getFloatValue(Row row, int index) {
        return getFloatValue(row, index, null);
    }

    public static Date getDateFromNumberWeek(Row row, int index, List<CellOmittedDTO> omittedCells) {

        Date value = null;
        try {
            int numberWeek = Math.round(Utilities.getFloatValue(row, index));
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.WEEK_OF_YEAR, numberWeek);
            calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
            value = calendar.getTime();
        } catch (Exception e) {
            String colString = CellReference.convertNumToColString(index);
            int rowNum = row.getRowNum() + 1;
            String cellName = colString + rowNum;
            if (omittedCells != null)
                omittedCells.add(new CellOmittedDTO(cellName, e.getMessage()));
            log.error(INVALID_DATA_TYPE, e);
        }

        return value;
    }

    public static Date getDateValue(Row row, int index, List<CellOmittedDTO> omittedCells) {
        Date value = null;

        Cell cell = row.getCell(index, Row.CREATE_NULL_AS_BLANK);
        if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
            return null;
        }

        try {
            boolean isHasPoint = cell.toString().contains(".");
            if (!isHasPoint) {
                cell.getCellStyle().setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));
                value = cell.getDateCellValue();
            } else {
                String strDate = cell.getStringCellValue().replace(".", "/");
                DateFormat lFormatter = new SimpleDateFormat("dd/MM/yyyy");
                Date date = null;
                try {
                    date = lFormatter.parse(strDate);
                } catch (ParseException e) {
                    throw new IllegalStateException(e.getMessage());
                }
                cell.setCellValue(date);
                cell.getCellStyle().setDataFormat(HSSFDataFormat.getBuiltinFormat("m/d/yy"));
                value = cell.getDateCellValue();
            }
        } catch (IllegalStateException e) {
            String colString = CellReference.convertNumToColString(index);
            int rowNum = row.getRowNum() + 1;
            String cellName = colString + rowNum;
            if (omittedCells != null)
                omittedCells.add(new CellOmittedDTO(cellName, e.getMessage()));
            log.error(INVALID_DATA_TYPE, e);
        }
        return value;
    }


    public static Date getDateValue(Row row, int index) {
        return getDateValue(row, index, null);
    }

    public static void createCellString(HSSFRow row, int column, String value, CellStyle style) {
        HSSFCell hssfCell = row.createCell(column);
        hssfCell.setCellStyle(style);
        if (value != null) {
            hssfCell.setCellValue(value);
        }
    }

    public static void createCellString(HSSFRow row, int column, String value) {
        HSSFCell hssfCell = row.createCell(column);
        if (value != null) {
            hssfCell.setCellValue(value);
        }
    }

    public static void createCellFloat(HSSFRow row, int column, Float value, CellStyle style) {
        DecimalFormat df = new DecimalFormat("###.##");

        HSSFCell hssfCell = row.createCell(column);
        hssfCell.setCellStyle(style);
        if (value != null) {
            hssfCell.setCellValue(df.format(value));
        }
    }

    public static void createCellFloat(HSSFRow row, int column, Float value) {
        DecimalFormat df = new DecimalFormat("###.##");

        HSSFCell hssfCell = row.createCell(column);
        if (value != null) {
            hssfCell.setCellValue(df.format(value));
        }
    }

    public static void createCellDouble(HSSFRow row, int column, Double value, CellStyle style) {
        HSSFCell hssfCell = row.createCell(column);
        hssfCell.setCellStyle(style);
        if (value != null) {
            hssfCell.setCellValue(value);
        }
    }

    public static void createCellDouble(HSSFRow row, int column, Double value) {
        HSSFCell hssfCell = row.createCell(column);
        if (value != null) {
            hssfCell.setCellValue(value);
        }
    }

    public static void addExcelRow(HSSFSheet excelSheet, Workbook workbook, String title, int fi, int co) {
        HSSFRow excelHeader = excelSheet.createRow(fi);

        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setWrapText(false);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setFillForegroundColor(HSSFColor.SEA_GREEN.index);

        Font font = workbook.createFont();
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        cellStyle.setFont(font);

        Utilities.createCellString(excelHeader, 0, title, cellStyle);

        excelSheet.addMergedRegion(new CellRangeAddress(fi, fi, 0, co));
    }

    public static com.lowagie.text.Font setFont(java.awt.Color color) {
        com.lowagie.text.Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(color);
        font.setSize(Constants.TEN);
        return font;
    }

    public static void setPdfValue(PdfPTable table, Object value, java.awt.Color fontColor, java.awt.Color bkg) throws BadElementException {
        com.lowagie.text.Font font = setFont(fontColor);
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(bkg);
        cell.setPadding(8);
        if (value != null) {
            cell.setPhrase(new Phrase(value.toString(), font));
            table.addCell(cell);
        } else {
            cell.setPhrase(new Phrase("", font));
            table.addCell(cell);
        }
    }

    public static Float convertStringToNumber(String str) {
        if (str == null) {
            return null;
        }
        //60M or 80M
        if (str.toUpperCase().trim().equals(Constants.JB)) {
            return null;
        }
        String val = str.substring(0, str.length() - 1);
        return Float.parseFloat(val);
    }

    public static MonthYearDTO getMonthAndYear(String value) {
        String[] arr = value.split("/");
        MonthYearDTO monthYearDTO = new MonthYearDTO();
        monthYearDTO.setYear(new Integer(arr[0]));
        monthYearDTO.setMonth(new Integer(arr[1]));
        return monthYearDTO;
    }

    public static Float parseStringToFloat(String value) throws ParseException {
        DecimalFormat df = new DecimalFormat();
        DecimalFormatSymbols symbols = new DecimalFormatSymbols();
        symbols.setDecimalSeparator(',');
        symbols.setGroupingSeparator('.');
        df.setDecimalFormatSymbols(symbols);
        return df.parse(value).floatValue();
    }

    public static void setCellStyle(HSSFRow excelRow, Integer cellIndex, CellStyle cellStyle) {
        HSSFCell cell = excelRow.getCell(cellIndex);
        if (cell == null) {
            cell = excelRow.createCell(cellIndex);
        }

        cell.setCellStyle(cellStyle);
    }

    public static Double getDoubleValue(Row row, int index) {
        Double value = null;

        Cell cell = row.getCell(index);
        if (cell == null) {
            return new Double(0);
        }
        try {
                value = cell.getNumericCellValue();

        } catch (IllegalStateException e) {
            e.getStackTrace();
        }

        return value;
    }
}
