package com.monsanto.prisma.core.workflow;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.CropService;
import com.monsanto.prisma.core.service.LotService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Prisma Process Manager which process the workflow by campaign.
 * User: BSBUON
 */
@Service
public class ApplicationProcessManager implements IProcessManager, ApplicationContextAware {

    @Autowired
    private CropService cropService;

    private static Logger log = Logger.getLogger(ApplicationProcessManager.class);

    @Autowired
    private LotService lotService;

    private ApplicationContext applicationContext;

    public ApplicationContext getApplicationContext() {
        return this.applicationContext;
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    public void process(Lot lot) throws ProcessWithErrorException, DataAccessException, BusinessException {
        if (lot.getCampaign() != null) {
            String workFlowName = cropService.findById(lot.getCampaign().getCrop().getId()).getWorkFlowName();
            process(workFlowName, lot);
        } else {
            throw new ProcessWithErrorException();
        }
    }

    public void process(String workFlowName, Lot lot) throws ProcessWithErrorException, DataAccessException, BusinessException {
        List<Process> workflow = (List<Process>) getApplicationContext().getBean(workFlowName);
        for (Process process : workflow) {
            process.doProcess(lot);
        }
        try {
            lotService.update(lot);
        } catch (DataAccessException e) {
            log.error(e.getMessage());
            throw new ProcessWithErrorException(e);
        }
    }

    public void process(String workFlowName, Lot lot, LotDTO lotDTO) throws BusinessException {
        log.debug("Init the workflow: " + workFlowName);
        List<Process> workflow = (List<Process>) getApplicationContext().getBean(workFlowName);
        try {
            for (Process process : workflow) {
                process.doProcess(lot, lotDTO);
                lotService.update(lot);
            }

        } catch (DataAccessException e) {
            log.error(e.getMessage());
            throw new ProcessWithErrorException(e);
        }

        log.debug("Finish the workflow: " + workFlowName);
    }
}
