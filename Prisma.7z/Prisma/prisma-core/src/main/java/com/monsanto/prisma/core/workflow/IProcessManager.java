package com.monsanto.prisma.core.workflow;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;

/**
 * Interface for application manager
 * User: BSBUON
 */
public interface IProcessManager {

    void process(Lot lot) throws ProcessWithErrorException, DataAccessException, BusinessException;

    void process(String workFlowName, Lot lot) throws ProcessWithErrorException, DataAccessException, BusinessException;
}
