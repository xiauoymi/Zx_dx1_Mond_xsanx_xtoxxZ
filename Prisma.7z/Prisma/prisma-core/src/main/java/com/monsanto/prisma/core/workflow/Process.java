package com.monsanto.prisma.core.workflow;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;

/**
 * Interface for the process in the workflow.
 */
public abstract class Process {

    public abstract void doProcess(Lot lot) throws ProcessWithErrorException, DataAccessException, BusinessException;

    public abstract void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException;
}
