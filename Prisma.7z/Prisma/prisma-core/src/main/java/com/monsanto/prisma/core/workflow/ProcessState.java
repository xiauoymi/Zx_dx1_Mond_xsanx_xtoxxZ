package com.monsanto.prisma.core.workflow;

/**
 * States for the Process Entities.
 * User: BSBUON
 * Date: 08/05/14
 * Time: 17:33
 * To change this template use File | Settings | File Templates.
 */
public enum ProcessState {
    OK, ERROR
}
