package com.monsanto.prisma.core.workflow;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 09/05/14
 * Time: 15:56
 * To change this template use File | Settings | File Templates.
 */
public class ProcessWithErrorException extends RuntimeException {

    private List<RuntimeException> violations;

    public ProcessWithErrorException() {
        super();
        violations = new ArrayList();
    }

    public ProcessWithErrorException(Exception e) {
        super(e);
        violations = new ArrayList();
    }

    public boolean hasViolations() {
        return !violations.isEmpty();
    }

    public void addViolation(RuntimeException e) {
        violations.add(e);
    }

    public List<RuntimeException> getViolations() {
        return violations;
    }
}
