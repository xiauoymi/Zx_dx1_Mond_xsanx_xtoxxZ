package com.monsanto.prisma.core.workflow.process;

import com.google.common.base.VerifyException;
import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.validation.FieldValidator;
import org.apache.log4j.Logger;

import java.util.Arrays;
import java.util.List;

public abstract class AbstractProcessOperation {
    private static Logger log = Logger.getLogger(AbstractProcessOperation.class);
    protected Lot lot;

    List<FieldValidator> fieldValidators;

    public AbstractProcessOperation() {
    }

    public void doCalculate(boolean doActionWhenValidationFails) {
        try {
            for (FieldValidator fieldValidator : fieldValidators) {
                fieldValidator.verify();
            }

            validCalculate(lot);
        } catch (VerifyException e) {
            if(doActionWhenValidationFails) {
                inValidCalculate(lot);
            }
            log.error(e.getMessage(),e);
        }
    }

    public void doCalculate() {
        doCalculate(true);
    }

    protected abstract void validCalculate(Lot lot);

    protected abstract void inValidCalculate(Lot lot);

    protected void initializeValidators(FieldValidator... validators) {
        this.fieldValidators = Arrays.asList(validators);
    }


}