package com.monsanto.prisma.core.workflow.process.businessInfo;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import org.apache.log4j.Logger;

/**
 * Created by AFREI on 01/09/2014.
 */
public class BusinessInfoProcess extends com.monsanto.prisma.core.workflow.Process {
    private static Logger log = Logger.getLogger(BusinessInfoProcess.class);

    @Override
    public void doProcess(Lot lot) throws ProcessWithErrorException, DataAccessException, BusinessException {
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("Start Lot process");
        parseLot(lot, lotDTO);
        log.debug("Finished Lot process");
    }

    public void parseLot(Lot lot, LotDTO lotDTO) {
        if (lotDTO.getObsLine() != null) {
            lot.setObsLine(lotDTO.getObsLine());
        }
        if (lotDTO.getGeneralObs() != null) {
            lot.setGeneralObs(lotDTO.getGeneralObs());
        }
        if (lotDTO.getEstimatedFngInit() != null) {
            lot.setEstimatedFngInit(lotDTO.getEstimatedFngInit());
        }
        if (lotDTO.getEstimatedFngEnd() != null) {
            lot.setEstimatedFngEnd(lotDTO.getEstimatedFngEnd());
        }
    }
}
