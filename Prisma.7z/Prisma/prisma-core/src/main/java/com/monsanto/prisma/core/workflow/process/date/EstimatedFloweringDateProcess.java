package com.monsanto.prisma.core.workflow.process.date;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.Process;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import com.monsanto.prisma.core.workflow.process.lot.EstimatedHarvestDateOperation;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by PGSETT on 16/06/2014.
 */
public class EstimatedFloweringDateProcess extends Process {

    private static Logger log = Logger.getLogger(EstimatedFloweringDateProcess.class);
    @Autowired
    EstimatedHarvestDateOperation estimatedHarvestDateOperation;

    @Override
    public void doProcess(Lot lot) {
        log.debug("the EstimatedFloweringDateProcess ready...");
        if (lot.getRealFloweringDate() == null && lot.getRealHarvestDate() == null) {
            doRecalculate(lot);
        }
        log.debug("the EstimatedFloweringDateProcess finished...");
    }

    private void doRecalculate(Lot lot) {
        if (lot.getEstimatedFloweringDate() != null && lot.getPlantingDate() != null) {
            if (lot.getEstimatedFloweringDate().before(lot.getPlantingDate())) {
                log.debug("The estimated flowering date is before than planting date.");
                throw new ProcessWithErrorException();
            }
            lot.setFloweringDate(lot.getEstimatedFloweringDate());
            estimatedHarvestDateOperation.initialize(lot).doCalculate();
        }
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("the EstimatedFloweringDateProcess ready...");
        if (lot.getRealFloweringDate() == null && lot.getRealHarvestDate() == null) {
            lot.setEstimatedFloweringDate(lotDTO.getEstimatedFloweringDate());
            doRecalculate(lot);
        }
        log.debug("the EstimatedFloweringDateProcess finished...");
    }
}
