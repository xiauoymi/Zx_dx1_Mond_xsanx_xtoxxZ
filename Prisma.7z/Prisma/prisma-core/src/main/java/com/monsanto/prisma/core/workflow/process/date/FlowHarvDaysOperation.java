package com.monsanto.prisma.core.workflow.process.date;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Created by AFREI on 30/07/2014.
 */
@Component
public class FlowHarvDaysOperation extends AbstractProcessOperation {

    public FlowHarvDaysOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Date>(lot.getFloweringDate(), "process.precondition.notNull.estimatedFloweringDate"),
                new NullValidator<Integer>(lot.getFlowHarvDays(), "process.precondition.notNull.flowHarvDays"),
                new NotZeroValidator<Integer>(lot.getFlowHarvDays(), "process.precondition.notNull.flowHarvDays"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        DateTime date = new DateTime(lot.getFloweringDate());
        date = date.plusDays(lot.getFlowHarvDays());
        lot.setEstimatedHarvestDate(date.toDate());
        lot.setHarvestDate(lot.getEstimatedHarvestDate());
        DateTime dateTime = new DateTime(lot.getHarvestDate());
        lot.setHarvestWeek(new Float(dateTime.getWeekOfWeekyear()));
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        //do nothing
    }
}
