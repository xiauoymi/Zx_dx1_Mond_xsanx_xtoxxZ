package com.monsanto.prisma.core.workflow.process.date;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.Process;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by PGSETT on 16/06/2014.
 */
public class FlowHarvDaysProcess extends Process {

    private static Logger log = Logger.getLogger(FlowHarvDaysProcess.class);

    @Autowired
    FlowHarvDaysOperation flowHarvDaysOperation;

    @Override
    public void doProcess(Lot lot) {
        log.debug("the FlowHarvDaysProcess ready...");
        if ((lot.getRealHarvestDate() == null)) {
            doRecalculate(lot);
        }
        log.debug("the FlowHarvDaysProcess finished...");
    }

    private void doRecalculate(Lot lot) {
        flowHarvDaysOperation.initialize(lot).doCalculate();
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("the FlowHarvDaysProcess ready...");
        if ((lot.getRealHarvestDate() == null)) {
            lot.setFlowHarvDays(lotDTO.getFlowHarvDays());
            doRecalculate(lot);
        }
        log.debug("the FlowHarvDaysProcess finished...");
    }
}
