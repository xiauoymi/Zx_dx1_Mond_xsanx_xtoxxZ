package com.monsanto.prisma.core.workflow.process.date;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.Process;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import com.monsanto.prisma.core.workflow.process.lot.EstimatedHarvestDateOperation;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by PGSETT on 16/06/2014.
 */
public class RealFloweringDateProcess extends Process {

    private static Logger log = Logger.getLogger(RealFloweringDateProcess.class);
    @Autowired
    EstimatedHarvestDateOperation estimatedHarvestDateOperation;

    @Override
    public void doProcess(Lot lot) {
        log.debug("the RealFloweringDateProcess ready...");
        if (lot.getRealHarvestDate() == null) {
            doRecalculate(lot);
        }
        log.debug("the RealFloweringDateProcess finished...");
    }

    private void doRecalculate(Lot lot) {
        if (lot.getRealFloweringDate() != null && lot.getPlantingDate() != null && lot.getRealFloweringDate().before(lot.getPlantingDate())) {
            log.debug("The real flowering date is before that planting date.");
            throw new ProcessWithErrorException();
        }
        lot.setFloweringDate(lot.getRealFloweringDate());
        estimatedHarvestDateOperation.initialize(lot).doCalculate();
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("the RealFloweringDateProcess ready...");
        if (lot.getRealHarvestDate() == null) {
            lot.setRealFloweringDate(lotDTO.getRealFloweringDate());
            doRecalculate(lot);
        }
        log.debug("the RealFloweringDateProcess finished...");
    }
}
