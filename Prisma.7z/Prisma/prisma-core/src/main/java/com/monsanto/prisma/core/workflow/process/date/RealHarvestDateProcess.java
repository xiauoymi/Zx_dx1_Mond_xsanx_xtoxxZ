package com.monsanto.prisma.core.workflow.process.date;

import com.monsanto.prisma.core.domain.Forecast;
import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.ForecastService;
import com.monsanto.prisma.core.workflow.Process;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Created by PGSETT on 16/06/2014.
 */
@Component
public class RealHarvestDateProcess extends Process {
    private static Logger log = Logger.getLogger(RealHarvestDateProcess.class);

    @Autowired
    private ForecastService forecastService;

    @Override
    public void doProcess(Lot lot) {
        log.debug("the RealHarvestDateProcess ready...");
        doRecalculate(lot);
        log.debug("the RealHarvestDateProcess finished...");
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("the RealHarvestDateProcess ready...");
        lot.setRealHarvestDate(lotDTO.getRealHarvestDate());
        doRecalculate(lot);
        log.debug("the RealHarvestDateProcess finished...");
    }

    private void doRecalculate(Lot lot) {
        if (lot.getRealHarvestDate() != null && lot.getFloweringDate() != null) {
            if (lot.getRealHarvestDate().before(lot.getFloweringDate())) {
                log.debug("The real harvest date is before that flowering date.");
                throw new ProcessWithErrorException();
            }
            lot.setHarvestDate(lot.getRealHarvestDate());
            DateTime dateTime = new DateTime(lot.getHarvestDate());
            lot.setHarvestWeek(new Float(dateTime.getWeekOfWeekyear()));
            Forecast forecast = forecastService.findByCampaignId(lot.getCampaign().getId());
            Date estimatedRwDate = dateTime.plusDays(forecast.getDaysRw()).toDate();
            lot.setEstimatedRwDate(estimatedRwDate);
            DateTime estimatedRwDateTime = new DateTime(estimatedRwDate);
            DateTime estimatedDsDate = null;
            if (lot.getRealRwReceiptDate() != null) {
                estimatedDsDate = new DateTime(lot.getRealRwReceiptDate());
            } else {
                estimatedDsDate = new DateTime(estimatedRwDateTime);
            }
            lot.setEstimatedDsDate(estimatedDsDate.plusDays(forecast.getDaysDs()).toDate());

        }
    }

}
