package com.monsanto.prisma.core.workflow.process.date;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.Process;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import com.monsanto.prisma.core.workflow.process.lot.EstimatedFloweringDateOperation;
import com.monsanto.prisma.core.workflow.process.lot.EstimatedHarvestDateOperation;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 08/05/14
 * Time: 16:06
 * To change this template use File | Settings | File Templates.
 */
public class RealPlantingDateProcess extends Process {

    private static Logger log = Logger.getLogger(RealPlantingDateProcess.class);

    @Autowired
    EstimatedFloweringDateOperation estimatedFloweringDateOperation;
    @Autowired
    EstimatedHarvestDateOperation estimatedHarvestDateOperation;

    @Override
    public void doProcess(Lot lot) {
        log.debug("the RealPlantingDateProcess ready...");
        if (lot.getRealFloweringDate() == null && lot.getRealHarvestDate() == null) {
            doRecalculate(lot);
        }
        log.debug("the RealPlantingDateProcess finish.");
    }

    private void doRecalculate(Lot lot) {
        lot.setPlantingDate(lot.getRealPlantingDate());
        estimatedFloweringDateOperation.initialize(lot).doCalculate();
        estimatedHarvestDateOperation.initialize(lot).doCalculate();
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("the RealPlantingDateProcess ready...");
        if (lot.getRealFloweringDate() == null && lot.getRealHarvestDate() == null) {
            lot.setRealPlantingDate(lotDTO.getRealPlantingDate());
            doRecalculate(lot);
        }
        log.debug("the RealPlantingDateProcess finish.");

    }

}
