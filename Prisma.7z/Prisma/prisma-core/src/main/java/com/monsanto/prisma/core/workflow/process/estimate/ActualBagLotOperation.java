package com.monsanto.prisma.core.workflow.process.estimate;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by AFREI on 15/07/2014.
 */
@Component
public class ActualBagLotOperation extends AbstractProcessOperation {

    public ActualBagLotOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getActualTnFngLot(), "process.precondition.notNull.actualTnFngLot"),
                new NullValidator<Float>(lot.getTargetKgBag(), "process.precondition.notNull.targetKgBag"),
                new NotZeroValidator<Float>(lot.getTargetKgBag(), "process.precondition.notZero.targetKgBag"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setActualBagLot((lot.getActualTnFngLot() * Constants.NUMBER_MIL) / lot.getTargetKgBag());
    }

    @Override
    protected void inValidCalculate(Lot lot) {

    }
}
