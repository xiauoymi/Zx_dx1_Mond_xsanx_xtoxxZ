package com.monsanto.prisma.core.workflow.process.estimate;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by EPESTE on 06/08/2014.
 */
@Component
public class ActualTnDsLotOperation extends AbstractProcessOperation {

    public ActualTnDsLotOperation initialize(Lot lot){
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getActualKgDsHa(), "process.precondition.notNull.actualKgDsHa"),
                new NullValidator<Float>(lot.getHarvestableHas(), "process.precondition.notNull.harvestableHas"),
                new NotZeroValidator<Float>(lot.getHarvestableHas(), "process.precondition.notZero.harvestableHas"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setActualTnDsLot((lot.getActualKgDsHa() / Constants.NUMBER_MIL) * lot.getHarvestableHas());
        if (lot.getTargetDsToFng()!= null) {
            lot.setEstimatedTnFngLot(lot.getActualTnDsLot()* lot.getTargetDsToFng());
        }
    }

    @Override
    protected void inValidCalculate(Lot lot) {

    }
}
