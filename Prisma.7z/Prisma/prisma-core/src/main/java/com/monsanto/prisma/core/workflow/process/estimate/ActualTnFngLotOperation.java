package com.monsanto.prisma.core.workflow.process.estimate;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by EPESTE on 06/08/2014.
 */
@Component
public class ActualTnFngLotOperation extends AbstractProcessOperation {

    public ActualTnFngLotOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(new NullValidator<Float>(lot.getActualTnDsLot(), "process.precondition.notNull.actualTnDsLot"),
                new NullValidator<Float>(lot.getTargetDsToFng(), "process.precondition.notNull.targetDsToFng"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setActualTnFngLot(lot.getActualTnDsLot() * lot.getTargetDsToFng());
    }

    @Override
    protected void inValidCalculate(Lot lot) {

    }
}
