package com.monsanto.prisma.core.workflow.process.estimate;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by EPESTE on 06/08/2014.
 */
@Component
public class ActualTnRwLotOperation extends AbstractProcessOperation {

    public ActualTnRwLotOperation initialize(Lot lot){
        this.lot = lot;
        initializeValidators(new NullValidator<Float>(lot.getActualTnDsLot(), "process.precondition.notNull.actualTnDsLot"),
                new NullValidator<Float>(lot.getTargetRwToDs(), "process.precondition.notNull.targetRwToDs"),
                new NotZeroValidator<Float>(lot.getTargetRwToDs(), "process.precondition.notZero.targetRwToDs"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setActualTnRwLot(lot.getActualTnDsLot() / lot.getTargetRwToDs());
    }

    @Override
    protected void inValidCalculate(Lot lot) {

    }
}
