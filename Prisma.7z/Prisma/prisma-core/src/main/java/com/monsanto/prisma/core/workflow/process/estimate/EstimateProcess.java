package com.monsanto.prisma.core.workflow.process.estimate;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by PGSETT on 03/06/2014.
 */
public class EstimateProcess extends com.monsanto.prisma.core.workflow.Process {

    @Autowired
    ActualBagLotOperation actualBagLotOperation;
    @Autowired
    PorcActualObjetiveTargetDsOperation porcActualObjetiveTargetDsOperation;
    @Autowired
    PorcentActualObjectiveUnTargetOperation porcentActualObjectiveUnTargetOperation;
    @Autowired
    EficienciaEstUnFieldOperation eficienciaEstUnFieldOperation;
    @Autowired
    ActualTnDsLotOperation actualTnDsLotOperation;
    @Autowired
    ActualTnRwLotOperation actualTnRwLotOperation;
    @Autowired
    ActualTnFngLotOperation actualTnFngLotOperation;

    private static Logger log = Logger.getLogger(EstimateProcess.class);

    @Override
    public void doProcess(Lot lot) {
        log.debug("Started estimate process.");
        if (!lot.isHarvested() && lot.isPlanted()) {
            doRecalculate(lot);
        } else {
            log.debug("The lot was harvested and wasn't planted");
        }

        log.debug("Finished estimate process");
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("Started estimate process.");
        if (!lot.isHarvested() && lot.isPlanted()) {
            parseLot(lot, lotDTO);
            doRecalculate(lot);
        } else {
            log.debug("The lot was harvested and wasn't planted");
        }
        log.debug("Finished estimate process");
    }

    private void doRecalculate(Lot lot) {
        lot.setActualKgDsHa(lot.getEstimatedKgDsHa());
        actualTnDsLotOperation.initialize(lot).doCalculate();
        actualTnRwLotOperation.initialize(lot).doCalculate();
        actualTnFngLotOperation.initialize(lot).doCalculate();
        actualBagLotOperation.initialize(lot).doCalculate();
        porcActualObjetiveTargetDsOperation.initialize(lot).doCalculate(false);
        porcentActualObjectiveUnTargetOperation.initialize(lot).doCalculate();
        eficienciaEstUnFieldOperation.initialize(lot).doCalculate();
    }

    private void parseLot(Lot lot, LotDTO lotDTO) {
        if (lotDTO.getEstimatedKgDsHa() != null) {
            lot.setEstimatedKgDsHa(lotDTO.getEstimatedKgDsHa());
            lot.setCountEstimatedKgDsHa(lot.getCountEstimatedKgDsHa() + 1);
        }

        if (lotDTO.getObsEstimatedKgDsHa() != null) {
            lot.setObsEstimatedKgDsHa(lotDTO.getObsEstimatedKgDsHa());
        }
    }

}
