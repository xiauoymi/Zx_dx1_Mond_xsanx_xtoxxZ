package com.monsanto.prisma.core.workflow.process.estimate;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by AFREI on 15/07/2014.
 */
@Component
public class PorcActualObjetiveTargetDsOperation extends AbstractProcessOperation {

    public PorcActualObjetiveTargetDsOperation initialize(Lot lot){
        this.lot = lot;
        initializeValidators(new NullValidator<Float>(lot.getActualKgDsHa(), "process.precondition.notNull.targetKgsDsHa"),
            new NullValidator<Float>(lot.getTargetKgsDsHa(), "process.precondition.notNull.targetKgsDsHa"),
            new NotZeroValidator<Float>(lot.getTargetKgsDsHa(),"process.precondition.notZero.targetKgsDsHa"));
        return this;
        }

        @Override
        protected void validCalculate(Lot lot) {
            lot.setPorcActualObjetiveTargetDs(lot.getActualKgDsHa() / lot.getTargetKgsDsHa());
        }

        @Override
        protected void inValidCalculate(Lot lot) {
            lot.setPorcActualObjetiveTargetDs(null);
        }
}
