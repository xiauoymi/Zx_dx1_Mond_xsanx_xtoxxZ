package com.monsanto.prisma.core.workflow.process.estimate;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by AFREI on 15/07/2014.
 */
@Component
public class PorcentActualObjectiveUnTargetOperation extends AbstractProcessOperation {


    public PorcentActualObjectiveUnTargetOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(new NullValidator<Float>(lot.getTargetBagLot(), "process.precondition.notNull.targetBagLot"),
                new NullValidator<Float>(lot.getActualBagLot(), "process.precondition.notNull.actualBagLot"),
                new NotZeroValidator<Float>(lot.getTargetBagLot(), "process.precondition.notZero.targetBagLot"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setPorcentActualObjectiveUnTarget(lot.getActualBagLot() / lot.getTargetBagLot());
    }

    @Override
    protected void inValidCalculate(Lot lot) {

    }
}
