package com.monsanto.prisma.core.workflow.process.harvest;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 22/07/2014.
 */
@Component
public class ActualKgDsHaOperation extends AbstractProcessOperation {

    public ActualKgDsHaOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getActualTnDsLot(), "process.precondition.notNull.actualTsDsLot"),
                new NullValidator<Float>(lot.getHarvestableHas(), "process.precondition.notNull.harvestableHas"),
                new NotZeroValidator<Float>(lot.getHarvestableHas(), "process.precondition.notZero.harvestableHas"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        //BASEESTIM-184
        lot.setActualKgDsHa((lot.getActualTnDsLot() * Constants.NUMBER_MIL) / lot.getHarvestableHas());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setActualKgDsHa(null);
    }
}
