package com.monsanto.prisma.core.workflow.process.harvest;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by EPESTE on 17/07/2014.
 */
@Component
public class ActualTnDsLotHarvestOperation extends AbstractProcessOperation {
    public ActualTnDsLotHarvestOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getHarvKgDsLotEstRw(), "process.precondition.notNull.harvKgDsLotEstRw"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setActualTnDsLot(lot.getHarvKgDsLotEstRw() / Constants.NUMBER_MIL);
        if (lot.getTargetDsToFng()!= null) {
            lot.setEstimatedTnFngLot(lot.getActualTnDsLot()* lot.getTargetDsToFng());
        }
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setActualTnDsLot(null);
    }
}
