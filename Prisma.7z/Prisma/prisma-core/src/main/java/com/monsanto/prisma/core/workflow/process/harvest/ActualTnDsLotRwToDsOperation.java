package com.monsanto.prisma.core.workflow.process.harvest;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 22/07/2014.
 */
@Component
public class ActualTnDsLotRwToDsOperation extends AbstractProcessOperation {
    public ActualTnDsLotRwToDsOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getActualTnRwLot(), "process.precondition.notNull.actualTnRwLot"),
                new NullValidator<Float>(lot.getHarvestRwToDs(), "process.precondition.notNull.HarvestRwToDs"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setActualTnDsLot(lot.getActualTnRwLot() * lot.getHarvestRwToDs());
        if (lot.getTargetDsToFng() != null) {
            lot.setEstimatedTnFngLot(lot.getActualTnDsLot() * lot.getTargetDsToFng());
        }
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setActualTnDsLot(null);
    }
}
