package com.monsanto.prisma.core.workflow.process.harvest;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by EPESTE on 17/07/2014.
 */
@Component
public class ActualTnRwLotHarvestOperation extends AbstractProcessOperation {
    public ActualTnRwLotHarvestOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getHarvestKgRWLot(), "process.precondition.notNull.harvestKgRWLot"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setActualTnRwLot(lot.getHarvestKgRWLot() / Constants.NUMBER_MIL);
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setActualTnRwLot(null);
    }
}
