package com.monsanto.prisma.core.workflow.process.harvest;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by EPESTE on 17/07/2014.
 */
@Component
public class EficienciaEstUnFieldHarvestOperation extends AbstractProcessOperation {
    public EficienciaEstUnFieldHarvestOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getActualKgDsHa(), "process.precondition.notNull.actualKgDsHa"),
                new NullValidator<Float>(lot.getTargetDsToFng(), "process.precondition.notNull.targetDsToFng"),
                new NullValidator<Float>(lot.getTargetKgsDsHa(), "process.precondition.notNull.targetKgsDsHa"),
                new NullValidator<Float>(lot.getHarvestableHas(), "process.precondition.notNull.harvestableHas"),
                new NotZeroValidator<Float>(lot.getTargetKgsDsHa(), "process.precondition.notZero.targetKgsDsHa"),
                new NotZeroValidator<Float>(lot.getHarvestableHas(), "process.precondition.notZero.harvestableHas"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setEficienciaEstUnField(lot.getActualKgDsHa() * lot.getTargetDsToFng() / (lot.getTargetKgsDsHa() * lot.getHarvestableHas()));
    }

    @Override
    protected void inValidCalculate(Lot lot) {
       // lot.setEficienciaEstUnField(null);
    }
}
