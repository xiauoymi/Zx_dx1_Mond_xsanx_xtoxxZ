package com.monsanto.prisma.core.workflow.process.harvest;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by EPESTE on 17/07/2014.
 */
@Component
public class HarvKgDsHaEstRwHarvestOperation extends AbstractProcessOperation {
    public HarvKgDsHaEstRwHarvestOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getHarvKgDsLotEstRw(), "process.precondition.notNull.harvKgDsLotEstRw"),
                new NullValidator<Float>(lot.getHarvestableHas(), "process.precondition.notNull.harvestableHas"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setHarvKgDsHaEstRw(lot.getHarvKgDsLotEstRw() * lot.getHarvestableHas());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setHarvKgDsHaEstRw(null);
    }
}
