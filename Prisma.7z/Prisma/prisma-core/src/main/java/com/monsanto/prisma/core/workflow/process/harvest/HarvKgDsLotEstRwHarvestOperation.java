package com.monsanto.prisma.core.workflow.process.harvest;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by EPESTE on 17/07/2014.
 */
@Component
public class HarvKgDsLotEstRwHarvestOperation extends AbstractProcessOperation {
    public HarvKgDsLotEstRwHarvestOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getTargetRwToDs(), "process.precondition.notNull.targetRwToDs"),
                new NullValidator<Float>(lot.getHarvestRwToDs(), "process.precondition.notNull.HarvestRwToDs"),
                new NullValidator<Float>(lot.getHarvestKgRWLot(), "process.precondition.notNull.harvestKgRWLot"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        if (lot.getHarvestRwToDs() == null) {
            lot.setHarvKgDsLotEstRw(lot.getHarvestKgRWLot() * lot.getTargetRwToDs());
        } else {
            if (lot.getHarvestRwToDs().equals(Constants.ZERO)) {
                if (lot.getTargetRwToDs() != null) {
                    lot.setHarvKgDsLotEstRw(lot.getHarvestKgRWLot() * lot.getTargetRwToDs());
                } else {
                    lot.setHarvKgDsLotEstRw(null);
                }
            } else {
                if (lot.getHarvestRwToDs() != null) {
                    lot.setHarvKgDsLotEstRw(lot.getHarvestKgRWLot() * lot.getHarvestRwToDs());
                } else {
                    lot.setHarvKgDsLotEstRw(null);
                }
            }
        }
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setHarvKgDsLotEstRw(null);
    }
}
