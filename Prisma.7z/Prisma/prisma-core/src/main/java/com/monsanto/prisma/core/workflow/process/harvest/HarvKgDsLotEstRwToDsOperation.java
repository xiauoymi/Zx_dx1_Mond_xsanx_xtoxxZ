package com.monsanto.prisma.core.workflow.process.harvest;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 22/07/2014.
 */
@Component
public class HarvKgDsLotEstRwToDsOperation extends AbstractProcessOperation {

    public HarvKgDsLotEstRwToDsOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getActualTnRwLot(), "process.precondition.notNull.actualTnRwLot"),
                new NullValidator<Float>(lot.getHarvestRwToDs(), "process.precondition.notNull.HarvestRwToDs"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setHarvKgDsLotEstRw((lot.getActualTnRwLot() / Constants.NUMBER_MIL) * lot.getHarvestRwToDs());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setHarvKgDsLotEstRw(null);
    }
}
