package com.monsanto.prisma.core.workflow.process.harvest;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.*;
import com.monsanto.prisma.core.workflow.process.estimate.PorcActualObjetiveTargetDsOperation;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by EPESTE on 16/07/2014.
 */
@Component
public class HarvestKgRwProcess extends com.monsanto.prisma.core.workflow.Process {

    private static Logger log = Logger.getLogger(HarvestKgRwProcess.class);
    @Autowired
    private HarvKgDsLotEstRwHarvestOperation harvKgDsLotEstRwOperation;
    @Autowired
    private HarvKgFngEstLotRwHarvestOperation harvKgFngEstLotRwOperation;
    @Autowired
    private HarvKgDsHaEstRwHarvestOperation harvKgDsHaEstRwOperation;
    @Autowired
    private ActualTnRwLotHarvestOperation actualTnRwLotOperation;
    @Autowired
    private ActualTnDsLotHarvestOperation actualTnDsLotOperation;
    @Autowired
    private PorcActualObjetiveTargetDsOperation porcActualObjetiveTargetDsOperation;
    @Autowired
    private EficienciaEstUnFieldHarvestOperation eficienciaEstUnFieldOperation;

    @Override
    public void doProcess(Lot lot) throws ProcessWithErrorException {
        log.debug("The Harvest kg RW process ready...");

        if (lot.getRealHarvestDate() == null) {
            log.debug("The real harvest date is null.");
            return;
        }

        if (lot.getHarvestKgRWLot() == null) {
            log.debug("The harvest kg rw lot is null.");
            return;
        }
        doRecalculate(lot);

        log.debug("The Harvest kg RW process finished...");
    }

    private void doRecalculate(Lot lot) {
        if (lot.getHarvestKgRWLot() > 0) {
            harvKgDsLotEstRwOperation.initialize(lot).doCalculate();
            harvKgFngEstLotRwOperation.initialize(lot).doCalculate();
            harvKgDsHaEstRwOperation.initialize(lot).doCalculate();
            actualTnRwLotOperation.initialize(lot).doCalculate();
            actualTnDsLotOperation.initialize(lot).doCalculate();
            lot.setActualKgDsHa(lot.getHarvKgDsHaEstRw());
            porcActualObjetiveTargetDsOperation.initialize(lot).doCalculate();
            eficienciaEstUnFieldOperation.initialize(lot).doCalculate();
        }
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("The Harvest kg RW process ready...");

        if (lot.getRealHarvestDate() == null) {
            log.debug("The real harvest date is null.");
            log.debug("The Harvest kg RW process finished...");
            return;
        }

        lot.setHarvestKgRWLot(lotDTO.getHarvestKgRWLot());
        doRecalculate(lot);

        log.debug("The Harvest kg RW process finished...");
    }
}
