package com.monsanto.prisma.core.workflow.process.harvest;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import com.monsanto.prisma.core.workflow.process.estimate.PorcActualObjetiveTargetDsOperation;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 22/07/2014.
 */
@Component
public class HarvestRwToDsProcess extends com.monsanto.prisma.core.workflow.Process {
    private static Logger log = Logger.getLogger(HarvestRwToDsProcess.class);

    @Autowired
    private HarvKgDsLotEstRwToDsOperation harvKgDsLotEstRwToDsOperation;

    @Autowired
    private HarvKgFngEstLotRwHarvestOperation harvKgFngEstLotRwOperation;
    @Autowired
    private HarvKgDsHaEstRwHarvestOperation harvKgDsHaEstRwOperation;
    @Autowired
    private ActualTnDsLotRwToDsOperation actualTnDsLotRwToDsOperation;
    @Autowired
    private ActualKgDsHaOperation actualKgDsHaOperation;

    @Autowired
    private PorcActualObjetiveTargetDsOperation porcActualObjetiveTargetDsOperation;
    @Autowired
    private EficienciaEstUnFieldHarvestOperation eficienciaEstUnFieldOperation;

    @Override
    public void doProcess(Lot lot) throws ProcessWithErrorException {
        log.debug("The Harvest RW to DS process ready...");
        doRecalculate(lot);
        log.debug("The Harvest RW to DS process finished...");
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("The Harvest RW to DS process ready...");
        lot.setHarvestRwToDs(lotDTO.getHarvestRwToDs());
        if (lotDTO.getObsHarvestRwToDs() != null) {
            lot.setObsHarvestRwToDs(lotDTO.getObsHarvestRwToDs());
        }
        doRecalculate(lot);
        log.debug("The Harvest RW to DS process finished...");
    }

    private void doRecalculate(Lot lot) {
        harvKgDsLotEstRwToDsOperation.initialize(lot).doCalculate();
        harvKgFngEstLotRwOperation.initialize(lot).doCalculate();
        harvKgDsHaEstRwOperation.initialize(lot).doCalculate();
        actualTnDsLotRwToDsOperation.initialize(lot).doCalculate();
        actualKgDsHaOperation.initialize(lot).doCalculate();
        porcActualObjetiveTargetDsOperation.initialize(lot).doCalculate();
        eficienciaEstUnFieldOperation.initialize(lot).doCalculate();
    }
}
