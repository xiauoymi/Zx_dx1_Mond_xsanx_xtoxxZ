package com.monsanto.prisma.core.workflow.process.husking;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 23/07/2014.
 */
@Component
public class ActualKgDsLotOperation extends AbstractProcessOperation {

    public ActualKgDsLotOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getHuskingKgDsLot(), "process.precondition.notNull.huskingKgDsLot"));
        return this;
    }


    @Override
    protected void validCalculate(Lot lot) {
        lot.setActualKgDsLot(lot.getHuskingKgDsLot());
        lot.setActualKgDsBalance(lot.getHuskingKgDsLot());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setActualKgDsLot(null);
    }
}
