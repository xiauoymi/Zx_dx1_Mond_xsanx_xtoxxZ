package com.monsanto.prisma.core.workflow.process.husking;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 23/07/2014.
 */
@Component
public class ActualTnDsHaOperation extends AbstractProcessOperation {

    public ActualTnDsHaOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getHuskingKgDsHa(), "process.precondition.notNull.huskingKgDsHa"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setActualTnDsHa(lot.getHuskingKgDsHa() / Constants.NUMBER_MIL);
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setActualTnDsHa(null);
    }
}
