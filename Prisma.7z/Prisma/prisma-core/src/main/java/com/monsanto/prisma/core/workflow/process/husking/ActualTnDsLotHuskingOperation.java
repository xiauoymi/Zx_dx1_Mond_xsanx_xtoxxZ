package com.monsanto.prisma.core.workflow.process.husking;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 23/07/2014.
 */
@Component
public class ActualTnDsLotHuskingOperation extends AbstractProcessOperation {

    public ActualTnDsLotHuskingOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getHuskingKgDsLot(), "process.precondition.notNull.huskingKgDsLot"));
        return this;
    }


    @Override
    protected void validCalculate(Lot lot) {
        lot.setActualTnDsLot(lot.getHuskingKgDsLot() / Constants.NUMBER_MIL);
        if (lot.getTargetDsToFng() != null) {
            lot.setEstimatedTnFngLot(lot.getActualTnDsLot() * lot.getTargetDsToFng());
        }
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setActualTnDsLot(null);
    }
}
