package com.monsanto.prisma.core.workflow.process.husking;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 28/07/2014.
 */
@Component
public class EficienciaDsToFngOperation extends AbstractProcessOperation {
    public EficienciaDsToFngOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getHuskingKgDsLot(), "process.precondition.notNull.huskingKgDsLot"),
                new NullValidator<Float>(lot.getActualKgFngLot(), "process.precondition.notNull.acutalKgFngLot"),
                new NotZeroValidator<Float>(lot.getHuskingKgDsLot(), "process.precondition.notZero.huskingKgDsLot"));
        return this;
    }
    @Override
    protected void validCalculate(Lot lot) {
        lot.setEficienciaDsToFng(lot.getActualKgFngLot() / lot.getHuskingKgDsLot());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setEficienciaDsToFng(null);
    }
}
