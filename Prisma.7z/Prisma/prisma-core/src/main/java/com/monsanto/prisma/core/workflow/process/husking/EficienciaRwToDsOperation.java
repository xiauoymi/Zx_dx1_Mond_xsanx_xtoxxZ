package com.monsanto.prisma.core.workflow.process.husking;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 23/07/2014.
 */
@Component
public class EficienciaRwToDsOperation extends AbstractProcessOperation {

    public EficienciaRwToDsOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getHuskingKgDsLot(), "process.precondition.notNull.huskingKgDsLot"),
                new NullValidator<Float>(lot.getHarvestKgRWLot(), "process.precondition.notNull.harvestKgRWLot"),
                new NotZeroValidator<Float>(lot.getHarvestKgRWLot(), "process.precondition.notZero.harvestKgRWLot"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setEficienciaRwToDs(lot.getHuskingKgDsLot() / lot.getHarvestKgRWLot());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setEficienciaRwToDs(null);
    }
}
