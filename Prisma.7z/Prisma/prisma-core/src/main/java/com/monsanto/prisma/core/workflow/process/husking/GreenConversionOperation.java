package com.monsanto.prisma.core.workflow.process.husking;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 23/07/2014.
 */
@Component
public class GreenConversionOperation extends AbstractProcessOperation {
    public GreenConversionOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getHuskingKgDsLot(), "process.precondition.notNull.huskingKgDsLot"),
                new NullValidator<Float>(lot.getPlsLot(), "process.precondition.notNull.plsLot"),
                new NullValidator<Float>(lot.getIndexLot(), "process.precondition.notNull.indexLot"),
                new NotZeroValidator<Float>(lot.getPlsLot(), "process.precondition.notZero.plsLot"));
        return this;
    }


    @Override
    protected void validCalculate(Lot lot) {
        lot.setGreenConversion(lot.getHuskingKgDsLot() / lot.getPlsLot() / lot.getIndexLot());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setGreenConversion(null);
    }
}
