package com.monsanto.prisma.core.workflow.process.husking;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 23/07/2014.
 */
@Component
public class HuskingProcess extends com.monsanto.prisma.core.workflow.Process {
    private static Logger log = Logger.getLogger(HuskingProcess.class);

    @Autowired
    private HuskingKgDsHaOperation huskingKgDsHaOperation;
    @Autowired
    private ActualKgDsLotOperation actualKgDsLotOperation;
    @Autowired
    private ActualTnDsHaOperation actualTnDsHaOperation;
    @Autowired
    private QualityKgFngLotHuskingOperation qualityKgFngLotOperation;
    @Autowired
    private ActualTnDsLotHuskingOperation actualTnDsLotHuskingOperation;
    @Autowired
    private GreenConversionOperation greenConversionOperation;
    @Autowired
    private EficienciaRwToDsOperation eficienciaRwToDsOperation;
    @Autowired
    private EficienciaDsToFngOperation eficienciaDsToFngOperation;

    @Override
    public void doProcess(Lot lot) throws ProcessWithErrorException {
        log.debug("The Husking process ready...");
        if (lot.isHarvested()) {
            doRecalculate(lot);
        }
        log.debug("The husking process finished...");
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("The Husking process ready...");
        if (lot.isHarvested()) {
            lot.setHuskingKgDsLot(lotDTO.getHuskingKgDsLot());
            lot.setObsHuskingKgDsLot(lotDTO.getObsHuskingKgDsLot());
            if (lotDTO.getWarehouseUnit() != null) {
                lot.setWarehouseUnit(lotDTO.getWarehouseUnit());
            }
            lot.setActualKgDsBalance(lotDTO.getHuskingKgDsLot());
            doRecalculate(lot);
        }
        log.debug("The husking process finished...");
    }

    private void doRecalculate(Lot lot) {
        getHuskingKgDsHaOperation().initialize(lot).doCalculate();
        getActualKgDsLotOperation().initialize(lot).doCalculate();
        getActualTnDsHaOperation().initialize(lot).doCalculate();
        getQualityKgFngLotOperation().initialize(lot).doCalculate();
        getActualTnDsLotHuskingOperation().initialize(lot).doCalculate();
        getGreenConversionOperation().initialize(lot).doCalculate();
        getEficienciaRwToDsOperation().initialize(lot).doCalculate();
        getEficienciaDsToFngOperation().initialize(lot).doCalculate();
    }

    public EficienciaDsToFngOperation getEficienciaDsToFngOperation() {
        return eficienciaDsToFngOperation;
    }

    public void setEficienciaDsToFngOperation(EficienciaDsToFngOperation eficienciaDsToFngOperation) {
        this.eficienciaDsToFngOperation = eficienciaDsToFngOperation;
    }

    public ActualKgDsLotOperation getActualKgDsLotOperation() {
        return actualKgDsLotOperation;
    }

    public void setActualKgDsLotOperation(ActualKgDsLotOperation actualKgDsLotOperation) {
        this.actualKgDsLotOperation = actualKgDsLotOperation;
    }

    public EficienciaRwToDsOperation getEficienciaRwToDsOperation() {
        return eficienciaRwToDsOperation;
    }

    public void setEficienciaRwToDsOperation(EficienciaRwToDsOperation eficienciaRwToDsOperation) {
        this.eficienciaRwToDsOperation = eficienciaRwToDsOperation;
    }

    public GreenConversionOperation getGreenConversionOperation() {
        return greenConversionOperation;
    }

    public void setGreenConversionOperation(GreenConversionOperation greenConversionOperation) {
        this.greenConversionOperation = greenConversionOperation;
    }

    public ActualTnDsLotHuskingOperation getActualTnDsLotHuskingOperation() {
        return actualTnDsLotHuskingOperation;
    }

    public void setActualTnDsLotHuskingOperation(ActualTnDsLotHuskingOperation actualTnDsLotHuskingOperation) {
        this.actualTnDsLotHuskingOperation = actualTnDsLotHuskingOperation;
    }

    public QualityKgFngLotHuskingOperation getQualityKgFngLotOperation() {
        return qualityKgFngLotOperation;
    }

    public void setQualityKgFngLotOperation(QualityKgFngLotHuskingOperation qualityKgFngLotOperation) {
        this.qualityKgFngLotOperation = qualityKgFngLotOperation;
    }

    public ActualTnDsHaOperation getActualTnDsHaOperation() {
        return actualTnDsHaOperation;
    }

    public void setActualTnDsHaOperation(ActualTnDsHaOperation actualTnDsHaOperation) {
        this.actualTnDsHaOperation = actualTnDsHaOperation;
    }


    public HuskingKgDsHaOperation getHuskingKgDsHaOperation() {
        return huskingKgDsHaOperation;
    }

    public void setHuskingKgDsHaOperation(HuskingKgDsHaOperation huskingKgDsHaOperation) {
        this.huskingKgDsHaOperation = huskingKgDsHaOperation;
    }
}
