package com.monsanto.prisma.core.workflow.process.lot;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.joda.time.DateTime;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Created by AFREI on 15/07/2014.
 */
@Component
public class EstimatedFloweringDateOperation extends AbstractProcessOperation {

    public EstimatedFloweringDateOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Date>(lot.getPlantingDate(), "process.precondition.notNull.estimatedPlantingDate"),
                new NullValidator<Integer>(lot.getPlantFlowDays(), "process.precondition.notNull.plantFlowDays"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        DateTime date = new DateTime(lot.getPlantingDate());
        date = date.plusDays(lot.getPlantFlowDays());
        lot.setEstimatedFloweringDate(date.toDate());
        lot.setFloweringDate(lot.getEstimatedFloweringDate());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        //do nothing
    }
}
