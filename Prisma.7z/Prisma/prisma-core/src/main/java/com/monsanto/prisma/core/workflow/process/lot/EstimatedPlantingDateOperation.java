package com.monsanto.prisma.core.workflow.process.lot;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Created by AFREI on 15/07/2014.
 */
@Component
public class EstimatedPlantingDateOperation extends AbstractProcessOperation {

    public EstimatedPlantingDateOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Integer>(lot.getPlantingWeek(), "process.precondition.notNull.plantingWeek"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        Date dayOfWeekPlanting = Utilities.getDateFromNumberWeek(lot.getPlantingWeek());
        lot.setEstimatedPlantingDate(dayOfWeekPlanting);
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setEstimatedPlantingDate(null);
    }
}
