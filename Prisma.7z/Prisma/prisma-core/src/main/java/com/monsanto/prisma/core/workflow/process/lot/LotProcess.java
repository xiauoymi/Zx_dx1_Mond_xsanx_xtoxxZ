package com.monsanto.prisma.core.workflow.process.lot;

import com.monsanto.prisma.core.domain.Establishment;
import com.monsanto.prisma.core.domain.Hybrid;
import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.repository.EstablishmentRepository;
import com.monsanto.prisma.core.repository.HybridRepository;
import com.monsanto.prisma.core.service.MasterdataService;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import org.apache.log4j.Logger;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

/**
 * Created by PGSETT on 03/06/2014.
 */
public class LotProcess extends com.monsanto.prisma.core.workflow.Process {

    private static Logger log = Logger.getLogger(LotProcess.class);

    @Autowired
    private MasterdataService masterdataService;

    @Autowired
    @Qualifier("establishmentRepository")
    private EstablishmentRepository establishmentRepository;

    @Autowired
    private HybridRepository hybridRepository;

    @Autowired
    EstimatedPlantingDateOperation estimatedPlantingDateOperation;
    @Autowired
    EstimatedFloweringDateOperation estimatedFloweringDateOperation;
    @Autowired
    EstimatedHarvestDateOperation estimatedHarvestDateOperation;

    @Override
    public void doProcess(Lot lot) throws DataAccessException, BusinessException {
        log.debug("Start Lot process");
        if (!lot.isPlanted()) {
            doRecalculate(lot);
            log.debug("Finished Lot process");
        }
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("Start Lot process");
//        if (!lot.isPlanted()) {
//            parseLot(lot, lotDTO);
//            doRecalculate(lot);
//        }
        if (!lot.isPlanted()) {
            parsePlantedLot(lot, lotDTO);
            doRecalculate(lot);
        }
        if (!lot.isHarvested()) {
            parseHarvestedLot(lot, lotDTO);
            doRecalculate(lot);
        }
        log.debug("Finished Lot process");
    }

    private void doRecalculate(Lot lot) throws DataAccessException, BusinessException {
        estimatedPlantingDateOperation.initialize(lot).doCalculate();
        lot.setPlantingDate(lot.getEstimatedPlantingDate());
        estimatedFloweringDateOperation.initialize(lot).doCalculate();
        lot.setFloweringDate(lot.getEstimatedFloweringDate());
        estimatedHarvestDateOperation.initialize(lot).doCalculate();
        lot.setHarvestDate(lot.getEstimatedHarvestDate());
        DateTime dateTime = new DateTime(lot.getHarvestDate());
        lot.setHarvestWeek(new Float(dateTime.getWeekOfWeekyear()));
    }

    public void parsePlantedLot(Lot lot, LotDTO lotDTO) throws DataAccessException, BusinessException {
        parseMainInformation(lot, lotDTO);

        parseDates(lot, lotDTO);

        parseEstablishment(lot, lotDTO);

        lot = parseHybrid(lot, lotDTO);

        parseFile(lot, lotDTO);

        parseObservations(lot, lotDTO);
    }

    public void parseHarvestedLot(Lot lot, LotDTO lotDTO) throws DataAccessException, BusinessException {
        if (lotDTO.getLotCode() != null) {
            lot.setLotCode(lotDTO.getLotCode());
        }
        parseHas(lot, lotDTO);
    }

    private void parseMainInformation(Lot lot, LotDTO lotDTO) {


        if (lotDTO.getMegazone() != null) {
            lot.setMegazone(lotDTO.getMegazone());
        }

        if (lotDTO.getCertification() != null) {
            lot.setCertification(lotDTO.getCertification());
        }

        if (lotDTO.getProgram() != null) {
            lot.setProgram(lotDTO.getProgram());
        }

        if (lotDTO.getExpediente() != null) {
            lot.setExpediente(lotDTO.getExpediente());
        }

        if (lotDTO.getColor() != null) {
            lot.setColor(lotDTO.getColor());
        }

        if (lotDTO.getClient() != null) {
            lot.setClient(lotDTO.getClient());
        }

        if (lotDTO.getGranProgram() != null) {
            lot.setGranProgram(lotDTO.getGranProgram());
        }

        if (lotDTO.getGermoplasma() != null) {
            lot.setGermoplasma(lotDTO.getGermoplasma());
        }
    }

    private void parseDates(Lot lot, LotDTO lotDTO) {
        if (lotDTO.getPlantingWeek() != null) {
            lot.setPlantingWeek(lotDTO.getPlantingWeek());
        }
    }

    private void parseEstablishment(Lot lot, LotDTO lotDTO) {
        if (lotDTO.getEstablishmentId() != null) {
            Establishment establishment = establishmentRepository.findOne(lotDTO.getEstablishmentId());
            lot.setEstablishment(establishment);
        }
    }

    private void parseFile(Lot lot, LotDTO lotDTO) {
        if (lotDTO.getFile() != null) {
            lot.setFile(lotDTO.getFile());
        }
        if (lotDTO.getSourceLotFile() != null) {
            lot.setSourceLotFile(lotDTO.getSourceLotFile());
        }
    }

    private void parseObservations(Lot lot, LotDTO lotDTO) {
        if (lotDTO.getObservation() != null && !lotDTO.getObservation().equals("")) {
            lot.setObservation(lotDTO.getObservation());
        }

        if (lotDTO.getObsLine() != null) {
            lot.setObsLine(lotDTO.getObsLine());
        }
        if (lotDTO.getGeneralObs() != null) {
            lot.setGeneralObs(lotDTO.getGeneralObs());
        }
    }


    private void parseHas(Lot lot, LotDTO lotDTO) {
        if (lotDTO.getHarvestableHas() != null) {
            lot.setHarvestableHas(lotDTO.getHarvestableHas());
        }

        if (lotDTO.getRegisteredHas() != null) {
            lot.setRegisteredHas(lotDTO.getRegisteredHas());
        }
    }

    private Lot parseHybrid(Lot lot, LotDTO lotDTO) throws DataAccessException, BusinessException {
        if (lotDTO.getHybridName() != null && (lotDTO.getIsHybridModified() || lotDTO.getIsMegazoneModified())) {
            Hybrid hybrid = hybridRepository.findByName(lotDTO.getHybridName());
            lot.setHybrid(hybrid);
            lot = masterdataService.processMasterdata(lot);
            lotDTO.setTargetRwToDs(lot.getTargetRwToDs());
            lotDTO.setTargetDsToFng(lot.getTargetDsToFng());
            lotDTO.setTargetKgBag(lot.getTargetKgBag());
            lotDTO.setTargetBagHa(lot.getTargetBagHa());
            lotDTO.setFlowHarvDays(lot.getFlowHarvDays());
            lotDTO.setPlantFlowDays(lot.getPlantFlowDays());
        }
        return lot;
    }
}