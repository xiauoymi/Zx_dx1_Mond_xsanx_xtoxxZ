package com.monsanto.prisma.core.workflow.process.payGrower;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 31/07/2014.
 */
@Component
public class BulkConversionOperation extends AbstractProcessOperation {


    public BulkConversionOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getPlsLot(), "process.precondition.notNull.plsLot"),
                new NullValidator<Float>(lot.getPlLot(), "process.precondition.notNull.plLot"),
                new NotZeroValidator<Float>(lot.getPlLot(), "process.precondition.notZero.plLot"));
        return this;
    }


    @Override
    protected void validCalculate(Lot lot) {
        lot.setBulkConversion(lot.getPlsLot() / lot.getPlLot());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setBulkConversion(null);
    }
}
