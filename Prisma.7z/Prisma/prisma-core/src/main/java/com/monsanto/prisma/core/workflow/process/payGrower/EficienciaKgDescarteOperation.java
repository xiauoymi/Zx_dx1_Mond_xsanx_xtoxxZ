package com.monsanto.prisma.core.workflow.process.payGrower;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 31/07/2014.
 */
@Component
public class EficienciaKgDescarteOperation extends AbstractProcessOperation {

    public EficienciaKgDescarteOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getPlsLot(), "process.precondition.notNull.plsLot"),
                new NullValidator<Float>(lot.getPlLot(), "process.precondition.notNull.plLot"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setEficienciaKgDescarte(lot.getPlLot() - lot.getPlsLot());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setEficienciaKgDescarte(null);
    }
}