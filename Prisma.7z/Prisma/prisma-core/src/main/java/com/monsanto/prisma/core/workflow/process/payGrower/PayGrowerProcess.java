package com.monsanto.prisma.core.workflow.process.payGrower;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import com.monsanto.prisma.core.workflow.process.husking.GreenConversionOperation;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by PGSETT on 31/07/2014.
 */
@Component
public class PayGrowerProcess extends com.monsanto.prisma.core.workflow.Process {
    private static Logger log = Logger.getLogger(PayGrowerProcess.class);

    @Autowired
    private GreenConversionOperation greenConversionOperation;

    @Autowired
    private BulkConversionOperation bulkConversionOperation;

    @Autowired
    private EficienciaKgDescarteOperation eficienciaKgDescarteOperation;

    @Override
    public void doProcess(Lot lot) throws ProcessWithErrorException {
        log.info("Start pay grower process");
        getGreenConversionOperation().initialize(lot).doCalculate();
        getBulkConversionOperation().initialize(lot).doCalculate();
        getEficienciaKgDescarteOperation().initialize(lot).doCalculate();
        log.info("Finnish pay grower process");
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        // do nothing.
    }

    public GreenConversionOperation getGreenConversionOperation() {
        return greenConversionOperation;
    }

    public void setGreenConversionOperation(GreenConversionOperation greenConversionOperation) {
        this.greenConversionOperation = greenConversionOperation;
    }

    public BulkConversionOperation getBulkConversionOperation() {
        return bulkConversionOperation;
    }

    public void setBulkConversionOperation(BulkConversionOperation bulkConversionOperation) {
        this.bulkConversionOperation = bulkConversionOperation;
    }

    public EficienciaKgDescarteOperation getEficienciaKgDescarteOperation() {
        return eficienciaKgDescarteOperation;
    }

    public void setEficienciaKgDescarteOperation(EficienciaKgDescarteOperation eficienciaKgDescarteOperation) {
        this.eficienciaKgDescarteOperation = eficienciaKgDescarteOperation;
    }
}
