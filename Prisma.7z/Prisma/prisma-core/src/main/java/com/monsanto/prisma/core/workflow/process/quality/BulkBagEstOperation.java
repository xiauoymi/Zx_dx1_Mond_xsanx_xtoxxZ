package com.monsanto.prisma.core.workflow.process.quality;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

@Component
public class BulkBagEstOperation extends AbstractProcessOperation {

    public BulkBagEstOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getQualityKgFngLot(), "process.precondition.notNull.qualityKgFngLot"),
                new NullValidator<Float>(lot.getQualityWeightBag(), "process.precondition.notNull.qualityWeightBag"),
                new NotZeroValidator<Float>(lot.getQualityWeightBag(), "process.precondition.notZero.qu"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setBulkBagEst(lot.getQualityKgFngLot() / lot.getQualityWeightBag());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setBulkBagEst(null);
    }
}
