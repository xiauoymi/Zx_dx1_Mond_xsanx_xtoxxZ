package com.monsanto.prisma.core.workflow.process.quality;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

@Component
public class BulkBagHaEstOperation extends AbstractProcessOperation {

    public BulkBagHaEstOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getBulkBagEst(), "process.precondition.notNull.bulkBagHaEst"),
                new NullValidator<Float>(lot.getHarvestableHas(), "process.precondition.notNull.harvestableHas"),
                new NotZeroValidator<Float>(lot.getHarvestableHas(), "process.precondition.notZero.harvestableHas"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setBulkBagHaEst(lot.getBulkBagEst() / lot.getHarvestableHas());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setBulkBagHaEst(null);
    }
}
