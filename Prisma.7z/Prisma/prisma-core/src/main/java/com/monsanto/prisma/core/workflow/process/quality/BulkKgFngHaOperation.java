package com.monsanto.prisma.core.workflow.process.quality;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NotZeroValidator;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

@Component
public class BulkKgFngHaOperation extends AbstractProcessOperation {

    public BulkKgFngHaOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getQualityKgFngLot(), "process.precondition.notNull.qualityKgFngLot"),
                new NullValidator<Float>(lot.getHarvestableHas(), "process.precondition.notNull.harvestableHas"),
                new NotZeroValidator<Float>(lot.getHarvestableHas(), "process.precondition.notZero.harvestableHas"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setBulkKgFNGHa(lot.getQualityKgFngLot() / lot.getHarvestableHas());
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setBulkKgFNGHa(null);
    }
}
