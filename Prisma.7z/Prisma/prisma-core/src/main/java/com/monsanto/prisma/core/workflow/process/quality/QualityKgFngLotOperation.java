package com.monsanto.prisma.core.workflow.process.quality;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.workflow.process.AbstractProcessOperation;
import com.monsanto.prisma.core.workflow.process.validation.NullValidator;
import org.springframework.stereotype.Component;

@Component
public class QualityKgFngLotOperation extends AbstractProcessOperation {

    public QualityKgFngLotOperation initialize(Lot lot) {
        this.lot = lot;
        initializeValidators(
                new NullValidator<Float>(lot.getQualityDsToFng(), "process.precondition.notNull.qualityKgFngLot"),
                new NullValidator<Float>(lot.getActualKgDsLot(), "process.precondition.notNull.qualityDsToFng"));
        return this;
    }

    @Override
    protected void validCalculate(Lot lot) {
        lot.setQualityKgFngLot(new Float(lot.getQualityDsToFng() * lot.getActualKgDsLot()));
        lot.setEstimatedTnFngLot(lot.getQualityKgFngLot() / Constants.NUMBER_MIL);
    }

    @Override
    protected void inValidCalculate(Lot lot) {
        lot.setQualityKgFngLot(null);
    }
}
