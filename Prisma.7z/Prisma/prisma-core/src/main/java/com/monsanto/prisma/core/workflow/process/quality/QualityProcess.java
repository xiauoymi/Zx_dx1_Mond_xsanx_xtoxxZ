package com.monsanto.prisma.core.workflow.process.quality;

import com.monsanto.prisma.core.domain.Lot;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.workflow.Process;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class QualityProcess extends Process {
    private static Logger log = Logger.getLogger(QualityProcess.class);

    @Autowired
    private QualityKgFngLotOperation qualityKgFngLotOperation;
    @Autowired
    private BulkBagEstOperation bulkBagEstOperation;
    @Autowired
    private BulkBagHaEstOperation bulkBagHaEstOperation;
    @Autowired
    private BulkKgFngHaOperation bulkKgFngHaOperation;

    @Override
    public void doProcess(Lot lot) throws ProcessWithErrorException {
        log.debug("Start quality process");
        doRecalculate(lot);
        log.debug("Finished quality process");
    }

    @Override
    public void doProcess(Lot lot, LotDTO lotDTO) throws ProcessWithErrorException, DataAccessException, BusinessException {
        log.debug("Start quality process");

        lot.setQualityDsToFng(lotDTO.getQualityDsToFng());
        lot.setQualityWeightBag(lotDTO.getQualityWeightBag());
        if (lotDTO.getQualityObs() != null) {
            lot.setQualityObs(lotDTO.getQualityObs());
        }

        doRecalculate(lot);

        log.debug("Finished quality process");
    }

    private void doRecalculate(Lot lot) {
        getQualityKgFngLotOperation().initialize(lot).doCalculate();
        getBulkBagEstOperation().initialize(lot).doCalculate();
        getBulkBagHaEstOperation().initialize(lot).doCalculate();
        getBulkKgFngHaOperation().initialize(lot).doCalculate();
    }

    public QualityKgFngLotOperation getQualityKgFngLotOperation() {
        return qualityKgFngLotOperation;
    }

    public void setQualityKgFngLotOperation(QualityKgFngLotOperation qualityKgFngLotOperation) {
        this.qualityKgFngLotOperation = qualityKgFngLotOperation;
    }

    public BulkBagEstOperation getBulkBagEstOperation() {
        return bulkBagEstOperation;
    }

    public void setBulkBagEstOperation(BulkBagEstOperation bulkBagEstOperation) {
        this.bulkBagEstOperation = bulkBagEstOperation;
    }

    public BulkBagHaEstOperation getBulkBagHaEstOperation() {
        return bulkBagHaEstOperation;
    }

    public void setBulkBagHaEstOperation(BulkBagHaEstOperation bulkBagHaEstOperation) {
        this.bulkBagHaEstOperation = bulkBagHaEstOperation;
    }

    public BulkKgFngHaOperation getBulkKgFngHaOperation() {
        return bulkKgFngHaOperation;
    }

    public void setBulkKgFngHaOperation(BulkKgFngHaOperation bulkKgFngHaOperation) {
        this.bulkKgFngHaOperation = bulkKgFngHaOperation;
    }
}
