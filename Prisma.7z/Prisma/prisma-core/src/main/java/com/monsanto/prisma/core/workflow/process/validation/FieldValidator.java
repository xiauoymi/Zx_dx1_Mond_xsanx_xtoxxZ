package com.monsanto.prisma.core.workflow.process.validation;

public interface FieldValidator{
        public void verify();
    }