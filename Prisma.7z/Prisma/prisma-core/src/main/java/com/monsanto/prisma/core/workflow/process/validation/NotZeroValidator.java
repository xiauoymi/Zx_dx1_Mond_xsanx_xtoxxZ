package com.monsanto.prisma.core.workflow.process.validation;

import com.google.common.base.Verify;

public class NotZeroValidator<T extends Number> implements FieldValidator {

    private final String[] args;
    private T obj;
    private String message;

    public NotZeroValidator(T obj, String message, String... args) {
        this.obj = obj;
        this.message = message;
        this.args = args;
    }

    public void verify() {
        Verify.verify(obj.doubleValue() > 0, message, args);
    }
}