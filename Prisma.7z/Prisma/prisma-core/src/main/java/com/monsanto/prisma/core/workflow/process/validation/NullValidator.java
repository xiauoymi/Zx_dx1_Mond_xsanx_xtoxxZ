package com.monsanto.prisma.core.workflow.process.validation;

import com.google.common.base.Verify;

public class NullValidator<T extends Object> implements FieldValidator {

        private final String[] args;
        private T obj;
        private String message;

        public NullValidator(T obj, String message, String... args) {
            this.obj = obj;
            this.message = message;
            this.args = args;
        }

        public void verify(){
            Verify.verifyNotNull(obj, message, args);
        }
    }