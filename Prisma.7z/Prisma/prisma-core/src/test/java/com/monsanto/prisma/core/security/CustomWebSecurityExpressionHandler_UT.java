package com.monsanto.prisma.core.security;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.security.access.expression.SecurityExpressionRoot;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;

import static org.powermock.api.mockito.PowerMockito.mock;

/**
 * Created by EPESTE on 20/10/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class CustomWebSecurityExpressionHandler_UT {
    private CustomWebSecurityExpressionHandler customWebSecurityExpressionHandler;

    @Before
    public void setUp() {
        customWebSecurityExpressionHandler = new CustomWebSecurityExpressionHandler();
    }

    @Test
    public void createSecurityExpressionRoot_withAuthenticationAndFilter_returnSecurityExpressionRoot() {
        final Authentication authenticationMock = mock(Authentication.class);
        final FilterInvocation filterInvocationMock = mock(FilterInvocation.class);
        SecurityExpressionRoot securityExpressionRoot = customWebSecurityExpressionHandler.createSecurityExpressionRoot(authenticationMock, filterInvocationMock);
        Assert.assertNotNull(securityExpressionRoot);

    }
}
