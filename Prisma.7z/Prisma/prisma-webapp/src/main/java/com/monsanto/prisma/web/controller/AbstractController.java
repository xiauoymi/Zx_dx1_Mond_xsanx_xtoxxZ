package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by BSBUON on 6/10/2014.
 */
public abstract class AbstractController {

    @Autowired
    private MessageCurrentLocaleResolver message;

    public String getMessage(String code){
        return message.getMessage(code);
    }
}
