package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.dto.*;
import com.monsanto.prisma.core.exception.BatchException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.exception.ExistsBatchWithNameException;
import com.monsanto.prisma.core.exception.KgDsAssignedInvalidException;
import com.monsanto.prisma.core.service.BatchService;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.HybridService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;


@Controller
@RequestMapping("/campaign/batch")
public class BatchController extends AbstractController {

    private static Logger log = Logger.getLogger(BatchController.class);

    public static final String BATCH_LIST = "batchList";
    public static final String BATCH_DETAIL = "batchDetail";
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";

    @Autowired
    private BatchService batchService;

    @Autowired
    private HybridService hybridService;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private LotService lotService;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    public ModelAndView init(HttpServletRequest request) {
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        return batchView(campaignId);
    }

    @RequestMapping(value = "/", method = RequestMethod.POST)
    public ModelAndView init(@RequestParam("campaignId") Integer campaignId) {
        return batchView(campaignId);
    }

    private ModelAndView batchView(Integer campaignId) {
        ModelAndView result = new ModelAndView(BATCH_LIST);

        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        result.addObject("campaignId", campaignId);
        result.addObject("campaign", campaignDTO);

        List<BatchDTO> batchDTOs = batchService.findByCampaignId(campaignId);
        result.addObject("batches", batchDTOs);

        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        result.addObject(TOTAL_LOTS_HAS, totalLotsDTO);

        return result;
    }

    @RequestMapping(value = "/detail", method = RequestMethod.POST)
    public ModelAndView detail(@RequestParam(value = "campaignId") Integer campaignId, @RequestParam(value = "batchId") Integer batchId) {
        ModelAndView result = new ModelAndView(BATCH_DETAIL);

        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        result.addObject("campaignId", campaignId);
        result.addObject("campaign", campaignDTO);

        List<HybridDTO> hybridDTOs = hybridService.findByCampaignId(campaignId);
        result.addObject("hybrids", hybridDTOs);

        BatchDTO batchDTO = batchService.findById(batchId);
        result.addObject("batch", batchDTO);

        List<LotBatchDTO> lotBatchDTOs = batchService.findLotsAssociated(batchId);
        result.addObject("associatedLots", lotBatchDTOs);
        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        result.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
        return result;
    }

    @RequestMapping(value = "/{batchId}/lots", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public JsonResponse<LotBatchDTO> findLotsAssociated(@PathVariable("batchId") Integer batchId) {
        List<LotBatchDTO> lotBatchDTOs = batchService.findLotsAssociated(batchId);
        return new JsonResponse<LotBatchDTO>(lotBatchDTOs);
    }

    @RequestMapping(value = "/addLot", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public JsonResponse<LotBatchDTO> addLot(@RequestBody Map request) throws DataAccessException {
        Integer lotId = (Integer) request.get("lotId");
        String kgDsLotAssigned = (String) request.get("kgDsLotAssigned");
        String kgDS = (String) request.get("kgDS");
        String kgFNG = (String) request.get("kgFNG");
        String bagProduced = (String) request.get("bagProduced");
        LotBatchDTO result = null;
        try {
            result = batchService.addLot(lotId, Float.parseFloat(kgDsLotAssigned), Float.parseFloat(kgDS),
                    Float.parseFloat(kgFNG), Integer.parseInt(bagProduced));

        } catch (KgDsAssignedInvalidException e) {
            log.debug("Kg Ds Assigned incorrect - " + e.getMessage(), e);
            return new JsonResponse<LotBatchDTO>(false, getMessage("batch.msg.kg.ds.assigned.greater"));
        }
        return new JsonResponse<LotBatchDTO>(result);
    }

    @RequestMapping(value = "/detail", method = RequestMethod.POST, consumes = {"application/json"}, produces = "application/json")
    @ResponseBody
    public JsonResponse<BatchDTO> save(@RequestBody BatchDTO batchDTO) {
        log.debug("Creating Batch...");
        try {
            BatchDTO newBatch = batchService.save(batchDTO);
            log.debug(getMessage("batch.save.success"));
            return new JsonResponse<BatchDTO>(getMessage("batch.save.success"), newBatch);
        } catch (ExistsBatchWithNameException e1) {
            log.error(e1.getMessage(), e1);
            return new JsonResponse<BatchDTO>(false, getMessage("batch.exists.with.same.name"));
        } catch (BatchException e2) {
            log.error(e2.getMessage(), e2);
            return new JsonResponse<BatchDTO>(false, getMessage("application.unexpectederror"));
        }
    }

    @RequestMapping(value = "/delete", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public JsonResponse<BatchDTO> delete(@RequestBody Integer batchId) {
        try {
            log.debug("Deleting Batch: " + batchId);
            batchService.delete(batchId);
            log.debug(getMessage("batch.delete.success"));
            return new JsonResponse<BatchDTO>(true, getMessage("batch.delete.success"));
        } catch (BatchException e) {
            log.error(getMessage("batch.delete.error"), e);
            return new JsonResponse<BatchDTO>(false, getMessage("application.unexpectederror"));
        }

    }
}
