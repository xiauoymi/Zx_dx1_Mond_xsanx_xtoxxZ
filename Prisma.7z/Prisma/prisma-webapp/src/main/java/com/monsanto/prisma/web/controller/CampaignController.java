package com.monsanto.prisma.web.controller;

/**
 * Created with IntelliJ IDEA.
 * User: BSBUON
 * Date: 12/05/14
 * Time: 13:30
 * To change this template use File | Settings | File Templates.
 */

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.exception.*;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.CountryService;
import com.monsanto.prisma.core.service.CropService;
import com.monsanto.prisma.core.service.RegionService;
import com.monsanto.prisma.web.dto.CountryDTO;
import com.monsanto.prisma.web.dto.CropDTO;
import com.monsanto.prisma.web.dto.RegionDTO;
import com.monsanto.prisma.web.security.SecurityHolderStrategy;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
@RequestMapping("/campaign")
public class CampaignController extends AbstractController {

    private static Logger log = Logger.getLogger(CampaignController.class);

    public static final String CAMPAIGN_LIST = "campaignList";

    public static final String MESSAGE_SAVE_SUCCESS = "campaign.save.success";

    public static final String MESSAGE_CAMPAIGN_MAX_BY_SEASON = "campaign.max.by.season";

    public static final String MESSAGE_CAMPAIGN_NAME_DUPLICATED = "campaign.name.duplicated";

    public static final String MESSAGE_APPLICATION_UNEXPECTED_ERROR = "application.unexpectederror";

    public static final String MESSAGE_CAMPAIGN_UPDATE_SUCCESS = "campaign.update.success";

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private CropService cropService;

    @Autowired
    private RegionService regionService;

    @Autowired
    private CountryService countryService;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    @RequestMapping(value = "/init", method = RequestMethod.GET)
    public ModelAndView init() {
        ModelAndView result = new ModelAndView(CAMPAIGN_LIST);

        List<CropDTO> crops = Lists.transform(cropService.findAll(), new Function<Crop, CropDTO>() {
            @Override
            public CropDTO apply(Crop crop) {
                return new CropDTO(crop);
            }
        });
        result.addObject("crops", crops);
        User user = securityHolderStrategy.getCurrentUser();
        List<Region> regions = user != null && user.getRegions() != null ?
                user.getRegions() :
                regionService.findAll();

        List<RegionDTO> regionDTOs = Lists.transform(regions, new Function<Region, RegionDTO>() {
            @Override
            public RegionDTO apply(Region region) {
                return new RegionDTO(region);
            }
        });
        result.addObject("regions", regionDTOs);

        List<CountryDTO> countries = Lists.transform(countryService.findAll(), new Function<Country, CountryDTO>() {
            @Override
            public CountryDTO apply(Country country) {
                return new CountryDTO(country);
            }
        });
        result.addObject("countries", countries);

        List<Campaign> campaigns = user == null ?
                campaignService.findAll() :
                campaignService.findByRegion(user.getRegions());

        List<CampaignDTO> campaignDTOs = Lists.transform(campaigns, new Function<Campaign, CampaignDTO>() {
            @Override
            public CampaignDTO apply(Campaign campaign) {
                return new CampaignDTO(campaign);
            }
        });

        result.addObject(CAMPAIGN_LIST, campaignDTOs);


        log.debug("Campaigns INIT.");
        return result;
    }


    @RequestMapping(value = "/", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse<CampaignDTO> findAll() {
        User user = securityHolderStrategy.getCurrentUser();
        List<Campaign> campaigns = user == null ?
                campaignService.findAll() :
                campaignService.findByRegion(user.getRegions());

        List<CampaignDTO> campaignDTOs = Lists.transform(campaigns, new Function<Campaign, CampaignDTO>() {
            @Override
            public CampaignDTO apply(Campaign campaign) {
                return new CampaignDTO(campaign);
            }
        });

        log.debug("returned all campaigns.");
        return new JsonResponse<CampaignDTO>(campaignDTOs);
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public JsonResponse<CampaignDTO> findById(@PathVariable Integer id) {
        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(id);
        return campaignDTO != null ?
                new JsonResponse<CampaignDTO>(campaignDTO) :
                new JsonResponse<CampaignDTO>(false, getMessage("campaign.not.exists"));
    }

    @RequestMapping(method = RequestMethod.POST, consumes = {"application/json", "application/x-www-form-urlencoded"}, produces = "application/json")
    @ResponseBody
    public JsonResponse<CampaignDTO> save(@RequestBody CampaignDTO campaignDTO) {
        log.debug("Creating Campaign: ");
        try {
            Campaign campaign = campaignService.save(campaignDTO);
            log.debug(getMessage(MESSAGE_SAVE_SUCCESS));
            return new JsonResponse<CampaignDTO>(getMessage(MESSAGE_SAVE_SUCCESS), new CampaignDTO(campaign));
        } catch (MaxCampaignsForSeasonException e1) {
            log.error(getMessage(MESSAGE_CAMPAIGN_MAX_BY_SEASON) + e1.getMessage(), e1);
            return new JsonResponse<CampaignDTO>(false, getMessage(MESSAGE_CAMPAIGN_MAX_BY_SEASON) + e1.getMessage());
        } catch (SeasonNotExistsException e2) {
            log.error("Not Exists Season for this Crop-Country : " + campaignDTO.getCropName() + " country: " + campaignDTO.getCountryName(), e2);
            return new JsonResponse<CampaignDTO>(false, getMessage("campaign.not.exists.season") + campaignDTO.getCropName() + " country: " + campaignDTO.getCountryName());
        } catch (CampaignNameDuplicatedException e3) {
            log.error("Campaign Name duplicated " + campaignDTO.getName(), e3);
            return new JsonResponse<CampaignDTO>(false, getMessage(MESSAGE_CAMPAIGN_NAME_DUPLICATED));
        } catch (CampaignException e) {
            log.error(getMessage("campaign.save.error"), e);
            return new JsonResponse<CampaignDTO>(false, getMessage(MESSAGE_APPLICATION_UNEXPECTED_ERROR));
        }
    }

    @RequestMapping(method = RequestMethod.PUT, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public JsonResponse<CampaignDTO> update(@RequestBody CampaignDTO campaignDTO) {
        try {
            log.debug("Editing Campaign: " + campaignDTO.getId());
            Campaign campaign = campaignService.update(campaignDTO);
            log.debug(getMessage(MESSAGE_CAMPAIGN_UPDATE_SUCCESS));
            return new JsonResponse<CampaignDTO>(getMessage(MESSAGE_CAMPAIGN_UPDATE_SUCCESS), new CampaignDTO(campaign));
        } catch (MaxCampaignsForSeasonException e1) {
            log.error(getMessage(MESSAGE_CAMPAIGN_MAX_BY_SEASON) + e1.getMessage(), e1);
            return new JsonResponse<CampaignDTO>(false, getMessage(MESSAGE_CAMPAIGN_MAX_BY_SEASON) + e1.getMessage());
        } catch (InactiveToUpdateCampaignException e2) {
            log.error(getMessage("campaign.inactive.to.modify"), e2);
            return new JsonResponse<CampaignDTO>(false, getMessage("campaign.inactive.to.modify"));
        } catch (CampaignUnableToChangeException e3) {
            log.error(getMessage("campaign.unable.to.change"), e3);
            return new JsonResponse<CampaignDTO>(false, getMessage("campaign.unable.to.change"));
        } catch (InvalidCampaignPathException e4) {
            log.error(getMessage("campaign.invalid.path"), e4);
            return new JsonResponse<CampaignDTO>(false, getMessage("campaign.invalid.path"));
        } catch (CampaignNameDuplicatedException e5) {
            log.error("Campaign Name duplicated " + campaignDTO.getName(), e5);
            return new JsonResponse<CampaignDTO>(false, getMessage(MESSAGE_CAMPAIGN_NAME_DUPLICATED));
        } catch (Exception e) {
            log.error(getMessage("campaign.update.error"), e);
            return new JsonResponse<CampaignDTO>(false, getMessage(MESSAGE_APPLICATION_UNEXPECTED_ERROR));
        }
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.PUT, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public JsonResponse<CampaignDTO> changeState(@PathVariable Integer id) {
        log.debug("Change State Campaign: " + id);
        campaignService.changeState(id);
        return new JsonResponse<CampaignDTO>(true, getMessage(MESSAGE_CAMPAIGN_UPDATE_SUCCESS));
    }


    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public JsonResponse<CampaignDTO> delete(@PathVariable Integer id) {
        try {
            log.debug("Deleting Campaign: " + id);
            Campaign campaign = campaignService.delete(id);
            log.debug(getMessage("campaign.delete.success"));
            return new JsonResponse<CampaignDTO>(getMessage("campaign.delete.success"), new CampaignDTO(campaign));
        } catch (ExistsLotsForThisCampaignException e1) {
            log.error(getMessage("campaign.exists.lots"), e1);
            return new JsonResponse<CampaignDTO>(false, getMessage("campaign.delete.error") + " " + getMessage("campaign.exists.lots"));
        } catch (CampaignException e) {
            log.error(getMessage("campaign.delete.error"), e);
            return new JsonResponse<CampaignDTO>(false, getMessage(MESSAGE_APPLICATION_UNEXPECTED_ERROR));
        }

    }
}
