package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Country;
import com.monsanto.prisma.core.domain.Region;
import com.monsanto.prisma.core.service.CountryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by BSBUON on 5/28/2014.
 */
@Controller
@RequestMapping("/country")
public class CountryController {

    @Autowired
    private CountryService countryService;

    @RequestMapping(value = "/region/", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    public List<Country> findByRegionId(@RequestBody Region region) {
        return countryService.findByRegionId(region.getId());
    }
}
