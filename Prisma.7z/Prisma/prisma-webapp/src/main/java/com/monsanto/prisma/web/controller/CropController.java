package com.monsanto.prisma.web.controller;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.Crop;
import com.monsanto.prisma.core.service.CropService;
import com.monsanto.prisma.web.dto.CropDTO;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

/**
 * Created by BSBUON on 5/19/2014.
 */
@Controller
@RequestMapping("/crop")
public class CropController {

    private static Logger log = Logger.getLogger(CropController.class);

    @Autowired
    private CropService cropService;

    public JsonResponse<CropDTO> findAll() {
        try {
            List<CropDTO> crops = Lists.transform(cropService.findAll(), new Function<Crop, CropDTO>() {
                @Override
                public CropDTO apply(Crop crop) {
                    return new CropDTO(crop);
                }
            });
            return new JsonResponse<CropDTO>(crops);
        } catch (Exception e) {
            String message = "Error al buscar Crops";
            log.error(message, e);
            return new JsonResponse<CropDTO>(false, message);
        }
    }
}
