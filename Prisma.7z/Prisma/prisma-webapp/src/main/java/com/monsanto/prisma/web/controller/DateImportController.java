package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.LotDate;
import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.DateImportService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.web.security.SecurityHolderStrategy;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by PGSETT on 28/10/2014.
 */
@Controller
@RequestMapping(value = "/dateImport")
public class DateImportController extends AbstractController {

    private static Logger log = Logger.getLogger(DateImportController.class);

    private static final String DATE_IMPORT_PAGE = "dateImport";
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";
    @Autowired
    private DateImportService dateImportService;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private LotService lotService;


    @RequestMapping(value = "/campaign/", method = RequestMethod.GET)
    public ModelAndView init(HttpServletRequest request) {
        log.info("Open date import page.");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        return dateImportView(campaignId);
    }

    @RequestMapping(value = "/campaign/", method = RequestMethod.POST)
    public ModelAndView init(@RequestParam("campaignId") Integer campaignId) {
        log.info("Open date import.");
        return dateImportView(campaignId);
    }

    private ModelAndView dateImportView(Integer campaignId) {
        ModelAndView page = new ModelAndView(DATE_IMPORT_PAGE);
        page.addObject("campaignId", campaignId);
        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        page.addObject("campaign", campaignDTO);
        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
        return page;
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<LotDate> updateLotFromDateImport(@RequestBody Integer campaignId) throws BusinessException {
        LotDate lotDate;
        try {
            User user = securityHolderStrategy.getCurrentUser();
            lotDate = dateImportService.updateLotFromDateImport(campaignId, user);
        } catch (BusinessException ex) {
            log.error("Error when add lot from date import - " + ex.getMessage(), ex);
            return new JsonResponse<LotDate>(false, ex.getLocalizedMessage());
        }
        return lotDate != null ?
                new JsonResponse<LotDate>(lotDate) : new JsonResponse<LotDate>(false, getMessage("dateImport.empty"));
    }

}
