package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.LotDitsem;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.DitsemService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by EPESTE on 28/05/2014.
 */
@Controller
@RequestMapping(value = "/ditsem")
public class DitsemController extends AbstractController {

    private static Logger log = Logger.getLogger(DitsemController.class);

    private static final String DITSEM_PAGE = "ditsem";
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";
    @Autowired
    private DitsemService ditsemService;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private LotService lotService;


    @RequestMapping(value = "/campaign/", method = RequestMethod.GET)
    public ModelAndView init(HttpServletRequest request) {
        log.info("Open ditsem page.");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        return ditsemView(campaignId);
    }

    @RequestMapping(value = "/campaign/", method = RequestMethod.POST)
    public ModelAndView init(@RequestParam("campaignId") Integer campaignId) {
        log.info("Open ditsem page.");
        return ditsemView(campaignId);
    }

    private ModelAndView ditsemView(Integer campaignId) {
        ModelAndView page = new ModelAndView(DITSEM_PAGE);
        page.addObject("campaignId", campaignId);
        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        page.addObject("campaign", campaignDTO);
        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
        return page;
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<LotDitsem> addLotsFromDitsem(@RequestBody Integer campaignId) throws BusinessException {
        LotDitsem lotDitsem;
        try {
            lotDitsem = ditsemService.addLotFromDitsem(campaignId);
        } catch (BusinessException ex) {
            log.error("Error when add lot from ditsem - " + ex.getMessage(), ex);
            return new JsonResponse<LotDitsem>(false, ex.getLocalizedMessage());
        }
        return lotDitsem != null ?
                new JsonResponse<LotDitsem>(lotDitsem) : new JsonResponse<LotDitsem>(false, getMessage("ditsem.empty"));
    }


}
