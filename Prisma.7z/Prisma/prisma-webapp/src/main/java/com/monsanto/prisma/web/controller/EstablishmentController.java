package com.monsanto.prisma.web.controller;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.Establishment;
import com.monsanto.prisma.core.dto.EstablishmentDTO;
import com.monsanto.prisma.core.dto.ZoneDTO;
import com.monsanto.prisma.core.service.EstablishmentService;
import com.monsanto.prisma.core.service.ZoneService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * Created by BSBUON on 19/09/2014.
 */

@Controller
@RequestMapping("/establishment")
public class EstablishmentController {

    @Autowired
    private EstablishmentService establishmentService;

    @Autowired
    private ZoneService zoneService;

    @RequestMapping(value = "/", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse<EstablishmentDTO> findAll() {
        List<EstablishmentDTO> list = Lists.transform(establishmentService.findAll(), new Function<Establishment, EstablishmentDTO>() {
            @Nullable
            @Override
            public EstablishmentDTO apply(@Nullable Establishment establishment) {
                return new EstablishmentDTO(establishment);
            }
        });
        return new JsonResponse<EstablishmentDTO>(list);
    }

    @RequestMapping(value = "/zones", method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<ZoneDTO> findAllZones(HttpServletRequest request) {
        Integer id = (Integer) request.getSession().getAttribute("idCampaign");
        return new JsonResponse<ZoneDTO>(zoneService.findByCampaign(id));
    }
}
