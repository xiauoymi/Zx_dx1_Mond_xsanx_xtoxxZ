package com.monsanto.prisma.web.controller;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.Filter;
import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.domain.UserFilter;
import com.monsanto.prisma.core.dto.FilterDTO;
import com.monsanto.prisma.core.service.FilterService;
import com.monsanto.prisma.core.service.UserFilterService;
import com.monsanto.prisma.core.dto.UserFilterDTO;
import com.monsanto.prisma.web.security.SecurityHolderStrategy;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.jsoup.helper.DataUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Created by epeste on 30/10/2014.
 */
@Controller
@RequestMapping(value = "/filter")
public class FilterController {

    @Autowired
    private UserFilterService userFilterService;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    @RequestMapping(value = "/user/new", method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse addNewFilter(@RequestBody UserFilterDTO userFilterDTO) {
        UserFilter userFilter = new UserFilter(userFilterDTO);
        User user = securityHolderStrategy.getCurrentUser();
        userFilter.setUser(user);

        try {
            userFilterService.save(userFilter);
        } catch (Exception e) {
            return new JsonResponse(false, "prisma.filter.new.error");
        }
        return new JsonResponse(true, "prisma.filter.new.ok");
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse findFilterByUserAndId(@RequestBody UserFilterDTO userFilterDTO) {
        User user = securityHolderStrategy.getCurrentUser();
        UserFilter userFilter = userFilterService.findByUserAndId(user, userFilterDTO.getId());
        List<FilterDTO> filterDTOList = Lists.transform(userFilter.getFilterList(), new Function<Filter, FilterDTO>() {
            @Nullable
            @Override
            public FilterDTO apply(@Nullable Filter filter) {
                return new FilterDTO(filter);
            }
        });
        return new JsonResponse(filterDTOList);
    }

    @RequestMapping(value = "/user/", method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<UserFilterDTO> findAllByUser() {
        User user = securityHolderStrategy.getCurrentUser();
        List<UserFilter> userFilterList = userFilterService.findAllByUser(user);
        List<UserFilterDTO> userFilterDTOList = Lists.transform(userFilterList, new Function<UserFilter, UserFilterDTO>() {
            @Nullable
            @Override
            public UserFilterDTO apply(@Nullable UserFilter userFilter) {
                return new UserFilterDTO(userFilter);
            }
        });


        return new JsonResponse(userFilterDTOList);
    }

    @RequestMapping(method = RequestMethod.DELETE)
    @ResponseBody
    public JsonResponse delete(@RequestBody FilterDTO filterDTO) {
        UserFilter userFilter;
        try {
            userFilter = userFilterService.delete(filterDTO.getId());
        } catch (Exception ex) {
            return new JsonResponse(false, "prisma.filter.delete.error");
        }

        return new JsonResponse("prisma.filter.delete.ok", new UserFilterDTO(userFilter));
    }


}
