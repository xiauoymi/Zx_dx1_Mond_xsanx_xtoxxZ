package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Forecast;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.ForecastDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.ForecastService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by EPESTE on 04/12/2014.
 */
@Controller
@RequestMapping(value = "/forecast")
public class ForecastController {
    @Autowired
    private ForecastService forecastService;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private LotService lotService;

    private static final String FORECAST_PAGE = "forecast";

    public static final String TOTAL_LOTS_HAS = "totalLotsHas";

    public static final String DAYS_RW = "daysRw";

    public static final String DAYS_DS = "daysDs";

    private static Logger log = Logger.getLogger(ForecastController.class);

    @RequestMapping(value = "/campaign/", method = RequestMethod.POST)
    public ModelAndView init(@RequestParam("campaignId") Integer campaignId) {
        log.debug("Init forecast page.");
        log.debug("Campaign id: " + campaignId);
        return forecastInit(campaignId);
    }

    @RequestMapping(value = "/campaign/", method = RequestMethod.GET)
    public ModelAndView init(HttpServletRequest request) {
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        ModelAndView model = forecastInit(campaignId);
        if (request.getSession().getAttribute("errorMessage") != null) {
            model.addObject("errorMessage", request.getSession().getAttribute("errorMessage"));
            request.getSession().removeAttribute("errorMessage");
        }
        return model;
    }

    private ModelAndView forecastInit(Integer campaignId) {
        ModelAndView page = new ModelAndView(FORECAST_PAGE);

        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        page.addObject("campaignId", campaignId);
        page.addObject("campaign", campaignDTO);

        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);

        Forecast forecast = forecastService.findByCampaignId(campaignId);

        log.debug("Days rw: " + forecast.getDaysRw());
        log.debug("Days ds: " + forecast.getDaysDs());

        page.addObject(DAYS_RW, forecast.getDaysRw());
        page.addObject(DAYS_DS, forecast.getDaysDs());

        return page;
    }

    @RequestMapping(method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse update(@RequestBody ForecastDTO forecastDTO) {
        try {
            forecastService.update(forecastDTO);
        } catch (Exception ex) {
            log.error(ex.getMessage(), ex);
            return new JsonResponse(false, "prisma.forecast.error");
        }
        return new JsonResponse(true, "prisma.forecast.ok");
    }


    @RequestMapping(value = "/campaign/{campaignId}/reporteActuals", method = RequestMethod.GET)
    public ModelAndView receiveTonsToExcel(@PathVariable Integer campaignId) throws DataAccessException {
        ModelAndView page = new ModelAndView("forecastReportExcel");
        page.addObject("campaignId", campaignId);
        page.addObject("forecastReportDTO", forecastService.getReportInformation(campaignId));
        return page;
    }

    @RequestMapping(value = "/campaign/{campaignId}/error", method = RequestMethod.GET)
    public String forecastError(HttpServletRequest request) {
        Integer campaignId = (Integer) request.getAttribute("campaignId");
        request.getSession().setAttribute("idCampaign", campaignId);
        request.getSession().setAttribute("errorMessage", "errorMessage");
        return "redirect:/forecast/campaign/";
    }
}
