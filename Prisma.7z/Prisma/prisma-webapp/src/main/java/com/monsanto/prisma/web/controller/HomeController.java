package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Campaign;
import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.web.security.SecurityHolderStrategy;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping(value = "/home")
public class HomeController {

    private static Logger log = Logger.getLogger(HomeController.class);
    private final String campaignIdKey = "campaignId";

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;

    @RequestMapping(method = RequestMethod.GET)
    public String home(Model model, RedirectAttributes redirectAttributes, HttpServletRequest request) throws DataAccessException {
        log.debug("Home Ready...");

        Campaign campaign = findCampaignActiveByUser();

        if (campaign != null) {
            CampaignDTO campaignDTO = new CampaignDTO(campaign);
            redirectAttributes.addFlashAttribute("campaign", campaignDTO);
        }
        Integer campaignId = (campaign != null ? campaign.getId() : 0);
        redirectAttributes.addFlashAttribute(campaignIdKey, campaignId);
        model.addAttribute(campaignIdKey, campaignId);

        HttpSession session = request.getSession();
        session.setAttribute("idCampaign", campaignId);

        log.debug("Redirecting /lot/campaign/" + campaignId);
        return "redirect:/lot/campaign/";
    }

    private Campaign findCampaignActiveByUser() throws DataAccessException {
        User user = securityHolderStrategy.getCurrentUser();
        Campaign campaign = campaignService.findCampaignActiveByUser(user);

        return campaign;
    }

}
