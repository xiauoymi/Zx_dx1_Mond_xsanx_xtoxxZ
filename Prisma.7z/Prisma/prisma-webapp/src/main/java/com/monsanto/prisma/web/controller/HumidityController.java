package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.HumidityReport;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.HumidityReportDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.HumidityReportService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Created by EPESTE on 21/08/2014.
 */
@RequestMapping(value = "/humidity")
@Controller
public class HumidityController extends AbstractController {
    private static Logger log = Logger.getLogger(HumidityController.class);
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";
    @Autowired
    private CampaignService campaignService;

    @Autowired
    private HumidityReportService humidityReportService;

    @Autowired
    private LotService lotService;

    @RequestMapping(value = "/import/campaign/", method = RequestMethod.GET)
    public ModelAndView home(HttpServletRequest request) {
        log.info("Import average humidity (GET) - Init");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        return humidityView(campaignId);
    }

    @RequestMapping(value = "/import/campaign/", method = RequestMethod.POST)
    public ModelAndView home(@RequestParam("campaignId") Integer campaignId) {
        log.info("Import average humidity (GET) - Init");
        return humidityView(campaignId);
    }

    private ModelAndView humidityView(Integer campaignId) {
        ModelAndView page = new ModelAndView();

        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);

        page.setViewName(Constants.PAGE_IMPORT_AVERAGE_HUMIDITY);
        page.addObject("campaignId", campaignId);
        page.addObject("campaign", campaignDTO);
        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
        log.info("Import average humidity (GET) - End. Forward to page " + page.getViewName());
        return page;
    }

    @RequestMapping(value = "/import/campaign/{campaignId}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse<HumidityReportDTO> importHumidityReport(@PathVariable Integer campaignId) throws IOException, InvalidFormatException, DataAccessException, BusinessException {
        log.info("Import average humidity (PUT) - Init");
        HumidityReport humidityReport = null;
        try {
            humidityReport = humidityReportService.importFile(campaignId);
        } catch (BusinessException ex) {
            log.debug("Import average humidity (PUT) - " + ex.getMessage(), ex);
            return new JsonResponse<HumidityReportDTO>(false, ex.getLocalizedMessage());
        }

        log.info("Import average humidity (PUT) - End");
        return humidityReport != null ?
                new JsonResponse<HumidityReportDTO>(new HumidityReportDTO(humidityReport)) : new JsonResponse<HumidityReportDTO>(false, getMessage("report1.notExists"));
    }
}
