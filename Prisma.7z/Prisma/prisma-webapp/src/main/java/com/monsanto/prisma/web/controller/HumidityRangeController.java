package com.monsanto.prisma.web.controller;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.HumidityRange;
import com.monsanto.prisma.core.domain.Hybrid;
import com.monsanto.prisma.core.domain.LotHumidity;
import com.monsanto.prisma.core.domain.Zone;
import com.monsanto.prisma.core.dto.HumidityRangeDTO;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.HumidityRangeService;
import com.monsanto.prisma.core.service.HybridService;
import com.monsanto.prisma.core.service.LotHumidityService;
import com.monsanto.prisma.core.service.ZoneService;
import com.monsanto.prisma.web.dto.HumidityRangeFilterDTO;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

/**
 * Created by PGSETT on 26/06/2014.
 */
@Controller
@RequestMapping("/humidityRange")
public class HumidityRangeController extends AbstractController {
    private static Logger log = Logger.getLogger(HumidityRangeController.class);

    public static final String HUMIDITY_RANGE_PAGE = "humidityRange";
    public static final String HUMIDITY_RANGE_LIST = "humidityRanges";
    public static final String HUMIDITY_RANGE_FILTER_DTO = "humidityRangeDTO";


    @Autowired
    private HumidityRangeService humidityRangeService;

    @Autowired
    private LotHumidityService lotHumidityService;

    @Autowired
    private HybridService hybridService;

    @Autowired
    private ZoneService zoneService;

    @Autowired
    private MessageCurrentLocaleResolver message;

    @RequestMapping(value = "/init", method = RequestMethod.GET)
    public ModelAndView init() {
        log.info("Open MASTERDATA page.");

        ModelAndView result = new ModelAndView(HUMIDITY_RANGE_PAGE);

        List<Hybrid> hybrids = hybridService.findAll();
        result.addObject("hybrids", hybrids);

        List<Zone> zones = zoneService.findAll();
        result.addObject("zones", zones);

        result.addObject("humidityRangeFilterDTO", new HumidityRangeFilterDTO());

        return result;
    }


    @RequestMapping(value = "/", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse<HumidityRangeDTO> findAll() {
        try {
            List<HumidityRangeDTO> humidityRanges = Lists.transform(humidityRangeService.findAll(), new Function<HumidityRange, HumidityRangeDTO>() {
                @Override
                public HumidityRangeDTO apply(HumidityRange humidityRange) {
                    return new HumidityRangeDTO(humidityRange);
                }
            });
            log.debug("returned all humidityRanges.");
            return new JsonResponse<HumidityRangeDTO>(humidityRanges);
        } catch (DataAccessException e) {
            log.error("Error while find humidity range ", e);
            return new JsonResponse<HumidityRangeDTO>(false, message.getMessage("humidityRange.find.error"));
        }
    }

    @RequestMapping(value = "/filter", method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<HumidityRangeFilterDTO> filter(@RequestBody HumidityRangeFilterDTO humidityRangeFilterDTO) throws DataAccessException {
        log.debug("Humidity Range Filter Init");

        String hybridName = humidityRangeFilterDTO.getHybridName().equals("") ? null : humidityRangeFilterDTO.getHybridName().toUpperCase();

        List<HumidityRangeDTO> humidityRanges = Lists.transform(humidityRangeService.findByHybrid(hybridName), new Function<HumidityRange, HumidityRangeDTO>() {
            @Override
            public HumidityRangeDTO apply(HumidityRange humidityRange) {
                return new HumidityRangeDTO(humidityRange);
            }
        });

        return humidityRanges.size() > 0 ?
                new JsonResponse<HumidityRangeFilterDTO>(new HumidityRangeFilterDTO(humidityRanges)) :
                new JsonResponse<HumidityRangeFilterDTO>(false, getMessage("humidityRange.notExist"));

    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public JsonResponse<HumidityRangeDTO> findById(@PathVariable Integer id) {
        try {
            HumidityRange humidityRange = humidityRangeService.findById(id);
            return humidityRange != null ?
                    new JsonResponse<HumidityRangeDTO>(new HumidityRangeDTO(humidityRange)) :
                    new JsonResponse<HumidityRangeDTO>(false, getMessage("humidityRange.notExist"));
        } catch (DataAccessException e) {
            log.error("Error while find humidity range ", e);
            return new JsonResponse<HumidityRangeDTO>(false, "");
        }
    }

    @RequestMapping(method = RequestMethod.POST, consumes = {"application/json", "application/x-www-form-urlencoded"}, produces = "application/json")
    @ResponseBody
    public JsonResponse<HumidityRangeDTO> save(@RequestBody HumidityRangeDTO humidityRangeDTO) {
        log.debug("Creating humidityRange: ");
        try {
            HumidityRange humidityRange = parseHumidityRange(new HumidityRange(), humidityRangeDTO);
            humidityRangeService.update(humidityRange);
            log.debug(getMessage("humidityRange.save.success"));
            return new JsonResponse<HumidityRangeDTO>(true, getMessage("humidityRange.save.success"));
        } catch (DataAccessException e) {
            log.error(getMessage("humidityRange.save.error"), e);
            return new JsonResponse<HumidityRangeDTO>(false, getMessage("application.unexpectederror"));
        }
    }

    @RequestMapping(method = RequestMethod.PUT, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public JsonResponse<HumidityRangeDTO> update(@RequestBody HumidityRangeDTO humidityRangeDTO) {
        try {
            log.debug("Editing humidityRange: " + humidityRangeDTO.getId());
            HumidityRange humidityRange = humidityRangeService.findById(humidityRangeDTO.getId());
            humidityRange = parseHumidityRange(humidityRange, humidityRangeDTO);
            humidityRangeService.update(humidityRange);
            log.debug(getMessage("humidityRange.update.success"));
            return new JsonResponse<HumidityRangeDTO>(true, getMessage("humidityRange.update.success"));
        } catch (DataAccessException e) {
            log.error(getMessage("humidityRange.save.error"), e);
            return new JsonResponse<HumidityRangeDTO>(false, getMessage("application.unexpectederror"));
        }
    }


    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE, consumes = "application/json", produces = "application/json")
    @ResponseBody
    public JsonResponse<HumidityRangeDTO> delete(@PathVariable Integer id) {
        try {
            log.debug("Deleting humidityRange: " + id);
            HumidityRange humidityRange = humidityRangeService.findById(id);
            List<LotHumidity> lotHumidities = lotHumidityService.findByHybridZone(humidityRange.getHybrid(), humidityRange.getZone());
            if (lotHumidities.size() == 0) {
                humidityRangeService.delete(id);
            } else {
                return new JsonResponse<HumidityRangeDTO>(false, getMessage("humidityRange.delete.hasLotHumidity"));
            }
            log.debug(getMessage("humidityRange.delete.success"));
            return new JsonResponse<HumidityRangeDTO>(true, getMessage("humidityRange.delete.success"));
        } catch (DataAccessException e) {
            log.error(getMessage("humidityRange.save.error"), e);
            return new JsonResponse<HumidityRangeDTO>(false, getMessage("application.unexpectederror"));
        }

    }


    private HumidityRange parseHumidityRange(HumidityRange humidityRange, HumidityRangeDTO humidityRangeDTO) {
        humidityRange.setHumidityMin(humidityRangeDTO.getHumidityMin());
        humidityRange.setHumidityMax(humidityRangeDTO.getHumidityMax());

        Hybrid hybrid = hybridService.findById(humidityRangeDTO.getHybridId());
        humidityRange.setHybrid(hybrid);

        Zone zone = zoneService.findByCode(humidityRangeDTO.getZoneCode());
        humidityRange.setZone(zone);

        return humidityRange;
    }
}