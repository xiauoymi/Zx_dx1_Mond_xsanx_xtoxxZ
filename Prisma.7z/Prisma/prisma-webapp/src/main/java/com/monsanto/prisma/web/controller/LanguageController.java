package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.web.utils.JsonResponse;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by AFREI on 02/09/2014.
 */
@Controller
@RequestMapping(value = "/")
public class LanguageController extends AbstractController {

    @RequestMapping(value = "/language/", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse<String> getLanguage(@RequestHeader(value = "accept-language") String acceptLanguage) {
        return new JsonResponse<String>(acceptLanguage);
    }
}
