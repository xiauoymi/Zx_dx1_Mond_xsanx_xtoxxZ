package com.monsanto.prisma.web.controller;

import com.google.common.base.Function;
import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.*;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.*;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import com.monsanto.prisma.web.dto.LotFilterDTO;
import com.monsanto.prisma.web.dto.LotListDTO;
import com.monsanto.prisma.web.exception.ControllerException;
import com.monsanto.prisma.web.security.SecurityHolderStrategy;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA. User: BSBUON Date: 22/04/14 Time: 15:56 To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/lot")
public class LotController {
    public static final String LOT_DETAILS = "lotDetails";
    public static final String LOT_HISTORY = "lotHistory";
    public static final String LOT_LIST = "lotList";
    public static final String HOME_PAGE = "home";
    public static final String LOTS = "lots";
    public static final String USER_LOT_FILTER_DTO = "userLotFilterDTO";
    public static final String EXPORT_EXCEL = "lotListExcel";
    public static final String EXPORT_PDF = "lotListPDF";
    public static final String DATE_PATTERN = "datePattern";
    public static final String LOT_HISTORIES = "lotHistories";
    public static final String LOT_HUMIDITIES = "lotHumidities";
    public static final String CAMPAIGN_ID = "campaignId";
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";
    public static final String PREV_LOT_WORKFLOW = "prevLotWorkFlow";
    public static final String ALL_LOTS = "allLots";
    private static Logger log = Logger.getLogger(LotController.class);
    @Autowired
    private LotService lotService;
    @Autowired
    private LotHumidityService lotHumidityService;
    @Autowired
    private HybridService hybridService;
    @Autowired
    private MessageCurrentLocaleResolver message;
    @Autowired
    private CampaignService campaignService;
    @Autowired
    private SecurityHolderStrategy securityHolderStrategy;
    @Autowired
    private LotBatchService lotBatchService;
    @Autowired
    private LotFilterService lotFilterService;

    @RequestMapping(value = "/filter", method = RequestMethod.POST)
    @ResponseBody
    public ModelAndView filter(@ModelAttribute(USER_LOT_FILTER_DTO) UserLotFilterDTO userLotFilterDTO, RedirectAttributes redirectAttributes, Model model) throws DataAccessException {
        List<Lot> lots;
        log.debug("/lot/filter (POST) - init");
        if (userLotFilterDTO.getFilters().isEmpty()) {
            lots = lotService.findLotsByCampaignId(userLotFilterDTO.getCampaignId());
        } else {
            lots = lotService.findByFilter(userLotFilterDTO.getCampaignId(), userLotFilterDTO.getFilters());
        }
        if (lots.size() == 0) {
            redirectAttributes.addFlashAttribute("message", message.getMessage("tab.lot.emptyLots"));
            redirectAttributes.addFlashAttribute(USER_LOT_FILTER_DTO, userLotFilterDTO);
            redirectAttributes.addFlashAttribute(LOTS, lots);
        } else {
            log.debug("Lots (size): " + lots.size());
            redirectAttributes.addFlashAttribute(USER_LOT_FILTER_DTO, userLotFilterDTO);
            redirectAttributes.addFlashAttribute(LOTS, lots);
        }
        redirectAttributes.addFlashAttribute(CAMPAIGN_ID, userLotFilterDTO.getCampaignId());
        model.addAttribute(USER_LOT_FILTER_DTO, userLotFilterDTO);
        log.debug("/lot/filter (POST) - end");
        return new ModelAndView("redirect:/lot/campaign/");
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse<LotDTO> findById(@PathVariable Integer id) throws DataAccessException {
        Lot lot = lotService.findById(id);
        return lot != null ? new JsonResponse<LotDTO>(new LotDTO(lot)) : new JsonResponse<LotDTO>(false, message.getMessage("tab.lot.dontExist"));
    }

    @RequestMapping(value = "/detail/", method = RequestMethod.GET)
    @ResponseBody
    public ModelAndView findDetailById(HttpServletRequest request) throws DataAccessException {
        ModelAndView result = new ModelAndView(LOT_DETAILS);
        Integer id = (Integer) request.getSession().getAttribute("lotId");

        final Lot lot = lotService.findById(id);
        if (lot != null) {
            List<LotHistoryDTO> lotHistories = Lists.transform(lotService.getLotHistory(id), new Function<LotHistory, LotHistoryDTO>() {
                @Nullable
                @Override
                public LotHistoryDTO apply(@Nullable LotHistory lotHistory) {
                    return new LotHistoryDTO(lotHistory);
                }
            });
            result.addObject(LOT_HISTORIES, lotHistories);
            List<LotHumidityDTO> lotHumidities = Lists.transform(lotHumidityService.findByLot(lot.getId()), new Function<LotHumidity, LotHumidityDTO>() {
                @Nullable
                @Override
                public LotHumidityDTO apply(@Nullable LotHumidity lotHumidity) {
                    return new LotHumidityDTO(lotHumidity, new LotDTO(lot));
                }
            });
            result.addObject(LOT_HUMIDITIES, lotHumidities);
            List<LotBatchDTO> lotBatchDTOs = lotBatchService.findByLotId(lot.getId());
            result.addObject(CAMPAIGN_ID, lot.getCampaign().getId());
            result.addObject("campaign", new CampaignDTO(lot.getCampaign()));
            result.addObject("lot", new LotDTO(lot));
            result.addObject("lotBatches", lotBatchDTOs);
            TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(lot.getCampaign().getId());
            result.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
            request.getSession().setAttribute("idCampaign", lot.getCampaign().getId());
        }
        return result;
    }

    @RequestMapping(value = "/detail/", method = RequestMethod.POST)
    public String findDetailById(@RequestParam("idLot") Integer id, @RequestParam("optionMenu") String optionMenu, HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.setAttribute("lotId", id);
        return "redirect:" + optionMenu;
    }

    @RequestMapping(value = "/{idTab}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse<LotDTO> update(@RequestBody LotDTO lotDTO, @PathVariable(value = "idTab") Integer idTab) {
        return updateProcess(lotDTO, idTab, "");
    }

    @RequestMapping(value = "/{idTab}/{operation}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse<LotDTO> updateOperation(@RequestBody LotDTO lotDTO, @PathVariable(value = "idTab") Integer idTab, @PathVariable(value = "operation") String operation) {
        return updateProcess(lotDTO, idTab, operation);
    }

    private JsonResponse<LotDTO> updateProcess(LotDTO lotDTO, Integer idTab, String operation) {
        try {
            JsonResponse<LotDTO> jsonResponse;
            Integer lotCount = lotService.countLotByCodeAndDiffLotId(lotDTO.getLotCode(), lotDTO.getId());
            if (lotCount > 0) {
                return setJsonResponseMessage(null, message.getMessage("tab.lot.lotExist"), false);
            }
            User user = securityHolderStrategy.getCurrentUser();
            Lot lot;
            if (!operation.equals(PREV_LOT_WORKFLOW)) {
                lot = lotService.recalculate(lotDTO, idTab, operation, user);
            } else {
                lot = lotService.updatePrevLot(lotDTO, user);
                lotDTO.setLotCode(lot.getLotCode());
            }
            if (lot != null) {
                jsonResponse = setJsonResponseMessage(lot, message.getMessage("tab.lot.success.lotCode", lotDTO.getLotCode()), true);
            } else {
                jsonResponse = setJsonResponseMessage(null, message.getMessage("tab.lot.error.lotCode", lotDTO.getLotCode()), false);
            }
            return jsonResponse;
        } catch (ProcessWithErrorException e) {
            log.error("Error while Updating Lot " + lotDTO.getLotCode(), e);
            StringBuilder builder = new StringBuilder(message.getMessage("tab.lot.error.lotCode", lotDTO.getLotCode()));
            for (RuntimeException violation : e.getViolations()) {
                String msg = message.getMessage(violation.getMessage());
                log.error("Error while Updating Lot:" + msg);
                builder.append("<br/>").append(msg);
            }
            return new JsonResponse<LotDTO>(false, builder.toString());
        } catch (Exception e) {
            log.error("Error while Updating Lot ", e);
            return new JsonResponse<LotDTO>(false, message.getMessage("tab.lot.errorLot"));
        }
    }

    private JsonResponse<LotDTO> setJsonResponseMessage(Lot lot, String message, Boolean success) {
        JsonResponse<LotDTO> jsonResponse;
        if (lot != null) {
            jsonResponse = new JsonResponse<LotDTO>(new LotDTO(lot));
        } else {
            jsonResponse = new JsonResponse<LotDTO>();
        }
        jsonResponse.setSuccess(success);
        jsonResponse.setMessage(message);
        return jsonResponse;
    }

    @RequestMapping(value = "/masive/{id}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse<LotListDTO> updateAll(@RequestBody LotDTO lotDTO, @PathVariable(value = "id") Integer id, @RequestParam(value = "operation", required = false) String operation) {
        List<LotDTO> lotSuccessList = new ArrayList<LotDTO>();
        List<String> lotErrorList = new ArrayList<String>();
        Lot lot;
        JsonResponse<LotListDTO> jsonResponse;
        if (lotDTO.getSelectedLots().size() > 0) {
            Integer notSuccess = 0;
            for (LotSelectedDTO lotSelected : lotDTO.getSelectedLots()) {
                lot = null;
                log.debug("Editing Lot: " + lotDTO.getId());
                lotDTO.setId(lotSelected.getLotId());
                try {
                    User user = securityHolderStrategy.getCurrentUser();
                    lot = lotService.recalculate(lotDTO, id, operation, user);
                } catch (Exception e) {
                    log.error("Error while Updating Lot ", e);
                }
                if (lot == null) {
                    lotErrorList.add(lotSelected.getLotCode());
                    notSuccess++;
                } else {
                    lotSuccessList.add(new LotDTO(lot));
                }
            }
            if (notSuccess == 0) {
                jsonResponse = setJsonResponseSuccess(lotSuccessList, "tab.lot.success.massive.lotCodes", "tab.lot.success.lotCode");
            } else {
                jsonResponse = setJsonResponseError(lotErrorList, lotSuccessList, "tab.lot.error.massive.lotCodes", "tab.lot.error.lotCode");
            }
        } else {
            jsonResponse = new JsonResponse<LotListDTO>();
            jsonResponse.setSuccess(false);
            jsonResponse.setMessage(message.getMessage("tab.lot.emptyLots"));
        }
        return jsonResponse;
    }

    private JsonResponse<LotListDTO> setJsonResponseError(List<String> lotErrorList, List<LotDTO> lotSuccessList, String msjMassive, String msj) {
        JsonResponse<LotListDTO> jsonResponse = new JsonResponse<LotListDTO>(new LotListDTO(lotSuccessList));
        jsonResponse.setSuccess(false);
        String lotCodes = Joiner.on(", ").skipNulls().join(lotErrorList);
        if (lotErrorList.size() > 1) {
            jsonResponse.setMessage(message.getMessage(msjMassive, lotCodes));
        } else {
            jsonResponse.setMessage(message.getMessage(msj, lotCodes));
        }
        return jsonResponse;
    }

    private JsonResponse<LotListDTO> setJsonResponseSuccess(List<LotDTO> lotSuccessList, String msjMassive, String msj) {
        JsonResponse<LotListDTO> jsonResponse = new JsonResponse<LotListDTO>(new LotListDTO(lotSuccessList));
        jsonResponse.setSuccess(true);
        String lotCodes = Joiner.on(", ").skipNulls().join(lotSuccessList);
        if (lotSuccessList.size() > 1) {
            jsonResponse.setMessage(message.getMessage(msjMassive, lotCodes));
        } else {
            jsonResponse.setMessage(message.getMessage(msj, lotCodes));
        }
        return jsonResponse;
    }


    @RequestMapping(method = RequestMethod.DELETE)
    @ResponseBody
    public JsonResponse<LotListDTO> delete(@RequestBody List<Integer> lotIds) throws DataAccessException {
        Lot lot = null;
        List<LotDTO> lotSuccessList = new ArrayList<LotDTO>();
        List<String> lotErrorList = new ArrayList<String>();
        Integer notSuccess = 0;
        JsonResponse<LotListDTO> jsonResponse;
        for (Integer lotId : lotIds) {
            try {
                lot = lotService.deleteLogical(lotId);
            } catch (Exception e) {
                log.error("Error while delete Lot ", e);
            }
            if (lot.getState()) {
                lotErrorList.add(lot.getLotCode());
                notSuccess++;
            } else {
                lotSuccessList.add(new LotDTO(lot));
            }
        }
        if (notSuccess == 0) {
            jsonResponse = setJsonResponseSuccess(lotSuccessList, "tab.lot.success.delete.massive.lotCodes", "tab.lot.delete.success.lotCode");
        } else {
            jsonResponse = setJsonResponseError(lotErrorList, lotSuccessList, "tab.lot.error.delete.massive.lotCodes", "tab.lot.delete.error.lotCode");
        }
        return jsonResponse;
    }

    @RequestMapping(value = "/lotList", method = RequestMethod.GET)
    public ModelAndView lotList(Model model) {
        ModelAndView page = new ModelAndView(LOT_LIST);
        page.addObject(USER_LOT_FILTER_DTO, model.asMap().get(USER_LOT_FILTER_DTO));
        page.addObject(LOTS, model.asMap().get(LOTS));
        return page;
    }

    @RequestMapping(value = "/campaign/", method = RequestMethod.GET)
    public ModelAndView findByCampaignId(Model model, HttpServletRequest request) {
        ModelAndView result = new ModelAndView(LOT_LIST);
        Integer id = null;
        try {
            HttpSession session = request.getSession();
            id = (Integer) model.asMap().get(CAMPAIGN_ID) != null ? (Integer) model.asMap().get(CAMPAIGN_ID) : (Integer) session.getAttribute("idCampaign");
            if (id != null) {
                UserLotFilterDTO userLotFilterDTO = (UserLotFilterDTO) model.asMap().get(USER_LOT_FILTER_DTO);
                if (userLotFilterDTO == null) {
                    userLotFilterDTO = new UserLotFilterDTO();
                }
                result.addObject(USER_LOT_FILTER_DTO, userLotFilterDTO);
                CampaignDTO campaignDTO = (CampaignDTO) model.asMap().get("campaign");
                if (campaignDTO == null && id != 0) {
                    campaignDTO = campaignService.findByIdAndActiveLots(id);
                }
                result.addObject("campaign", campaignDTO);
                if (campaignDTO != null && campaignDTO.getIsActive()) {
                    result.addObject(CAMPAIGN_ID, campaignDTO.getId());
                }
                result.addObject(CAMPAIGN_ID, id);
                model.addAttribute(CAMPAIGN_ID, id);
                result.getModel().put(CAMPAIGN_ID, id);
                TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(id);
                result.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
                List<LotFilter> lotFilterList = lotFilterService.findAll();
                List<LotFilterDTO> lotFilterDTOList = Lists.transform(lotFilterList, new Function<LotFilter, com.monsanto.prisma.web.dto.LotFilterDTO>() {
                    @Override
                    public com.monsanto.prisma.web.dto.LotFilterDTO apply(@Nullable LotFilter lotFilter) {
                        return new LotFilterDTO(lotFilter);
                    }
                });
                result.addObject("lotFilterList", lotFilterDTOList);
            } else {
                result = new ModelAndView("redirect:/" + HOME_PAGE);
            }
        } catch (Exception e) {
            log.error("Error while Loading Campaign id: " + id, e);
        }
        return result;
    }


    @RequestMapping(value = "/campaign/", method = RequestMethod.POST)
    public String findByCampaignId(@RequestParam("idCampaign") Integer id, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        redirectAttributes.addFlashAttribute(CAMPAIGN_ID, id);
        HttpSession session = request.getSession();
        session.setAttribute("idCampaign", id);
        return "redirect:/lot/campaign/";
    }

    @RequestMapping(value = "/history/{id}", method = RequestMethod.GET)
    public ModelAndView getLotHistory(@PathVariable(value = "id") Integer id) throws BusinessException, DataAccessException {
        ModelAndView result = new ModelAndView(LOT_HISTORY);
        List<LotHistory> lotHistories = lotService.getLotHistory(id);
        final Lot lot = lotService.findById(id);
        result.addObject(LOT_HISTORIES, lotHistories);
        if (lot.getCampaign() != null && lot.getCampaign().getIsActive()) {
            result.addObject(CAMPAIGN_ID, lot.getCampaign().getId());
        }
        result.addObject("lot", new LotDTO(lot));
        List<LotHumidityDTO> lotHumidities = Lists.transform(lotHumidityService.findByLot(lot.getId()), new Function<LotHumidity, LotHumidityDTO>() {
            @Nullable
            @Override
            public LotHumidityDTO apply(@Nullable LotHumidity lotHumidity) {
                return new LotHumidityDTO(lotHumidity, new LotDTO(lot));
            }
        });
        result.addObject(LOT_HUMIDITIES, lotHumidities);
        return result;
    }


    @RequestMapping(value = "/hybrid/", method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<HybridDTO> findAllHybrid() {
        List<Hybrid> hybrids = hybridService.findAll();
        List<HybridDTO> hybridDTOs = Lists.transform(hybrids, new Function<Hybrid, HybridDTO>() {
            @Nullable
            @Override
            public HybridDTO apply(@Nullable Hybrid hybrid) {
                return new HybridDTO(hybrid);
            }
        });
        JsonResponse jsonResponse = new JsonResponse<HybridDTO>(hybridDTOs);
        jsonResponse.setSuccess(true);
        return jsonResponse;
    }


    @RequestMapping(value = "/previousLots/{id}", method = RequestMethod.GET)
    @ResponseBody
    public JsonResponse<PreviousLotDTO> findPreviousLotsByLotId(@PathVariable Integer id) throws DataAccessException {
        List<PreviousLotDTO> previousLots = lotService.findPreviousLotsByLotId(id);
        return previousLots != null ? new JsonResponse<PreviousLotDTO>(previousLots) : new JsonResponse<PreviousLotDTO>(false, message.getMessage("tab.lot.dontExist"));
    }

    @RequestMapping(value = "/campaign/{id}/error", method = RequestMethod.GET)
    public String handleLotError(HttpServletRequest request) {
        Integer campaignId = (Integer) request.getAttribute("campaignId");
        request.getSession().setAttribute("idCampaign", campaignId);
        request.getSession().setAttribute("errorMessage", "errorMessage");
        return "redirect:/lot/campaign/";
    }

    @RequestMapping(value = "/campaign/{id}/exportToExcel.xls", method = RequestMethod.GET)
    public ModelAndView exportToExcel(@PathVariable Integer id) {
        ModelAndView model = new ModelAndView(EXPORT_EXCEL);
        List<LotDTO> lotDTOList = Lists.transform(lotService.findActiveLotsByCampaignId(id), new Function<Lot, LotDTO>() {
            @Nullable
            @Override
            public LotDTO apply(@Nullable Lot lot) {
                return new LotDTO(lot, false);
            }
        });
        model.addObject(EXPORT_EXCEL, lotDTOList);
        model.addObject(DATE_PATTERN, message.getMessage("configuration.date.pattern"));
        return model;
    }

    @RequestMapping(value = "/campaign/{id}/exportToPDF", method = RequestMethod.GET)
    protected ModelAndView exportToPDF(@PathVariable Integer id) throws ControllerException {
        ModelAndView model = new ModelAndView(EXPORT_PDF);
        List<LotDTO> lotDTOList = Lists.transform(lotService.findActiveLotsByCampaignId(id), new Function<Lot, LotDTO>() {
            @Nullable
            @Override
            public LotDTO apply(@Nullable Lot lot) {
                return new LotDTO(lot, false);
            }
        });
        model.addObject(EXPORT_PDF, lotDTOList);
        return model;
    }

    @RequestMapping(value = "/hybrid/campaign/", method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<LotComboDTO> findByHybridAndCampaign(@RequestBody List<Integer> ids) {
        Integer hybridId = ids.get(0);
        Integer campaignId = ids.get(1);
        List<LotComboDTO> lotList = Lists.transform(lotService.findActiveAndHuskedLotsByHybridIdAndCampaignId(hybridId, campaignId), new Function<Lot, LotComboDTO>() {
            @Nullable
            @Override
            public LotComboDTO apply(@Nullable Lot lot) {
                return new LotComboDTO(lot);
            }
        });
        return new JsonResponse<LotComboDTO>(lotList);
    }

    @RequestMapping(value = "/", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public JsonResponse<LotComboDTO> findAll() {
        log.debug("get All lots...");
        try {
            List<LotComboDTO> lots = Lists.transform(lotService.findAll(), new Function<LotCombo, LotComboDTO>() {
                @Nullable
                @Override
                public LotComboDTO apply(@Nullable LotCombo lot) {
                    return new LotComboDTO(lot);
                }
            });
            return new JsonResponse<LotComboDTO>(lots);
        } catch (Exception e) {
            log.error("Error while find all Lots.", e);
            return new JsonResponse<LotComboDTO>(false, "Error while find all Lots: " + e.getMessage());
        }
    }
}