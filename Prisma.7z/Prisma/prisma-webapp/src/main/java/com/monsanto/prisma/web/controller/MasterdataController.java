package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.LotMasterdata;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.MasterdataService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;

/**
 * Created by EPESTE on 28/05/2014.
 */
@Controller
@RequestMapping(value = "/masterdata")
public class MasterdataController extends AbstractController {

    private static Logger log = Logger.getLogger(MasterdataController.class);

    private static String MASTERDATA_PAGE = "masterdata";
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";

    @Autowired
    private MasterdataService masterdataService;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private LotService lotService;

    private String messageTimeout = "prisma.timeout";

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<? extends Object> uploadFile(@RequestBody Integer campaignId) throws BusinessException, DataAccessException {
        ArrayList<LotMasterdata> lotMasterdata;
        try {
            lotMasterdata = masterdataService.refreshFromMasterdata(campaignId);
        } catch (BusinessException ex) {
            log.error("error when refresh from masterdata -" + ex.getMessage(), ex);
            return new JsonResponse<ArrayList<LotMasterdata>>(false, ex.getLocalizedMessage());
        }

        return lotMasterdata != null ?
                new JsonResponse<ArrayList<LotMasterdata>>(lotMasterdata) : new JsonResponse<ArrayList<LotMasterdata>>(false, getMessage("ditsem.empty"));
    }

    @RequestMapping(value = "/campaign/", method = RequestMethod.GET)
    public ModelAndView init(HttpServletRequest request) {
        log.info("Open MASTERDATA page.");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        return masterdataView(campaignId);
    }

    @RequestMapping(value = "/campaign/", method = RequestMethod.POST)
    public ModelAndView init(@RequestParam("campaignId") Integer campaignId) {
        log.info("Open MASTERDATA page.");
        return masterdataView(campaignId);
    }

    private ModelAndView masterdataView(Integer campaignId) {
        ModelAndView page = new ModelAndView(MASTERDATA_PAGE);
        page.addObject("campaignId", campaignId);
        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        page.addObject("campaign", campaignDTO);
        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
        return page;
    }


}
