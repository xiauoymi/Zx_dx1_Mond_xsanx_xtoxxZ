package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.PayGrower;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.PayGrowerService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.dto.PayGrowerDTO;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.text.ParseException;

/**
 * Created by PGSETT on 31/07/2014.
 */
@Controller
@RequestMapping(value = "/payGrower")
public class PayGrowerController extends AbstractController {
    private static Logger log = Logger.getLogger(PayGrowerController.class);
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";
    @Autowired
    private CampaignService campaignService;

    @Autowired
    private PayGrowerService payGrowerService;
    @Autowired
    private LotService lotService;

    @RequestMapping(value = "/campaign/", method = RequestMethod.GET)
    public ModelAndView init(HttpServletRequest request) {
        log.info("Open pay grower page.");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        return payGrowerView(campaignId);
    }

    @RequestMapping(value = "/campaign/", method = RequestMethod.POST)
    public ModelAndView init(@RequestParam("campaignId") Integer campaignId) {
        log.info("Open pay grower page.");
        return payGrowerView(campaignId);
    }

    private ModelAndView payGrowerView(Integer campaignId) {
        ModelAndView page = new ModelAndView(Constants.PAGE_PAY_GROWER);
        page.addObject("campaignId", campaignId);
        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        page.addObject("campaign", campaignDTO);
        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
        log.info("forward to page " + Constants.PAGE_PAY_GROWER);
        return page;
    }

    @RequestMapping(value = "/campaign/{campaignId}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse<PayGrowerDTO> updateLots(@PathVariable Integer campaignId) throws BusinessException, InvalidFormatException, IOException, ParseException {
        log.info("update lots from pay grower.");
        PayGrower payGrower;
        try {
            payGrower = payGrowerService.importFile(campaignId);
        } catch (BusinessException ex) {
            log.error("error when impor file pay grower -" + ex.getMessage(), ex);
            return new JsonResponse<PayGrowerDTO>(false, ex.getLocalizedMessage());
        }
        return payGrower != null ?
                new JsonResponse<PayGrowerDTO>(new PayGrowerDTO(payGrower)) : new JsonResponse<PayGrowerDTO>(false, getMessage("payGrower.notExists"));
    }
}
