package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.PreHarvestHumidity;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.PreHarvestHumidityDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.PreHarvestHumidityService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by PGSETT on 24/06/2014.
 */
@Controller
@RequestMapping(value = "/preHarvest")
public class PreHarvestController extends AbstractController {

    private static Logger log = Logger.getLogger(PreHarvestController.class);

    private static String PREHARVEST_PAGE = "preHarvest";
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";
    @Autowired
    private LotService lotService;
    @Autowired
    private PreHarvestHumidityService preHarvestHumidityService;
    @Autowired
    private CampaignService campaignService;

    @RequestMapping(value = "/campaign/", method = RequestMethod.GET)
    public ModelAndView init(HttpServletRequest request) {
        log.info("Open PREHARVEST page.");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        return preHarvestView(campaignId);
    }

    @RequestMapping(value = "/campaign/", method = RequestMethod.POST)
    public ModelAndView init(@RequestParam("campaignId") Integer campaignId) {
        log.info("Open PREHARVEST page.");
        return preHarvestView(campaignId);
    }

    private ModelAndView preHarvestView(Integer campaignId) {
        ModelAndView page = new ModelAndView(PREHARVEST_PAGE);
        page.addObject("campaignId", campaignId);
        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        page.addObject("campaign", campaignDTO);
        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
        return page;
    }


    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<PreHarvestHumidityDTO> uploadFile(@RequestBody Integer campaignId) throws BusinessException {
        PreHarvestHumidity preHarvestHumidity;
        try {
            preHarvestHumidity = preHarvestHumidityService.refreshFromPreHarvest(campaignId);
        } catch (BusinessException ex) {
            log.error("error when refresh from preharvest -" + ex.getMessage(), ex);
            return new JsonResponse<PreHarvestHumidityDTO>(false, ex.getLocalizedMessage());
        }
        if (preHarvestHumidity == null) {
            return new JsonResponse<PreHarvestHumidityDTO>(false, getMessage("preHarvest.empty"));
        }
        PreHarvestHumidityDTO preHarvestHumidityDTO = new PreHarvestHumidityDTO(preHarvestHumidity);
        return preHarvestHumidity != null ?
                new JsonResponse<PreHarvestHumidityDTO>(preHarvestHumidityDTO) : new JsonResponse<PreHarvestHumidityDTO>(false, getMessage("preHarvest.empty"));
    }
}