package com.monsanto.prisma.web.controller;


import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.PrismaFunctionality;
import com.monsanto.prisma.core.domain.Profile;
import com.monsanto.prisma.core.dto.PrismaFunctionalityDTO;
import com.monsanto.prisma.core.dto.ProfileDTO;
import com.monsanto.prisma.core.service.PrismaFunctionalityService;
import com.monsanto.prisma.core.service.ProfileService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/profile")
public class ProfileController {

    private static Logger log = Logger.getLogger(ProfileController.class);

    private static final String PROFILE_LIST = "profileList";

    @Autowired
    private ProfileService profileService;

    @Autowired
    private PrismaFunctionalityService prismaFunctionalityService;

    @RequestMapping(value = "/init", method = RequestMethod.GET)
    public ModelAndView init() {
        log.debug("Profile Management Init");
        ModelAndView page = new ModelAndView(PROFILE_LIST);

        List<Profile> profiles = profileService.findAll();
        List<ProfileDTO> profileDTOList = Lists.transform(profiles, new Function<Profile, ProfileDTO>() {
            @Nullable
            @Override
            public ProfileDTO apply(@Nullable Profile rol) {
                return new ProfileDTO(rol);
            }
        });
        page.addObject("profileList", profileDTOList);

        return page;
    }

    @RequestMapping(value = "/new", method = RequestMethod.GET)
    public ModelAndView addProfile() {
        log.debug("New profile Init");
        ModelAndView page = new ModelAndView("newProfile");

        List<PrismaFunctionality> prismaFunctionalityList = prismaFunctionalityService.findAll();

        List<PrismaFunctionalityDTO> prismaFunctionalityDTOList;
        prismaFunctionalityDTOList = Lists.transform(prismaFunctionalityList, new Function<PrismaFunctionality, PrismaFunctionalityDTO>() {
            @Nullable
            @Override
            public PrismaFunctionalityDTO apply(@Nullable PrismaFunctionality prismaFunctionality) {
                return new PrismaFunctionalityDTO(prismaFunctionality);
            }
        });

        page.addObject("functionalities", prismaFunctionalityDTOList);

        return page;
    }

    @RequestMapping(method = RequestMethod.DELETE)
    @ResponseBody
    public JsonResponse<ProfileDTO> delete(@RequestParam(value = "id") Integer profileId) {
        profileService.delete(profileId);
        return new JsonResponse<ProfileDTO>("prisma.profile.delete.ok", new ProfileDTO(profileId));
    }


    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<ProfileDTO> addProfile(@RequestBody ProfileDTO profileDTO) {
        Profile profile = profileService.add(profileDTO);

        return new JsonResponse<ProfileDTO>("prisma.profile.add.ok", new ProfileDTO(profile));
    }


    @RequestMapping(value = "/detail", method = RequestMethod.GET)
    public ModelAndView detail(@RequestParam(value = "id") Integer id) {
        log.debug("Detail profile Init");
        ModelAndView page = new ModelAndView("profileEdit");

        Profile profile = profileService.findById(id);
        page.addObject("profile", profile);

        List<PrismaFunctionality> prismaFunctionalityList = prismaFunctionalityService.findAll();

        List<PrismaFunctionalityDTO> prismaFunctionalityDTOList;
        prismaFunctionalityDTOList = Lists.transform(prismaFunctionalityList, new Function<PrismaFunctionality, PrismaFunctionalityDTO>() {
            @Nullable
            @Override
            public PrismaFunctionalityDTO apply(@Nullable PrismaFunctionality prismaFunctionality) {
                return new PrismaFunctionalityDTO(prismaFunctionality);
            }
        });

        List<PrismaFunctionalityDTO> prismaFunctionalityDTOArrayLista = new ArrayList<PrismaFunctionalityDTO>(prismaFunctionalityDTOList);
        for (PrismaFunctionality prismaFunctionality : profile.getPrismaFunctionalityList()) {
            int index = prismaFunctionalityDTOArrayLista.indexOf(new PrismaFunctionalityDTO(prismaFunctionality));
            if (index >= 0) {
                prismaFunctionalityDTOArrayLista.set(index, new PrismaFunctionalityDTO(prismaFunctionality, Boolean.TRUE));
            }
        }

        page.addObject("functionalities", prismaFunctionalityDTOArrayLista);

        return page;
    }

    @RequestMapping(method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse<ProfileDTO> update(@RequestBody ProfileDTO profileDTO) {
        Profile profile = profileService.update(profileDTO);
        return new JsonResponse<ProfileDTO>("prisma.profile.update.ok", new ProfileDTO(profile));
    }
}
