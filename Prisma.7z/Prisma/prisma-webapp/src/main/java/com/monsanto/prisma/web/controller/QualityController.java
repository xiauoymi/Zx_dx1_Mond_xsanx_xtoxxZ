package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.QualityFile;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.QualityDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.QualityService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.exception.ControllerException;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

/**
 * Created by EPESTE on 29/07/2014.
 */
@Controller
@RequestMapping(value = "/quality")
public class QualityController extends AbstractController {

    private static Logger log = Logger.getLogger(QualityController.class);
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";

    @Autowired
    private LotService lotService;

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private QualityService qualityService;

    @RequestMapping(value = "/campaign/", method = RequestMethod.GET)
    public ModelAndView init(HttpServletRequest request) {
        log.info("Open quality import page.");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        return qualityView(campaignId);
    }

    @RequestMapping(value = "/campaign/", method = RequestMethod.POST)
    public ModelAndView init(@RequestParam("campaignId") Integer campaignId) {
        log.info("Open quality import page.");
        return qualityView(campaignId);
    }

    private ModelAndView qualityView(Integer campaignId) {
        ModelAndView page = new ModelAndView(Constants.PAGE_IMPORT_QUALITY);

        page.addObject("campaignId", campaignId);

        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        page.addObject("campaign", campaignDTO);
        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
        log.info("forward to page " + page.getViewName());
        return page;
    }

    @RequestMapping(value = "/campaign/{campaignId}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse<QualityDTO> updateFromFile(@PathVariable Integer campaignId) throws ControllerException {
        log.info("update lots from " + Constants.QUALITY_BULK_FILE + ". CampaignId: " + campaignId);
        QualityFile qualityFile;
        try {
            qualityFile = qualityService.importFromFile(campaignId);
        } catch (IOException e) {
            log.error("error when import file -" + e.getMessage(), e);
            return new JsonResponse(false, e.getLocalizedMessage());
        } catch (InvalidFormatException e) {
            log.error("error when import file -" + e.getMessage(), e);
            return new JsonResponse(false, e.getLocalizedMessage());
        } catch (BusinessException e) {
            log.error("error when import file -" + e.getMessage(), e);
            return new JsonResponse(false, e.getLocalizedMessage());
        }
        return qualityFile != null ?
                new JsonResponse<QualityDTO>(new QualityDTO(qualityFile)) : new JsonResponse<QualityDTO>(false, getMessage("qualityFile.notExists"));
    }

}
