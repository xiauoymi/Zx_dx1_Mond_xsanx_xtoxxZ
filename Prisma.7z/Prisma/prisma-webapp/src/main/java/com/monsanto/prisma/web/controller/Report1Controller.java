package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Report1;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.Report1Service;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.dto.Report1DTO;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.text.ParseException;

/**
 * Created by EPESTE on 23/07/2014.
 */
@Controller
@RequestMapping(value = "/report1")
public class Report1Controller extends AbstractController {

    private static Logger log = Logger.getLogger(Report1Controller.class);
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";
    @Autowired
    private CampaignService campaignService;

    @Autowired
    private Report1Service report1Service;
    @Autowired
    private LotService lotService;
    @RequestMapping(value = "/campaign/", method = RequestMethod.GET)
    public ModelAndView init(HttpServletRequest request) {
        log.info("Open report 1 page.");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        return report1View(campaignId);
    }

    @RequestMapping(value = "/campaign/", method = RequestMethod.POST)
    public ModelAndView init(@RequestParam("campaignId") Integer campaignId) {
        log.info("Open report 1 page.");
        return report1View(campaignId);
    }

    private ModelAndView report1View(Integer campaignId) {
        ModelAndView page = new ModelAndView(Constants.PAGE_REPORT_1);
        page.addObject("campaignId", campaignId);
        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        page.addObject("campaign", campaignDTO);
        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);
        log.info("forward to page " + Constants.PAGE_REPORT_1);
        return page;
    }

    @RequestMapping(value = "/campaign/{campaignId}", method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse<Report1DTO> updateLots(@PathVariable Integer campaignId) throws BusinessException, InvalidFormatException, IOException, ParseException {
        log.info("update lots from report 1.");
        Report1 report1;

        try {
            report1 = report1Service.importFile(campaignId);
        } catch (BusinessException ex) {
            log.error("error when import file -" + ex.getMessage(), ex);
            return new JsonResponse<Report1DTO>(false, ex.getLocalizedMessage());
        }
        return report1 != null ?
                new JsonResponse<Report1DTO>(new Report1DTO(report1)) : new JsonResponse<Report1DTO>(false, getMessage("report1.notExists"));
    }
}
