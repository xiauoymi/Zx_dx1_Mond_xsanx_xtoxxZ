package com.monsanto.prisma.web.controller;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.Hybrid;
import com.monsanto.prisma.core.domain.Zone;
import com.monsanto.prisma.core.dto.*;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.*;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 25/08/2014.
 */
@Controller
@RequestMapping(value = "/report/tons")
public class TonsReportController extends AbstractController {

    private static Logger log = Logger.getLogger(TonsReportController.class);

    @Autowired
    private CampaignService campaignService;

    @Autowired
    private ZoneService zoneService;

    @Autowired
    private MessageCurrentLocaleResolver message;

    @Autowired
    private HybridService hybridService;

    @Autowired
    private TonsReportService tonsReportService;

    @Autowired
    private LotService lotService;

    public static final String EXPORT_EXCEL = "tonsToHostReportExcel";
    public static final String EXPORT_PDF = "tonsToHostReportPDF";

    public static final String CAMPAIGN_TON_DTO = "campaignTonDTO";
    public static final String WEEKS_TONS_TO_HOST = "weeksTonsToHost";

    public static final String STATUS_EXPORT_EXCEL = "statusReportExcel";
    public static final String STATUS_EXPORT_PDF = "statusReportPDF";
    public static final String BULK_DESTINATION_EXPORT_EXCEL = "bulkDestinationExcel";
    public static final String BULK_DESTINATION_EXPORT_PDF = "bulkDestinationPDF";
    public static final String TOTAL_LOTS_HAS = "totalLotsHas";

    @Value("${report.tons.zone.all}")
    private String allZones;

    @Value("${report.tons.hybrid.all}")
    private String allHybrids;

    private static final String OPTION_FILTER = "_optionFilter";
    private static final Integer ALL_ZONES = -1;
    private static final Integer ALL_HYBRIDS = -1;


    private static final String PROGRAM_FIELD = "l.program";
    private static final String LOT_CODE_FIELD = "l.lotCode";


    @RequestMapping(value = "tonsToHostReport/campaign/", method = RequestMethod.GET)
    public ModelAndView init(HttpServletRequest request) {
        log.info("Init Tons Report Controller");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        ModelAndView model = tonsToHostView(campaignId);
        if (request.getSession().getAttribute("errorMessage") != null) {
            model.addObject("errorMessage", request.getSession().getAttribute("errorMessage"));
            request.getSession().removeAttribute("errorMessage");
        }
        return model;
    }

    @RequestMapping(value = "tonsToHostReport/campaign/", method = RequestMethod.POST)
    public ModelAndView init(@RequestParam("campaignId") Integer campaignId) {
        log.info("Init Tons Report Controller");
        return tonsToHostView(campaignId);
    }

    private ModelAndView tonsToHostView(Integer campaignId) {
        ModelAndView page = new ModelAndView(Constants.PAGE_TONS_TO_HOST_REPORT);

        page.addObject("campaignId", campaignId);
        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        log.info("Get Campaign");
        page.addObject("campaign", campaignDTO);

        final List<ZoneDTO> zones = Lists.transform(zoneService.findAll(), new Function<Zone, ZoneDTO>() {
            @Nullable
            @Override
            public ZoneDTO apply(@Nullable Zone zone) {
                return new ZoneDTO(zone);
            }

        });
        page.addObject("selectOption", message.getMessage("application.selectOption"));
        page.addObject("zones", zones);

        List<HybridDTO> hybrids = Lists.transform(hybridService.findAll(), new Function<Hybrid, HybridDTO>() {
            @Nullable
            @Override
            public HybridDTO apply(@Nullable Hybrid hybrid) {
                return new HybridDTO(hybrid);
            }
        });
        page.addObject("hybrids", hybrids);

        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);

        log.info("forward to page " + Constants.PAGE_TONS_TO_HOST_REPORT);
        return page;
    }

    @RequestMapping(value = "/tonsToHostReport/campaign/{id}/error", method = RequestMethod.GET)
    public String handleTonsToHostError(HttpServletRequest request) {
        Integer campaignId = (Integer) request.getAttribute("campaignId");
        request.getSession().setAttribute("idCampaign", campaignId);
        request.getSession().setAttribute("errorMessage", "errorMessage");
        return "redirect:/report/tons/tonsToHostReport/campaign/";
    }

    @RequestMapping(value = "/tonsToHostReport/campaign/{id}/xls", method = RequestMethod.GET)
    @ResponseBody
    public ModelAndView exportToExcel(@PathVariable Integer id, @RequestParam(value = "zone", required = false) Integer zone,
                                      @RequestParam(value = "optionFilter", required = false) Integer optionFilter,
                                      @RequestParam(value = "hybrid", required = false) Integer hybrid,
                                      @RequestParam(value = "textFilter", required = false) String textFilter,
                                      @RequestParam(value = "harvestWeekFrom") Long harvestWeekFrom,
                                      @RequestParam(value = "harvestWeekTo") Long harvestWeekTo) throws DataAccessException {
        log.info("Export to excel document");
        return createTonsToHostReport(EXPORT_EXCEL, id, optionFilter, hybrid, textFilter, zone, harvestWeekFrom, harvestWeekTo);
    }

    @RequestMapping(value = "tonsToHostReport/campaign/{id}/pdf", method = RequestMethod.GET)
    @ResponseBody
    public ModelAndView exportToPdf(@PathVariable Integer id, @RequestParam(value = "zone", required = false) Integer zone,
                                    @RequestParam(value = "optionFilter", required = false) Integer optionFilter,
                                    @RequestParam(value = "hybrid", required = false) Integer hybrid,
                                    @RequestParam(value = "textFilter", required = false) String textFilter,
                                    @RequestParam(value = "harvestWeekFrom") Long harvestWeekFrom,
                                    @RequestParam(value = "harvestWeekTo") Long harvestWeekTo) throws DataAccessException {
        log.info("Export to pdf document");
        return createTonsToHostReport(EXPORT_PDF, id, optionFilter, hybrid, textFilter, zone, harvestWeekFrom, harvestWeekTo);
    }

    private ModelAndView createTonsToHostReport(String pageName, Integer id, Integer optionFilter, Integer hybridId, String textFilter, Integer zoneId, Long harvestWeekFrom, Long harvestWeekTo) {
        ModelAndView page = new ModelAndView(pageName);
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(id);
        campaignTonDTO.setHarvestDateFrom(new Date(harvestWeekFrom));
        campaignTonDTO.setHarvestDateTo(new Date(harvestWeekTo));
        List<TonsToHostDTO> tonsToHostDTOs;
        List<TonsToHostDTO> weeksTonsToHostDTO;
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            campaignTonDTO.setLotCode(textFilter.equals("") ? null : textFilter);
            tonsToHostDTOs = tonsReportService.filterTonsToHostReport(id, LOT_CODE_FIELD, campaignTonDTO.getLotCode(), campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
            weeksTonsToHostDTO = tonsReportService.filterWeekTonsToHostReport(id, LOT_CODE_FIELD, campaignTonDTO.getLotCode(), campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            if (ALL_ZONES.equals(zoneId)) {
                campaignTonDTO.setZoneName(allZones);
            } else {
                Zone zone = zoneService.findById(zoneId);
                campaignTonDTO.setZoneName(zone.getCode());
            }
            zoneId = zoneId == -1 ? null : zoneId;
            tonsToHostDTOs = tonsReportService.filterTonsToHostReportByZone(id, zoneId, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
            weeksTonsToHostDTO = tonsReportService.filterWeekTonsToHostReportByZone(id, zoneId, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            if (ALL_HYBRIDS.equals(hybridId)) {
                campaignTonDTO.setHybridName(allHybrids);
            } else {
                Hybrid hybrid = hybridService.findById(hybridId);
                campaignTonDTO.setHybridName(hybrid.getName());
            }
            hybridId = hybridId == -1 ? null : hybridId;
            tonsToHostDTOs = tonsReportService.filterTonsToHostReportByHybrid(id, hybridId, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
            weeksTonsToHostDTO = tonsReportService.filterWeekTonsToHostReportByHybrid(id, hybridId, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
        } else {
            campaignTonDTO.setProgram(textFilter.equals("") ? null : textFilter);
            tonsToHostDTOs = tonsReportService.filterTonsToHostReport(id, PROGRAM_FIELD, campaignTonDTO.getProgram(), campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
            weeksTonsToHostDTO = tonsReportService.filterTonsToHostReport(id, PROGRAM_FIELD, campaignTonDTO.getProgram(), campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
        }

        page.addObject(pageName, tonsToHostDTOs);
        page.addObject(CAMPAIGN_TON_DTO, campaignTonDTO);
        page.addObject(WEEKS_TONS_TO_HOST, weeksTonsToHostDTO);
        page.addObject(OPTION_FILTER, optionFilter);
        return page;
    }

    @RequestMapping(value = "/receive/campaign/", method = RequestMethod.POST)
    public ModelAndView receive(@RequestParam("campaignId") Integer campaignId) {
        log.info("Open receiving tons report.");
        return recieveView(campaignId);
    }

    @RequestMapping(value = "/receive/campaign/", method = RequestMethod.GET)
    public ModelAndView receive(HttpServletRequest request) {
        log.info("Open receiving tons report.");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        ModelAndView model = recieveView(campaignId);
        if (request.getSession().getAttribute("errorMessage") != null) {
            model.addObject("errorMessage", request.getSession().getAttribute("errorMessage"));
            request.getSession().removeAttribute("errorMessage");
        }
        return model;
    }

    private ModelAndView recieveView(Integer campaignId) {
        ModelAndView page = new ModelAndView(Constants.PAGE_RECEIVING_TONS_REPORT);

        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        page.addObject("campaignId", campaignId);
        page.addObject("campaign", campaignDTO);

        final List<ZoneDTO> zones = Lists.transform(zoneService.findAll(), new Function<Zone, ZoneDTO>() {
            @Nullable
            @Override
            public ZoneDTO apply(@Nullable Zone zone) {
                return new ZoneDTO(zone);
            }

        });
        page.addObject("zones", zones);

        List<HybridDTO> hybrids = Lists.transform(hybridService.findAll(), new Function<Hybrid, HybridDTO>() {
            @Nullable
            @Override
            public HybridDTO apply(@Nullable Hybrid hybrid) {
                return new HybridDTO(hybrid);
            }
        });
        log.info("Get hybrids");
        page.addObject("hybrids", hybrids);

        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);

        log.info("forward to page " + Constants.PAGE_RECEIVING_TONS_REPORT);
        return page;
    }

    @RequestMapping(value = "/receive/campaign/{id}/error", method = RequestMethod.GET)
    public String handleReceiveTonsError(HttpServletRequest request) {
        Integer campaignId = (Integer) request.getAttribute("campaignId");
        request.getSession().setAttribute("idCampaign", campaignId);
        request.getSession().setAttribute("errorMessage", "errorMessage");
        return "redirect:/report/tons/receive/campaign/";
    }

    @RequestMapping(value = "/receive/campaign/{campaignId}/xls", method = RequestMethod.GET)
    public ModelAndView receiveTonsToExcel(@PathVariable Integer campaignId, @RequestParam(value = "zone", required = false) Integer zone,
                                           @RequestParam(value = "optionFilter", required = false) Integer optionFilter,
                                           @RequestParam(value = "hybrid", required = false) Integer hybrid,
                                           @RequestParam(value = "textFilter", required = false) String textFilter,
                                           @RequestParam(value = "harvestWeekFrom") Long harvestWeekFrom,
                                           @RequestParam(value = "harvestWeekTo") Long harvestWeekTo) throws DataAccessException {

        return createReportReceiveTons(Constants.RECEIVE_TONS_EXPORT_XLS, campaignId, optionFilter, hybrid, textFilter, zone, new Date(harvestWeekFrom), new Date(harvestWeekTo));
    }

    @RequestMapping(value = "/receive/campaign/{campaignId}/pdf", method = RequestMethod.GET)
    public ModelAndView receiveTonsToPdf(@PathVariable Integer campaignId, @RequestParam(value = "zone", required = false) Integer zone,
                                         @RequestParam(value = "optionFilter", required = false) Integer optionFilter,
                                         @RequestParam(value = "hybrid", required = false) Integer hybrid,
                                         @RequestParam(value = "textFilter", required = false) String textFilter,
                                         @RequestParam(value = "harvestWeekFrom") Long harvestWeekFrom, @RequestParam(value = "harvestWeekTo") Long harvestWeekTo) throws DataAccessException {
        return createReportReceiveTons(Constants.RECEIVE_TONS_EXPORT_PDF, campaignId, optionFilter, hybrid, textFilter, zone, new Date(harvestWeekFrom), new Date(harvestWeekTo));
    }

    public ModelAndView createReportReceiveTons(String pageName, Integer campaign, Integer optionFilter, Integer hybridId, String textFilter, Integer zoneId, Date harvestDateFrom, Date harvestDateTo) {
        ModelAndView page = new ModelAndView(pageName);
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setHarvestDateFrom(harvestDateFrom);
        campaignTonDTO.setHarvestDateTo(harvestDateTo);
        campaignTonDTO.setCampaignId(campaign);
        List<ReceiveTonsDTO> receiveTonsDTOs;
        List<ReceiveTonsDTO> receivingTonsWeeks;
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            campaignTonDTO.setLotCode(textFilter.equals("") ? null : textFilter);
            receiveTonsDTOs = tonsReportService.findReceiveTons(campaign, LOT_CODE_FIELD, campaignTonDTO.getLotCode(), harvestDateFrom, harvestDateTo);
            receivingTonsWeeks = tonsReportService.findWeeksReceivingTons(campaign, LOT_CODE_FIELD, campaignTonDTO.getLotCode(), harvestDateFrom, harvestDateTo);
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            if (ALL_ZONES.equals(zoneId)) {
                campaignTonDTO.setZoneName(allZones);
            } else {
                Zone zone = zoneService.findById(zoneId);
                campaignTonDTO.setZoneName(zone.getCode());
            }
            zoneId = zoneId == -1 ? null : zoneId;
            receiveTonsDTOs = tonsReportService.findReceivingTonsByZone(campaign, zoneId, harvestDateFrom, harvestDateTo);
            receivingTonsWeeks = tonsReportService.findWeeksReceivingTonsByZone(campaign, zoneId, harvestDateFrom, harvestDateTo);
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            if (ALL_HYBRIDS.equals(hybridId)) {
                campaignTonDTO.setHybridName(allHybrids);
            } else {
                Hybrid hybrid = hybridService.findById(hybridId);
                campaignTonDTO.setHybridName(hybrid.getName());
            }
            hybridId = hybridId == -1 ? null : hybridId;
            receiveTonsDTOs = tonsReportService.findReceivingTonsByHybrid(campaign, hybridId, harvestDateFrom, harvestDateTo);
            receivingTonsWeeks = tonsReportService.findWeeksReceivingTonsByHybrid(campaign, hybridId, harvestDateFrom, harvestDateTo);
        } else {
            campaignTonDTO.setProgram(textFilter.equals("") ? null : textFilter);
            receiveTonsDTOs = tonsReportService.findReceiveTons(campaign, PROGRAM_FIELD, campaignTonDTO.getProgram(), harvestDateFrom, harvestDateTo);
            receivingTonsWeeks = tonsReportService.findWeeksReceivingTons(campaign, PROGRAM_FIELD, campaignTonDTO.getProgram(), harvestDateFrom, harvestDateTo);
        }


        page.addObject(pageName, receiveTonsDTOs);
        page.addObject(CAMPAIGN_TON_DTO, campaignTonDTO);
        page.addObject(Constants.CAMPAIGN_TON_WEEKS, receivingTonsWeeks);
        page.addObject(OPTION_FILTER, optionFilter);
        return page;
    }

    @RequestMapping(value = "statusReport/campaign/", method = RequestMethod.GET)
    public ModelAndView statusReport(HttpServletRequest request) {
        log.info("Init Tons Report Controller");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        ModelAndView model = statusReportView(campaignId);
        if (request.getSession().getAttribute("errorMessage") != null) {
            model.addObject("errorMessage", request.getSession().getAttribute("errorMessage"));
            request.getSession().removeAttribute("errorMessage");
        }
        return model;
    }

    private ModelAndView statusReportView(Integer campaignId) {
        ModelAndView page = new ModelAndView(Constants.PAGE_STATUS_REPORT);

        page.addObject("campaignId", campaignId);
        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        log.info("Get Campaign");
        page.addObject("campaignId", campaignId);
        page.addObject("campaign", campaignDTO);

        final List<ZoneDTO> zones = Lists.transform(zoneService.findAll(), new Function<Zone, ZoneDTO>() {
            @Nullable
            @Override
            public ZoneDTO apply(@Nullable Zone zone) {
                return new ZoneDTO(zone);
            }

        });
        page.addObject("selectOption", message.getMessage("application.selectOption"));
        page.addObject("zones", zones);


        List<HybridDTO> hybrids = Lists.transform(hybridService.findAll(), new Function<Hybrid, HybridDTO>() {
            @Nullable
            @Override
            public HybridDTO apply(@Nullable Hybrid hybrid) {
                return new HybridDTO(hybrid);
            }
        });
        log.info("Get hybrids");
        page.addObject("hybrids", hybrids);

        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);

        log.info("forward to page " + Constants.PAGE_STATUS_REPORT);
        return page;
    }

    @RequestMapping(value = "statusReport/campaign/", method = RequestMethod.POST)
    public ModelAndView statusReport(@RequestParam("campaignId") Integer campaignId) {
        log.info("Init Tons Report Controller");
        return statusReportView(campaignId);
    }

    @RequestMapping(value = "/statusReport/campaign/{id}/error", method = RequestMethod.GET)
    public String handleStatusReportError(HttpServletRequest request) {
        Integer campaignId = (Integer) request.getAttribute("campaignId");
        request.getSession().setAttribute("idCampaign", campaignId);
        request.getSession().setAttribute("errorMessage", "errorMessage");
        return "redirect:/report/tons/statusReport/campaign/";
    }

    @RequestMapping(value = "/statusReport/campaign/{id}/xls", method = RequestMethod.GET)
    @ResponseBody
    public ModelAndView statusExportToExcel(@PathVariable Integer id, @RequestParam(value = "hybrid") Integer hybrid,
                                            @RequestParam(value = "program") String program, @RequestParam(value = "hybridName") String hybridName) throws DataAccessException {
        log.info("Export to excel document");
        ModelAndView page = new ModelAndView(STATUS_EXPORT_EXCEL);
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(id);
        campaignTonDTO.setProgram(program);
        campaignTonDTO.setHybridId(hybrid);
        campaignTonDTO.setHybridName(hybridName);
        List<StatusReportDTO> statusReportDTOs = campaignService.filterToStatusReport(campaignTonDTO, id);

        page.addObject(STATUS_EXPORT_EXCEL, statusReportDTOs);
        page.addObject(CAMPAIGN_TON_DTO, campaignTonDTO);
        return page;
    }

    @RequestMapping(value = "statusReport/campaign/{id}/pdf", method = RequestMethod.GET)
    @ResponseBody
    public ModelAndView statusExportToPdf(@PathVariable Integer id, @RequestParam(value = "hybrid") Integer hybrid,
                                          @RequestParam(value = "program") String program, @RequestParam(value = "hybridName") String hybridName)
            throws DataAccessException {
        log.info("Export to pdf document");
        ModelAndView page = new ModelAndView(STATUS_EXPORT_PDF);
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(id);
        campaignTonDTO.setProgram(program);
        campaignTonDTO.setHybridId(hybrid);
        campaignTonDTO.setHybridName(hybridName);
        List<StatusReportDTO> statusReportDTOs = campaignService.filterToStatusReport(campaignTonDTO, id);
        page.addObject(STATUS_EXPORT_PDF, statusReportDTOs);
        page.addObject(CAMPAIGN_TON_DTO, campaignTonDTO);
        return page;
    }

    private ModelAndView bulkDestintationView(Integer campaignId) {
        ModelAndView page = new ModelAndView(Constants.PAGE_BULK_DESTINATION_REPORT);

        page.addObject("campaignId", campaignId);
        CampaignDTO campaignDTO = campaignService.findByIdAndActiveLots(campaignId);
        log.info("Get Campaign");
        page.addObject("campaignId", campaignId);
        page.addObject("campaign", campaignDTO);
        page.addObject("selectOption", message.getMessage("application.selectOption"));
        List<HybridDTO> hybrids = Lists.transform(hybridService.findAll(), new Function<Hybrid, HybridDTO>() {
            @Nullable
            @Override
            public HybridDTO apply(@Nullable Hybrid hybrid) {
                return new HybridDTO(hybrid);
            }
        });
        log.info("Get hybrids");
        page.addObject("hybrids", hybrids);

        TotalLotsDTO totalLotsDTO = lotService.findTotalLotsAndHas(campaignId);
        page.addObject(TOTAL_LOTS_HAS, totalLotsDTO);

        log.info("forward to page " + Constants.PAGE_BULK_DESTINATION_REPORT);
        return page;
    }

    @RequestMapping(value = "bulkDestination/campaign/", method = RequestMethod.POST)
    public ModelAndView bulkDestinationReport(@RequestParam("campaignId") Integer campaignId) {
        log.info("Init Tons Report Controller");
        return bulkDestintationView(campaignId);
    }

    @RequestMapping(value = "bulkDestination/campaign/", method = RequestMethod.GET)
    public ModelAndView bulkDestinationReport(HttpServletRequest request) {
        log.info("Init Tons Report Controller");
        Integer campaignId = (Integer) request.getSession().getAttribute("idCampaign");
        ModelAndView model = bulkDestintationView(campaignId);
        if (request.getSession().getAttribute("errorMessage") != null) {
            model.addObject("errorMessage", request.getSession().getAttribute("errorMessage"));
            request.getSession().removeAttribute("errorMessage");
        }
        return model;
    }

    @RequestMapping(value = "/bulkDestination/campaign/{id}/error", method = RequestMethod.GET)
    public String handleBulkDestinationError(HttpServletRequest request) {
        Integer campaignId = (Integer) request.getAttribute("campaignId");
        request.getSession().setAttribute("idCampaign", campaignId);
        request.getSession().setAttribute("errorMessage", "errorMessage");
        return "redirect:/report/tons/bulkDestination/campaign/";
    }

    @RequestMapping(value = "/bulkDestination/campaign/{id}/xls", method = RequestMethod.GET)
    @ResponseBody
    public ModelAndView bulkDestinationExportToExcel(@PathVariable Integer id, @RequestParam(value = "warehouseUnit") String warehouseUnit,
                                                     @RequestParam(value = "hybrid") Integer hybrid, @RequestParam(value = "hybridName") String hybridName)
            throws DataAccessException {
        log.info("Export to excel document");
        ModelAndView page = new ModelAndView(BULK_DESTINATION_EXPORT_EXCEL);
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(id);
        campaignTonDTO.setWarehouseUnit(warehouseUnit);
        campaignTonDTO.setHybridId(hybrid);
        campaignTonDTO.setHybridName(hybridName);
        List<BulkDestinationReportDTO> bulkDTOs = campaignService.filterBulkDestinationReport(campaignTonDTO, id);

        page.addObject(BULK_DESTINATION_EXPORT_EXCEL, bulkDTOs);
        page.addObject(CAMPAIGN_TON_DTO, campaignTonDTO);
        return page;
    }

    @RequestMapping(value = "bulkDestination/campaign/{id}/pdf", method = RequestMethod.GET)
    @ResponseBody
    public ModelAndView bulkDestinationExportToPdf(@PathVariable Integer id, @RequestParam(value = "warehouseUnit") String warehouseUnit,
                                                   @RequestParam(value = "hybrid") Integer hybrid, @RequestParam(value = "hybridName") String hybridName)
            throws DataAccessException {
        log.info("Export to pdf document");
        ModelAndView page = new ModelAndView(BULK_DESTINATION_EXPORT_PDF);
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(id);
        campaignTonDTO.setWarehouseUnit(warehouseUnit);
        campaignTonDTO.setHybridId(hybrid);
        campaignTonDTO.setHybridName(hybridName);
        List<BulkDestinationReportDTO> bulkDTOs = campaignService.filterBulkDestinationReport(campaignTonDTO, id);
        page.addObject(BULK_DESTINATION_EXPORT_PDF, bulkDTOs);
        page.addObject(CAMPAIGN_TON_DTO, campaignTonDTO);
        return page;
    }
}
