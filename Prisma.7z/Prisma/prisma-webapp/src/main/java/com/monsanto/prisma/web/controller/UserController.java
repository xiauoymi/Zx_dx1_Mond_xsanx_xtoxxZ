package com.monsanto.prisma.web.controller;


import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.Profile;
import com.monsanto.prisma.core.domain.Region;
import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.dto.ProfileDTO;
import com.monsanto.prisma.core.dto.UserDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.UserNotFoundException;
import com.monsanto.prisma.core.service.ProfileService;
import com.monsanto.prisma.core.service.RegionService;
import com.monsanto.prisma.core.service.UserService;
import com.monsanto.prisma.web.dto.RegionDTO;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Nullable;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {

    private static Logger log = Logger.getLogger(UserController.class);

    private static final String USER_LIST = "userList";

    @Autowired
    private UserService userService;

    @Autowired
    private ProfileService profileService;

    @Autowired
    private RegionService regionService;

    @RequestMapping(value = "/init", method = RequestMethod.GET)
    public ModelAndView init() {
        log.debug("Users Management Init");
        ModelAndView page = new ModelAndView(USER_LIST);

        List<User> userList = userService.findAll();
        List<UserDTO> userDTOList = Lists.transform(userList, new Function<User, UserDTO>() {
            @Nullable
            @Override
            public UserDTO apply(@Nullable User user) {
                return new UserDTO(user);
            }
        });
        page.addObject("userList", userDTOList);

        List<Profile> profiles = profileService.findByEnabled(true);
        List<ProfileDTO> profileDTOList = Lists.transform(profiles, new Function<Profile, ProfileDTO>() {
            @Nullable
            @Override
            public ProfileDTO apply(@Nullable Profile profile) {
                return new ProfileDTO(profile);
            }
        });
        page.addObject("profileList", profileDTOList);

        List<Region> regions = regionService.findAll();
        List<RegionDTO> regionDTOList = Lists.transform(regions, new Function<Region, RegionDTO>() {
            @Nullable
            @Override
            public RegionDTO apply(@Nullable Region region) {
                return new RegionDTO(region);
            }
        });
        page.addObject("regionList", regionDTOList);

        return page;
    }

    @RequestMapping(method = RequestMethod.PUT)
    @ResponseBody
    public JsonResponse<UserDTO> update(@RequestBody UserDTO userDTO) {
        User user = null;
        try {
            user = userService.update(userDTO);
        } catch (BusinessException ex) {
            log.error("duplicate error -" + ex.getMessage(), ex);
            return new JsonResponse(Boolean.FALSE, "prisma.user.new.duplicate");
        }

        return new JsonResponse<UserDTO>("prisma.user.update.ok", new UserDTO(user));
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public UserDTO delete(@PathVariable(value = "id") Integer id) throws UserNotFoundException {
        User user = userService.delete(id);
        return new UserDTO(user);
    }

    @RequestMapping(method = RequestMethod.POST)
    @ResponseBody
    public JsonResponse<UserDTO> newUser(@RequestBody UserDTO userDTO) {
        User user = null;
        try {
            user = userService.newUser(userDTO);
        } catch (BusinessException ex) {
            log.error("duplicate error -" + ex.getMessage(), ex);
            return new JsonResponse(Boolean.FALSE, "prisma.user.new.duplicate");
        }
        return new JsonResponse<UserDTO>("prisma.user.new.ok", new UserDTO(user));
    }


}
