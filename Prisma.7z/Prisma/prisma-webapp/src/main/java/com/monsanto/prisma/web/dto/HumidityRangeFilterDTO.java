package com.monsanto.prisma.web.dto;

import com.monsanto.prisma.core.dto.HumidityRangeDTO;

import java.io.Serializable;
import java.util.List;

/**
 * Created by PGSETT on 27/06/2014.
 */
public class HumidityRangeFilterDTO implements Serializable {
    private String hybridName;
    private List<HumidityRangeDTO> humidityRanges;

    public HumidityRangeFilterDTO() {
    }

    public HumidityRangeFilterDTO(List<HumidityRangeDTO> humidityRanges) {
        this.humidityRanges = humidityRanges;
    }

    public List<HumidityRangeDTO> getHumidityRanges() {
        return humidityRanges;
    }

    public void setHumidityRanges(List<HumidityRangeDTO> humidityRanges) {
        this.humidityRanges = humidityRanges;
    }

    public HumidityRangeFilterDTO(String hybridName) {
        this.hybridName = hybridName;
    }

    public String getHybridName() {
        return hybridName;
    }

    public void setHybridName(String hybridName) {
        this.hybridName = hybridName;
    }
}
