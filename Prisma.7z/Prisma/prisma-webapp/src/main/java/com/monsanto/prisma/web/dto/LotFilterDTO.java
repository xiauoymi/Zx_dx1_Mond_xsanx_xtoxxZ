package com.monsanto.prisma.web.dto;

import com.monsanto.prisma.core.domain.LotFilter;

import java.io.Serializable;

/**
 * Created by EPESTE on 19/05/2014.
 */
public class LotFilterDTO implements Serializable {

    private Integer id;

    private String field;

    private String value;

    private Integer typeField;

    public LotFilterDTO() {
    }

    public LotFilterDTO(LotFilter lotFilter) {
        this.id = lotFilter.getId();
        this.field = lotFilter.getField();
        this.typeField = lotFilter.getTypeField();
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setField(String field) {
        this.field = field;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public void setTypeField(Integer typeField) {
        this.typeField = typeField;
    }

    public Integer getId() {
        return id;
    }

    public String getField() {
        return field;
    }

    public String getValue() {
        return value;
    }

    public Integer getTypeField() {
        return typeField;
    }
}

