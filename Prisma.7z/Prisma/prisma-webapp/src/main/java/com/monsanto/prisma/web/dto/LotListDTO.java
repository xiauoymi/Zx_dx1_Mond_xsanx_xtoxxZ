package com.monsanto.prisma.web.dto;

import com.monsanto.prisma.core.dto.LotDTO;

import java.io.Serializable;
import java.util.List;

/**
 * Created by PGSETT on 10/06/2014.
 */
public class LotListDTO implements Serializable {
    private List<LotDTO> lotDTO;

    public LotListDTO(List<LotDTO> lotDTO) {
        this.lotDTO = lotDTO;
    }

    public List<LotDTO> getLotDTO() {
        return lotDTO;
    }

    public void setLotDTO(List<LotDTO> lotDTO) {
        this.lotDTO = lotDTO;
    }
}
