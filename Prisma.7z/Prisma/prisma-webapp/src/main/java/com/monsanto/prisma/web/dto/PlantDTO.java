package com.monsanto.prisma.web.dto;

import com.monsanto.prisma.core.domain.Plant;

import java.io.Serializable;

/**
 * Created by BSBUON on 5/19/2014.
 */
public class PlantDTO implements Serializable {

    private Integer id;
    private String name;

    public PlantDTO() {
    }

    public PlantDTO(Plant plant) {
        this.id = plant.getId();
        this.name = plant.getName();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
