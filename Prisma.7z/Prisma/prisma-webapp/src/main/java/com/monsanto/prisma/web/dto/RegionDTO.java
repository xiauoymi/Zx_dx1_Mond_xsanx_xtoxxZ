package com.monsanto.prisma.web.dto;

import com.monsanto.prisma.core.domain.Region;

/**
 * Created by BSBUON on 5/19/2014.
 */
public class RegionDTO {

    private Integer id;
    private String name;

    public RegionDTO() {
    }

    public RegionDTO(Region region) {
        this.id = region.getId();
        this.name = region.getName();
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RegionDTO regionDTO = (RegionDTO) o;

        if (id != null ? !id.equals(regionDTO.id) : regionDTO.id != null) return false;
        if (name != null ? !name.equals(regionDTO.name) : regionDTO.name != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }
}
