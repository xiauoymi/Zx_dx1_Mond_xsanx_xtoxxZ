package com.monsanto.prisma.web.dto;

import com.monsanto.prisma.core.domain.Report1;
import com.monsanto.prisma.core.dto.LotDTO;

import javax.persistence.Column;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by EPESTE on 23/07/2014.
 */
public class Report1DTO implements Serializable {
    private String pathFile;

    private Date dateProccess;

    private int modified;

    private int omitted;

    private List<LotDTO> lotDTOs;

    public Report1DTO(Report1 report1) {
        this.pathFile = report1.getPathFile();
        this.dateProccess = report1.getDateProccess();
        this.modified = report1.getModified();
        this.omitted = report1.getOmitted();
        this.lotDTOs = report1.getLotDTOs();
    }

    public String getPathFile() {
        return pathFile;
    }

    public void setPathFile(String pathFile) {
        this.pathFile = pathFile;
    }

    public Date getDateProccess() {
        return dateProccess;
    }

    public void setDateProccess(Date dateProccess) {
        this.dateProccess = dateProccess;
    }

    public int getModified() {
        return modified;
    }

    public void setModified(int modified) {
        this.modified = modified;
    }

    public int getOmitted() {
        return omitted;
    }

    public void setOmitted(int omitted) {
        this.omitted = omitted;
    }

    public List<LotDTO> getLotDTOs() {
        return lotDTOs;
    }

    public void setLotDTOs(List<LotDTO> lotDTOs) {
        this.lotDTOs = lotDTOs;
    }
}
