package com.monsanto.prisma.web.dto;

import com.monsanto.prisma.core.domain.Report2;
import com.monsanto.prisma.core.dto.LotDTO;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * Created by PGSETT on 28/07/2014.
 */
public class Report2DTO implements Serializable {
    private String pathFile;

    private Date dateProccess;

    private int modified;

    private int omitted;

    private List<LotDTO> lotDTOs;

    public Report2DTO(Report2 report2) {
        this.pathFile = report2.getPathFile();
        this.dateProccess = report2.getDateProccess();
        this.modified = report2.getModified();
        this.omitted = report2.getOmitted();
        this.lotDTOs = report2.getLotDTOs();
    }

    public String getPathFile() {
        return pathFile;
    }

    public void setPathFile(String pathFile) {
        this.pathFile = pathFile;
    }

    public Date getDateProccess() {
        return dateProccess;
    }

    public void setDateProccess(Date dateProccess) {
        this.dateProccess = dateProccess;
    }

    public int getModified() {
        return modified;
    }

    public void setModified(int modified) {
        this.modified = modified;
    }

    public int getOmitted() {
        return omitted;
    }

    public void setOmitted(int omitted) {
        this.omitted = omitted;
    }

    public List<LotDTO> getLotDTOs() {
        return lotDTOs;
    }

    public void setLotDTOs(List<LotDTO> lotDTOs) {
        this.lotDTOs = lotDTOs;
    }
}
