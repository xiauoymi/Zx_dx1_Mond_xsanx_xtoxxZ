package com.monsanto.prisma.web.exception;

/**
 * Created by PGSETT on 15/10/2014.
 */
public class ControllerException extends Exception {

    public ControllerException() {
    }


    public ControllerException(String message) {
        super(message);
    }


    public ControllerException(Throwable cause) {
        super(cause);
    }


    public ControllerException(String message, Throwable cause) {
        super(message, cause);
    }
}
