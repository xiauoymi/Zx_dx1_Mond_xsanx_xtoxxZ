package com.monsanto.prisma.web.security;

import org.springframework.security.core.GrantedAuthority;

/**
 * It represent a permission.
 */
public class Authority {

    public static final String ADMINISTRATOR_ROLE = "SYSTEM_ADMINISTRATOR";

    private Integer id;

    private String name;

    private String description;

    private String roleName;
    public static final String APPLICATION_ACCESS = "APPLICATION_ACCESS";

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }
}
