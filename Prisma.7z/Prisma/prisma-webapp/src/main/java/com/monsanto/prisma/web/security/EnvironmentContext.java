package com.monsanto.prisma.web.security;

/**
 * Provides information about the environment the application is running.
 */
public interface EnvironmentContext {

    boolean isLocalEnvironment();

    boolean isDevEnvironment();

    String getEnvironment();

}
