package com.monsanto.prisma.web.security;


import com.monsanto.prisma.core.domain.Region;
import com.monsanto.prisma.core.domain.User;

import java.util.List;

/**
 * Strategy to provide access to the security data (user)
 * TODO change this object name
 *
 * @author CAFAU
 */
public interface SecurityHolderStrategy {

    public static final String ALL_SERVICE_CENTERS = "ALL_SERVICE_CENTERS"; // Move this to a proper class

    /**
     * Get The current User Logged.
     * @return
     */
    public User getCurrentUser();

    /**
     * Get Regions For the Current User Logged
     */
    public List<Region> getRegionsCurrentUser();

    /**
     * Returns true if the user has the required permission.
     * False if not.
     *
     * @param permission the permission to check.
     * @return true is user has the permission
     */
    public boolean hasUserPermission(String permission);

    /**
     * @return True if this running environment is for Local Development
     */
    public boolean isLocalEnvironment();

    /**
     * @return True if this running environment is for Development
     */
    public boolean isDevEnvironment();
}
