package com.monsanto.prisma.web.security;

import com.monsanto.prisma.core.domain.Region;
import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.security.UserWrapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
* Provides access to the security data (user) via the SpringContextHolder
*/
public class SecurityHolderStrategyImpl implements SecurityHolderStrategy,EnvironmentContext {

    private static final String DEVELOPMENT_ENVIRONMENT = "dev";
    private static final String LOCAL_ENVIRONMENT = "win";

    /**
     * The environment name where the application is running.
     * <br/>
     * This can be: "win, dev, qc, prod".
     */
    private String environment;

    public SecurityHolderStrategyImpl() {
    }

    public User getCurrentUser() {
        Authentication authentication = getAuthentication();

        if (authentication != null) {
            Object o = authentication.getPrincipal();

            if (o instanceof UserWrapper) {
                return ((UserWrapper) o).getUser();
            }
        }
        return null;
    }

    @Override
    public List<Region> getRegionsCurrentUser() {
        User user = getCurrentUser();
        return user.getRegions().size()>0 ? user.getRegions() : new ArrayList<Region>();
    }

    private Authentication getAuthentication() {
        return getContext().getAuthentication();
    }

    public boolean hasUserPermission(String permission) {
        Authentication authentication = getAuthentication();

        if (authentication != null) {
            Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();

            if (authorities != null) {
                for (GrantedAuthority grantedAuthority : authorities) {
                    if (permission.equals(grantedAuthority.getAuthority())) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    @Override
    public boolean isLocalEnvironment() {
        return LOCAL_ENVIRONMENT.equals(environment);
    }

    @Override
    public boolean isDevEnvironment() {
        return DEVELOPMENT_ENVIRONMENT.equals(environment);
    }

    protected SecurityContext getContext() {
        return SecurityContextHolder.getContext();
    }

    @Override
    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

}
