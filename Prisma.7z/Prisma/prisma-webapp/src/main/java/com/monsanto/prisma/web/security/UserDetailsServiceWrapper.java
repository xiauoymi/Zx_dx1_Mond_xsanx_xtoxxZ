package com.monsanto.prisma.web.security;

import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.exception.UserNotFoundException;
import com.monsanto.prisma.core.security.UserDetailsImpl;
import com.monsanto.prisma.core.service.UserService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Wraps the standard UserDao for Spring Security
 */
public class UserDetailsServiceWrapper implements UserDetailsService {

    private static final Logger log = Logger.getLogger(UserDetailsServiceWrapper.class);

    @Autowired
    private UserService userService;

    private User user;

    private List<SimpleGrantedAuthority> authorities;


    @Override
    public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {

        log.debug("User Logged: " + userName);
        try {
            if (userName == null) {
                log.error("User is null");
                return new UserDetailsImpl();
            }
            log.debug("Search user with userName: " + userName);
            user = userService.findByUserName(userName);
            if(user==null){
                throw new UserNotFoundException();
            }
            log.debug("User founded. fullName: " + user.getFullName());
            authorities = userService.findAuthoritiesByUserName(userName);
            log.debug("Authorities Granted.");
            return new UserDetailsImpl(user, authorities);
        } catch (UserNotFoundException e) {
            log.error("User " + userName + " not founded");
            throw new UsernameNotFoundException(e.getMessage());
        }
    }

}
