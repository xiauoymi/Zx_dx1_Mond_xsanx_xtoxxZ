package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.BulkDestinationReportDTO;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Created by PGSETT on 08/09/2014.
 */
public class BulkDestinationReportExcelView extends AbstractExcelView {

    private static final short INIT_RECORD = 5;
    private MessageSource messageSource;
    private static final String BULK_DESTINATION_REPORT_LIST = "bulkDestinationExcel";
    private static final String CAMPAIGN_TON_DTO = "campaignTonDTO";
    private static final Double TO_TONS = 0.001D;

    private HSSFWorkbook workbook;

    private HSSFSheet excelSheet;

    private List<BulkDestinationReportDTO> bulkList;

    private CampaignTonDTO campaignDTO;

    private Locale locale;

    @Override
    protected void buildExcelDocument(Map model, HSSFWorkbook hssfWorkbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            campaignDTO = (CampaignTonDTO) model.get(CAMPAIGN_TON_DTO);
            request.setAttribute("campaignId", campaignDTO.getCampaignId());
            workbook =  hssfWorkbook;
            bulkList = (List<BulkDestinationReportDTO>) model.get(BULK_DESTINATION_REPORT_LIST);
            excelSheet = workbook.createSheet(Constants.SHEET_NAME);
            locale = LocaleContextHolder.getLocale();

            createMainInformationReport();
            setExcelHeader();

            if (bulkList != null) {
                setExcelRows();
            }
        } catch (Exception ex) {
            RequestDispatcher rd = request.getRequestDispatcher("error");
            rd.forward(request, response);
        }
    }

    private void createMainInformationReport() {
        Utilities.addExcelRow(excelSheet, workbook, messageSource.getMessage("report.tons.bulkDestination.title", null, locale), 0, Constants.TWO);

        String strWarehouseUnit = messageSource.getMessage("report.tons.bulkDestination.header.warehouseUnit.label", null, locale) + ":";
        strWarehouseUnit += campaignDTO.getWarehouseUnit() != null && !campaignDTO.getWarehouseUnit().equals("") ? campaignDTO.getWarehouseUnit() : "-";
        Utilities.addExcelRow(excelSheet, workbook, strWarehouseUnit, Constants.ONE, Constants.TWO);

        String strHybrid = messageSource.getMessage("report.tons.statusReport.header.hybrid.label", null, locale) + ":";
        strHybrid += campaignDTO.getHybridId() != null ? campaignDTO.getHybridName() : "-";
        Utilities.addExcelRow(excelSheet, workbook, strHybrid, Constants.TWO, Constants.TWO);
    }


    public void setExcelHeader() {
        CellStyle cellStyle = createCellStyle(true, HSSFColor.SEA_GREEN.index);
        createFont(cellStyle);

        HSSFRow excelHeader = excelSheet.createRow(Constants.FOUR);
        Utilities.createCellString(excelHeader, Constants.ONE, messageSource.getMessage("report.tons.bulkDestination.header.warehouseUnit.label", null, locale), cellStyle);
        Utilities.createCellString(excelHeader, Constants.TWO, messageSource.getMessage("report.tons.statusReport.header.hybrid.label", null, locale), cellStyle);
        Utilities.createCellString(excelHeader, Constants.THREE, messageSource.getMessage("report.tons.bulkDestination.header.husking.label", null, locale), cellStyle);
    }

    private void setExcelRows() {
        int record = INIT_RECORD;
        int i = Constants.ONE;
        boolean flag = true;
        int initRecord = INIT_RECORD;
        for (BulkDestinationReportDTO bulk : bulkList) {
            String warehouseUnit = bulk.getWarehouseUnit();
            if (i < bulkList.size() && warehouseUnit.equals(bulkList.get(i).getWarehouseUnit())) {
                if (flag) {
                    initRecord = record;
                }
                addRow(record++, bulk);
                flag = false;
            } else {
                addRow(record++, bulk);
                addTotalRows(Constants.THREE, initRecord, record++);
                initRecord = record;
                flag = true;
            }
            i++;
        }
    }

    private void addRow(Integer record, BulkDestinationReportDTO bulk) {
        CellStyle cellStyle = createCellStyle(false, HSSFColor.LIGHT_GREEN.index);
        HSSFRow excelRow = excelSheet.createRow(record++);
        Utilities.createCellString(excelRow, Constants.ONE, bulk.getWarehouseUnit(), cellStyle);
        Utilities.createCellString(excelRow, Constants.TWO, bulk.getHybridName(), cellStyle);
        Utilities.createCellDouble(excelRow, Constants.THREE, bulk.getHuskingKgDsLot() * TO_TONS, cellStyle);
    }


    private void addTotalRows(int colIndex, int initRecord, int record) {
        CellStyle cellStyle = createCellStyle(false, HSSFColor.SEA_GREEN.index);
        int recordHasta = record;

        HSSFRow excelRow = excelSheet.createRow(record++);
        Utilities.createCellString(excelRow, Constants.ONE, "", cellStyle);
        Utilities.createCellString(excelRow, Constants.TWO, "", cellStyle);

        Cell cell = excelRow.createCell(colIndex);
        cell.setCellStyle(cellStyle);
        String colString = CellReference.convertNumToColString(colIndex);
        cell.setCellFormula("SUM(" + colString + (initRecord + Constants.ONE) + ":" + colString + recordHasta + ")");

    }

    private CellStyle createCellStyle(Boolean wrapText, short color) {
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setWrapText(wrapText);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setFillForegroundColor(color);
        return cellStyle;
    }

    private void createFont(CellStyle cellStyle) {
        Font font = workbook.createFont();
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        cellStyle.setFont(font);
    }


    public MessageSource getMessageSource() {
        return messageSource;
    }

    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}
