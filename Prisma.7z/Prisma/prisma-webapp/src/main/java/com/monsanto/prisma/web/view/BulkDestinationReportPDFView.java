package com.monsanto.prisma.web.view;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.prisma.core.dto.BulkDestinationReportDTO;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import com.monsanto.prisma.web.utils.AbstractITextPdfView;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.List;

/**
 * Created by PGSETT on 08/09/2014.
 */
public class BulkDestinationReportPDFView extends AbstractITextPdfView {

    private MessageSource messageSource;

    private static final String BULK_DESTINATION_REPORT_PDF = "bulkDestinationPDF";
    private static final String CAMPAIGN_TON_DTO = "campaignTonDTO";
    private static final Double TO_TONS = 0.001D;

    private Double totalHuskingKgDsLot = 0D;

    @Override
    protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            CampaignTonDTO campaignDTO = (CampaignTonDTO) model.get(CAMPAIGN_TON_DTO);
            request.setAttribute("campaignId", campaignDTO.getCampaignId());
            List<BulkDestinationReportDTO> bulkList = (List<BulkDestinationReportDTO>) model.get(BULK_DESTINATION_REPORT_PDF);
            totalHuskingKgDsLot = 0D;
            PdfPTable table = new PdfPTable(Constants.THREE);
            table.setWidthPercentage(100.0f);
            table.setSpacingBefore(Constants.FIFTEEN);


            Locale locale = LocaleContextHolder.getLocale();
            Paragraph title = new Paragraph(messageSource.getMessage("report.tons.bulkDestination.title", null, locale));
            document.add(title);
            document.add(Chunk.NEWLINE);
            String strWarehouseUnit = messageSource.getMessage("report.tons.bulkDestination.header.warehouseUnit.label", null, locale) + ":";
            strWarehouseUnit += campaignDTO.getWarehouseUnit() != null && !campaignDTO.getWarehouseUnit().equals("") ? campaignDTO.getWarehouseUnit() : "-";
            Paragraph warehouseUnit = new Paragraph(strWarehouseUnit);
            document.add(warehouseUnit);

            document.add(Chunk.NEWLINE);
            String strHybrid = messageSource.getMessage("report.tons.statusReport.header.hybrid.label", null, locale) + ":";
            strHybrid += campaignDTO.getHybridId() != null ? campaignDTO.getHybridName() : "-";

            Paragraph hybrid = new Paragraph(strHybrid);
            document.add(hybrid);


            setHeader(table);
            if (bulkList != null) {
                setLotValues(table, bulkList);
            }
            document.add(table);
        } catch (Exception ex) {
            logger.error("error in pdf view -" + ex.getMessage(), ex);
            RequestDispatcher rd = request.getRequestDispatcher("error");
            rd.forward(request, response);
        }
    }

    private void setLotValues(PdfPTable table, List<BulkDestinationReportDTO> bulkList) throws BadElementException {
        int i = 1;
        for (BulkDestinationReportDTO bulk : bulkList) {
            String warehouseUnit = bulk.getWarehouseUnit();
            if (i < bulkList.size() && warehouseUnit.equals(bulkList.get(i).getWarehouseUnit())) {
                addRow(table, bulk);
                calculateTotals(bulk);
            } else {
                addRow(table, bulk);
                calculateTotals(bulk);
                addTotalRows(table);
                if (i != bulkList.size()) {
                    totalHuskingKgDsLot = 0D;
                }
            }
            i++;
        }

    }

    private void addTotalRows(PdfPTable table) throws BadElementException {
        Utilities.setPdfValue(table, "", Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, "", Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, totalHuskingKgDsLot, Color.WHITE, Color.LIGHT_GRAY);
    }

    private void addRow(PdfPTable table, BulkDestinationReportDTO bulk) throws BadElementException {
        Utilities.setPdfValue(table, bulk.getWarehouseUnit(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, bulk.getHybridName(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, bulk.getHuskingKgDsLot() * TO_TONS, Color.BLACK, Color.white);
    }

    private void calculateTotals(BulkDestinationReportDTO bulk) {
        totalHuskingKgDsLot += bulk.getHuskingKgDsLot() * TO_TONS;
    }


    private void setHeader(PdfPTable table) throws BadElementException {
        Locale locale = LocaleContextHolder.getLocale();
        Font font = Utilities.setFont(Color.WHITE);
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(Color.GRAY);
        cell.setPadding(Constants.EIGHT);

        cell.setPhrase(new Phrase(messageSource.getMessage("report.tons.bulkDestination.header.warehouseUnit.label", null, locale), font));
        table.addCell(cell);

        cell.setPhrase(new Phrase(messageSource.getMessage("report.tons.statusReport.header.hybrid.label", null, locale), font));
        table.addCell(cell);

        cell.setPhrase(new Phrase(messageSource.getMessage("report.tons.bulkDestination.header.husking.label", null, locale), font));
        table.addCell(cell);
    }


    public MessageSource getMessageSource() {
        return messageSource;
    }

    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}

