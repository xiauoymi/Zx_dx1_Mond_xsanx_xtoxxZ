package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.DataReportForecastDTO;
import com.monsanto.prisma.core.dto.ForecastReportDTO;
import com.monsanto.prisma.core.dto.MonthYearDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.context.MessageSource;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by EPESTE on 10/12/2014.
 */
public class ForecastReportExcelView extends AbstractExcelView {
    private MessageSource messageSource;

    private HSSFWorkbook workbook;

    private HSSFSheet excelSheet;

    private ForecastReportDTO forecastReportDTO = null;
    private static final String CAMPAIGN_FORECAST_DTO = "campaignId";
    private static final String FORECAST_REPORT_DTO = "forecastReportDTO";
    private static final String ESTIMATED_HEADER = "Estimado";
    private static final String REAL_HEADER = "Real";
    private static final String MONTH_HEADER = "Mes";
    private static final String GRAN_PROGRAM_HEADER = "Gran Programa";
    private static final String HEADER_TN_RW = "TN RW";
    private static final String HEADER_TN_DS = "TN DS";
    private static final String HEADER_TN_FNG = "TN FNG";

    Double sumTotalEstimated = 0D;
    Double sumTotalReal = 0D;

    @Override
    protected void buildExcelDocument(Map<String, Object> model, HSSFWorkbook hssfWorkbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            Integer campaignId = (Integer) model.get(CAMPAIGN_FORECAST_DTO);
            request.setAttribute("campaignId", campaignId);
            forecastReportDTO = (ForecastReportDTO) model.get(FORECAST_REPORT_DTO);
            this.workbook = hssfWorkbook;
            createHeader(forecastReportDTO.getRange());
            createBody(forecastReportDTO);
        } catch (Exception ex) {
            RequestDispatcher rd = request.getRequestDispatcher("error");
            rd.forward(request, response);
        }
    }

    private void createBody(ForecastReportDTO forecastReportDTO) {
        CellStyle cellStyle = createCellStyle(true, HSSFColor.LIGHT_GREEN.index);
        createFont(cellStyle, HSSFColor.AUTOMATIC.index);
        int rowIndex = processRow(HEADER_TN_RW, forecastReportDTO.getRwForecastDTOs(), Constants.TWO, cellStyle);
        rowIndex = processRow(HEADER_TN_DS, forecastReportDTO.getDsForecastDTOs(), rowIndex + Constants.ONE, cellStyle);
        processRow(HEADER_TN_FNG, forecastReportDTO.getFngForecastDTOs(), rowIndex + Constants.ONE, cellStyle);
    }

    private int processRow(String typeName, List<DataReportForecastDTO> list, Integer rowIndex, CellStyle cellStyle) {
        boolean isFirstTime = true;
        String granProgramActual = null;
        HSSFRow excelRow = null;
        int cellIndex = 0;

        for (DataReportForecastDTO forecastDTO : list) {
            if (isNew(granProgramActual, forecastDTO.getGranProgram())) {
                granProgramActual = forecastDTO.getGranProgram();
                excelRow = excelSheet.createRow(rowIndex++);
            }
            cellIndex = Constants.ONE;
            if (isFirstTime) {
                Utilities.createCellString(excelRow, cellIndex - 1, typeName, cellStyle);
                isFirstTime = false;
            }
            Utilities.createCellString(excelRow, cellIndex, forecastDTO.getGranProgram(), cellStyle);
            dateProcess(forecastDTO, excelRow, cellIndex, cellStyle);
        }
        return rowIndex;
    }

    private void dateProcess(DataReportForecastDTO forecastDTO, HSSFRow excelRow, Integer cellIndex, CellStyle cellStyle) {
        for (Date date : forecastReportDTO.getRange()) {
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            Integer month = cal.get(Calendar.MONTH) + Constants.ONE;
            Integer year = cal.get(Calendar.YEAR);
            processTotalValues(forecastDTO.getRealDate(), forecastDTO.getTotalReal(), month, year, excelRow, cellIndex + Constants.TWO, cellStyle);
            processTotalValues(forecastDTO.getEstimatedDate(), forecastDTO.getTotalEstimated(), month, year, excelRow, cellIndex + Constants.ONE, cellStyle);
            cellIndex = cellIndex + Constants.TWO;
        }
    }

    private void processTotalValues(String date, Double totalValue, Integer month, Integer year, HSSFRow excelRow, Integer cellIndex, CellStyle cellStyle) {
        if (date != null) {
            MonthYearDTO rwRealDate = Utilities.getMonthAndYear(date);
            Integer rwRealMonth = rwRealDate.getMonth();
            Integer rwRealYear = rwRealDate.getYear();
            if (date != null && month.equals(rwRealMonth) && year.equals(rwRealYear)) {
                Double value = Utilities.getDoubleValue(excelRow, cellIndex);
                value += totalValue;
                Utilities.createCellDouble(excelRow, cellIndex, value, cellStyle);
            } else {
                Utilities.setCellStyle(excelRow, cellIndex, cellStyle);
            }
        } else {
            Utilities.setCellStyle(excelRow, cellIndex, cellStyle);
        }
    }

    private boolean isNew(String granProgramActual, String granProgram) {
        if (granProgramActual == null) {
            return true;
        }
        if (!granProgram.equals(granProgramActual)) {
            return true;
        }
        return false;
    }

    private void createHeader(List<Date> dates) {
        excelSheet = workbook.createSheet(Constants.SHEET_NAME);
        CellStyle cellStyle = createCellStyle(true, HSSFColor.SEA_GREEN.index);
        createFont(cellStyle, HSSFColor.WHITE.index);
        HSSFRow excelMonthHeader = excelSheet.createRow(Constants.INT_ZERO);
        HSSFRow excelHeader = excelSheet.createRow(Constants.ONE);
        int initIndex = Constants.ONE;
        Utilities.createCellString(excelMonthHeader, initIndex, GRAN_PROGRAM_HEADER, cellStyle);
        for (Date date : dates) {
            Utilities.createCellString(excelMonthHeader, initIndex + Constants.ONE, MONTH_HEADER, cellStyle);
            Utilities.createCellString(excelHeader, initIndex + Constants.ONE, ESTIMATED_HEADER, cellStyle);
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            Integer month = cal.get(Calendar.MONTH) + Constants.ONE;
            Utilities.createCellString(excelMonthHeader, initIndex + Constants.TWO, month.toString(), cellStyle);
            Utilities.createCellString(excelHeader, initIndex + Constants.TWO, REAL_HEADER, cellStyle);
            initIndex = initIndex + Constants.TWO;
        }
    }

    private CellStyle createCellStyle(Boolean wrapText, short color) {
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setWrapText(wrapText);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setFillForegroundColor(color);
        return cellStyle;
    }

    private void createFont(CellStyle cellStyle, short colorIndex) {
        Font font = workbook.createFont();
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(colorIndex);
        cellStyle.setFont(font);
    }

    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}
