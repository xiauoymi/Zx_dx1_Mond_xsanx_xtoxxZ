package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * Created by PGSETT on 11/08/2014.
 */
public class LotListExcelView extends AbstractExcelView {

    public static final int INIT_RECORD = 3;
    private HSSFCellStyle dateStyle;
    public static final String DATE_PATTERN = "datePattern";
    public static final String EXPORT_EXCEL = "lotListExcel";

    @Override
    protected void buildExcelDocument(Map model, HSSFWorkbook hssfWorkbook, HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse) throws Exception {
        try {
            List<LotDTO> lotDTOList = (List<LotDTO>) model.get(EXPORT_EXCEL);

            HSSFSheet excelSheet = hssfWorkbook.createSheet(Constants.SHEET_NAME);
            short df = hssfWorkbook.createDataFormat().getFormat(model.get(DATE_PATTERN).toString());
            dateStyle = hssfWorkbook.createCellStyle();
            dateStyle.setDataFormat(df);
            setExcelHeader(excelSheet);
            setExcelRows(excelSheet, lotDTOList);
        } catch (Exception ex) {
            RequestDispatcher rd = httpServletRequest.getRequestDispatcher("error");
            rd.forward(httpServletRequest, httpServletResponse);
        }
    }

    private void setExcelHeader(HSSFSheet excelSheet) {
        HSSFRow excelHeader = excelSheet.createRow(Constants.TWO);
        excelHeader.createCell(Constants.INT_ZERO).setCellValue("");
        excelHeader.createCell(Constants.ONE).setCellValue(Constants.EXCEL_HEADER_LOT);
        excelHeader.createCell(Constants.TWO).setCellValue(Constants.EXCEL_HEADER_ZONE);
        excelHeader.createCell(Constants.THREE).setCellValue(Constants.EXCEL_HEADER_FIELD);
        excelHeader.createCell(Constants.FOUR).setCellValue(Constants.EXCEL_HEADER_HYBRID);
        excelHeader.createCell(Constants.FIVE).setCellValue(Constants.EXCEL_HEADER_HAS_REG);
        excelHeader.createCell(Constants.SIX).setCellValue(Constants.EXCEL_HEADER_HAS_HARV);
        excelHeader.createCell(Constants.SEVEN).setCellValue(Constants.EXCEL_HEADER_CLIENT);
        excelHeader.createCell(Constants.EIGHT).setCellValue(Constants.EXCEL_HEADER_CERT);
        excelHeader.createCell(Constants.NINE).setCellValue(Constants.EXCEL_HEADER_EXP);
        excelHeader.createCell(Constants.TEN).setCellValue(Constants.EXCEL_HEADER_GERMOPLASMA);
        setExcelHeaderSecond(excelHeader);
        setExcelHeaderThird(excelHeader);
        setExcelHeaderFour(excelHeader);
    }

    private void setExcelHeaderSecond(HSSFRow excelHeader) {
        excelHeader.createCell(Constants.ELEVEN).setCellValue(Constants.EXCEL_HEADER_GRAN_PROGRAM);
        excelHeader.createCell(Constants.TWELVE).setCellValue(Constants.EXCEL_HEADER_COLOR);
        excelHeader.createCell(Constants.THIRTEEN).setCellValue(Constants.EXCEL_HEADER_COMMENT);
        excelHeader.createCell(Constants.FOURTEEN).setCellValue(Constants.EXCEL_HEADER_PLANTING_WEEK);
        excelHeader.createCell(Constants.FIFTEEN).setCellValue(Constants.EXCEL_HEADER_PLANTING_EST);
        excelHeader.createCell(Constants.SIXTEEN).setCellValue(Constants.EXCEL_HEADER_PLANTING_REAL);
        excelHeader.createCell(Constants.SEVENTEEN).setCellValue(Constants.EXCEL_HEADER_PLANTING);
        excelHeader.createCell(Constants.EIGHTEEN).setCellValue(Constants.EXCEL_HEADER_FLOW_EST);
        excelHeader.createCell(Constants.NINETEEN).setCellValue(Constants.EXCEL_HEADER_FLOW_REAL);
        excelHeader.createCell(Constants.TWENTY).setCellValue(Constants.EXCEL_HEADER_FLOW);
    }

    private void setExcelHeaderThird(HSSFRow excelHeader) {
        excelHeader.createCell(Constants.TWENTY_ONE).setCellValue(Constants.EXCEL_HEADER_HARVEST_EST);
        excelHeader.createCell(Constants.TWENTY_TWO).setCellValue(Constants.EXCEL_HEADER_HARVEST_HUMIDITY);
        excelHeader.createCell(Constants.TWENTY_THREE).setCellValue(Constants.EXCEL_HEADER_HARVEST);
        excelHeader.createCell(Constants.TWENTY_FOUR).setCellValue(Constants.EXCEL_HEADER_HARVEST_WEEK);
        excelHeader.createCell(Constants.TWENTY_FIVE).setCellValue(Constants.EXCEL_HEADER_HARVESTED);
        excelHeader.createCell(Constants.TWENTY_SIX).setCellValue(Constants.EXCEL_HEADER_TARGET_TN_RW);
        excelHeader.createCell(Constants.TWENTY_SEVEN).setCellValue(Constants.EXCEL_HEADER_TARGET_TN_DS);
        excelHeader.createCell(Constants.TWENTY_EIGHT).setCellValue(Constants.EXCEL_HEADER_TARGET_LOT);
        excelHeader.createCell(Constants.TWENTY_NINE).setCellValue(Constants.EXCEL_HEADER_TARGET_RW_DS);
        excelHeader.createCell(Constants.THIRTY).setCellValue(Constants.EXCEL_HEADER_TARGET_DS_FNG);
        excelHeader.createCell(Constants.THIRTY_ONE).setCellValue(Constants.EXCEL_HEADER_TARGET_KG_BAG);
        excelHeader.createCell(Constants.THIRTY_TWO).setCellValue(Constants.EXCEL_HEADER_TARGET_UN_HA);
        excelHeader.createCell(Constants.THIRTY_THREE).setCellValue(Constants.EXCEL_HEADER_TARGET_KW_DS_HA);
    }

    private void setExcelHeaderFour(HSSFRow excelHeader) {
        excelHeader.createCell(Constants.THIRTY_FOUR).setCellValue(Constants.EXCEL_HEADER_EST);
        excelHeader.createCell(Constants.THIRTY_FIVE).setCellValue(Constants.EXCEL_HEADER_EST_COMMENT);
        excelHeader.createCell(Constants.THIRTY_SIX).setCellValue(Constants.EXCEL_HEADER_HARVEST_KG_RW);
        excelHeader.createCell(Constants.THIRTY_SEVEN).setCellValue(Constants.EXCEL_HEADER_HARVEST_TN_DS_ACTUAL);
        excelHeader.createCell(Constants.THIRTY_EIGHT).setCellValue(Constants.EXCEL_HEADER_HARVEST_TN_RW_ACTUAL);
        excelHeader.createCell(Constants.THIRTY_NINE).setCellValue(Constants.EXCEL_HEADER_HARVEST_RW_DS);
        excelHeader.createCell(Constants.FORTY).setCellValue(Constants.EXCEL_HEADER_HUSKING_KG_DS);
        excelHeader.createCell(Constants.FORTY_ONE).setCellValue(Constants.EXCEL_HEADER_HUSKING_WAREHOUSE_UNIT);
        excelHeader.createCell(Constants.FORTY_TWO).setCellValue(Constants.EXCEL_HEADER_HUSKING_OBS);
        excelHeader.createCell(Constants.FORTY_TRHEE).setCellValue(Constants.EXCEL_HEADER_QUALITY_ACTUAL_KG_DS);
        excelHeader.createCell(Constants.FORTY_FOUR).setCellValue(Constants.EXCEL_HEADER_QUALITY_APROV_DS_FNG);
        excelHeader.createCell(Constants.FORTY_FIVE).setCellValue(Constants.EXCEL_HEADER_QUALITY_PESO_X_BOLSA);
        excelHeader.createCell(Constants.FORTY_SIX).setCellValue(Constants.EXCEL_HEADER_QUALITY_KG_FNG_EST);
        excelHeader.createCell(Constants.FORTY_SEVEN).setCellValue(Constants.EXCEL_HEADER_QUALITY_OBS);
        excelHeader.createCell(Constants.FORTY_EIGHT).setCellValue(Constants.EXCEL_HEADER_PREHARVEST_SAMPLE_DATE);
        excelHeader.createCell(Constants.FORTY_NINE).setCellValue(Constants.EXCEL_HEADER_PREHARVEST_HUMIDITY);
        excelHeader.createCell(Constants.FIFTY).setCellValue(Constants.EXCEL_HEADER_MEGA_ZONE);
    }

    private void setFloatValue(Cell cell, Float value) {
        if (value != null) {
            cell.setCellValue(value);
        }
    }

    private void setDateValue(Cell cell, Date value) {
        if (value != null) {
            cell.setCellValue(value);
            cell.setCellStyle(dateStyle);
        }
    }

    private void setIntegerValue(Cell cell, Integer value) {
        if (value != null) {
            cell.setCellValue(value);
        }
    }

    private void setExcelRows(Sheet excelSheet, List<LotDTO> lotDTOList) {
        int record = INIT_RECORD;

        for (LotDTO lot : lotDTOList) {
            Row excelRow = excelSheet.createRow(record++);
            setExcelMainInfo(excelRow, lot);
            setExcelInfo(excelRow, lot);
            setExcelInfoTwo(excelRow, lot);
        }

        //footer
        Row excelRow = excelSheet.createRow(record++);
        setSumFormulas(record, excelRow, Constants.FIVE, Constants.SIX, Constants.TWENTY_SIX, Constants.TWENTY_SEVEN,
                Constants.TWENTY_EIGHT, Constants.TWENTY_NINE, Constants.THIRTY, Constants.THIRTY_ONE,
                Constants.THIRTY_TWO, Constants.THIRTY_THREE, Constants.THIRTY_FOUR, Constants.THIRTY_SIX, Constants.THIRTY_SEVEN,
                Constants.THIRTY_EIGHT, Constants.THIRTY_NINE, Constants.FORTY, Constants.FORTY_TRHEE, Constants.FORTY_FOUR,
                Constants.FORTY_FIVE, Constants.FORTY_SIX, Constants.FORTY_NINE);

        setAverageFormulas(record, excelRow, Constants.TWENTY_NINE, Constants.THIRTY, Constants.THIRTY_ONE, Constants.THIRTY_NINE,
                Constants.FORTY_FOUR, Constants.FORTY_FIVE);
    }

    private void setExcelMainInfo(Row excelRow, LotDTO lot) {
        excelRow.createCell(Constants.ONE).setCellValue(lot.getLotCode());
        excelRow.createCell(Constants.TWO).setCellValue(lot.getZoneCode());
        excelRow.createCell(Constants.THREE).setCellValue(lot.getEstablishmentName());
        excelRow.createCell(Constants.FOUR).setCellValue(lot.getHybridName());
        setFloatValue(excelRow.createCell(Constants.FIVE), lot.getRegisteredHas());
        setFloatValue(excelRow.createCell(Constants.SIX), lot.getHarvestableHas());
        excelRow.createCell(Constants.SEVEN).setCellValue(lot.getClient());
        excelRow.createCell(Constants.EIGHT).setCellValue(lot.getCertification());
        excelRow.createCell(Constants.NINE).setCellValue(lot.getExpediente());
        excelRow.createCell(Constants.TEN).setCellValue(lot.getGermoplasma());
        excelRow.createCell(Constants.ELEVEN).setCellValue(lot.getGranProgram());
        excelRow.createCell(Constants.TWELVE).setCellValue(lot.getColor());
        excelRow.createCell(Constants.THIRTEEN).setCellValue(lot.getObservation());
    }


    private void setExcelInfo(Row excelRow, LotDTO lot) {
        setIntegerValue(excelRow.createCell(Constants.FOURTEEN), lot.getPlantingWeek());
        setDateValue(excelRow.createCell(Constants.FIFTEEN), lot.getEstimatedPlantingDate());
        setDateValue(excelRow.createCell(Constants.SIXTEEN), lot.getRealPlantingDate());
        setDateValue(excelRow.createCell(Constants.SEVENTEEN), lot.getPlantingDate());
        setDateValue(excelRow.createCell(Constants.EIGHTEEN), lot.getEstimatedFloweringDate());
        setDateValue(excelRow.createCell(Constants.NINETEEN), lot.getRealFloweringDate());
        setDateValue(excelRow.createCell(Constants.TWENTY), lot.getFloweringDate());
        setDateValue(excelRow.createCell(Constants.TWENTY_ONE), lot.getEstimatedHarvestDate());
        setDateValue(excelRow.createCell(Constants.TWENTY_TWO), lot.getHarvestDateForHumidity());
        setDateValue(excelRow.createCell(Constants.THIRTY_THREE), lot.getHarvestDate());
        setFloatValue(excelRow.createCell(Constants.TWENTY_FOUR), lot.getHarvestWeek());
        excelRow.createCell(Constants.TWENTY_FIVE).setCellValue(lot.isHarvested());
        setFloatValue(excelRow.createCell(Constants.TWENTY_SIX), lot.getTargetTnRwLot());
        setFloatValue(excelRow.createCell(Constants.TWENTY_SEVEN), lot.getTargetTnDsLot());
        setFloatValue(excelRow.createCell(Constants.TWENTY_EIGHT), lot.getTargetLot());
        setFloatValue(excelRow.createCell(Constants.TWENTY_NINE), lot.getTargetRwToDs());
        setFloatValue(excelRow.createCell(Constants.THIRTY), lot.getTargetDsToFng());
        setFloatValue(excelRow.createCell(Constants.THIRTY_ONE), lot.getTargetKgBag());

    }

    private void setExcelInfoTwo(Row excelRow, LotDTO lot) {
        setFloatValue(excelRow.createCell(Constants.THIRTY_TWO), lot.getTargetBagHa());
        setFloatValue(excelRow.createCell(Constants.THIRTY_THREE), lot.getTargetKgsDsHa());
        setFloatValue(excelRow.createCell(Constants.THIRTY_FOUR), lot.getEstimatedKgDsHa());
        excelRow.createCell(Constants.THIRTY_FIVE).setCellValue(lot.getObsEstimatedKgDsHa());
        setFloatValue(excelRow.createCell(Constants.THIRTY_SIX), lot.getHarvestKgRWLot());
        setFloatValue(excelRow.createCell(Constants.THIRTY_SEVEN), lot.getActualTnDsLot());
        setFloatValue(excelRow.createCell(Constants.THIRTY_EIGHT), lot.getActualTnRwLot());
        setFloatValue(excelRow.createCell(Constants.THIRTY_NINE), lot.getHarvestRwToDs());
        setFloatValue(excelRow.createCell(Constants.FORTY), lot.getHuskingKgDsLot());
        excelRow.createCell(Constants.FORTY_ONE).setCellValue(lot.getWarehouseUnit());
        excelRow.createCell(Constants.FORTY_TWO).setCellValue(lot.getObsHuskingKgDsLot());
        setFloatValue(excelRow.createCell(Constants.FORTY_TRHEE), lot.getActualKgDsLot());
        setFloatValue(excelRow.createCell(Constants.FORTY_FOUR), lot.getQualityDsToFng());
        setFloatValue(excelRow.createCell(Constants.FORTY_FIVE), lot.getQualityWeightBag());
        setFloatValue(excelRow.createCell(Constants.FORTY_SIX), lot.getQualityKgFngLot());
        excelRow.createCell(Constants.FORTY_SEVEN).setCellValue(lot.getQualityObs());
        setDateValue(excelRow.createCell(Constants.FORTY_EIGHT), lot.getSampleDateHumidity());
        setFloatValue(excelRow.createCell(Constants.FORTY_NINE), lot.getHumidity());
        excelRow.createCell(Constants.FIFTY).setCellValue(lot.getMegazone());
    }

    private void setSumFormulas(int record, Row excelRow, int... colIndexs) {
        for (int colIndex : colIndexs) {
            Cell cell = excelRow.createCell(colIndex);
            String colString = CellReference.convertNumToColString(colIndex);
            cell.setCellFormula("SUM(" + colString + (INIT_RECORD + Constants.ONE) + ":" + colString + (record - Constants.ONE) + ")");
        }

    }

    private void setAverageFormulas(int record, Row excelRow, int... colIndexs) {
        for (int colIndex : colIndexs) {
            Cell cell = excelRow.createCell(colIndex);
            String colString = CellReference.convertNumToColString(colIndex);
            cell.setCellFormula("AVERAGE(" + colString + (INIT_RECORD + Constants.ONE) + ":" + colString + (record - Constants.ONE) + ")");
        }

    }
}
