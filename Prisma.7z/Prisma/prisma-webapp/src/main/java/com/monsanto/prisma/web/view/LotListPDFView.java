package com.monsanto.prisma.web.view;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.utils.AbstractITextPdfView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.List;

/**
 * Created by PGSETT on 19/08/2014.
 */
public class LotListPDFView extends AbstractITextPdfView {
    public static final int NUM_COLUMNS = 50;
    public static final float WIDTH_PERCENTAGE = 100.0f;
    public static final int SPACING_BEFORE = 15;
    public static final int FONT_SIZE = 10;
    public static final int CELL_PADDING = 8;
    public static final float H_BACK_1 = 180f;
    public static final float S_BACK_1 = 75f;
    public static final float B_BACK_1 = 80f;
    public static final float H_BACK_2 = 120f;
    public static final float S_BACK_2 = 100f;
    public static final float B_BACK_2 = 100f;
    public static final float H_BACK_3 = 225f;
    public static final float S_BACK_3 = 80f;
    public static final float B_BACK_3 = 100f;
    public static final String LOT_LIST_PDF = "lotListPDF";
    Float totalRegisteredHas = Constants.ZERO;
    Float totalHarvestableHas = Constants.ZERO;
    Float totalTargetTnRwLot = Constants.ZERO;
    Float totalTargetTnDsLot = Constants.ZERO;
    Float totalTargetLot = Constants.ZERO;
    Float totalTargetRwToDs = Constants.ZERO;
    Float totalTargetDsToFng = Constants.ZERO;
    Float totalTargetKgBag = Constants.ZERO;
    Float totalTargetBagHa = Constants.ZERO;
    Float totalTargetKgsDsHa = Constants.ZERO;
    Float totalEstimatedKgDsHa = Constants.ZERO;

    Float totalHarvestKgRWLot = Constants.ZERO;
    Float totalActualTnDsLot = Constants.ZERO;
    Float totalActualTnRwLot = Constants.ZERO;
    Float totalHarvestRwToDs = Constants.ZERO;
    Float totalHuskingKgDsLot = Constants.ZERO;
    Float totalActualKgDsLot = Constants.ZERO;
    Float totalQualityDsToFng = Constants.ZERO;
    Float totalQualityWeightBag = Constants.ZERO;
    Float totalQualityKgFngLot = Constants.ZERO;
    Float totalHumidity = Constants.ZERO;

    Integer countTargetRwToDs = 0;
    Integer countTargetDsToFng = 0;
    Integer countHarvestRwToDs = 0;
    Integer countQualityDsToFng = 0;
    Integer countQualityWeightBag = 0;
    Integer countTargetKgBag = 0;

    @Override
    protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            List<LotDTO> lotDTOList = (List<LotDTO>) model.get(LOT_LIST_PDF);

            PdfPTable table = new PdfPTable(NUM_COLUMNS);
            table.setWidthPercentage(WIDTH_PERCENTAGE);
            table.setSpacingBefore(SPACING_BEFORE);

            setHeaderFirst(table);
            setHeaderSecond(table);
            setHeaderThird(table);
            setHeaderFour(table);
            setHeaderFive(table);
            setLotValues(table, lotDTOList);
            document.add(table);
        } catch (Exception e) {
            logger.error("error in pdf view -" + e.getMessage(), e);
            RequestDispatcher rd = request.getRequestDispatcher("error");
            rd.forward(request, response);
        }
    }

    private void setLotValues(PdfPTable table, List<LotDTO> lotDTOList) throws BadElementException {

        for (LotDTO lot : lotDTOList) {
            addRowFirst(table, lot);
            addRowSecond(table, lot);
            addRowThird(table, lot);
            addRowFour(table, lot);
            accumulateTotals(lot);
            accumulateTotalsTwo(lot);
            countForAverages(lot);
        }
        addFooter(table);
        addFooterTwo(table);
    }


    private void countForAverages(LotDTO lot) {
        countTargetRwToDs += getCount(lot.getTargetRwToDs());
        countTargetDsToFng += getCount(lot.getTargetDsToFng());
        countTargetKgBag += getCount(lot.getTargetKgBag());
        countQualityWeightBag += getCount(lot.getQualityWeightBag());
        countHarvestRwToDs += getCount(lot.getHarvestRwToDs());
        countQualityDsToFng += getCount(lot.getQualityDsToFng());
    }

    private void accumulateTotals(LotDTO lot) {
        totalRegisteredHas += getValueOrZero(lot.getRegisteredHas());
        totalHarvestableHas += getValueOrZero(lot.getHarvestableHas());
        totalTargetTnRwLot += getValueOrZero(lot.getTargetTnRwLot());
        totalTargetTnDsLot += getValueOrZero(lot.getTargetTnDsLot());
        totalTargetLot += getValueOrZero(lot.getTargetLot());
        totalTargetRwToDs += getValueOrZero(lot.getTargetRwToDs());
        totalTargetDsToFng += getValueOrZero(lot.getTargetDsToFng());
        totalTargetKgBag += getValueOrZero(lot.getTargetKgBag());
        totalTargetBagHa += getValueOrZero(lot.getTargetBagHa());
        totalTargetKgsDsHa += getValueOrZero(lot.getTargetKgsDsHa());
        totalEstimatedKgDsHa += getValueOrZero(lot.getEstimatedKgDsHa());
    }

    private void accumulateTotalsTwo(LotDTO lot) {
        totalHarvestKgRWLot += getValueOrZero(lot.getHarvestKgRWLot());
        totalActualTnDsLot += getValueOrZero(lot.getActualTnDsLot());
        totalActualTnRwLot += getValueOrZero(lot.getActualTnRwLot());
        totalHarvestRwToDs += getValueOrZero(lot.getHarvestRwToDs());
        totalHuskingKgDsLot += getValueOrZero(lot.getHuskingKgDsLot());
        totalActualKgDsLot += getValueOrZero(lot.getActualKgDsLot());
        totalQualityDsToFng += getValueOrZero(lot.getQualityDsToFng());
        totalQualityWeightBag += getValueOrZero(lot.getQualityWeightBag());
        totalQualityKgFngLot += getValueOrZero(lot.getQualityKgFngLot());
        totalHumidity += getValueOrZero(lot.getHumidity());
    }

    private float getValueOrZero(Float value) {
        return value == null ? 0 : value;
    }

    private int getCount(Float value) {
        return value == null ? 0 : 1;
    }

    private void addFooter(PdfPTable table) throws BadElementException {
        addBlanks(table, 5);
        setValue(table, totalRegisteredHas, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, totalHarvestableHas, Color.WHITE, Color.LIGHT_GRAY);
        addBlanks(table, 19);
        setValue(table, totalTargetTnRwLot, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, totalTargetTnDsLot, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, totalTargetLot, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, countTargetRwToDs > 0 ? totalTargetRwToDs / countTargetRwToDs : totalTargetRwToDs, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, countTargetDsToFng > 0 ? totalTargetDsToFng / countTargetDsToFng : totalTargetDsToFng, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, countTargetKgBag > 0 ? totalTargetKgBag / countTargetKgBag : totalTargetKgBag, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, totalTargetBagHa, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, totalTargetKgsDsHa, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, totalEstimatedKgDsHa, Color.WHITE, Color.LIGHT_GRAY);
        addBlanks(table, 1);
    }

    private void addFooterTwo(PdfPTable table) throws BadElementException {
        setValue(table, totalHarvestKgRWLot, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, totalActualTnDsLot, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, totalActualTnRwLot, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, countHarvestRwToDs > 0 ? totalHarvestRwToDs / countHarvestRwToDs : totalHarvestRwToDs, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, totalHuskingKgDsLot, Color.WHITE, Color.LIGHT_GRAY);
        addBlanks(table, 2);
        setValue(table, totalActualKgDsLot, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, countQualityDsToFng > 0 ? totalQualityDsToFng / countQualityDsToFng : totalQualityDsToFng, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, countQualityWeightBag > 0 ? totalQualityWeightBag / countQualityWeightBag : totalQualityWeightBag, Color.WHITE, Color.LIGHT_GRAY);
        setValue(table, totalQualityKgFngLot, Color.WHITE, Color.LIGHT_GRAY);
        addBlanks(table, 2);
        setValue(table, totalHumidity, Color.WHITE, Color.LIGHT_GRAY);
    }

    private void addBlanks(PdfPTable table, int quantity) throws BadElementException {
        for (int i = 0; i < quantity; i++) {
            setValue(table, null, Color.WHITE, Color.LIGHT_GRAY);
        }
    }

    private void addRowFirst(PdfPTable table, LotDTO lot) throws BadElementException {
        setValue(table, lot.getLotCode(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getMegazone(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getZoneCode(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getEstablishmentName(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getHybridName(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getRegisteredHas(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getHarvestableHas(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getObservation(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getCertification(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getExpediente(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getGermoplasma(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getGranProgram(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getClient(), Color.BLACK, Color.WHITE);
    }

    private void addRowSecond(PdfPTable table, LotDTO lot) throws BadElementException {
        setValue(table, lot.getColor(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getPlantingWeek(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getEstimatedPlantingDate(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getRealPlantingDate(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getPlantingDate(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getEstimatedFloweringDate(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getRealFloweringDate(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getFloweringDate(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getEstimatedHarvestDate(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getHarvestDateForHumidity(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getHarvestDate(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getHarvestWeek(), Color.BLACK, Color.WHITE);
    }

    private void addRowThird(PdfPTable table, LotDTO lot) throws BadElementException {
        setValue(table, lot.isHarvested() ? "SI" : "NO", Color.BLACK, Color.WHITE);
        setValue(table, lot.getTargetTnRwLot(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getTargetTnDsLot(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getTargetLot(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getTargetRwToDs(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getTargetDsToFng(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getTargetKgBag(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getTargetBagHa(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getTargetKgsDsHa(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getEstimatedKgDsHa(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getObsEstimatedKgDsHa(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getHarvestKgRWLot(), Color.BLACK, Color.WHITE);
    }

    private void addRowFour(PdfPTable table, LotDTO lot) throws BadElementException {
        setValue(table, lot.getActualTnDsLot(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getActualTnRwLot(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getHarvestRwToDs(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getHuskingKgDsLot(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getWarehouseUnit(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getObsHuskingKgDsLot(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getActualKgDsLot(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getQualityDsToFng(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getQualityWeightBag(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getQualityKgFngLot(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getQualityObs(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getSampleDateHumidity(), Color.BLACK, Color.WHITE);
        setValue(table, lot.getHumidity(), Color.BLACK, Color.WHITE);
    }

    private void setHeaderFirst(PdfPTable table) throws BadElementException {
        Font font = setFont(Color.WHITE);
        PdfPCell cell = initPdfCell(Color.GRAY, Constants.EIGHT);
        addCell(table, Constants.EXCEL_HEADER_LOT, font, cell);
        addCell(table, Constants.EXCEL_HEADER_MEGA_ZONE, font, cell);
        addCell(table, Constants.EXCEL_HEADER_ZONE, font, cell);
        addCell(table, Constants.EXCEL_HEADER_FIELD, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HYBRID, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HAS_REG, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HAS_HARV, font, cell);
        addCell(table, Constants.EXCEL_HEADER_COMMENT, font, cell);
        addCell(table, Constants.EXCEL_HEADER_CERT, font, cell);
        addCell(table, Constants.EXCEL_HEADER_EXP, font, cell);
    }

    private void setHeaderSecond(PdfPTable table) throws BadElementException {
        Font font;
        PdfPCell cell = initPdfCell(Color.GRAY, Constants.EIGHT);
        font = setFont(Color.WHITE);
        addCell(table, Constants.EXCEL_HEADER_GERMOPLASMA, font, cell);
        addCell(table, Constants.EXCEL_HEADER_GRAN_PROGRAM, font, cell);
        addCell(table, Constants.EXCEL_HEADER_CLIENT, font, cell);
        addCell(table, Constants.EXCEL_HEADER_COLOR, font, cell);
        addCell(table, Constants.EXCEL_HEADER_PLANTING_WEEK, font, cell);
        font = setFont(Color.WHITE);
        cell.setBackgroundColor(Color.BLUE);
        addCell(table, Constants.EXCEL_HEADER_PLANTING_EST, font, cell);
        addCell(table, Constants.EXCEL_HEADER_PLANTING_REAL, font, cell);
        addCell(table, Constants.EXCEL_HEADER_PLANTING, font, cell);
        addCell(table, Constants.EXCEL_HEADER_FLOW_EST, font, cell);
        addCell(table, Constants.EXCEL_HEADER_FLOW_REAL, font, cell);
        addCell(table, Constants.EXCEL_HEADER_FLOW, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HARVEST_EST, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HARVEST_HUMIDITY, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HARVEST, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HARVEST_WEEK, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HARVESTED, font, cell);
    }

    private void setHeaderThird(PdfPTable table) throws BadElementException {
        Font font;
        PdfPCell cell = initPdfCell(Color.GRAY, Constants.EIGHT);
        font = setFont(Color.BLACK);
        cell.setBackgroundColor(Color.ORANGE);
        addCell(table, Constants.EXCEL_HEADER_TARGET_TN_RW, font, cell);
        addCell(table, Constants.EXCEL_HEADER_TARGET_TN_DS, font, cell);
        addCell(table, Constants.EXCEL_HEADER_TARGET_LOT, font, cell);
        addCell(table, Constants.EXCEL_HEADER_TARGET_RW_DS, font, cell);
        addCell(table, Constants.EXCEL_HEADER_TARGET_DS_FNG, font, cell);
        addCell(table, Constants.EXCEL_HEADER_TARGET_KG_BAG, font, cell);
        addCell(table, Constants.EXCEL_HEADER_TARGET_UN_HA, font, cell);
        addCell(table, Constants.EXCEL_HEADER_TARGET_KW_DS_HA, font, cell);
    }

    private void setHeaderFour(PdfPTable table) throws BadElementException {
        Font font;
        PdfPCell cell = initPdfCell(Color.GRAY, Constants.EIGHT);
        font = setFont(Color.BLACK);
        cell.setBackgroundColor(Color.getHSBColor(H_BACK_1, S_BACK_1, B_BACK_1));
        addCell(table, Constants.EXCEL_HEADER_EST, font, cell);
        addCell(table, Constants.EXCEL_HEADER_EST_COMMENT, font, cell);
        font = setFont(Color.BLACK);
        cell.setBackgroundColor(Color.getHSBColor(H_BACK_2, S_BACK_2, B_BACK_2));
        addCell(table, Constants.EXCEL_HEADER_HARVEST_KG_RW, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HARVEST_TN_DS_ACTUAL, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HARVEST_TN_RW_ACTUAL, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HARVEST_RW_DS, font, cell);
    }
    private void setHeaderFive(PdfPTable table) throws BadElementException {
        Font font;
        PdfPCell cell = initPdfCell(Color.GRAY, Constants.EIGHT);
        font = setFont(Color.BLACK);
        cell.setBackgroundColor(Color.getHSBColor(H_BACK_3, S_BACK_3, B_BACK_3));
        addCell(table, Constants.EXCEL_HEADER_HUSKING_KG_DS, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HUSKING_WAREHOUSE_UNIT, font, cell);
        addCell(table, Constants.EXCEL_HEADER_HUSKING_OBS, font, cell);
        font = setFont(Color.BLACK);
        cell.setBackgroundColor(Color.RED);
        addCell(table, Constants.EXCEL_HEADER_QUALITY_ACTUAL_KG_DS, font, cell);
        addCell(table, Constants.EXCEL_HEADER_QUALITY_APROV_DS_FNG, font, cell);
        addCell(table, Constants.EXCEL_HEADER_QUALITY_PESO_X_BOLSA, font, cell);
        addCell(table, Constants.EXCEL_HEADER_QUALITY_KG_FNG_EST, font, cell);
        addCell(table, Constants.EXCEL_HEADER_QUALITY_OBS, font, cell);
        font = setFont(Color.BLACK);
        cell.setBackgroundColor(Color.GREEN);
        addCell(table, Constants.EXCEL_HEADER_PREHARVEST_SAMPLE_DATE, font, cell);
        addCell(table, Constants.EXCEL_HEADER_PREHARVEST_HUMIDITY, font, cell);
    }

    private void addCell(PdfPTable table, String phrase, Font font, PdfPCell cell) {
        cell.setPhrase(new Phrase(phrase, font));
        table.addCell(cell);
    }

    private Font setFont(Color color) {
        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(color);
        font.setSize(FONT_SIZE);
        return font;
    }

    private void setValue(PdfPTable table, Object value, Color fontColor, Color bkg) throws BadElementException {
        Font font = setFont(fontColor);
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(bkg);
        cell.setPadding(CELL_PADDING);
        if (value != null) {
            cell.setPhrase(new Phrase(value.toString(), font));
            table.addCell(cell);
        } else {
            cell.setPhrase(new Phrase("", font));
            table.addCell(cell);
        }
    }

    private PdfPCell initPdfCell(Color color, Integer padding) {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(color);
        cell.setPadding(padding);
        return cell;
    }
}
