package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.ReceiveTonsDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Created by PGSETT on 26/08/2014.
 */
public class ReceiveTonsReportExcelView extends AbstractExcelView {

    private MessageSource messageSource;
    private static final String CAMPAIGN_TON_DTO = "campaignTonDTO";

    private HSSFWorkbook workbook;

    private HSSFSheet excelSheet;

    private List<ReceiveTonsDTO> receiveTonsDTOs;

    private List<ReceiveTonsDTO> harvestWeekList;

    private Integer optionFilter;

    @Override
    protected void buildExcelDocument(Map model, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            CampaignTonDTO campaignDTO = (CampaignTonDTO) model.get(CAMPAIGN_TON_DTO);
            request.setAttribute("campaignId", campaignDTO.getCampaignId());
            this.workbook = workbook;
            this.receiveTonsDTOs = (List<ReceiveTonsDTO>) model.get(Constants.RECEIVE_TONS_EXPORT_XLS);
            this.harvestWeekList = (List<ReceiveTonsDTO>) model.get(Constants.CAMPAIGN_TON_WEEKS);
            this.optionFilter = (Integer) model.get(Constants.OPTION_FILTER);
            createMainInformation(campaignDTO);
            setExcelHeader();
            if (receiveTonsDTOs != null) {
                setExcelRows();
            }
            createTotals();
        } catch (Exception ex) {
            RequestDispatcher rd = request.getRequestDispatcher("error");
            rd.forward(request, response);
        }
    }

    private String setLabelForParamMessages(CampaignTonDTO campaignDTO) {
        String strValue = "";
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            strValue = getMessage("report.tons.receive.header.lotCode.label") + ":";
            strValue += campaignDTO.getLotCode() != null ? campaignDTO.getLotCode() : "-";
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            strValue = getMessage("report.tons.receive.header.zone.label") + ":";
            strValue += campaignDTO.getZoneName() != null ? campaignDTO.getZoneName() : "-";
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            strValue = getMessage("report.tons.receive.header.hybrid.label") + ":";
            strValue += campaignDTO.getHybridName() != null ? campaignDTO.getHybridName() : "-";
        } else {
            strValue = getMessage("report.tons.receive.header.program.label") + ":";
            strValue += campaignDTO.getProgram() != null ? campaignDTO.getProgram() : "-";
        }
        return strValue;
    }

    private void createMainInformation(CampaignTonDTO campaignDTO) {
        this.excelSheet = workbook.createSheet(Constants.SHEET_NAME);
        Utilities.addExcelRow(excelSheet, workbook, getMessage("report.tons.receive.title"), 0, Constants.TWO);

        Utilities.addExcelRow(excelSheet, workbook, setLabelForParamMessages(campaignDTO), Constants.ONE, Constants.TWO);

        createDatesMainInformation(workbook, campaignDTO, excelSheet);
    }

    private void createDatesMainInformation(HSSFWorkbook workbook, CampaignTonDTO campaignDTO, HSSFSheet excelSheet) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String harvestDateFrom = simpleDateFormat.format(campaignDTO.getHarvestDateFrom());
        String harvestDateTo = simpleDateFormat.format(campaignDTO.getHarvestDateTo());

        String strharvestWeekFrom = getMessage("report.tons.tonsToHost.harvestWeekFrom") + ":";
        strharvestWeekFrom += harvestDateFrom != null ? harvestDateFrom : "-";
        Utilities.addExcelRow(excelSheet, workbook, strharvestWeekFrom, Constants.TWO, Constants.FOUR);

        String strharvestWeekTo = getMessage("report.tons.tonsToHost.harvestWeekTo") + ":";
        strharvestWeekTo += harvestDateTo != null ? harvestDateTo : "-";
        Utilities.addExcelRow(excelSheet, workbook, strharvestWeekTo, Constants.THREE, Constants.FOUR);
    }

    private void createTotals() {
        CellStyle cellStyle = getCellStyle(HSSFColor.LIGHT_GREEN.index);

        HSSFRow row = excelSheet.createRow(excelSheet.getLastRowNum() + 1);
        Float sumTotalZoneWeek = null;
        Float sumTotal = 0f;

        Utilities.createCellString(row, 1, "Total", cellStyle);
        for (int i = 0; i < harvestWeekList.size(); i++) {
            sumTotalZoneWeek = 0f;
            for (int j = Constants.SIX; j < excelSheet.getLastRowNum(); j++) {
                HSSFCell value = excelSheet.getRow(j).getCell(2 + i);
                if (value != null) {
                    sumTotalZoneWeek += new Float(value.getStringCellValue().replace(",", "."));
                }
            }
            Utilities.createCellFloat(row, i + 2, sumTotalZoneWeek, cellStyle);
            sumTotal += sumTotalZoneWeek;
        }
        Utilities.createCellFloat(row, harvestWeekList.size() + 2, sumTotal, cellStyle);
    }

    public void setExcelHeader() {
        HSSFRow excelHeader = excelSheet.createRow(Constants.FIVE);

        CellStyle cellStyle = getCellStyle(HSSFColor.SEA_GREEN.index);

        createFont(cellStyle);
        String strHarvestWeek = getStrMessageForHeaderLabel() + "/" + getMessage("report.tons.receive.header.harvestWeek.label");

        Utilities.createCellString(excelHeader, 1, strHarvestWeek, cellStyle);

        for (int i = 0; i < harvestWeekList.size(); i++) {
            Utilities.createCellFloat(excelHeader, i + 2, harvestWeekList.get(i).getHarvestWeek(), cellStyle);
        }
        Utilities.createCellString(excelHeader, harvestWeekList.size() + 2, "Total", cellStyle);
    }

    private String getStrMessageForHeaderLabel() {
        String strValue;
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            strValue = getMessage("report.tons.receive.header.lotCode.label");

        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            strValue = getMessage("report.tons.receive.header.zone.label");
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            strValue = getMessage("report.tons.receive.header.hybrid.label");

        } else {
            strValue = getMessage("report.tons.receive.header.program.label");
        }
        return strValue;
    }


    private void createFont(CellStyle cellStyle) {
        Font font = workbook.createFont();
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        cellStyle.setFont(font);
    }

    private void setValuesByOption(HSSFRow excelRow, ReceiveTonsDTO valueActual) {
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            Utilities.createCellString(excelRow, Constants.ONE, valueActual.getLotCode());
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            Utilities.createCellString(excelRow, Constants.ONE, valueActual.getZoneCode());
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            Utilities.createCellString(excelRow, Constants.ONE, valueActual.getHybridName());
        } else {
            Utilities.createCellString(excelRow, Constants.ONE, valueActual.getProgram());
        }
    }

    private void setExcelRows() {
        int record = Constants.SIX;

        ReceiveTonsDTO valueActual = new ReceiveTonsDTO();
        HSSFRow excelRow = null;
        Float sumZone = null;

        if (receiveTonsDTOs.isEmpty()) {
            excelRow = excelSheet.createRow(record++);
            Utilities.createCellString(excelRow, Constants.ONE, getMessage("report.tons.receive.empty.label"));
            return;
        }

        for (ReceiveTonsDTO receiveTonsDTO : receiveTonsDTOs) {
            if (isNew(this.optionFilter, valueActual, receiveTonsDTO)) {
                valueActual = receiveTonsDTO;
                excelRow = excelSheet.createRow(record++);
                setValuesByOption(excelRow, valueActual);
                sumZone = 0f;
            }

            if (isEqualValues(receiveTonsDTO, valueActual)) {
                for (int i = 0; i < harvestWeekList.size(); i++) {
                    if (receiveTonsDTO.getHarvestWeek() != null && receiveTonsDTO.getHarvestWeek().equals(harvestWeekList.get(i).getHarvestWeek())
                            && receiveTonsDTO.getYear() == harvestWeekList.get(i).getYear()) {
                        if (receiveTonsDTO.getSumActualTnRwLot() != null) {
                            Utilities.createCellFloat(excelRow, i + 2, receiveTonsDTO.getSumActualTnRwLot());
                            sumZone += receiveTonsDTO.getSumActualTnRwLot();
                        }
                        Utilities.createCellFloat(excelRow, harvestWeekList.size() + 2, sumZone);
                        break;
                    }
                }
            }
        }
    }

    private boolean isEqualValues(ReceiveTonsDTO receiveTonsDTO, ReceiveTonsDTO valueActual) {
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            return receiveTonsDTO.getLotCode().equals(valueActual.getLotCode());
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            return receiveTonsDTO.getZoneCode().equals(valueActual.getZoneCode());
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            return receiveTonsDTO.getHybridName().equals(valueActual.getHybridName());
        } else {
            return receiveTonsDTO.getProgram().equals(valueActual.getProgram());
        }
    }

    private boolean isNew(Integer optionFilter, ReceiveTonsDTO valueActual, ReceiveTonsDTO receiveTonsDTO) {

        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            return isNewLotCode(valueActual.getLotCode(), receiveTonsDTO.getLotCode());
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            return isNewZone(valueActual.getZoneCode(), receiveTonsDTO.getZoneCode());
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            return isNewHybrid(valueActual.getHybridName(), receiveTonsDTO.getHybridName());
        } else {
            return isNewProgram(valueActual.getProgram(), receiveTonsDTO.getProgram());
        }
    }

    private boolean isNewZone(String zoneActual, String zoneCode) {
        if (zoneActual == null) {
            return true;
        }

        if (!zoneCode.equals(zoneActual)) {
            return true;
        }

        return false;
    }

    private boolean isNewHybrid(String hybridActual, String hybridName) {
        if (hybridActual == null) {
            return true;
        }

        if (!hybridName.equals(hybridActual)) {
            return true;
        }

        return false;
    }

    private boolean isNewLotCode(String lotCodeActual, String lotCode) {
        if (lotCodeActual == null) {
            return true;
        }

        if (!lotCode.equals(lotCodeActual)) {
            return true;
        }

        return false;
    }

    private boolean isNewProgram(String programActual, String program) {
        if (programActual == null) {
            return true;
        }

        if (!program.equals(programActual)) {
            return true;
        }

        return false;
    }

    private CellStyle getCellStyle(short color) {
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setFillForegroundColor(color);
        return cellStyle;
    }

    private String getMessage(String key) {
        Locale locale = LocaleContextHolder.getLocale();
        return messageSource.getMessage(key, null, locale);
    }

    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}
