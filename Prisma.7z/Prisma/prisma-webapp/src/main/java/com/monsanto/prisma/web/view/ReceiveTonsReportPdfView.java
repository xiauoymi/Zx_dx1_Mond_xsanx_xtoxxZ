package com.monsanto.prisma.web.view;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.ReceiveTonsDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.utils.AbstractITextPdfView;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.List;

public class ReceiveTonsReportPdfView extends AbstractITextPdfView {

    private MessageSource messageSource;
    private static final String CAMPAIGN_TON_DTO = "campaignTonDTO";

    private Locale locale = LocaleContextHolder.getLocale();

    private List<ReceiveTonsDTO> receiveTonsDTOList;
    private List<ReceiveTonsDTO> harvestWeekList;
    private CampaignTonDTO campaignDTO;
    private Integer optionFilter;

    @Override
    protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            campaignDTO = (CampaignTonDTO) model.get(CAMPAIGN_TON_DTO);
            request.setAttribute("campaignId", campaignDTO.getCampaignId());
            receiveTonsDTOList = (List<ReceiveTonsDTO>) model.get(Constants.RECEIVE_TONS_EXPORT_PDF);
            harvestWeekList = (List<ReceiveTonsDTO>) model.get(Constants.CAMPAIGN_TON_WEEKS);
            this.optionFilter = (Integer) model.get(Constants.OPTION_FILTER);

            PdfPTable table = createPdfPTable();

            createHeaderDocument(document);
            createHeaderReport(table);
            createReportData(table);
            createTotals(table);

            document.add(table);
        } catch (Exception e) {
            logger.error("error in pdf view -" + e.getMessage(), e);
            RequestDispatcher rd = request.getRequestDispatcher("error");
            rd.forward(request, response);
        }
    }

    private PdfPTable createPdfPTable() {
        PdfPTable table = new PdfPTable(2 + harvestWeekList.size());
        table.setWidthPercentage(100.0f);
        table.setSpacingBefore(Constants.FIFTEEN);
        return table;
    }

    private void createReportData(PdfPTable table) throws BadElementException {
        String valueProcessed = null;
        PdfPCell[] pdfPCells = null;
        Float sumTotalZone = 0f;

        if (receiveTonsDTOList == null) {
            return;
        }

        if (harvestWeekList.isEmpty()) {
            table.addCell(createCell(getMessageSource().getMessage("report.tons.receive.empty.label", null, locale), Color.WHITE, null));
        }
        for (int i = 0; i < receiveTonsDTOList.size(); i++) {
            ReceiveTonsDTO actual = receiveTonsDTOList.get(i);


            if (valueProcessed == null) {
                valueProcessed = getValueByOption(actual);
                sumTotalZone = 0f;
                pdfPCells = createPdfPCelList(harvestWeekList.size() + 2);
                pdfPCells[0] = createCell(valueProcessed, Color.WHITE, null);
            }

            if (!getValueByOption(actual).equals(valueProcessed)) {
                pdfPCells[harvestWeekList.size() + 1] = createCell(String.format("%.2f", sumTotalZone), Color.LIGHT_GRAY, null);
                for (int j = 0; j < pdfPCells.length; j++) {
                    table.addCell(pdfPCells[j]);
                }
                valueProcessed = getValueByOption(actual);
                pdfPCells = createPdfPCelList(harvestWeekList.size() + 2);
                pdfPCells[0] = createCell(valueProcessed, Color.WHITE, null);
                sumTotalZone = 0f;
            }

            if (getValueByOption(actual).equals(valueProcessed)) {
                int indexPos = findIndexWeek(actual.getHarvestWeek(), actual.getYear(), harvestWeekList);
                pdfPCells[indexPos + 1] = createCell(String.format("%.2f", actual.getSumActualTnRwLot()), Color.WHITE, null);
                sumTotalZone += actual.getSumActualTnRwLot() != null ? actual.getSumActualTnRwLot() : 0;
            }
        }

        if (valueProcessed != null) {
            pdfPCells[harvestWeekList.size() + 1] = createCell(String.format("%.2f", sumTotalZone), Color.LIGHT_GRAY, null);
            for (int i = 0; i < pdfPCells.length; i++) {
                table.addCell(pdfPCells[i]);
            }
        }
    }

    private String getValueByOption(ReceiveTonsDTO actual) {
        String strValue = "";
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            strValue = actual.getLotCode() != null ? actual.getLotCode() : "";
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            strValue = actual.getZoneCode();
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            strValue = actual.getHybridName();
        } else {
            strValue = actual.getProgram() != null ? actual.getProgram() : "";
        }
        return strValue;
    }

    private void createHeaderDocument(Document document) throws DocumentException {
        createHeaderTitleDocument(document);
        createZoneHeaderDocument(document);
        createDateHeaderDocument(document);
    }

    private void createZoneHeaderDocument(Document document) throws DocumentException {
        Paragraph zone = new Paragraph(setStrHeaderValues());
        document.add(zone);
    }

    private String setStrHeaderValues() {
        String strValue;
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            strValue = messageSource.getMessage("report.tons.receive.header.lotCode.label", null, locale) + ":";
            strValue += campaignDTO.getLotCode() != null ? campaignDTO.getLotCode() : "-";
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            strValue = messageSource.getMessage("report.tons.receive.header.zone.label", null, locale) + ":";
            strValue += campaignDTO.getZoneName() != null ? campaignDTO.getZoneName() : "-";
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            strValue = messageSource.getMessage("report.tons.receive.header.hybrid.label", null, locale) + ":";
            strValue += campaignDTO.getHybridName() != null ? campaignDTO.getHybridName() : "-";
        } else {
            strValue = messageSource.getMessage("report.tons.receive.header.program.label", null, locale) + ":";
            strValue += campaignDTO.getProgram() != null ? campaignDTO.getProgram() : "-";
        }
        return strValue;
    }

    private void createHeaderTitleDocument(Document document) throws DocumentException {
        Paragraph title = new Paragraph(messageSource.getMessage("report.tons.receive.title", null, locale));
        document.add(title);
        document.add(Chunk.NEWLINE);
    }

    private void createDateHeaderDocument(Document document) throws DocumentException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String harvestDateFrom = simpleDateFormat.format(campaignDTO.getHarvestDateFrom());
        String harvestDateTo = simpleDateFormat.format(campaignDTO.getHarvestDateTo());

        document.add(Chunk.NEWLINE);
        String strharvestWeekFrom = messageSource.getMessage("report.tons.tonsToHost.harvestWeekFrom", null, locale) + ":";
        strharvestWeekFrom += harvestDateFrom != null ? harvestDateFrom : "-";
        Paragraph harvestWeekFrom = new Paragraph(strharvestWeekFrom);
        document.add(harvestWeekFrom);

        document.add(Chunk.NEWLINE);
        String strharvestWeekTo = messageSource.getMessage("report.tons.tonsToHost.harvestWeekTo", null, locale) + ":";
        strharvestWeekTo += harvestDateTo != null ? harvestDateTo : "-";
        Paragraph harvestWeekTo = new Paragraph(strharvestWeekTo);
        document.add(harvestWeekTo);
    }

    private void createTotals(PdfPTable table) {
        Float sumTotal = 0f;
        Float totalWeek = 0f;

        PdfPCell[] pdfPCells = createPdfPCelList(harvestWeekList.size() + 2);
        PdfPCell cell = createCell(messageSource.getMessage("report.tons.receive.footer.total.label", null, locale), Color.LIGHT_GRAY, null);
        pdfPCells[0] = cell;

        for (int i = 0; i < harvestWeekList.size(); i++) {
            totalWeek = 0f;
            for (ReceiveTonsDTO receiveTonsDTO : receiveTonsDTOList) {
                if (receiveTonsDTO.getHarvestWeek() != null && receiveTonsDTO.getHarvestWeek().equals(harvestWeekList.get(i).getHarvestWeek()) &&
                        receiveTonsDTO.getYear() == harvestWeekList.get(i).getYear()) {
                    totalWeek += receiveTonsDTO.getSumActualTnRwLot();
                }
            }

            pdfPCells[i + 1] = createCell(String.format("%.2f", totalWeek), Color.LIGHT_GRAY, null);
            sumTotal += totalWeek;
        }

        pdfPCells[harvestWeekList.size() + 1] = createCell(String.format("%.2f", sumTotal), Color.LIGHT_GRAY, null);

        for (int i = 0; i < pdfPCells.length; i++) {
            table.addCell(pdfPCells[i]);
        }
    }

    private int findIndexWeek(Float harvestWeek, int year, List<ReceiveTonsDTO> harvestWeekList) {
        for (int i = 0; i < harvestWeekList.size(); i++) {
            if (harvestWeekList.get(i).getYear() == year && harvestWeekList.get(i).getHarvestWeek() != null && harvestWeekList.get(i).getHarvestWeek().equals(harvestWeek)) {
                return i;
            }
        }
        return 0;
    }

    private String setHeaderMessage() {
        String strValue;
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            strValue = getMessageSource().getMessage("report.tons.receive.header.lotCode.label", null, locale);
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            strValue = getMessageSource().getMessage("report.tons.receive.header.zone.label", null, locale);
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            strValue = getMessageSource().getMessage("report.tons.receive.header.hybrid.label", null, locale);
        } else {
            strValue = getMessageSource().getMessage("report.tons.receive.header.program.label", null, locale);
        }
        return strValue;
    }

    private void createHeaderReport(PdfPTable table) throws BadElementException {
        PdfPCell[] pdfPCells = new PdfPCell[harvestWeekList.size() + 2];

        Font font = setFont(Color.WHITE);


        String zoneHarvestWeek = setHeaderMessage() + "/" + getMessageSource().getMessage("report.tons.receive.header.harvestWeek.label", null, locale);
        pdfPCells[0] = createCell(zoneHarvestWeek, Color.GRAY, font);

        for (int i = 0; i < harvestWeekList.size(); i++) {
            pdfPCells[i + 1] = createCell(String.format("%.0f", harvestWeekList.get(i).getHarvestWeek()), Color.GRAY, font);
        }

        pdfPCells[harvestWeekList.size() + 1] = createCell(getMessageSource().getMessage("report.tons.receive.footer.total.label", null, locale), Color.GRAY, font);

        for (int i = 0; i < pdfPCells.length; i++) {
            table.addCell(pdfPCells[i]);
        }

        table.completeRow();
    }

    private Font setFont(Color color) {
        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(color);
        return font;
    }

    private PdfPCell[] createPdfPCelList(Integer size) {
        PdfPCell[] pdfPCells = new PdfPCell[size];
        for (int i = 0; i < size; i++) {
            pdfPCells[i] = new PdfPCell();
        }

        return pdfPCells;
    }

    private PdfPCell createCell(String data, Color backgroundColor, Font font) {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(backgroundColor);
        cell.setPadding(8);
        if (font == null) {
            cell.setPhrase(new Phrase(data));
        } else {
            cell.setPhrase(new Phrase(data, font));
        }
        return cell;
    }

    public MessageSource getMessageSource() {
        return messageSource;
    }

    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}