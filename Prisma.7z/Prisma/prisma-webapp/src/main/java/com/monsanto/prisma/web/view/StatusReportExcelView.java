package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.StatusReportDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Created by PGSETT on 27/08/2014.
 */
public class StatusReportExcelView extends AbstractExcelView {

    private final String reportTonsStatusReportHeaderHybridLabel = "report.tons.statusReport.header.hybrid.label";
    private final String reportTonsReceiveHeaderProgramLabel = "report.tons.receive.header.program.label";
    private MessageSource messageSource;
    private static final short INIT_RECORD = 5;
    private static final String STATUS_REPORT_LIST = "statusReportExcel";
    private static final String CAMPAIGN_TON_DTO = "campaignTonDTO";

    private HSSFWorkbook workbook = null;

    private HSSFSheet excelSheet = null;
    private List<StatusReportDTO> statusReportList = new ArrayList<StatusReportDTO>();

    @Override
    protected void buildExcelDocument(Map model, HSSFWorkbook hssfWorkbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            CampaignTonDTO campaignDTO = (CampaignTonDTO) model.get(CAMPAIGN_TON_DTO);
            request.setAttribute("campaignId", campaignDTO.getCampaignId());
            this.workbook = hssfWorkbook;
            statusReportList = (List<StatusReportDTO>) model.get(STATUS_REPORT_LIST);
            excelSheet = workbook.createSheet(Constants.SHEET_NAME);

            setInformationReport(campaignDTO);
            setExcelHeader();
            setExcelRows();
        } catch (Exception ex) {
            RequestDispatcher rd = request.getRequestDispatcher("error");
            rd.forward(request, response);
        }
    }

    private void setInformationReport(CampaignTonDTO campaignDTO) {
        String reportTonsStatusReportTitle = "report.tons.statusReport.title";
        Utilities.addExcelRow(excelSheet, workbook, getMessage(reportTonsStatusReportTitle), 0, Constants.TWO);

        String strHybrid = getMessage(reportTonsStatusReportHeaderHybridLabel) + ":";
        strHybrid += campaignDTO.getHybridId() == null ? "-" : campaignDTO.getHybridName();
        Utilities.addExcelRow(excelSheet, workbook, strHybrid, Constants.ONE, Constants.TWO);

        String strProgram = getMessage(reportTonsReceiveHeaderProgramLabel) + ":";
        strProgram += (campaignDTO.getProgram() == null || campaignDTO.getProgram().equals(Constants.BLANK)) ? "-" : campaignDTO.getProgram();
        Utilities.addExcelRow(excelSheet, workbook, strProgram, Constants.TWO, Constants.TWO);

    }


    private void setExcelHeader() {
        HSSFRow excelHeader = excelSheet.createRow(Constants.FOUR);

        CellStyle cellStyle = createCellStyle(true);

        createFont(cellStyle);

        createCellString(excelHeader, Constants.ONE, "campaign.plant.name", cellStyle);
        createCellString(excelHeader, Constants.TWO, reportTonsStatusReportHeaderHybridLabel, cellStyle);
        createCellString(excelHeader, Constants.THREE, reportTonsReceiveHeaderProgramLabel, cellStyle);
        createCellString(excelHeader, Constants.FOUR, "report.tons.statusReport.header.umProgram.label", cellStyle);
        createCellString(excelHeader, Constants.FIVE, "report.tons.statusReport.header.actual.label", cellStyle);
        createCellString(excelHeader, Constants.SIX, "report.tons.statusReport.header.baggingStatus.label", cellStyle);
        createCellString(excelHeader, Constants.SEVEN, "report.tons.statusReport.header.initialProgram.label", cellStyle);
        createCellString(excelHeader, Constants.EIGHT, "report.tons.statusReport.header.fieldPercent.label", cellStyle);
        createCellString(excelHeader, Constants.NINE, "report.tons.statusReport.header.plantPercent.label", cellStyle);
        createCellString(excelHeader, Constants.TEN, "report.tons.statusReport.header.baggingPercent.label", cellStyle);
        createCellString(excelHeader, Constants.ELEVEN, "report.tons.statusReport.header.bagging.label", cellStyle);
        createCellString(excelHeader, Constants.TWELVE, "report.tons.statusReport.header.commercialUnit.label", cellStyle);
        createCellString(excelHeader, Constants.THIRTEEN, "report.tons.statusReport.header.commercialBag.label", cellStyle);
        createCellString(excelHeader, Constants.FOURTEEN, "report.tons.statusReport.header.observations.label", cellStyle);
        createCellString(excelHeader, Constants.FIFTEEN, "report.tons.statusReport.header.tnds.label", cellStyle);
    }

    private void createFont(CellStyle cellStyle) {
        Font font = workbook.createFont();
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        cellStyle.setFont(font);
    }

    private CellStyle createCellStyle(Boolean wrapText) {
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setWrapText(wrapText);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setFillForegroundColor(HSSFColor.SEA_GREEN.index);
        return cellStyle;
    }

    private void createCellString(HSSFRow excelHeader, int column, String messageKey, CellStyle cellStyle) {
        Utilities.createCellString(excelHeader, column, getMessage(messageKey), cellStyle);
    }

    private void setExcelRows() {
        int record = INIT_RECORD;
        int i = Constants.ONE;
        boolean flag = true;
        int initRecord = INIT_RECORD;
        for (StatusReportDTO statusReportDTO : statusReportList) {
            String granProgram = statusReportDTO.getGranProgram();
            String germoplasma = statusReportDTO.getGermoplasma();

            if (granProgram != null && germoplasma != null) {
                if (i < statusReportList.size() && granProgram.equals(statusReportList.get(i).getGranProgram())
                        && germoplasma.equals(statusReportList.get(i).getGermoplasma())) {
                    if (flag) {
                        initRecord = record;
                    }
                    addRow(record++, statusReportDTO);
                    flag = false;
                } else {
                    addRow(record++, statusReportDTO);
                    addTotalRows(statusReportDTO, initRecord, record++, Constants.FIVE, Constants.SIX,
                            Constants.SEVEN, Constants.EIGHT, Constants.NINE, Constants.TEN, Constants.THIRTEEN, Constants.FIFTEEN);
                    initRecord = record;
                    flag = true;
                }
            }
            i++;
        }
    }

    private void addTotalRows(StatusReportDTO statusReportDTO, int initRecord, int record, int... colIndexs) {
        int recordHasta = record;

        CellStyle cellStyle = createCellStyle(false);

        HSSFRow excelRow = excelSheet.createRow(record++);

        createLabelTotalRow(statusReportDTO, cellStyle, excelRow);

        for (int colIndex : colIndexs) {
            Cell cell = excelRow.createCell(colIndex);
            cell.setCellStyle(cellStyle);
            String colString = CellReference.convertNumToColString(colIndex);
            String function = colIndex >= Constants.NINE && colIndex <= Constants.ELEVEN ? "AVERAGE" : "SUM";

            cell.setCellFormula(function + "(" + colString + (initRecord + Constants.ONE) + ":" + colString + recordHasta + ")");
        }
    }

    private void createLabelTotalRow(StatusReportDTO statusReportDTO, CellStyle cellStyle, HSSFRow excelRow) {
        Utilities.createCellString(excelRow, Constants.ONE, statusReportDTO.getGranProgram() + " " + statusReportDTO.getGermoplasma(), cellStyle);
        Utilities.createCellString(excelRow, Constants.TWO, Constants.BLANK, cellStyle);
        Utilities.createCellString(excelRow, Constants.THREE, Constants.BLANK, cellStyle);
        Utilities.createCellString(excelRow, Constants.FOUR, Constants.BLANK, cellStyle);
        Utilities.createCellString(excelRow, Constants.FIVE, Constants.BLANK, cellStyle);
        Utilities.createCellString(excelRow, Constants.ELEVEN, Constants.BLANK, cellStyle);
        Utilities.createCellString(excelRow, Constants.TWELVE, Constants.BLANK, cellStyle);
        Utilities.createCellString(excelRow, Constants.FOURTEEN, Constants.BLANK, cellStyle);
    }


    private void addRow(Integer record, StatusReportDTO statusReportDTO) {
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_GREEN.index);

        HSSFRow excelRow = excelSheet.createRow(record);
        Utilities.createCellString(excelRow, Constants.ONE, statusReportDTO.getPlantName(), cellStyle);
        Utilities.createCellString(excelRow, Constants.TWO, statusReportDTO.getHybridName(), cellStyle);
        Utilities.createCellString(excelRow, Constants.THREE, statusReportDTO.getProgram(), cellStyle);
        Utilities.createCellString(excelRow, Constants.FOUR, statusReportDTO.getUmProgram(), cellStyle);
        Utilities.createCellDouble(excelRow, Constants.FIVE, statusReportDTO.getActual(), cellStyle);
        Utilities.createCellDouble(excelRow, Constants.SIX, statusReportDTO.getBaggingStatus(), cellStyle);
        Utilities.createCellDouble(excelRow, Constants.SEVEN, statusReportDTO.getInitialProgram(), cellStyle);
        Utilities.createCellDouble(excelRow, Constants.EIGHT, statusReportDTO.getField(), cellStyle);
        Utilities.createCellDouble(excelRow, Constants.NINE, statusReportDTO.getPlant(), cellStyle);
        Utilities.createCellDouble(excelRow, Constants.TEN, statusReportDTO.getBagging(), cellStyle);
        Utilities.createCellString(excelRow, Constants.ELEVEN, statusReportDTO.getEmbolse(), cellStyle);
        Utilities.createCellString(excelRow, Constants.TWELVE, statusReportDTO.getUnidadComercial(), cellStyle);
        Utilities.createCellDouble(excelRow, Constants.THIRTEEN, statusReportDTO.getBolsasComerciales(), cellStyle);
        Utilities.createCellString(excelRow, Constants.FOURTEEN, Constants.BLANK, cellStyle);
        Utilities.createCellDouble(excelRow, Constants.FIFTEEN, statusReportDTO.getTnDs(), cellStyle);
    }

    private String getMessage(String key) {
        Locale locale = LocaleContextHolder.getLocale();
        return messageSource.getMessage(key, null, locale);
    }

    public MessageSource getMessageSource() {
        return messageSource;
    }

    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}