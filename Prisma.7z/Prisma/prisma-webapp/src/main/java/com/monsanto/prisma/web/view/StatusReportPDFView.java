package com.monsanto.prisma.web.view;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.StatusReportDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import com.monsanto.prisma.web.utils.AbstractITextPdfView;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.servlet.view.document.AbstractPdfView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.List;

/**
 * Created by PGSETT on 27/08/2014.
 */
public class StatusReportPDFView extends AbstractITextPdfView {

    public static final float WIDTH_PERCENTAGE = 110.0f;
    private static final String reportTonsStatusReportHeaderHybridLabel = "report.tons.statusReport.header.hybrid.label";
    private static final String reportTonsReceiveHeaderProgramLabel = "report.tons.receive.header.program.label";
    private MessageSource messageSource;
    private static final String STATUS_REPORT_PDF = "statusReportPDF";
    private static final String CAMPAIGN_TON_DTO = "campaignTonDTO";

    Double totalActual = 0D;
    Double totalStatusBagging = 0D;
    Double totalProgram = 0D;
    Double totalField = 0D;
    Double totalPlant = 0D;
    Double totalBagging = 0D;
    Double totalCommercialBagging = 0D;
    Double totalTnDs = 0D;

    private Locale locale;

    @Override
    protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer, HttpServletRequest request, HttpServletResponse response) throws Exception {
        initializeValues();
        try {
            CampaignTonDTO campaignDTO = (CampaignTonDTO) model.get(CAMPAIGN_TON_DTO);
            request.setAttribute("campaignId", campaignDTO.getCampaignId());
            List<StatusReportDTO> statusReportList = (List<StatusReportDTO>) model.get(STATUS_REPORT_PDF);
            setParamValues(document, model);
            PdfPTable table = new PdfPTable(Constants.FIFTEEN);
            table.setWidthPercentage(WIDTH_PERCENTAGE);
            table.setSpacingBefore(Constants.FOURTEEN);
            setHeaderFirst(table);
            setHeaderSecond(table);
            if (statusReportList != null) {
                setLotValues(table, statusReportList);
            }
            document.add(table);
        } catch (Exception e) {
            logger.error("error in pdf view -" + e.getMessage(), e);
            RequestDispatcher rd = request.getRequestDispatcher("error");
            rd.forward(request, response);
        }
    }

    private void setParamValues(Document document, Map<String, Object> model) throws DocumentException {
        CampaignTonDTO campaignDTO = (CampaignTonDTO) model.get(CAMPAIGN_TON_DTO);
        setTitleReport(document);

        setHybridReport(document, campaignDTO);

        setProgramReport(document, campaignDTO);
    }

    private void setProgramReport(Document document, CampaignTonDTO campaignDTO) throws DocumentException {
        document.add(Chunk.NEWLINE);
        String strProgram = messageSource.getMessage(reportTonsReceiveHeaderProgramLabel, null, locale) + ":";
        strProgram += campaignDTO.getProgram() != null && !campaignDTO.getProgram().equals("") ? campaignDTO.getProgram() : "-";
        Paragraph program = new Paragraph(strProgram);
        document.add(program);
    }

    private void setHybridReport(Document document, CampaignTonDTO campaignDTO) throws DocumentException {
        document.add(Chunk.NEWLINE);
        String strHybrid = messageSource.getMessage(reportTonsStatusReportHeaderHybridLabel, null, locale) + ":";
        strHybrid += campaignDTO.getHybridId() != null ? campaignDTO.getHybridName() : "-";
        Paragraph hybrid = new Paragraph(strHybrid);
        document.add(hybrid);
    }

    private void setTitleReport(Document document) throws DocumentException {
        Paragraph title = new Paragraph(messageSource.getMessage("report.tons.statusReport.title", null, locale));
        document.add(title);
    }

    private void setLotValues(PdfPTable table, List<StatusReportDTO> statusReportList) throws BadElementException {
        int i = Constants.ONE;
        for (StatusReportDTO statusReportDTO : statusReportList) {
            String granProgram = statusReportDTO.getGranProgram();
            String germoplasma = statusReportDTO.getGermoplasma();

            if (granProgram != null && germoplasma != null) {
                if (i < statusReportList.size() && granProgram.equals(statusReportList.get(i).getGranProgram())
                        && germoplasma.equals(statusReportList.get(i).getGermoplasma())) {
                    addRow(table, statusReportDTO);
                    calculateTotals(statusReportDTO);
                } else {
                    if (i != statusReportList.size()) {
                        addTotalRows(table, statusReportDTO);
                        initializeValues();
                        addRow(table, statusReportDTO);
                        calculateTotals(statusReportDTO);
                    } else {
                        addRow(table, statusReportDTO);
                        calculateTotals(statusReportDTO);
                        addTotalRows(table, statusReportDTO);
                    }
                }
            }
            i++;
        }
    }

    private void initializeValues() {
        totalActual = 0D;
        totalStatusBagging = 0D;
        totalProgram = 0D;
        totalField = 0D;
        totalPlant = 0D;
        totalBagging = 0D;
        totalCommercialBagging = 0D;
        totalTnDs = 0D;
        locale = LocaleContextHolder.getLocale();
    }

    private void addRow(PdfPTable table, StatusReportDTO statusReportDTO) throws BadElementException {
        Utilities.setPdfValue(table, statusReportDTO.getPlantName(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getHybridName(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getProgram(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getUmProgram(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getActual(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getBaggingStatus(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getInitialProgram(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getField(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getPlant(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getBagging(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getEmbolse(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getUnidadComercial(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getBolsasComerciales(), Color.BLACK, Color.white);
        Utilities.setPdfValue(table, null, Color.BLACK, Color.white);
        Utilities.setPdfValue(table, statusReportDTO.getTnDs(), Color.BLACK, Color.white);
    }

    private void addTotalRows(PdfPTable table, StatusReportDTO statusReportDTO) throws BadElementException {
        String granProgram = statusReportDTO.getGranProgram() != null ? statusReportDTO.getGranProgram() : "";
        String germoplasma = statusReportDTO.getGermoplasma() != null ? statusReportDTO.getGermoplasma() : "";

        Utilities.setPdfValue(table, granProgram + " " + germoplasma, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, null, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, null, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, null, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, totalActual, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, totalStatusBagging, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, totalProgram, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, totalField, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, totalPlant, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, totalBagging, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, null, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, null, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, totalCommercialBagging, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, null, Color.WHITE, Color.LIGHT_GRAY);
        Utilities.setPdfValue(table, totalTnDs, Color.WHITE, Color.LIGHT_GRAY);
    }

    private void setHeaderFirst(PdfPTable table) throws BadElementException {
        PdfPCell cell = createPdfPCell();
        Font font = Utilities.setFont(Color.WHITE);

        setHeaderValue(table, cell, "campaign.plant.name", font);
        setHeaderValue(table, cell, reportTonsStatusReportHeaderHybridLabel, font);
        setHeaderValue(table, cell, reportTonsReceiveHeaderProgramLabel, font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.umProgram.label", font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.actual.label", font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.baggingStatus.label", font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.initialProgram.label", font);
    }

    private void setHeaderValue(PdfPTable table, PdfPCell cell, String key, Font font) {
        cell.setPhrase(new Phrase(messageSource.getMessage(key, null, locale), font));
        table.addCell(cell);
    }

    private void setHeaderSecond(PdfPTable table) throws BadElementException {
        Font font = Utilities.setFont(Color.WHITE);
        PdfPCell cell = createPdfPCell();

        setHeaderValue(table, cell, "report.tons.statusReport.header.fieldPercent.label", font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.plantPercent.label", font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.baggingPercent.label", font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.bagging.label", font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.commercialUnit.label", font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.commercialBag.label", font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.observations.label", font);
        setHeaderValue(table, cell, "report.tons.statusReport.header.tnds.label", font);
    }

    private PdfPCell createPdfPCell() {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(Color.GRAY);
        cell.setPadding(Constants.EIGHT);
        return cell;
    }

    private void calculateTotals(StatusReportDTO statusReportDTO) {
        totalActual += statusReportDTO.getActual() != null ? statusReportDTO.getActual() : 0;
        totalStatusBagging += statusReportDTO.getBaggingStatus() != null ? statusReportDTO.getBaggingStatus() : 0;
        totalProgram += statusReportDTO.getInitialProgram() != null ? statusReportDTO.getInitialProgram() : 0;
        totalField += statusReportDTO.getField() != null ? statusReportDTO.getField() : 0;
        totalPlant += statusReportDTO.getPlant() != null ? statusReportDTO.getPlant() : 0;
        totalBagging += statusReportDTO.getBagging() != null ? statusReportDTO.getBagging() : 0;
        totalCommercialBagging += statusReportDTO.getBolsasComerciales() != null ? statusReportDTO.getBolsasComerciales() : 0;
        totalTnDs += statusReportDTO.getTnDs() != null ? statusReportDTO.getTnDs() : 0;
    }

    public MessageSource getMessageSource() {
        return messageSource;
    }

    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}