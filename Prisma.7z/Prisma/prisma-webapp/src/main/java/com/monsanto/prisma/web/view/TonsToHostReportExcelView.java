package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.TonsToHostDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.core.utils.utilities.Utilities;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.servlet.view.document.AbstractExcelView;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Created by PGSETT on 26/08/2014.
 */
public class TonsToHostReportExcelView extends AbstractExcelView {

    private static final String REPORT_TONS_RECEIVE_FOOTER_TOTAL_LABEL = "report.tons.receive.footer.total.label";
    private MessageSource messageSource = null;
    private static final String TONS_TO_HOTS_REPORT_LIST = "tonsToHostReportExcel";
    private static final String CAMPAIGN_TON_DTO = "campaignTonDTO";
    private static final String WEEKS_TONS_TO_HOST = "weeksTonsToHost";
    private List<TonsToHostDTO> weeks = null;
    private HSSFSheet excelSheet = null;
    private List<TonsToHostDTO> tonsToHostList = null;
    private HSSFWorkbook workbook = null;
    private Integer optionFilter;

    @Override
    protected void buildExcelDocument(Map model, HSSFWorkbook workbook, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            CampaignTonDTO campaignDTO = (CampaignTonDTO) model.get(CAMPAIGN_TON_DTO);
            request.setAttribute("campaignId", campaignDTO.getCampaignId());
            this.workbook =  workbook;
            tonsToHostList = (List<TonsToHostDTO>) model.get(TONS_TO_HOTS_REPORT_LIST);
            weeks = (List<TonsToHostDTO>) model.get(WEEKS_TONS_TO_HOST);
            this.optionFilter = (Integer) model.get(Constants.OPTION_FILTER);

            createMainInformationReport(campaignDTO);

            createHeader();
            createBody();
            createTotals();
        } catch (Exception ex) {
            RequestDispatcher rd = request.getRequestDispatcher("error");
            rd.forward(request, response);
        }
    }

    private boolean isEqualValues(TonsToHostDTO tonsToHostDTO, TonsToHostDTO valueActual) {
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            return tonsToHostDTO.getLotCode().equals(valueActual.getLotCode());
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            return tonsToHostDTO.getZoneCode().equals(valueActual.getZoneCode());
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            return tonsToHostDTO.getHybridName().equals(valueActual.getHybridName());
        } else {
            return tonsToHostDTO.getProgram().equals(valueActual.getProgram());
        }
    }

    private void createBody() {
        TonsToHostDTO valueActual = new TonsToHostDTO();
        HSSFRow excelRow = null;
        int record = Constants.FIVE;
        Float sumProgram = 0f;

        if (tonsToHostList.isEmpty()) {
            excelRow = excelSheet.createRow(record++);
            Locale locale = LocaleContextHolder.getLocale();
            Utilities.createCellString(excelRow, Constants.ONE, messageSource.getMessage("report.tons.receive.empty.label", null, locale));
        }

        for (TonsToHostDTO tonsToHostDTO : tonsToHostList) {
            if (isNew(optionFilter, valueActual, tonsToHostDTO)) {
                valueActual = tonsToHostDTO;
                excelRow = excelSheet.createRow(record++);
                setValuesByOption(excelRow, valueActual);
                sumProgram = 0f;
            }
            if (isEqualValues(tonsToHostDTO, valueActual)) {
                sumProgram += getSumProgram(excelRow, tonsToHostDTO, sumProgram);
            }
        }
    }

    private void setValuesByOption(HSSFRow excelRow, TonsToHostDTO valueActual) {
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            Utilities.createCellString(excelRow, Constants.ONE, valueActual.getLotCode());
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            Utilities.createCellString(excelRow, Constants.ONE, valueActual.getZoneCode());
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            Utilities.createCellString(excelRow, Constants.ONE, valueActual.getHybridName());
        } else {
            Utilities.createCellString(excelRow, Constants.ONE, valueActual.getProgram());
        }
    }

    private boolean isNew(Integer optionFilter, TonsToHostDTO valueActual, TonsToHostDTO receiveTonsDTO) {
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            return isNewLotCode(valueActual.getLotCode(), receiveTonsDTO.getLotCode());
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            return isNewZone(valueActual.getZoneCode(), receiveTonsDTO.getZoneCode());
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            return isNewHybrid(valueActual.getHybridName(), receiveTonsDTO.getHybridName());
        } else {
            return isNewProgram(valueActual.getProgram(), receiveTonsDTO.getProgram());
        }
    }

    private boolean isNewZone(String zoneActual, String zoneCode) {
        if (zoneActual == null) {
            return true;
        }

        if (!zoneCode.equals(zoneActual)) {
            return true;
        }
        return false;
    }

    private boolean isNewHybrid(String hybridActual, String hybridName) {
        if (hybridActual == null) {
            return true;
        }
        if (!hybridName.equals(hybridActual)) {
            return true;
        }
        return false;
    }

    private boolean isNewLotCode(String lotCodeActual, String lotCode) {
        if (lotCodeActual == null) {
            return true;
        }
        if (!lotCode.equals(lotCodeActual)) {
            return true;
        }
        return false;
    }

    private boolean isNewProgram(String programActual, String program) {
        if (programActual == null) {
            return true;
        }
        if (!program.equals(programActual)) {
            return true;
        }
        return false;
    }

    private Float getSumProgram(HSSFRow excelRow, TonsToHostDTO tonsToHostDTO, Float sumProgram) {
        for (int i = 0; i < weeks.size(); i++) {
            if (tonsToHostDTO.getHarvestWeek() != null && tonsToHostDTO.getHarvestWeek().equals(weeks.get(i).getHarvestWeek())
                    && tonsToHostDTO.getYear() == weeks.get(i).getYear()) {
                if (tonsToHostDTO.getSumActualTnDSLot() != null) {
                    Utilities.createCellDouble(excelRow, i + 2, tonsToHostDTO.getSumActualTnDSLot());
                    sumProgram += tonsToHostDTO.getSumActualTnDSLot().floatValue();
                }
                Utilities.createCellFloat(excelRow, weeks.size() + 2, sumProgram);
                break;
            }
        }
        return sumProgram;
    }


    private void createTotals() {
        Float sumTotalProgramWeek = null;
        Float sumTotal = 0f;

        Locale locale = LocaleContextHolder.getLocale();

        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setFillForegroundColor(HSSFColor.LIGHT_GREEN.index);

        HSSFRow row = excelSheet.createRow(excelSheet.getLastRowNum() + 1);

        Utilities.createCellString(row, Constants.ONE, getMessageSource().getMessage(REPORT_TONS_RECEIVE_FOOTER_TOTAL_LABEL, null, locale), cellStyle);
        for (int i = 0; i < weeks.size(); i++) {
            sumTotalProgramWeek = 0f;
            for (int j = Constants.FIVE; j < excelSheet.getLastRowNum(); j++) {
                HSSFCell value = excelSheet.getRow(j).getCell(2 + i);
                if (value != null) {
                    sumTotalProgramWeek += new Float(value.getNumericCellValue());
                }
            }
            Utilities.createCellFloat(row, i + 2, sumTotalProgramWeek, cellStyle);
            sumTotal += sumTotalProgramWeek;
        }
        Utilities.createCellFloat(row, weeks.size() + 2, sumTotal, cellStyle);
    }

    private void createMainInformationReport(CampaignTonDTO campaignDTO) {
        excelSheet = workbook.createSheet(Constants.SHEET_NAME);
        Locale locale = LocaleContextHolder.getLocale();
        Utilities.addExcelRow(excelSheet, workbook, messageSource.getMessage("report.tons.tonsToHost.title", null, locale), 0, Constants.THREE);
        String strValue = getLabelsForParamsMessage(campaignDTO);
        strValue += campaignDTO.getProgram() != null && !campaignDTO.getProgram().equals("") ? campaignDTO.getProgram() : "-";
        Utilities.addExcelRow(excelSheet, workbook, strValue, Constants.ONE, Constants.THREE);
        createDatesMainInformation(campaignDTO, locale);
    }

    private String getLabelsForParamsMessage(CampaignTonDTO campaignDTO) {
        String strValue;
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            strValue = getMessage("report.tons.receive.header.lotCode.label") + ":";
            strValue += campaignDTO.getLotCode() != null ? campaignDTO.getLotCode() : "-";
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            strValue = getMessage("report.tons.receive.header.zone.label") + ":";
            strValue += campaignDTO.getZoneName() != null ? campaignDTO.getZoneName() : "-";
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            strValue = getMessage("report.tons.receive.header.hybrid.label") + ":";
            strValue += campaignDTO.getHybridName() != null ? campaignDTO.getHybridName() : "-";
        } else {
            strValue = getMessage("report.tons.receive.header.program.label") + ":";
            strValue += campaignDTO.getProgram() != null ? campaignDTO.getProgram() : "-";
        }
        return strValue;
    }

    private void createDatesMainInformation(CampaignTonDTO campaignDTO, Locale locale) {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String harvestDateFrom = simpleDateFormat.format(campaignDTO.getHarvestDateFrom());
        String harvestDateTo = simpleDateFormat.format(campaignDTO.getHarvestDateTo());

        String strharvestWeekFrom = messageSource.getMessage("report.tons.tonsToHost.harvestWeekFrom", null, locale) + ":";
        strharvestWeekFrom += harvestDateFrom == null ? "-" : harvestDateFrom;
        Utilities.addExcelRow(excelSheet, workbook, strharvestWeekFrom, Constants.TWO, Constants.THREE);

        String strharvestWeekTo = messageSource.getMessage("report.tons.tonsToHost.harvestWeekTo", null, locale) + ":";
        strharvestWeekTo += harvestDateTo == null ? "-" : harvestDateTo;
        Utilities.addExcelRow(excelSheet, workbook, strharvestWeekTo, Constants.THREE, Constants.THREE);
    }

    private String getHeaderMassage() {
        String strValue;
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            strValue = getMessage("report.tons.receive.header.lotCode.label");

        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            strValue = getMessage("report.tons.receive.header.zone.label");
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            strValue = getMessage("report.tons.receive.header.hybrid.label");

        } else {
            strValue = getMessage("report.tons.receive.header.program.label");

        }
        return strValue;
    }

    void createHeader() {
        CellStyle cellStyle = createCellStyle(true, HSSFColor.SEA_GREEN.index);
        createFont(cellStyle);
        HSSFRow excelHeader = excelSheet.createRow(Constants.FOUR);
        String strHarvestWeek = getHeaderMassage() + "/" + getMessage("report.tons.receive.header.harvestWeek.label");
        Utilities.createCellString(excelHeader, Constants.ONE, strHarvestWeek, cellStyle);
        for (int i = 0; i < weeks.size(); i++) {
            Utilities.createCellFloat(excelHeader, i + 2, weeks.get(i).getHarvestWeek(), cellStyle);
        }
        Utilities.createCellString(excelHeader, weeks.size() + 2, getMessage(REPORT_TONS_RECEIVE_FOOTER_TOTAL_LABEL), cellStyle);
    }

    private String getMessage(String key) {
        Locale locale = LocaleContextHolder.getLocale();
        return messageSource.getMessage(key, null, locale);
    }

    private void createFont(CellStyle cellStyle) {
        Font font = workbook.createFont();
        font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
        font.setColor(HSSFColor.WHITE.index);
        cellStyle.setFont(font);
    }

    private CellStyle createCellStyle(Boolean wrapText, short color) {
        CellStyle cellStyle = workbook.createCellStyle();
        cellStyle.setWrapText(wrapText);
        cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        cellStyle.setFillForegroundColor(color);
        return cellStyle;
    }

    public MessageSource getMessageSource() {
        return messageSource;
    }

    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}
