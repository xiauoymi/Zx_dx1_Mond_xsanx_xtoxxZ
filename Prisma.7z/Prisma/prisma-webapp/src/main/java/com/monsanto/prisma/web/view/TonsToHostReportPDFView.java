package com.monsanto.prisma.web.view;

import com.lowagie.text.*;
import com.lowagie.text.Font;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.TonsToHostDTO;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.utils.AbstractITextPdfView;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.List;

/**
 * Created by PGSETT on 27/08/2014.
 */
public class TonsToHostReportPDFView extends AbstractITextPdfView {

    private MessageSource messageSource;
    public static final String EXPORT_PDF = "tonsToHostReportPDF";
    private static final String CAMPAIGN_TON_DTO = "campaignTonDTO";
    public static final String WEEKS_TONS_TO_HOST = "weeksTonsToHost";

    private List<TonsToHostDTO> tonsToHostList;
    private List<TonsToHostDTO> weeks;

    private CampaignTonDTO campaignDTO;

    private Locale locale = LocaleContextHolder.getLocale();
    private Integer optionFilter;

    @Override
    protected void buildPdfDocument(Map<String, Object> model, Document document, PdfWriter writer, HttpServletRequest request, HttpServletResponse response) throws Exception {
        try {
            campaignDTO = (CampaignTonDTO) model.get(CAMPAIGN_TON_DTO);
            request.setAttribute("campaignId", campaignDTO.getCampaignId());
            tonsToHostList = (List<TonsToHostDTO>) model.get(EXPORT_PDF);
            weeks = (List<TonsToHostDTO>) model.get(WEEKS_TONS_TO_HOST);
            this.optionFilter = (Integer) model.get(Constants.OPTION_FILTER);
            PdfPTable table = createPdfPTable();

            createMainInformation(document);
            createHeaderReport(table);
            createReportData(table);
            createTotals(table);
            document.add(table);
        } catch (Exception e) {
            RequestDispatcher rd = request.getRequestDispatcher("error");
            rd.forward(request, response);
        }
    }

    private PdfPTable createPdfPTable() {
        PdfPTable table = new PdfPTable(weeks.size() + 2);
        table.setWidthPercentage(100.0f);
        table.setSpacingBefore(Constants.FIFTEEN);
        return table;
    }

    private void createMainInformation(Document document) throws DocumentException {
        createTitleReport(document);
        createProgramMainInformation(document);
        createDateMainInformation(document);
    }

    private void createTitleReport(Document document) throws DocumentException {
        Paragraph title = new Paragraph(messageSource.getMessage("report.tons.tonsToHost.title", null, locale));
        document.add(title);
        document.add(Chunk.NEWLINE);
    }

    private void createProgramMainInformation(Document document) throws DocumentException {
        Paragraph program = new Paragraph(setLabelForParamMessage());
        document.add(program);
    }

    private String setLabelForParamMessage() {
        String strValue = "";
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            strValue = messageSource.getMessage("report.tons.receive.header.lotCode.label", null, locale) + ":";
            strValue += campaignDTO.getLotCode() != null ? campaignDTO.getLotCode() : "-";
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            strValue = messageSource.getMessage("report.tons.receive.header.zone.label", null, locale) + ":";
            strValue += campaignDTO.getZoneName() != null ? campaignDTO.getZoneName() : "-";
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            strValue = messageSource.getMessage("report.tons.receive.header.hybrid.label", null, locale) + ":";
            strValue += campaignDTO.getHybridName() != null ? campaignDTO.getHybridName() : "-";
        } else {
            strValue = messageSource.getMessage("report.tons.receive.header.program.label", null, locale) + ":";
            strValue += campaignDTO.getProgram() != null ? campaignDTO.getProgram() : "-";
        }
        return strValue;
    }

    private void createDateMainInformation(Document document) throws DocumentException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String harvestDateFrom = simpleDateFormat.format(campaignDTO.getHarvestDateFrom());
        String harvestDateTo = simpleDateFormat.format(campaignDTO.getHarvestDateTo());

        document.add(Chunk.NEWLINE);
        String strharvestWeekFrom = messageSource.getMessage("report.tons.tonsToHost.harvestWeekFrom", null, locale) + ":";
        strharvestWeekFrom += harvestDateFrom != null ? harvestDateFrom : "-";
        Paragraph harvestWeekFrom = new Paragraph(strharvestWeekFrom);
        document.add(harvestWeekFrom);

        document.add(Chunk.NEWLINE);
        String strHarvestWeekTo = messageSource.getMessage("report.tons.tonsToHost.harvestWeekTo", null, locale) + ":";
        strHarvestWeekTo += harvestDateTo != null ? harvestDateTo : "-";
        Paragraph harvestWeekTo = new Paragraph(strHarvestWeekTo);
        document.add(harvestWeekTo);
    }

    private String getLabelForHeaderMassage() {
        String strValue;
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            strValue = getMessageSource().getMessage("report.tons.receive.header.lotCode.label", null, locale);
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            strValue = getMessageSource().getMessage("report.tons.receive.header.zone.label", null, locale);
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            strValue = getMessageSource().getMessage("report.tons.receive.header.hybrid.label", null, locale);
        } else {
            strValue = getMessageSource().getMessage("report.tons.receive.header.program.label", null, locale);
        }
        return strValue;
    }

    private void createHeaderReport(PdfPTable table) {
        PdfPCell[] pdfPCells = new PdfPCell[weeks.size() + 2];
        Font font = setFont(Color.WHITE);

        String zoneHarvestWeek = getLabelForHeaderMassage() + "/" + getMessageSource().getMessage("report.tons.receive.header.harvestWeek.label", null, locale);
        pdfPCells[0] = createCell(zoneHarvestWeek, Color.GRAY, font);

        for (int i = 0; i < weeks.size(); i++) {
            pdfPCells[i + 1] = createCell(String.format("%.0f", weeks.get(i).getHarvestWeek()), Color.GRAY, font);
        }

        pdfPCells[weeks.size() + 1] = createCell(getMessageSource().getMessage("report.tons.receive.footer.total.label", null, locale), Color.GRAY, font);

        for (int i = 0; i < pdfPCells.length; i++) {
            table.addCell(pdfPCells[i]);
        }

        table.completeRow();
    }

    private void createReportData(PdfPTable table) {
        String valueProcessed = null;
        PdfPCell[] pdfPCells = null;
        Float sumTotalProgram = 0f;

        if (tonsToHostList == null) {
            return;
        }

        if (weeks.isEmpty()) {
            Locale locale = LocaleContextHolder.getLocale();
            table.addCell(createCell(getMessageSource().getMessage("report.tons.receive.empty.label", null, locale), Color.WHITE, null));
        }

        for (int i = 0; i < tonsToHostList.size(); i++) {
            TonsToHostDTO actual = tonsToHostList.get(i);

            if (valueProcessed == null) {
                valueProcessed = getValueByOption(actual);
                sumTotalProgram = 0f;
                pdfPCells = createPdfPCelList(weeks.size() + 2);
                pdfPCells[0] = createCell(valueProcessed, Color.WHITE, null);
            }

            if (!getValueByOption(actual).equals(valueProcessed)) {
                writeSumtotalProgram(table, pdfPCells, sumTotalProgram);
                valueProcessed = getValueByOption(actual);
                sumTotalProgram = 0f;
                pdfPCells = createPdfPCelList(weeks.size() + 2);
                pdfPCells[0] = createCell(valueProcessed, Color.WHITE, null);
            }

            if (getValueByOption(actual).equals(valueProcessed)) {
                int indexPos = findIndexWeek(actual.getHarvestWeek(), actual.getYear(), weeks);
                pdfPCells[indexPos + 1] = createCell(String.format("%.2f", actual.getSumActualTnDSLot()), Color.WHITE, null);
                if (actual.getSumActualTnDSLot() != null) {
                    sumTotalProgram += new Float(actual.getSumActualTnDSLot());
                }
            }
        }

        if (valueProcessed != null) {
            writeSumtotalProgram(table, pdfPCells, sumTotalProgram);
        }
    }

    private String getValueByOption(TonsToHostDTO actual) {
        String strValue = "";
        if (optionFilter.equals(Constants.OPTION_LOT_CODE)) {
            strValue = actual.getLotCode() != null ? actual.getLotCode() : "";
        } else if (optionFilter.equals(Constants.OPTION_ZONE)) {
            strValue = actual.getZoneCode();
        } else if (optionFilter.equals(Constants.OPTION_HYBRID)) {
            strValue = actual.getHybridName();
        } else {
            strValue = actual.getProgram() != null ? actual.getProgram() : "";
        }
        return strValue;
    }

    private void writeSumtotalProgram(PdfPTable table, PdfPCell[] pdfPCells, Float sumTotalProgram) {
        pdfPCells[weeks.size() + 1] = createCell(String.format("%.2f", sumTotalProgram), Color.LIGHT_GRAY, null);
        for (int j = 0; j < pdfPCells.length; j++) {
            table.addCell(pdfPCells[j]);
        }
    }

    private void createTotals(PdfPTable table) {
        Float sumTotal = 0f;

        PdfPCell[] pdfPCells = createPdfPCelList(weeks.size() + 2);
        PdfPCell cell = createCell(messageSource.getMessage("report.tons.receive.footer.total.label", null, locale), Color.LIGHT_GRAY, null);
        pdfPCells[0] = cell;

        for (int i = 0; i < weeks.size(); i++) {
            Float totalWeek = 0f;
            for (TonsToHostDTO tonsToHostDTO : tonsToHostList) {
                if (tonsToHostDTO.getHarvestWeek() != null && tonsToHostDTO.getHarvestWeek().equals(weeks.get(i).getHarvestWeek()) &&
                        tonsToHostDTO.getYear() == weeks.get(i).getYear() &&
                        tonsToHostDTO.getSumActualTnDSLot() != null) {
                    Double sumActTnDs = tonsToHostDTO.getSumActualTnDSLot() != null ? tonsToHostDTO.getSumActualTnDSLot() : 0;
                    totalWeek += new Float(sumActTnDs);
                }
            }

            pdfPCells[i + 1] = createCell(String.format("%.2f", totalWeek), Color.LIGHT_GRAY, null);
            sumTotal += totalWeek != null ? totalWeek : 0;
        }

        pdfPCells[weeks.size() + 1] = createCell(String.format("%.2f", sumTotal), Color.LIGHT_GRAY, null);

        for (int i = 0; i < pdfPCells.length; i++) {
            table.addCell(pdfPCells[i]);
        }
    }

    private PdfPCell[] createPdfPCelList(Integer size) {
        PdfPCell[] pdfPCells = new PdfPCell[size];
        for (int i = 0; i < size; i++) {
            pdfPCells[i] = new PdfPCell();
        }

        return pdfPCells;
    }

    private int findIndexWeek(Float harvestWeek, int year, List<TonsToHostDTO> weeks) {
        for (int i = 0; i < weeks.size(); i++) {
            if (weeks.get(i).getYear() == year && weeks.get(i).getHarvestWeek() != null && weeks.get(i).getHarvestWeek().equals(harvestWeek)) {
                return i;
            }
        }
        return 0;
    }

    private Font setFont(Color color) {
        Font font = FontFactory.getFont(FontFactory.HELVETICA);
        font.setColor(color);
        return font;
    }

    private PdfPCell createCell(String data, Color backgroundColor, Font font) {
        PdfPCell cell = new PdfPCell();
        cell.setBackgroundColor(backgroundColor);
        cell.setPadding(Constants.EIGHT);
        if (font == null) {
            cell.setPhrase(new Phrase(data));
        } else {
            cell.setPhrase(new Phrase(data, font));
        }
        return cell;
    }

    public MessageSource getMessageSource() {
        return messageSource;
    }

    public void setMessageSource(MessageSource messageSource) {
        this.messageSource = messageSource;
    }
}
