function CropService(){

}

var cropUrl = url + "/crop";

CropService.prototype.findAll = function(){
    $.ajax({
        url: cropUrl,
        type: 'GET',
        dataType: 'json',
        success: function (data){

        }
    });
}

var cropService = new CropService();