var batch = (function () {

    var batchService = new BatchService();

    var showSuccess = function (msg) {
        $('.alert').addClass('hide');
        $('.alert.alert-success').find('strong').html(msg);
        $('.alert.alert-success').removeClass('hide');
    }

    var showError = function (msg) {
        $('.alert').addClass('hide');
        $('.alert.alert-danger').find('label').html(msg);
        $('.alert.alert-danger').removeClass('hide');
    }

    var showErrorModal = function (msg) {
        $('.alert').addClass('hide');
        $('.alert-danger.alert-modal').find('label').html(msg);
        $('.alert-danger.alert-modal').removeClass('hide');
    }

    var showLoading = function () {
        $('.alert').addClass('hide');
        $('.alert.alert-warning').removeClass('hide');
    }

    var showModalLoading = function () {
        $('.alert').addClass('hide');
        $('.alert-warning.alert-modal').removeClass('hide');
    }

    var showLotsAssociated = function () {
        $('#lotAssociatedTable').find('tbody').html('');
        showLoading();
        var batchId = $('#batchId').val() || 0;
        batchService.findLotsAssociated($('#campaignId').val(), batchId)
            .done(function (data) {
                renderGrid(data.rows);
                calculateKgDs();
                $('.alert').addClass('hide');
            })
            .fail(function (data) {
                showError(data.message);
            });
    };

    var renderGrid = function (lotBatches) {
        $.each(lotBatches, function (index, lotBatch) {
            renderLot(lotBatch);
        });
        blockHybridCombo();
    }

    var renderLot = function (lotBatch) {
        $('.lot-batch .deleted-text').remove();
        if ($('.lot-batch[data-id="' + lotBatch.lot.id + '"]').length) {
            modifyLotInGrid(lotBatch);
        } else {
            addLotInGrid(lotBatch);
        }
    }

    var modifyLotInGrid = function (lotBatch) {
        $('.lot-batch[data-id="' + lotBatch.lot.id + '"]').find('.lot-batch-actual-kg-ds-lot').html(lotBatch.lot.actualKgDsLot);
        $('.lot-batch[data-id="' + lotBatch.lot.id + '"]').find('.lot-batch-kg-ds-lot-assigned').html(lotBatch.kgDSLotAssigned);
        $('.lot-batch[data-id="' + lotBatch.lot.id + '"]').find('.lot-batch-kg-fng-lot-assigned').html(lotBatch.kgFNGLotAssigned);
        $('.lot-batch[data-id="' + lotBatch.lot.id + '"]').find('.lot-batch-bag-lot-assigned').html(lotBatch.bagLotAssigned);
        $('.lot-batch[data-id="' + lotBatch.lot.id + '"]').find('.lot-batch-kg-ds-balance').html(lotBatch.lot.actualKgDsBalance);
        $('.lot-batch[data-id="' + lotBatch.lot.id + '"]').find('.lot-batch-kg-cull-tower').html(lotBatch.kgCullTower);
        $('.lot-batch[data-id="' + lotBatch.lot.id + '"]').find('.lot-batch-kg-ds-last').html(lotBatch.kgDSBatchLast);
    }

    var addLotInGrid = function (lotBatch) {
        var row = '' +
            '<tr class="lot-batch" data-id="' + lotBatch.lot.id + '" >' +
            '<td class="lot-code">' + '<button type="button" class="btn btn-link batch-lot-detail" data-lotid="' + lotBatch.lot.id + '">' + lotBatch.lot.lotCode + '</button>' + '</td>' +
//            '<td class="lot-code"><a href="' + url + '/lot/detail/' + lotBatch.lot.id + '">' + lotBatch.lot.lotCode + '</td>' +
//            '<td>' + lotBatch.lot.zoneCode + '</td>' +
            '<td>' + lotBatch.lot.establishmentName + '</td>' +
            '<td class="lot-batch-hybrid-id hide">' + lotBatch.lot.hybridId + '</td>' +
            '<td>' + lotBatch.lot.hybridName + '</td>' +
            '<td class="lot-batch-actual-kg-ds-lot">' + lotBatch.lot.actualKgDsLot + '</td>' +
            '<td class="lot-batch-kg-ds-lot-assigned">' + lotBatch.kgDSLotAssigned + '</td>' +
            '<td class="lot-batch-kg-fng-lot-assigned">' + lotBatch.kgFNGLotAssigned.toFixed(2) + '</td>' +
            '<td class="lot-batch-bag-lot-assigned">' + lotBatch.bagLotAssigned.toFixed(2) + '</td>' +
            '<td class="lot-batch-kg-ds-balance">' + lotBatch.lot.actualKgDsBalance + '</td>' +
            '<td class="lot-batch-kg-cull-tower">' + lotBatch.kgCullTower + '</td>' +
            '<td>' +
            '<div class="btn-toolbar">' +
            '<a class="btn btn-default update-lot" title="Actualizar" data-id="' + lotBatch.lot.id + '" ><i class="glyphicon glyphicon-pencil"></i></a>' +
            '<a class="btn btn-default delete-lot" title="Borrar" data-id="' + lotBatch.lot.id + '" ><i class="glyphicon glyphicon-trash"></i></a>' +
            '</div>' +
            '</td>'
        '</tr>';
        $('#lotAssociatedTable').find('tbody').append(row);
        renderButtons();
    }

    var renderButtons = function () {
        $('.btn.delete-lot').on({
            click: function () {
                $('.lot-batch[data-id="' + $(this).data('id') + '"]')
                    //mark lot like delete
                    .addClass('deleted-text')
                    //disable update and delete button of the lot.
                    .find('.btn').addClass('hide');
                calculateKgDs();
            }
        });

        $('.btn.update-lot').on("click", function () {
                $('#batchModal').modal('show');

                var lotId = $(this).data('id');
                var lot = $('.lot-batch[data-id="' + lotId + '"]');
                renderComboLots(function () {
                    $('#comboLots option[data-lot-id="' + lotId + '"]')
                        .prop('selected', true)
                        //Show Option Combo
                        .removeClass('hide');
                    //disable Combo
                    $('#comboLots').prop('disabled', true);
                    $('#lotKgDsAssigned').val($(lot).find(".lot-batch-kg-ds-lot-assigned").html().trim());
                    $('#kgCullTower').val($(lot).find(".lot-batch-kg-cull-tower").html());
                });

            }
        );

        $('.btn.batch-lot-detail').on("click", function () {
                var lotid = $(this).data("lotid");
                $("#associateLotForm").find('input#idLot').val(lotid);
                $("#associateLotForm").find('input#optionMenu').val("/lot/detail/");

                $('#associateLotForm').attr('action', url + "/lot/detail/");

                $('#associateLotForm').submit();
            }
        );
    }

    var blockHybridCombo = function () {
        //Block Hybrid combo when associated lots grid > 0
        if ($('.lot-batch').length) {
            $('#comboHybrid').prop('disabled', true);
        } else {
            $('#comboHybrid').prop('disabled', false);
        }
    }

    var addLot = function () {
        if ($('#addLotForm').bootstrapValidator('validate').data('bootstrapValidator').isValid()) {
            $('#batchForm').attr('action', url + "/campaign/batch/detail");
            showModalLoading();
            processLot();
            $('#batchForm').submit();
        }
    }

    var processLot = function () {
        if (isKgDsAssignedOk()) {
            showErrorModal(msgKgDsExceeded);
        } else {
            renderLot(createLot());
            calculateKgDs();
            saveBatch();
            $('#batchModal').modal('hide');
        }
    }

    var isKgDsAssignedOk = function () {
        var kgDsLotAssigned = $('#lotKgDsAssigned').val();
        var kgCullTower = $('#kgCullTower').val();
        var lotBalance = $('#comboLots').find(':selected').data('lot-balance');
        var lotId = $('#comboLots').find(':selected').data('lot-id');
        var kgDsLotAssignedOld = lotId > 0 ? $('.lot-batch[data-id=' + lotId + ']').find('.lot-batch-kg-ds-lot-assigned').html() : 0;
        return parseFloat(lotBalance) + parseFloat(kgDsLotAssignedOld) < parseFloat(kgDsLotAssigned);
    }

    var createLot = function () {
        return {
            lot: {
                id: $('#comboLots').find(':selected').data('lot-id'),
                lotCode: '',
                establishmentName: '',
                hybridId: $('#comboHybrid').find(':selected').val(),
                hybridName: '',
                actualKgDsLot: 0,
                actualKgDsBalance: 0
            },
            kgDSLotAssigned: $('#lotKgDsAssigned').val(),
            kgCullTower: $('#kgCullTower').val(),
            kgFNGLotAssigned: 0,
            bagLotAssigned: 0
        };
    }

    var calculateKgDs = function () {
        var kgDs = 0;
        $('#comboLots').find(':selected').prop('selected', false);
        $('#lotKgDsAssigned').val(0);
        $('#kgCullTower').val(0);
        $('.lot-batch').each(function () {
            isDeleted = $(this).hasClass('deleted-text');
            lotId = $(this).data('id');
            if ((typeof  isDeleted === "undefined") || (!isDeleted)) {
                //sum kgDS
                kgDs = +kgDs + +$(this).find('.lot-batch-kg-ds-lot-assigned').html();
                //hide options
                $('#comboLots').find('option[data-lot-id="' + lotId + '"]')
                    .addClass('hide')
                    .prop('disabled', true);
            } else {
                //show options
                $('#comboLots').find('option[data-lot-id="' + lotId + '"]')
                    .removeClass('hide')
                    .prop('disabled', false);
            }
        });
        $('#batchKgDS').val(kgDs);
    }

    var renderComboLots = function (postRenderCombo) {
        var hybridId = $('#comboHybrid').find(':selected').val();
        if (hybridId > 0) {
            //find lots by hybrid and campaign
            $('#comboLots').prop('disabled', true);
            $('#comboLots').find('option[data-lot-id!=0]').remove();
            showModalLoading();
            lotService.findLotsByHybridAndCampaign(hybridId)
                .done(function (data) {
                    if (data.success) {
                        $(data.rows).each(function (index, item) {
                            var option = '<option data-lot-id="' + item.id +
                                '" data-hybrid-id="' + item.hybridId +
                                '" data-lot-balance="' + item.actualKgDsBalance + '">' +
                                item.lotCode + ' - (' + item.actualKgDsBalance + ')</option>';
                            $('#comboLots').append(option);
                        });
                        $('#comboLots').prop('disabled', false);
                        postRenderCombo ? postRenderCombo() : 0;
                        $('.alert').addClass('hide');
                    }
                });
            $('.btn.show-modal-add-lot').removeClass('disabled');
        } else {
            $('.btn.show-modal-add-lot').addClass('disabled');
        }
    }


    var saveBatch = function () {
        $('#batchForm').data('bootstrapValidator').resetForm();
        if ($('#batchForm').bootstrapValidator('validate')
            .data('bootstrapValidator').isValid()) {
            showLoading();
            batchService.save(formToJson(), $('#campaignId').val())
                .done(function (data) {
                    if (data.success) {
                        $('#batchId').val(data.item.id);
                        $('.lot-batch').remove();
                        showLotsAssociated();
                        //renderComboLots();
                        blockHybridCombo();
                        showSuccess(data.message);
                    } else {
                        showError(data.message);
                    }
                });
        }
    }

    var deleteBatch = function () {
        showLoading();
        var data = $('#toDelete').data('id').toString();
        batchService.remove(data)
            .done(function (data) {
                if (data.success) {
                    showSuccess(data.message);
                    $('#batchGrid').find('tr[data-id="' + $('#toDelete').data('id') + '"]').remove();
                    blockHybridCombo();
                    renderComboLots();
                } else {
                    showError(data.message);
                }
            });
    }

    var formToJson = function () {
        var batch = new Object();

        batch.id = $('#batchId').val();
        batch.name = $('#batchName').val();
        batch.campaignId = $('#campaignId').val();
        batch.campaignName = '';
        batch.hybridId = $('#comboHybrid').find(':selected').val();
        batch.hybridName = '';
        batch.kgDS = $('#batchKgDS').val();
        batch.kgFNG = $('#batchKgFNG').val();
        batch.bagProduced = $('#batchBagProduced').val();
        batch.realFngInit = $("#realFngInit").datepicker("getDate");
        batch.realFngEnd = $("#realFngEnd").datepicker("getDate");

        batch.totalKgCullTower = $('#totalKgCullTower').val();

        batch.lotBatches = [];

        i = 0;
        $('#lotAssociatedTable').find('.lot-batch').each(function () {
            var lotBatch = new Object();
            lotBatch.lot = new Object();
            lotBatch.lot.id = $(this).data('id');
            lotBatch.lot.lotCode = $(this).find('.lot-code').find('button').html();
            lotBatch.isDeleted = $(this).hasClass('deleted-text');
            lotBatch.kgDSLotAssigned = $(this).find('.lot-batch-kg-ds-lot-assigned').html();
            lotBatch.kgFNGLotAssigned = $(this).find('.lot-batch-kg-fng-lot-assigned').html();
            lotBatch.bagLotAssigned = $(this).find('.lot-batch-bag-lot-assigned').html();
            lotBatch.kgCullTower = $(this).find('.lot-batch-kg-cull-tower').html();
            lotBatch.kgDSBatchLast = $(this).find('.lot-batch-kg-ds-last').html();
            batch.lotBatches[i] = lotBatch;
            i++;
        });

        return JSON.stringify(batch);
    }

    var renderModal = function () {
        renderComboLots(function () {
            $('#comboLots').prop('disabled', false);
            $('#comboLots').find(':selected').prop('selected', false);
            calculateKgDs();
        });
    }

    var init = function () {

        $("#realFngInit").datepicker({dateFormat: datePickerPattern});
        $("#realFngEnd").datepicker({dateFormat: datePickerPattern});
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // EVENTS
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////
        $('#comboHybrid').find('[value="' + $('#batchHybrid').data('id') + '"]').prop('selected', true);

        $('.btn.save').on({'click': saveBatch});

        //Add Lot button to AddLot Modal Dialog
        $('.btn.addLot').on({'click': addLot});

        //Ok button of the Delete Modal Dialog batch, inside the Batch List
        $('.btn.delete.ok').on({'click': deleteBatch});

        //Hybrid of the Details Batch
        $('#comboHybrid').on({ 'change': renderComboLots});

        //event to button delete of batch list
        $('.btn.to-delete').on({
            click: function () {
                $('#toDelete').data('id', $(this).data('id'));
            }
        });

        $('.btn.batch-detail').on({
            click: function () {
                $('#formBatch').attr('action', url + "/campaign/batch/detail/");
                var batchid = $(this).data("batchid");
                $("#batchId").val(batchid);
                $('#formBatch').submit();
            }
        });

        $('.btn.new-batch').on({
            click: function () {
                $('#formBatch').attr('action', url + "/campaign/batch/detail");
                $("#batchId").val(0);
                $('#formBatch').submit();
            }
        });

        $('.btn.show-modal-add-lot').on({ 'click': renderModal})

        $('.btn.batch-lot-detail').on("click", function () {
                var lotid = $(this).data("lotid");
                $("#associateLotForm").find('input#idLot').val(lotid);
                $("#associateLotForm").find('input#optionMenu').val("/lot/detail/");

                $('#associateLotForm').attr('action', url + "/lot/detail/");

                $('#associateLotForm').submit();
            }
        );

        $('.btn.batch.back').on({
            click: function () {
                var campaignid = $(this).data("id");
                $("#formBatch").find('input#campaignId').val(campaignid);
                $('#formBatch').val("/campaign/batch/");
                $('#formBatch').attr('action', url + "/campaign/batch/");
                $('#formBatch').submit();
            }
        });

//        showLotsAssociated();
        //renderComboLots();
        renderButtons();
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    batch.init();
});