BatchService = function(){

}

var batchUrl = url + "/campaign";

/**
 * Call the REST Partidas Service.
 * @param method
 * @param data
 * @param id
 * @returns {*}
 */
BatchService.prototype.callService = function(method, data, campaignId, id){
    return $.ajax({
        url: batchUrl + '/batch/delete',
        type: method,
        dataType: 'json',
        contentType: 'application/json',
        data: data
    });
}

/**
 * Find Lots Associateds to batch
 * @param id
 */
BatchService.prototype.findLotsAssociated = function (campaignId,batchId) {
    return $.ajax({
        url: batchUrl + '/batch/' + batchId + '/lots',
        type: 'GET',
        dataType: 'json',
        contentType: 'application/json'
    });
}

/**
 * CRUD Operations
 */

/**
 * Save a Batch
 */
BatchService.prototype.save = function(batch, campaignId){
    return $.ajax({
        url: batchUrl + '/batch/detail',
        type: 'POST',
        dataType: 'json',
        contentType: 'application/json',
        data: batch
    });

}

/**
 * Add Lot to Batch
 */
BatchService.prototype.addLot = function(data, campaignId){
    return $.ajax({
        url: batchUrl + '/' + campaignId + '/batch/addLot',
        type: 'POST',
        dataType: 'json',
        contentType: 'application/json',
        data: data
    });
}

/**
 * Update a Batch
 */
BatchService.prototype.update = function(data, campaignId){
    return this.callService('PUT',data, campaignId, '');
}

/**
 * Delete a batch
 * @returns {*}
 */
BatchService.prototype.remove = function(data){
    return this.callService('POST', data,'','');
}

/**
 * Find all Batch (partidas)
 * @type {BatchService}
 */
BatchService.prototype.findAll = function(campaignId){
    return this.callService('GET', {}, campaignId, '');
}

