$(document).ready(function () {
    var regexp = /^[a-z0-9\s\ñ\Ñ\$\/\\\u00e1\u00e9\u00ed\u00f3\u00fa\u00c1\u00c9\u00cd\u00d3\u00da\u00f1\u00d1\u00FC\u00DC\,\.\-\_]+$/i;

    $('#batchForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            comboHybrid: {
                validators: {
                    notEmpty: {
                        message: 'Debe Seleccionar un Híbrido.'
                    }
                }
            },
            batchName: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: 'El Nombre de la partida contiene caracteres inválidos.'
                    },
                    notEmpty: {
                        message: 'El Nombre de la partida es obligatorio.'
                    }
                }
            },
            batchKgFNG: {
                validators: {
                    notEmpty: {
                        message: 'Debe Ingresar Kg FNG.'
                    },
                    numeric: {
                        message: 'Solo puede ingresarse números.'
                    },
                    callback: {
                        message: 'Debe ser Mayor a 0 y kg ds mayor a kg fng',
                        callback: function (value, validator) {
                            var kgDs = parseFloat($("#batchKgDS").val());

                            return  parseFloat(value) > 0 && kgDs > parseFloat(value);
                        }
                    }
                }
            },
            realFngInit: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        callback: function (value, validator) {
                            var dateField = getDateOrNull(value);
                            if (dateField == null) {
                                return false;
                            }
                            return true;
                        }
                    }
                }
            },
            realFngEnd: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        callback: function (value, validator) {
                            var dateField = getDateOrNull(value);
                            if (dateField == null) {
                                return false;
                            }
                            return true;
                        }
                    }
                }
            },
            batchBagProduced: {
                validators: {
                    notEmpty: {
                        message: 'Debe Ingresar Bolsas generadas.'
                    },
                    numeric: {
                        message: 'Solo puede ingresarse números.'
                    },
                    callback: {
                        message: 'Debe ser Mayor a 0',
                        callback: function (value, validator) {
                            return parseFloat(value) > 0;
                        }
                    }
                }
            },
            totalKgCullTower: {
                validators: {
                    notEmpty: {
                        message: 'Debe Ingresar Kg. Cull Torre.'
                    },
                    numeric: {
                        message: 'Solo puede ingresarse números.'
                    },
                    callback: {
                        message: 'Debe ser Mayor o Igual a 0',
                        callback: function (value, validator) {
                            return parseFloat(value) >= 0;
                        }
                    }
                }
            }
        }
    });

    $('#addLotForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            lotKgDsAssigned: {
                validators: {
                    notEmpty: {
                        message: 'Debe Ingresar los Kg Ds.'
                    },
                    numeric: {
                        message: 'Solo puede ingresarse números.'
                    },
                    callback: {
                        message: 'Debe ser Mayor a 0',
                        callback: function (value, validator) {
                            return parseFloat(value) > 0;
                        }
                    }
                }
            },
            kgCullTower: {
                validators: {
                    notEmpty: {
                        message: 'Debe Ingresar los Kg Cull Torre.'
                    },
                    numeric: {
                        message: 'Solo puede ingresarse números.'
                    },
                    callback: {
                        message: 'Debe ser Mayor o Igual a 0 y no exceder el total del kg cull torre permitidos',
                        callback: function (value, validator) {
                            var kgCullTower = parseFloat(value);
                            var kgCullTowerTotal = 0;
                            $('.lot-batch').each(function () {
                                isDeleted = $(this).hasClass('deleted-text');
                                lotId = $(this).data('id');
                                if ((typeof  isDeleted === "undefined") || (!isDeleted)) {
                                    kgCullTowerTotal += parseFloat($(this).find('.lot-batch-kg-cull-tower').html());
                                }
                            });

                            var valor = parseFloat($('#totalKgCullTower').val()) - kgCullTowerTotal;
                            if (kgCullTower >= 0 && kgCullTower <= valor) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                    }
                }
            },
            comboLots: {
                validators: {
                    notEmpty: {
                        message: "Debe Seleccionar un Lote."
                    }
                }
            }
        }
    });
})
;
