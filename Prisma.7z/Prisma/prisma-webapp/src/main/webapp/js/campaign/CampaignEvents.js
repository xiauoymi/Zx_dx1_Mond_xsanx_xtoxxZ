var campaign = (function () {

    var campaignService = new CampaignService();

    /**
     * Show a Successfully Message
     * @param msg
     */
    var showSuccess = function (msg) {
        $(".alert.alert-warning").addClass("hide");
        $("#campaignModal").modal("hide");
        $(".alert.alert-success strong").text(msg);
        $(".alert.alert-success").removeClass("hide");
    }

    var showModalSuccess = function (msg) {
        $(".alert.alert-warning.alert-modal").addClass("hide");
        $(".alert.alert-success.alert-modal strong").text(msg);
        $(".alert.alert-success.alert-modal").removeClass("hide");
    }

    /**
     * Show a Error Message
     * @param msg
     */
    var showError = function (msg) {
        $(".alert.alert-warning").addClass("hide");
        $("#campaignModal").modal("hide");
        $(".alert.alert-danger label").text(msg);
        $(".alert.alert-danger").removeClass("hide");
    }

    var showModalError = function (msg) {
        $(".alert.alert-warning.alert-modal").addClass("hide");
        $(".alert.alert-danger.alert-modal label").text(msg);
        $(".alert.alert-danger.alert-modal").removeClass("hide");
    }

    /**
     * Render all atributes of the campaign.
     * @param campaign
     */
    var renderDetails = function (campaignDTO) {
        $('#campaignId').val(campaignDTO.id);

        $("#comboRegion").find('[value=' + campaignDTO.regionId + ']').prop('selected', true);

        renderComboCountries()
            .done(function (countries) {
                $('#comboCountry').find('[value!=""]').remove();
                $(countries).each(function () {
                    $('#comboCountry').append("<option value='" + this.id + "' >" + this.name + "</option>");
                });
                $("#comboCountry").find('[value=' + campaignDTO.countryId + ']').prop('selected', true);
                $('#campaignForm').bootstrapValidator('resetForm');
                $('#campaignForm').bootstrapValidator('validate');
            });

        $("#comboCrop").find('[value=' + campaignDTO.cropId + ']').prop('selected', true);

        $("#campaignName").val(campaignDTO.name);
        $("#campaignCode").val(campaignDTO.campaignCode);

        $("#campaignPath").val(campaignDTO.filePath);
        $("#campaignObservations").val(campaignDTO.observations);

        $('#campaignReal').prop('checked', campaignDTO.isReal);
        $('#campaignActive').prop('checked', campaignDTO.isActive);

        disableElements(campaignDTO.containsLots);
    }

    var disableElements = function (containsLots) {
        if (containsLots) {
            $("#comboRegion").prop("disabled", true);
            $("#comboCountry").prop("disabled", true);
            $("#comboCrop").prop("disabled", true);
            $("#campaignName").prop("disabled", true);
            $("#campaignCode").prop("disabled", true);
        }
    }


    /**
     * reset all inputs and comboboxes
     */
    var resetInputs = function () {
        $("#comboRegion").find("[value='']").prop('selected', true);
        $("#comboCountry").find("[value='']").prop('selected', true);
        $("#comboCrop").find("[value='']").prop('selected', true);

        $("#campaignName").val("");
        $("#campaignCode").val("");

        $("#campaignPath").val("");
        $("#campaignObservations").val("");

        $('#campaignReal').prop('checked', false);
        $('#campaignActive').prop('checked', true);

        $("#comboRegion").prop("disabled", false);
        $("#comboCountry").prop("disabled", false);
        $("#comboCrop").prop("disabled", false);
        $("#campaignName").prop("disabled", false);
        $("#campaignCode").prop("disabled", false);
    }

    /**
     * Parse Form html to json object (Campaign).
     * @returns {*}
     */
    var formToJson = function () {
        var campaign = new Object();
        campaign.id = $('input#campaignId').val();
        campaign.name = $('input#campaignName').val();
        campaign.campaignCode = $('input#campaignCode').val();

        campaign.regionId = $("#comboRegion").find(":selected").val();

        campaign.countryId = $("#comboCountry").find(":selected").val();

        campaign.cropId = $("#comboCrop").find(":selected").val();

        //    campaign.plants = new Array();

        campaign.filePath = $('input#campaignPath').val();

        campaign.observations = $('input#campaignObservations').val();

        campaign.isActive = $('#campaignActive').prop('checked');
        //campaign.isReal = $('#campaignReal').prop('checked');
        campaign.isReal = true;

        return JSON.stringify(campaign);
    }

    var renderGrid = function (rows, postrender) {
        $('#gridCampaign').find('tbody').html('');

        $.each(rows, function (index, campaign) {
            var state = campaign.isActive ? {
                isActive: 'ACTIVA',
                deletedDisabled: 'disabled',
                updatedDisabled: '',
                buttonActive: 'Desactivar Campaña',
                glyphicon: 'glyphicon-remove'
            } : {
                isActive: 'NO ACTIVA',
                deletedDisabled: '',
                updatedDisabled: 'disabled',
                buttonActive: 'Activar Campaña',
                glyphicon: 'glyphicon-ok'
            };

            var row = '<tr>' +
                '<td>' + campaign.regionCode + '</td>' +
                '<td>' + campaign.countryName + '</td>' +
                '<td>' + campaign.cropName + '</td>' +
                '<td>' + '<button type="submit" class="btn btn-link" data-id="' + campaign.id + '">' + campaign.name + '</button>' + '</td>' +
                '<td>' + campaign.campaignCode + '</td>' +
                '<td>' + state.isActive + '</td>' +
                '<td>' + campaign.observations + '</td>' +
                '<td>' +
                '<div class="btn-toolbar">' +
                '<div class="btn-group">' +
                '<button class="btn btn-default find" title="Actualizar" value="' + campaign.id + '" data-toggle="modal" data-target="#campaignModal" ' + state.updatedDisabled + '><span class="glyphicon glyphicon-pencil"></span></button>' +
                '<button class="btn btn-default delete" title="Borrar" value="' + campaign.id + '" data-toggle="modal" data-target="#deleteConfirmation" ' + state.deletedDisabled + ' ><i class="glyphicon glyphicon-trash"></i></button>' +
                '<button class="btn btn-default change-state" title="' + state.buttonActive + '" value="' + campaign.id + '" data-toggle="modal" data-target="#stateConfirmation" ><i class="glyphicon ' + state.glyphicon + '" ></i></button>' +
                '</div>' +
                '</div>' +
                '</td>' +
                '</tr>';
            $('#gridCampaign').find('tbody').append(row);
        });
        postrender ? postrender() : 0;
    }


    /**
     * Find All Campaigns and render Actions Buttons.
     */
    var findAll = function () {
        $('.alert-warning').removeClass('hide');
        campaignService.findAll().done(function (data) {
            renderGrid(data.rows, renderEvents);
            $('.alert-warning').addClass('hide');
        });
    };

    /**
     * Events to Handle Button Delete. open Modal and render inputs details.
     */
    function renderEvents() {
        $('.btn.find').on({
            click: function () {
                $('.alert').addClass('hide');
                var id = $(this).val();
                resetInputs();

                campaignService.findById(id)
                    .done(function (data) {
                        renderDetails(data.item);
//                        $('#campaignForm').bootstrapValidator('resetForm');
//                        $('#campaignForm').bootstrapValidator('validate');
                    });

                $(".save").addClass("hide");
                $(".update").removeClass("hide");
            }
        });

        $('.btn.delete').on({
            click: function () {
                $('#toDelete').val($(this).val());
            }
        });

        $('.btn.change-state').on({
            click: function () {
                $('#toChangeState').val($(this).val());
            }
        });

        $('.btn.btn-link').on({
            click: function () {
                var id = $(this).data("id");
                $('#idCampaign').val(id);
                $('#formCampaign').submit();
            }
        });
    }

    var renderComboCountries = function () {
        return countryService.findByRegionId($('#comboRegion').find(':selected').val());
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    // Event for all Buttons.
    ////////////////////////////////////////////////////////////////////////////////////////////////

    var init = function () {
        $('.btn').click(function () {
            $('.alert').addClass('hide');
        });

        /**
         * Event for OK button of the Confirmation Modal Dialog to delete campaign.
         */
        $('#okDelete').click(function () {
            $('.alert').addClass('hide');
            $(".alert.alert-warning").removeClass("hide");
            campaignService.remove($('#toDelete').val())
                .done(function (data) {
                    if (data.success) {
                        showSuccess(data.message);
                        campaignElement.erase(data.item);
                    } else {
                        showError(data.message);
                    }
                });
        });


        /**
         * Ok Button to the Confirmation Modal dialog to change state of campaign.
         */
        $('#okChangeState').click(function () {
            $('.alert').addClass('hide');
            $(".alert.alert-warning").removeClass("hide");
            campaignService.changeState($('#toChangeState').val())
                .done(function (data) {
                    if (data.success) {
                        showSuccess(data.message);
                        campaignElement.changeState($('#toChangeState').val());
                        renderEvents();
                    } else {
                        showError(data.message);
                    }
                });
        });

        /**
         * Event of New Button;
         */
        $('.btn.new').click(function () {
            resetInputs();
            $('#campaignForm').bootstrapValidator('resetForm');
            $(".save").removeClass("hide");
            $(".update").addClass("hide");
        });

        /**
         * Event of Save Button
         */
        $('.btn.save').click(function () {
            if ($('#campaignForm').bootstrapValidator('validate')
                .data('bootstrapValidator').isValid()) {
                $(".alert.alert-warning.alert-modal").removeClass("hide");
                campaignService.save(formToJson())
                    .done(function (data) {
                        if (data.success) {
                            showModalSuccess(data.message);
                            campaignElement.save(data.item);
                            renderEvents();
                        } else {
                            showModalError(data.message);
                        }
                    })
            }
        });

        /**
         * Event of find Button for Update Campaign
         */
        $('.btn.update').click(function () {
            if ($('#campaignForm').bootstrapValidator('validate')
                .data('bootstrapValidator').isValid()) {
                $(".alert.alert-warning.alert-modal").removeClass("hide");
                //$("#campaignModal").modal("hide");
                campaignService.update(formToJson())
                    .done(function (data) {
                        if (data.success) {
                            showModalSuccess(data.message);
                            renderDetails(data.item);
                            campaignElement.refresh(data.item);
                        } else {
                            showModalError(data.message);
                        }
                    })
                    .fail(function (data) {
                        showModalError(this.status + " - " + this.statusText);
                    });
            }
        });


        /**
         * Events of button Cancel;
         */
        $('.btn.cancel').click(function () {
            $("#campaignModal").modal("hide");
        });

        /**
         * Nested ComboBoxes
         */
        $('#comboRegion').on({
            change: function () {
                var promise = countryService.findByRegionId($('#comboRegion').find(':selected').val());
                promise.done(function (countries) {
                    $('#comboCountry').find('[value!=""]').remove();
                    $(countries).each(function () {
                        $('#comboCountry').append("<option value='" + this.id + "' >" + this.name + "</option>");
                    });
                });
            }
        });

        $('.btn-primary').off('submit');

        renderEvents();
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    campaign.init();
});



