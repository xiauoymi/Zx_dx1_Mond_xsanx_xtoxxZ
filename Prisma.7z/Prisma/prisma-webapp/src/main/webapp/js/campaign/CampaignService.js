CampaignService = function () {

}

var campaignUrl = url + "/campaign";

/**
 * Call the REST Campaign Service.
 * @param method
 * @param data
 * @param id
 * @returns {*}
 */
CampaignService.prototype.callService = function (method, data, id) {
    return $.ajax({
        url: campaignUrl + "/" + id,
        type: method,
        dataType: 'json',
        contentType: 'application/json',
        data: data
    });
}

CampaignService.prototype.callLotService = function (method, data) {
    return $.ajax({
        url: "/prisma/lot/campaign/",
        type: method,
        dataType: 'json',
        contentType: 'application/json',
        data: data
    });
}

/**
 * CRUD Operations
 */

/**
 * Find a Campaign by Id
 * @param id
 */
CampaignService.prototype.findById = function (id) {
    return this.callService('GET', {}, id);
}

CampaignService.prototype.redirectById = function (data) {
    return this.callLotService('POST', data);
}


/**
 * Save a Campaign
 */
CampaignService.prototype.save = function (data) {
    return this.callService('POST', data, '');

}

/**
 * Update a Campaign
 */
CampaignService.prototype.update = function (data) {
    return this.callService('PUT', data, '');
}

/**
 * Delete a campaign
 * @returns {*}
 */
CampaignService.prototype.remove = function (id) {
    return this.callService('DELETE', {}, id);
}

/**
 * Find all Campaigns
 * @type {CampaignService}
 */
CampaignService.prototype.findAll = function () {
    return this.callService('GET', {}, '');
}

CampaignService.prototype.changeState = function (campaignId) {
    return this.callService('PUT', {}, campaignId)
}

var campaignService = new CampaignService();

