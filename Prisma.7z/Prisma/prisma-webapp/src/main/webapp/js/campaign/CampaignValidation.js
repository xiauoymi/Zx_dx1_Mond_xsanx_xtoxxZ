$(document).ready(function() {
    var regexp = /^[a-z0-9\s\ñ\Ñ\$\/\\\u00e1\u00e9\u00ed\u00f3\u00fa\u00c1\u00c9\u00cd\u00d3\u00da\u00f1\u00d1\u00FC\u00DC\,\.\-\_]+$/i;

    $('#campaignForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            comboRegion: {
                validators: {
                    notEmpty: {
                        message: 'Debe Seleccionar una Región.'
                    }
                }
            },
            comboCountry: {
                validators: {
                    notEmpty: {
                        message: 'Debe Seleccionar un País.'
                    }
                }
            },
            comboCrop: {
                validators: {
                    notEmpty: {
                        message: 'Debe Seleccionar un Cultivo.'
                    }
                }
            },
            campaignName: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: 'El Nombre de la campaña contiene caracteres inválidos.'
                    },
                    notEmpty: {
                        message: 'El Nombre de la campaña es obligatorio.'
                    }
                }
            },
            campaignCode: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: 'El Codigo de la campaña contiene caracteres inválidos.'
                    },
                    notEmpty: {
                        message: 'El Codigo de la campaña es obligatorio.'
                    }
                }
            },
            campaignPath: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: 'La ruta del archivo contiene caracteres inválidos.'
                    },
                    notEmpty: {
                        message: 'La ruta del archivo es obligatorio.'
                    }
                }
            },
            campaignObservations: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: 'Las observaciones contiene caracteres inválidos.'
                    },
                    notEmpty: {
                        message: 'Las observaciones es un campo obligatorio.'
                    }
                }
            }
        }
    });
    $('#campaignForm').bootstrapValidator('validate');
});

