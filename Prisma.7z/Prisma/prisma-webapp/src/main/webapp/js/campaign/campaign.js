var campaignElement = (function () {

    function refresh(campaign) {
        var $campaign = $(".prisma-js-campaign-" + campaign.id);
        $campaign.find(".prisma-js-campaign-region").html(campaign.regionCode);
        $campaign.find(".prisma-js-campaign-country").html(campaign.countryName);
        $campaign.find(".prisma-js-campaign-crop").html(campaign.cropName);
        $campaign.find(".prisma-js-campaign-code").html(campaign.campaignCode);
        if (campaign.isActive) {
            $campaign.find(".prisma-js-campaign-active").html(isActive);
        } else {
            $campaign.find(".prisma-js-campaign-active").html(isNotActive);
        }
        $campaign.find(".prisma-js-campaign-observations").html(campaign.observations);
    }

    function erase(campaign) {
        $campaign = $(".prisma-js-campaign-" + campaign.id);
        $campaign.remove();
    }

    function save(campaign) {
        var active = campaign.isActive ? isActive : isNotActive;
        var changeState = "";
        var edit = "";
        var deleteCampaign = "";

        if (campaign.isActive) {
            edit = '<button class="btn btn-default find" title="Actualizar" value="' + campaign.id + '" data-toggle="modal" data-target="#campaignModal"><span class="glyphicon glyphicon-pencil"></span></button>';
            deleteCampaign = '<button class="btn btn-default delete" title="Borrar" value="' + campaign.id + '" data-toggle="modal" data-target="#deleteConfirmation" disabled><i class="glyphicon glyphicon-trash"></i></button>';
            changeState = '<button class="btn btn-default change-state" value="' + campaign.id + '"' +
                'data-toggle="modal" data-target="#stateConfirmation"data-active="' + !campaign.isActive + '"><i class="glyphicon glyphicon-remove"></i></button>';
        } else {
            edit = '<button class="btn btn-default find" title="Actualizar" value="' + campaign.id + '" data-toggle="modal" data-target="#campaignModal" disabled><span class="glyphicon glyphicon-pencil"></span></button>';
            deleteCampaign = '<button class="btn btn-default delete" title="Borrar" value="' + campaign.id + '" data-toggle="modal" data-target="#deleteConfirmation"><i class="glyphicon glyphicon-trash"></i></button>';
            changeState = '<button class="btn btn-default change-state" value="' + campaign.id + '"' +
                'data-toggle="modal" data-target="#stateConfirmation" data-active="' + !campaign.isActive + '"><i class="glyphicon glyphicon-ok"></i></button>';
        }

        var campaignActions = edit + deleteCampaign + changeState;

        var row = '<tr class="prisma-js-campaign-' + campaign.id + '">' +
            '<td class="prisma-js-campaign-region">' + campaign.regionCode + '</td>' +
            '<td class="prisma-js-campaign-country">' + campaign.countryName + '</td>' +
            '<td class="prisma-js-campaign-crop">' + campaign.cropName + '</td>' +
            '<td >' + '<button type="submit" class="btn btn-link" data-id="' + campaign.id + '">' + campaign.name + '</button>' + '</td>' +
            '<td class="prisma-js-campaign-code">' + campaign.campaignCode + '</td>' +
            '<td class="prisma-js-campaign-active">' + active + '</td>' +
            '<td class="prisma-js-campaign-observations">' + campaign.observations + '</td>' +
            '<td class="prisma-js-campaign-actions">' + campaignActions +
            '</td>' +
            '</tr>';

        $('#gridCampaign').find('tbody').append(row);
    }

    function changeState(campaignId) {
        var changeState = "";
        var edit = "";
        var deleteCampaign = "";
        var $campaign = $(".prisma-js-campaign-" + campaignId);

        var active = $campaign.find(".change-state").data("active");

        if (active) {
            $campaign.find(".prisma-js-campaign-active").html(isNotActive);
            edit = '<button class="btn btn-default find" title="Actualizar" value="' + campaignId + '" data-toggle="modal" data-target="#campaignModal" disabled><span class="glyphicon glyphicon-pencil"></span></button>';
            deleteCampaign = '<button class="btn btn-default delete" title="Borrar" value="' + campaignId + '" data-toggle="modal" data-target="#deleteConfirmation"><i class="glyphicon glyphicon-trash"></i></button>';
            changeState = '<button class="btn btn-default change-state" value="' + campaignId + '"' +
                'data-toggle="modal" data-target="#stateConfirmation" data-active="' + !active + '"><i class="glyphicon glyphicon-ok"></i></button>';
        } else {
            edit = '<button class="btn btn-default find" title="Actualizar" value="' + campaignId + '" data-toggle="modal" data-target="#campaignModal"><span class="glyphicon glyphicon-pencil"></span></button>';
            deleteCampaign = '<button class="btn btn-default delete" title="Borrar" value="' + campaignId + '" data-toggle="modal" data-target="#deleteConfirmation" disabled><i class="glyphicon glyphicon-trash"></i></button>';
            $campaign.find(".prisma-js-campaign-active").html(isActive);
            changeState = '<button class="btn btn-default change-state" value="' + campaignId + '"' +
                'data-toggle="modal" data-target="#stateConfirmation"data-active="' + !active + '"><i class="glyphicon glyphicon-remove"></i></button>';
        }

        var campaignActions = edit + deleteCampaign + changeState;
        $campaign.find(".prisma-js-campaign-actions").html(campaignActions);

    }

    return {
        refresh: refresh,
        erase: erase,
        save: save,
        changeState: changeState
    }
})();


