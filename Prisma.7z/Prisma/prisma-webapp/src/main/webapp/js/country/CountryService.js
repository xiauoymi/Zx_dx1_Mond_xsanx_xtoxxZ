/**
 * Created by BSBUON on 5/28/2014.
 */
function CountryService() {

};

var countryUrl = url + "/country";

CountryService.prototype.findByRegionId = function (id) {
    var region = {};
    region.id = id;

    return $.ajax({
        type: 'POST',
        url: countryUrl + "/region/",
        dataType: 'json',
        data: JSON.stringify(region),
        contentType: 'application/json'
    });
}

var countryService = new CountryService();