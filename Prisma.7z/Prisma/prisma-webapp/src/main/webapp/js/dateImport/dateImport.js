
var dateImport = {

};

dateImport.service = (function () {
    function updateLotFromDateImport() {
        var campaignId = $('#campaignId').val();

        return $.ajax({
            url: url + "/dateImport",
            type: 'POST',
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify(campaignId)
        });
    }

    return {
        updateLotFromDateImport: updateLotFromDateImport
    }
})();

dateImport.ui = (function () {
    function init() {
        $("#updateLotFromDateImport").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmUpdateLotFromDateImport,
            onCancel: cancelUpdateLotFromDateImport});
    }

    function confirmUpdateLotFromDateImport() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-dateImport-loading").removeClass("hide");
        $("#updateLotFromDateImport").confirmation('hide');
        dateImport.service.updateLotFromDateImport().done(doneUpdateLotFromDateImport).fail(failUpdateLotFromDateImport);
    }



    function doneUpdateLotFromDateImport(data) {
        if (data.success == true) {
            renderFileStatistics(data.item);
            renderLotsOmitted(data.item.lotDTOs);
            renderLotsWithOmissions(data.item.lotsWithOmissions);
        } else {
            failImportFile(data.message);
        }
    }

    function renderFileStatistics(statistics) {
        var dateImportFile = $.format.date(statistics.dateProccess, "dd/MM/yyyy hh:mm:ss");
        var pathFile = statistics.pathFile;
        var lotsModified = statistics.imported;
        var lotsOmitted = statistics.omitted;

        var newLotFromDateImport = "<tr><td> " + dateImportFile + "</td><td> " + pathFile + "</td><td>" + lotsModified + "</td><td>" + lotsOmitted + "</td></tr>";
        $("#lotsAdded").append(newLotFromDateImport);

        $(".prisma-js-dateImport-loading").addClass("hide");
        $(".prisma-js-dateImport-result").addClass("hide");
        $("#message").find(".alert-success").removeClass("hide");
    }

    function renderLotsOmitted(lotsOmitted) {
        var lotCode;
        var hybrid;
        var causes;
        var rowLotOmitted;
        var errorDetail;

        $(".prisma-js-dateImport-omitted").addClass("hide");

        for (var i = 0; i < lotsOmitted.length; i++) {
            lotCode = lotsOmitted[i].lotCode != null? lotsOmitted[i].lotCode:'-';
            hybrid = lotsOmitted[i].hybridName != null? lotsOmitted[i].hybridName:'-';
            causes = lotsOmitted[i].causes;
            errorDetail = lotsOmitted[i].errorDetail != null? lotsOmitted[i].errorDetail:'-';
            rowLotOmitted = "<tr><td> " + lotCode + "</td><td>" + hybrid + "</td><td data-localize=\'" + causes + "\'></td><td>" + errorDetail + "</td></tr>";
            $("#lotsOmitted").append(rowLotOmitted);
        }

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function renderLotsWithOmissions(lotsWithOmissions) {
        var lotCode;
        var zoneCode;
        var establishment;
        var hybrid;
        var rowLotOmitted;
        var errorDetail;
        var omissionsDetail;

        $(".prisma-js-dateImport-lot-with-omissions").addClass("hide");


        for (var i = 0; i < lotsWithOmissions.length; i++) {
            var lot = lotsWithOmissions[i];
            var omissions = lot.omittedCells;
            omissionsDetail = "<ul>";
            for(var u=0; u< omissions.length;u++ ){
                omissionsDetail += "<li>"+omissions[u].cellName+"</li>"
            }
            omissionsDetail = omissionsDetail + "</ul>";

            lotCode = lot.lotCode != null? lot.lotCode:'-';
            hybrid = lot.hybridName != null? lot.hybridName:'-';
            errorDetail = lot.lotOmissions;
            rowLotOmitted = "<tr><td> " + lotCode + "</td><td>" + hybrid + "</td><td>" + omissionsDetail + "</td></tr>";
            $("#lotsWithOmissions").append(rowLotOmitted);
        }

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function failUpdateLotFromDateImport() {
        $(".prisma-js-dateImport-loading").addClass("hide");
        $("#updateLotFromDateImport").confirmation('hide');
        $("#message").find(".alert-danger").removeClass("hide");
    }

    function failImportFile(errorThrown) {
        $(".prisma-js-dateImport-loading").addClass("hide");
        $("#updateLotFromDateImport").confirmation('hide');
        if (errorThrown.length > 0) {
            var divErrorMessage = "<span data-localize=\'" + errorThrown + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }


    function cancelUpdateLotFromDateImport() {
        $("#updateLotFromDateImport").confirmation('hide');
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    dateImport.ui.init();

});