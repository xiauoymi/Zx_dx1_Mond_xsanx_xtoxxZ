/**
 * Created by EPESTE on 28/05/2014.
 */
var ditsem = {

};

ditsem.service = (function () {
    function addLotsFromDitsem() {
        var campaignId = $('#campaignId').val();

        return $.ajax({
            url: url + "/ditsem",
            type: 'POST',
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify(campaignId)
        });
    }

    function addLotsFromDitsemManual() {
        var form = new FormData();
        form.append("campaignId", $('#campaignId').val());
        form.append("file", $('#uploadFile').prop("files")[0]);

        return $.ajax({
            url: url + "/ditsem/upload",
            type: 'POST',
            processData: false,
            contentType: false,
            data: form
        });
    }

    return {
        addLotsFromDitsem: addLotsFromDitsem,
        refreshManualLots: addLotsFromDitsemManual
    }
})();

ditsem.ui = (function () {
    function init() {
        $("#addLotFromDitsem").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmAddLotsFromDitsem,
            onCancel: cancelAddLotsFromDitsem});
    }

    function confirmAddLotsFromDitsem() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-ditsem-loading").removeClass("hide");
        $("#addLotFromDitsem").confirmation('hide');
        ditsem.service.addLotsFromDitsem().done(doneAddLotsFromDitsem).fail(failAddLotsFromDitsem);
    }

    function confirmManualImport() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-ditsem-loading").removeClass("hide");
        $("#addLotFromDitsemManual").confirmation('hide');
        ditsem.service.refreshManualLots().done(doneAddLotsFromDitsem).fail(failAddLotsFromDitsem);
    }

    function doneAddLotsFromDitsem(data) {
        if (data.success == true) {
            renderFileStatistics(data.item);
            renderLotsOmitted(data.item.lotDTOs);
            renderLotsWithOmissions(data.item.lotsWithOmissions);
        } else {
            failImportFile(data.message);
        }
    }

    function renderFileStatistics(statistics) {
        var dateImportFile = $.format.date(statistics.dateProccess, "dd/MM/yyyy hh:mm:ss");
        var pathFile = statistics.pathFile;
        var lotsModified = statistics.imported;
        var lotsOmitted = statistics.omitted;

        var newLotFromDitsem = "<tr><td> " + dateImportFile + "</td><td> " + pathFile + "</td><td>" + lotsModified + "</td><td>" + lotsOmitted + "</td></tr>";
        $("#lotsAdded").append(newLotFromDitsem);

        $(".prisma-js-ditsem-loading").addClass("hide");
        $(".prisma-js-ditsem-result").addClass("hide");
        $("#message").find(".alert-success").removeClass("hide");
    }

    function renderLotsOmitted(lotsOmitted) {
        var lotCode;
        var zoneCode;
        var establishment;
        var hybrid;
        var causes;
        var rowLotOmitted;
        var errorDetail;

        $(".prisma-js-ditsem-omitted").addClass("hide");

        for (var i = 0; i < lotsOmitted.length; i++) {
            lotCode = lotsOmitted[i].lotCode != null ? lotsOmitted[i].lotCode : '-';
            zoneCode = lotsOmitted[i].zoneCode != null ? lotsOmitted[i].zoneCode : '-';
            establishment = lotsOmitted[i].establishmentName != null ? lotsOmitted[i].establishmentName : '-';
            hybrid = lotsOmitted[i].hybridName != null ? lotsOmitted[i].hybridName : '-';
            causes = lotsOmitted[i].causes;
            errorDetail = lotsOmitted[i].errorDetail != null ? lotsOmitted[i].errorDetail : '-';
            ;
            rowLotOmitted = "<tr><td> " + lotCode + "</td><td> " + zoneCode + "</td><td>" + establishment + "</td><td>" + hybrid + "</td><td data-localize=\'" + causes + "\'></td><td>" + errorDetail + "</td></tr>";
            $("#lotsOmitted").append(rowLotOmitted);
        }

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function renderLotsWithOmissions(lotsWithOmissions) {
        var lotCode;
        var zoneCode;
        var establishment;
        var hybrid;
        var rowLotOmitted;
        var errorDetail;
        var omissionsDetail;

        $(".prisma-js-ditsem-lot-with-omissions").addClass("hide");


        for (var i = 0; i < lotsWithOmissions.length; i++) {
            var lot = lotsWithOmissions[i];
            var omissions = lot.omittedCells;
            omissionsDetail = "<ul>";
            for (var u = 0; u < omissions.length; u++) {
                omissionsDetail = omissionsDetail.concat("<li>" + omissions[u].cellName + "</li>");
            }
            omissionsDetail = omissionsDetail + "</ul>";

            lotCode = lot.lotCode != null ? lot.lotCode : '-';
            zoneCode = lot.zoneCode != null ? lot.zoneCode : '-';
            establishment = lot.establishmentName != null ? lot.establishmentName : '-';
            hybrid = lot.hybridName != null ? lot.hybridName : '-';
            errorDetail = lot.lotOmissions;
            rowLotOmitted = "<tr><td> " + lotCode + "</td><td> " + zoneCode + "</td><td>" + establishment + "</td><td>" + hybrid + "</td><td>" + omissionsDetail + "</td></tr>";
            $("#lotsWithOmissions").append(rowLotOmitted);
        }

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function failAddLotsFromDitsem() {
        $(".prisma-js-ditsem-loading").addClass("hide");
        $("#addLotFromDitsem").confirmation('hide');
        $("#message").find(".alert-danger").removeClass("hide");
    }

    function failImportFile(errorThrown) {
        $(".prisma-js-ditsem-loading").addClass("hide");
        $("#addLotFromDitsem").confirmation('hide');
        if (errorThrown.length > 0) {
            var divErrorMessage = "<span data-localize=\'" + errorThrown + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }


    function cancelAddLotsFromDitsem() {
        $("#addLotFromDitsem").confirmation('hide');
        $("#addLotFromDitsemManual").confirmation('hide');
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    ditsem.ui.init();

});