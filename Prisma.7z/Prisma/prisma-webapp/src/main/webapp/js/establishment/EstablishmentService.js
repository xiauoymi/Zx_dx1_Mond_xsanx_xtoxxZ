EstablishmentService = function(){

}

var establishmentUrl = url + "/establishment" ;

/**
 * Call the REST Campaign Service.
 * @param method
 * @param data
 * @param id
 * @returns {*}
 */
EstablishmentService.prototype.callService = function(method, data, id){
    return $.ajax({
        url: establishmentUrl + "/" + id,
        type: method,
        dataType: 'json',
        contentType: 'application/json',
        data: data
    });
}


EstablishmentService.prototype.findAll = function(){
    return this.callService('GET', {}, '');
}

EstablishmentService.prototype.findAllZones = function(id){
    return this.callService('POST', {}, 'zones');
}

var establishmentService = new EstablishmentService();
