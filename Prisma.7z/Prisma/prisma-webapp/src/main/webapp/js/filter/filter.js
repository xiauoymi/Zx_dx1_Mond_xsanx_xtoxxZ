var filter = (function () {

    var FILTER_TYPE = {"TEXT": 1, "NUMBER": 2, "DATE": 3, "ZONE": 4, "HARVESTED": 5};

    function addNewFilterInFilterList() {
        var newItem = $(".prisma-js-filter:first").html();
        $(".prisma-js-filter-list tbody").append('<tr class="prisma-js-filter">' + newItem + '</tr>');
        $(".prisma-js-filter:last option:first").attr("selected", true);
        $(".prisma-js-filter:last").find(".prisma-js-filter-value").html('<input type="text" class="form-control" style="width: 100%"/>');
        $(".prisma-js-delete-filter:last").show();
    }

    function setFieldAsDate(typeField, filterToProcess) {
        if (typeField === FILTER_TYPE.DATE) {
            var $input = $(filterToProcess).find(".prisma-js-filter-value input");
            if ($input.val() !== "") {
                $input.val(getDateForFilter($input.val()));
            }
            $input.datepicker({dateFormat: datePickerPattern});
        }
    }

    function setFieldAsZoneSelect(typeField, filterToProcess) {
        zone.createInputFilter(filterToProcess, typeField);
    }

    function setFieldAsHarvested(typeField, filterToProcess) {
        harvested.createInputFilter(filterToProcess, typeField);
    }

    function updateTypesFiltersWhenLoad() {
        var $filterList = $(".prisma-js-filter");
        $.each($filterList, function (index, filterToProcess) {
            var typeField = $(filterToProcess).find(".prisma-js-filter-field select option:selected").data("typefield");
            setFieldAsDate(typeField, filterToProcess);
            setFieldAsZoneSelect(typeField, filterToProcess);
            setFieldAsHarvested(typeField, filterToProcess);
        });
    }


    function getFilterList() {
        var $filterList = $(".prisma-js-filter");
        var list = [];
        $.each($filterList, function (index, filterToProcess) {
            var filter = {};
            var lotField = $(filterToProcess).find(".prisma-js-filter-field select option:selected").data("id");
            if (lotField !== undefined) {
                filter.field = $(filterToProcess).find(".prisma-js-filter-field select").val();
                filter.value = getValueOfFilterOption(filterToProcess);
                filter.lotField = lotField;
                filter.typeField = $(filterToProcess).find(".prisma-js-filter-field select option:selected").data("typefield");
                list.push(filter);
            }
        });

        return list;
    }

    function save() {
        $(".prisma-button.prisma-js-save-filter").attr("disabled", false);
        var $filterList = $(".prisma-js-filter");
        var filter = {};
        filter.name = $(".prisma-js-new-filter-name").val();
        filter.description = $(".prisma-js-new-filter-description").val();
        var list = [];

        $.each($filterList, function (index, filterToProcess) {
            var filter = getDataFromFilterToSave(filterToProcess);
            if (filter != null) {
                list.push(filter);
            }
        });

        filter.filterList = list;
        return service.service("/filter/user/new", "POST", filter);
    }

    function listByUser() {
        return service.service("/filter/user/", "POST", "");
    }

    function renderListByUser() {
        loading.show();

        filter.listByUser()
            .done(function (data) {
                var $listByUser = $(".prisma-js-list-filter-by-user tbody");
                $listByUser.empty();
                $.each(data.rows, function (index, value) {
                    var descriptionFilter = value.description == null ? "" : value.description;
                    var $trFilter = '<tr class="prisma-js-filter-id-' + value.id + '"><td>' + value.name + '</td><td>' + descriptionFilter + '</td>' +
                        '<td><a class="prisma-js-filter-select btn" data-id="' + value.id + '"><i class="fa fa-arrow-circle-o-up"></i></a>' +
                        '<a class="btn prisma-js-filter-trash" data-id="' + value.id + '"><i class="fa fa-trash"></i></a></td></tr>';
                    $listByUser.append($trFilter);
                });
                $(".prisma-js-filter-select").on("click", selectFilter);
                $(".prisma-js-filter-trash").on("click", trashFilter);
            })
            .complete(function () {
                loading.hide();
            });
    }

    function trashFilter() {
        var filterId = $(this).data("id");
        loading.show();
        message.hideMessages();

        var filter = {};
        filter.id = filterId;

        service.service("/filter", "DELETE", filter)
            .done(function (data) {
                if (data.success) {
                    $(".prisma-js-filter-id-" + data.item.id).remove();
                    message.showSuccess(data.message);
                } else {
                    message.showError(data.message);
                }
            })
            .complete(function () {
                loading.hide();
            });
    }

    function selectFilter() {
        var filterId = $(this).data("id");
        loading.show();
        listByUserAndId(filterId)
            .done(function (data) {
                renderFilterSelected(data.rows);
                $(".prisma-js-delete-filter").on("click", lot.filter.deleteNewFilter);
                $("#listFilterModal").modal('hide');
                updateTypesFiltersWhenLoad();
            })
            .complete(function () {
                loading.hide();
            });
    }

    function renderFilterSelected(list) {
        cleanFilterList();

        var filterOption = $(".prisma-js-filter:first").clone();
        var filterList = $(".prisma-js-filter-list tbody").find(".prisma-js-filter");

        for (var i = 0; i < filterList.length; i++) {
            filterList[i].remove();
        }

        $.each(list, function (index, element) {
            if (index === 0) {
                $(".prisma-js-filter-list tbody").append('<tr class="prisma-js-filter">' + filterOption.html() + '</tr>');
            } else {
                $(".prisma-js-filter-list tbody").append('<tr class="prisma-js-filter">' + filterOption.html() + '</tr>');
                $(".prisma-js-delete-filter:last").show();
            }
            var elementAdd = $(".prisma-js-filter:last");
            elementAdd.find("select option[data-id='" + element.field + "']").prop("selected", true);
            elementAdd.find(".prisma-js-filter-value input").val(element.value);
        });

        $(".prisma-js-add-filter").on("click", lot.filter.addNewFilter);
    }

    function listByUserAndId(id) {
        var filter = {};
        filter.id = id;
        return service.service("/filter", "POST", filter);
    }

    function getValueOfFilterOption(filterOption) {
        var valueOfFilter = "";
        var filter = $(filterOption).find(".prisma-js-filter-field select option:selected");
        var typeField = filter.data("typefield");

        if (typeField === FILTER_TYPE.DATE) {
            valueOfFilter = $(filterOption).find(".prisma-js-filter-value input").val();
            if (valueOfFilter !== ""){
                valueOfFilter = $.format.date(valueOfFilter, "dd/MM/yy");
            }
        }

        if (typeField === FILTER_TYPE.ZONE) {
            var $zoneSelecteds = $(filterOption).find(".prisma-js-filter-value input").find("option:selected");
            for (var i = 0; i < $zoneSelecteds.length; i++) {
                valueOfFilter += $zoneSelecteds[i].text + ",";
            }
            valueOfFilter = valueOfFilter.slice(0, -1);
        }

        if (typeField === FILTER_TYPE.HARVESTED) {
            valueOfFilter = $(filterOption).find(".prisma-js-filter-value input").find("option:selected").val();
        }

        if (typeField !== FILTER_TYPE.DATE && typeField !== FILTER_TYPE.ZONE && typeField !== FILTER_TYPE.HARVESTED) {
            valueOfFilter = $(filterOption).find(".prisma-js-filter-value input").val();
        }

        return valueOfFilter;
    }

    function findLotsWithFilter() {
        var $filterList = $(".prisma-js-filter");
        var countFilter = 0;
        $.each($filterList, function (index, filterToProcess) {
            var valueFilter = getValueOfFilterOption(filterToProcess);
            var filter = $(filterToProcess).find(".prisma-js-filter-field select option:selected");
            var lotField = filter.data("id");
            var typeField = filter.data("typefield");
            if (lotField !== undefined) {
                var hiddenField = document.createElement("input");
                hiddenField.setAttribute("type", "hidden");
                hiddenField.setAttribute("name", "filters[" + countFilter + "].id");
                hiddenField.setAttribute("value", lotField);
                $("#filterForm")[0].appendChild(hiddenField);

                var hiddenField = document.createElement("input");
                hiddenField.setAttribute("type", "hidden");
                hiddenField.setAttribute("name", "filters[" + countFilter + "].value");
                hiddenField.setAttribute("value", valueFilter);
                $("#filterForm")[0].appendChild(hiddenField);

                var hiddenField = document.createElement("input");
                hiddenField.setAttribute("type", "hidden");
                hiddenField.setAttribute("name", "filters[" + countFilter + "].typeField");
                hiddenField.setAttribute("value", typeField);
                $("#filterForm")[0].appendChild(hiddenField);

                countFilter += 1;
            }
        });

        $("#filterForm")[0].submit();
    }

    function remove(filter) {
        var $filter = filter.parents("tr");
        $filter.remove();
    }

    function getDataFromFilterToSave(filter) {
        var filterData = {};
        var optionSelected = $(filter).find(".prisma-js-filter-field select option:selected");
        filterData.field = optionSelected.data("id");
        if (filterData.field !== undefined) {
            filterData.typeField = optionSelected.data("typefield");
            filterData.value = getValueOfFilterOption(filter);
        } else {
            return null;
        }

        return filterData;
    }

    function cleanFilterList() {
        var filterList = $(".prisma-js-filter-list tbody tr").not(".prisma-js-campaign");
        for (var i = 0; i < filterList.length - 1; i++) {
            filterList[i].remove();
        }
        $(".prisma-js-filter:last option").attr("selected", false);
        $(".prisma-js-filter:last option:first").attr("selected", true);
        $(".prisma-js-filter:last").find(".prisma-js-filter-value").html('<input type="text" class="form-control" style="width: 100%"/>');
    }

    return {
        addNewFilterInFilterList: addNewFilterInFilterList,
        getFilterList: getFilterList,
        save: save,
        listByUser: listByUser,
        listByUserAndId: listByUserAndId,
        renderListByUser: renderListByUser,
        findLotsWithFilter: findLotsWithFilter,
        remove: remove,
        updateTypesFiltersWhenLoad: updateTypesFiltersWhenLoad,
        cleanFilterList: cleanFilterList
    }
})();