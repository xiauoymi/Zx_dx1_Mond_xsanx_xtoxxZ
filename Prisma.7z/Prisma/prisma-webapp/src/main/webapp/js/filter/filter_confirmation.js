var confirmation = (function(){

    function create() {
        $("#filter").confirmation({
            title: filterMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmationApplyFilter,
            onCancel: cancelApplyFilter});
    }

    function show() {
        $("#filter").confirmation('show');
    }

    function confirmationApplyFilter() {
        filter.findLotsWithFilter();
    }

    function cancelApplyFilter() {
        $("#filter").confirmation('hide');
        $("#filter").confirmation('destroy');
    }

    function hide() {
        $("#filter").confirmation('hide');
        $("#filter").confirmation('destroy');
        filter.findLotsWithFilter();
    }

    return {
        create: create,
        show: show,
        hide: hide
    }
})();