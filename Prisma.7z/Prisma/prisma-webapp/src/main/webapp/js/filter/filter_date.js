var date = (function () {
    function createInputFilter(filterSelected, typeFilterSelected) {
        if (typeFilterSelected !== 3) {
            event.preventDefault();
            return;
        }

        var $input = $(filterSelected).find(".prisma-js-filter-value input");
        $($input).multiselect("destroy");
        $($input).html("");

        $($input).datepicker({dateFormat: datePickerPattern});
    }

    return {
        createInputFilter: createInputFilter
    }

})();
