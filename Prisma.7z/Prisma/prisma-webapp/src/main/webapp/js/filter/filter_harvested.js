var harvested = (function () {
    function createInputFilter(filterSelected, typeFilterSelected) {
        if (typeFilterSelected !== 5) {
            event.preventDefault();
            return;
        }

        var $input = $(filterSelected).find(".prisma-js-filter-value input");

        $($input).multiselect("destroy");
        $($input).html("");

        var optionValues = ["YES", "NO"];

        for (var i = 0; i < optionValues.length; i++) {
            $($input).append("<option  value='" + optionValues[i] + "'></option>");
            $($input).find("option:last").html("<span data-localize='prisma.filter.harvested." + optionValues[i] + "'></span>");
            if ($input.val() === optionValues[i]) {
                $($input).find("option:last").attr("selected", "selected");
            }
        }

        $($input).multiselect({
            buttonWidth: '200px'
        });

        $($input).multiselect("refresh");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    return {
        createInputFilter: createInputFilter
    }

})();
