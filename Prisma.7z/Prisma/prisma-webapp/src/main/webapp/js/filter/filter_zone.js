var zone = (function () {
    function createInputFilter(filterSelected, typeFilterSelected) {
        if (typeFilterSelected !== 4) {
            event.preventDefault();
            return;
        }

        var $input = $(filterSelected).find(".prisma-js-filter-value input");

        renderInputWithZoneMultiselected($input);
    }


    function renderInputWithZoneMultiselected(input) {
        var valuesOfFilter = input.val().split(",");
        establishmentService.findAllZones(parseInt($('#campaignId').val()))
            .done(function (data) {
                $(input).multiselect("destroy");
                $(input).html("");
                if (data.rows !== null) {
                    for (var i = 0; i < data.rows.length; i++) {
                        var zoneCode = data.rows[i].code;
                        $(input).append("<option  value='" + data.rows[i].id + "'>" + data.rows[i].code + "</option>");
                        if ($.inArray(zoneCode, valuesOfFilter) !== -1) {
                            $(input).find("option:last").attr("selected", "selected");
                        }
                    }

                    $(input).attr("multiple", "multiple");

                    $(input).multiselect({
                        enableFiltering: true,
                        buttonWidth: '200px',
                        enableCaseInsensitiveFiltering: true,
                        includeSelectAllOption: true
                    });

                    $(input).multiselect("refresh");
                }

            });
    }

    return {
        createInputFilter: createInputFilter
    }

})();
