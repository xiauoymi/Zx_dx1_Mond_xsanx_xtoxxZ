var validation = (function () {

    var regexp = /^[a-z0-9\s\ñ\Ñ\/\\\u00e1\u00e9\u00ed\u00f3\u00fa\u00c1\u00c9\u00cd\u00d3\u00da\u00f1\u00d1\u00FC\u00DC\,\.\-\_]+$/i;

    function resetNewFilter() {
        $("#newFilterForm").data('bootstrapValidator').resetForm();
    }

    function newFilter() {
        $('#newFilterForm')
            .bootstrapValidator({
                excluded: ':disabled',
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    newFilterName: {
                        validators: {
                            regexp: {
                                regexp: regexp,
                                message: '<span data-localize="prisma.validator.filter.name.regexp"/>'
                            },
                            notEmpty: {
                                message: '<span data-localize="prisma.validator.filter.name.notEmpty"/>'
                            }
                        }
                    }
                }
            });

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function isNewFilterValid() {
        var $newFilterValidator = $('#newFilterForm').bootstrapValidator('validate');
        return $newFilterValidator.data('bootstrapValidator').isValid();
    }

    return {
        resetNewFilter: resetNewFilter,
        newFilter: newFilter,
        isNewFilterValid: isNewFilterValid
    }
})();
