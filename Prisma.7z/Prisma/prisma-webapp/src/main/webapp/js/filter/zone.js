var zone = (function () {

    function filter(zones) {
        var lotTab = $(".prisma-section-tab-detail")[0];
        var $lots = $(lotTab).find(".prisma-lot-list");
        $.each($lots, function (index, element) {
            var zoneLot = $(element).find(".prisma-js-zone").html().trim();
            var indexOf = $.inArray(zoneLot, zones);
            if (indexOf === -1) {
                hideLot(element);
            } else {
                showLot(element);
            }
        });

        lot.util.refreshLotFooter();
    }

    function hideLot(element) {
        var tmp = $(element).attr("class").split("prisma-js-id-")[1];
        var lotId = parseInt(tmp);
        $(".prisma-lot-list.prisma-js-lot-main-id-" + lotId).hide();
        $(".prisma-lot-list.prisma-js-id-" + lotId).hide().removeClass("prisma-js-show");
    }

    function showLot(element) {
        var tmp = $(element).attr("class").split("prisma-js-id-")[1];
        var lotId = parseInt(tmp);
        $(".prisma-lot-list.prisma-js-lot-main-id-" + lotId).show();
        $(".prisma-lot-list.prisma-js-id-" + lotId).show().addClass("prisma-js-show");
    }

    return {
        filter: filter
    }
})();
