var edit = (function () {

    function init() {
        $("#updateForecast").on("click", update);
    }

    function update() {
        var forecastCampaign = {};

        validation.update();

        if (!validation.isValid()) {
            event.preventDefault();
            return;
        }

        forecastCampaign.campaign = $("#campaignId").val();
        forecastCampaign.daysRw = $("#daysRw").val();
        forecastCampaign.daysDs = $("#daysDs").val();

        loading.show();
        message.hideMessages();
        service.service("/forecast", "PUT", forecastCampaign)
            .done(function (data) {
                if (data.success) {
                    message.showSuccess(data.message);
                } else {
                    message.showError(data.message);
                }
            })
            .complete(function () {
                loading.hide();
                validation.reset();
            });
    }

    return {
        init: init
    }
})();

