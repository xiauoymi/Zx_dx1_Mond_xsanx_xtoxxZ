$(document).ready(function () {
    edit.init();
    report.init();
});
