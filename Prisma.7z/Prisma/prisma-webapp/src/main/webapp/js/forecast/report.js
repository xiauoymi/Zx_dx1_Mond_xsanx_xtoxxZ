var report = (function(){

    function init() {
        $("#reportForecast").on("click", generate);
    }

    function generate() {
    }

    return {
        init: init
    }
})();
