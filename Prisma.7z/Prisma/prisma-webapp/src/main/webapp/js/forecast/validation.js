var validation = (function () {

    function reset() {
        $("#forecastForm").data('bootstrapValidator').resetForm();
    }

    function update() {
        $('#forecastForm')
            .bootstrapValidator({
                excluded: ':disabled',
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    daysRw: {
                        validators: {
                            notEmpty: {
                                message: '<span data-localize="prisma.forecast.daysRw"/>'
                            },
                            integer: {
                                message: '<span data-localize="prisma.validator.number.invalidInteger"/>'
                            }
                        }
                    },
                    daysDs: {
                        validators: {
                            notEmpty: {
                                message: '<span data-localize="prisma.forecast.daysDs"/>'
                            },
                            integer: {
                                message: '<span data-localize="prisma.validator.number.invalidInteger"/>'
                            }
                        }
                    }
                }
            });

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function isValid() {
        var $updateValidator = $('#forecastForm').bootstrapValidator('validate');
        return $updateValidator.data('bootstrapValidator').isValid();
    }

    return {
        reset: reset,
        update: update,
        isValid: isValid
    }
})();
