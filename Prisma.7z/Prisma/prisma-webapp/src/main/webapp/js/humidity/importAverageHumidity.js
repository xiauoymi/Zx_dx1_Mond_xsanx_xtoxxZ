var importAverageHumidity = {};

importAverageHumidity.ui = (function () {
    function init() {
        $("#importAverageHumidity").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmImportAverageHumidity,
            onCancel: cancelImportAverageHumidity});
    }

    function confirmImportAverageHumidity() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-importAverageHumidity-loading").removeClass("hide");
        $("#importAverageHumidity").confirmation('hide');
        service.service("/humidity/import/campaign/" + $("#campaignId").val(), "PUT", null).done(doneImportAverageHumidity).fail(failImportAverageHumidity);
    }

    function doneImportAverageHumidity(data) {
        if (data.success) {
            renderStatistics(data.item);
        } else {
            renderStatisticsFailed(data.message);
        }
    }

    function renderStatistics(statitics) {
        var datehumidityRun = $.format.date(statitics.dateProccess, datePattern);
        var pathFilehumidity = statitics.pathFile;
        var lotModified = statitics.modified;
        var lotOmitted = statitics.omitted;

        var rowImportAverageHumidity = "<tr><td style='width: 120px;'> " + datehumidityRun + "</td><td> " + pathFilehumidity + "</td><td>" + lotModified + "</td><td>" + lotOmitted + "</td></tr>";
        $("#importAverageHumidityStatistics").append(rowImportAverageHumidity);

        $(".prisma-js-importAverageHumidity-loading").addClass("hide");
        $("#message").find(".alert-success").removeClass("hide");
    }

    function renderStatisticsFailed(errorCode) {
        $(".prisma-js-importAverageHumidity-loading").addClass("hide");
        $("#importAverageHumidity").confirmation('hide');
        if (errorCode.length > 0) {
            var divErrorMessage = "<div data-localize=\'" + errorCode + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function failImportAverageHumidity(jqXHR, textStatus, errorThrown) {
        $(".prisma-js-importAverageHumidity-loading").addClass("hide");
        $("#importAverageHumidity").confirmation('hide');
        if (errorThrown.length > 0) {
            var divErrorMessage = "<div data-localize=\'" + errorThrown + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });

    }

    function cancelImportAverageHumidity() {
        $("#importAverageHumidity").confirmation('hide');
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    importAverageHumidity.ui.init();

});
