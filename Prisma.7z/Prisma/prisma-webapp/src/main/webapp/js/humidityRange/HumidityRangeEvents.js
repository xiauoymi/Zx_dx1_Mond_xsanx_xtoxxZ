/**
 * Created by PGSETT on 26/06/2014.
 */
$(document).ready(function () {
    /**
     * Show a Successfully Message
     * @param msg
     */
    var showSuccess = function (msg) {
        $(".prisma-humidityRange-message").addClass("hide");
        $(".alert.alert-danger").addClass("hide");
        $("#humidityRangeModal").modal("hide");
        $(".alert.alert-success strong").text(msg);
        $(".alert.alert-success").removeClass("hide");
    }

    /**
     * Show a Error Message
     * @param msg
     */
    var showError = function (msg) {
        $(".prisma-humidityRange-message").addClass("hide");
        $(".alert.alert-success").addClass("hide");
        $("#humidityRangeModal").modal("hide");
        $(".alert.alert-danger").removeClass("hide");
        $(".alert.alert-danger").text(msg);
    }

    /**
     * Render all atributes of the humidityRange.
     * @param humidityRange
     */
    var renderDetails = function (humidityRange) {
        $('#humidityRangeId').val(humidityRange.id);

        $('#hiddenHybridId').val(humidityRange.hybridId);
        $('#hiddenZoneId').val(humidityRange.zoneId);

        $('#comboHybrid option').filter(function () {
            return $(this).val() == humidityRange.hybridId;
        }).prop('selected', true);

        $('#comboZone option').filter(function () {
            return $(this).val() == humidityRange.zoneId;
        }).prop('selected', true);

        $("#humidityMin").val(humidityRange.humidityMin);
        $("#humidityMax").val(humidityRange.humidityMax);
    }

    /**
     * reset all inputs and comboboxes
     */
    var resetInputs = function () {
        $("#comboHybrid option:selected").removeAttr("selected");
        $('#comboZone option:selected').removeAttr("selected");
        $('#comboHybrid').prop('disabled', false);
        $('#comboZone').prop('disabled', false);
        $("#humidityMin").val("");
        $("#humidityMax").val("");
    }

    /**
     * Parse Form html to json object (humidityRange).
     * @returns {*}
     */
    var formToJson = function () {
        var humidityRange = new Object();
        humidityRange.id = $('input#humidityRangeId').val();
        humidityRange.humidityMin = $('input#humidityMin').val();
        humidityRange.humidityMax = $('input#humidityMax').val();
        humidityRange.hybridId = $('#comboHybrid option:selected').val();
        humidityRange.zoneId = $('#comboZone option:selected').val();
        humidityRange.zoneCode = $('#comboZone option:selected').text();
        return JSON.stringify(humidityRange);
    }


    var renderGrid = function (rows) {
        $('#gridHumidityRange').find('tbody').html('');
        $.each(rows, function (index, humidityRange) {
            var row = '<tr   data-hybrid="' + humidityRange.hybridId + '" data-zone="' + humidityRange.zoneId + '">' +
                '<td>' + humidityRange.hybridName + '</td>' +
                '<td>' + humidityRange.zoneCode + '</td>' +
                '<td>' + humidityRange.humidityMin + '</td>' +
                '<td>' + humidityRange.humidityMax + '</td>' +
                '<td>' +
                '<div class="btn-toolbar">' +
                '<div class="btn-group">' +
                '<button class="btn btn-default find" title="Actualizar" value="' + humidityRange.id + '" data-toggle="modal" data-target="#humidityRangeModal" ' + '><span class="glyphicon glyphicon-pencil"></span></button>' +
                '<button class="btn btn-default delete" title="Borrar" value="' + humidityRange.id + '" data-toggle="modal" data-target="#confirmation" ' + '  ><i class="glyphicon glyphicon-trash"></i></button>' +
                '</div>' +
                '</div>' +
                '</td>' +
                '</tr>';
            $('#gridHumidityRange').find('tbody').append(row);
        });
    }

    /**
     * Find All humidityRange and render Actions Buttons.
     */
    var findAll = function () {
        $('.alert-warning').addClass('hide');
        humidityRangeService.findAll().done(function (data) {
            renderGrid(data.rows);
            renderEventsUpdate();
            renderEventsDelete();
            if (data.rows.length == 0) {
                $('.alert-warning').removeClass('hide');
            }
        });
    };

    /**
     * Events to Handle Button Delete. open Modal and render inputs details.
     */
    function renderEventsUpdate() {
        $('.btn.find').on({
            click: function () {
                $('.alert').addClass('hide');
                var id = $(this).val();
                resetInputs();
                $('.alert-warning').addClass('hide');
                humidityRangeService.findById(id)
                    .done(function (data) {
                        renderDetails(data.item);
                        $('#comboHybrid').prop('disabled', true);
                        $('#comboZone').prop('disabled', true);

                        $('#humidityRangeForm').bootstrapValidator('resetForm');
                        $('#humidityRangeForm').bootstrapValidator('validate');
                    });

                $(".save").addClass("hide");
                $(".update").removeClass("hide");
            }
        });
    }

    /***
     * Events to Handle Button Delete. Enables Dialog Confirmation.
     */
    function renderEventsDelete() {
        $('.btn.delete').on({
            click: function () {
                $('#toDelete').val($(this).val());
            }
        });
    }

    /**
     * Event for all the Buttons.
     */
    $('.btn').click(function () {
        $('.alert').addClass('hide');
    });

    /**
     * Event for OK of the Confirmation Modal Dialog.
     */
    $('#okDelete').click(function () {
        $(".alert-warning.prisma-humidityRange-message").addClass("hide");
        humidityRangeService.remove($('#toDelete').val())
            .done(function (data) {
                if (data.success) {
                    showSuccess(data.message);
                    findAll();
                } else {
                    showError(data.message);
                }
            });
    });


    /**
     * Event of New Button;
     */
    $('.btn.new').click(function () {
        resetInputs();
        $('#humidityRangeForm').bootstrapValidator('resetForm');
        $(".save").removeClass("hide");
        $(".update").addClass("hide");
    });

    /**
     * Event of Save Button
     */
    $('.btn.save').click(function () {
        if ($('#humidityRangeForm').bootstrapValidator('validate')
            .data('bootstrapValidator').isValid()) {
            $(".alert-warning.prisma-humidityRange-message").addClass("hide");
            $("#humidityRangeModal").modal("hide");
            humidityRangeService.save(formToJson())
                .done(function (data) {
                    if (data.success) {
                        showSuccess(data.message);
                        findAll();
                    } else {
                        showError(data.message);
                    }
                })
                .fail(function (data) {
                    showError(this.status + " - " + this.statusText);
                });
        }
    });

    /**
     * Event of find Button for Update humidityRange
     */
    $('.btn.update').click(function () {
        $('#humidityRangeForm').bootstrapValidator('resetForm');
        if ($('#humidityRangeForm').bootstrapValidator('validate')
            .data('bootstrapValidator').isValid()) {
            $(".alert-warning.prisma-humidityRange-message").addClass("hide");
            $("#humidityRangeModal").modal("hide");


            humidityRangeService.update(formToJson())
                .done(function (data) {
                    if (data.success) {
                        showSuccess(data.message);
                        findAll();
                    } else {
                        showError(data.message);
                    }
                });
        }
    });

    $('.prisma-filterHumidity-submit').click(
        function () {
            $('.alert-warning.prisma-humidityRange-message').addClass('hide');

            humidityRangeService.findByHybrid(formFilterToJson()).done(function (data) {
                if (data.success) {
                    renderGrid(data.item.humidityRanges);
                    renderEventsUpdate();
                    renderEventsDelete();
                } else {
                    $('.alert-warning.prisma-humidityRange-message').removeClass('hide');
                }
            });
        });

    var formFilterToJson = function () {
        var humidityRangeDTO = new Object();

        humidityRangeDTO.hybridName = $('#hybridName').val();

        return JSON.stringify(humidityRangeDTO);
    }

    /**
     * Events of button Cancel;
     */
    $('.btn.cancel').click(function () {
        $("#humidityRangeModal").modal("hide");
    });

    $('.btn-primary').off('submit');

    findAll();
});



