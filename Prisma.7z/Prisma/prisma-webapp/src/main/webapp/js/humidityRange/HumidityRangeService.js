/**
 * Created by PGSETT on 26/06/2014.
 */
HumidityRangeService = function () {

}

var humidityUrl = url + "/humidityRange";

/**
 * Call the REST HumidityRangeService.
 * @param method
 * @param data
 * @param id
 * @returns {*}
 */
HumidityRangeService.prototype.callService = function (method, data, id) {
    return $.ajax({
        url: humidityUrl + "/" + id,
        type: method,
        dataType: 'json',
        contentType: 'application/json',
        data: data
    });
}


/**
 * CRUD Operations
 */

HumidityRangeService.prototype.findById = function (id) {
    return this.callService('GET', {}, id);
}

/**
 * Find a humidityRange by hybrid
 * @param id
 */
HumidityRangeService.prototype.findByHybrid = function (data) {
    return this.callService('POST', data, "filter");
}

/**
 * Find a humidityRange by zone
 * @param id
 */
HumidityRangeService.prototype.findByZone = function (id) {
    return this.callService('GET', {}, id);
}

/**
 * Save a humidityRange
 */
HumidityRangeService.prototype.save = function (data) {
    return this.callService('POST', data, '');

}

/**
 * Update a humidityRange
 */
HumidityRangeService.prototype.update = function (data) {
    return this.callService('PUT', data, '');
}

/**
 * Delete a humidityRange
 * @returns {*}
 */
HumidityRangeService.prototype.remove = function (id) {
    return this.callService('DELETE', {}, id);
}

/**
 * Find all humidityRanges
 * @type {HumidityRangeService}
 */
HumidityRangeService.prototype.findAll = function () {
    return this.callService('GET', {}, '');
}

var humidityRangeService = new HumidityRangeService();

