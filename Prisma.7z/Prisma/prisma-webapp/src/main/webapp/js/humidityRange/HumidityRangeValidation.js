/**
 * Created by PGSETT on 26/06/2014.
 */
$(document).ready(function () {
    $('#humidityRangeForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            comboHybrid: {
                validators: {
                    notEmpty: {
                        message: 'Debe Seleccionar un Híbrido.'
                    },
                    callback: {
                        message: 'El híbrido y la zona ya existen, por favor ingrese otro híbrido.',
                        callback: function (value, validator) {
                            var tr = $('#gridHumidityRange').find('tr');
                            for (var i = 1; i < tr.length; i++) {
                                var hybrid = $(tr[i]).data("hybrid");
                                var zone = $(tr[i]).data("zone");
                                if ($('#hiddenHybridId').val() == $('#comboHybrid option:selected').val()) {
                                    return true;
                                }
                                if (hybrid == value && zone == $('#comboZone option:selected').val()) {
                                    return false;
                                }
                            }
                            if ($('#comboZone option:selected').val() != 0) {
                                validator.updateStatus("comboZone", "VALID");
                            }
                            return  true;
                        }
                    }
                }
            },
            comboZone: {
                validators: {
                    notEmpty: {
                        message: 'Debe Seleccionar una Zona.'
                    }, callback: {
                        message: 'El híbrido y la zona ya existen, por favor ingrese otra zona.',
                        callback: function (value, validator) {
                            var tr = $('#gridHumidityRange').find('tr');
                            for (var i = 1; i < tr.length; i++) {
                                var hybrid = $(tr[i]).data("hybrid");
                                var zone = $(tr[i]).data("zone");
                                if ($('#hiddenZoneId').val() == $('#comboZone option:selected').val()) {
                                    return true;
                                }
                                if (hybrid == $('#comboHybrid option:selected').val() && zone == value) {
                                    return false;
                                }
                            }

                            if ($('#comboHybrid option:selected').val() != 0) {
                                validator.updateStatus("comboHybrid", "VALID");
                            }
                            return  true;
                        }
                    }
                }
            },
            humidityMin: {
                validators: {
                    notEmpty: {
                        message: 'La humedad minima es requerida'
                    },
                    numeric: {
                        message: 'El valor no es un número.'
                    },
                    callback: {
                        message: 'Debe ser menor que el máximo, mayor que 0 y menor que 100',
                        callback: function (value, validator) {
                            var maxValue = parseFloat($("#humidityMax").val());
                            var valor = parseFloat(value);
                            if (valor >= maxValue) {
                                return false;
                            } else {
                                if (valor >= 0 && valor <= 100) {
                                    return true;
                                } else {
                                    return false;
                                }
                            }

                        }
                    }

                }
            },
            humidityMax: {
                validators: {
                    notEmpty: {
                        message: 'La humedad máxima es requerida'
                    },
                    numeric: {
                        message: 'El valor no es un número.'
                    },
                    callback: {
                        message: 'Debe ser mayor que el mínimo, mayor que 0 y menor que 100',
                        callback: function (value, validator) {
                            var minValue = parseFloat($("#humidityMin").val());
                            var valor = parseFloat(value);
                            if (valor <= minValue) {
                                return false;
                            } else {
                                if (valor >= 0 && valor <= 100) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
    });
    $('#humidityRangeForm').bootstrapValidator('validate');
});