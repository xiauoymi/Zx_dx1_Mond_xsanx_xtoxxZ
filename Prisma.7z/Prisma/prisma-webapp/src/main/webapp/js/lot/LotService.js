LotService = function () {

}

var lotUrl = url + "/lot";


/**
 * Call the REST lot Service.
 * @param method
 * @param data
 * @param id
 * @returns {*}
 */
LotService.prototype.callService = function (method, data, id) {
    return $.ajax({
        url: lotUrl + "/" + id,
        type: method,
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(data),
        timeout: 10000
    });
}

LotService.prototype.service = function (method, url, data) {
    return $.ajax({
        url: url,
        type: method,
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(data)
    });
}


LotService.prototype.callServiceMasive = function (method, data, id) {
    return $.ajax({
        url: lotUrl + "/masive/" + id,
        type: method,
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify(data)
    });
}

/**
 * CRUD Operations
 */

/**
 * Find a lot by Id
 * @param id
 */
LotService.prototype.findById = function (id) {
    return this.callService('GET', {}, id);
}

LotService.prototype.selectedHybrid = function (id) {
    var uri = lotUrl + "/hybrid/";
    return this.service('POST', uri, "");
}

/**
 * Save a lot
 */
LotService.prototype.save = function (data) {
    return this.callService('POST', data, "");

}

/**
 * Delete a lot
 * @returns {*}
 */
LotService.prototype.deleteLot = function (data) {
    return this.callService('DELETE', data, "");
}

/**
 * Update a lot
 */
LotService.prototype.update = function (data, id) {
    return this.callService('PUT', data, id);
}
LotService.prototype.updateAll = function (data, id) {
    return this.callServiceMasive('PUT', data, id);
}

LotService.prototype.updateOperation = function (data, id, operation) {
    var uri = lotUrl + "/" + id + "/" + operation;
    return this.service('PUT', uri, data);
}

LotService.prototype.updateMassiveOperation = function (data, id, operation) {
    var uri = lotUrl + "/masive/" + id + "?operation=" + operation;
    return this.service('PUT', uri, data);
}

LotService.prototype.refreshLotsFromMasterdata = function () {
    var service = this;
    service.callService('POST', null, "")
        .done(function (data) {
            if (data.success) {
                service.showSuccess(data.message);
            } else {
                service.showError(data.message);
            }
        })
        .fail(function (data) {
            service.showError(this.status + " - " + this.statusText);
        });
}

LotService.prototype.modifyLot = function (data) {
    var service = this;
    return service.callService('PUT', data, "");
}

LotService.prototype.findPreviousLots = function (id) {
    var uri = lotUrl + "/previousLots/" + id;
    return this.service('GET', uri, "");
}

LotService.prototype.selectedEstablishment = function (id) {
    var uri =  url+"/tonsToHostReport/campaign/"+id+"/establishment";
    return this.service('GET', uri, "");
}

LotService.prototype.findLotsByHybridAndCampaign = function(hybridId){
    var campaignId = $('#campaignId').val();
    var  ids=[];
    ids.push(hybridId);
    ids.push(campaignId);
    var uri = lotUrl + "/hybrid/campaign/";
    return this.service('POST', uri, ids);
}

LotService.prototype.findAll = function(){
    return $.ajax({
        url: lotUrl + "/",
        type: 'GET',
        dataType: 'json',
        contentType: 'application/json',
        data: {}
    });
}

/***
 * Export to Excel Service
 */
//LotService.prototype.exportToExcel = function () {
//    var uri = lotUrl + "/exportToExcel";
//    return this.service('GET', uri, "");
//}


var lotService = new LotService();


