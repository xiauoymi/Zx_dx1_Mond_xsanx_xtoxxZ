/**
 * Created by PGSETT on 02/06/2014.
 */
$(document).ready(function () {
    var regexp = /^[a-z0-9\s\ñ\Ñ\/\\\u00e1\u00e9\u00ed\u00f3\u00fa\u00c1\u00c9\u00cd\u00d3\u00da\u00f1\u00d1\u00FC\u00DC\,\.\-\_]+$/i;

    $('#lotForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            modifyLotCode: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.modifyLotCode.regexp"/>'
                    },
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.lotForm.modifyLotCode.notEmpty"/>'
                    }
                }
            },
            modifyZoneCode: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.modifyZoneCode.regexp"/>'
                    },
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.lotForm.modifyZoneCode.notEmpty"/>'
                    }
                }
            },
            modifyEstablishmentName: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.modifyEstablishmentName.regexp"/>'
                    },
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.lotForm.modifyEstablishmentName.notEmpty"/>'
                    }
                }
            },
            modifyHybridName: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.modifyHybridName.regexp"/>'
                    },
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.lotForm.modifyHybridName.notEmpty"/>'
                    }
                }
            },
            modifyMegazone:{
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.modifyMegazone.regexp"/>'
                    },
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.lotForm.modifyMegazone.notEmpty"/>'
                    }
                }
            },
            modifyCertification: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.modifyCertification.regexp"/>'
                    }
                }
            },
            hybridTypeName: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.hybridTypeName.regexp"/>'
                    },
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.lotForm.hybridTypeName.notEmpty"/>'
                    }
                }
            },
            modifyExpedient: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.modifyExpedient.regexp"/>'
                    }
                }
            },
            modifyColor: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.modifyColor.regexp"/>'
                    }
                }
            },
            lotFile: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.lotFile.regexp"/>'
                    },
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.lotForm.lotFile.notEmpty"/>'
                    }
                }
            },
            lotSourceLotFile: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.lotForm.lotSourceLotFile.regexp"/>'
                    },
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.lotForm.lotSourceLotFile.notEmpty"/>'
                    }
                }
            },
            lotPlantingWeek: {
                validators: {
                    stringLength: {
                        min: 1,
                        max: 2,
                        message: '<span data-localize="prisma.validator.lotForm.lotPlantingWeek.stringLength"/>'
                    },
                    integer: {
                        message: '<span data-localize="prisma.validator.number.invalidInteger"/>'
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.lotForm.lotPlantingWeek.range"/>',
                        callback: function (value, validator) {
                            return value >= 1 && value <= 52;
                        }
                    }
                }
            },
            lotRegisteredHas: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.number.invalidFloat"/>'
                    }
                }
            },
            lotHarvestableHas: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.lotForm.lotHarvestableHas.notEmpty"/>'
                    },
                    numeric: {
                        message: '<span data-localize="prisma.validator.number.invalidFloat"/>'
                    }
                }
            },
            lotObservation: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }
    });
    $('#lotForm').bootstrapValidator('validate');

    $('#lotMassiveForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            lotMassivePlantingWeek: {
                validators: {

                    stringLength: {
                        min: 1,
                        max: 2,
                        message: '<span data-localize="prisma.validator.lotMassiveForm.lotMassivePlantingWeek.stringLength"/>'
                    },
                    integer: {
                        message: '<span data-localize="prisma.validator.number.invalidInteger"/>'
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.lotMassiveForm.lotMassivePlantingWeek.range"/>',
                        callback: function (value, validator) {
                            return value == "" || (value >= 1 && value <= 52);
                        }
                    }
                }
            },
            lotMasiveRegisteredHas: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.number.invalidFloat"/>'
                    }
                }
            },
            lotMasiveHarvestableHas: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.number.invalidFloat"/>'
                    }
                }
            },
            lotMasiveObservation: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }
    });
    $('#lotMassiveForm').bootstrapValidator('validate');

    $('#targetForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            targetRwToDs: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.targetForm.targetRwToDs.notEmpty"/>'
                    },
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            targetDsToFng: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.targetForm.targetDsToFng.notEmpty"/>'
                    },
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            targetKgBag: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.targetForm.targetKgBag.notEmpty"/>'
                    },
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            targetBagHa: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.targetForm.targetBagHa.notEmpty"/>'
                    },
                    integer: {
                        message: '<span data-localize="prisma.validator.number.invalidInteger"/>'
                    }
                }
            }

        }
    });
    $('#targetForm').bootstrapValidator('validate');

    $('#estimateForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            estimatedKgDsHa: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.estimateForm.estimatedKgDsHa.notEmpty"/>'
                    },
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            obsEstimatedKgDsHa: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }
    });
    $('#estimateForm').bootstrapValidator('validate');

    $('#targetMassiveForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            targetMasiveRwToDs: {
                validators: {

                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            targetMasiveDsToFng: {
                validators: {

                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            targetMasiveKgBag: {
                validators: {

                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            targetMasiveBagHa: {
                validators: {

                    integer: {
                        message: '<span data-localize="prisma.validator.number.invalidInteger"/>'
                    }
                }
            }

        }
    });
    $('#targetMassiveForm').bootstrapValidator('validate');

    $('#estimateMassiveForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            estimatedMasiveKgDsHa: {
                validators: {
                    integer: {
                        message: '<span data-localize="prisma.validator.number.invalidInteger"/>'
                    }
                }
            },
            masiveobsEstimatedKgDsHa: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }
    });
    $('#estimateMassiveForm').bootstrapValidator('validate');

    $('#dateForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            realPlantingDate: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.notEmpty"/>',
                        callback: function (value, validator) {
                            var dateField = getDateOrNull(value);
                            if (dateField == null) {
                                return false;
                            }

                            return true;
                        }
                    }
                }
            },
            flowHarvDays: {
                validators: {
                    integer: {
                        message: '<span data-localize="prisma.validator.number.invalidInteger"/>'
                    },
                    callback: {
                         message: '<span data-localize="prisma.validator.number.greaterThanZero"/>',
                        callback: function (value, validator) {
                            if (value > 0) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                    }
                }
            },
            estimatedFloweringDate: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.dateForm.estimatedFloweringDate.flowDateGreaterThanPlantingDate"/>',
                        callback: function (value, validator) {
                            var lotId = $("#estimatedFloweringDateWorkFlow").data("lotid");
                            var plantingDate = $.trim($(".prisma-js-id-" + lotId).find(".prisma-js-planting-date").html());
                            if (plantingDate !== "") {
                                plantingDate = getDateOrNull(plantingDate);
                            } else {
                                return false;
                            }

                            return compareDates(value, plantingDate);
                        }
                    }
                }
            },
            realFloweringDate: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.dateForm.realFloweringDate.flowDateGreaterThanPlantingDate"/>',
                        callback: function (value, validator) {
                            var lotId = $("#floweringDateWorkFlow").data("lotid");
                            var plantingDate = $.trim($(".prisma-js-id-" + lotId).find(".prisma-js-planting-date").html());
                            if (plantingDate !== "") {
                                plantingDate = getDateOrNull(plantingDate);
                            } else {
                                return false;
                            }

                            return compareDates(value, plantingDate);
                        }
                    }
                }
            },
            realHarvestDate: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.dateForm.realHarvestDate.harvestDateGreaterThanFlowDate"/>',
                        callback: function (value, validator) {
                            var lotId = $("#realHarvestDateWorkFlow").data("lotid");
                            var floweringDate = $.trim($(".prisma-js-id-" + lotId).find(".prisma-js-flowering-date").html());
                            if (floweringDate !== "") {
                                floweringDate = getDateOrNull(floweringDate);
                            } else {
                                return false;
                            }

                            return compareDates(value, floweringDate);
                        }
                    }
                }
            }
        }});

    $('#dateMassiveForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            dateMasivePlantingDate: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.notEmpty"/>',
                        callback: function (value, validator) {
                            var dateForm = null;
                            if (value !== "") {
                                dateForm = getDateOrNull(value);
                            } else {
                                return false;
                            }

                            if (dateForm === null) {
                                return false;
                            }

                            return true;
                        }
                    }
                }
            },
            dateMasiveFlowHarvDays: {
                validators: {
                    integer: {
                        message: '<span data-localize="prisma.validator.number.invalidInteger"/>'
                    },
                    callback: {
                         message: '<span data-localize="prisma.validator.number.greaterThanZero"/>',
                        callback: function (value, validator) {
                            if (value > 0) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                    }
                }
            },
            dateMasiveFloweringDate: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.notEmpty"/>',
                        callback: function (value, validator) {
                            var dateForm = null;
                            if (value !== "") {
                                dateForm = getDateOrNull(value);
                            } else {
                                return false;
                            }

                            if (dateForm === null) {
                                return false;
                            }

                            return true;
                        }
                    }
                }
            },
            dateMasiveEstimateFloweringDate: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.notEmpty"/>',
                        callback: function (value, validator) {
                            var dateForm = null;
                            if (value !== "") {
                                dateForm = getDateOrNull(value);
                            } else {
                                return false;
                            }

                            if (dateForm === null) {
                                return false;
                            }

                            return true;
                        }
                    }
                }
            },
            dateMasiveRealHarvestDate: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.notEmpty"/>',
                        callback: function (value, validator) {
                            var dateForm = null;
                            if (value !== "") {
                                dateForm = getDateOrNull(value);
                            } else {
                                return false;
                            }

                            if (dateForm === null) {
                                return false;
                            }

                            return true;
                        }
                    }
                }
            }
        }});

    $('#harvestForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            harvestKgRwLot: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                         message: '<span data-localize="prisma.validator.number.greaterThanZero"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            if (number > 0) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                    }
                }
            },
            harvestRwToDs: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.harvestForm.harvestRwToDs,range"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            if (number > 0 && number <= 1) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                    }
                }
            },
            obsHarvestRwToDs: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }

        }});

    $('#harvestMassiveForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            harvestMassiveKgRwLot: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                         message: '<span data-localize="prisma.validator.number.greaterThanZero"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            if (number > 0) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                    }
                }
            },
            harvestMassiveRwToDs: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.harvestForm.harvestRwToDs,range"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            if (number > 0 && number <= 1) {
                                return true;
                            } else {
                                return false;
                            }
                        }
                    }
                }
            },
            obsHarvestMassiveRwToDsLot: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }});

    $('#huskingForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            huskingKgDsLot: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                         message: '<span data-localize="prisma.validator.number.greaterThanZero"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            return number > 0;
                        }
                    }
                }
            },

            obsHuskingKgDsLot: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            warehouseUnit: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.huskingForm.warehouseUnit.notEmpty"/>'
                    },
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }});

    $('#huskingMassiveForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            huskingKgDsLotMassive: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                         message: '<span data-localize="prisma.validator.number.greaterThanZero"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            return number > 0;
                        }
                    }
                }
            },

            obsHuskingKgDsLotMassive: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            warehouseUnitMassive: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.huskingForm.warehouseUnit.notEmpty"/>'
                    },
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }});

    $('#qualityForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            qualityDsToFng: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.qualityForm.qualityDsToFng.range"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            return number > 0;
                        }
                    }
                }
            },
            qualityWeightBag: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.qualityForm.qualityWeightBag.notEmpty"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            return number >= 0;
                        }
                    }
                }
            },
            qualityObs: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }});

    $('#qualityForm').bootstrapValidator('validate');

    $('#qualityMassiveForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            dsToFngMassive: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.qualityForm.qualityDsToFng.range"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            return number > 0;
                        }
                    }
                }
            },
            weightBagMassive: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.qualityForm.qualityWeightBag.notEmpty"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            return number >= 0;
                        }
                    }
                }
            },
            observationMassive: {
                validators: {
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }
    });
    $('#qualityMassiveForm').bootstrapValidator('validate');

    $('#businessInfoForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            estimatedFngInit: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        callback: function (value, validator) {
                            var dateField = getDateOrNull(value);
                            if (dateField == null) {
                                return false;
                            }
                            return true;
                        }
                    }
                }
            },
            estimatedFngEnd: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        callback: function (value, validator) {
                            var dateField = getDateOrNull(value);
                            if (dateField == null) {
                                return false;
                            }
                            return true;
                        }
                    }
                }
            },
            obsLine: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.businessInfo.obsLineRequired"/>'
                    },
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            generalObs: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.businessInfo.generalObsRequired"/>'
                    },
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }});

    $('#businessInfoMassiveForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            estimatedFngInitMassive: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        callback: function (value, validator) {
                            var dateField = getDateOrNull(value);
                            if (dateField == null) {
                                return false;
                            }
                            return true;
                        }
                    }
                }
            },
            estimatedFngEndMassive: {
                validators: {
                    date: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        format: datePickerPattern
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.date.invalid"/>',
                        callback: function (value, validator) {
                            var dateField = getDateOrNull(value);
                            if (dateField == null) {
                                return false;
                            }
                            return true;
                        }
                    }
                }
            },
            obsLineMassive: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.businessInfo.obsLineRequired"/>'
                    },
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            generalObsMassive: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.businessInfo.generalObsRequired"/>'
                    },
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }});

    $('#huskingMassiveForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            obsLineMassive: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.huskingMassiveForm.obsLineRequired"/>'
                    },
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            },
            generalObsMassive: {
                validators: {
                    notEmpty: {
                        message: '<span data-localize="prisma.validator.huskingMassiveForm.generalObsRequired"/>'
                    },
                    regexp: {
                        regexp: regexp,
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    }
                }
            }
        }});

    $('#receiveTonsReportForm').bootstrapValidator({
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        live: 'enabled',
        fields: {
            harvestFrom: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.receiveTonsReportForm.harvestFrom.range"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            return number > 0 && number <= 54;
                        }
                    }
                }
            },
            harvestTo: {
                validators: {
                    numeric: {
                        message: '<span data-localize="prisma.validator.regexp"/>'
                    },
                    callback: {
                        message: '<span data-localize="prisma.validator.receiveTonsReportForm.harvestTo.range"/>',
                        callback: function (value, validator) {
                            var number = parseFloat(value);
                            return number > 0 && number <= 54;
                        }
                    }
                }
            }
        }
    });



    $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
});