var loading = (function () {
    function show() {
        $(".alert.alert-warning").removeClass("hide");
    }

    function hide() {
        $(".alert.alert-warning").addClass("hide");
    }

    function hideLotHome() {
        $('#lotHomeModal').modal({
            backdrop: 'static'
        });
        $('#lotHomeModal').modal('show');
    }

    function showLotHome() {
        $('#lotHomeModal').modal('hide');
    }

    return {
        show: show,
        hide: hide,
        showLotHome: showLotHome,
        hideLotHome: hideLotHome
    }
})();
