var lot = {};


