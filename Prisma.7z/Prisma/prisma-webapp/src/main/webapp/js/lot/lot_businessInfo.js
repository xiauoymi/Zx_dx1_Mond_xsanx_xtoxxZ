/**
 * Created by PGSETT on 21/08/2014.
 */
lot.businessInfo = (function () {
    function init() {
        $("#estimatedFngInit").datepicker({dateFormat: datePickerPattern});
        $("#estimatedFngEnd").datepicker({dateFormat: datePickerPattern});
        $("#estimatedFngInitMassive").datepicker({dateFormat: datePickerPattern});
        $("#estimatedFngEndMassive").datepicker({dateFormat: datePickerPattern});

        $(".prisma-js-refresh-businessInfo").on("click", updateBusinessInfo);
        $("#businessInfo").find("#updateMasivo").on("click", function () {
            $("#businessInfoMassiveForm")[0].reset();
        });

        $(".prisma-js-refresh-massive-businessInfo").on("click", updateMassiveBusinessInfo);

    }

    function updateBusinessInfo() {
        var $businessInfoUpdate = $(this);
        var field = $businessInfoUpdate.data("field");
        var operation = $businessInfoUpdate.data("operation");

        updateOperation(operation, field);
    }

    function updateOperation(operation, field) {
        var res = field.split(",");
        var fieldValidList = new Array();

        for (var i = 0; i < res.length; i++) {
            $('#businessInfoForm').data('bootstrapValidator').updateStatus(res[i], 'NOT_VALIDATED').validateField(res[i]);
            var fieldValid = $("#" + res[i]).parents("td").find(".has-success");
            if (fieldValid.length === 1) {
                fieldValidList.push(fieldValid);
            }
        }

        if (fieldValidList.length === res.length) {
            var lotModified = lot.util.formToJson(operation);
            update(lotModified, operation);
        }
    }

    function updateMassiveBusinessInfo() {
        var $businessInfoUpdate = $(this);
        var field = $businessInfoUpdate.data("field");
        var operation = $businessInfoUpdate.data("operation");

        updateMassiveOperation(operation, field);
    }

    function updateMassiveOperation(operation, field) {
        var res = field.split(",");
        var fieldValidList = new Array();
        for (var i = 0; i < res.length; i++) {
            $('#businessInfoMassiveForm').data('bootstrapValidator').updateStatus(res[i], 'NOT_VALIDATED').validateField(res[i]);
            var fieldValid = $("#" + res[i]).parents("td").find(".has-success");
            if (fieldValid.length === 1) {
                fieldValidList.push(fieldValid);
            }
        }

        if (fieldValidList.length === res.length) {
            var lotModified = lot.util.formToJsonMasive(operation);
            updateMassive(lotModified, operation);
        }
    }

    function update(lotModified, operation) {
        var id = $('ul#tabs li.active').attr("id");
        lot.main.showSpinner();
        $("#businessInfoModal").modal("hide");
        lotService.updateOperation(lotModified, id, operation)
            .done(function (data) {
                if (data.success) {
                    lot.main.showSuccess(data.message);
                    lot.util.refreshLotView(data.item);
                } else {
                    lot.main.showError(data.message);
                }
            });
    }

    function updateMassive(lotModified, operation) {
        var id = $('ul#tabs li.active').attr("id");
        lot.main.showSpinner();
        $("#businessInfoMassiveModal").modal("hide");
        lotService.updateMassiveOperation(lotModified, id, operation)
            .done(function (data) {
                if (data.success) {
                    lot.main.showSuccess(data.message);
                    for (var i = 0; i < data.item.lotDTO.length; i++) {
                        lot.util.refreshLotView(data.item.lotDTO[i]);
                    }
                } else {
                    for (var i = 0; i < data.item.lotDTO.length; i++) {
                        lot.util.refreshLotView(data.item.lotDTO[i]);
                    }
                    lot.main.showError(data.message);
                }
            });
    }


    return {
        init: init
    }
})();

