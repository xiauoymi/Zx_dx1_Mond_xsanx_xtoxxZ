$(function () {

    renderDateChart();
    renderRwChart();
    renderDsChart();
    renderBagsChart();

    function renderDateChart() {

        var arr = getHistory("prisma-history-dates", [0, 3, 4, 5, 6]);
        if (arr.length > 0) {
            var y = [];
            var d1 = [];
            var d2 = [];
            var d3 = [];
            var d4 = [];

            for (var i = 0; i < arr.length; i++) {
                y = arr[i];
                var x = y[0].split(' ');
                d1.push([gd(x[0]), gd(y[1])]);
                if (y[2] != "") {
                    d3.push([gd(x[0]), gd(y[2])]);
                }
                d2.push([gd(x[0]), gd(y[3])]);
                if (y[4] != "") {
                    d4.push([gd(x[0]), gd(y[4])]);
                }
            }

            var _datesModification = getDateModification(arr);
            var _maxMinArr = getMaxMinAxisYDateChart();

            $.plot("#placeholder", [
                { label: " Est. Flow.", data: d1},
                { label: " Real Flow.", data: d3},
                { label: " Est. Harv.", data: d2},
                { label: " Real Harv.", data: d4}
            ], {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                grid: {
                    hoverable: true,
                    clickable: true
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%d-%m-%y",
                    ticks: 10,
                    min: ((_datesModification[0]).getTime() - (2 * 24 * 3600 * 1000)),
                    max: ((_datesModification[_datesModification.length - 1]).getTime() + (15 * 24 * 3600 * 1000))

                },
                yaxis: {
                    mode: "time",
                    timeformat: "%d-%m-%y",
                    ticks: 5,
                    min: (((_maxMinArr[0])[0]).getTime() - (5 * 24 * 3600 * 1000)),
                    max: (((_maxMinArr[0])[1]).getTime() + (5 * 24 * 3600 * 1000))
                }

            });

            $("<div id='tooltip'></div>").css({
                position: "absolute",
                display: "none",
                border: "1px solid #fdd",
                padding: "2px",
                "background-color": "#fee",
                opacity: 0.80
            }).appendTo("body");

            $("#placeholder").bind("plothover", function (event, pos, item) {
                if (item) {
                    var x = getDateOrNull(new Date(item.datapoint[0])),
                        y = getDateOrNull(new Date(item.datapoint[1]));

                    $("#tooltip").html("x= " + x + ", y= " + y)
                        .css({top: item.pageY + 5, left: item.pageX + 5})
                        .fadeIn(200);
                } else {
                    $("#tooltip").hide();
                }
            });
        }
    }

    function renderRwChart() {
        var targets = getHistory("prisma-history-target", [0, 5]);
        var harvest = getHistory("prisma-history-harvest", [0, 3]);
        var dateModification = [];
        var d1 = [];
        if (targets.length > 0) {
            d1 = setDataModification(d1, targets, dateModification);
        }

        var d2 = [];
        if (harvest.length > 0) {
            d2 = setDataModification(d2, harvest, dateModification);
        }
        if (harvest.length > 0 || targets.length > 0) {
            var _datesModification = getMaxMinFormArray(dateModification);

            $.plot("#placeholder_tnRw", [
                { label: " Est. Rw.", data: d1},
                { label: " Real Rw.", data: d2}
            ], {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                grid: {
                    hoverable: true,
                    clickable: true
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%d-%m-%y",
                    ticks: d1.length,
                    min: (_datesModification[0])[0],
                    max: (_datesModification[0])[1]
                }
            });

            $("<div id='tooltip'></div>").css({
                position: "absolute",
                display: "none",
                border: "1px solid #fdd",
                padding: "2px",
                "background-color": "#fee",
                opacity: 0.80
            }).appendTo("body");

            $("#placeholder_tnRw").bind("plothover", function (event, pos, item) {
                if (item) {
                    var x = getDateOrNull(new Date(item.datapoint[0])),
                        y = item.datapoint[1];

                    $("#tooltip").html("x= " + x + ", y= " + y)
                        .css({top: item.pageY + 5, left: item.pageX + 5})
                        .fadeIn(200);
                } else {
                    $("#tooltip").hide();
                }
            });
        }
    }


    function renderDsChart() {
        var targets = getHistory("prisma-history-target", [0, 6]);
        var harvest = getHistory("prisma-history-harvest", [0, 2]);
        var estimation = getHistory("prisma-history-estimation", [0, 1]);
        var husking = getHistory("prisma-history-husking", [0, 3]);
        var dateModification = [];

        var d1 = [];
        if (targets.length > 0) {
            d1 = setDataModification(d1, targets, dateModification);
        }

        var d2 = [];
        if (harvest.length > 0) {
            d2 = setDataModification(d2, harvest, dateModification);
        }

        var d3 = [];
        if (estimation.length > 0) {
            d3 = setDataModification(d3, estimation, dateModification);
        }
        var d4 = [];
        if (husking.length > 0) {
            var y = [];
            for (var i = 0; i < husking.length; i++) {
                y = husking[i];
                var x = y[0].split(' ');
                if (y[1] != "") {
                    var valueY = getFloatOrNull(y[1]);
                    if (valueY != null) {
                        valueY = valueY / 1000;
                    }
                    d4.push([gd(x[0]), valueY]);
                }
                if (x[0] != '') {
                    dateModification.push(gd(x[0]));
                }
            }
        }

        var _datesModification = getMaxMinFormArray(dateModification);

        $.plot("#placeholder_ds", [
            { label: " Target. TnDs.", data: d1},
            { label: " Kg. Ds/Ha", data: d2},
            { label: " Harv. TnDs.", data: d3},
            { label: " Husk. TnDs.", data: d4}
        ], {
            series: {
                lines: {
                    show: true
                },
                points: {
                    show: true
                }
            },
            grid: {
                hoverable: true,
                clickable: true
            },
            xaxis: {
                mode: "time",
                timeformat: "%d-%m-%y",
                ticks: d1.length,
                min: (_datesModification[0])[0],
                max: (_datesModification[0])[1]
            }
        });

        $("<div id='tooltip'></div>").css({
            position: "absolute",
            display: "none",
            border: "1px solid #fdd",
            padding: "2px",
            "background-color": "#fee",
            opacity: 0.80
        }).appendTo("body");

        $("#placeholder_ds").bind("plothover", function (event, pos, item) {
            if (item) {
                var x = getDateOrNull(new Date(item.datapoint[0])),
                    y = item.datapoint[1];

                $("#tooltip").html("x= " + x + ", y= " + y)
                    .css({top: item.pageY + 5, left: item.pageX + 5})
                    .fadeIn(200);
            } else {
                $("#tooltip").hide();
            }
        });
    }

    function renderBagsChart() {
        var targets = getHistory("prisma-history-target", [0, 7]);
        var actualBags = getHistory("prisma-history-actual", [0, 7]);
        var dateModification = [];
        var d1 = [];
        if (targets.length > 0) {
            d1 = setDataModification(d1, targets, dateModification);
        }

        var d2 = [];
        if (actualBags.length > 0) {
            d2 = setDataModification(d2, actualBags, dateModification);
        }
        if (targets.length > 0 || actualBags.length > 0) {
            var _datesModification = getMaxMinFormArray(dateModification);

            $.plot("#placeholder_bags", [
                { label: " Target Batch", data: d1},
                { label: " Actual Bag Lot", data: d2}
            ], {
                series: {
                    lines: {
                        show: true
                    },
                    points: {
                        show: true
                    }
                },
                grid: {
                    hoverable: true,
                    clickable: true
                },
                xaxis: {
                    mode: "time",
                    timeformat: "%d-%m-%y",
                    ticks: d1.length,
                    min: (_datesModification[0])[0],
                    max: (_datesModification[0])[1]
                }
            });

            $("<div id='tooltip'></div>").css({
                position: "absolute",
                display: "none",
                border: "1px solid #fdd",
                padding: "2px",
                "background-color": "#fee",
                opacity: 0.80
            }).appendTo("body");

            $("#placeholder_bags").bind("plothover", function (event, pos, item) {
                if (item) {
                    var x = getDateOrNull(new Date(item.datapoint[0])),
                        y = item.datapoint[1];

                    $("#tooltip").html("x= " + x + ", y= " + y)
                        .css({top: item.pageY + 5, left: item.pageX + 5})
                        .fadeIn(200);
                } else {
                    $("#tooltip").hide();
                }
            });
        }
    }

    function setDataModification(d, arr, dateModification) {
        var y = [];
        for (var i = 0; i < arr.length; i++) {
            y = arr[i];
            var x = y[0].split(' ');
            if (y[1] != "") {
                d.push([gd(x[0]), getFloatOrNull(y[1])]);
            }
            if (x[0] != '') {
                dateModification.push(gd(x[0]));
            }
        }
        return d;
    }

    function gd(strValue) {
        return new Date(getDateFromString(strValue)).getTime();
    }

    function getMaxMinAxisYDateChart() {
        var arr = getHistory("prisma-history-dates", [3, 4, 5, 6]);
        var dates = [];
        var data = arr[0];
       // var min = new Date(getDateFromString(data[1]));
        //var max = 0;
        var arrDates = [];
        for (var i = 0; i < arr.length; i++) {
            for (var j = 0; j < arr.length; j++) {
                if (arr[i][j] != '' && arr[i][j] != undefined) {
                    arrDates.push(arr[i][j]);
                }
            }
        }

        var min = new Date(getDateFromString('31/12/2999'));
        var max = new Date(getDateFromString('01/01/1901'));
        for (var i = 0; i < arrDates.length; i++) {
            data = arrDates[i];
            var value = new Date(getDateFromString(data));
            if (value < min) {
                min = value;
            }
            if (value > max) {
                max = value;
            }
        }
        dates.push([min, max]);
        return dates;
    }

    function getMaxMinFormArray(arr) {
        if (arr.length > 0) {
            var dates = [];
            var max = 0;
            var min = arr[0];
            for (var i = 0; i < arr.length; i++) {
                if (arr[i] > max) {
                    max = arr[i];
                }
                if (arr[i] < min) {
                    min = arr[i];
                }
            }
            dates.push([min, max]);
            return dates;
        } else {
            return null;
        }
    }

    function getDateModification(arr) {
        var dates = [];
        var prevData = [];
        for (var i = 0; i < arr.length; i++) {
            data = arr[i];

            var dateModification = data[0].split(' ');
            var date = new Date(getDateFromString(dateModification[0]));
//            var firstDate = new Date(date.getTime() - (1 * 24 * 3600 * 1000));
//            dates.push(firstDate);
            if (i > 0) {
                prevData = arr[i - 1];
                var prevModification = prevData[0].split(' ');
                var prevDate = new Date(getDateFromString(prevModification[0]));

                if (prevDate.getTime() != date.getTime()) {
                    dates.push(date);
                }
            } else {
                dates.push(date);
            }
        }
        return dates.sort();
    }

    function getHistory(tab, keyIndexs) {
        var histories = $("." + tab);
        var data = [];
        var arr = [];
        var historyEntries = $(histories).find(".prisma-lot-history");
        for (var i = 0; i < historyEntries.length; i++) {
            var current = historyEntries[i];
            var currentValues = $(current).find("td");
            var isBlank = true;

            data = [];
            for (var u = 0; u < keyIndexs.length; u++) {
                var keyIndex = keyIndexs[u];
                var currValue = $.trim($(currentValues[keyIndex]).text());
                isBlank = isBlank && (currValue == '');
                if (!isBlank) {
                    data.push(currValue);
                }
            }
            arr.push(data);
        }
        return arr;
    }
});
