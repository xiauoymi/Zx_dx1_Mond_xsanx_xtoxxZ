lot.detail = (function () {
    function init() {

//        selectedHybrid();

        $('.btn.update').on("click", refreshLotDetail);

        $('.btn.updatePrevLot').on("click", refreshPrevLot);

        $('.btn.cancel').on("click", closeModal);

    }

    function selectedHybrid() {
        LotService.prototype.selectedHybrid().done(function (data) {
            if (data.success) {
                fillSelectedHybrid(data);
            } else {
                lot.main.showError(data.message);
            }
        });
    }

    function fillSelectedHybrid(data) {
        var $input = $("#modifyHybridName");
        var $hybridLot = $("#modifyHybridName").data("hybrid-lot");
        for (var i = 0; i < data.rows.length; i++) {
            $input.append("<option data-type=" + data.rows[i].hybridType.name + ">" + data.rows[i].name + "</option>");
            if (data.rows[i].name === $hybridLot) {
                $($input).find("option:last").attr("selected", "selected");
            }
        }

        $("#modifyHybridName").on("change", function () {
            $("#modifyHybridTypeName").val($("#modifyHybridName").find(":selected").data("type"));
        });
    }

    function refreshLotDetail() {
        var isValidLotForm = $('#lotForm').bootstrapValidator('validate').data('bootstrapValidator').isValid();
        var id = $('ul#tabs li.active').attr("id");
        var operation = $(this).data("operation");

        if (isValidLotForm) {
            $("#lotModal").modal("hide");
            $("#targetModal").modal("hide");
            $("#estimateModal").modal("hide");
            lot.main.showSpinner();
            var lotModified = lot.util.formToJson();
            var $selectedRow = $(".prisma-js-lot-main-id-" + lotModified.id)[0];
            var $selectedRowDetail = $(".prisma-js-id-" + lotModified.id)[0];
            var hybridInit = $($selectedRow).find(".prisma-js-lot-main-hybridName").html();
            var megaZoneInit = $($selectedRowDetail).find(".prisma-js-megaZone").html();
            lotModified.isHybridModified = lotModified.hybridName === hybridInit ? false : true;
            lotModified.isMegazoneModified = lotModified.megazone === megaZoneInit ? false : true;

            lotService.updateOperation(lotModified, id, operation)
                .done(function (data) {
                    if (data.success) {
                        lot.main.showSuccess(data.message);
                        lot.util.refreshLotView(data.item);
                    } else {
                        lot.main.showError(data.message);
                    }
                    $('.btn.btn-link.lot').on("click", refreshLotLinkButton);
                });
        }


    };

    function refreshPrevLot() {
        var isValidLotForm = $('#lotForm').bootstrapValidator('validate').data('bootstrapValidator').isValid();
        var id = $('ul#tabs li.active').attr("id");
        var operation = $(this).data("operation");

        if (isValidLotForm) {
            $("#lotModal").modal("hide");
            $("#targetModal").modal("hide");
            $("#estimateModal").modal("hide");
            var lotModified = new Object();
            lotModified.id = $('#lotId').val();
            var lotCodes = [];
            var lots = $("#previousLot option:selected");

            $.each(lots, function (index, value) {
                lotCodes.push(value.value);
            });
            lotModified.previousLot = lotCodes;

            loading.show();
            message.hideMessages();
            lotService.updateOperation(lotModified, id, operation)
                .done(function (data) {
                    if (data.success) {
                        lot.main.showSuccess(data.message);
                        lot.util.refreshLotView(data.item);
                    } else {
                        lot.main.showError(data.message);
                    }
                    $('.btn.btn-link.lot').on("click", refreshLotLinkButton);
                })
                .complete(function () {
                    loading.hide();
                });
        }

    };

    function closeModal() {
        $("#lotModal").modal("hide");
    };

    function refreshLotLinkButton() {
        var id = $(this).data("lotid");
        $('#idLot').val(id);
        $('#formCampaign').attr('action', '/prisma/lot/detail/');
        $('#optionMenu').val("/lot/detail/");
        $('#formCampaign').submit();
    }

    return {
        init: init,
        selectedHybrid: selectedHybrid
    }
})();

