lot.filter = (function () {

    function init() {
        filter.updateTypesFiltersWhenLoad();
        $(".prisma-js-delete-filter").on("click", deleteNewFilter);
        $(".prisma-js-new-filter").on("click", showFiltersSelectedPreviousSave);
        $(".prisma-js-save-filter").on("click", saveFilter);
        $(".prisma-js-list-filter").on("click", showFilterList);
        $(".prisma-js-filter-clean").on("click", cleanFilterList);
        $(".prisma-js-add-filter").on("click", addNewFilterInFilterList);
        $(".prisma-js-new-cancel").on("click", cancelNew);
        $("#filter").on("click", findLotsWithFilter);
        $(".prisma-js-filter-field select").on("change", changeTheOptionFilterThenUpdateTheType);
        $(".prisma-js-filter-value input").on("keypress", pressEnterKeyThenApplyFilter);
    }

    function pressEnterKeyThenApplyFilter(event) {
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if (keycode == '13') {
            findLotsWithFilter();
        }
    }

    function showFiltersSelectedPreviousSave() {
        var filterToSaveList = filter.getFilterList();
        var filterToShow;

        validation.newFilter();
        message.hideMessages();
        $(".prisma-js-new-filter-name").val("");
        $(".prisma-js-new-filter-description").val("");
        $(".prisma-js-filter-to-save tbody").html("");
        for (var i = 0; i < filterToSaveList.length; i++) {
            filterToShow = '<tr><td data-lotfield="' + filterToSaveList[i].lotField + '">' + filterToSaveList[i].field + '</td><td>' + filterToSaveList[i].value + '</td></tr>';
            $(".prisma-js-filter-to-save").append(filterToShow);
        }

        if (filterToSaveList.length === 0) {
            $(".prisma-button.prisma-js-save-filter").attr("disabled", true);
            return;
        }
        $(".prisma-button.prisma-js-save-filter").attr("disabled", false);
    }

    function saveFilter() {
        var isValidFilter = validation.isNewFilterValid();

        if (!isValidFilter) {
            event.preventDefault();
            return;
        }

        message.hideMessages();
        loading.show();
        filter.save()
            .success(function (data) {
                if (data.success) {
                    message.showSuccess(data.message);
                } else {
                    message.showError(data.message);
                }
            }).
            error(function (data) {
                message.showError(data.message);
            })
            .complete(function () {
                loading.hide();
                validation.resetNewFilter();
            });
    }

    function addNewFilterInFilterList() {
        filter.addNewFilterInFilterList();
        $(".prisma-js-add-filter").off("click");
        $(".prisma-js-add-filter").on("click", addNewFilterInFilterList);
        $(".prisma-js-delete-filter").on("click", deleteNewFilter);
        $(".prisma-js-filter-field select").on("change", changeTheOptionFilterThenUpdateTheType);
        $(".prisma-js-filter-value input").on("keypress", pressEnterKeyThenApplyFilter);

        $("#filter").confirmation('destroy');
    }

    function showFilterList() {
        filter.renderListByUser();
    }

    function cleanFilterList() {
        filter.cleanFilterList();
    }

    function deleteNewFilter() {
        var countFilters = $(".prisma-js-filter").length;
        if (countFilters > 1) {
            filter.remove($(this));
        } else {
            confirmation.create();
        }
    }

    function cancelNew() {
        message.hideMessages();
    }

    function findLotsWithFilter() {
        var filterList = filter.getFilterList();
        if (filterList.length === 0) {
            confirmation.create();
            confirmation.show();
        } else {
            confirmation.hide();
        }
    }

    function changeTheOptionFilterThenUpdateTheType() {
        var $filter = $(this).parents("tr");
        var $typeField = $(this).find("option:selected").data("typefield");

        date.createInputFilter($filter, $typeField);
        zone.createInputFilter($filter, $typeField);
        harvested.createInputFilter($filter, $typeField);
        theOptionFilterSelectedIsNotDateOrZoneOrHarvested($filter, $typeField);
    }

    function theOptionFilterSelectedIsNotDateOrZoneOrHarvested(filter, typeField) {
        if (typeField !== 3 && typeField !== 4 && typeField !== 5) {
            filter.find("input").datepicker("destroy");
            filter.find("input").multiselect("destroy");
        }
    }

    return {
        init: init,
        addNewFilter: addNewFilterInFilterList,
        deleteNewFilter: deleteNewFilter
    }
})();

