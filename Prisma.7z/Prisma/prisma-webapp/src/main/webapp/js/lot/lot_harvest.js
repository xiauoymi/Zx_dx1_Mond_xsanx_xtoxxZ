 lot.harvest = (function () {
    function init() {
        $(".prisma-js-refresh-harvest").on("click", updateHarvest);
        $("#harvest").find("#updateMasivo").on("click", function () {
            $("#harvestMassiveForm")[0].reset();
        });

        $(".prisma-js-refresh-massive-harvest").on("click", updateMassiveHarvest);
    }

    function updateHarvest() {
        var $harvestUpdate = $(this);
        var field = $harvestUpdate.data("field");
        var operation = $harvestUpdate.data("operation");
        updateOperation(operation, field);
    }

    function updateOperation(operation, field) {
        $('#harvestForm').data('bootstrapValidator').updateStatus(field, 'NOT_VALIDATED').validateField(field);
        var fieldValid = $("#" + field).parents("td").find(".has-success");

        if (fieldValid.length === 1) {
            var lotModified = lot.util.formToJson(operation);
            update(lotModified, operation);
        }
    }

    function updateMassiveHarvest() {
        var $harvestUpdate = $(this);
        var field = $harvestUpdate.data("field");
        var operation = $harvestUpdate.data("operation");
        updateMassiveOperation(operation, field);
    }

    function updateMassiveOperation(operation, field) {
        $('#harvestMassiveForm').data('bootstrapValidator').updateStatus(field, 'NOT_VALIDATED').validateField(field);
        var fieldValid = $("#" + field).parents("td").find(".has-success");

        if (fieldValid.length === 1) {
            var lotModified = lot.util.formToJsonMasive(operation);
            updateMassive(lotModified, operation);
        }
    }

    function update(lotModified, operation) {
        var id = $('ul#tabs li.active').attr("id");
        lot.main.showSpinner();
        $("#harvestModal").modal("hide");
        lotService.updateOperation(lotModified, id, operation)
            .done(function (data) {
                if (data.success) {
                    lot.main.showSuccess(data.message);
                    lot.util.refreshLotView(data.item);
                } else {
                    lot.main.showError(data.message);
                }
            });
    }

    function updateMassive(lotModified, operation) {
        var id = $('ul#tabs li.active').attr("id");
        lot.main.showSpinner();
        $("#harvestMassiveModal").modal("hide");
        lotService.updateMassiveOperation(lotModified, id, operation)
            .done(function (data) {
                if (data.success) {
                    lot.main.showSuccess(data.message);
                    for (var i = 0; i < data.item.lotDTO.length; i++) {
                        lot.util.refreshLotView(data.item.lotDTO[i]);
                    }
                } else {
                    for (var i = 0; i < data.item.lotDTO.length; i++) {
                        lot.util.refreshLotView(data.item.lotDTO[i]);
                    }
                    lot.main.showError(data.message);
                }
            });
    }


    return {
        init: init
    }
})();

