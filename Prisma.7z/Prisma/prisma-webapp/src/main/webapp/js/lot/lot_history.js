$(document).ready(function () {
    $('.collapse').collapse({
        toggle: true
    });
    clearHistory("prisma-history-lot", [2,3]);
    clearHistory("prisma-history-dates", [1, 2, 3, 4, 5, 6, 7]);
    clearHistory("prisma-history-target", [1, 2, 3, 4, 5,7,8]);
    clearHistory("prisma-history-estimation", [1]);
    /*pre-harvest*/
    clearHistory("prisma-history-harvest", [1, 2, 3, 4, 5]);
    clearHistory("prisma-history-husking", [1, 2, 3, 4, 5]);
    clearHistory("prisma-history-quality", [1, 2, 3, 4, 5, 6, 7]);
    clearHistory("prisma-history-growers-payment", [1, 2, 3, 4, 5]);
    clearHistory("prisma-history-business-info", [1, 2, 3, 4, 5, 6, 7, 8]);
    /*batches*/
    clearHistory("prisma-history-actual", [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]);

    function clearHistory(tab, keyIndexs) {
        var histories = $("." + tab);


        var historyEntries = $(histories).find(".prisma-lot-history");
        for (var i = 0; i < historyEntries.length; i++) {
            var current = historyEntries[i];
            var next = historyEntries[i + 1];

            var currentValues = $(current).find("td");
            var nextValues = $(next).find("td");
            var show = false;
            var isBlank = true;

            for (var u = 0; u < keyIndexs.length; u++) {
                var keyIndex = keyIndexs[u];
                var currValue = $.trim($(currentValues[keyIndex]).text());
                var nextValue = $.trim($(nextValues[keyIndex]).text());

                isBlank = isBlank && (currValue == '');

                var hasChanged = currValue != nextValue;
                if (hasChanged && i + 1 != historyEntries.length) {
                    $(currentValues[keyIndex]).css("color", "red")
                }
                show = show || hasChanged;
            }

            if (!show || isBlank) {
                $(current).hide();
            }
        }
    }
});