$(document).ready(function () {
    lot.main.init();
    lot.detail.init();
    lot.dates.init();
    lot.harvest.init();
    lot.husking.init();
    lot.quality.init();
    lot.businessInfo.init();
    loading.showLotHome();
});



