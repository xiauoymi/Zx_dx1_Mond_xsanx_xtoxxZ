lot.husking = (function () {
    function init() {
        $(".prisma-js-refresh-husking").on("click", updateHusking);
        $("#husking").find("#updateMasivo").on("click", function () {
            $("#huskingMassiveForm")[0].reset();
        });

        $(".prisma-js-refresh-massive-husking").on("click", updateMassiveHusking);
    }

    function updateHusking() {
        var $huskingUpdate = $(this);
        var field = $huskingUpdate.data("field");
        var operation = $huskingUpdate.data("operation");
        updateOperation(operation, field);
    }

    function updateOperation(operation, field) {
        var res = field.split(",");
        var fieldValidList = new Array();
        for (var i = 0; i < res.length; i++) {
            $('#huskingForm').data('bootstrapValidator').updateStatus(res[i], 'NOT_VALIDATED').validateField(res[i]);
            var fieldValid = $("#" + res[i]).parents("td").find(".has-success");
            if (fieldValid.length === 1) {
                fieldValidList.push(fieldValid);
            }
        }

        if (fieldValidList.length === res.length) {
            var lotModified = lot.util.formToJson(operation);
            update(lotModified, operation);
        }
    }

    function updateMassiveHusking() {
        var $huskingUpdate = $(this);
        var field = $huskingUpdate.data("field");
        var operation = $huskingUpdate.data("operation");
        updateMassiveOperation(operation, field);
    }

    function updateMassiveOperation(operation, field) {
        var res = field.split(",");
        var fieldValidList = new Array();
        for (var i = 0; i < res.length; i++) {
            $('#huskingMassiveForm').data('bootstrapValidator').updateStatus(res[i], 'NOT_VALIDATED').validateField(res[i]);
            var fieldValid = $("#" + res[i]).parents("td").find(".has-success");
            if (fieldValid.length === 1) {
                fieldValidList.push(fieldValid);
            }
        }

        if (fieldValidList.length === res.length) {
            var lotModified = lot.util.formToJsonMasive(operation);
            updateMassive(lotModified, operation);
        }
    }

    function update(lotModified, operation) {
        var id = $('ul#tabs li.active').attr("id");
        lot.main.showSpinner();
        $("#huskingModal").modal("hide");
        lotService.updateOperation(lotModified, id, operation)
            .done(function (data) {
                if (data.success) {
                    lot.main.showSuccess(data.message);
                    lot.util.refreshLotView(data.item);
                } else {
                    lot.main.showError(data.message);
                }
            });
    }

    function updateMassive(lotModified, operation) {
        var id = $('ul#tabs li.active').attr("id");
        lot.main.showSpinner();
        $("#huskingMassiveModal").modal("hide");
        lotService.updateMassiveOperation(lotModified, id, operation)
            .done(function (data) {
                if (data.success) {
                    lot.main.showSuccess(data.message);
                    for (var i = 0; i < data.item.lotDTO.length; i++) {
                        lot.util.refreshLotView(data.item.lotDTO[i]);
                    }
                } else {
                    for (var i = 0; i < data.item.lotDTO.length; i++) {
                        lot.util.refreshLotView(data.item.lotDTO[i]);
                    }
                    lot.main.showError(data.message);
                }
            });
    }


    return {
        init: init
    }
})();

