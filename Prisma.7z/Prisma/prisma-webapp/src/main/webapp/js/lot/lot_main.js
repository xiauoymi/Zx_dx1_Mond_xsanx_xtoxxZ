lot.main = (function () {

    function init() {
        $("#zones").multiselect('destroy');
        $("#zones").html("");
        $("#zones").hide();
        $('.btn.find').on("click", initLot);
        $('.btn.findLot').on("click", initTabLot);
        $('.btn.findPrevLot').on("click", initPrevLot);
        $('.btn.formMasivo').on("click", tabSelected);
        $('.btn.updateAll').on("click", updateAll);
        var campaignId = $('#campaignId').val();
        $('.btn.exportToExcel').prop('href', url + "/lot/campaign/" + campaignId + "/exportToExcel.xls");
        $('.btn.exportToPDF').prop('href', url + "/lot/campaign/" + campaignId + "/exportToPDF");

        $("#mainLotTable").find(".prisma-js-lot-main-lot-checkbox").on("click", enabledButtons);

        var lots = $(".prisma-js-lot-main-lot-checkbox");
        $.each(lots, function (index, value) {
            var id = value.value;
            lot.util.renderEstimateColor(id);
        });

        $(".btn.delete").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: function () {
                showSpinner();
                var lotCodes = [];
                var lots = $(".tab-pane.active").find("input:checked");

                $.each(lots, function (index, value) {
                    lotCodes.push(parseInt(value.value));
                });

                lotService.deleteLot(lotCodes)
                    .done(function (data) {
                        if (data.success) {
                            showSuccess(data.message);
                            $.each(lots, function (index, value) {
                                $(".prisma-js-id-" + value.value).remove();
                                $(".prisma-js-lot-main-id-" + value.value).remove();
                            });

                            lot.util.refreshLotFooter();
                        } else {
                            showError(data.message);
                        }
                    });
                $(".delete").confirmation('hide');
                $("#lotModal").modal("hide");
            },
            onCancel: function () {
                $(".delete").confirmation('hide');
            }
        });

        $('#tabs a:last').tab();

        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            $(".tab-pane.active").find(".prisma-js-lot-main-lot-checkbox").on("click", enabledButtons);
            tabSelected();
        });

        $('#accordion').collapse({
            toggle: false
        })

        $('#previousLot').multiselect({
            enableFiltering: true,
            buttonWidth: '200px'
        });

        showModalSpinner();

        $('.btn.btn-link.lot').on("click", refreshLotLinkButton);

        $('.btn.menu').on({
            click: function () {
                var id = $(this).data("id");
                $('#idCampaign').val(id);
                $('#formMenu').submit();
            }
        });

        lot.filter.init();
    }

    function refreshLotLinkButton() {
        var id = $(this).data("lotid");
        $('#idLot').val(id);
        $('#formCampaign').attr('action', '/prisma/lot/detail/');
        $('#optionMenu').val("/lot/detail/");
        $('#formCampaign').submit();
    }

    function renderAllLotsCombo(data) {
        if (data.success) {
            for (var i = 0; i < data.rows.length; i++) {
                $('#previousLot').append("<option value='" + data.rows[i].id + "'>" + data.rows[i].lotCode + "</option>");
            }


            hideModalSpinner();
        } else {
            $('.alert.alert-danger')
                .removeClass('hide')
                .find('strong').html('Error while find All Lots.');
        }
    }

    function renderEstablishmentCombo(data) {
        if (data.success) {

            for (var i = 0; i < data.rows.length; i++) {
                $('#modifyEstablishmentName')
                    .append('<option value="' + data.rows[i].id + '">' + data.rows[i].name + '</option>');
            }
            hideModalSpinner();
        } else {
            $('.alert.alert-danger')
                .removeClass('hide')
                .find('strong').html('Error while find Establishment.');
        }
    }

    function initLot() {
        var id = $(this).val();
        resetInputs();

        $(".save").addClass("hide");
        $(".update").removeClass("hide");
        $(".delete").removeClass("hide");
        $("#lotForm").bootstrapValidator('resetForm', true);
        $("#dateForm").bootstrapValidator('resetForm', true);
        $("#targetForm").bootstrapValidator('resetForm', true);
        $("#estimateForm").bootstrapValidator('resetForm', true);
        $("#lotMasivoModal").bootstrapValidator('resetForm', true);
        $("#dateMassiveModal").bootstrapValidator('resetForm', true);
        $("#targetMasivoModal").bootstrapValidator('resetForm', true);
        $("#estimateMasivoModal").bootstrapValidator('resetForm', true);
        $("#harvestModal").bootstrapValidator('resetForm', true);
        $("#harvestMassiveModal").bootstrapValidator('resetForm', true);
        $("#huskingModal").bootstrapValidator('resetForm', true);
        $("#huskingMassiveModal").bootstrapValidator('resetForm', true);
        $("#businessInfoModal").bootstrapValidator('resetForm', true);
        $("#businessInfoMassiveModal").bootstrapValidator('resetForm', true);

        valideteForm(id);
        renderDetails(id);
    }

    function initPrevLot() {
        var id = $(this).val();

        var lot_m = $(".prisma-js-lot-main-id-" + id);
        var lot_l = $(".prisma-js-id-" + id);

        var lotCode = $.trim(lot_m.find(".prisma-js-lot-main-lotCode").find("button").html());
        var hybridName = $.trim(lot_m.find(".prisma-js-lot-main-hybridName").html());

        $(".prisma-js-modal-edit-lot-code").html(lotCode);
        $(".prisma-js-modal-edit-hybrid-name").html(hybridName);
        $("#previousLot").multiselect('destroy');
        $("#previousLot").html("");
        $("#previousLot").hide();
        loading.show();
        message.hideMessages();
        $('#lotId').val(id);
        lotService.findPreviousLots(id)
            .done(function (data) {
                renderLotsWithPreviousLotInfo(id, data.rows)
            })
            .complete(function () {
                loading.hide();
            });
    }


    function initTabLot() {
        var id = $(this).val();
        resetInputs();

        $(".save").addClass("hide");
        $(".update").removeClass("hide");
        $(".delete").removeClass("hide");
        $("#lotForm").bootstrapValidator('resetForm', true);
        $("#dateForm").bootstrapValidator('resetForm', true);
        $("#targetForm").bootstrapValidator('resetForm', true);
        $("#estimateForm").bootstrapValidator('resetForm', true);
        $("#lotMasivoModal").bootstrapValidator('resetForm', true);
        $("#dateMassiveModal").bootstrapValidator('resetForm', true);
        $("#targetMasivoModal").bootstrapValidator('resetForm', true);
        $("#estimateMasivoModal").bootstrapValidator('resetForm', true);
        $("#harvestModal").bootstrapValidator('resetForm', true);
        $("#harvestMassiveModal").bootstrapValidator('resetForm', true);
        $("#huskingModal").bootstrapValidator('resetForm', true);
        $("#huskingMassiveModal").bootstrapValidator('resetForm', true);
        $("#businessInfoModal").bootstrapValidator('resetForm', true);
        $("#businessInfoMassiveModal").bootstrapValidator('resetForm', true);
        lot.detail.selectedHybrid();
        establishmentService.findAll().done(renderEstablishmentCombo);
        valideteForm(id);
        renderDetails(id);
    }

    function tabSelected() {
        var tab = $('ul#tabs li.active').attr("id");
        var checkboxs;
        var countCheckboxActives = 0;
        var tabActive = $(".tab-pane.active");

        resetMassiveInputs();
        switch (tab) {
            case '1':

                $("#lotMassiveForm").bootstrapValidator('resetForm', true);
                $('#updateMasivo').attr('data-target', "#lotMasivoModal");
                break;
            case '2':
                $("#dateMassiveForm").bootstrapValidator('resetForm', true);
                break;
            case '3':
                $("#targetMassiveForm").bootstrapValidator('resetForm', true);
                $('#updateMasivo').attr('data-target', "#targetMasivoModal");
                break;
            case '4':
                $("#estimateMassiveForm").bootstrapValidator('resetForm', true);
                $('#updateMasivo').attr('data-target', "#estimateMasivoModal");
                break;
            case '5':
                $("#harvestMassiveForm").bootstrapValidator('resetForm', true);
                break;
            case '6':
                $("#huskingMassiveModal").bootstrapValidator('resetForm', true);
                break;
            case '7':
                $("#qualityMassiveForm").bootstrapValidator('resetForm', true);
                break;
            default:

        }

        checkboxs = tabActive.find(".prisma-js-lot-main-lot-checkbox");

        $.each(checkboxs, function (index, value) {
            if ($(value).is(":checked")) {
                countCheckboxActives++;
            }
        });

        if (countCheckboxActives > 0) {
            tabActive.find("#updateMasivo").removeAttr("disabled");
            tabActive.find("#deleteLot").removeAttr("disabled");

        } else {
            tabActive.find("#updateMasivo").attr("disabled", "disabled");
            tabActive.find("#deleteLot").attr("disabled", "disabled");
        }

    }

    function resetMassiveInputs() {
        $('input#lotMassivePlantingWeek').val("");
        $('input#lotMasiveHarvestableHas').val("");
        $('input#lotMasiveRegisteredHas').val("");
        $('textarea#lotMasiveObservation').val("");
        $("input#targetMasiveRwToDs").val("");
        $("input#targetMasiveDsToFng").val("");
        $("input#targetMasiveKgBag").val("");
        $("input#targetMasiveBagHa").val("");
        $("input#estimatedMasiveKgDsHa").val("");
        $("textarea#masiveobsEstimatedKgDsHa").val("");
    }

    /**
     * reset all inputs
     */
    function resetInputs() {
        $("#modifyLotCode").val("");
        $("#modifyEstablishmentName").val("");
        $("#modifyHybridName").val("");
        $("#modifyHybridTypeName").val("");
        $("#modifyRegisteredHas").val("");
        $("#modifyHarvestableHas").val("");
        $("#modifyProgram").val("");
        $("#modifyExpedient").val("");
        $("#modifyColor").val("");
        $("#modifyAreaName").val("");
        $("#modifyCertification").val("");
        $("#modifyMegazone").val("");
        $("#modifyZoneCode").val("");
        $("#modifyGranProgram").val("");
        $("#modifyClient").val("");
        $("#modifyGermoplasma").val("");
        $('#lotFile').val("");
        $('#sourceLotFile').val("");
        $("#lotHarvestableHas").val("");
        $("#lotRegisteredHas").val("");
        $("#lotObservation").val("");
        $("#targetRwToDs").val("");
        $("#targetDsToFng").val("");
        $("#targetKgBag").val("");
        $("#targetBagHa").val("");
        $("input#estimatedKgDsHa").val("");
        $("textarea#obsEstimatedKgDsHa").val("");
    }

    function showSuccess(msg) {
        $(".alert").alert();
        $("#lotModal").modal("hide");
        $(".modal.fade.bv-form.in").modal("hide");
        $(".prisma-js-loading").addClass("hide");
        $(".alert.alert-success strong").text(msg);
        $(".alert.alert-danger").addClass("hide");
        $(".alert.alert-success").removeClass("hide");

        $(".close").on("click", function () {
            $(this).parent().hide();
        });

        $(".alert-success").removeAttr('style');
        $("input:checked").prop("checked", false);
        $(".prisma-button.formMasivo").attr("disabled", "disabled");
        $(".prisma-button.delete").attr("disabled", "disabled");

    }

    function showError(msg) {
        $(".alert").alert();
        $("#lotModal").modal("hide");
        $(".prisma-js-loading").addClass("hide");
        $(".alert.alert-danger strong").html(msg);
        $(".alert.alert-success").addClass("hide");
        $(".alert.alert-danger").removeClass("hide");
        $(".close").on("click", function () {
            $(this).parent().hide();
        });

        $(".alert-danger").removeAttr('style');
        $("input:checked").prop("checked", false);
        $(".prisma-button.formMasivo").attr("disabled", "disabled");
        $(".prisma-button.delete").attr("disabled", "disabled");
    }


    function showSpinner() {
        $(".prisma-js-loading").removeClass("hide");
    }

    function showModalSpinner() {
        $(".prisma-js-modal-loading").removeClass("hide");
    }

    function hideModalSpinner() {
        $(".prisma-js-modal-loading").addClass("hide");
    }

    function valideteForm(id) {
        $('#lotFile').attr('disabled', true);
        $('#lotSourceLotFile').attr('disabled', true);
        $('#modifyZoneCode').attr('disabled', true);

        var lot_l = $(".prisma-js-id-" + id);

        var realPlantingDate = $.trim(getDateOrNull(lot_l.find(".prisma-js-real-planting-date").html()));
        if (isPlanted(realPlantingDate)) {
            $("#modifyMegazone").attr('disabled', true);
            $("#modifyEstablishmentName").attr('disabled', true);
            $("#modifyHybridName").attr('disabled', true);
            $("#modifyHybridTypeName").attr('disabled', true);
            $("#modifyProgram").attr('disabled', true);
            $("#modifyExpedient").attr('disabled', true);
            $("#modifyAreaName").attr('disabled', true);
            $("#modifyColor").attr('disabled', true);
            $("#lotPlantingWeek").attr('disabled', true);
            $("#modifyClient").attr('disabled', true);
            $("#modifyGranProgram").attr('disabled', true);
            $("#modifyGermoplasma").attr('disabled', true);
            $("#modifyCertification").attr('disabled', true);
        } else {
            $("#modifyMegazone").attr('disabled', false);
            $("#modifyEstablishmentName").attr('disabled', false);
            $("#modifyHybridName").attr('disabled', false);
            $("#modifyHybridTypeName").attr('disabled', false);
            $("#modifyProgram").attr('disabled', false);
            $("#modifyExpedient").attr('disabled', false);
            $("#modifyAreaName").attr('disabled', false);
            $("#modifyColor").attr('disabled', false);
            $("#lotPlantingWeek").attr('disabled', false);
            $("#modifyClient").attr('disabled', false);
            $("#modifyGranProgram").attr('disabled', false);
            $("#modifyGermoplasma").attr('disabled', false);
            $("#modifyCertification").attr('disabled', false);
        }

        var realHarvestDate = $.trim(lot_l.find(".prisma-js-real-harvest-date").html());
        var harvestKgRwLot = $.trim(lot_l.find(".prisma-js-harvest-kg-rw").html());
        if (isHarvested(harvestKgRwLot, realHarvestDate)) {
            $("#modifyLotCode").attr('disabled', true);
            $("#lotHarvestableHas").attr('disabled', true);
            $("#lotRegisteredHas").attr('disabled', true);
            $('#previousLot').prop('disabled', 'disabled');
            $("#huskingKgDsLot").attr('disabled', false);
            $("#obsHuskingKgDsLot").attr('disabled', false);
            $("#warehouseUnit").attr('disabled', false);


        } else {
            $("#modifyLotCode").attr('disabled', false);
            $("#lotHarvestableHas").attr('disabled', false);
            $("#lotRegisteredHas").attr('disabled', false);
            $('#previousLot').prop('disabled', false);
            $("#huskingKgDsLot").attr('disabled', true);
            $("#obsHuskingKgDsLot").attr('disabled', true);
            $("#warehouseUnit").attr('disabled', true);

        }
    }

    function isHarvested(harvestKgRwLot, realHarvestDate) {
        return (harvestKgRwLot != null && harvestKgRwLot > 0) || realHarvestDate.length > 0;
    }

    function isPlanted(realPlantingDate) {
        return realPlantingDate.length > 0;
    }

    function renderLotsWithPreviousLotInfo(id, previousLot) {
        $("#previousLot option").prop('selected', false);

        if (previousLot !== null) {

            for (var i = 0; i < previousLot.length; i++) {
                var str = "";
                if (previousLot[i].isPreviousLot) {
                    str = "selected = 'selected'";
                }
                $('#previousLot').append("<option " + str + " value='" + previousLot[i].id + "' >" + previousLot[i].lotCode + "</option>");
            }
        }

        $('#previousLot').multiselect({
            enableFiltering: true,
            buttonWidth: '200px'
        });

        $('#previousLot').multiselect('refresh');
    }

    function renderDetails(id) {
        $('#lotId').val(id);

        var lot_m = $(".prisma-js-lot-main-id-" + id);
        var lot_l = $(".prisma-js-id-" + id);

        var lotCode = $.trim(lot_m.find(".prisma-js-lot-main-lotCode").find("button").html());
        var hybridName = $.trim(lot_m.find(".prisma-js-lot-main-hybridName").html());

        $(".prisma-js-modal-edit-lot-code").html(lotCode);
        $(".prisma-js-modal-edit-hybrid-name").html(hybridName);

        //tab Lot
        $("#modifyLotCode").val(lotCode);
        $("#modifyEstablishmentName").val($.trim(lot_l.find(".prisma-js-establishmentId").html()));
        $("#modifyHybridName").data("hybrid-lot", hybridName);
        $("#modifyRegisteredHas").val($.trim(lot_l.find(".prisma-js-registeredHas").html()));
        $("#modifyHarvestableHas").val($.trim(lot_l.find(".prisma-js-harvestableHas").html()));
        $("#modifyExpedient").val($.trim(lot_l.find(".prisma-js-expedient").html()));
        $("#modifyColor").val($.trim(lot_l.find(".prisma-js-color").html()));
        $("#modifyCertification").val($.trim(lot_l.find(".prisma-js-certification").html()));
        $("#modifyZoneCode").val($.trim(lot_l.find(".prisma-js-zoneCode").html()));
        $("#modifyMegazone").val($.trim(lot_l.find(".prisma-js-megaZone").html()));
        $("#modifyGranProgram").val($.trim(lot_l.find(".prisma-js-granProgram").html()));
        $("#modifyClient").val($.trim(lot_l.find(".prisma-js-client").html()));
        $("#modifyGermoplasma").val($.trim(lot_l.find(".prisma-js-germoplasma").html()));

        $('#lotFile').val($.trim(lot_l.find(".prisma-js-file").html()));
        $('#lotSourceLotFile').val($.trim(lot_l.find(".prisma-js-sourceLotFile").html()));
        $("#lotPlantingWeek").val($.trim(lot_l.find(".prisma-js-plantingWeek").html()));
        $("#lotHarvestableHas").val($.trim(lot_l.find(".prisma-js-harvestableHas").html()));
        $("#lotRegisteredHas").val($.trim(lot_l.find(".prisma-js-registeredHas").html()));
        $("#lotObservation").val($.trim(lot_l.find(".prisma-js-observation").html()));

        //Tab Dates
        $("#estimatedFloweringDateWorkFlow").data("lotid", id);
        $("#floweringDateWorkFlow").data("lotid", id);
        $("#realHarvestDateWorkFlow").data("lotid", id);
        var realHarvestDate = $.trim(lot_l.find(".prisma-js-real-harvest-date").html());

        if (realHarvestDate.length > 0) {
            $("#realHarvestDate").val($.format.date(realHarvestDate, datePattern));
        } else {
            $("#realHarvestDate").removeAttr("disabled", "disabled");
        }
        $("#realHarvestDate").datepicker({dateFormat: datePickerPattern});

        var realPlantingDate = $.trim(lot_l.find(".prisma-js-real-planting-date").html());
        if (realPlantingDate !== "") {
            $("#realPlantingDate").val($.format.date(realPlantingDate, datePattern));
        }
        $("#realPlantingDate").datepicker({dateFormat: datePickerPattern});

        var realFloweringDate = $.trim(lot_l.find(".prisma-js-real-flowering-date").html());
        if (realFloweringDate.length > 0) {
            $("#realFloweringDate").val($.format.date(realFloweringDate, datePattern));
        }

        $("#realFloweringDate").datepicker({dateFormat: datePickerPattern});

        var estimatedFloweringDate = $.trim(lot_l.find(".prisma-js-estimated-flowering-date").html());
        if (estimatedFloweringDate.length > 0) {
            $("#estimatedFloweringDate").val($.format.date(estimatedFloweringDate, datePattern));
        }
        $("#estimatedFloweringDate").datepicker({dateFormat: datePickerPattern});

        var flowHarvDays = $.trim(lot_l.find(".prisma-js-real-flow-harv-days").html());
        $("#flowHarvDays").val(flowHarvDays);

        //Tab Target
        $("#targetRwToDs").val($.trim(lot_l.find(".prisma-js-targetRwToDs").html()));
        $("#targetDsToFng").val($.trim(lot_l.find(".prisma-js-targetDsToFng").html()));
        $("#targetKgBag").val($.trim(lot_l.find(".prisma-js-targetKgBag").html()));
        $("#targetBagHa").val($.trim(lot_l.find(".prisma-js-targetBagHa").html()));
        $("#targetRwToDs").removeAttr("disabled", "disabled");
        $("#targetDsToFng").removeAttr("disabled", "disabled");
        $("#targetKgBag").removeAttr("disabled", "disabled");
        $("#targetBagHa").removeAttr("disabled", "disabled");
        $(".prisma-js-target-update").removeAttr("disabled", "disabled");
        if (realHarvestDate.length > 0) {
            $("#targetRwToDs").attr("disabled", "disabled");
            $("#targetDsToFng").attr("disabled", "disabled");
            $("#targetKgBag").attr("disabled", "disabled");
            $("#targetBagHa").attr("disabled", "disabled");
            $(".prisma-js-target-update").attr("disabled", "disabled");
        }

        //Tab estimate
        $("input#estimatedKgDsHa").val($.trim(lot_l.find(".prisma-js-estimatedKgDsHa").html()));
        $("textarea#obsEstimatedKgDsHa").val($.trim(lot_l.find(".prisma-js-obsEstimatedKgDsHa").html()));

        $("#estimatedKgDsHa").attr("disabled", "disabled");
        $("#obsEstimatedKgDsHa").attr("disabled", "disabled");
        $(".prisma-js-estimate-update").attr("disabled", "disabled");
        var harvestKgRwLot = getFloatOrNull($.trim(lot_l.find(".prisma-js-harvest-kg-rw").html()));
        if (!isHarvested(harvestKgRwLot, realHarvestDate) && isPlanted(realPlantingDate)) {
            $("#estimatedKgDsHa").removeAttr("disabled", "disabled");
            $("#obsEstimatedKgDsHa").removeAttr("disabled", "disabled");
            $(".prisma-js-estimate-update").removeAttr("disabled", "disabled");
        }

        // Tab harvest
        $("#harvestKgRwLot").val(getFloatOrNull($.trim(lot_l.find(".prisma-js-harvest-kg-rw").html())));
        $("#harvestRwToDs").val(getFloatOrNull($.trim(lot_l.find(".prisma-js-harvest-rw-ds").html())));
        $("#obsHarvestRwToDs").val(getStringOrNull($.trim(lot_l.find(".prisma-js-harvest-obs-rw-ds").html())));
        $("#harvestKgRwLot").attr("disabled", "disabled");
        $("#harvestRwToDs").attr("disabled", "disabled");
        $("#obsHarvestRwToDs").attr("disabled", "disabled");
        $("#harvestWorkFlow").attr("disabled", "disabled");
        $("#harvestRwToDsWorkFlow").attr("disabled", "disabled");
        if (realHarvestDate.length > 0) {
            $("#harvestKgRwLot").removeAttr("disabled", "disabled");
            $("#harvestRwToDs").removeAttr("disabled", "disabled");
            $("#obsHarvestRwToDs").removeAttr("disabled", "disabled");
            $("#harvestWorkFlow").removeAttr("disabled", "disabled");
            $("#harvestRwToDsWorkFlow").removeAttr("disabled", "disabled");
        }

        //Tab husking
        $("#huskingKgDsLot").val(getFloatOrNull($.trim(lot_l.find(".prisma-js-husking-kg-ds").html())));
        $("#obsHuskingKgDsLot").val(getStringOrNull($.trim(lot_l.find(".prisma-js-husking-obs-kg-ds").html())));
        $("#warehouseUnit").val(getStringOrNull($.trim(lot_l.find(".prisma-js-husking-whereHouseUnit").html())));

        //Tab Business Info
        $("#obsLine").val($.trim(lot_l.find(".prisma-js-businessInfo-obsLine").html()));
        $("#generalObs").val($.trim(lot_l.find(".prisma-js-businessInfo-generalObs").html()));
        $("#estimatedFngInit").val($.trim(lot_l.find(".prisma-js-businessInfo-estimatedFngInit").html()));
        $("#estimatedFngEnd").val($.trim(lot_l.find(".prisma-js-businessInfo-estimatedFngEnd").html()));
    }

    function updateAll() {
        var isValidLotForm = $('#lotMassiveForm').bootstrapValidator('validate').data('bootstrapValidator').isValid();
        var isValidTargetForm = $('#targetMassiveForm').bootstrapValidator('validate').data('bootstrapValidator').isValid();
        var isValidEstimateForm = $('#estimateMassiveForm').bootstrapValidator('validate').data('bootstrapValidator').isValid();

        var id = $('ul#tabs li.active').attr("id");

        var operation = $(this).data("operation");

        if ((id == 1 && isValidLotForm) || (id == 3 && isValidTargetForm) || (id == 4 && isValidEstimateForm)) {
            $("#lotMasivoModal").modal("hide");
            $("#targetMasivoModal").modal("hide");
            $("#estimateMasivoModal").modal("hide");
            showSpinner();
            lotService.updateMassiveOperation(lot.util.formToJsonMasive(), id, operation)
                .done(function (data) {
                    if (data.success) {
                        showSuccess(data.message);

                        for (i = 0; i < data.item.lotDTO.length; i++) {
                            lot.util.refreshLotView(data.item.lotDTO[i]);
                        }
                    } else {
                        showError(data.message);
                    }
                    $('.btn.btn-link.lot').on("click", refreshLotLinkButton);
                });
            $("input:checked").removeAttr('checked');
            $("#updateMasivo").attr("disabled", "disabled");
            $("#deleteLot").attr("disabled", "disabled");
        }
    }

    function enabledButtons() {
        var chk = $(this);
        var tabActive = $(".tab-pane.active");
        var formMasivo = $('.btn.formMasivo');
        var countCheckboxActives = formMasivo.data("contchk");
        var lotId = chk.val();
        var lotRow = $(".prisma-js-lot-main-id-" + lotId);
        lotRow.find(".prisma-js-lot-main-lot-checkbox").prop("checked", chk.is(":checked"));

        if (chk.is(":checked")) {
            countCheckboxActives++;
            formMasivo.data("contchk", countCheckboxActives);
        } else {
            countCheckboxActives--;
            formMasivo.data("contchk", countCheckboxActives);
        }

        if (countCheckboxActives > 0) {
            tabActive.find("#updateMasivo").removeAttr("disabled");
            tabActive.find("#deleteLot").removeAttr("disabled");

        } else {
            tabActive.find("#updateMasivo").attr("disabled", "disabled");
            tabActive.find("#deleteLot").attr("disabled", "disabled");
        }
    }


    return {
        init: init,
        showSuccess: showSuccess,
        showError: showError,
        showSpinner: showSpinner
    }
})();
