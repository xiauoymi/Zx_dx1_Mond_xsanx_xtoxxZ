lot.quality = (function () {
    function init() {
        $(".prisma-update-modal").on("click", fillQualityModal);
        $(".prisma-update-quality").on("click", update);
        $(".quality-update-massive").on("click", updateMassive);
    }

    function fillQualityModal() {
        $('#qualityForm').data('bootstrapValidator').resetForm();
        var $row = $(this).parents(".prisma-lot-list");
        $(".prisma-js-modal-edit-lot-code").html($row.data("lotcode"));
        $(".prisma-js-modal-edit-hybrid-name").html($row.data("hybrid"));
        $("#lotId").val($row.data("id"));
        $("#lotCode").val($row.data("lotcode"));
        $("#qualityDsToFng").val($.trim($row.find(".prisma-js-quality-qualityDsToFng").html()));
        $("#qualityWeightBag").val($.trim($row.find(".prisma-js-quality-qualityWeightBag").html()));
        $("#qualityObs").val($.trim($row.find(".prisma-js-quality-qualityObs").html()));
    }

    function update() {
        var lotToUpdate = {};
        var operation = $(this).data("operation");

        var isValidLotQualityForm = $('#qualityForm').bootstrapValidator('validate').data('bootstrapValidator').isValid();
        if (!isValidLotQualityForm) {
            return;
        }

        lotToUpdate.id = $('#lotId').val();
        lotToUpdate.lotCode = $('#lotCode').val();
        lotToUpdate.qualityDsToFng = $("#qualityDsToFng").val();
        lotToUpdate.qualityWeightBag = $("#qualityWeightBag").val();
        lotToUpdate.qualityObs = $("#qualityObs").val();

        lot.main.showSpinner();
        $("#qualityModal").modal("hide");

        var id = $('ul#tabs li.active').attr("id");

        lotService.updateOperation(lotToUpdate, id, operation).done(refreshLotUpdated);
    }

    function refreshLotUpdated(data) {
        if (data.success) {
            lot.main.showSuccess(data.message);
            lot.util.refreshLotView(data.item);
        } else {
            lot.main.showError(data.message);
        }
    }

    function refreshMassiveLotUpdated(data) {
        if (data.success) {
            lot.main.showSuccess(data.message);
            for (var i = 0; i < data.item.lotDTO.length; i++) {
                lot.util.refreshLotView(data.item.lotDTO[i]);
            }
        } else {
            for (var i = 0; i < data.item.lotDTO.length; i++) {
                lot.util.refreshLotView(data.item.lotDTO[i]);
            }
            lot.main.showError(data.message);
        }
    }

    function updateMassive() {
        var operation = $(this).data("operation");

        var isValidLotQualityForm = $('#qualityMassiveForm').bootstrapValidator('validate').data('bootstrapValidator').isValid();
        if (!isValidLotQualityForm) {
            return;
        }

        var lots = {};
        var lotSelecteds = [];
        var lotsChecked = $(".tab-pane.active").find("input:checked");
        $.each(lotsChecked, function (index, checkboxLot) {
            var lotSelected = $(checkboxLot);
            var lotModified = {};
            lotModified.lotId = parseInt(lotSelected.val());
            lotModified.lotCode = lotSelected.data("lotcode");
            lotSelecteds.push(lotModified);
        });
        lots.selectedLots = lotSelecteds;
        lots.qualityDsToFng = $("#dsToFngMassive").val();
        lots.qualityWeightBag = $("#weightBagMassive").val();
        lots.qualityObs = $("#observationMassive").val();

        lot.main.showSpinner();
        $("#qualityMassiveModal").modal("hide");

        var id = $('ul#tabs li.active').attr("id");

        lotService.updateMassiveOperation(lots, id, operation).done(refreshMassiveLotUpdated);

    }

    return {
        init: init
    }
})();



