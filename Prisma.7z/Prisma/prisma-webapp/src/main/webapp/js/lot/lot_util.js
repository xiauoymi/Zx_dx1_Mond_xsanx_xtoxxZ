lot.util = (function () {

    /**
     * Parse Form html to json object (Lot).
     * @returns {*}
     */
    function formToJson() {
        var lot = new Object();

        var realHarvestDate;
        lot.id = $('#lotId').val();
        lot.lotCode = $("#modifyLotCode").val();
        lot.megazone = $("#modifyMegazone").val();
        lot.establishmentId = $("#modifyEstablishmentName").val();
        lot.establishmentName = $("#modifyEstablishmentName").val();
        lot.hybridName = $("#modifyHybridName").val();
        lot.expediente = $("#modifyExpedient").val();
        lot.color = $("#modifyColor").val();
        lot.certification = $("#modifyCertification").val();
        lot.zoneCode = $("#modifyZoneCode").val();
        lot.file = $('input#lotFile').val();
        lot.sourceLotFile = $('input#lotSourceLotFile').val();
        lot.plantingWeek = $('input#lotPlantingWeek').val();
        lot.harvestableHas = $('input#lotHarvestableHas').val();
        lot.registeredHas = $('input#lotRegisteredHas').val();
        lot.client = $("#modifyClient").val();
        lot.germoplasma = $("#modifyGermoplasma").val();
        lot.granProgram = $("#modifyGranProgram").val();
        lot.observation = $('textarea#lotObservation').val();
        lot.targetRwToDs = $("input#targetRwToDs").val();
        lot.targetDsToFng = $("input#targetDsToFng").val();
        lot.targetKgBag = $("input#targetKgBag").val();
        lot.targetBagHa = $("input#targetBagHa").val();
        lot.estimatedKgDsHa = $("input#estimatedKgDsHa").val() === "" ? null : $("input#estimatedKgDsHa").val();
        lot.obsEstimatedKgDsHa = $("textarea#obsEstimatedKgDsHa").val();

        if (arguments[0] == "realHarvestDateWorkFlow") {
            realHarvestDate = $("#realHarvestDate");
            if (realHarvestDate !== null && realHarvestDate.length > 0) {
                lot.realHarvestDate = realHarvestDate.datepicker("getDate");
            } else {
                lot.realHarvestDate = null;
            }
        }
        var lotCodes = [];
        var lots = $("#previousLot option:selected");

        $.each(lots, function (index, value) {
            lotCodes.push(value.value);
        });
        lot.previousLot = lotCodes;

        // Tab harvest
        if (arguments[0] == 'harvestKgRwWorkFlow') {
            lot.harvestKgRWLot = $("#harvestKgRwLot").val();
        }
        if (arguments[0] == 'harvestRwToDsWorkFlow') {
            lot.harvestRwToDs = $("#harvestRwToDs").val();

            lot.obsHarvestRwToDs = $("#obsHarvestRwToDs").val();
        }

        //Tab Husking
        if (arguments[0] == 'huskingWorkFlow') {
            lot.huskingKgDsLot = $("#huskingKgDsLot").val();
            lot.warehouseUnit = $("#warehouseUnit").val();
            lot.obsHuskingKgDsLot = $("#obsHuskingKgDsLot").val();
        }

        lot.obsLine = $("#obsLine").val();
        lot.generalObs = $("#generalObs").val();

        lot.estimatedFngInit = $("#estimatedFngInit").datepicker("getDate");
        lot.estimatedFngEnd = $("#estimatedFngEnd").datepicker("getDate");

        return lot;
    }

    function formToJsonMasive() {
        var lot = new Object();

        var realHarvestDate;

        lot.id = $('#lotId').val();
        lot.plantingWeek = $('input#lotMassivePlantingWeek').val();
        lot.harvestableHas = $('input#lotMasiveHarvestableHas').val();
        lot.registeredHas = $('input#lotMasiveRegisteredHas').val();
        lot.observation = $('textarea#lotMasiveObservation').val();
        lot.targetRwToDs = $("input#targetMasiveRwToDs").val();
        lot.targetDsToFng = $("input#targetMasiveDsToFng").val();
        lot.targetKgBag = $("input#targetMasiveKgBag").val();
        lot.targetBagHa = $("input#targetMasiveBagHa").val();
        lot.estimatedKgDsHa = $("input#estimatedMasiveKgDsHa").val();
        lot.obsEstimatedKgDsHa = $("textarea#masiveobsEstimatedKgDsHa").val();


        if (arguments[0] == 'realHarvestDateWorkFlow') {
            realHarvestDate = $("#dateMasiveRealHarvestDate");
            if (realHarvestDate !== null && realHarvestDate.length > 0) {
                lot.realHarvestDate = realHarvestDate.datepicker("getDate");
            } else {
                lot.realHarvestDate = null;
            }
        }

        var lotSelecteds = [];
        var lotModified;
        var lots = $(".tab-pane.active").find("input:checked");

        $.each(lots, function (index, checkboxLot) {
            var lotSelected = $(checkboxLot);
            lotModified = {};
            lotModified.lotId = parseInt(lotSelected.val());
            lotModified.lotCode = lotSelected.data("lotcode");
            lotSelecteds.push(lotModified);
        });
        lot.selectedLots = lotSelecteds;

        // Tab harvest
        if (arguments[0] == 'harvestKgRwWorkFlow') {
            lot.harvestKgRWLot = $("#harvestMassiveKgRwLot").val();
        }
        if (arguments[0] == 'harvestRwToDsWorkFlow') {
            lot.harvestRwToDs = $("#harvestMassiveRwToDs").val();
            lot.obsHarvestRwToDs = $("#obsHarvestMassiveRwToDsLot").val();
        }

        //tab husking
        if (arguments[0] == 'huskingWorkFlow') {
            lot.huskingKgDsLot = $("#huskingKgDsLotMassive").val();
            lot.warehouseUnit = $("#warehouseUnitMassive").val();
            lot.obsHuskingKgDsLot = $("#obsHuskingKgDsLotMassive").val();
        }

        lot.obsLine = $("#obsLineMassive").val();
        lot.generalObs = $("#generalObsMassive").val();

        lot.estimatedFngInit = $("#estimatedFngInitMassive").datepicker("getDate");
        lot.estimatedFngEnd = $("#estimatedFngEndMassive").datepicker("getDate");

        return lot;
    }

    function refreshLotView(lotDto) {
        var lot = $(".prisma-js-id-" + lotDto.id);

        refreshLotHeadView(lotDto);

        lot.find(".prisma-js-plantingWeek").html(lotDto.plantingWeek);
        lot.find(".prisma-js-registeredHas").html(getFloatOrNull(lotDto.registeredHas));
        lot.find(".prisma-js-harvestableHas").html(getFloatOrNull(lotDto.harvestableHas));
        lot.find(".prisma-js-observation").html(lotDto.observation);

        lot.find(".prisma-js-targetRwToDs").html(getFloatOrNull(lotDto.targetRwToDs));
        lot.find(".prisma-js-targetDsToFng").html(getFloatOrNull(lotDto.targetDsToFng));
        lot.find(".prisma-js-targetKgBag").html(getFloatOrNull(lotDto.targetKgBag));
        lot.find(".prisma-js-targetBagHa").html(getFloatOrNull(lotDto.targetBagHa));
        lot.find(".prisma-js-targetTnRwLot").html(getFloatOrNull(lotDto.targetTnRwLot));
        lot.find(".prisma-js-targetTnDsLot").html(getFloatOrNull(lotDto.targetTnDsLot));
        lot.find(".prisma-js-targetLot").html(lotDto.targetLot);
        lot.find(".prisma-js-targetBagLot").html(getFloatOrNull(lotDto.targetBagLot));
        lot.find(".prisma-js-targetKgsDsHa").html(getFloatOrNull(lotDto.targetKgsDsHa));


        lot.find(".prisma-js-estimatedKgDsHa").html(getFloatOrNull(lotDto.estimatedKgDsHa));
        lot.find(".prisma-js-obsEstimatedKgDsHa").html(lotDto.obsEstimatedKgDsHa);
        $('#estimatedKgDsHa-id-' + lotDto.id).val(lotDto.countEstimatedKgDsHa);
        renderEstimateColor(lotDto.id);


        // tab dates
        lot.find(".prisma-js-planting-date").html(getDateOrNull(lotDto.plantingDate));
        lot.find(".prisma-js-estimated-planting-date").html(getDateOrNull(lotDto.estimatedPlantingDate));
        lot.find(".prisma-js-real-planting-date").html(getDateOrNull(lotDto.realPlantingDate));
        lot.find(".prisma-js-plantFlowDays").html(lotDto.plantFlowDays);
        lot.find(".prisma-js-flowering-date").html(getDateOrNull(lotDto.floweringDate));
        lot.find(".prisma-js-estimated-flowering-date").html(getDateOrNull(lotDto.estimatedFloweringDate));
        lot.find(".prisma-js-real-flowering-date").html(getDateOrNull(lotDto.realFloweringDate));
        lot.find(".prisma-js-real-flow-harv-days").html(lotDto.flowHarvDays);
        lot.find(".prisma-js-harvest-date").html(getDateOrNull(lotDto.harvestDate));
        lot.find(".prisma-js-estimated-harvest-date").html(getDateOrNull(lotDto.estimatedHarvestDate));
        lot.find(".prisma-js-real-harvest-date").html(getDateOrNull(lotDto.realHarvestDate));
        lot.find(".prisma-js-harvest-date-for-humidity").html(getDateOrNull(lotDto.harvestDateForHumidity));


        // harvest Tab
        lot.find(".prisma-js-harvest-kg-rw").html(getFloatOrNull(lotDto.harvestKgRWLot));
        lot.find(".prisma-js-harvest-kgDsLotEstRw").html(getFloatOrNull(lotDto.harvKgDsLotEstRw));
        lot.find(".prisma-js-harvest-harvKgFngEstLotRw").html(getFloatOrNull(lotDto.harvKgFngEstLotRw));
        lot.find(".prisma-js-harvest-harvKgDsHaEstRw").html(getFloatOrNull(lotDto.harvKgDsHaEstRw));
        lot.find(".prisma-js-actual-tn-ds").html(getFloatOrNull(lotDto.actualTnDsLot));
        lot.find(".prisma-js-actual-tn-rw").html(getFloatOrNull(lotDto.actualTnRwLot));
        lot.find(".prisma-js-harvest-rw-ds").html(getFloatOrNull(lotDto.harvestRwToDs));
        lot.find(".prisma-js-harvest-rw-date").html(getDateOrNull(lotDto.estimatedRwDate));
        lot.find(".prisma-js-harvest-rw-real-date").html(getDateOrNull(lotDto.realRwReceiptDate));
        lot.find(".prisma-js-harvest-obs-rw-ds").html(lotDto.obsHarvestRwToDs);

        // husking Tab
        lot.find(".prisma-js-husking-kg-ds").html(getFloatOrNull(lotDto.huskingKgDsLot));
        lot.find(".prisma-js-husking-obs-kg-ds").html(lotDto.obsHuskingKgDsLot);
        lot.find(".prisma-js-husking-whereHouseUnit").html(lotDto.warehouseUnit);
        lot.find(".prisma-js-husking-actual-tn-ds").html(getFloatOrNull(lotDto.actualTnDsLot));
        lot.find(".prisma-js-husking-actual-tn-rw").html(getFloatOrNull(lotDto.actualTnRwLot));
        lot.find(".prisma-js-husking-ds-real-date").html(getDateOrNull(lotDto.realDsDate));
        lot.find(".prisma-js-husking-ds-date").html(getDateOrNull(lotDto.estimatedDsDate));

        // Quality tab
        lot.find(".prisma-js-quality-qualityDsToFng").html(getFloatOrNull(lotDto.qualityDsToFng));
        lot.find(".prisma-js-quality-qualityWeightBag").html(getFloatOrNull(lotDto.qualityWeightBag));
        lot.find(".prisma-js-quality-qualityObs").html(lotDto.qualityObs);
        lot.find(".prisma-js-quality-qualityKgFngLot").html(getFloatOrNull(lotDto.qualityKgFngLot));

        //preharvest
        lot.find(".prisma-js-preHarvest-sampleHum").html(getFloatOrNull(lotDto.humidity));
        lot.find(".prisma-js-preHarvest-sampleDate").html(getDateOrNull(lotDto.sampleDateHumidity));

        //paygrower
        lot.find(".prisma-js-payGrower-pl").html(getFloatOrNull(lotDto.plLot));
        lot.find(".prisma-js-payGrower-pls").html(getFloatOrNull(lotDto.plsLot));
        lot.find(".prisma-js-payGrower-greenConversion").html(getFloatOrNull(lotDto.greenConversion));
        lot.find(".prisma-js-payGrower-bulkConversion").html(getFloatOrNull(lotDto.bulkConversion));
        lot.find(".prisma-js-payGrower-eficienciaKgDescarte").html(getFloatOrNull(lotDto.eficienciaKgDescarte));

        //business info
        lot.find(".prisma-js-businessInfo-obsLine").html(lotDto.obsLine);
        lot.find(".prisma-js-businessInfo-generalObs").html(lotDto.generalObs);
        lot.find(".prisma-js-businessInfo-estimatedFngInit").html(getDateOrNull(lotDto.estimatedFngInit));
        lot.find(".prisma-js-businessInfo-estimatedFngEnd").html(getDateOrNull(lotDto.estimatedFngEnd));

        // Actual
        lot.find(".prisma-js-actualTnRwLot").html(getFloatOrNull(lotDto.actualTnRwLot));
        lot.find(".prisma-js-actualTnDsLot").html(getFloatOrNull(lotDto.actualTnDsLot));
        lot.find(".prisma-js-actualTnFngLot").html(getFloatOrNull(lotDto.actualTnFngLot));
        lot.find(".prisma-js-actualBagLot").html(getFloatOrNull(lotDto.actualBagLot));
        lot.find(".prisma-js-actualWeightBagLot").html(getFloatOrNull(lotDto.actualWeightBagLot));
        lot.find(".prisma-js-actualKgDsHa").html(getFloatOrNull(lotDto.actualKgDsHa));
        <!-- BASEESTIM-184 -->
        lot.find(".prisma-js-actualKgFngHa").html(getFloatOrNull(lotDto.actualTnFngLot * 1000 / lotDto.harvestableHas));
        lot.find(".prisma-js-actualBagHa").html(getFloatOrNull(lotDto.actualBagLot / lotDto.harvestableHas));

        //refresh sums
        refreshLotFooter();

        $('.btn.btn-link.lot').on("click", refreshLotLinkButton);
    }

    function refreshLotLinkButton() {
        var id = $(this).data("lotid");
        $('#idLot').val(id);
        $('#formCampaign').attr('action', '/prisma/lot/detail/');
        $('#optionMenu').val("/lot/detail/");
        $('#formCampaign').submit();
    }

    function renderEstimateColor(idLot) {
        var countEstimatedKgDsHa = $('#estimatedKgDsHa-id-' + idLot).val();

        if (countEstimatedKgDsHa == 1) {
            $(".prisma-js-estimatedKgDsHa.id-" + idLot).css('backgroundColor', '#82FA58')
        }
        if (countEstimatedKgDsHa == 2) {
            $(".prisma-js-estimatedKgDsHa.id-" + idLot).css('backgroundColor', '#BCF5A9')
        }
        if (countEstimatedKgDsHa > 2) {
            $(".prisma-js-estimatedKgDsHa.id-" + idLot).css('backgroundColor', '#01DF3A')
        }
    }

    function refreshLotFooter() {
        $.each($('.summable'), function (i, table) {
            $(table).sumtr({
                readValue: function (e) {
                    if (e.parent().css("display") === "none") {
                        return 0;
                    }
                    var val = e.html().trim();
                    return val !== "" ? parseFloat(val) : 0;
                },
                formatValue: function (val) {
                    return getFloatOrNull(val);
                },
                bodyRows: 'tbody .prisma-js-show'
            });
        });
    }

    function refreshLotHeadView(lotDto) {
        var b = '<button type="submit" class="btn btn-link lot" data-lotid="' + lotDto.id + '">' + lotDto.lotCode + '</button>';
        var lotMain = $(".prisma-lot-list.prisma-js-lot-main-id-" + lotDto.id);
        lotMain.find(".prisma-js-lot-main-lotCode").html(b);
        lotMain.find(".prisma-js-lot-main-hybridName").html(lotDto.hybridName);

        var lot = $(".prisma-lot-list.prisma-js-id-" + lotDto.id);
        lot.find(".prisma-js-megaZone").html(lotDto.megazone);
        lot.find(".prisma-js-zone").html(lotDto.zoneCode);
        lot.find(".prisma-js-establishmentName").html(lotDto.establishmentName);
        lot.find(".prisma-js-granProgram").html(lotDto.granProgram);
        lot.find(".prisma-js-client").html(lotDto.client);
        lot.find(".prisma-js-germoplasma").html(lotDto.germoplasma);
        lot.find(".prisma-js-expedient").html(lotDto.expediente);
        lot.find(".prisma-js-color").html(lotDto.color);
        lot.find(".prisma-js-certification").html(lotDto.certification);
    }

    return {
        formToJson: formToJson,
        formToJsonMasive: formToJsonMasive,
        refreshLotView: refreshLotView,
        renderEstimateColor: renderEstimateColor,
        refreshLotFooter: refreshLotFooter
    }
})();
