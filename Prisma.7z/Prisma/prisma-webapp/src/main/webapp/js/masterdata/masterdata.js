/**
 * Created by EPESTE on 28/05/2014.
 */
var masterdata = {

};

masterdata.service = (function () {
    function refreshLotsFromMasterdata() {
        var campaignId = $('#campaignId').val();
        return $.ajax({
            url: url + "/masterdata",
            type: 'POST',
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify(campaignId)
        });
    }

    function refreshLotsFromMasterDataManual() {
        var form = new FormData();
        form.append("campaignId", $('#campaignId').val());
        form.append("file", $('#uploadFile').prop("files")[0]);

        return $.ajax({
            url: url + "/masterdata/upload",
            type: 'POST',
            data: form,
            cache: false,
            processData: false,
            contentType: false
        });
    }

    return {
        automatic: refreshLotsFromMasterdata,
        manual: refreshLotsFromMasterDataManual

    }
})();

masterdata.ui = (function () {
    function init() {
        $("#modifyLotFromMasterdata").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmAddLotsFromMasterdata,
            onCancel: cancelRefreshLotsFromMasterdata});

        $("#modifyLotFromMasterdataManual").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmManualImport,
            onCancel: cancelRefreshLotsFromMasterdata});
    }

    function loadBundles(lang) {
        jQuery.i18n.properties({
            name: 'Messages',
            path: 'bundle/',
            mode: 'both',
            language: lang
        });
    }


    function confirmAddLotsFromMasterdata() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-masterdata-loading").removeClass("hide");
        $("#modifyLotFromMasterdata").confirmation('hide');
        masterdata.service.automatic().done(doneRefreshLotsFromMasterdata).fail(failRefreshLotsFromMasterdata);
    }

    function confirmManualImport() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-masterdata-loading").removeClass("hide");
        $("#modifyLotFromMasterdataManual").confirmation('hide');
        masterdata.service.manual().done(doneRefreshLotsFromMasterdata).fail(failRefreshLotsFromMasterdata);
    }

    function doneRefreshLotsFromMasterdata(data) {
        if (data.success) {
            renderFileStatistics(data.item);
        } else {
            failImportFile(data.message);
        }
    }

    function renderFileStatistics(statistics) {
        $(".prisma-js-masterdata-loading").addClass("hide");

        $("#lotsAdded").html("");
        $.each(statistics, function (i, itemVal) {
            var causes = itemVal.causes;
            var modifiyLotFromMasterdata = "<tr><td> " + itemVal.hybridName + "</td><td>" + itemVal.megazone + "</td><td>" + itemVal.imported + "</td><td>" + itemVal.omitted + "</td>";

            if (causes.length > 1) {
                modifiyLotFromMasterdata = modifiyLotFromMasterdata + "<td data-localize=\'" + itemVal.causes + "\'></td>";
            } else {
                modifiyLotFromMasterdata = modifiyLotFromMasterdata + "<td></td>";
            }

            var omissions = itemVal.cellsOmitted;
            if (omissions != null) {
                if (omissions.length > 1) {
                    var omissionsDetail = "<ul>";
                    for (var u = 0; u < omissions.length; u++) {
                        omissionsDetail += "<li>" + omissions[u].cellName + "</li>";
                    }
                    omissionsDetail = "<td>" + omissionsDetail + "</ul>" + "</td>";

                    modifiyLotFromMasterdata = modifiyLotFromMasterdata + omissionsDetail;
                } else {
                    modifiyLotFromMasterdata = modifiyLotFromMasterdata + "<td></td>";
                }
            }

            modifiyLotFromMasterdata = modifiyLotFromMasterdata + "</tr>";
            $("#lotsAdded").append(modifiyLotFromMasterdata);
        });

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });

        $("#message").find(".alert-success").removeClass("hide");
    }

    function failRefreshLotsFromMasterdata() {
        $(".prisma-js-masterdata-loading").addClass("hide");
        $("#modifyLotFromMasterdata").confirmation('hide');
        $("#message").find(".alert-danger").removeClass("hide");
    }

    function cancelRefreshLotsFromMasterdata() {
        $("#modifyLotFromMasterdata").confirmation('hide');
        $("#modifyLotFromMasterdataManual").confirmation('hide');
    }

    function failImportFile(errorThrown) {
        $(".prisma-js-masterdata-loading").addClass("hide");
        $("#modifyLotFromMasterdata").confirmation('hide');
        if (errorThrown.length > 0) {
            var divErrorMessage = "<span data-localize=\'" + errorThrown + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    masterdata.ui.init();
});