/**
 * Created by PGSETT on 31/07/2014.
 */
/**
 * Created by PGSETT on 28/07/2014.
 */
var payGrower = {};

payGrower.ui = (function () {
    function init() {
        $("#modifyLotFromPayGrower").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmModifyLotsFromPayGrower,
            onCancel: cancelModifyLotsFromPayGrower});
    }

    function confirmModifyLotsFromPayGrower() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-payGrower-loading").removeClass("hide");
        $("#modifyLotFromPayGrower").confirmation('hide');
        service.service("/payGrower/campaign/" + $("#campaignId").val(), "PUT", null).done(doneModifyLotsFromPayGrower).fail(failModifyLotsFromPayGrower);
    }

    function doneModifyLotsFromPayGrower(data) {
        if (data.success) {
            renderPayGrowerStatistics(data.item);
            renderLotsOmitted(data.item.lotDTOs);
        } else {
            renderStatiticsFailed(data.message);
        }
    }

    function renderPayGrowerStatistics(payGrowerStatistics) {
        var datePayGrowerRun = $.format.date(payGrowerStatistics.dateProccess, "dd/MM/yyyy hh:mm:ss");
        var pathFilePayGrower = payGrowerStatistics.pathFile;
        var lotModified = payGrowerStatistics.modified;
        var lotOmitted = payGrowerStatistics.omitted;

        var rowPayGrower = "<tr><td style='width: 120px;'> " + datePayGrowerRun + "</td><td> " + pathFilePayGrower + "</td><td>" + lotModified + "</td><td>" + lotOmitted + "</td></tr>";
        $("#payGrowerStatistics").append(rowPayGrower);


        $(".prisma-js-payGrower-loading").addClass("hide");
        $("#message").find(".alert-success").removeClass("hide");
    }

    function renderLotsOmitted(lotsOmitted) {
        var rowLotOmitted;
        for (var i = 0; i < lotsOmitted.length; i++) {
            var rowLotOmitted = "<tr><td> " + lotsOmitted[i].lotCode + "</td><td data-localize=\'" + lotsOmitted[i].causes + "\'> " + lotsOmitted[i].causes + "</td></tr>";
            $("#payGrowerLotsOmitted").append(rowLotOmitted);
        }

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function failModifyLotsFromPayGrower(jqXHR, textStatus, errorThrown) {
        $(".prisma-js-payGrower-loading").addClass("hide");
        $("#modifyLotFromPayGrower").confirmation('hide');
        if (errorThrown.length > 0) {
            var divErrorMessage = "<div data-localize=\'" + errorThrown + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });

    }

    function renderStatiticsFailed(errorCode) {
        $(".prisma-js-payGrower-loading").addClass("hide");
        $("#modifyLotFromPayGrower").confirmation('hide');
        if (errorCode.length > 0) {
            var divErrorMessage = "<div data-localize=\'" + errorCode + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });

    }

    function cancelModifyLotsFromPayGrower() {
        $("#modifyLotFromPayGrower").confirmation('hide');
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    payGrower.ui.init();

});