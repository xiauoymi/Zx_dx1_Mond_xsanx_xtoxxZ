/**
 * Created by PGSETT on 24/06/2014.
 */
/**
 * Created by EPESTE on 28/05/2014.
 */
var preHarvest = {

};

preHarvest.service = (function () {
    function refreshLotsFromPreHarvest() {
        var campaignId = $('#campaignId').val();
        return $.ajax({
            url: url + "/preHarvest",
            type: 'POST',
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify(campaignId)
        });
    }



    return {
        automatic: refreshLotsFromPreHarvest


    }
})();

preHarvest.ui = (function () {
    function init() {
        $("#modifyPreHarvest").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmAddLotsFromPreHarvest,
            onCancel: cancelRefreshLotsFromPreHarvest});

        $("#modifyPreHarvestManual").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmManualImport,
            onCancel: cancelRefreshLotsFromPreHarvest});
    }

    function confirmAddLotsFromPreHarvest() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-preHarvest-loading").removeClass("hide");
        $("#modifyPreHarvest").confirmation('hide');
        preHarvest.service.automatic().done(doneRefreshLotsFromPreHarvest).fail(failRefreshLotsFromPreHarvest);
    }

    function confirmManualImport() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-preHarvest-loading").removeClass("hide");
        $("#modifyPreHarvestManual").confirmation('hide');
        preHarvest.service.manual().done(doneRefreshLotsFromPreHarvest).fail(failRefreshLotsFromPreHarvest);
    }

    function doneRefreshLotsFromPreHarvest(data) {
        if (data.success == true) {
            renderStatistics(data.item);
            renderLotsOmitted(data.item.lotHumidityDTOs);
        } else {
            renderStatisticsFailed(data.message);
        }
    }


    function renderStatistics(statistics) {
        var date = $.format.date(statistics.dateCreation, "dd/MM/yyyy hh:mm:ss");

        var modifiyLotFromPreHarvest = "<tr><td style='width: 120px;'> " + date + "</td><td> " + statistics.sourceHumidityFile + "</td><td>" + statistics.imported + "</td><td>" + statistics.omitted + "</td></tr>";
        $("#lotsAdded").append(modifiyLotFromPreHarvest);

        $(".prisma-js-preHarvest-loading").addClass("hide");
        $(".prisma-js-preHarvest-result").addClass("hide");
        $(".prisma-js-preHarvest-omitted").addClass("hide");
    }

    function renderLotsOmitted(lotsOmitted) {
        var lotCode;
        var zoneCode;
        var hybrid;
        var causes;
        var humidity;
        var rowLotOmitted;

        for (var i = 0; i < lotsOmitted.length; i++) {
            lotCode = lotsOmitted[i].lot.lotCode;
            zoneCode = lotsOmitted[i].lot.zoneCode;
            hybrid = lotsOmitted[i].lot.hybridName;
            humidity = lotsOmitted[i].humidity;
            causes = lotsOmitted[i].lot.causes;
            rowLotOmitted = "<tr><td > " + lotCode + "</td><td> " + zoneCode + "</td><td>" + hybrid + "</td><td>" + humidity + "</td><td data-localize=\'" + causes + "\'>" + causes + "</td></tr>";
            $("#lotsOmitted").append(rowLotOmitted);
        }

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
        $("#message").find(".alert-success").removeClass("hide");
    }

    function renderStatisticsFailed(errorCode) {
        $(".prisma-js-preHarvest-loading").addClass("hide");
        $("#modifyPreHarvest").confirmation('hide');
        if (errorCode.length > 0) {
            var divErrorMessage = "<div data-localize=\'" + errorCode + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function failRefreshLotsFromPreHarvest() {
        $(".prisma-js-preHarvest-loading").addClass("hide");
        $("#modifyPreHarvest").confirmation('hide');
        $("#modifyPreHarvestManual").confirmation('hide');
        $("#message").find(".alert-danger").removeClass("hide");

    }

    function cancelRefreshLotsFromPreHarvest() {
        $("#modifyPreHarvest").confirmation('hide');
        $("#modifyPreHarvestManual").confirmation('hide');
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    preHarvest.ui.init();
});