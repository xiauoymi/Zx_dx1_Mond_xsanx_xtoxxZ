/**
 * Created by PGSETT on 06/10/2014.
 */
var menu = (function () {
    function init() {

        $('.btn-link.batch').on({
            click: function () {
                $('#optionMenu').val("/campaign/batch/");

                $('#formCampaign').attr('action', url + "/campaign/batch/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.ditsem').on({
            click: function () {
                $('#optionMenu').val("/ditsem/campaign/");

                $('#formCampaign').attr('action', url + "/ditsem/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.masterdata').on({
            click: function () {
                $('#optionMenu').val("/masterdata/campaign/");

                $('#formCampaign').attr('action', url + "/masterdata/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.preharvest').on({
            click: function () {
                $('#optionMenu').val("/preHarvest/campaign/");

                $('#formCampaign').attr('action', url + "/preHarvest/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.report1').on({
            click: function () {
                $('#optionMenu').val("/report1/campaign/");

                $('#formCampaign').attr('action', url + "/report1/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.report2').on({
            click: function () {
                $('#optionMenu').val("/report2/campaign/");

                $('#formCampaign').attr('action', url + "/report2/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.quality').on({
            click: function () {
                $('#optionMenu').val("/quality/campaign/");

                $('#formCampaign').attr('action', url + "/quality/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.payGrower').on({
            click: function () {
                $('#optionMenu').val("/payGrower/campaign/");

                $('#formCampaign').attr('action', url + "/payGrower/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.humidityImport').on({
            click: function () {
                $('#optionMenu').val("/humidity/import/campaign/");

                $('#formCampaign').attr('action', url + "/humidity/import/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.statusReport').on({
            click: function () {
                $('#optionMenu').val("/report/tons/statusReport/campaign/");

                $('#formCampaign').attr('action', url + "/report/tons/statusReport/campaign/");

                $('#formCampaign').submit();
            }
        });
        $('.btn-link.receivingTons').on({
            click: function () {
                $('#optionMenu').val("/report/tons/receive/campaign/");

                $('#formCampaign').attr('action', url + "/report/tons/receive/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.tonsToHostReport').on({
            click: function () {
                $('#optionMenu').val("/report/tons/tonsToHostReport/campaign/");

                $('#formCampaign').attr('action', url + "/report/tons/tonsToHostReport/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.bulkDestinationReport').on({
            click: function () {
                $('#optionMenu').val("/report/tons/bulkDestination/campaign/");

                $('#formCampaign').attr('action', url + "/report/tons/bulkDestination/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.dateImport').on({
            click: function () {
                $('#optionMenu').val("/dateImport/campaign/");

                $('#formCampaign').attr('action', url + "/dateImport/campaign/");

                $('#formCampaign').submit();
            }
        });

        $('.btn-link.prisma-js-forecast').on({
            click: function () {
                $('#optionMenu').val("/forecast/campaign/");

                $('#formCampaign').attr('action', url + "/forecast/campaign/");

                $('#formCampaign').submit();
            }
        });


    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    menu.init();
});