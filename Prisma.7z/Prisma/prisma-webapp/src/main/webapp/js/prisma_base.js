function getFloatOrNull(floatNr) {
    return (floatNr !== null && floatNr !== "" ? $.number(parseFloat(floatNr), 2, '.', '') : null);
}

function getDateOrNull(dateField) {
    return (dateField !== null && dateField !== "" ? $.format.date(dateField, datePattern) : null);
}

function getStringOrNull(stringVar) {
    return (stringVar !== null ? stringVar : null);
}

function getDateForFilter(dayString) {
    var year;
    var month;
    var day;

    var daySplit = dayString.split("/");
    day = daySplit[0];
    month = daySplit[1];
    year = daySplit[2];
    return getDateOrNull(Date.parse(month + "/" + day + "/" + year));
}

function getDateFromString(dayString) {
    var year;
    var month;
    var day;

    var daySplit = dayString.split("/");

    if (datePattern === "dd/MM/yy") {
        day = daySplit[0];
        month = daySplit[1];
        year = daySplit[2];
    } else {
        month = daySplit[0];
        day = daySplit[1];
        year = daySplit[2];
    }

    return Date.parse(month + "/" + day + "/" + year);
}

function compareDates(dayString1, dayString2) {
    var day1 = getDateFromString(dayString1);
    var day2 = getDateFromString(dayString2);

    return moment(day1).isAfter(day2);
}