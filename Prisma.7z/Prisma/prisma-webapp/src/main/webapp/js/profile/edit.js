var edit = (function () {
    function init() {
        $("#saveProfile").on("click", updateProfile);
        $("#all").on("click", selectAll);
        $("#none").on("click", noneSelect);
        validation.profile();
    }

    function selectAll() {
        var $checkbox = $("#profileFunctionalities").find(":checkbox");
        $.each($checkbox, function(index, checkbox){
           $(checkbox).prop("checked", "checked");
        });
    }

    function noneSelect() {
        var $checkbox = $("#profileFunctionalities").find(":checkbox");
        $.each($checkbox, function(index, checkbox){
            $(checkbox).prop("checked", "");
        });
    }

    function updateProfile() {
        if (!validation.isProfileValid()) {
            event.preventDefault();
            return;
        }

        message.hideMessages();
        loading.show();
        profile.update().done(doneUpdateProfile).error(errorUpdateProfile);
    }

    function doneUpdateProfile(data) {
        message.showSuccess(data.message);
        loading.hide();
    }

    function errorUpdateProfile() {
        message.showError("prisma.profile.update.error");
        loading.hide();
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    edit.init();
});
