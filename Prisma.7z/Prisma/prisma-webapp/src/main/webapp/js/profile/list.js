var list = (function () {
    function init() {
        $(".prisma-js-delete").on("click", completeConfirmationModal);
    }

    function completeConfirmationModal() {
        var idProfile = $(this).data("id");
        var $rowProfile = $(".prisma-js-profile-id-" + idProfile);
        $("#deleteName").html($rowProfile.find(".prisma-js-profile-name").html().trim());
        $("#deleteEnabled").html($rowProfile.find(".prisma-js-profile-enabled span").html().trim());
        $("#delete").data("id", idProfile);

        $("#delete").on("click", deleteProfile);
    }

    function deleteProfile() {
        var idProfile = $("#delete").data("id");

        message.hideMessages();
        loading.show();

        profile.delete(idProfile).done(doneDeleteProfile).error(errorDeleteProfile);
    }

    function doneDeleteProfile(data) {
        var $rowProfile = $(".prisma-js-profile-id-" + data.item.id);
        $rowProfile.remove();
        message.showSuccess(data.message);
        loading.hide();
    }

    function errorDeleteProfile() {
        message.showError("prisma.profile.delete.error");
        loading.hide();
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    list.init();
});
