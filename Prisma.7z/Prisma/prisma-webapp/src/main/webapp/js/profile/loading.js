var loading = (function () {
    function show() {
        $(".alert.alert-warning").removeClass("hide");
    }

    function hide() {
        $(".alert.alert-warning").addClass("hide");
    }

    return {
        show: show,
        hide: hide
    }
})();
