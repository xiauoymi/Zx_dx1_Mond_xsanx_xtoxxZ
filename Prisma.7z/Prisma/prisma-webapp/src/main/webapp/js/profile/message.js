var message = (function () {
    function showSuccess(key) {
        $("#messageSuccess").data("localize", key);
        $(".alert.alert-success").removeClass("hide");
        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function hideSuccess() {
        $(".alert.alert-success").addClass("hide");
    }

    function showError(key) {
        $("#messageError").data("localize", key);
        $(".alert.alert-danger").removeClass("hide");
        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function hideError() {
        $(".alert.alert-danger").addClass("hide");
    }

    function hideMessages() {
        hideError();
        hideSuccess();
    }

    return {
        showSuccess: showSuccess,
        hideSuccess: hideSuccess,
        showError: showError,
        hideError: hideError,
        hideMessages: hideMessages
    }
})();
