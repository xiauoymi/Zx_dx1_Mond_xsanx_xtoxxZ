var profile = (function () {
    function get() {
        var profile = {};
        profile.name = $("#profileName").val();
        profile.enabled = $("#enabled").prop("checked");

        var $functionalities = $("#profileFunctionalities").find(":checked").parents("tr");
        var functionalities = [];
        $.each($functionalities, function (index, element) {
            var $functionality = $(element);
            var functionality = {};
            functionality.id = $functionality.data("id");
            functionality.functionality = $functionality.find(".prisma-js-functionality").html();
            functionality.action = $functionality.find(".prisma-js-functionality-selected").data("action");
            functionalities.push(functionality);
        });
        profile.functionalities = functionalities;
        return profile;
    }

    function getForUpdate() {
        var profile = get();
        profile.id = $("#profileForm").data("profileId");
        return profile;
    }

    function update() {
        var profile = getForUpdate();
        return service.service("/profile", "PUT", profile);
    }

    function add() {
        var profile = get();
        return service.service("/profile", "POST", profile);
    }

    function trash(id) {
        return service.service("/profile?id=" + id, "DELETE", null);
    }

    return {
        update: update,
        add: add,
        delete: trash
    }
})();
