var validation = (function () {

    var regexp = /^[a-z0-9\s\ñ\Ñ\/\\\u00e1\u00e9\u00ed\u00f3\u00fa\u00c1\u00c9\u00cd\u00d3\u00da\u00f1\u00d1\u00FC\u00DC\,\.\-\_]+$/i;

    function profile() {
        $('#profileForm')
            .bootstrapValidator({
                excluded: ':disabled',
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    profileName: {
                        validators: {
                            regexp: {
                                regexp: regexp,
                                message: '<span data-localize="prisma.validator.profile.name.regexp"/>'
                            },
                            notEmpty: {
                                message: '<span data-localize="prisma.validator.profile.name.notEmpty"/>'
                            }
                        }
                    }
                }
            });

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function isProfileValid() {
        var $profileFormBootstrapValidator = $('#profileForm').bootstrapValidator('validate');
        return $profileFormBootstrapValidator.data('bootstrapValidator').isValid();
    }

    return {
        profile: profile,
        isProfileValid: isProfileValid
    }
})();
