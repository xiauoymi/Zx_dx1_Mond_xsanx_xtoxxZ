var quality = {};

quality.ui = (function () {
    function init() {
        $("#modifyLotFromQualityFile").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmModifyLotsFromQualityFile,
            onCancel: cancelModifyLotsFromQualityFile});
    }

    function confirmModifyLotsFromQualityFile() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-quality-loading").removeClass("hide");
        $("#modifyLotFromQualityFile").confirmation('hide');
        service.service("/quality/campaign/" + $("#campaignId").val(), "PUT", null).done(doneModifyLotsFromQualityFile).error(errorModifyLotsFromQualityFile);
    }

    function doneModifyLotsFromQualityFile(data) {
        if (data.success == true) {
            renderQualityFileStatistics(data.item);
            renderLotsOmitted(data.item.lotDTOs);
        } else {
            renderStatisticsFailed(data.message);
        }
    }

    function renderQualityFileStatistics(qualityFileStatistics) {
        var dateQualityFileRun = $.format.date(qualityFileStatistics.dateProcess, "dd/MM/yyyy hh:mm:ss");
        var pathFileQualityFile = qualityFileStatistics.pathFile;
        var lotModified = qualityFileStatistics.lotsModified;
        var lotOmitted = qualityFileStatistics.lotsNotModified;

        var rowQualityFile = "<tr><td style='width: 120px;'> " + dateQualityFileRun + "</td><td> " + pathFileQualityFile + "</td><td>" + lotModified + "</td><td>" + lotOmitted + "</td></tr>";
        $("#qualityFileStatistics").append(rowQualityFile);

        $(".prisma-js-quality-loading").addClass("hide");
        $("#message").find(".alert-success").removeClass("hide");
    }

    function renderLotsOmitted(lotsOmitted) {
        var rowLotOmitted;
        for (var i = 0; i < lotsOmitted.length; i++) {
            var lotCode = "<td> " + lotsOmitted[i].lotCode + "</td>";
            var cause = "<td data-localize=\'" + lotsOmitted[i].causes + "\'></td>";
            var rowCell = "<td></td>";
            if (lotsOmitted[i].errorDetail != null) {
                rowCell = "<td>" + lotsOmitted[i].errorDetail + "</td>";
            }
            rowLotOmitted = "<tr>" + lotCode + cause + rowCell + "</tr>";
            $("#qualityFileLotsOmitted").append(rowLotOmitted);
        }

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function renderStatisticsFailed(errorThrown) {
        $(".prisma-js-quality-loading").addClass("hide");
        $("#modifyLotFromQualityFile").confirmation('hide');
        if (errorThrown.length > 0) {
            var divErrorMessage = "<span data-localize=\'" + errorThrown + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function errorModifyLotsFromQualityFile(jqXHR, textStatus, errorThrown) {
        $(".prisma-js-quality-loading").addClass("hide");
        $("#modifyLotFromQualityFile").confirmation('hide');
        if (errorThrown.length > 0) {
            var divErrorMessage = "<span data-localize=\'" + errorThrown + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function cancelModifyLotsFromQualityFile() {
        $("#modifyLotFromQualityFile").confirmation('hide');
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    quality.ui.init();

});