var report1 = {};

report1.ui = (function () {
    function init() {
        $("#modifyLotFromReport1").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmModifyLotsFromReport1,
            onCancel: cancelModifyLotsFromReport1});
    }

    function confirmModifyLotsFromReport1() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-report1-loading").removeClass("hide");
        $("#modifyLotFromReport1").confirmation('hide');
        service.service("/report1/campaign/" + $("#campaignId").val(), "PUT", null).done(doneModifyLotsFromReport1).error(errorModifyLotsFromReport1);
    }

    function doneModifyLotsFromReport1(data) {
        if (data.success == true) {
            renderReport1Statistics(data.item);
            renderLotsOmitted(data.item.lotDTOs);
        } else {
            renderStatisticsFailed(data.message);
        }
    }

    function renderReport1Statistics(report1Statistics) {
        var dateReport1Run = $.format.date(report1Statistics.dateProccess, "dd/MM/yyyy hh:mm:ss");
        var pathFileReport1 = report1Statistics.pathFile;
        var lotModified = report1Statistics.modified;
        var lotOmitted = report1Statistics.omitted;

        var rowRepor1 = "<tr><td style='width: 120px;'> " + dateReport1Run + "</td><td> " + pathFileReport1 + "</td><td>" + lotModified + "</td><td>" + lotOmitted + "</td></tr>";
        $("#report1Statistics").append(rowRepor1);

        $(".prisma-js-report1-loading").addClass("hide");
        $("#message").find(".alert-success").removeClass("hide");
    }

    function renderLotsOmitted(lotsOmitted) {
        var rowLotOmitted;
        for (var i = 0; i < lotsOmitted.length; i++) {
            var rowLotOmitted = "<tr><td> " + lotsOmitted[i].lotCode + "</td><td data-localize=\'" + lotsOmitted[i].causes + "\'></td></tr>";
            $("#report1LotsOmitted").append(rowLotOmitted);
        }

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function renderStatisticsFailed(errorThrown) {
        $(".prisma-js-report1-loading").addClass("hide");
        $("#modifyLotFromReport1").confirmation('hide');
        if (errorThrown.length > 0) {
            var divErrorMessage = "<div data-localize=\'" + errorThrown + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function errorModifyLotsFromReport1(jqXHR, textStatus, errorThrown) {
        $(".prisma-js-report1-loading").addClass("hide");
        $("#modifyLotFromReport1").confirmation('hide');
        if (errorThrown.length > 0) {
            var divErrorMessage = "<div data-localize=\'" + errorThrown + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function cancelModifyLotsFromReport1() {
        $("#modifyLotFromReport1").confirmation('hide');
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    report1.ui.init();

});