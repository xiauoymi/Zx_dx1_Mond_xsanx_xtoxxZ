/**
 * Created by PGSETT on 28/07/2014.
 */
var report2 = {};

report2.ui = (function () {
    function init() {
        $("#modifyLotFromReport2").confirmation({
            title: confirmationMessage,
            btnOkLabel: confirmationOkButton,
            btnCancelLabel: confirmationCancelButton,
            onConfirm: confirmModifyLotsFromReport2,
            onCancel: cancelModifyLotsFromReport2});
    }

    function confirmModifyLotsFromReport2() {
        $("#message").find(".alert-success").addClass("hide");
        $("#message").find(".alert-danger").addClass("hide");
        $(".prisma-js-report2-loading").removeClass("hide");
        $("#modifyLotFromReport2").confirmation('hide');
        service.service("/report2/campaign/" + $("#campaignId").val(), "PUT", null).done(doneModifyLotsFromReport2).error(failModifyLotsFromReport2);
    }

    function doneModifyLotsFromReport2(data) {
        if (data.success == true) {
            renderReport2Statistics(data.item);
            renderLotsOmitted(data.item.lotDTOs);
        } else {
            renderStatisticsFailed(data.message);
        }
    }

    function renderReport2Statistics(report2Statistics) {
        var dateReport2Run = $.format.date(report2Statistics.dateProccess, "dd/MM/yyyy hh:mm:ss");
        var pathFileReport2 = report2Statistics.pathFile;
        var lotModified = report2Statistics.modified;
        var lotOmitted = report2Statistics.omitted;

        var rowRepor2 = "<tr><td style='width: 120px;'> " + dateReport2Run + "</td><td> " + pathFileReport2 + "</td><td>" + lotModified + "</td><td>" + lotOmitted + "</td></tr>";
        $("#report2Statistics").append(rowRepor2);

        $(".prisma-js-report2-loading").addClass("hide");
        $("#message").find(".alert-success").removeClass("hide");
    }

    function renderLotsOmitted(lotsOmitted) {
        var rowLotOmitted;
        for (var i = 0; i < lotsOmitted.length; i++) {
            var rowLotOmitted = "<tr><td> " + lotsOmitted[i].lotCode + "</td><td data-localize=\'" + lotsOmitted[i].causes + "\'></td></tr>";
            $("#report2LotsOmitted").append(rowLotOmitted);
        }

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function renderStatisticsFailed(codeError) {
        $(".prisma-js-report2-loading").addClass("hide");
        $("#modifyLotFromReport2").confirmation('hide');
        if (codeError.length > 0) {
            var divErrorMessage = "<div data-localize=\'" + codeError + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });

    }

    function failModifyLotsFromReport2(jqXHR, textStatus, errorThrown) {
        $(".prisma-js-report2-loading").addClass("hide");
        $("#modifyLotFromReport2").confirmation('hide');
        if (errorThrown.length > 0) {
            var divErrorMessage = "<div data-localize=\'" + errorThrown + "\'/>";
            $("#message").find(".alert-danger").html(divErrorMessage);
        }
        $("#message").find(".alert-danger").removeClass("hide");

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });

    }

    function cancelModifyLotsFromReport2() {
        $("#modifyLotFromReport2").confirmation('hide');
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    report2.ui.init();

});