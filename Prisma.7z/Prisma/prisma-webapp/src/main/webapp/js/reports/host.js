var host = (function () {
    function init() {
        $("#harvestRealFrom").datepicker({dateFormat: datePickerPattern});
        $("#harvestRealTo").datepicker({dateFormat: datePickerPattern});

        renderOptionFilter();
        $("#optionFilter").change(renderOptionFilter);
    }

    function filter() {
        var filter = {};
        filter.optionFilter =  $("#optionFilter").find(":selected").val();
        filter.program = $("#textFilter").val();
        filter.textFilter = $("#textFilter").val();
        filter.zoneId = $("#zone").find(":selected").val();
        filter.hybridId = $("#hybrid").find(":selected").val();
        var harvestDateFrom = getDateFromString($("#harvestRealFrom").val());
        filter.harvestRealWeekFrom = new Date(harvestDateFrom).valueOf();
        var harvestDateTo = getDateFromString($("#harvestRealTo").val());
        filter.harvestRealWeekTo = new Date(harvestDateTo).valueOf();
        return filter;
    }
    function renderOptionFilter() {
        if ($("#optionFilter").val() == "1" || $("#optionFilter").val() == "4") {
            $("#zone").attr("style", "display:none");
            $("#hybrid").attr("style", "display:none");
            $("#textFilter").attr("style", "width:196px;display:inline");
        } else {
            if ($("#optionFilter").val() == "2") {
                //zone
                $("#textFilter").attr("style", "display:none");
                $("#hybrid").attr("style", "display:none");
                $("#zone").attr("style", "width:196px;display:inline");
            } else {
                //hybrid
                $("#textFilter").attr("style", "display:none");
                $("#zone").attr("style", "display:none");
                $("#hybrid").attr("style", "width:196px;display:inline");
            }
        }
    }

    return {
        init: init,
        filter: filter
    }
})();
