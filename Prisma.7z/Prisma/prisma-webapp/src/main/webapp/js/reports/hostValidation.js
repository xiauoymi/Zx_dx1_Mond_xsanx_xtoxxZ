var hostValidation = (function () {
    var regexp = /^[a-z0-9\s\ñ\Ñ\/\\\u00e1\u00e9\u00ed\u00f3\u00fa\u00c1\u00c9\u00cd\u00d3\u00da\u00f1\u00d1\u00FC\u00DC\,\.\-\_]+$/i;

    function validate() {
        $('#tonsToHostReportForm').bootstrapValidator({
            feedbackIcons: {
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            live: 'enabled',
            fields: {
                textFilter: {
                    validators: {
                        regexp: {
                            regexp: regexp,
                            message: '<span data-localize="prisma.validator.regexp"/>'
                        }
                    }
                },
                harvestRealFrom: {
                    validators: {
                        date: {
                            message: '<span data-localize="prisma.validator.date.invalid"/>',
                            format: datePickerPattern
                        },
                        callback: {
                            message: '<span data-localize="prisma.validator.date.invalid"/>',
                            callback: function (value, validator) {
                                var dateField = getDateOrNull(value);
                                if (dateField == null) {
                                    return false;
                                }
                                return true;
                            }
                        }
                    }
                },
                harvestRealTo: {
                    validators: {
                        date: {
                            message: '<span data-localize="prisma.validator.date.invalid"/>',
                            format: datePickerPattern
                        },
                        callback: {
                            message: '<span data-localize="prisma.validator.receiveTonsReportForm.harvestTo.range"/>',
                            callback: function (value, validator) {
                                var harvestDateFrom = $("#harvestRealFrom").val();
                                if (harvestDateFrom == "") {
                                    return false;
                                }
                                var harvestNumberDateFrom = new Date(getDateFromString(harvestDateFrom)).valueOf();

                                var harvestNumberDateTo = new Date(getDateFromString(value)).valueOf();
                                return harvestNumberDateTo > harvestNumberDateFrom;
                            }
                        }
                    }
                }
            }
        });

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function isValid() {
        return $('#tonsToHostReportForm').bootstrapValidator('validate').data('bootstrapValidator').isValid();
    }

    function reset() {
        var $form = $("#tonsToHostReportForm").data('bootstrapValidator');
        if ($form !== undefined) {
            $form.resetForm();
        }
    }

    return {
        validate: validate,
        isValid: isValid,
        reset: reset
    }

})();
