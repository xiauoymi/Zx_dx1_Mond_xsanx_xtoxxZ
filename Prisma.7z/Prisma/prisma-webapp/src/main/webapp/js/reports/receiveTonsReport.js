var receiveTonsReport = (function () {
    function init() {
        $(".prisma-js-export").on("click", generateReceiveTonsReport);
        receive.init();
    }

    function generateReceiveTonsReport() {
        validation.reset();
        validation.validate();
        var id = $('#campaignId').val();
        var isValidForm = validation.isValid();
        if (!isValidForm) {
            event.preventDefault();
            return;
        }

        var filter = receive.filter();
        var urlFilter = "zone=" + filter.zoneId + "&harvestWeekFrom=" + filter.harvestRealWeekFrom +
            "&harvestWeekTo=" + filter.harvestRealWeekTo +
            "&optionFilter=" + filter.optionFilter +
            "&textFilter=" + filter.textFilter +
            "&program=" + filter.program +
            "&hybrid=" + filter.hybridId;

        $("#exportToXls").attr("href", id + "/xls?" + urlFilter);
        $("#exportToPdf").attr("href", id + "/pdf?" + urlFilter);
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    receiveTonsReport.init();
});
