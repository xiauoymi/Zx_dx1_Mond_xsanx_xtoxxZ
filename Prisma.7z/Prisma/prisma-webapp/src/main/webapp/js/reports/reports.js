/**
 * Created by PGSETT on 25/08/2014.
 */
var reports = {};

reports.ui = (function () {

    function init() {
        $(".prisma-js-export").on("click", exportForm);
        host.init();
    }

    function exportForm() {
        var id = $('#campaignId').val();
        var typeReport = $(this).data("report");
        if (typeReport == "tonsToHostReport") {
            hostValidation.reset();
            hostValidation.validate();
        }
        if (typeReport == "statusReport") {
            var isValidForm = $('#statusReportForm').bootstrapValidator('validate').data('bootstrapValidator').isValid();
            if (!isValidForm) {
                return;
            }
        }

        var program = $("#modifyProgram").val();
        var campaignId = $('#campaignId').val();
        var hybridId;
        var hybridName;
        var harvestRealWeekFrom;
        var harvestRealWeekTo;

        if (typeReport == "statusReport") {
            hybridId = $("#modifyHybridName option:selected").val();
            hybridName = $("#modifyHybridName option:selected").text();
            if (hybridId == 0) {
                hybridName = "";
            }
            harvestRealWeekFrom = "";
            harvestRealWeekTo = "";
            $("#exportToExcel").attr("href", id + "/xls?hybrid=" + hybridId + "&hybridName=" + hybridName + "&program=" + program);
            $("#exportToPDF").attr("href", id + "/pdf?hybrid=" + hybridId + "&hybridName=" + hybridName + "&program=" + program);
        }
        if (typeReport == "tonsToHostReport") {
            var isValidForm = hostValidation.isValid();
            if (!isValidForm) {
                event.preventDefault();
                return;
            }

            var hostFilter = host.filter();
            var url = "zone=" + hostFilter.zoneId + "&harvestWeekFrom=" + hostFilter.harvestRealWeekFrom +
                "&harvestWeekTo=" + hostFilter.harvestRealWeekTo +
                "&optionFilter=" + hostFilter.optionFilter +
                "&textFilter=" + hostFilter.textFilter +
                "&program=" + hostFilter.program +
                "&hybrid=" + hostFilter.hybridId;
            //var url = "program=" + hostFilter.program + "&harvestWeekFrom=" + hostFilter.harvestRealWeekFrom + "&harvestWeekTo=" + hostFilter.harvestRealWeekTo;
            $("#exportToExcel").attr("href", id + "/xls?" + url);
            $("#exportToPDF").attr("href", id + "/pdf?" + url);
        }
        if (typeReport == "bulkDestinationReport") {

            var warehouseUnit = $("#modifyWarehouseUnit").val();
            hybridName = $("#modifyHybridName option:selected").text();
            hybridId = $("#modifyHybridName option:selected").val();
            $("#exportToExcel").attr("href", id + "/xls?warehouseUnit=" + warehouseUnit + "&hybrid=" + hybridId + "&hybridName=" + hybridName);
            $("#exportToPDF").attr("href", id + "/pdf?warehouseUnit=" + warehouseUnit + "&hybrid=" + hybridId + "&hybridName=" + hybridName);
        }


    }

    return {
        init: init
    }
})
();

$(document).ready(function () {
    reports.ui.init();
});