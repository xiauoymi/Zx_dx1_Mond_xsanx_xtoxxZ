service = function(){
    function service(urlService, method, data){
        var uri = url + urlService;
        return $.ajax({
            url: uri,
            type: method,
            dataType: 'json',
            contentType: 'application/json',
            data: JSON.stringify(data)
        });
    }

    return {
        service: service
    }
}();
