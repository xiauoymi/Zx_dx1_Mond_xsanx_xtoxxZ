var user = (function () {

    function getFromList(id) {
        var user = {};
        var $userInfoRow = $(".prisma-js-user-id-" + id);
        user.username = $userInfoRow.find(".prisma-js-user-username").html().trim();
        user.fullname = $userInfoRow.find(".prisma-js-user-fullname").html().trim();
        user.enabled = $userInfoRow.find(".prisma-js-user-enabled span").data("enabled");
        user.profiles = [];
        var $userProfile = $userInfoRow.find(".prisma-js-user-profile label");
        $.each($userProfile, function (index, element) {
            user.profiles.push($(element).data("id"));
        });
        user.regions = [];
        var $userRegion = $userInfoRow.find(".prisma-js-user-region label");
        $.each($userRegion, function (index, element) {
            user.regions.push($(element).data("id"));
        });
        return user;
    }

    function getFromUpdateModal() {
        var user = {};
        user.id = parseInt($("#updateUserId").val().trim());
        user.userName = $("#updateUserName").val().trim();
        user.fullName = $("#updateFullName").val().trim();
        user.enabled = $("#updateEnabled").is(":checked");
        user.profiles = [];
        var $userProfile = $("#updateProfile option");
        $.each($userProfile, function (index, element) {
            if ($(element).prop("selected")) {
                var profile = {};
                profile.id = parseInt(element.value);
                profile.name = element.label;
                user.profiles.push(profile);
            }
        });
        user.regions = [];
        var $userRegion = $("#updateRegion option");
        $.each($userRegion, function (index, element) {
            if ($(element).prop("selected")) {
                var region = {};
                region.id = parseInt(element.value);
                region.name = element.label;
                user.regions.push(region);
            }
        });
        return user;
    }

    function getFromNewModal() {
        var user = {};
        user.userName = $("#newUserName").val().trim();
        user.fullName = $("#newFullName").val().trim();
        user.enabled = $("#newEnabled").is(":checked");
        user.profiles = [];
        var $userProfile = $("#newProfile option");
        $.each($userProfile, function (index, element) {
            if ($(element).prop("selected")) {
                var profile = {};
                profile.id = parseInt(element.value);
                profile.name = element.label;
                user.profiles.push(profile);
            }
        });

        user.regions = [];
        var $userRegion = $("#newRegion option");
        $.each($userRegion, function (index, element) {
            if ($(element).prop("selected")) {
                var region = {};
                region.id = parseInt(element.value);
                region.name = element.label;
                user.regions.push(region);
            }
        });
        return user;
    }

    function update(data) {
        var profiles = "";
        var regions = "";
        $userInfoRow = $(".prisma-js-user-id-" + data.id);
        $userInfoRow.find(".prisma-js-user-username").html(data.userName);
        $userInfoRow.find(".prisma-js-user-fullname").html(data.fullName);
        var $enabled = "<span data-enabled='" + data.enabled + "' data-localize='prisma.user.enabled." + data.enabled + "'></span>";
        $userInfoRow.find(".prisma-js-user-enabled").html($enabled);
        $.each(data.regions, function (index, element) {
            if (index == data.regions.length - 1) {
                regions = regions.concat("<label data-id='" + element.id + "'>" + element.name + "</label>");
            } else {
                regions = regions.concat("<label data-id='" + element.id + "'>" + element.name + "</label>, ");
            }
        });
        $userInfoRow.find(".prisma-js-user-region").html(regions);
        $.each(data.profiles, function (index, element) {
            if (index == data.profiles.length - 1) {
                profiles = profiles.concat("<label data-id='" + element.id + "'>" + element.name + "</label>");
            } else {
                profiles = profiles.concat("<label data-id='" + element.id + "'>" + element.name + "</label>, ");
            }
        });
        $userInfoRow.find(".prisma-js-user-profile").html(profiles);

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function deleteUser(id) {
        $(".prisma-js-user-id-" + id).remove();
    }

    function newUser(data) {
        var $userList = $("#userList tbody");
        var $userName = "<td class='prisma-js-user-username'>" + data.userName + "</td>";
        var $fullName = "<td class='prisma-js-user-fullname'>" + data.fullName + "</td>";

        var $enabled = "<td class='prisma-js-user-enabled'><span data-enabled='" + data.enabled + "' data-localize='prisma.user.enabled." + data.enabled + "'></span></td>";
        var regions = "";
        $.each(data.regions, function (index, element) {
            if (index == data.regions.length - 1) {
                regions = regions.concat("<label data-id='" + element.id + "'>" + element.name + "</label>");
            } else {
                regions = regions.concat("<label data-id='" + element.id + "'>" + element.name + "</label>, ");
            }
        });
        var $region = "<td class='prisma-js-user-region prisma-user-label'>" + regions + "</td>";

        var profiles = "";
        $.each(data.profiles, function (index, element) {
            if (index == data.profiles.length - 1) {
                profiles = profiles.concat("<label data-id='" + element.id + "'>" + element.name + "</label>");
            } else {
                profiles = profiles.concat("<label data-id='" + element.id + "'>" + element.name + "</label>, ");
            }
        });
        var $profile = "<td class='prisma-js-user-profile prisma-user-label'>" + profiles + "</td>";
        var $actionUpdate = "<button class='btn btn-default update' data-toggle='modal' data-id='" + data.id + "' data-target='#userModal'><span class='glyphicon glyphicon-pencil'></span></button>";
        var $actionDelete = "<button class='btn btn-default delete' data-toggle='modal' data-target='#confirmation' data-id='" + data.id + "'><span class='glyphicon glyphicon-trash'></span></button>";
        var $actions = "<td><div class='btn-toolbar'><div class='btn-group'>" + $actionUpdate + $actionDelete + "</div></div></td>";

        var $userRow = "<tr class='prisma-js-user-id-" + data.id + "'>" + $userName + $fullName + $region + $profile + $enabled + $actions + "</tr>";
        $userList.append($userRow);

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    return {
        getFromList: getFromList,
        getFromUpdateModal: getFromUpdateModal,
        update: update,
        deleteUser: deleteUser,
        getFromNewModal: getFromNewModal,
        newUser: newUser
    }
})();

