var userPage = {};

userPage.ui = (function () {
    function init() {
        $(".update").on("click", completeUserInformation);
        $(".prisma-js-update-confirm").on("click", updateUser);
        $(".prisma-js-update-cancel").on("click", cancelUpdate);

        $(".prisma-js-new-cancel").on("click", cancelNew);

        $(".prisma-js-new-user").on("click", enabledNewUser);

        $(".new").on("click", saveUser);

        $(".delete").on("click", completeUserDeleteInformation);
    }

    function setMultiselectOptions($field, numberDisplay, options) {
        $($field).find("option").each(function () {
            $(this).prop('selected', false);
        });

        $($field).multiselect({
            numberDisplayed: numberDisplay
        });
        $.each(options, function (index, element) {
            $($field).multiselect('select', element);
        });
        $($field).multiselect('refresh');
    }

    function completeUserInformation() {
        var $userId = $(this).data("id");
        var userUpdate = user.getFromList($userId);

        $("#updateUserName").val(userUpdate.username);
        $("#updateFullName").val(userUpdate.fullname);
        $("#updateEnabled").prop("checked", userUpdate.enabled);
        $("#updateUserId").val($userId);

        setMultiselectOptions("#updateRegion", 2, userUpdate.regions);

        setMultiselectOptions("#updateProfile", 1, userUpdate.profiles);

        validation.update();

    }

    function completeUserDeleteInformation() {
        var $userId = $(this).data("id");
        var userUpdate = user.getFromList($userId);
        $("#deleteUserName").html(userUpdate.username);
        $("#deleteFullName").html(userUpdate.fullname);
        $("#delete").data("id", $userId);
        $("#delete").on("click", deleteUser);
    }

    function updateUser() {
        var isValidate = validation.isUpdateValid();
        if (!isValidate) {
            event.preventDefault();
            return;
        }

        var userUpdate = user.getFromUpdateModal();

        loading.show();
        message.hideMessages();

        $("#userModal").modal("hide");

        service.service("/user", "PUT", userUpdate).done(doneUpdate).error(failUpdate);
    }

    function enabledNewUser() {
        $('#newRegion').multiselect({
            numberDisplayed: 2
        });

        $('#newProfile').multiselect({
            numberDisplayed: 1
        });

        validation.newUser();
    }

    function doneUpdate(data) {
        if (data.success) {
            user.update(data.item);
            message.showSuccess(data.message);
        } else {
            message.showError(data.message);
        }
        loading.hide();
        validation.resetUpdate();

    }

    function failUpdate() {
        message.showError("prisma.user.update.error");
        loading.hide();
    }

    function deleteUser() {
        var $userId = $(this).data("id");
        loading.show();
        service.service("/user/" + $userId, "DELETE", null).done(doneDelete).error(errorDelete);
    }

    function doneDelete(data) {
        loading.hide();
        message.showSuccess("prisma.user.delete.ok");
        user.deleteUser(data.id);
    }

    function errorDelete() {
        message.showError("prisma.user.error.delete");
        loading.hide();
    }

    function saveUser() {
        var isValidate = validation.isNewValid();
        if (!isValidate) {
            event.preventDefault();
            return;
        }

        var newUser = user.getFromNewModal();

        loading.show();
        message.hideMessages();

        $("#userNewModal").modal("hide");

        service.service("/user", "POST", newUser).done(doneNewUser).error(errorNewUser);
    }

    function doneNewUser(data) {
        if (data.success) {
            user.newUser(data.item);
            message.showSuccess(data.message);
            $(".update").on("click", completeUserInformation);
            $(".delete").on("click", completeUserDeleteInformation);
        } else {
            message.showError(data.message);
        }
        loading.hide();
        validation.resetNew();
        cleanNewUserForm();
    }

    function errorNewUser() {
        message.showError("prisma.user.new.error");
        loading.hide();
        cleanNewUserForm();
    }

    function cancelUpdate() {
        validation.resetUpdate();
    }

    function cancelNew() {
        validation.resetNew();
    }

    function cleanNewUserForm() {
        $("#newUserForm")[0].reset();
        $('#newRegion').multiselect('destroy');
        $('#newProfile').multiselect('destroy');
        $("#newEnabled").prop("ckecked", false);
    }

    return {
        init: init
    }
})();

$(document).ready(function () {
    userPage.ui.init();
});