var validation = (function () {

    var regexp = /^[a-z0-9\s\ñ\Ñ\/\\\u00e1\u00e9\u00ed\u00f3\u00fa\u00c1\u00c9\u00cd\u00d3\u00da\u00f1\u00d1\u00FC\u00DC\,\.\-\_]+$/i;

    function resetUpdate() {
        $("#updateUserForm").data('bootstrapValidator').resetForm();
    }

    function update() {
        $('#updateUserForm')
            .find('[name="updateRegion"]')
            .multiselect({
                onChange: function(element, checked) {
                    $('#updateUserForm').bootstrapValidator('revalidateField', 'updateRegion');
                }
            })
            .end()
            .find('[name="updateRol"]')
            .multiselect({
                onChange: function(element, checked) {
                    $('#updateUserForm').bootstrapValidator('revalidateField', 'updateRol');
                }
            })
            .end()
            .bootstrapValidator({
                excluded: ':disabled',
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    updateUserName: {
                        validators: {
                            regexp: {
                                regexp: regexp,
                                message: '<span data-localize="prisma.validator.user.username.regexp"/>'
                            },
                            notEmpty: {
                                message: '<span data-localize="prisma.validator.user.username.notEmpty"/>'
                            }
                        }
                    },
                    updateFullName: {
                        validators: {
                            regexp: {
                                regexp: regexp,
                                message: '<span data-localize="prisma.validator.user.fullname.regexp"/>'
                            },
                            notEmpty: {
                                message: '<span data-localize="prisma.validator.user.fullname.notEmpty"/>'
                            }
                        }
                    },
                    updateRegion: {
                        validators: {
                            callback: {
                                message: '<span data-localize="prisma.validator.user.region.notEmpty"/>',
                                callback: function (value, validator) {
                                    var regionSelected = validator.getFieldElements('updateRegion').val();
                                    return regionSelected !== null;
                                }
                            }
                        }
                    },
                    updateProfile: {
                        validators: {
                            callback: {
                                message: '<span data-localize="prisma.validator.user.profile.notEmpty"/>',
                                callback: function (value, validator) {
                                    var profileSelected = validator.getFieldElements('updateProfile').val();
                                    return profileSelected !== null;
                                }
                            }
                        }
                    }
                }
            });

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function isUpdateValid() {
        var $updateValidator = $('#updateUserForm').bootstrapValidator('validate');
        return $updateValidator.data('bootstrapValidator').isValid();
    }

    function resetNew() {
        $("#newUserForm").data('bootstrapValidator').resetForm();
    }

    function newUser() {
        $('#newUserForm')
            .find('[name="newRegion"]')
            .multiselect({
                onChange: function(element, checked) {
                    $('#newUserForm').bootstrapValidator('revalidateField', 'newRegion');
                }
            })
            .end()
            .find('[name="newRol"]')
            .multiselect({
                onChange: function(element, checked) {
                    $('#newUserForm').bootstrapValidator('revalidateField', 'newRol');
                }
            })
            .end()
            .bootstrapValidator({
                excluded: ':disabled',
                feedbackIcons: {
                    valid: 'glyphicon glyphicon-ok',
                    invalid: 'glyphicon glyphicon-remove',
                    validating: 'glyphicon glyphicon-refresh'
                },
                fields: {
                    newUserName: {
                        validators: {
                            regexp: {
                                regexp: regexp,
                                message: '<span data-localize="prisma.validator.user.username.regexp"/>'
                            },
                            notEmpty: {
                                message: '<span data-localize="prisma.validator.user.username.notEmpty"/>'
                            }
                        }
                    },
                    newFullName: {
                        validators: {
                            regexp: {
                                regexp: regexp,
                                message: '<span data-localize="prisma.validator.user.fullname.regexp"/>'
                            },
                            notEmpty: {
                                message: '<span data-localize="prisma.validator.user.fullname.notEmpty"/>'
                            }
                        }
                    },
                    newRegion: {
                        validators: {
                            callback: {
                                message: '<span data-localize="prisma.validator.user.region.notEmpty"/>',
                                callback: function (value, validator) {
                                    var regionSelected = validator.getFieldElements('newRegion').val();
                                    return regionSelected !== null;
                                }
                            }
                        }
                    },
                    newProfile: {
                        validators: {
                            callback: {
                                message: '<span data-localize="prisma.validator.user.profile.notEmpty"/>',
                                callback: function (value, validator) {
                                    var profileSelected = validator.getFieldElements('newProfile').val();
                                    return profileSelected !== null;
                                }
                            }
                        }
                    }
                }
            });

        $("[data-localize]").localize("/prisma/bundle/application", { language: userLang });
    }

    function isNewValid() {
        var $newValidator = $('#newUserForm').bootstrapValidator('validate');
        return $newValidator.data('bootstrapValidator').isValid();
    }

    return {
        resetUpdate: resetUpdate,
        update: update,
        isUpdateValid: isUpdateValid,
        resetNew: resetNew,
        newUser: newUser,
        isNewValid: isNewValid
    }
})();
