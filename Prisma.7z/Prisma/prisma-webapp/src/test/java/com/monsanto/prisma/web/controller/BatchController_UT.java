package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.*;
import com.monsanto.prisma.core.exception.BatchException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.exception.ExistsBatchWithNameException;
import com.monsanto.prisma.core.exception.KgDsAssignedInvalidException;
import com.monsanto.prisma.core.service.BatchService;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.HybridService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.*;

/**
 * Created by PGSETT on 09/10/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class BatchController_UT {

    @Mock
    private LotService lotService;

    @Mock
    private BatchService batchService;

    @Mock
    private HybridService hybridService;

    @Mock
    private CampaignService campaignService;

    @InjectMocks
    private BatchController batchController;

    @Mock
    private MessageCurrentLocaleResolver message;


    private Campaign campaign1;

    private CampaignDTO campaignDTO1;
    private Crop crop;
    private Region region;
    private BatchDTO batchDTO;
    private Country country;
    private List<BatchDTO> batchDTOList;
    private List<HybridDTO> hybrids;
    HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
    HttpSession session = PowerMockito.mock(HttpSession.class);
    private List<LotBatchDTO> lotBatchDTOs;

    @Before
    public void setUp() throws BatchException {
        crop = new Crop();
        crop.setId(1);
        crop.setName("SOJA");

        region = new Region();
        region.setId(1);
        region.setName("LAS");

        country = new Country();
        country.setId(1);
        country.setName("ARGENTINA");
        country.setRegion(region);

        Season season1 = new Season();
        season1.setId(1);
        season1.setName("season1");
        season1.setMaxCampaigns(1);
        season1.setCrop(crop);
        season1.setCountry(country);

        campaign1 = new Campaign();
        campaign1.setId(1);
        campaign1.setName("campaignName");
        campaign1.setCrop(crop);
        campaign1.setSeason(season1);
        campaign1.setObservations("observations");
        campaign1.setFilePath("filePath");
        campaign1.setIsActive(true);
        campaign1.setIsReal(true);
        campaign1.setCode("code");

        Lot lot1 = new Lot();
        lot1.setId(1);
        lot1.setLotCode("OQ577L2A");
        lot1.setEstablishment(new Establishment());
        lot1.getEstablishment().setZone(new Zone());
        lot1.getEstablishment().getZone().setArea(new Area());
        lot1.setHybrid(new Hybrid());
        lot1.getHybrid().setHybridType(new HybridType());
        lot1.setUser(new User());
        lot1.setCampaign(campaign1);


        campaignDTO1 = new CampaignDTO(1, 1, "regionCode", 1, "ARGENTINA", 1, "SOJA", "2013/2014", "campaignCode", true, true);

        batchDTOList = new ArrayList<BatchDTO>();
        batchDTO = new BatchDTO();
        batchDTO.setId(1);
        batchDTOList.add(batchDTO);

        lotBatchDTOs = new ArrayList<LotBatchDTO>();
        LotBatch lotBatch = new LotBatch();
        lotBatch.setLot(lot1);
        Batch batch = new Batch();
        batch.setCampaign(campaign1);
        Hybrid hybrid = mock(Hybrid.class);
        hybrid.setId(1);
        hybrid.setName("H1");
        batch.setHybrid(hybrid);
        lotBatch.setBatch(batch);
        LotBatchDTO lotBatchDTO = new LotBatchDTO(lotBatch);
        lotBatchDTOs.add(lotBatchDTO);


        when(campaignService.findByIdAndActiveLots(1)).thenReturn(campaignDTO1);
        when(batchService.findByCampaignId(1)).thenReturn(batchDTOList);

        when(request.getSession()).thenReturn(session);
        when(request.getSession().getAttribute("idCampaign")).thenReturn(campaignDTO1.getId());
        when(campaignService.findByIdAndActiveLots(campaignDTO1.getId())).thenReturn(campaignDTO1);
        when(hybridService.findByCampaignId(campaignDTO1.getId())).thenReturn(hybrids);
        when(batchService.findById(batchDTO.getId())).thenReturn(batchDTO);

        when(batchService.findLotsAssociated(batchDTO.getId())).thenReturn(lotBatchDTOs);
        when(batchService.addLot(lot1.getId(), 2F, 3F, 4F, 5)).thenReturn(lotBatchDTO);
        when(batchService.save(batchDTO)).thenReturn(batchDTO);
    }


    @Test
    @DirtiesContext
    public void test_init_batch_get() {

        ModelAndView modelAndView = batchController.init(request);
        Assert.assertEquals(modelAndView.getModel().get("campaignId"), campaignDTO1.getId());
        Assert.assertEquals(modelAndView.getModel().get("campaign"), campaignDTO1);
        Assert.assertEquals(modelAndView.getModel().get("batches"), batchDTOList);
    }

    @Test
    public void test_init_batch_post() {
        ModelAndView modelAndView = batchController.init(campaignDTO1.getId());
        Assert.assertEquals(modelAndView.getModel().get("campaignId"), campaignDTO1.getId());
        Assert.assertEquals(modelAndView.getModel().get("campaign"), campaignDTO1);
        Assert.assertEquals(modelAndView.getModel().get("batches"), batchDTOList);
    }

    @Test
    public void test_detail_when_campaignIdAndBatchIdExist() {
        ModelAndView modelAndView = batchController.detail(campaignDTO1.getId(), batchDTO.getId());
        Assert.assertEquals(modelAndView.getModel().get("campaignId"), campaignDTO1.getId());
        Assert.assertEquals(modelAndView.getModel().get("campaign"), campaignDTO1);
        Assert.assertEquals(modelAndView.getModel().get("hybrids"), hybrids);
        Assert.assertEquals(modelAndView.getModel().get("batch"), batchDTO);
    }

    @Test
    public void findLotsAssociated_when_batchIdExist() {
        JsonResponse<LotBatchDTO> lotBatchDTOs = batchController.findLotsAssociated(batchDTO.getId());

        Assert.assertTrue(lotBatchDTOs.getSuccess());
        Assert.assertTrue(lotBatchDTOs.getRows().size() > 0);
    }

    @Test
    public void addLot_when_request_has_values() throws DataAccessException {

        Map request = new HashMap();
        request.put("lotId", 1);
        request.put("kgDsLotAssigned", "2");
        request.put("kgDS", "3");
        request.put("kgFNG", "4");
        request.put("bagProduced", "5");

        JsonResponse<LotBatchDTO> lotBatchDTOs = batchController.addLot(request);

        Assert.assertTrue(lotBatchDTOs.getSuccess());
        Assert.assertTrue(lotBatchDTOs.getItem() != null);
    }

    @Test
    public void addLot_whenError_returnJsonResponseWithStatusFalse() throws DataAccessException, KgDsAssignedInvalidException {
        Map request = new HashMap();
        request.put("lotId", 1);
        request.put("kgDsLotAssigned", "2");
        request.put("kgDS", "3");
        request.put("kgFNG", "4");
        request.put("bagProduced", "5");
        when(batchService.addLot(1, 2F, 3F, 4F, 5)).thenThrow(new KgDsAssignedInvalidException());

        JsonResponse<LotBatchDTO> lotBatchDTOs = batchController.addLot(request);
        Assert.assertFalse(lotBatchDTOs.getSuccess());
    }

    @Test
    public void save_when_request_has_value() {

        batchDTO.setHybridName("h1");
        batchDTO.setHybridId(1);
        batchDTO.setBagProduced(1);
        batchDTO.setCampaignId(1);
        batchDTO.setKgDS(1F);
        batchDTO.setLotBatches(lotBatchDTOs);

        JsonResponse<BatchDTO> batchDTOJsonResponse = batchController.save(batchDTO);
        Assert.assertTrue(batchDTOJsonResponse.getSuccess());
        Assert.assertTrue(batchDTOJsonResponse.getItem() != null);
    }

    @Test
    public void save_batchWithNameDuplicate_returnJsonResponseWithStatusFalse() throws BatchException {

        batchDTO.setHybridName("h1");
        batchDTO.setHybridId(1);
        batchDTO.setBagProduced(1);
        batchDTO.setCampaignId(1);
        batchDTO.setKgDS(1F);
        batchDTO.setLotBatches(lotBatchDTOs);

        when(batchService.save(any(BatchDTO.class))).thenThrow(new ExistsBatchWithNameException());

        JsonResponse<BatchDTO> batchDTOJsonResponse = batchController.save(batchDTO);
        Assert.assertFalse(batchDTOJsonResponse.getSuccess());
    }

    @Test
    @DirtiesContext
    public void save_withBatchExceptionInSave_returnJsonResponseWithStatusFalse() throws BatchException {

        batchDTO.setHybridName("h1");
        batchDTO.setHybridId(1);
        batchDTO.setBagProduced(1);
        batchDTO.setCampaignId(1);
        batchDTO.setKgDS(1F);
        batchDTO.setLotBatches(lotBatchDTOs);

        when(batchService.save(any(BatchDTO.class))).thenThrow(new BatchException());

        JsonResponse<BatchDTO> batchDTOJsonResponse = batchController.save(batchDTO);
        Assert.assertFalse(batchDTOJsonResponse.getSuccess());
    }

    @Test
    public void delete_when_request_has_value() {
        JsonResponse<BatchDTO> batchDTOJsonResponse = batchController.delete(1);
        Assert.assertTrue(batchDTOJsonResponse.getSuccess());
    }

    @Test
    @DirtiesContext
    public void delete_withBatchExceptionInDelte_returnJsonResponseWithStatusFalse() throws BatchException {
        doThrow(new BatchException()).when(batchService).delete(anyInt());
        JsonResponse<BatchDTO> batchDTOJsonResponse = batchController.delete(1);
        Assert.assertFalse(batchDTOJsonResponse.getSuccess());
    }
}

