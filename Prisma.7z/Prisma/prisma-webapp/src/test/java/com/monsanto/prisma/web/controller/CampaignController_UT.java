package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.ReceiveTonsDTO;
import com.monsanto.prisma.core.exception.*;
import com.monsanto.prisma.core.service.*;
import com.monsanto.prisma.web.dto.CountryDTO;
import com.monsanto.prisma.web.dto.CropDTO;
import com.monsanto.prisma.web.dto.RegionDTO;
import com.monsanto.prisma.web.security.SecurityHolderStrategy;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.servlet.ModelAndView;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;


/**
 * Created by BSBUON on 5/30/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class CampaignController_UT {

    @Mock
    private CampaignService campaignService;

    @Mock
    private CropService cropService;

    @Mock
    private MessageCurrentLocaleResolver message;

    @Mock
    private PlantService plantService;

    @Mock
    private RegionService regionService;

    @Mock
    private CountryService countryService;

    @Mock
    private SeasonService seasonService;

    @Mock
    private SecurityHolderStrategy securityHolderStrategy;

    @InjectMocks
    private CampaignController campaignController;


    private Campaign campaign1;
    private Campaign campaign2;
    private Campaign campaign3;

    private CampaignDTO campaignDTO1;
    private CampaignDTO campaignDTO2;
    private CampaignDTO campaignDTO3;

    private Crop crop;

    private Region region;

    private Country country;

    @Before
    public void setUp() throws CampaignException {

        crop = new Crop();
        crop.setId(1);
        crop.setName("SOJA");

        region = new Region();
        region.setId(1);
        region.setName("LAS");

        country = new Country();
        country.setId(1);
        country.setName("ARGENTINA");
        country.setRegion(region);

        Season season1 = new Season();
        season1.setId(1);
        season1.setName("season1");
        season1.setMaxCampaigns(1);
        season1.setCrop(crop);
        season1.setCountry(country);

        campaign1 = new Campaign();
        campaign1.setId(1);
        campaign1.setName("campaignName");
        campaign1.setCrop(crop);
        campaign1.setSeason(season1);
        campaign1.setObservations("observations");
        campaign1.setFilePath("filePath");
        campaign1.setIsActive(true);
        campaign1.setIsReal(true);
        campaign1.setCode("code");

        Lot lot1 = mock(Lot.class);
        lot1.setCampaign(campaign1);

        campaign2 = new Campaign();
        campaign2.setId(2);
        campaign2.setName("campaignName2");
        campaign2.setCrop(crop);
        campaign2.setSeason(season1);
        campaign2.setObservations("observations2");
        campaign2.setFilePath("filePath2");
        campaign2.setIsActive(true);
        campaign2.setIsReal(false);
        campaign2.setCode("code2");

        campaign3 = new Campaign();
        campaign3.setId(null);
        campaign3.setName("2013/2014");
        campaign3.setCrop(crop);
        campaign3.setSeason(season1);
        campaign3.setObservations(null);
        campaign3.setFilePath(null);
        campaign3.setIsActive(true);
        campaign3.setIsReal(true);
        campaign3.setCode("campaignCode");


        campaignDTO1 = new CampaignDTO(1, 1, "regionCode", 1, "ARGENTINA", 1, "SOJA", "2013/2014", "campaignCode", true, true);
        campaignDTO2 = new CampaignDTO(2, 1, "regionCode", 1, "ARGENTINA", 2, "MAIZ", "2013/2014", "campaignCode", true, true);
        campaignDTO3 = new CampaignDTO(3, 1, "regionCode", 1, "ARGENTINA", 1, "SOJA", "2013/2014", "campaignCode", true, true);

        when(campaignService.findAll()).thenReturn(Arrays.asList(campaign1, campaign2));
        when(campaignService.save(any(CampaignDTO.class))).thenReturn(campaign1);
        when(campaignService.delete(any(Integer.class))).thenReturn(campaign1);
        when(campaignService.update(any(CampaignDTO.class))).thenReturn(campaign1);
        when(cropService.findAll()).thenReturn(Arrays.asList(crop));
        when(regionService.findAll()).thenReturn(Arrays.asList(region));
        when(countryService.findAll()).thenReturn(Arrays.asList(country));
        when(campaignService.findByIdAndActiveLots(1)).thenReturn(campaignDTO1);
        when(cropService.findById(1)).thenReturn(crop);
        when(countryService.findById(1)).thenReturn(country);
        when(seasonService.findByCropAndCountry(crop, country)).thenReturn(season1);
        when(securityHolderStrategy.getCurrentUser()).thenReturn(null);

    }

    @Test
    public void test_init_Initialize_crops_regions_countries() {
        ModelAndView modelAndView = campaignController.init();

        Assert.assertTrue(((List<CropDTO>) modelAndView.getModel().get("crops")).size() == 1);
        Assert.assertEquals(((List<CropDTO>) modelAndView.getModel().get("crops")).get(0), new CropDTO(crop));

        Assert.assertTrue(((List) modelAndView.getModel().get("regions")).size() == 1);
        Assert.assertEquals(((List<RegionDTO>) modelAndView.getModel().get("regions")).get(0), new RegionDTO(region));

        Assert.assertFalse(((List) modelAndView.getModel().get("countries")).isEmpty());
        Assert.assertEquals(((List<CountryDTO>) modelAndView.getModel().get("countries")).get(0), new CountryDTO(country));


    }


    @Test
    public void testCallsServices_WhenListingCampaigns() throws Exception {

        JsonResponse<CampaignDTO> campaigns = campaignController.findAll();

        verify(this.campaignService, times(1)).findAll();

        assertTrue(campaigns.getRows().size() == 2);
        Assert.assertEquals(campaigns.getRows().get(0), new CampaignDTO(campaign1));
        Assert.assertEquals(campaigns.getRows().get(1), new CampaignDTO(campaign2));

    }

    @Test
    public void testCallSaveServices_WhenCallingSaveController() throws CampaignException {

        JsonResponse<CampaignDTO> response = campaignController.save(campaignDTO1);

        assertNotNull(response);
        assertTrue(response.getSuccess());
    }

    @Test
    public void testFailNotExistsSeason_WhenSaveCampaign() throws CampaignException, SeasonNotExistsException {

        when(campaignService.save(campaignDTO2)).thenThrow(new SeasonNotExistsException());
        JsonResponse<CampaignDTO> response = campaignController.save(campaignDTO2);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }

    @Test
    public void testFailNotExistsSeason_WhenUpdateCampaign() throws CampaignException, SeasonNotExistsException {

        when(campaignService.update(campaignDTO2)).thenThrow(new SeasonNotExistsException());
        JsonResponse<CampaignDTO> response = campaignController.update(campaignDTO2);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }


    @Test
    public void testResponseSuccess_WhenCallingUpdateController() {
        JsonResponse<CampaignDTO> response = campaignController.update(campaignDTO1);

        assertNotNull(response);
        assertTrue(response.getSuccess());
    }

    @Test
    public void testResponseFailCampaignException_WhenCallingDeleteCampaign() throws CampaignException {
        doThrow(CampaignException.class).when(campaignService).delete(1);
        JsonResponse<CampaignDTO> response = campaignController.delete(1);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }

    @Test
    public void testResponseSuccess_WhenCallingDeleteCampaign() throws CampaignException {
        JsonResponse<CampaignDTO> response = campaignController.delete(1);

        assertNotNull(response);
        assertTrue(response.getSuccess());
    }

    @Test
    public void testFailExistsSeason_WhenCallingDeleteCampaign() throws CampaignException {
        doThrow(ExistsLotsForThisCampaignException.class).when(campaignService).delete(2);
        JsonResponse<CampaignDTO> response = campaignController.delete(2);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }


    @Test
    public void testFindByIDCampaign_whenReturnOnlyCampaignExpected() {
        JsonResponse<CampaignDTO> response = campaignController.findById(1);

        verify(campaignService, times(1)).findByIdAndActiveLots(1);

        assertNotNull(response.getItem());
        assertTrue(response.getSuccess());
    }

    @Test
    public void testFindNull_whenFindCampaignWhichDontExists() {
        when(campaignService.findByIdAndActiveLots(3)).thenReturn(null);
        JsonResponse<CampaignDTO> response = campaignController.findById(3);

        assertNull(response.getItem());
        assertFalse(response.getSuccess());
    }

    @Test
    public void testFailMaxCampaignsForSeasonException_WhenUpdateCampaign() throws CampaignException, SeasonNotExistsException {

        when(campaignService.update(campaignDTO2)).thenThrow(new MaxCampaignsForSeasonException("test"));
        JsonResponse<CampaignDTO> response = campaignController.update(campaignDTO2);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }

    @Test
    public void testFailInactiveToUpdateCampaignException_WhenUpdateCampaign() throws CampaignException, SeasonNotExistsException {

        when(campaignService.update(campaignDTO2)).thenThrow(new InactiveToUpdateCampaignException());
        JsonResponse<CampaignDTO> response = campaignController.update(campaignDTO2);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }

    @Test
    public void testFailCampaignUnableToChangeException_WhenUpdateCampaign() throws CampaignException, SeasonNotExistsException {

        when(campaignService.update(campaignDTO2)).thenThrow(new CampaignUnableToChangeException());
        JsonResponse<CampaignDTO> response = campaignController.update(campaignDTO2);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }

    @Test
    public void testFailMaxCampaignsForSeasonException_WhenSaveCampaign() throws CampaignException, SeasonNotExistsException {

        when(campaignService.save(campaignDTO2)).thenThrow(new MaxCampaignsForSeasonException("test"));
        JsonResponse<CampaignDTO> response = campaignController.save(campaignDTO2);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }

    @Test
    public void testFailCampaignException_WhenSaveCampaign() throws CampaignException, SeasonNotExistsException {

        when(campaignService.save(campaignDTO2)).thenThrow(new CampaignException());
        JsonResponse<CampaignDTO> response = campaignController.save(campaignDTO2);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }

    @Test
    public void changeState_when_id_exist() {
        JsonResponse<CampaignDTO> response = campaignController.changeState(campaign1.getId());
        assertNotNull(response);
        assertTrue(response.getSuccess());
    }

    @Test
    public void save_withCampaignNameDuplicated_returnJsonResponseWithStatusFalse() throws CampaignException {
        when(campaignService.save(any(CampaignDTO.class))).thenThrow(new CampaignNameDuplicatedException());
        JsonResponse jsonResponse = campaignController.save(new CampaignDTO());
        Assert.assertFalse(jsonResponse.getSuccess());
    }

    @Test
    public void update_withInvalidCampaignPath_returnJsonResponseWithStatusFalse() throws CampaignException {
        when(campaignService.update(any(CampaignDTO.class))).thenThrow(new InvalidCampaignPathException("exception"));
        JsonResponse jsonResponse = campaignController.update(new CampaignDTO());
        Assert.assertFalse(jsonResponse.getSuccess());
    }

    @Test
    public void update_withCampaignNameDuplicated_returnJsonResponseWithStatusFalse() throws CampaignException {
        when(campaignService.update(any(CampaignDTO.class))).thenThrow(new CampaignNameDuplicatedException());
        JsonResponse jsonResponse = campaignController.update(new CampaignDTO());
        Assert.assertFalse(jsonResponse.getSuccess());
    }

}
