package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Country;
import com.monsanto.prisma.core.domain.Region;
import com.monsanto.prisma.core.service.CountryService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.List;

import static junit.framework.TestCase.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Created by BSBUON on 6/2/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class CountryController_UT {

    @Mock
    private CountryService countryService;

    @InjectMocks
    private CountryController countryController;

    private Region region;
    private Country country1;
    private Country country2;


    @Before
    public void setUp(){
        region = new Region();
        region.setId(1);
        region.setName("LAS");

        country1 = new Country();
        country1.setId(1);
        country1.setName("ARGENTINA");
        country1.setRegion(region);

        country2 = new Country();
        country2.setId(2);
        country2.setName("BRAZIL");
        country2.setRegion(region);

        when(countryService.findByRegionId(1)).thenReturn(Arrays.asList(country1, country2));
    }


    @Test
    public void testListCountries(){
        Region region = new Region();
        region.setId(1);
        List<Country> countries = countryController.findByRegionId(region);
        assertEquals(countries.size(), 2);
    }
}
