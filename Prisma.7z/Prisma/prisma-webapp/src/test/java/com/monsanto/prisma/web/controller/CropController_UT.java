package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Crop;
import com.monsanto.prisma.core.service.CropService;
import com.monsanto.prisma.web.dto.CropDTO;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Arrays;


import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

/**
 * Created by BSBUON on 6/2/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class CropController_UT {

    @Mock
    private CropService cropService;

    @InjectMocks
    private CropController cropController;

    @Before
    public void setUp(){

        Crop crop1 = new Crop();
        crop1.setId(1);
        crop1.setName("SOJA");

        Crop crop2 = new Crop();
        crop2.setId(2);
        crop2.setName("MAIZ");

        when(cropService.findAll()).thenReturn(Arrays.asList(crop1,crop2));

    }

    @Test
    public void testFindAllCrops_WhenSearchCrops(){
        JsonResponse<CropDTO> result =  cropController.findAll();
        assertTrue(result.getSuccess());
        assertEquals(result.getRows().size(),2);
        assertNotNull(result.getRows().get(0).getName());

    }

    @Test
    public void testFailFindAllCrops_WhenSearchCrops(){
        when(cropService.findAll()).thenReturn(null);
        JsonResponse<CropDTO> result =  cropController.findAll();
        assertFalse(result.getSuccess());
        assertNotNull(result.getMessage());
    }
}
