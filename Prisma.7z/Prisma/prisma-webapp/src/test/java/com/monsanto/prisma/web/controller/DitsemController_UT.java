package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.LotDitsem;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.DitsemService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import static junit.framework.TestCase.assertNotNull;
import static org.mockito.Mockito.*;

/**
 * Created by BSBUON on 6/2/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class DitsemController_UT {

    @InjectMocks
    private DitsemController ditsemController;

    @Mock
    private CampaignService campaignService;

    @Mock
    private MessageCurrentLocaleResolver message;

    @Mock
    private MultipartHttpServletRequest multipartHttpServletRequest;

    @Mock
    private DitsemService ditsemService;

    @Mock
    private LotService lotService;

    @Before
    public void setUp() throws BusinessException {
        CampaignDTO campaign = Mockito.mock(CampaignDTO.class);
        when(campaignService.findByIdAndActiveLots(1)).thenReturn(campaign);
        LotDitsem lotDitsem = new LotDitsem();
        lotDitsem.setId(100);
        when(ditsemService.addLotFromDitsem(1)).thenReturn(lotDitsem);
        when(ditsemService.addLotFromDitsem(2)).thenReturn(null);
        when(message.getMessage("ditsem.empty")).thenReturn("Ditsem no existe.");

    }

    @Test
    public void testCallInit() {
        ModelAndView modelAndView = ditsemController.init(any(Integer.class));
        assertNotNull(modelAndView);
        Assert.assertEquals("ditsem", modelAndView.getViewName());
    }

    @Test
    public void addLotsFromDitsem_whenExitsNewLotsInDitsem() throws BusinessException {
        JsonResponse<LotDitsem> lotDitsemJsonResponse = ditsemController.addLotsFromDitsem(1);
        Assert.assertEquals(new Integer(100), lotDitsemJsonResponse.getItem().getId());
    }

    @Test
    public void addLotsFromDitsem_whenNotExitsInDitsem() throws BusinessException {
        JsonResponse<LotDitsem> lotDitsemJsonResponse = ditsemController.addLotsFromDitsem(2);
//        Assert.assertEquals("Ditsem no existe.", lotDitsemJsonResponse.getMessage());
        Assert.assertTrue(!lotDitsemJsonResponse.getSuccess());
    }

    @Test
    public void uploadFile_returnsLotDitsemWhenAddLotFromDitsemIsOk() throws BusinessException {
        LotDitsem lotDitsem = mock(LotDitsem.class);
        when(ditsemService.addLotFromDitsem(1)).thenReturn(lotDitsem);

        JsonResponse<? extends Object> result = ditsemController.addLotsFromDitsem(1);

        verify(ditsemService, times(1)).addLotFromDitsem(1);
        Assert.assertEquals(result.getItem(), lotDitsem);
    }

    @Test
    public void uploadFile_NotSuccessResponseWhenFileIsEmpty() throws BusinessException {
        when(ditsemService.addLotFromDitsem(1)).thenReturn(null);
        when(message.getMessage("ditsem.empty")).thenReturn("test");

        JsonResponse<? extends Object> result = ditsemController.addLotsFromDitsem(1);

        verify(ditsemService, times(1)).addLotFromDitsem(1);
        verify(message, times(1)).getMessage("ditsem.empty");
        Assert.assertFalse(result.getSuccess());
    }


    @Test
    public void init_withModelOk_when_has_request() {

        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        ModelAndView modelAndView = ditsemController.init(request);

        Assert.assertEquals("ditsem", modelAndView.getViewName());
    }
}
