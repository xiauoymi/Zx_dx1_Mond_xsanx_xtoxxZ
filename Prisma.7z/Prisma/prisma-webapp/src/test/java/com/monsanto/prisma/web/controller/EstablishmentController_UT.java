package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Establishment;
import com.monsanto.prisma.core.dto.ZoneDTO;
import com.monsanto.prisma.core.service.EstablishmentService;
import com.monsanto.prisma.core.service.ZoneService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mock;

/**
 * Created by EPESTE on 10/10/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class EstablishmentController_UT {
    @InjectMocks
    private EstablishmentController establishmentController;

    @Mock
    private EstablishmentService establishmentServiceMock;

    @Mock
    private ZoneService zoneService;

    private List<Establishment> establishmentList;

    @Before
    public void setUp() {
        establishmentList = new ArrayList<Establishment>();
        Establishment establishmentMock = mock(Establishment.class);
        establishmentList.add(establishmentMock);
    }

    @Test
    public void findAll_withEstablishment_returnEstablishmentList() {
        when(establishmentServiceMock.findAll()).thenReturn(establishmentList);

        JsonResponse jsonResponse = establishmentController.findAll();

        Mockito.verify(establishmentServiceMock, times(1)).findAll();

        Assert.assertTrue(jsonResponse.getRows() instanceof List);
        Assert.assertEquals(1, ((List) jsonResponse.getRows()).size());
    }

    @Test
    public void findAllZones_withZones_returnZoneList() {
        HttpServletRequest httpServletRequest = mock(HttpServletRequest.class);
        HttpSession httpSession = mock(HttpSession.class);
        when(httpServletRequest.getSession()).thenReturn(httpSession);
        when(httpSession.getAttribute("idCampaign")).thenReturn(1);


        when(zoneService.findByCampaign(1)).thenReturn(new ArrayList<ZoneDTO>());

        JsonResponse jsonResponse = establishmentController.findAllZones(httpServletRequest);

        Mockito.verify(zoneService, times(1)).findByCampaign(any(Integer.class));

        Assert.assertTrue(jsonResponse.getRows() instanceof List);
    }

}
