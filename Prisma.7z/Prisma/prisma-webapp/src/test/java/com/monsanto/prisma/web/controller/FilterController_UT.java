package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Filter;
import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.domain.UserFilter;
import com.monsanto.prisma.core.dto.FilterDTO;
import com.monsanto.prisma.core.dto.UserFilterDTO;
import com.monsanto.prisma.core.service.UserFilterService;
import com.monsanto.prisma.web.security.SecurityHolderStrategy;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.dao.DataIntegrityViolationException;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by EPESTE on 17/11/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class FilterController_UT {
    @InjectMocks
    private FilterController filterController;

    @Mock
    private UserFilterService userFilterService;

    @Mock
    private SecurityHolderStrategy securityHolderStrategy;

    private UserFilterDTO userFilterDTO;

    private UserFilter userFilter;

    @Before
    public void setUp() {
        when(securityHolderStrategy.getCurrentUser()).thenReturn(new User());

        userFilterDTO = new UserFilterDTO();
        userFilterDTO.setId(1);
        userFilterDTO.setName("name");
        userFilterDTO.setDescription("description");
        List<FilterDTO> filterDTOList = new ArrayList<FilterDTO>();
        FilterDTO filterDTO = new FilterDTO();
        filterDTOList.add(filterDTO);
        userFilterDTO.setFilterList(filterDTOList);

        userFilter = new UserFilter(userFilterDTO);
    }

    @Test
    public void addNewFilter_withUserFilter_returnJsonResponseWithStatusOk() {
        when(userFilterService.save(any(UserFilter.class))).thenReturn(new UserFilter());

        JsonResponse jsonResponse = filterController.addNewFilter(userFilterDTO);

        verify(securityHolderStrategy, times(1)).getCurrentUser();
        verify(userFilterService, times(1)).save(any(UserFilter.class));
        Assert.assertEquals(true, jsonResponse.getSuccess());
    }

    @Test
    public void addNewFilter_withErrorInSave_returnJsonResponseWithStatusError() {
        when(userFilterService.save(any(UserFilter.class))).thenThrow(new DataIntegrityViolationException("exception"));

        JsonResponse jsonResponse = filterController.addNewFilter(userFilterDTO);

        verify(securityHolderStrategy, times(1)).getCurrentUser();
        verify(userFilterService, times(1)).save(any(UserFilter.class));
        Assert.assertEquals(false, jsonResponse.getSuccess());
    }

    @Test
    public void findFilterByUserAndId_withUserFilter_returnJsonResponseWithFilterList() {
        when(userFilterService.findByUserAndId(any(User.class), any(Integer.class))).thenReturn(userFilter);

        JsonResponse jsonResponse = filterController.findFilterByUserAndId(userFilterDTO);

        verify(securityHolderStrategy, times(1)).getCurrentUser();
        verify(userFilterService, times(1)).findByUserAndId(any(User.class), any(Integer.class));
        Assert.assertEquals(true, jsonResponse.getSuccess());
        Assert.assertEquals(1, jsonResponse.getRows().size());
    }

    @Test
    public void findAllByUser_withUserWithFilters_returnJsonResponseWithFilterList() {
        List<UserFilter> userFilterList = new ArrayList<UserFilter>();
        userFilterList.add(userFilter);
        when(userFilterService.findAllByUser(any(User.class))).thenReturn(userFilterList);

        JsonResponse jsonResponse = filterController.findAllByUser();

        verify(securityHolderStrategy, times(1)).getCurrentUser();
        verify(userFilterService, times(1)).findAllByUser(any(User.class));
        Assert.assertEquals(true, jsonResponse.getSuccess());
        Assert.assertEquals(1, jsonResponse.getRows().size());
    }

    @Test
    public void delete_withFilter_returnJsonResponseWithSuccessOk() {
        when(userFilterService.delete(any(Integer.class))).thenReturn(userFilter);

        FilterDTO filterDTO = new FilterDTO();
        filterDTO.setId(1);
        JsonResponse jsonResponse = filterController.delete(filterDTO);

        verify(userFilterService, times(1)).delete(any(Integer.class));
        Assert.assertEquals(true, jsonResponse.getSuccess());
    }

    @Test
    public void delete_withFilter_returnJsonResponseWithSuccessError() {
        when(userFilterService.delete(any(Integer.class))).thenThrow(new DataIntegrityViolationException("asdasd"));

        FilterDTO filterDTO = new FilterDTO();
        filterDTO.setId(1);
        JsonResponse jsonResponse = filterController.delete(filterDTO);

        verify(userFilterService, times(1)).delete(any(Integer.class));
        Assert.assertEquals(false, jsonResponse.getSuccess());
    }
}
