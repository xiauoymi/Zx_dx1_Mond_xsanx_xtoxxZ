package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Forecast;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.ForecastDTO;
import com.monsanto.prisma.core.dto.ForecastReportDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.ForecastService;
import com.monsanto.prisma.core.service.LotService;

import com.monsanto.prisma.web.utils.JsonResponse;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by EPESTE on 04/12/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class ForecastController_UT {
    @InjectMocks
    private ForecastController forecastController;

    @Mock
    private ForecastService forecastService;

    @Mock
    private CampaignService campaignService;

    @Mock
    private LotService lotService;

    @Test
    public void init_campaignWithForecast_returnPage() {
        Forecast forecast = new Forecast();
        forecast.setDaysRw(1);
        forecast.setDaysDs(4);

        when(campaignService.findByIdAndActiveLots(any(Integer.class))).thenReturn(new CampaignDTO());
        when(lotService.findTotalLotsAndHas(any(Integer.class))).thenReturn(new TotalLotsDTO(2l, 10d, 15d));
        when(forecastService.findByCampaignId(any(Integer.class))).thenReturn(forecast);

        ModelAndView page = forecastController.init(1);

        verify(campaignService, times(1)).findByIdAndActiveLots(anyInt());
        verify(lotService, times(1)).findTotalLotsAndHas(anyInt());
        verify(forecastService, times(1)).findByCampaignId(anyInt());

        Assert.assertNotNull(page);
        Assert.assertEquals("forecast", page.getViewName());
    }

    @Test
    public void init_campaignWithForecastMethodGet_returnPage() {
        Forecast forecast = new Forecast();
        forecast.setDaysRw(1);
        forecast.setDaysDs(4);

        when(campaignService.findByIdAndActiveLots(any(Integer.class))).thenReturn(new CampaignDTO());
        when(lotService.findTotalLotsAndHas(any(Integer.class))).thenReturn(new TotalLotsDTO(2l, 10d, 15d));
        when(forecastService.findByCampaignId(any(Integer.class))).thenReturn(forecast);

        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getSession().getAttribute("errorMessage")).thenReturn("error");
        ModelAndView page = forecastController.init(request);

        verify(campaignService, times(1)).findByIdAndActiveLots(anyInt());
        verify(lotService, times(1)).findTotalLotsAndHas(anyInt());
        verify(forecastService, times(1)).findByCampaignId(anyInt());

        Assert.assertNotNull(page);
        Assert.assertEquals("forecast", page.getViewName());
    }

    @Test
    public void handleError_request() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getAttribute("campaignId")).thenReturn(1);
        String page = forecastController.forecastError(request);

        Assert.assertEquals("redirect:/forecast/campaign/", page);
    }

    @Test
    public void update_withForecastOk_returnJsonResponseWithStatusOk() throws BusinessException {
        when(forecastService.update(any(ForecastDTO.class))).thenReturn(new Forecast());

        JsonResponse jsonResponse = forecastController.update(new ForecastDTO());

        verify(forecastService, times(1)).update(any(ForecastDTO.class));

        Assert.assertEquals(true, jsonResponse.getSuccess());
        Assert.assertEquals("prisma.forecast.ok", jsonResponse.getMessage());
    }

    @Test
    public void update_withError_returnJsonResponseWithStatusError() throws BusinessException {
        when(forecastService.update(any(ForecastDTO.class))).thenThrow(new BusinessException());

        JsonResponse jsonResponse = forecastController.update(new ForecastDTO());

        verify(forecastService, times(1)).update(any(ForecastDTO.class));

        Assert.assertEquals(false, jsonResponse.getSuccess());
        Assert.assertEquals("prisma.forecast.error", jsonResponse.getMessage());
    }

    @Test
    public void receiveTonsToExcel_withRwDsAndFngInformation_forwardPage() throws DataAccessException {
        when(forecastService.getReportInformation(anyInt())).thenReturn(new ForecastReportDTO());

        ModelAndView page = forecastController.receiveTonsToExcel(1);

        verify(forecastService, times(1)).getReportInformation(anyInt());
        Assert.assertEquals("forecastReportExcel", page.getViewName());
    }
}
