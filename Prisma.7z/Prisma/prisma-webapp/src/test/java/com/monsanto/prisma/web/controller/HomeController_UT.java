package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.EstablishmentService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.web.security.SecurityHolderStrategy;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by BSBUON on 6/2/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class HomeController_UT {

    @Mock
    private LotService lotService;

    @InjectMocks
    private HomeController homeController;

    @Mock
    private CampaignService campaignService;

    @Mock
    private EstablishmentService establishmentService;

    private Model model;

    private Map mapModel = new HashMap();

    private Lot lot1 = mock(Lot.class);
    private Lot lot2 = mock(Lot.class);

    @Mock
    private SecurityHolderStrategy securityHolderStrategy;

    private User user;

    @Mock
    HttpServletRequest request;


    @Before
    public void setUp() throws DataAccessException {

        when(request.getSession()).thenReturn(new MockHttpSession());

        Crop crop = new Crop();
        crop.setId(1);
        crop.setName("SOJA");

        Region region = new Region();
        region.setId(1);
        region.setName("LAS");

        Country country = new Country();
        country.setId(1);
        country.setName("ARGENTINA");
        country.setRegion(region);

        Season season1 = new Season();
        season1.setId(1);
        season1.setName("season1");
        season1.setMaxCampaigns(1);
        season1.setCrop(crop);
        season1.setCountry(country);

        Campaign campaign = new Campaign();
        campaign.setId(1);
        campaign.setName("campaignName");
        campaign.setCrop(crop);
        campaign.setSeason(season1);
        campaign.setObservations("observations");
        campaign.setFilePath("filePath");
        campaign.setIsActive(true);
        campaign.setIsReal(true);
        campaign.setCode("code");

        model = new Model() {

            @Override
            public Model addAttribute(String s, Object o) {
                return null;
            }

            @Override
            public Model addAttribute(Object o) {
                return null;
            }

            @Override
            public Model addAllAttributes(Collection<?> objects) {
                return null;
            }

            @Override
            public Model addAllAttributes(Map<String, ?> stringMap) {
                return null;
            }

            @Override
            public Model mergeAttributes(Map<String, ?> stringMap) {
                return null;
            }

            @Override
            public boolean containsAttribute(String s) {
                return false;
            }

            @Override
            public Map<String, Object> asMap() {
                return mapModel;
            }
        };

        user = new User("bsbuon");
        user.setEnabled(true);
        user.setFullName("");
        user.setRegions(Arrays.asList(region));

        when(securityHolderStrategy.getCurrentUser()).thenReturn(null);

        when(lot1.getCampaign()).thenReturn(campaign);
        when(lot2.getCampaign()).thenReturn(campaign);
        when(lotService.findActiveLotsForCurrentActiveCampaign()).thenReturn(Arrays.asList(lot1, lot2));
        when(lotService.findActiveLotsByCampaignId(campaign.getId())).thenReturn(Arrays.asList(lot1, lot2));


        when(campaignService.findByIsActive()).thenReturn(Arrays.asList(campaign));
        when(campaignService.findCampaignActiveByUser(null)).thenReturn(campaign);
    }

    @Test
    public void testFindLots_WhenCallHomeController() throws DataAccessException {
        RedirectAttributes redirect = new RedirectAttributesModelMap();
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);

        String result = homeController.home(model, redirect, request);

        assertNotNull(result);

        CampaignDTO campaignDTO = (CampaignDTO) redirect.getFlashAttributes().get("campaign");
        assertNotNull(campaignDTO);
    }
}
