package com.monsanto.prisma.web.controller;


import com.monsanto.prisma.core.domain.HumidityReport;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.HumidityReportDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.HumidityReportService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.hibernate.Session;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.powermock.api.mockito.PowerMockito.mock;

/**
 * Created by EPESTE on 21/08/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class HumidityController_UT {
    @InjectMocks
    private HumidityController humidityControllerMock;

    @Mock
    private CampaignService campaignServiceMock;

    @Mock
    private HumidityReportService humidityReportServiceMock;

    @Mock
    private HttpServletRequest httpServletRequestMock;

    @Mock
    private LotService lotService;

    @Before
    public void setUp() throws IOException, InvalidFormatException, DataAccessException, BusinessException {
        when(campaignServiceMock.findByIdAndActiveLots(1)).thenReturn(new CampaignDTO());

        HumidityReport humidityReportMock = mock(HumidityReport.class);
        when(humidityReportMock.getPathFile()).thenReturn("\\dev\\");
        when(humidityReportMock.getDateProccess()).thenReturn(new Date());
        when(humidityReportMock.getModified()).thenReturn(2);
        when(humidityReportMock.getOmitted()).thenReturn(1);
        when(humidityReportServiceMock.importFile(1)).thenReturn(humidityReportMock);

        HttpSession httpSessionMock = mock(HttpSession.class);
        when(httpSessionMock.getAttribute("idCampaign")).thenReturn(1);
        when(httpServletRequestMock.getSession()).thenReturn(httpSessionMock);

    }

    @Test
    public void home_withRequest_forwardPage() {
        ModelAndView page = humidityControllerMock.home(httpServletRequestMock);

        verify(campaignServiceMock, times(1)).findByIdAndActiveLots(1);

        Assert.assertEquals("importAverageHumidity", page.getViewName());
        Assert.assertEquals(1, page.getModel().get("campaignId"));
        Assert.assertTrue(page.getModel().get("campaign") instanceof CampaignDTO);
    }

    @Test
    public void home_withCampaign_forwardPage() {
        ModelAndView page = humidityControllerMock.home(1);

        verify(campaignServiceMock, times(1)).findByIdAndActiveLots(1);

        Assert.assertEquals("importAverageHumidity", page.getViewName());
        Assert.assertEquals(1, page.getModel().get("campaignId"));
        Assert.assertTrue(page.getModel().get("campaign") instanceof CampaignDTO);
    }

    @Test
    public void importHumidityReport_withCampaign_returnHumidityReportDTO() throws IOException, InvalidFormatException, DataAccessException, BusinessException {
        JsonResponse<HumidityReportDTO> jsonResponse = humidityControllerMock.importHumidityReport(1);

        verify(humidityReportServiceMock, times(1)).importFile(any(Integer.class));

        HumidityReportDTO humidityReportDTOResponse = jsonResponse.getItem();
        Assert.assertEquals("\\dev\\", humidityReportDTOResponse.getPathFile());
        Assert.assertTrue(humidityReportDTOResponse.getDateProccess() instanceof Date);
        Assert.assertEquals(2, humidityReportDTOResponse.getModified());
        Assert.assertEquals(1, humidityReportDTOResponse.getOmitted());
    }

    @Test
    public void importHumidityReport_withErrorInImport_returnHumidityReportDTO() throws IOException, InvalidFormatException, DataAccessException, BusinessException {
        when(humidityReportServiceMock.importFile(1)).thenThrow(new BusinessException("ERROR"));
        JsonResponse<HumidityReportDTO> jsonResponse = humidityControllerMock.importHumidityReport(1);

        verify(humidityReportServiceMock, times(1)).importFile(any(Integer.class));

        Assert.assertFalse(jsonResponse.getSuccess());
    }

}
