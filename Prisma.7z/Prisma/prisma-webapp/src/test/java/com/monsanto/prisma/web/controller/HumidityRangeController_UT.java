package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.HumidityRangeDTO;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.HumidityRangeService;
import com.monsanto.prisma.core.service.HybridService;
import com.monsanto.prisma.core.service.LotHumidityService;
import com.monsanto.prisma.core.service.ZoneService;
import com.monsanto.prisma.web.dto.HumidityRangeFilterDTO;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

/**
 * Created by PGSETT on 10/07/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class HumidityRangeController_UT {

    @Mock
    private HumidityRangeService humidityRangeService;

    @Mock
    private HybridService hybridService;

    @Mock
    private ZoneService zoneService;

    @Mock
    private MessageCurrentLocaleResolver message;

    @InjectMocks
    private HumidityRangeController humidityRangeController;

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private LotHumidityService lotHumidityService;

    @Before
    public void setUp() throws Exception {

        HumidityRange humidityRange1 = new HumidityRange();
        Hybrid hybrid1 = new Hybrid();

        HybridType hybridType1 = new HybridType();
        hybridType1.setId(1);
        hybridType1.setName("TIPO1");

        hybrid1.setHybridType(hybridType1);
        hybrid1.setId(1);
        hybrid1.setName("HYBRID1");

        humidityRange1.setHybrid(hybrid1);

        Zone zone1 = new Zone();
        zone1.setId(1);
        zone1.setCode("ZONE1");

        humidityRange1.setId(1);
        humidityRange1.setZone(zone1);
        humidityRange1.setHumidityMin(new Double(1));
        humidityRange1.setHumidityMax(new Double(99));

        List<HumidityRange> humidityRangeList = new ArrayList<HumidityRange>();
        humidityRangeList.add(humidityRange1);

        List<Zone> zoneList = new ArrayList<Zone>();
        zoneList.add(0, zone1);
        List<Hybrid> hybridList = new ArrayList<Hybrid>();
        hybridList.add(0, hybrid1);


        List<LotHumidity> lotHumidities = new ArrayList<LotHumidity>();
        LotHumidity lotHumidity = new LotHumidity();
        lotHumidity.setId(1);
        lotHumidity.setSampleDate(new Date());
        lotHumidity.setHumidity(new Float(44));

        Lot lot1 = new Lot();
        lot1.setId(1);
        lot1.setLotCode("OQ577L2A");
        lot1.setEstablishment(new Establishment());
        lot1.getEstablishment().setZone(zone1);
        lot1.setHybrid(hybrid1);
        lot1.getHybrid().setHybridType(hybridType1);
        lot1.setCampaign(new Campaign());

        lotHumidity.setLot(lot1);
        lotHumidities.add(lotHumidity);

        when(humidityRangeService.findAll()).thenReturn(humidityRangeList);
        when(humidityRangeService.findById(1)).thenReturn(humidityRange1);
        when(humidityRangeService.findByHybrid("HYBRID1")).thenReturn(humidityRangeList);
        when(zoneService.findAll()).thenReturn(zoneList);
        when(zoneService.findByCode("ZONE1")).thenReturn(zone1);
        when(hybridService.findAll()).thenReturn(hybridList);
        when(hybridService.findById(1)).thenReturn(hybrid1);
        when(lotHumidityService.findByHybridZone(hybrid1, zone1)).thenReturn(lotHumidities);
        when(humidityRangeService.findById(2)).thenReturn(new HumidityRange());
    }

    @Test
    public void testFindHumidityRange_initController() {
        ModelAndView result = humidityRangeController.init();
        assertNotNull(result);
        assertTrue(result.getModel().size() > 0);
    }

    @Test
    public void testFindHumidityRange_whenFindAll() {
        JsonResponse<HumidityRangeDTO> result = humidityRangeController.findAll();

        assertNotNull(result);
        assertTrue(result.getSuccess());
    }


    @Test
    public void testFindHumidityRange_whenSearchById() {
        JsonResponse<HumidityRangeDTO> result = humidityRangeController.findById(1);

        assertNotNull(result);
        assertTrue(result.getSuccess());
    }

    @Test
    @DirtiesContext
    public void testFindHumidityRange_whenSearchByIdNotSuccess() {
        JsonResponse<HumidityRangeDTO> result = humidityRangeController.findById(3);

        assertNotNull(result);
        assertFalse(result.getSuccess());
    }

    @Test
    public void testFindHumidityRange_whenSearchByIdThrowException() throws DataAccessException {
        when(humidityRangeService.findById(1)).thenThrow(new DataAccessException());
        JsonResponse<HumidityRangeDTO> result = humidityRangeController.findById(1);

        assertNotNull(result);
        assertFalse(result.getSuccess());
    }

    @Test
    public void testFindAll_whenThrowException() throws DataAccessException {
        when(humidityRangeService.findAll()).thenThrow(new DataAccessException());
        JsonResponse<HumidityRangeDTO> result = humidityRangeController.findAll();

        assertNotNull(result);
        assertFalse(result.getSuccess());
    }


    @Test
    public void testFindHumidityRange_whenControllerFilter() throws DataAccessException {

        HumidityRangeFilterDTO humidityRangeDTO = new HumidityRangeFilterDTO();
        humidityRangeDTO.setHybridName("HYBRID1");

        JsonResponse<HumidityRangeFilterDTO> result = humidityRangeController.filter(humidityRangeDTO);

        assertNotNull(result);
        assertTrue(result.getSuccess());
    }

    @Test
    public void testFindHumidityRange_whenControllerNotFilter() throws DataAccessException {

        HumidityRangeFilterDTO humidityRangeDTO = new HumidityRangeFilterDTO();
        humidityRangeDTO.setHybridName("JJ");

        JsonResponse<HumidityRangeFilterDTO> result = humidityRangeController.filter(humidityRangeDTO);

        assertNotNull(result);
        assertFalse(result.getSuccess());
    }

    @Test
    public void testSaveHumidityRange_whenExist() throws DataAccessException {

        HumidityRange humidityRange = humidityRangeService.findById(1);
        humidityRange.setId(null);
        humidityRange.setHumidityMin(new Double(2));
        humidityRange.setHumidityMax(new Double(33));
        HumidityRangeDTO humidityRangeDTO = new HumidityRangeDTO(humidityRange);

        JsonResponse<HumidityRangeDTO> result = humidityRangeController.save(humidityRangeDTO);

        assertNotNull(result);
        assertTrue(result.getSuccess());
    }

    @Test
    public void testUpdateHumidityRange_whenExist() throws DataAccessException {

        HumidityRange humidityRange = humidityRangeService.findById(1);
        humidityRange.setId(1);
        humidityRange.setHumidityMin(new Double(2));
        humidityRange.setHumidityMax(new Double(33));
        HumidityRangeDTO humidityRangeDTO = new HumidityRangeDTO(humidityRange);

        JsonResponse<HumidityRangeDTO> result = humidityRangeController.update(humidityRangeDTO);

        assertNotNull(result);
        assertTrue(result.getSuccess());
    }

    @Test
    public void testDeleteHumidityRange_whenLotHumidityExist() throws DataAccessException {


        JsonResponse<HumidityRangeDTO> result = humidityRangeController.delete(1);

        assertNotNull(result);
        assertFalse(result.getSuccess());
    }

    @Test
    public void testDeleteHumidityRange_whenLotHumidityNotExist() throws DataAccessException {
        JsonResponse<HumidityRangeDTO> result = humidityRangeController.delete(2);

        assertNotNull(result);
        assertTrue(result.getSuccess());
    }


}
