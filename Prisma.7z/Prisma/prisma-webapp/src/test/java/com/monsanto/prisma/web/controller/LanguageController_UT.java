package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.web.utils.JsonResponse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * Created by EPESTE on 10/10/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class LanguageController_UT {

    private LanguageController languageController;

    @Before
    public void setUp() {
        languageController = new LanguageController();
    }

    @Test
    public void getLanguage_withEnglishLanguage_returnJsonResponde() {
        JsonResponse jsonResponse = languageController.getLanguage("es,en;q=0.8,en-US;q=0.6");

        Assert.assertEquals("es,en;q=0.8,en-US;q=0.6", jsonResponse.getItem());
    }

}
