package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.*;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.*;
import com.monsanto.prisma.core.workflow.ApplicationProcessManager;
import com.monsanto.prisma.core.workflow.ProcessWithErrorException;
import com.monsanto.prisma.web.dto.LotListDTO;
import com.monsanto.prisma.web.security.SecurityHolderStrategy;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.context.ApplicationContext;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

/**
 * Created by BSBUON on 6/9/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class LotController_UT {

    @Mock
    private MessageCurrentLocaleResolver message;

    @Mock
    private LotService lotService;

    @Mock
    private LotBatchService lotBatchService;


    @Mock
    private LotHumidityService lotHumidityServiceMock;

    @Mock
    private CampaignService campaignService;

    @InjectMocks
    private LotController lotController = new LotController();

    @InjectMocks
    private ApplicationProcessManager processManager = new ApplicationProcessManager();

    @Mock
    private ApplicationContext applicationContext;

    @Mock
    private EstablishmentService establishmentService;

    @Mock
    private SecurityHolderStrategy securityHolderStrategy;

    @Mock
    private HybridService hybridServiceMock;

    private Lot lot2;

    private LotDTO lotDTO;
    private Lot lot1;
    private Campaign campaign1;
    private Crop crop;
    private Region region;
    private Country country;
    private User user;

    private Model model;

    private List<Lot> lotList;

    @Before
    public void setUp() throws Exception {
        crop = new Crop();
        crop.setId(1);
        crop.setName("SOJA");

        region = new Region();
        region.setId(1);
        region.setName("LAS");

        country = new Country();
        country.setId(1);
        country.setName("ARGENTINA");
        country.setRegion(region);

        Season season1 = new Season();
        season1.setId(1);
        season1.setName("season1");
        season1.setMaxCampaigns(1);
        season1.setCrop(crop);
        season1.setCountry(country);

        lot1 = new Lot();
        lot1.setId(1);
        lot1.setLotCode("OQ577L2A");
        lot1.setEstablishment(new Establishment());
        lot1.getEstablishment().setZone(new Zone());
        lot1.getEstablishment().getZone().setArea(new Area());
        lot1.setHybrid(new Hybrid());
        lot1.getHybrid().setHybridType(new HybridType());
        lot1.setUser(new User());
        lot1.setCampaign(new Campaign());

        campaign1 = new Campaign();
        campaign1.setId(1);
        campaign1.setName("campaignName");
        campaign1.setCrop(crop);
        campaign1.setSeason(season1);
        campaign1.setObservations("observations");
        campaign1.setFilePath("filePath");
        campaign1.setIsActive(true);
        campaign1.setIsReal(true);
        campaign1.setCode("code");

        this.lot2 = new Lot();
        this.lot2.setId(2);
        this.lot2.setLotCode("OQ577L2B");
        this.lot2.setEstablishment(new Establishment());
        this.lot2.getEstablishment().setZone(new Zone());
        this.lot2.getEstablishment().getZone().setArea(new Area());
        this.lot2.setHybrid(new Hybrid());
        this.lot2.getHybrid().setHybridType(new HybridType());
        this.lot2.setUser(new User());
        this.lot2.setCampaign(campaign1);

        user = new User("anonymous");
        user.setEnabled(true);
        user.setId(1L);
        user.setFullName("");
        user.setRegions(Arrays.asList(region));

        model = new Model() {

            @Override
            public Model addAttribute(String s, Object o) {
                return null;
            }

            @Override
            public Model addAttribute(Object o) {
                return null;
            }

            @Override
            public Model addAllAttributes(Collection<?> objects) {
                return null;
            }

            @Override
            public Model addAllAttributes(Map<String, ?> stringMap) {
                return null;
            }

            @Override
            public Model mergeAttributes(Map<String, ?> stringMap) {
                return null;
            }

            @Override
            public boolean containsAttribute(String s) {
                return false;
            }

            @Override
            public Map<String, Object> asMap() {
                return new HashMap<String, Object>();
            }
        };

        when(lotService.findById(1)).thenReturn(lot1);
        when(lotService.findById(2)).thenReturn(this.lot2);
        when(lotService.recalculate(new LotDTO(lot1), 1, "", user)).thenReturn(lot1);
        when(lotService.findLotsByCampaignId(1)).thenReturn(Arrays.asList(new Lot()));
//        when(lotService.findByFilter(1, "OQ577L2A")).thenReturn(Arrays.asList(lot1));

        when(campaignService.findByIdAndActiveLots(1)).thenReturn(new CampaignDTO());

        when(lotService.countLotByCodeAndDiffLotId("TEST", 1)).thenReturn(2);

        when(lotService.countLotByCodeAndDiffLotId("OQ577L2B", 2)).thenReturn(0);

        lotDTO = new LotDTO(this.lot2);
        when(lotService.recalculate(lotDTO, 2, "", user)).thenReturn(this.lot2);

        when(securityHolderStrategy.getCurrentUser()).thenReturn(user);

        LotHumidity lotHumidity = new LotHumidity();
        lotHumidity.setLot(lot1);
        lotHumidity.setHumidity(25F);
        lotHumidity.setSampleDate(new Date());
        List<LotHumidity> lotHumidities = new ArrayList<LotHumidity>();
        when(lotHumidityServiceMock.findByLot(lot1.getId())).thenReturn(lotHumidities);

        lotList = new ArrayList<Lot>();
        lotList.add(lot1);
        lotList.add(lot2);


        when(lotService.findActiveLotsByCampaignId(1)).thenReturn(lotList);
    }

    @Test
    @DirtiesContext
    public void findDetailById_WhenLotIsFound() throws DataAccessException {
        when(lotService.findById(1)).thenReturn(lot2);
        when(lotBatchService.findByLotId(lot2.getId())).thenReturn(new ArrayList<LotBatchDTO>());
        model = new ExtendedModelMap();
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        Integer value = (Integer) request.getSession().getAttribute("lotId");
        when(value).thenReturn(1);
        ModelAndView modelAndView = lotController.findDetailById(request);
        Assert.assertEquals(modelAndView.getModel().get("campaignId"), lot2.getCampaign().getId());
        Assert.assertEquals(modelAndView.getModel().get("campaign"), new CampaignDTO(lot2.getCampaign()));
        Assert.assertEquals(modelAndView.getModel().get("lot"), lotDTO);
    }

    @Test
    public void testFindLots_whenSearchByCampaignId_when_idNotExist() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getSession().getAttribute("lotId")).thenReturn(1);
        ModelAndView result = lotController.findByCampaignId(new ExtendedModelMap(), request);
        assertEquals(result.getViewName(), "redirect:/home");
    }


    @Test
    public void testFindByFilterLotCode_whenCallingFilterController() throws DataAccessException {
//        String fieldCode = "OQ577L2A";
        List<FilterDTO> filterDTOs = new ArrayList<FilterDTO>();
        FilterDTO filter = new FilterDTO();
        filter.setField(1);
        filterDTOs.add(filter);
        UserLotFilterDTO userFilterDTO = new UserLotFilterDTO();
        userFilterDTO.setFilters(filterDTOs);

        RedirectAttributes redirectAttributes = new RedirectAttributesModelMap();

        ModelAndView response = lotController.filter(userFilterDTO, redirectAttributes, model);
        assertNotNull(response);
        assertTrue(response.getViewName().equals("redirect:/lot/campaign/"));

    }


    @Test
    public void testFindByFilterLotCode_whenFilterLotCodeHasValues() throws DataAccessException {
        List<FilterDTO> filterDTOs = new ArrayList<FilterDTO>();
        FilterDTO filter = new FilterDTO();
        filter.setField(1);
        filterDTOs.add(filter);
        UserLotFilterDTO userFilterDTO = new UserLotFilterDTO();
        userFilterDTO.setFilters(filterDTOs);
        when(lotService.findByFilter(userFilterDTO.getCampaignId(), userFilterDTO.getFilters())).thenReturn(lotList);

        RedirectAttributes redirectAttributes = new RedirectAttributesModelMap();

        ModelAndView response = lotController.filter(userFilterDTO, redirectAttributes, model);
        assertNotNull(response);
        assertTrue(response.getViewName().equals("redirect:/lot/campaign/"));
    }

    @Test
    public void testResponseSuccess_WhenCallingFindByIdController() throws DataAccessException {

        JsonResponse<LotDTO> response = lotController.findById(1);

        assertNotNull(response);
        assertTrue(response.getSuccess());
    }

    @Test
    public void testResponseSuccess_WhenCallingFindByIdControllerWhenIdNotExist() throws DataAccessException {

        JsonResponse<LotDTO> response = lotController.findById(55);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }

    @Test
    public void testResponseSuccess_WhenCallingUpdateLotExistController() throws DataAccessException {

        Lot lot1 = lotService.findById(1);
        LotDTO lotDTO = new LotDTO(lot1);
        lotDTO.setId(2);
        JsonResponse<LotDTO> response = lotController.update(lotDTO, 1);

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }


    @Test
    public void testResponseSuccess_WhenCallingUpdateAllNotSuccessController() throws DataAccessException {
        Lot lot = lotService.findById(1);
        LotDTO lotDTO = new LotDTO(lot);
        List<LotSelectedDTO> list = new ArrayList<LotSelectedDTO>();
        LotSelectedDTO lotSelectedDTO = new LotSelectedDTO();
        lotSelectedDTO.setLotId(1);
        lotSelectedDTO.setLotCode("OQ577L2A");
        list.add(lotSelectedDTO);
        lotSelectedDTO = new LotSelectedDTO();
        lotSelectedDTO.setLotId(2);
        lotSelectedDTO.setLotCode("OQ577L2B");
        list.add(lotSelectedDTO);
        lotDTO.setSelectedLots(list);
        JsonResponse<LotListDTO> response = lotController.updateAll(lotDTO, 1, "");

        assertNotNull(response);
        assertFalse(response.getSuccess());
    }

    @Test
    public void testLotList__WhenCallingLotListController() {
        Model m = new ExtendedModelMap();
        ModelAndView model = lotController.lotList(m);
        assertTrue(model.getModel().size() > 0);
    }


    @Test
    public void updateProcess_whenLotByCodeAndDiffLotIdIsGreatherThan0_returnJsonResponseWithSuccessFalse() {
        LotDTO lotDTO = new LotDTO();
        lotDTO.setLotCode("TEST");
        lotDTO.setId(1);
        JsonResponse jsonResponse = lotController.update(lotDTO, 1);

        verify(message, times(1)).getMessage("tab.lot.lotExist");
        Assert.assertFalse(jsonResponse.getSuccess());
    }

    @Test
    public void updateProcess_whenRecalculateReturnDistinctNull_returnJsonResponseWithSuccessTrue() {
        JsonResponse jsonResponse = lotController.update(lotDTO, 2);
        Assert.assertTrue(jsonResponse.getSuccess());
    }

    @Test
    @DirtiesContext
    public void updateProcess_whenRecalculateThrowsProcessWithErrorException_returnJsonResponseWithSuccessFalse() throws Exception {
        ProcessWithErrorException processWithErrorException = new ProcessWithErrorException();
        RuntimeException violation = new RuntimeException("violation.message");
        when(message.getMessage(violation.getMessage())).thenReturn("violation message");
        when(message.getMessage("tab.lot.error.lotCode", lotDTO.getLotCode())).thenReturn("lotCode error message");

        processWithErrorException.addViolation(violation);

        when(lotService.recalculate(lotDTO, 2, "", user)).thenThrow(processWithErrorException);

        JsonResponse jsonResponse = lotController.update(lotDTO, 2);
        Assert.assertFalse(jsonResponse.getSuccess());
        Assert.assertEquals(jsonResponse.getMessage(), "lotCode error message<br/>violation message");
    }

    @Test
    public void updateProcess_whenRecalculateThrowsException_returnJsonResponseWithSuccessFalse() throws BusinessException {
        BusinessException exception = new BusinessException();
        when(message.getMessage("tab.lot.errorLot")).thenReturn("lotCode error message");

        when(lotService.recalculate(lotDTO, 2, "", user)).thenThrow(exception);

        JsonResponse jsonResponse = lotController.update(lotDTO, 2);
        Assert.assertFalse(jsonResponse.getSuccess());
        Assert.assertEquals(jsonResponse.getMessage(), "lotCode error message");
    }


    @Test
    public void findDetailById_WhenMethodIsPost() throws DataAccessException {
        RedirectAttributes redirectAttributes = PowerMockito.mock(RedirectAttributes.class);
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        String result = lotController.findDetailById(1, "/lot/detail/", request);
        Assert.assertEquals(result, "redirect:/lot/detail/");
    }

    @Test
    public void delete_WhenNotSuccess() throws DataAccessException {
        List<Integer> lotIds = new ArrayList<Integer>();
        lotIds.add(1);
        lotIds.add(2);
        lot1.setState(true);
        lot2.setState(false);
        when(lotService.deleteLogical(1)).thenReturn(lot1);
        when(lotService.deleteLogical(2)).thenReturn(lot2);

        JsonResponse<LotListDTO> result = lotController.delete(lotIds);
        assertFalse(result.getSuccess());
    }

    @Test
    public void delete_WhenSuccess() throws DataAccessException {
        List<Integer> lotIds = new ArrayList<Integer>();
        lotIds.add(1);
        lotIds.add(2);
        lot1.setState(false);
        lot2.setState(false);
        when(lotService.deleteLogical(1)).thenReturn(lot1);
        when(lotService.deleteLogical(2)).thenReturn(lot2);

        JsonResponse<LotListDTO> result = lotController.delete(lotIds);
        assertTrue(result.getSuccess());
    }


    @Test
    public void exportToExcel_whenCampaignExist() {
        ModelAndView model = lotController.exportToExcel(1);
        List<LotDTO> lotDTOList = (List<LotDTO>) model.getModel().get("lotListExcel");
        Assert.assertTrue(lotDTOList.size() > 0);
    }


    @Test
    public void findPreviousLotsByLotId_whitPreviusLot_returnResponseWithPreviusLot() throws DataAccessException {
        List<PreviousLotDTO> previousLots = new ArrayList<PreviousLotDTO>();
        LotCombo lotCombo = new LotCombo();
        lotCombo.setId(1);
        lotCombo.setLotCode("lotCode");
        List<PreviousLot> prev = new ArrayList<PreviousLot>();
        PreviousLot p = new PreviousLot();
        p.setActualLot(1);
        p.setPreviousLot(2);
        prev.add(p);
        PreviousLotDTO previousLot = new PreviousLotDTO(lotCombo, prev);
        previousLots.add(previousLot);

        when(lotService.findPreviousLotsByLotId(1)).thenReturn(previousLots);

        JsonResponse<PreviousLotDTO> previousLotJsonResponse = lotController.findPreviousLotsByLotId(1);

        verify(lotService, times(1)).findPreviousLotsByLotId(any(Integer.class));

        Assert.assertEquals(1, previousLotJsonResponse.getRows().size());
    }

    @Test
    public void findPreviousLotsByLotId_whitoutPreviusLot_returnResponseWithMessageDontExists() throws DataAccessException {
        when(message.getMessage("tab.lot.dontExist")).thenReturn("lot don't exist.");

        when(lotService.findPreviousLotsByLotId(1)).thenReturn(null);

        JsonResponse<PreviousLotDTO> previousLotJsonResponse = lotController.findPreviousLotsByLotId(1);

        verify(lotService, times(1)).findPreviousLotsByLotId(any(Integer.class));
        verify(message, times(1)).getMessage("tab.lot.dontExist");

        Assert.assertEquals("lot don't exist.", previousLotJsonResponse.getMessage());
    }

    @Test
    @DirtiesContext
    public void findAllHybrid_withHybrids_returnResponseWithHybrid() {
        List<Hybrid> hybrids = new ArrayList<Hybrid>();
        hybrids.add(new Hybrid());
        when(hybridServiceMock.findAll()).thenReturn(hybrids);

        JsonResponse<HybridDTO> hybridDTOJsonResponse = lotController.findAllHybrid();

        verify(hybridServiceMock, times(1)).findAll();
        Assert.assertEquals(true, hybridDTOJsonResponse.getSuccess());
    }

    @Test
    public void getLotHistory_whitLotHistory_returnViewWithLotAndLotHumidity() throws DataAccessException, BusinessException {
        List<LotHistory> lotHistories = new ArrayList<LotHistory>();
        LotHistory lotHistory = new LotHistory();
        lotHistories.add(lotHistory);
        when(lotService.getLotHistory(1)).thenReturn(lotHistories);

        List<LotHumidity> lotHumidities = new ArrayList<LotHumidity>();
        lotHumidities.add(new LotHumidity());
        when(lotHumidityServiceMock.findByLot(1)).thenReturn(lotHumidities);

        lot1.setCampaign(campaign1);
        when(lotService.findById(1)).thenReturn(lot1);

        ModelAndView modelAndView = lotController.getLotHistory(1);

        verify(lotService, times(1)).getLotHistory(1);
        verify(lotService, times(1)).findById(1);
        verify(lotHumidityServiceMock, times(1)).findByLot(1);

        Assert.assertEquals(1, ((List<LotHistory>) modelAndView.getModel().get("lotHistories")).size());
        Assert.assertEquals(1, modelAndView.getModel().get("campaignId"));
        Assert.assertNotNull(modelAndView.getModel().get("lot"));
        Assert.assertEquals(1, ((List<LotHumidityDTO>) modelAndView.getModel().get("lotHumidities")).size());
    }

    @Test
    public void getLotHistory_whitCampaignNull_returnViewWithLotAndLotHumidity() throws DataAccessException, BusinessException {
        List<LotHistory> lotHistories = new ArrayList<LotHistory>();
        LotHistory lotHistory = new LotHistory();
        lotHistories.add(lotHistory);
        when(lotService.getLotHistory(1)).thenReturn(lotHistories);

        List<LotHumidity> lotHumidities = new ArrayList<LotHumidity>();
        lotHumidities.add(new LotHumidity());
        when(lotHumidityServiceMock.findByLot(1)).thenReturn(lotHumidities);

        lot1.setCampaign(null);
        when(lotService.findById(1)).thenReturn(lot1);

        ModelAndView modelAndView = lotController.getLotHistory(1);

        verify(lotService, times(1)).getLotHistory(1);
        verify(lotService, times(1)).findById(1);
        verify(lotHumidityServiceMock, times(1)).findByLot(1);

        Assert.assertEquals(1, ((List<LotHistory>) modelAndView.getModel().get("lotHistories")).size());
        Assert.assertNull(modelAndView.getModel().get("campaignId"));
        Assert.assertNotNull(modelAndView.getModel().get("lot"));
        Assert.assertEquals(1, ((List<LotHumidityDTO>) modelAndView.getModel().get("lotHumidities")).size());
    }

    @Test
    @DirtiesContext
    public void getLotHistory_withCampaingWithIsActiveFalse_returnViewWithLotAndLotHumidity() throws DataAccessException, BusinessException {
        List<LotHistory> lotHistories = new ArrayList<LotHistory>();
        LotHistory lotHistory = new LotHistory();
        lotHistories.add(lotHistory);
        when(lotService.getLotHistory(1)).thenReturn(lotHistories);

        List<LotHumidity> lotHumidities = new ArrayList<LotHumidity>();
        lotHumidities.add(new LotHumidity());
        when(lotHumidityServiceMock.findByLot(1)).thenReturn(lotHumidities);

        campaign1.setIsActive(false);
        lot1.setCampaign(campaign1);
        when(lotService.findById(1)).thenReturn(lot1);

        ModelAndView modelAndView = lotController.getLotHistory(1);

        verify(lotService, times(1)).getLotHistory(1);
        verify(lotService, times(1)).findById(1);
        verify(lotHumidityServiceMock, times(1)).findByLot(1);

        Assert.assertEquals(1, ((List<LotHistory>) modelAndView.getModel().get("lotHistories")).size());
        Assert.assertNull(modelAndView.getModel().get("campaignId"));
        Assert.assertNotNull(modelAndView.getModel().get("lot"));
        Assert.assertEquals(1, ((List<LotHumidityDTO>) modelAndView.getModel().get("lotHumidities")).size());
    }

    @Test
    public void findByCampaignId_withCampaignThatExists_returnModelAndView() throws DataAccessException {
        List<Lot> lots = new ArrayList<Lot>();
        lots.add(lot1);

        List<LotCombo> allLots = new ArrayList<LotCombo>();
        allLots.add(new LotCombo());

        when(campaignService.findByIdAndActiveLots(1)).thenReturn(new CampaignDTO(campaign1));

        List<Establishment> establishments = new ArrayList<Establishment>();
        establishments.add(new Establishment());
        when(establishmentService.findAll()).thenReturn(establishments);

        Model modelMock = mock(Model.class);
        Map<String, Object> map = mock(Map.class);
        when(map.get("lotFilterDTO")).thenReturn(null);
        when(map.get("allLots")).thenReturn(null);
        when(modelMock.asMap()).thenReturn(map);

        when(lotService.findAll()).thenReturn(allLots);
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        when(lotService.findAll()).thenReturn(allLots);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(session.getAttribute("idCampaign")).thenReturn(1);

        when(modelMock.asMap().get("campaignId")).thenReturn(1);

        ModelAndView modelAndView = lotController.findByCampaignId(modelMock, request);

        verify(campaignService, times(1)).findByIdAndActiveLots(any(Integer.class));

        Assert.assertNotNull(modelAndView.getModel().get("campaign"));
        Assert.assertEquals(1, modelAndView.getModel().get("campaignId"));

    }

    @Test
    public void findByCampaignId_withCampaignNotExists_returnModelAndView() throws DataAccessException {
        List<Lot> lots = new ArrayList<Lot>();
        lots.add(lot1);

        List<LotCombo> allLots = new ArrayList<LotCombo>();
        allLots.add(new LotCombo());

        when(campaignService.findByIdAndActiveLots(1)).thenReturn(null);

        List<Establishment> establishments = new ArrayList<Establishment>();
        establishments.add(new Establishment());
        when(establishmentService.findAll()).thenReturn(establishments);

        Model modelMock = mock(Model.class);
        Map<String, Object> map = mock(Map.class);
        when(map.get("lotFilterDTO")).thenReturn(null);
        when(map.get("allLots")).thenReturn(null);
        when(modelMock.asMap()).thenReturn(map);

        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        when(lotService.findAll()).thenReturn(allLots);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(session.getAttribute("idCampaign")).thenReturn(1);

        when(modelMock.asMap().get("campaignId")).thenReturn(1);

        ModelAndView modelAndView = lotController.findByCampaignId(modelMock, request);
        verify(campaignService, times(1)).findByIdAndActiveLots(any(Integer.class));

        Assert.assertNull(modelAndView.getModel().get("campaign"));
        Assert.assertNotNull(modelAndView.getModel().get("campaignId"));

    }


    @Test
    public void exportToPDF_whenCampaignExist() throws Exception {
        ModelAndView model = lotController.exportToPDF(1);
        List<LotDTO> lotDTOList = (List<LotDTO>) model.getModel().get("lotListPDF");
        Assert.assertTrue(lotDTOList.size() > 0);
    }

    @Test
    public void findByHybridAndCampaign_when_request_has_value() {

        List<Integer> ids = new ArrayList<Integer>();
        ids.add(1);
        ids.add(1);

        when(lotService.findActiveAndHuskedLotsByHybridIdAndCampaignId(1, 1)).thenReturn(lotList);
        JsonResponse<LotComboDTO> lotComboDTOJsonResponse = lotController.findByHybridAndCampaign(ids);

        Assert.assertTrue(lotComboDTOJsonResponse.getSuccess());
        Assert.assertTrue(lotComboDTOJsonResponse.getRows().size() > 0);
    }

    @Test
    public void findAll_when_response_return_values() throws DataAccessException {

        List<LotCombo> lotComboList = new ArrayList<LotCombo>();

        for (Lot lot : lotList) {
            LotCombo lotCombo = new LotCombo();
            lotCombo.setId(lot.getId());
            lotCombo.setLotCode(lot.getLotCode());
            lotComboList.add(lotCombo);
        }

        when(lotService.findAll()).thenReturn(lotComboList);
        JsonResponse<LotComboDTO> lotComboDTOJsonResponse = lotController.findAll();

        Assert.assertTrue(lotComboDTOJsonResponse.getSuccess());
        Assert.assertTrue(lotComboDTOJsonResponse.getRows().size() > 0);
    }


    @Test
    public void test_findByCampaignId_whenReturnValue() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        RedirectAttributes redirectAttributes = PowerMockito.mock(RedirectAttributes.class);
        when(request.getSession()).thenReturn(PowerMockito.mock(HttpSession.class));
        Assert.assertEquals("redirect:/lot/campaign/", lotController.findByCampaignId(1, redirectAttributes, request));
    }

    @Test
    public void handleLotError_request() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getAttribute("campaignId")).thenReturn(1);
        String page = lotController.handleLotError(request);

        Assert.assertEquals("redirect:/lot/campaign/", page);
    }
}

