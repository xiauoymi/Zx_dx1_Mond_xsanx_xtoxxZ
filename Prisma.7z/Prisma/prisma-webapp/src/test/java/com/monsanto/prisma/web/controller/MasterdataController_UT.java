package com.monsanto.prisma.web.controller;

import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.LotMasterdata;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.TotalLotsDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.MasterdataService;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;

import static org.mockito.Mockito.*;

/**
 * Created by EPESTE on 11/06/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class MasterdataController_UT {

    @Mock
    private Model model;

    @InjectMocks
    private MasterdataController masterdataController;

    @Mock
    private CampaignService campaignService;

    @Mock
    private MasterdataService masterdataService;

    @Mock
    private MessageCurrentLocaleResolver message;

    @Mock
    MultipartHttpServletRequest multipartHttpServletRequest;

    @Mock
    private LotService lotService;

    @Before
    public void setUp() {
        CampaignDTO campaign = Mockito.mock(CampaignDTO.class);
        when(campaignService.findByIdAndActiveLots(1)).thenReturn(campaign);
    }

    @Test
    public void init_withModelOk_forwardMasterdataPage() {
        ModelAndView modelAndView = masterdataController.init(1);
        Assert.assertEquals("masterdata", modelAndView.getViewName());
    }

    @Test
    public void uploadFile_returnsLotMasterdataListWhenRefreshIsOk() throws BusinessException, DataAccessException {
        LotMasterdata lotMasterdata = mock(LotMasterdata.class);
        ArrayList<LotMasterdata> lotMasterdataList = Lists.newArrayList(lotMasterdata);
        when(masterdataService.refreshFromMasterdata(1)).thenReturn(lotMasterdataList);

        JsonResponse<? extends Object> result = masterdataController.uploadFile(1);

        verify(masterdataService, times(1)).refreshFromMasterdata(1);
        Assert.assertArrayEquals(((ArrayList<LotMasterdata>) result.getItem()).toArray(), lotMasterdataList.toArray());
    }

    @Test
    public void uploadFile_NotSuccessResponseWhenFileIsEmpty() throws BusinessException, DataAccessException {
        when(masterdataService.refreshFromMasterdata(1)).thenReturn(null);
        when(message.getMessage("ditsem.empty")).thenReturn("test");

        JsonResponse<? extends Object> result = masterdataController.uploadFile(1);

        verify(masterdataService, times(1)).refreshFromMasterdata(1);
        verify(message, times(1)).getMessage("ditsem.empty");
        Assert.assertFalse(result.getSuccess());
    }


    @Test
    public void init_withModelOk_when_has_request() {

        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        ModelAndView modelAndView = masterdataController.init(request);

        Assert.assertEquals("masterdata", modelAndView.getViewName());
    }

}
