package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.PayGrower;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.PayGrowerService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.dto.PayGrowerDTO;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created by PGSETT on 31/07/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class PayGrowerController_UT {
    @Mock
    private LotService lotService;

    @InjectMocks
    private PayGrowerController payGrowerController;

    @Mock
    private CampaignService campaignServiceMock;

    @Mock
    private PayGrowerService payGrowerServiceMock;

    private Date date;

    @Mock
    MessageCurrentLocaleResolver messageCurrentLocaleResolverMock;

    @Before
    public void setUp() throws BusinessException, InvalidFormatException, IOException, ParseException {
        when(campaignServiceMock.findByIdAndActiveLots(1)).thenReturn(new CampaignDTO());
        when(campaignServiceMock.findByIdAndActiveLots(2)).thenReturn(new CampaignDTO());

        PayGrower payGrower = mock(PayGrower.class);
        date = new Date();
        when(payGrower.getDateProccess()).thenReturn(date);
        when(payGrower.getPathFile()).thenReturn("path");
        when(payGrower.getCampaignId()).thenReturn(1);
        when(payGrower.getModified()).thenReturn(1);
        when(payGrower.getOmitted()).thenReturn(0);
        List<LotDTO> lotDTOs = new ArrayList<LotDTO>();
        lotDTOs.add(new LotDTO());
        when(payGrower.getLotDTOs()).thenReturn(lotDTOs);


        when(payGrowerServiceMock.importFile(1)).thenReturn(payGrower);
        when(payGrowerServiceMock.importFile(2)).thenReturn(null);

        when(messageCurrentLocaleResolverMock.getMessage("payGrower.notExists")).thenReturn("Reporte 3 no existe");
    }

    @Test
    public void init_whenCampaignExists_forwardPage() {
        ModelAndView page = payGrowerController.init(1);

        verify(campaignServiceMock, times(1)).findByIdAndActiveLots(any(Integer.class));
        Assert.assertEquals(Constants.PAGE_PAY_GROWER, page.getViewName());
        Assert.assertEquals(1, page.getModel().get("campaignId"));
        Assert.assertNotNull(page.getModel().get("campaign"));
    }

    @Test
    public void updateLots_withCampaignExists_returnPayGrowerStatistics() throws BusinessException, InvalidFormatException, IOException, ParseException {
        JsonResponse<PayGrowerDTO> payGrowerJsonResponse = payGrowerController.updateLots(1);

        verify(payGrowerServiceMock, times(1)).importFile(1);
        Assert.assertEquals("path", payGrowerJsonResponse.getItem().getPathFile());
        Assert.assertEquals(1, payGrowerJsonResponse.getItem().getModified());
        Assert.assertEquals(0, payGrowerJsonResponse.getItem().getOmitted());
        Assert.assertEquals(1, payGrowerJsonResponse.getItem().getLotDTOs().size());
        Assert.assertEquals(date, payGrowerJsonResponse.getItem().getDateProccess());
    }

    @Test
    public void updateLots_withReportNull_returnMessageReportNotExists() throws BusinessException, InvalidFormatException, IOException, ParseException {
        JsonResponse<PayGrowerDTO> report2JsonResponse = payGrowerController.updateLots(2);

        verify(payGrowerServiceMock, times(1)).importFile(2);
        verify(messageCurrentLocaleResolverMock, times(1)).getMessage("payGrower.notExists");
        Assert.assertEquals(false, report2JsonResponse.getSuccess());
        Assert.assertEquals("Reporte 3 no existe", report2JsonResponse.getMessage());
    }

    @Test
    public void init_withModelOk_when_has_request() {

        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        ModelAndView modelAndView = payGrowerController.init(request);

        Assert.assertEquals("payGrower", modelAndView.getViewName());
    }
}
