package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Campaign;
import com.monsanto.prisma.core.domain.PreHarvestHumidity;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.PreHarvestHumidityDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.repository.CampaignRepository;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.PreHarvestHumidityService;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.ui.Model;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import static org.mockito.Mockito.*;

/**
 * Created by PGSETT on 10/07/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class PreHarvestController_UT {
    @Mock
    private Model model;

    @InjectMocks
    private PreHarvestController preHarvestController;

    @Mock
    private CampaignService campaignService;

    @Mock
    private CampaignRepository campaignRepository;

    @Mock
    private PreHarvestHumidityService preHarvestHumidityService;

    @Mock
    private MessageCurrentLocaleResolver message;

    @Mock
    private MultipartHttpServletRequest multipartHttpServletRequest;

    @Mock
    private LotService lotService;

    @Before
    public void setUp() throws BusinessException {
        CampaignDTO campaign = Mockito.mock(CampaignDTO.class);

        when(campaignService.findByIdAndActiveLots(1)).thenReturn(campaign);
        PreHarvestHumidity preHarvestHumidity = new PreHarvestHumidity();
        preHarvestHumidity.setId(100);
        when(preHarvestHumidityService.refreshFromPreHarvest(1)).thenReturn(preHarvestHumidity);
        when(campaignRepository.findById(1)).thenReturn(new Campaign());
        when(preHarvestHumidityService.refreshFromPreHarvest(2)).thenReturn(null);
        when(message.getMessage("preHarvest.empty")).thenReturn("preHarvestHumidity no existe.");

        when(campaignService.findByIdAndActiveLots(1)).thenReturn(campaign);
    }

    @Test
    @DirtiesContext
    public void init_withModelOk_forwardPreHarvestPage() {
        ModelAndView modelAndView = preHarvestController.init(1);
        Assert.assertEquals("preHarvest", modelAndView.getViewName());
    }


    @Test
    public void uploadFile_whenExitsNewMoistureInPreHarvestHumidity() throws BusinessException {
        JsonResponse<PreHarvestHumidityDTO> response = preHarvestController.uploadFile(1);
        Assert.assertEquals(new Integer(100), response.getItem().getId());
    }

    @Test
    public void uploadFile_whenNotExitsMoistureInPreHarvestHumidity() throws BusinessException {
        JsonResponse<PreHarvestHumidityDTO> response = preHarvestController.uploadFile(2);
        Assert.assertTrue(!response.getSuccess());
    }

    @Test
    public void uploadFile_returnsPreHarvestHumidityWhenAddLotFromPreHarvestIsOk() throws BusinessException {
        JsonResponse<? extends Object> response = preHarvestController.uploadFile(1);

        verify(preHarvestHumidityService, times(1)).refreshFromPreHarvest(1);
        Assert.assertEquals(((PreHarvestHumidityDTO) response.getItem()).getId(), new Integer(100));
    }

    @Test
    public void uploadFile_NotSuccessResponseWhenFileIsEmpty() throws BusinessException {
        when(preHarvestHumidityService.refreshFromPreHarvest(1)).thenReturn(null);
        when(message.getMessage("preHarvest.empty")).thenReturn("test");

        JsonResponse<? extends Object> result = preHarvestController.uploadFile(1);

        verify(preHarvestHumidityService, times(1)).refreshFromPreHarvest(1);
        verify(message, times(1)).getMessage("preHarvest.empty");
        Assert.assertFalse(result.getSuccess());
    }

    @Test
    public void init_withModelOk_when_has_request() {

        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        ModelAndView modelAndView = preHarvestController.init(request);

        Assert.assertEquals("preHarvest", modelAndView.getViewName());
    }

}
