package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.PrismaFunctionality;
import com.monsanto.prisma.core.domain.Profile;
import com.monsanto.prisma.core.dto.ProfileDTO;
import com.monsanto.prisma.core.service.PrismaFunctionalityService;
import com.monsanto.prisma.core.service.ProfileService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;
import static org.powermock.api.mockito.PowerMockito.doNothing;
import static org.powermock.api.mockito.PowerMockito.mock;

/**
 * Created by EPESTE on 06/10/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class ProfileController_UT {
    @InjectMocks
    private ProfileController profileController;

    @Mock
    private ProfileService profileService;

    @Mock
    private PrismaFunctionalityService prismaFunctionalityServiceMock;

    private Profile profileMock;

    private List<PrismaFunctionality> prismaFunctionalityList;

    @Before
    public void setUp() {
        List<Profile> profiles = new ArrayList<Profile>();
        profileMock = mock(Profile.class);
        when(profileMock.getId()).thenReturn(1);
        when(profileMock.getName()).thenReturn("fullname");
        when(profileMock.getEnabled()).thenReturn(Boolean.TRUE);

        PrismaFunctionality prismaFunctionalityMock = mock(PrismaFunctionality.class);
        when(prismaFunctionalityMock.getId()).thenReturn(1);
        when(prismaFunctionalityMock.getAction()).thenReturn("action");
        when(prismaFunctionalityMock.getFunctionality()).thenReturn("functionality");

        prismaFunctionalityList = new ArrayList<PrismaFunctionality>();
        prismaFunctionalityList.add(prismaFunctionalityMock);
        when(profileMock.getPrismaFunctionalityList()).thenReturn(prismaFunctionalityList);

        profiles.add(profileMock);

        when(profileService.findAll()).thenReturn(profiles);
    }

    @Test
    public void init_withProfileList_returnView() {
        ModelAndView modelAndView = profileController.init();

        verify(profileService, times(1)).findAll();
        Assert.assertEquals("profileList", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("profileList") instanceof List);
    }

    @Test
    public void addProfile_withPrismaFunctionalityList_returnView() {
        when(prismaFunctionalityServiceMock.findAll()).thenReturn(new ArrayList<PrismaFunctionality>());

        ModelAndView modelAndView = profileController.addProfile();

        verify(prismaFunctionalityServiceMock, times(1)).findAll();
        Assert.assertEquals("newProfile", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("functionalities") instanceof List);
    }

    @Test
    public void delete_idValid_returnProfileDeleted() {
        doNothing().when(profileService).delete(any(Integer.class));

        JsonResponse jsonResponse = profileController.delete(1);

        verify(profileService, times(1)).delete(any(Integer.class));
        Assert.assertEquals("prisma.profile.delete.ok", jsonResponse.getMessage());
    }

    @Test
    public void addProfile_withProfileDTO_returnProfile() {
        when(profileService.add(any(ProfileDTO.class))).thenReturn(profileMock);

        JsonResponse jsonResponse = profileController.addProfile(new ProfileDTO());

        verify(profileService, times(1)).add(any(ProfileDTO.class));
        Assert.assertEquals("prisma.profile.add.ok", jsonResponse.getMessage());
        Assert.assertTrue(jsonResponse.getItem() instanceof ProfileDTO);
    }

    @Test
    public void detail_withProfile_returnView() {
        when(profileService.findById(any(Integer.class))).thenReturn(profileMock);

        when(prismaFunctionalityServiceMock.findAll()).thenReturn(prismaFunctionalityList);

        ModelAndView view = profileController.detail(1);

        verify(profileService, times(1)).findById(any(Integer.class));
        verify(prismaFunctionalityServiceMock, times(1)).findAll();

        Assert.assertTrue(view.getModel().get("profile") instanceof Profile);
        Assert.assertTrue(view.getModel().get("functionalities") instanceof List);
    }

    @Test
    public void update_withProfileDTO_returnProfileDTO() {
        when(profileService.update(any(ProfileDTO.class))).thenReturn(profileMock);

        JsonResponse jsonResponse = profileController.update(new ProfileDTO());

        verify(profileService, times(1)).update(any(ProfileDTO.class));
        Assert.assertEquals("prisma.profile.update.ok", jsonResponse.getMessage());
        Assert.assertTrue(jsonResponse.getItem() instanceof ProfileDTO);
    }
}
