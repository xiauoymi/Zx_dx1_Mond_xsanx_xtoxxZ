package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.QualityFile;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.dto.QualityDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.QualityService;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Created by EPESTE on 29/07/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class QualityController_UT {
    @InjectMocks
    private QualityController qualityController;

    @Mock
    private CampaignService campaignServiceMock;

    @Mock
    private QualityService qualityServiceMock;

    @Mock
    MessageCurrentLocaleResolver messageCurrentLocaleResolverMock;

    @Mock
    private LotService lotService;

    private Date date;

    @Before
    public void setUp() throws Exception {
        date = new Date();
        when(campaignServiceMock.findByIdAndActiveLots(1)).thenReturn(new CampaignDTO());

        QualityFile qualityFile = new QualityFile();
        qualityFile.setPathFile("//dev/path//");
        qualityFile.setDateProcess(date);
        qualityFile.setLotsModified(1);
        qualityFile.setLotsNotModified(2);
        List<LotDTO> lotDTOsMock = mock(List.class);
        when(lotDTOsMock.size()).thenReturn(2);
        LotDTO lotDTO1Mock = mock(LotDTO.class);
        LotDTO lotDTO2Mock = mock(LotDTO.class);
        when(lotDTOsMock.get(0)).thenReturn(lotDTO1Mock);
        when(lotDTOsMock.get(1)).thenReturn(lotDTO2Mock);
        when(lotDTO1Mock.getCauses()).thenReturn("The lot not exists.");
        when(lotDTO2Mock.getCauses()).thenReturn("The lot not exists.");
        qualityFile.setLotDTOs(lotDTOsMock);
        when(qualityServiceMock.importFromFile(1)).thenReturn(qualityFile);

        when(qualityServiceMock.importFromFile(2)).thenReturn(null);

        when(messageCurrentLocaleResolverMock.getMessage("qualityFile.notExists")).thenReturn("The file not exists.");
    }

    @Test
    public void init_withCampaignValid_forwardQualityImport() {
        ModelAndView modelAndView = qualityController.init(1);

        verify(campaignServiceMock, times(1)).findByIdAndActiveLots(1);
        Assert.assertEquals(Constants.PAGE_IMPORT_QUALITY, modelAndView.getViewName());
        Assert.assertEquals(1, modelAndView.getModel().get("campaignId"));
        Assert.assertNotNull(modelAndView.getModel().get("campaign"));
    }

    @Test
    public void import_whenExistsFile_returnJsonResponseWithInformation() throws Throwable {
        JsonResponse<QualityDTO> jsonResponse = qualityController.updateFromFile(1);

        verify(qualityServiceMock, times(1)).importFromFile(1);

        Assert.assertEquals("//dev/path//", jsonResponse.getItem().getPathFile());
        Assert.assertEquals(date, jsonResponse.getItem().getDateProcess());
        Assert.assertEquals(new Integer(1), jsonResponse.getItem().getLotsModified());
        Assert.assertEquals(new Integer(2), jsonResponse.getItem().getLotsNotModified());
    }

    @Test
    public void import_whenNotExistsFile_returnMessageNotExists() throws Throwable {
        JsonResponse<QualityDTO> jsonResponse = qualityController.updateFromFile(2);

        verify(qualityServiceMock, times(1)).importFromFile(2);
        verify(messageCurrentLocaleResolverMock, times(1)).getMessage(anyString());

        Assert.assertEquals("The file not exists.", jsonResponse.getMessage());
    }

    @Test
    public void updateFromFile_withIOExceptionInUpdate_returnJsonResponse() throws Throwable {
        when(qualityServiceMock.importFromFile(anyInt())).thenThrow(new IOException("EXCEPTION"));
        JsonResponse<QualityDTO> jsonResponse = qualityController.updateFromFile(2);

        verify(qualityServiceMock, times(1)).importFromFile(2);

        Assert.assertFalse(jsonResponse.getSuccess());
    }

    @Test
    public void updateFromFile_withInvalidFormatExceptionInUpdate_returnJsonResponse() throws Throwable {
        when(qualityServiceMock.importFromFile(anyInt())).thenThrow(new InvalidFormatException("EXCEPTION"));
        JsonResponse<QualityDTO> jsonResponse = qualityController.updateFromFile(2);

        verify(qualityServiceMock, times(1)).importFromFile(2);

        Assert.assertFalse(jsonResponse.getSuccess());
    }

    @Test
    public void updateFromFile_withBusinessExceptionInUpdate_returnJsonResponse() throws Throwable {
        when(qualityServiceMock.importFromFile(anyInt())).thenThrow(new BusinessException("EXCEPTION"));
        JsonResponse<QualityDTO> jsonResponse = qualityController.updateFromFile(2);

        verify(qualityServiceMock, times(1)).importFromFile(2);

        Assert.assertFalse(jsonResponse.getSuccess());
    }

    @Test
    public void init_withModelOk_when_has_request() {

        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        ModelAndView modelAndView = qualityController.init(request);

        Assert.assertEquals("quality", modelAndView.getViewName());
    }
}

