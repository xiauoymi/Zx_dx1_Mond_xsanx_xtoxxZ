package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Report1;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.Report1Service;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.dto.Report1DTO;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created by EPESTE on 23/07/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class Report1Controller_UT {
    @InjectMocks
    private Report1Controller report1Controller;

    @Mock
    private CampaignService campaignServiceMock;

    @Mock
    private Report1Service report1ServiceMock;

    private Date date;
    @Mock
    private LotService lotService;


    @Mock
    MessageCurrentLocaleResolver messageCurrentLocaleResolverMock;

    @Before
    public void setUp() throws BusinessException, InvalidFormatException, IOException, ParseException {
        when(campaignServiceMock.findByIdAndActiveLots(1)).thenReturn(new CampaignDTO());
        when(campaignServiceMock.findByIdAndActiveLots(2)).thenReturn(new CampaignDTO());

        Report1 report1 = mock(Report1.class);
        date = new Date();
        when(report1.getDateProccess()).thenReturn(date);
        when(report1.getPathFile()).thenReturn("path");
        when(report1.getCampaignId()).thenReturn(1);
        when(report1.getModified()).thenReturn(23);
        when(report1.getOmitted()).thenReturn(1);
        List<LotDTO> lotDTOs = new ArrayList<LotDTO>();
        lotDTOs.add(new LotDTO());
        when(report1.getLotDTOs()).thenReturn(lotDTOs);


        when(report1ServiceMock.importFile(1)).thenReturn(report1);
        when(report1ServiceMock.importFile(2)).thenReturn(null);

        when(messageCurrentLocaleResolverMock.getMessage("report1.notExists")).thenReturn("Reporte 1 no existe");
    }

    @Test
    public void init_whenCampaignExists_forwardPage() {
        ModelAndView page = report1Controller.init(1);

        verify(campaignServiceMock, times(1)).findByIdAndActiveLots(any(Integer.class));
        Assert.assertEquals(Constants.PAGE_REPORT_1, page.getViewName());
        Assert.assertEquals(1, page.getModel().get("campaignId"));
        Assert.assertNotNull(page.getModel().get("campaign"));
    }

    @Test
    public void updateLots_withCampaignExists_returnReport1Statistics() throws BusinessException, InvalidFormatException, IOException, ParseException {
        JsonResponse<Report1DTO> report1JsonResponse = report1Controller.updateLots(1);

        verify(report1ServiceMock, times(1)).importFile(1);
        Assert.assertEquals("path", report1JsonResponse.getItem().getPathFile());
        Assert.assertEquals(23, report1JsonResponse.getItem().getModified());
        Assert.assertEquals(1, report1JsonResponse.getItem().getOmitted());
        Assert.assertEquals(1, report1JsonResponse.getItem().getLotDTOs().size());
        Assert.assertEquals(date, report1JsonResponse.getItem().getDateProccess());
    }

    @Test
    public void updateLots_withReportNull_returnMessageReportNotExists() throws BusinessException, InvalidFormatException, IOException, ParseException {
        JsonResponse<Report1DTO> report1JsonResponse = report1Controller.updateLots(2);

        verify(report1ServiceMock, times(1)).importFile(2);
        verify(messageCurrentLocaleResolverMock, times(1)).getMessage("report1.notExists");
        Assert.assertEquals(false, report1JsonResponse.getSuccess());
        Assert.assertEquals("Reporte 1 no existe", report1JsonResponse.getMessage());
    }

    @Test
    public void init_withModelOk_when_has_request() {

        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        ModelAndView modelAndView = report1Controller.init(request);

        Assert.assertEquals("report1", modelAndView.getViewName());
    }
}

