package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Report2;
import com.monsanto.prisma.core.dto.CampaignDTO;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.LotService;
import com.monsanto.prisma.core.service.Report2Service;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.dto.Report2DTO;
import com.monsanto.prisma.web.utils.JsonResponse;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created by PGSETT on 28/07/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class Report2Controller_UT {
    @InjectMocks
    private Report2Controller report2Controller;

    @Mock
    private CampaignService campaignServiceMock;

    @Mock
    private Report2Service report2ServiceMock;

    private Date date;

    @Mock
    private LotService lotService;

    @Mock
    MessageCurrentLocaleResolver messageCurrentLocaleResolverMock;

    @Before
    public void setUp() throws BusinessException, InvalidFormatException, IOException, ParseException {
        when(campaignServiceMock.findByIdAndActiveLots(1)).thenReturn(new CampaignDTO());
        when(campaignServiceMock.findByIdAndActiveLots(2)).thenReturn(new CampaignDTO());

        Report2 report2 = mock(Report2.class);
        date = new Date();
        when(report2.getDateProccess()).thenReturn(date);
        when(report2.getPathFile()).thenReturn("path");
        when(report2.getCampaignId()).thenReturn(1);
        when(report2.getModified()).thenReturn(1);
        when(report2.getOmitted()).thenReturn(0);
        List<LotDTO> lotDTOs = new ArrayList<LotDTO>();
        lotDTOs.add(new LotDTO());
        when(report2.getLotDTOs()).thenReturn(lotDTOs);


        when(report2ServiceMock.importFile(1)).thenReturn(report2);
        when(report2ServiceMock.importFile(2)).thenReturn(null);

        when(messageCurrentLocaleResolverMock.getMessage("report2.notExists")).thenReturn("Reporte 2 no existe");
    }

    @Test
    public void init_whenCampaignExists_forwardPage() {
        ModelAndView page = report2Controller.init(1);

        verify(campaignServiceMock, times(1)).findByIdAndActiveLots(any(Integer.class));
        Assert.assertEquals(Constants.PAGE_REPORT_2, page.getViewName());
        Assert.assertEquals(1, page.getModel().get("campaignId"));
        Assert.assertNotNull(page.getModel().get("campaign"));
    }

    @Test
    public void updateLots_withCampaignExists_returnReport2Statistics() throws BusinessException, InvalidFormatException, IOException, ParseException {
        JsonResponse<Report2DTO> report2JsonResponse = report2Controller.updateLots(1);

        verify(report2ServiceMock, times(1)).importFile(1);
        Assert.assertEquals("path", report2JsonResponse.getItem().getPathFile());
        Assert.assertEquals(1, report2JsonResponse.getItem().getModified());
        Assert.assertEquals(0, report2JsonResponse.getItem().getOmitted());
        Assert.assertEquals(1, report2JsonResponse.getItem().getLotDTOs().size());
        Assert.assertEquals(date, report2JsonResponse.getItem().getDateProccess());
    }

    @Test
    public void updateLots_withReportNull_returnMessageReportNotExists() throws BusinessException, InvalidFormatException, IOException, ParseException {
        JsonResponse<Report2DTO> report2JsonResponse = report2Controller.updateLots(2);

        verify(report2ServiceMock, times(1)).importFile(2);
        verify(messageCurrentLocaleResolverMock, times(1)).getMessage("report2.notExists");
        Assert.assertEquals(false, report2JsonResponse.getSuccess());
        Assert.assertEquals("Reporte 2 no existe", report2JsonResponse.getMessage());
    }

    @Test
    public void init_withModelOk_when_has_request() {

        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        when(request.getSession()).thenReturn(session);
        when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        ModelAndView modelAndView = report2Controller.init(request);

        Assert.assertEquals("report2", modelAndView.getViewName());
    }
}