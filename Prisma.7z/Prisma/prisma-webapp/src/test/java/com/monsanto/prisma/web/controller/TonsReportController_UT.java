package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.Hybrid;
import com.monsanto.prisma.core.domain.Zone;
import com.monsanto.prisma.core.dto.*;
import com.monsanto.prisma.core.exception.DataAccessException;
import com.monsanto.prisma.core.service.*;
import com.monsanto.prisma.core.utils.utilities.Constants;
import com.monsanto.prisma.web.utils.MessageCurrentLocaleResolver;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.powermock.api.mockito.PowerMockito.mock;
import static org.powermock.api.mockito.PowerMockito.when;

/**
 * Created by EPESTE on 25/08/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class TonsReportController_UT {
    @InjectMocks
    private TonsReportController tonsReportController;

    @Mock
    private CampaignService campaignServiceMock;

    @Mock
    private TonsReportService tonsReportServiceMock;

    @Mock
    private MessageCurrentLocaleResolver message;

    @Mock
    private EstablishmentService establishmentServiceMock;

    @Mock
    private ZoneService zoneServiceMock;

    @Mock
    private HybridService hybridServiceMock;

    @Mock
    private LotService lotService;


    @Before
    public void setUp() {
        CampaignDTO campaignMock = mock(CampaignDTO.class);

        when(campaignServiceMock.findByIdAndActiveLots(1)).thenReturn(campaignMock);

        List<Zone> zoneListMock = mock(List.class);
        when(zoneServiceMock.findAll()).thenReturn(zoneListMock);

        List<Hybrid> hybridList = mock(List.class);
        when(hybridServiceMock.findAll()).thenReturn(hybridList);
    }

    @Test
    public void receive_idCampaignExists_forwardReceivingTonsReport() {

        ModelAndView modelAndView = tonsReportController.receive(1);

        verify(campaignServiceMock, times(1)).findByIdAndActiveLots(1);
        verify(zoneServiceMock, times(1)).findAll();

        Assert.assertEquals("receivingTonsReport", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("campaign") instanceof CampaignDTO);
        Assert.assertTrue(modelAndView.getModel().get("zones") instanceof List);
    }

    @Test
    public void receiveTonsToExcel_withDataValid_returnExcelReport() throws DataAccessException {
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setZoneId(1);
        campaignTonDTO.setHarvestRealWeekFrom(1f);
        campaignTonDTO.setHarvestRealWeekTo(54f);
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();
        when(tonsReportServiceMock.findReceivingTonsByZone(1, 1, today, tomorrow)).thenReturn(new ArrayList<ReceiveTonsDTO>());

        Zone zoneMock = mock(Zone.class);
        when(zoneMock.getCode()).thenReturn("");
        when(zoneServiceMock.findById(1)).thenReturn(zoneMock);

        ModelAndView modelAndView = tonsReportController.receiveTonsToExcel(1, 1, 2, 1, "", today.getTime(), tomorrow.getTime());

        Assert.assertEquals(Constants.RECEIVE_TONS_EXPORT_XLS, modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get(Constants.RECEIVE_TONS_EXPORT_XLS) instanceof List);
    }

    @Test
    public void receiveTonsToExcel_Hybrid_returnExcelReport() throws DataAccessException {
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setHybridId(1);
        campaignTonDTO.setHarvestRealWeekFrom(1f);
        campaignTonDTO.setHarvestRealWeekTo(54f);
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();
        when(tonsReportServiceMock.findReceivingTonsByHybrid(1, 1, today, tomorrow)).thenReturn(new ArrayList<ReceiveTonsDTO>());

        Hybrid hybridMock = mock(Hybrid.class);
        when(hybridMock.getName()).thenReturn("");
        when(hybridServiceMock.findById(1)).thenReturn(hybridMock);

        ModelAndView modelAndView = tonsReportController.receiveTonsToExcel(1, 1, 3, 1, "", today.getTime(), tomorrow.getTime());

        Assert.assertEquals(Constants.RECEIVE_TONS_EXPORT_XLS, modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get(Constants.RECEIVE_TONS_EXPORT_XLS) instanceof List);
    }

    @Test
    public void receiveTonsToExcel_returnExcelReport() throws DataAccessException {
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setLotCode("lotCode");
        campaignTonDTO.setProgram("Program");
        campaignTonDTO.setHarvestRealWeekFrom(1f);
        campaignTonDTO.setHarvestRealWeekTo(54f);
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();
        when(tonsReportServiceMock.findReceiveTons(1, "l.lotCode","lotCode", today, tomorrow)).thenReturn(new ArrayList<ReceiveTonsDTO>());

        ModelAndView modelAndView = tonsReportController.receiveTonsToExcel(1, 1, 1, 1, "lotCode", today.getTime(), tomorrow.getTime());

        Assert.assertEquals(Constants.RECEIVE_TONS_EXPORT_XLS, modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get(Constants.RECEIVE_TONS_EXPORT_XLS) instanceof List);

        when(tonsReportServiceMock.findReceiveTons(1, "l.program","Program", today, tomorrow)).thenReturn(new ArrayList<ReceiveTonsDTO>());

        ModelAndView modelAndView2 = tonsReportController.receiveTonsToExcel(1, 1, 4, 1, "Program", today.getTime(), tomorrow.getTime());

        Assert.assertEquals(Constants.RECEIVE_TONS_EXPORT_XLS, modelAndView2.getViewName());
        Assert.assertTrue(modelAndView.getModel().get(Constants.RECEIVE_TONS_EXPORT_XLS) instanceof List);

    }

    @Test
    public void receiveTonsToPdf_withDataValid_returnExcelReport() throws DataAccessException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();
        when(tonsReportServiceMock.findReceivingTonsByZone(1, -1, today, tomorrow)).thenReturn(new ArrayList<ReceiveTonsDTO>());
        when(tonsReportServiceMock.findWeeksReceivingTonsByZone(1, -1, today, tomorrow)).thenReturn(new ArrayList<ReceiveTonsDTO>());

        Zone zoneMock = mock(Zone.class);
        when(zoneMock.getCode()).thenReturn("");
        when(zoneServiceMock.findById(1)).thenReturn(zoneMock);

        ModelAndView modelAndView = tonsReportController.receiveTonsToPdf(1, 1, 2, 1, "", today.getTime(), tomorrow.getTime());
        Mockito.when(message.getMessage("application.selectOption")).thenReturn("Seleccione una opcion");
        Assert.assertEquals(Constants.RECEIVE_TONS_EXPORT_PDF, modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get(Constants.RECEIVE_TONS_EXPORT_PDF) instanceof List);
    }

    @Test
    public void receiveTonsToPdf_allZoneSelected_returnExcelReport() throws DataAccessException {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();
        when(tonsReportServiceMock.findReceivingTonsByZone(1, 1, today, tomorrow)).thenReturn(new ArrayList<ReceiveTonsDTO>());
        when(tonsReportServiceMock.findWeeksReceivingTonsByZone(1, -1, today, tomorrow)).thenReturn(new ArrayList<ReceiveTonsDTO>());

        Zone zoneMock = mock(Zone.class);
        when(zoneMock.getCode()).thenReturn("");
        when(zoneServiceMock.findById(1)).thenReturn(zoneMock);

        ModelAndView modelAndView = tonsReportController.receiveTonsToPdf(1, -1, 2, -1, "", today.getTime(), tomorrow.getTime());
        Mockito.when(message.getMessage("application.selectOption")).thenReturn("Seleccione una opcion");
        Assert.assertEquals(Constants.RECEIVE_TONS_EXPORT_PDF, modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get(Constants.RECEIVE_TONS_EXPORT_PDF) instanceof List);
    }

    @Test
    public void tonsToHost_idCampaignExists_forwardTonsToHostReport() {
        ModelAndView modelAndView = tonsReportController.init(1);
        verify(campaignServiceMock, times(1)).findByIdAndActiveLots(1);
        verify(zoneServiceMock, times(1)).findAll();
        Assert.assertEquals("tonsToHostReport", modelAndView.getViewName());
        Assert.assertEquals(1, modelAndView.getModel().get("campaignId"));
        Assert.assertTrue(modelAndView.getModel().get("campaign") instanceof CampaignDTO);
        Assert.assertTrue(modelAndView.getModel().get("zones") instanceof List);
    }

    @Test
    public void tonsToHostExcel_withDataValid_returnExcelReport() throws DataAccessException {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setProgram("Program");
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);
        when(tonsReportServiceMock.filterTonsToHostReport(1, "l.program", campaignTonDTO.getProgram(), today, tomorrow)).thenReturn(new ArrayList<TonsToHostDTO>());

        ModelAndView modelAndView = tonsReportController.exportToExcel(1, null, 4, null, "Program", today.getTime(), tomorrow.getTime());

        Assert.assertEquals("tonsToHostReportExcel", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("tonsToHostReportExcel") instanceof List);
    }

    @Test
    public void tonsToHostExcel_LotCode_returnExcelReport() throws DataAccessException {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setLotCode("lotCode");
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);
        when(tonsReportServiceMock.filterTonsToHostReport(1, "l.lotCode", campaignTonDTO.getProgram(), today, tomorrow)).thenReturn(new ArrayList<TonsToHostDTO>());

        ModelAndView modelAndView = tonsReportController.exportToExcel(1, null, 1, null, "lotCode", today.getTime(), tomorrow.getTime());

        Assert.assertEquals("tonsToHostReportExcel", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("tonsToHostReportExcel") instanceof List);
    }

    @Test
    public void tonsToHostExcel_AllZones_returnExcelReport() throws DataAccessException {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setZoneId(-1);
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);
        when(tonsReportServiceMock.filterTonsToHostReportByZone(1, null, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(new ArrayList<TonsToHostDTO>());
        when(tonsReportServiceMock.filterWeekTonsToHostReportByZone(1, null, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(new ArrayList<TonsToHostDTO>());
        ModelAndView modelAndView = tonsReportController.exportToExcel(1, -1, 2, null, "zone", today.getTime(), tomorrow.getTime());

        Assert.assertEquals("tonsToHostReportExcel", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("tonsToHostReportExcel") instanceof List);
    }

    @Test
    public void tonsToHostExcel_zones_returnExcelReport() throws DataAccessException {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setZoneId(1);
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);
        when(tonsReportServiceMock.filterTonsToHostReportByZone(1, 1, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(new ArrayList<TonsToHostDTO>());
        when(tonsReportServiceMock.filterWeekTonsToHostReportByZone(1, 1, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(new ArrayList<TonsToHostDTO>());
        Zone zone = new Zone();
        zone.setId(1);
        zone.setCode("ZONA");
        when(zoneServiceMock.findById(1)).thenReturn(zone);
        ModelAndView modelAndView = tonsReportController.exportToExcel(1, 1, 2, null, "zone", today.getTime(), tomorrow.getTime());

        Assert.assertEquals("tonsToHostReportExcel", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("tonsToHostReportExcel") instanceof List);
    }

    @Test
    public void tonsToHostExcel_AllHybrids_returnExcelReport() throws DataAccessException {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setHybridId(-1);
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);
        when(tonsReportServiceMock.filterTonsToHostReportByHybrid(1, null, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(new ArrayList<TonsToHostDTO>());
        when(tonsReportServiceMock.filterWeekTonsToHostReportByHybrid(1, null, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(new ArrayList<TonsToHostDTO>());
        ModelAndView modelAndView = tonsReportController.exportToExcel(1, null, 3, -1, "hybrid", today.getTime(), tomorrow.getTime());

        Assert.assertEquals("tonsToHostReportExcel", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("tonsToHostReportExcel") instanceof List);
    }

    @Test
    public void tonsToHostExcel_hybrid_returnExcelReport() throws DataAccessException {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setHybridId(1);
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);
        when(tonsReportServiceMock.filterTonsToHostReportByZone(1, 1, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(new ArrayList<TonsToHostDTO>());
        when(tonsReportServiceMock.filterWeekTonsToHostReportByZone(1, 1, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(new ArrayList<TonsToHostDTO>());
        Hybrid hybrid = new Hybrid();
        hybrid.setId(1);
        hybrid.setName("HYBRID");
        when(hybridServiceMock.findById(1)).thenReturn(hybrid);
        ModelAndView modelAndView = tonsReportController.exportToExcel(1, null, 3, 1, "hybrid", today.getTime(), tomorrow.getTime());

        Assert.assertEquals("tonsToHostReportExcel", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("tonsToHostReportExcel") instanceof List);
    }

    @Test
    public void tonsToHostToPdf_withDataValid_returnPDFReport() throws DataAccessException {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setProgram("Program");
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);
        when(tonsReportServiceMock.filterTonsToHostReport(1, "l.program", campaignTonDTO.getProgram(), today, tomorrow)).thenReturn(new ArrayList<TonsToHostDTO>());

        ModelAndView modelAndView = tonsReportController.exportToPdf(1, null, 4, null, "Program", today.getTime(), tomorrow.getTime());
        Mockito.when(message.getMessage("application.selectOption")).thenReturn("Seleccione una opcion");
        Assert.assertEquals("tonsToHostReportPDF", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("tonsToHostReportPDF") instanceof List);
    }

    @Test
    public void statusReport_idCampaignExists_forwardStatusReport() {
        ModelAndView modelAndView = tonsReportController.statusReport(1);
        verify(campaignServiceMock, times(1)).findByIdAndActiveLots(1);
        verify(zoneServiceMock, times(1)).findAll();
        verify(hybridServiceMock, times(1)).findAll();
        Assert.assertEquals("statusReport", modelAndView.getViewName());
        Assert.assertEquals(1, modelAndView.getModel().get("campaignId"));
        Assert.assertTrue(modelAndView.getModel().get("campaign") instanceof CampaignDTO);
        Assert.assertTrue(modelAndView.getModel().get("zones") instanceof List);
        Assert.assertTrue(modelAndView.getModel().get("hybrids") instanceof List);

    }

    @Test
    public void statusReportExcel_withDataValid_returnExcelReport() throws DataAccessException {
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setProgram("Program");
        campaignTonDTO.setHybridId(1);
        campaignTonDTO.setHybridName("hybrid");

        when(campaignServiceMock.filterToStatusReport(campaignTonDTO, 1)).thenReturn(new ArrayList<StatusReportDTO>());

        ModelAndView modelAndView = tonsReportController.statusExportToExcel(1, 1, "Program", "hybrid");

        Assert.assertEquals("statusReportExcel", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("statusReportExcel") instanceof List);
    }

    @Test
    public void statusReportToPdf_withDataValid_returnPDFReport() throws DataAccessException {
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setProgram("Program");
        campaignTonDTO.setHybridId(1);
        campaignTonDTO.setHybridName("hybrid");
        when(campaignServiceMock.filterToStatusReport(campaignTonDTO, 1)).thenReturn(new ArrayList<StatusReportDTO>());

        ModelAndView modelAndView = tonsReportController.statusExportToPdf(1, 1, "Program", "hybrid");
        Mockito.when(message.getMessage("application.selectOption")).thenReturn("Seleccione una opcion");
        Assert.assertEquals("statusReportPDF", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("statusReportPDF") instanceof List);
    }


    @Test
    public void bulkReport_idCampaignExists_forwardBulkReport() {
        ModelAndView modelAndView = tonsReportController.bulkDestinationReport(1);
        verify(campaignServiceMock, times(1)).findByIdAndActiveLots(1);
        verify(hybridServiceMock, times(1)).findAll();
        Assert.assertEquals("bulkDestinationReport", modelAndView.getViewName());
        Assert.assertEquals(1, modelAndView.getModel().get("campaignId"));
        Assert.assertTrue(modelAndView.getModel().get("campaign") instanceof CampaignDTO);
        Assert.assertTrue(modelAndView.getModel().get("hybrids") instanceof List);
    }

    @Test
    public void bulkDestinationReportExcel_withDataValid_returnExcelReport() throws DataAccessException {
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setHybridId(1);
        campaignTonDTO.setHybridName("hybrid");
        campaignTonDTO.setWarehouseUnit("warehouse");

        when(campaignServiceMock.filterBulkDestinationReport(campaignTonDTO, 1)).thenReturn(new ArrayList<BulkDestinationReportDTO>());

        ModelAndView modelAndView = tonsReportController.bulkDestinationExportToExcel(1, "warehouse", 1, "hybrid");

        Assert.assertEquals("bulkDestinationExcel", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("bulkDestinationExcel") instanceof List);
    }

    @Test
    public void bulkDestinationReportToPdf_withDataValid_returnPDFReport() throws DataAccessException {
        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setHybridId(1);
        campaignTonDTO.setHybridName("hybrid");
        campaignTonDTO.setWarehouseUnit("warehouse");

        when(campaignServiceMock.filterBulkDestinationReport(campaignTonDTO, 1)).thenReturn(new ArrayList<BulkDestinationReportDTO>());

        ModelAndView modelAndView = tonsReportController.bulkDestinationExportToPdf(1, "warehouse", 1, "hybrid");

        Mockito.when(message.getMessage("application.selectOption")).thenReturn("Seleccione una opcion");
        Assert.assertEquals("bulkDestinationPDF", modelAndView.getViewName());
        Assert.assertTrue(modelAndView.getModel().get("bulkDestinationPDF") instanceof List);
    }

    @Test
    public void init_withModelOk_when_has_request() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        Mockito.when(request.getSession().getAttribute("errorMessage")).thenReturn("errorMessage");
        ModelAndView modelAndView = tonsReportController.init(request);

        Assert.assertEquals("tonsToHostReport", modelAndView.getViewName());
    }

    @Test
    public void handleTonsToHostError_request() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getAttribute("campaignId")).thenReturn(1);
        String page = tonsReportController.handleTonsToHostError(request);

        Assert.assertEquals("redirect:/report/tons/tonsToHostReport/campaign/", page);
    }

    @Test
    public void handleReceiveTonsError_request() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getAttribute("campaignId")).thenReturn(1);
        String page = tonsReportController.handleReceiveTonsError(request);

        Assert.assertEquals("redirect:/report/tons/receive/campaign/", page);
    }

    @Test
    public void handleStatusReportError_request() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getAttribute("campaignId")).thenReturn(1);
        String page = tonsReportController.handleStatusReportError(request);

        Assert.assertEquals("redirect:/report/tons/statusReport/campaign/", page);
    }

    @Test
    public void handleBulkDestinationError_request() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getAttribute("campaignId")).thenReturn(1);
        String page = tonsReportController.handleBulkDestinationError(request);

        Assert.assertEquals("redirect:/report/tons/bulkDestination/campaign/", page);
    }

    @Test
    public void init_bulkDestinationReport_withModelOk_when_has_request() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        Mockito.when(request.getSession().getAttribute("errorMessage")).thenReturn("errorMessage");
        ModelAndView modelAndView = tonsReportController.bulkDestinationReport(request);

        Assert.assertEquals("bulkDestinationReport", modelAndView.getViewName());
    }

    @Test
    public void init_statusReport_withModelOk_when_has_request() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        Mockito.when(request.getSession().getAttribute("errorMessage")).thenReturn("errorMessage");
        ModelAndView modelAndView = tonsReportController.statusReport(request);

        Assert.assertEquals("statusReport", modelAndView.getViewName());
    }

    @Test
    public void init_receiveReport_withModelOk_when_has_request() {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpSession session = PowerMockito.mock(HttpSession.class);
        Mockito.when(request.getSession()).thenReturn(session);
        Mockito.when(request.getSession().getAttribute("idCampaign")).thenReturn(1);
        Mockito.when(request.getSession().getAttribute("errorMessage")).thenReturn("errorMessage");
        ModelAndView modelAndView = tonsReportController.receive(request);

        Assert.assertEquals("receivingTonsReport", modelAndView.getViewName());
    }


}
