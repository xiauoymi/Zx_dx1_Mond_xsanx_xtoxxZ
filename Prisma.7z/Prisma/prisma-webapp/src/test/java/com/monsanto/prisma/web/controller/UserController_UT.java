package com.monsanto.prisma.web.controller;

import com.monsanto.prisma.core.domain.PrismaFunctionality;
import com.monsanto.prisma.core.domain.Profile;
import com.monsanto.prisma.core.domain.Region;
import com.monsanto.prisma.core.domain.User;
import com.monsanto.prisma.core.dto.UserDTO;
import com.monsanto.prisma.core.exception.BusinessException;
import com.monsanto.prisma.core.exception.UserNotFoundException;
import com.monsanto.prisma.core.service.ProfileService;
import com.monsanto.prisma.core.service.RegionService;
import com.monsanto.prisma.core.service.UserService;
import com.monsanto.prisma.web.utils.JsonResponse;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

/**
 * Created by EPESTE on 03/10/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class UserController_UT {
    @InjectMocks
    private UserController userController;

    @Mock
    private UserService userServiceMock;

    @Mock
    private ProfileService profileServiceMock;

    @Mock
    private RegionService regionServiceMock;

    private User user;

    @Before
    public void setUp() {
        user = new User();
        user.setId(1l);
        user.setUserName("username");
        user.setFullName("fullname");
        user.setEnabled(Boolean.TRUE);
        user.setProfiles(null);
        user.setRegions(null);
        List<User> users = new ArrayList<User>();
        users.add(user);

        Profile profile = new Profile();
        profile.setId(1);
        profile.setName("profile");
        profile.setEnabled(Boolean.TRUE);
        List<PrismaFunctionality> prismaFunctionalities = new ArrayList<PrismaFunctionality>();
        PrismaFunctionality prismaFunctionality = new PrismaFunctionality();
        prismaFunctionality.setId(1);
        prismaFunctionality.setFunctionality("LOT");
        prismaFunctionality.setAction("READ");
        prismaFunctionalities.add(prismaFunctionality);
        profile.setPrismaFunctionalityList(prismaFunctionalities);

        List<Profile> profiles = new ArrayList<Profile>();
        profiles.add(profile);

        Region region = new Region();
        region.setId(1);
        region.setName("LAN");

        List<Region> regions = new ArrayList<Region>();
        regions.add(region);

        when(userServiceMock.findAll()).thenReturn(users);
        when(profileServiceMock.findByEnabled(any(Boolean.class))).thenReturn(profiles);
        when(regionServiceMock.findAll()).thenReturn(regions);
    }

    @Test
    public void init_withUser_returnUserPage() {
        ModelAndView modelAndView = userController.init();

        verify(userServiceMock, times(1)).findAll();
        verify(profileServiceMock, times(1)).findByEnabled(any(Boolean.class));
        verify(regionServiceMock, times(1)).findAll();

        Assert.assertEquals("userList", modelAndView.getViewName());
    }

    @Test
    public void update_withUserOK_returnResponse() throws BusinessException {
        when(userServiceMock.update(any(UserDTO.class))).thenReturn(user);

        userController.update(new UserDTO());

        verify(userServiceMock, times(1)).update(any(UserDTO.class));
    }

    @Test
    public void update_withErrorInUpdate_returnResponse() throws BusinessException {
        when(userServiceMock.update(any(UserDTO.class))).thenThrow(new BusinessException(""));

        JsonResponse jsonResponse = userController.update(new UserDTO());

        verify(userServiceMock, times(1)).update(any(UserDTO.class));
        Assert.assertEquals(Boolean.FALSE, jsonResponse.getSuccess());
    }

    @Test
    public void delete_withIdUserOK_returnUserDeleted() throws BusinessException, UserNotFoundException {
        when(userServiceMock.delete(any(Integer.class))).thenReturn(user);

        userController.delete(1);

        verify(userServiceMock, times(1)).delete(any(Integer.class));
    }

    @Test
    public void newUser_withUserDTO_returnResponse() throws BusinessException, UserNotFoundException {
        when(userServiceMock.newUser(any(UserDTO.class))).thenReturn(user);

        UserDTO userDTO = new UserDTO();
        userDTO.setUserName("username");
        userDTO.setFullName("fullname");
        userDTO.setEnabled(true);
        userDTO.setProfiles(null);
        userDTO.setRegions(null);
        JsonResponse jsonResponse = userController.newUser(userDTO);

        verify(userServiceMock, times(1)).newUser(any(UserDTO.class));
        Assert.assertEquals(true, jsonResponse.getSuccess());
    }

    @Test
    public void newUser_withErrorInSave_returnException() throws BusinessException, UserNotFoundException {
        when(userServiceMock.newUser(any(UserDTO.class))).thenThrow(new BusinessException(""));

        UserDTO userDTO = new UserDTO();
        userDTO.setUserName("username");
        userDTO.setFullName("fullname");
        userDTO.setEnabled(true);
        userDTO.setProfiles(null);
        userDTO.setRegions(null);
        JsonResponse jsonResponse = userController.newUser(userDTO);

        verify(userServiceMock, times(1)).newUser(any(UserDTO.class));
        Assert.assertEquals(false, jsonResponse.getSuccess());
    }
}
