package com.monsanto.prisma.web.exception;

import org.junit.Test;
import org.springframework.util.Assert;

/**
 * Created by PGSETT on 15/10/2014.
 */
public class ControllerException_UT {
    @Test
    public void testControllerException() {

        ControllerException a = new ControllerException();
        Assert.isTrue(a != null);
    }

    @Test
    public void testControllerException_whenHaveMessage() {

        ControllerException a = new ControllerException("Test Message");
        Assert.isTrue(a.getMessage().equals("Test Message"));
    }

    @Test
    public void testControllerException_whenHaveThrowable() {

        ControllerException a = new ControllerException(new Exception("Test Message"));
        Assert.isTrue(a != null);
    }

    @Test
    public void testControllerException_whenHaveThrowableAndMessage() {

        ControllerException a = new ControllerException("Other message", new Exception("Test Message"));
        Assert.isTrue(a != null);
    }
}
