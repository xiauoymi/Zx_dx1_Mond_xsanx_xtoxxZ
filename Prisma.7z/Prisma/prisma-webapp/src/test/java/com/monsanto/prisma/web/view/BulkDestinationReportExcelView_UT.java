package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.BulkDestinationReportDTO;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.service.CampaignService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static org.mockito.Mockito.when;

/**
 * Created by PGSETT on 16/09/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class BulkDestinationReportExcelView_UT {
    @Mock
    private CampaignService campaignService;

    @Mock
    private MessageSource messageSource;

    @InjectMocks
    private BulkDestinationReportExcelView view = new BulkDestinationReportExcelView();

    private Map model;

    @Before
    public void setUp() throws Exception {

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(1);
        campaignTonDTO.setProgram("");
        campaignTonDTO.setHarvestRealWeekFrom(new Float(1));
        campaignTonDTO.setHarvestRealWeekTo(new Float(50));

        List<BulkDestinationReportDTO> bulkDestinationReportDTOs = new ArrayList<BulkDestinationReportDTO>();
        Object[] objects = new Object[3];
        objects[0] = "unidad de almacenaje";
        objects[1] = "Program";
        objects[2] = 2D;


        BulkDestinationReportDTO bulkDestinationReportDTO = new BulkDestinationReportDTO(objects);
        bulkDestinationReportDTOs.add(bulkDestinationReportDTO);
        when(campaignService.filterBulkDestinationReport(campaignTonDTO, 1)).thenReturn(bulkDestinationReportDTOs);
        bulkDestinationReportDTOs = campaignService.filterBulkDestinationReport(campaignTonDTO, 1);

        model = PowerMockito.mock(Map.class);
        when(model.get("bulkDestinationExcel")).thenReturn(bulkDestinationReportDTOs);
        when(model.get("campaignTonDTO")).thenReturn(campaignTonDTO);
        Locale locale = LocaleContextHolder.getLocale();
        when(messageSource.getMessage("test", null, locale)).thenReturn("test");
    }

    @Test
    public void buildExcelDocument_whenHasBulkReport() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }
}
