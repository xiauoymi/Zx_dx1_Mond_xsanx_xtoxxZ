package com.monsanto.prisma.web.view;

import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.prisma.core.dto.BulkDestinationReportDTO;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.service.CampaignService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static org.mockito.Mockito.when;

/**
 * Created by PGSETT on 16/09/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class BulkDestinationReportPDFView_UT {
    @Mock
    private CampaignService campaignService;

    @Mock
    private MessageSource messageSource;

    @InjectMocks
    private BulkDestinationReportPDFView view = new BulkDestinationReportPDFView();

    private Map model;

    @Before
    public void setUp() throws Exception {

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(1);
        campaignTonDTO.setProgram("");
        campaignTonDTO.setHarvestRealWeekFrom(new Float(1));
        campaignTonDTO.setHarvestRealWeekTo(new Float(50));

        List<BulkDestinationReportDTO> bulkDestinationReportDTOs = new ArrayList<BulkDestinationReportDTO>();
        Object[] objects = new Object[3];
        objects[0] = "unidad de almacenaje";
        objects[1] = "Program";
        objects[2] = 2D;


        BulkDestinationReportDTO bulkDestinationReportDTO = new BulkDestinationReportDTO(objects);
        bulkDestinationReportDTOs.add(bulkDestinationReportDTO);
        when(campaignService.filterBulkDestinationReport(campaignTonDTO, 1)).thenReturn(bulkDestinationReportDTOs);
        bulkDestinationReportDTOs = campaignService.filterBulkDestinationReport(campaignTonDTO, 1);

        model = PowerMockito.mock(Map.class);
        when(model.get("bulkDestinationPDF")).thenReturn(bulkDestinationReportDTOs);
        when(model.get("campaignTonDTO")).thenReturn(campaignTonDTO);
        Locale locale = LocaleContextHolder.getLocale();
        when(messageSource.getMessage("test", null, locale)).thenReturn("test");
    }

    @Test
    public void buildExcelDocument_whenHasBulkReport() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        ByteArrayOutputStream baos = PowerMockito.mock(ByteArrayOutputStream.class);
        Document document = new Document(PageSize.A4);
        PdfWriter pdfWriter = PdfWriter.getInstance(document, baos);

        document.open();
        view.buildPdfDocument(model, document, pdfWriter, request, response);
        Assert.assertTrue(pdfWriter.getPageNumber() > 0);
        document.close();

    }
}

