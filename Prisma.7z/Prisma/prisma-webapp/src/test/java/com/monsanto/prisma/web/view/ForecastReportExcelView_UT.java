package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.DataReportForecastDTO;
import com.monsanto.prisma.core.dto.ForecastReportDTO;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.ForecastService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.context.MessageSource;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

import static org.mockito.Mockito.when;

/**
 * Created by PGSETT on 15/12/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class ForecastReportExcelView_UT {
    @Mock
    private CampaignService campaignService;
    @Mock
    private MessageSource messageSource;
    @InjectMocks
    private ForecastReportExcelView forecastReportExcelView = new ForecastReportExcelView();
    @Mock
    private ForecastService forecastService;

    private Map model;

    private ForecastReportDTO forecastReportDTO;

    @Before
    public void setUp() throws Exception {
        model = PowerMockito.mock(Map.class);
        when(model.get("campaignId")).thenReturn(1);

        forecastReportDTO = new ForecastReportDTO();
        forecastReportDTO.setDsForecastDTOs(new ArrayList<DataReportForecastDTO>());
        forecastReportDTO.setFngForecastDTOs(new ArrayList<DataReportForecastDTO>());
        List<Date> ranges = new ArrayList<Date>();
        Calendar cal = Calendar.getInstance();
        cal.set(2014,10,10);
        ranges.add(cal.getTime());
        cal.set(2014,11,10);
        ranges.add(cal.getTime());
        forecastReportDTO.setRange(ranges);

        List<DataReportForecastDTO> list = new ArrayList<DataReportForecastDTO>();
        Object[] objects = new Object[5];
        objects[0] = "granProgram";
        objects[1] = "2013/10";
        objects[2] = 10D;
        objects[3] = "2013/10";
        objects[4] = 10D;
        DataReportForecastDTO dataReportForecastDTO = new DataReportForecastDTO(objects);
        list.add(dataReportForecastDTO);

        forecastReportDTO.setRwForecastDTOs(list);
        forecastReportDTO.setDsForecastDTOs(list);
        forecastReportDTO.setFngForecastDTOs(list);

        when(model.get("forecastReportDTO")).thenReturn(forecastReportDTO);
    }

    @Test
    public void buildExcelDocument_whenHasValues() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        HSSFWorkbook workbook = new HSSFWorkbook();
        forecastReportExcelView.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }
}
