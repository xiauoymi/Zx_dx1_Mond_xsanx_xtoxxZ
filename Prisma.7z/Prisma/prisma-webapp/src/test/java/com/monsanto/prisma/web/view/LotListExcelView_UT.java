package com.monsanto.prisma.web.view;

import com.google.common.base.Function;
import com.google.common.collect.Lists;
import com.monsanto.prisma.core.domain.*;
import com.monsanto.prisma.core.dto.LotDTO;
import com.monsanto.prisma.core.service.LotService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;

import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

/**
 * Created by PGSETT on 13/08/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class LotListExcelView_UT {

    @Mock
    private LotService lotService;

    @InjectMocks
    private LotListExcelView view = new LotListExcelView();

    private LotDTO lotDTO;
    private Lot lot1;
    private Lot lot2;
    private Campaign campaign1;
    private Crop crop;
    private Region region;
    private Country country;
    private User user;
    private Map model;

    @Before
    public void setUp() throws Exception {
        crop = new Crop();
        crop.setId(1);
        crop.setName("SOJA");

        region = new Region();
        region.setId(1);
        region.setName("LAS");

        country = new Country();
        country.setId(1);
        country.setName("ARGENTINA");
        country.setRegion(region);

        Season season1 = new Season();
        season1.setId(1);
        season1.setName("season1");
        season1.setMaxCampaigns(1);
        season1.setCrop(crop);
        season1.setCountry(country);

        lot1 = new Lot();
        lot1.setId(1);
        lot1.setLotCode("OQ577L2A");
        lot1.setEstablishment(new Establishment());
        lot1.getEstablishment().setZone(new Zone());
        lot1.getEstablishment().getZone().setArea(new Area());
        lot1.setHybrid(new Hybrid());
        lot1.getHybrid().setHybridType(new HybridType());
        lot1.setUser(new User());
        lot1.setCampaign(new Campaign());
        lot1.setRegisteredHas(1F);
        lot1.setEstimatedPlantingDate(new Date());
        lot1.setPlantingWeek(1);
        campaign1 = new Campaign();
        campaign1.setId(1);
        campaign1.setName("campaignName");
        campaign1.setCrop(crop);
        campaign1.setSeason(season1);
        campaign1.setObservations("observations");
        campaign1.setFilePath("filePath");
        campaign1.setIsActive(true);
        campaign1.setIsReal(true);
        campaign1.setCode("code");

        this.lot2 = new Lot();
        this.lot2.setId(2);
        this.lot2.setLotCode("OQ577L2B");
        this.lot2.setEstablishment(new Establishment());
        this.lot2.getEstablishment().setZone(new Zone());
        this.lot2.getEstablishment().getZone().setArea(new Area());
        this.lot2.setHybrid(new Hybrid());
        this.lot2.getHybrid().setHybridType(new HybridType());
        this.lot2.setUser(new User());
        this.lot2.setCampaign(campaign1);

        user = new User("anonymous");
        user.setEnabled(true);
        user.setId(1L);
        user.setFullName("");
        user.setRegions(Arrays.asList(region));

        lotDTO = new LotDTO(this.lot2);

        LotHumidity lotHumidity = new LotHumidity();
        lotHumidity.setLot(lot1);
        lotHumidity.setHumidity(25F);
        lotHumidity.setSampleDate(new Date());

        List<Lot> lotList = new ArrayList<Lot>();
        lotList.add(lot1);
        lotList.add(lot2);
        when(lotService.findActiveLotsByCampaignId(1)).thenReturn(lotList);
        List<LotDTO> lotDTOList = Lists.transform(lotService.findActiveLotsByCampaignId(1), new Function<Lot, LotDTO>() {
            @Nullable
            @Override
            public LotDTO apply(@Nullable Lot lot) {
                return new LotDTO(lot, false);
            }
        });

        model = PowerMockito.mock(Map.class);
        when(model.get("lotListExcel")).thenReturn(lotDTOList);
        when(model.get("datePattern")).thenReturn("MM/dd/yy");
    }

    @Test
    public void buildExcelDocument_whenHasLots() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets()>0);
    }
}
