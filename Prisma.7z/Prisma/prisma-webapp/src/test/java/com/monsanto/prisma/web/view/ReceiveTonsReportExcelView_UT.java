package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.ReceiveTonsDTO;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.TonsReportService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

/**
 * Created by PGSETT on 17/09/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class ReceiveTonsReportExcelView_UT {
    @Mock
    private CampaignService campaignService;
    @Mock
    private TonsReportService tonsReportService;
    @Mock
    private MessageSource messageSource;

    @InjectMocks
    private ReceiveTonsReportExcelView view = new ReceiveTonsReportExcelView();

    private Map model;

    @Before
    public void setUp() throws Exception {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(1);
        campaignTonDTO.setProgram("");
        campaignTonDTO.setLotCode("");
        campaignTonDTO.setZoneId(1);
        campaignTonDTO.setHybridId(1);
        campaignTonDTO.setHarvestRealWeekFrom(new Float(1));
        campaignTonDTO.setHarvestRealWeekTo(new Float(50));
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);

        List<ReceiveTonsDTO> receiveTonsDTOs = new ArrayList<ReceiveTonsDTO>();

        Object[] objects = new Object[4];
        objects[0] = "zona";
        objects[1] = 1f;
        objects[2] = "2014";
        objects[3] = 2d;
        ReceiveTonsDTO receiveTonsDTO = new ReceiveTonsDTO(objects, true);
        receiveTonsDTO.setLotCode("lot");
        receiveTonsDTO.setProgram("program");
        receiveTonsDTO.setHybridName("hibrido");
        receiveTonsDTO.setZoneCode("zone");
        receiveTonsDTOs.add(receiveTonsDTO);

        objects = new Object[4];
        objects[0] = "zona2";
        objects[1] = 1f;
        objects[2] = "2014";
        objects[3] = 2d;
        receiveTonsDTO = new ReceiveTonsDTO(objects, true);
        receiveTonsDTO.setLotCode("lot");
        receiveTonsDTO.setProgram("program");
        receiveTonsDTO.setHybridName("hibrido");
        receiveTonsDTO.setZoneCode("zone");
        receiveTonsDTOs.add(receiveTonsDTO);

        when(tonsReportService.findReceivingTonsByZone(1, 1, today, tomorrow)).thenReturn(receiveTonsDTOs);
        when(tonsReportService.findReceivingTonsByHybrid(1, 1, today, tomorrow)).thenReturn(receiveTonsDTOs);
        when(tonsReportService.findReceiveTons(1, "l.lotCode", "lot", today, tomorrow)).thenReturn(receiveTonsDTOs);
        when(tonsReportService.findReceiveTons(1, "l.program", "program", today, tomorrow)).thenReturn(receiveTonsDTOs);
        receiveTonsDTOs = tonsReportService.findReceivingTonsByZone(1, 1, today, tomorrow);

        model = PowerMockito.mock(Map.class);
        when(model.get("receiveTonsReportXls")).thenReturn(receiveTonsDTOs);
        when(model.get("campaignTonWeeks")).thenReturn(receiveTonsDTOs);
        when(model.get("campaignTonDTO")).thenReturn(campaignTonDTO);

        Locale locale = LocaleContextHolder.getLocale();
        when(messageSource.getMessage("test", null, locale)).thenReturn("test");
    }

    @Test
    public void buildExcelDocument_whenHasBulkReport_zone() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        HSSFWorkbook workbook = new HSSFWorkbook();
        when(model.get("_optionFilter")).thenReturn(2);
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }

    @Test
    public void buildExcelDocument_whenHasBulkReport_LotCode() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();
        when(model.get("_optionFilter")).thenReturn(1);
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }

    @Test
    public void buildExcelDocument_whenHasBulkReport_HybridName() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();
        when(model.get("_optionFilter")).thenReturn(3);
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }

    @Test
    public void buildExcelDocument_whenHasBulkReport_program() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();
        when(model.get("_optionFilter")).thenReturn(4);
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }

    @Test
    public void buildExcelDocument_emptyList() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        when(model.get("receiveTonsReportXls")).thenReturn(new ArrayList<ReceiveTonsDTO>());

        HSSFWorkbook workbook = new HSSFWorkbook();
        when(model.get("_optionFilter")).thenReturn(1);
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }

    @Test(expected = Exception.class)
    public void buildExcelDocument_exception() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        when(model.get("receiveTonsReportXls")).thenReturn(new ArrayList<ReceiveTonsDTO>());

        HSSFWorkbook workbook = new HSSFWorkbook();
        when(model.get("_optionFilter")).thenReturn(1);
        view.buildExcelDocument(null, workbook, request, response);

    }
}
