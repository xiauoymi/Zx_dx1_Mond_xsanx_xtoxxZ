package com.monsanto.prisma.web.view;

import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.ReceiveTonsDTO;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.TonsReportService;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.util.*;

import static org.mockito.Mockito.when;

/**
 * Created by PGSETT on 17/09/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class ReceiveTonsReportPdfView_UT {
    @Mock
    private CampaignService campaignService;
    @Mock
    private TonsReportService tonsReportService;
    @Mock
    private MessageSource messageSource;

    @InjectMocks
    private ReceiveTonsReportPdfView view = new ReceiveTonsReportPdfView();

    private Map model;

    @Before
    public void setUp() throws Exception {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(1);
        campaignTonDTO.setProgram("");
        campaignTonDTO.setLotCode("");
        campaignTonDTO.setHybridId(1);
        campaignTonDTO.setZoneId(1);
        campaignTonDTO.setHarvestRealWeekFrom(1F);
        campaignTonDTO.setHarvestRealWeekTo(50F);
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);

        List<ReceiveTonsDTO> receiveTonsDTOs = new ArrayList<ReceiveTonsDTO>();
        Object[] objects = new Object[4];
        objects[0] = "zona";
        objects[1] = 1F;
        objects[2] = "2";
        objects[3] = 3D;


        ReceiveTonsDTO receiveTonsDTO = new ReceiveTonsDTO(objects, true);
        receiveTonsDTOs.add(receiveTonsDTO);
        when(tonsReportService.findReceivingTonsByZone(1, 1, today, tomorrow)).thenReturn(receiveTonsDTOs);
        when(tonsReportService.findReceivingTonsByHybrid(1, 1, today, tomorrow)).thenReturn(receiveTonsDTOs);
        when(tonsReportService.findReceiveTons(1, "l.lotCode","", today, tomorrow)).thenReturn(receiveTonsDTOs);
        when(tonsReportService.findReceiveTons(1, "l.program","", today, tomorrow)).thenReturn(receiveTonsDTOs);
        receiveTonsDTOs = tonsReportService.findReceivingTonsByZone(1, 1, today, tomorrow);

        model = PowerMockito.mock(Map.class);
        when(model.get("receiveTonsReportPdf")).thenReturn(receiveTonsDTOs);
        when(model.get("campaignTonDTO")).thenReturn(campaignTonDTO);
        when(model.get("campaignTonWeeks")).thenReturn(receiveTonsDTOs);

        Locale locale = LocaleContextHolder.getLocale();
        when(messageSource.getMessage("test", null, locale)).thenReturn("test");
    }

    @Test
    public void buildExcelDocument_whenHasBulkReport() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        ByteArrayOutputStream baos = PowerMockito.mock(ByteArrayOutputStream.class);
        Document document = new Document(PageSize.A4);
        PdfWriter pdfWriter = PdfWriter.getInstance(document, baos);
        when(model.get("_optionFilter")).thenReturn(2);
        document.open();
        view.buildPdfDocument(model, document, pdfWriter, request, response);
        Assert.assertTrue(pdfWriter.getPageNumber() > 0);
        document.close();
    }

    @Test
    public void buildExcelDocument_lotCode_whenHasBulkReport() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        ByteArrayOutputStream baos = PowerMockito.mock(ByteArrayOutputStream.class);
        Document document = new Document(PageSize.A4);
        PdfWriter pdfWriter = PdfWriter.getInstance(document, baos);
        when(model.get("_optionFilter")).thenReturn(1);
        document.open();
        view.buildPdfDocument(model, document, pdfWriter, request, response);
        Assert.assertTrue(pdfWriter.getPageNumber() > 0);
        document.close();

    }


    @Test
    public void buildExcelDocument_program_whenHasBulkReport() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        ByteArrayOutputStream baos = PowerMockito.mock(ByteArrayOutputStream.class);
        Document document = new Document(PageSize.A4);
        PdfWriter pdfWriter = PdfWriter.getInstance(document, baos);
        when(model.get("_optionFilter")).thenReturn(4);
        document.open();
        view.buildPdfDocument(model, document, pdfWriter, request, response);
        Assert.assertTrue(pdfWriter.getPageNumber() > 0);
        document.close();

    }

    @Test
    public void buildExcelDocument_hybrid_whenHasBulkReport() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        ByteArrayOutputStream baos = PowerMockito.mock(ByteArrayOutputStream.class);
        Document document = new Document(PageSize.A4);
        PdfWriter pdfWriter = PdfWriter.getInstance(document, baos);
        when(model.get("_optionFilter")).thenReturn(3);
        document.open();
        view.buildPdfDocument(model, document, pdfWriter, request, response);
        Assert.assertTrue(pdfWriter.getPageNumber() > 0);
        document.close();
    }

    @Test(expected = Exception.class)
    public void buildExcelDocument_exception() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        view.buildPdfDocument(null, new Document(),null, request, response);
    }
}
