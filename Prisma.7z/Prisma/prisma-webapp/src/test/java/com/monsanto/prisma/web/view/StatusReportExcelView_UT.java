package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.StatusReportDTO;
import com.monsanto.prisma.core.service.CampaignService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static org.mockito.Mockito.when;

/**
 * Created by PGSETT on 16/09/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class StatusReportExcelView_UT {
    @Mock
    private CampaignService campaignService;

    @Mock
    private MessageSource messageSource;

    @InjectMocks
    private StatusReportExcelView view = new StatusReportExcelView();

    private Map model;

    @Before
    public void setUp() throws Exception {

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(1);
        campaignTonDTO.setProgram("");
        campaignTonDTO.setHarvestRealWeekFrom(1F);
        campaignTonDTO.setHarvestRealWeekTo(50F);

        List<StatusReportDTO> statusReportDTOs = new ArrayList<StatusReportDTO>();
        Object[] objects = new Object[3];
        objects[0] = "hybridName";
        objects[1] = 1D;
        objects[2] = 2D;

        StatusReportDTO statusReportDTO = new StatusReportDTO(objects);
        statusReportDTO.setGermoplasma("LT");
        statusReportDTO.setGranProgram("WINTER");

        StatusReportDTO statusReportDTO2 = new StatusReportDTO(objects);
        statusReportDTO2.setGermoplasma("LT");
        statusReportDTO2.setGranProgram("WINTER");

        StatusReportDTO statusReportDTO3 = new StatusReportDTO(objects);
        statusReportDTO3.setGermoplasma("LT");
        statusReportDTO3.setGranProgram("TEMPLADO");

        statusReportDTOs.add(statusReportDTO);
        statusReportDTOs.add(statusReportDTO2);
        statusReportDTOs.add(statusReportDTO3);
        when(campaignService.filterToStatusReport(campaignTonDTO, 1)).thenReturn(statusReportDTOs);
        statusReportDTOs = campaignService.filterToStatusReport(campaignTonDTO, 1);

        model = PowerMockito.mock(Map.class);
        when(model.get("statusReportExcel")).thenReturn(statusReportDTOs);
        when(model.get("campaignTonDTO")).thenReturn(campaignTonDTO);
        Locale locale = LocaleContextHolder.getLocale();
        when(messageSource.getMessage("test", null, locale)).thenReturn("test");
    }

    @Test
    public void buildExcelDocument_whenHasStatusReport() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }
}
