package com.monsanto.prisma.web.view;

import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.TonsToHostDTO;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.TonsReportService;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.*;

import static org.mockito.Mockito.when;

/**
 * Created by PGSETT on 16/09/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class TonsToHostReportExcelView_UT {

    @Mock
    private CampaignService campaignService;

    @Mock
    private TonsReportService tonsReportService;

    @Mock
    private MessageSource messageSource;

    @InjectMocks
    private TonsToHostReportExcelView view = new TonsToHostReportExcelView();

    private Map model;
    List<TonsToHostDTO> tonsToHostDTOs;
    TonsToHostDTO tonsToHostDTO;
    CampaignTonDTO campaignTonDTO;

    @Before
    public void setUp() throws Exception {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(1);
        campaignTonDTO.setProgram("");
        campaignTonDTO.setHarvestRealWeekFrom(new Float(1));
        campaignTonDTO.setHarvestRealWeekTo(new Float(50));
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);

        model = PowerMockito.mock(Map.class);
        when(model.get("tonsToHostReportExcel")).thenReturn(tonsToHostDTOs);
        when(model.get("campaignTonDTO")).thenReturn(campaignTonDTO);
        when(model.get("weeksTonsToHost")).thenReturn(tonsToHostDTOs);

        Locale locale = LocaleContextHolder.getLocale();
        when(messageSource.getMessage("test", null, locale)).thenReturn("test");
    }

    @Test
    public void buildExcelDocument_whenHasTonsToHost_program() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();
        tonsToHostDTOs = new ArrayList<TonsToHostDTO>();
        Object[] objects = new Object[4];
        objects[0] = "Plant Name";
        objects[1] = 1F;
        objects[2] = "2014";
        objects[3] = 2D;
        tonsToHostDTO = new TonsToHostDTO(objects, false);
        tonsToHostDTOs.add(tonsToHostDTO);
        when(tonsReportService.filterTonsToHostReport(1, "l.program", "Program", campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(tonsToHostDTOs);
        tonsToHostDTOs = tonsReportService.filterTonsToHostReport(1, "l.program", "Program", campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
        when(model.get("_optionFilter")).thenReturn(4);
        when(model.get("weeksTonsToHost")).thenReturn(tonsToHostDTOs);
        when(model.get("tonsToHostReportExcel")).thenReturn(tonsToHostDTOs);
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);


    }

    @Test
    public void buildExcelDocument_whenHasTonsToHost_lotCode() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();
        tonsToHostDTOs = new ArrayList<TonsToHostDTO>();
        Object[] objects = new Object[4];
        objects[0] = "Plant Name";
        objects[1] = 1F;
        objects[2] = "2014";
        objects[3] = 2D;
        tonsToHostDTO = new TonsToHostDTO(objects, false);
        tonsToHostDTOs.add(tonsToHostDTO);

        when(tonsReportService.filterTonsToHostReport(1, "l.lotCode", "lotCode", campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(tonsToHostDTOs);
        tonsToHostDTOs = tonsReportService.filterTonsToHostReport(1, "l.lotCode", "lotCode", campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
        when(model.get("_optionFilter")).thenReturn(1);
        when(model.get("weeksTonsToHost")).thenReturn(tonsToHostDTOs);
        when(model.get("tonsToHostReportExcel")).thenReturn(tonsToHostDTOs);
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);

    }

    @Test
    public void buildExcelDocument_whenHasTonsToHost_zone() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();

        when(model.get("_optionFilter")).thenReturn(2);
        tonsToHostDTOs = new ArrayList<TonsToHostDTO>();
        Object[] objects = new Object[4];
        objects[0] = "Plant Name";
        objects[1] = 1F;
        objects[2] = "2014";
        objects[3] = 2D;
        tonsToHostDTO = new TonsToHostDTO(objects, true);
        tonsToHostDTOs.add(tonsToHostDTO);
        when(tonsReportService.filterTonsToHostReportByZone(1, 1, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(tonsToHostDTOs);
        when(tonsReportService.filterWeekTonsToHostReportByZone(1, 1, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(tonsToHostDTOs);
        tonsToHostDTOs = tonsReportService.filterTonsToHostReportByZone(1, 1, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
        when(model.get("weeksTonsToHost")).thenReturn(tonsToHostDTOs);
        when(model.get("tonsToHostReportExcel")).thenReturn(tonsToHostDTOs);
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }

    @Test
    public void buildExcelDocument_whenHasTonsToHost_hybrid() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();

        when(model.get("_optionFilter")).thenReturn(3);
        tonsToHostDTOs = new ArrayList<TonsToHostDTO>();
        Object[] objects = new Object[4];
        objects[0] = "Plant Name";
        objects[1] = 1F;
        objects[2] = "2014";
        objects[3] = 2D;
        tonsToHostDTO = new TonsToHostDTO(objects, true);
        tonsToHostDTOs.add(tonsToHostDTO);
        when(tonsReportService.filterTonsToHostReportByHybrid(1, 1, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(tonsToHostDTOs);
        when(tonsReportService.filterWeekTonsToHostReportByHybrid(1, 1, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(tonsToHostDTOs);
        tonsToHostDTOs = tonsReportService.filterTonsToHostReportByHybrid(1, 1, campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
        when(model.get("weeksTonsToHost")).thenReturn(tonsToHostDTOs);
        when(model.get("tonsToHostReportExcel")).thenReturn(tonsToHostDTOs);
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }

    @Test
    public void buildExcelDocument_whenIsEmptyList() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);

        HSSFWorkbook workbook = new HSSFWorkbook();
        tonsToHostDTOs = new ArrayList<TonsToHostDTO>();

        when(tonsReportService.filterTonsToHostReport(1, "l.lotCode", "LotCode", campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(tonsToHostDTOs);
        tonsToHostDTOs = tonsReportService.filterTonsToHostReport(1, "l.LotCode", "LotCode", campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());
        when(model.get("_optionFilter")).thenReturn(1);
        when(model.get("weeksTonsToHost")).thenReturn(tonsToHostDTOs);
        when(model.get("tonsToHostReportExcel")).thenReturn(tonsToHostDTOs);
        view.buildExcelDocument(model, workbook, request, response);
        Assert.assertTrue(workbook.getNumberOfSheets() > 0);
    }

    @Test(expected = Exception.class)
    public void buildExcelDocument_exception() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        view.buildExcelDocument(model, null, request, response);
    }


}