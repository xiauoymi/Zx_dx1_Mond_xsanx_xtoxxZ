package com.monsanto.prisma.web.view;

import com.lowagie.text.Document;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;
import com.monsanto.prisma.core.dto.CampaignTonDTO;
import com.monsanto.prisma.core.dto.TonsToHostDTO;
import com.monsanto.prisma.core.service.CampaignService;
import com.monsanto.prisma.core.service.TonsReportService;
import org.joda.time.DateTime;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayOutputStream;
import java.util.*;

import static org.mockito.Mockito.when;

/**
 * Created by PGSETT on 17/09/2014.
 */
@RunWith(MockitoJUnitRunner.class)
public class TonsToHostReportPDFView_UT {

    @Mock
    private CampaignService campaignService;

    @Mock
    private MessageSource messageSource;

    @InjectMocks
    private TonsToHostReportPDFView view = new TonsToHostReportPDFView();

    private Map model;
    @Mock
    private TonsReportService tonsReportService;

    @Before
    public void setUp() throws Exception {
        DateTime dateTime = new DateTime(new Date());
        Date today = dateTime.toDate();
        Date tomorrow = dateTime.plusDays(1).toDate();

        CampaignTonDTO campaignTonDTO = new CampaignTonDTO();
        campaignTonDTO.setCampaignId(1);
        campaignTonDTO.setProgram("");
        campaignTonDTO.setHarvestRealWeekFrom(new Float(1));
        campaignTonDTO.setHarvestRealWeekTo(new Float(50));
        campaignTonDTO.setHarvestDateFrom(today);
        campaignTonDTO.setHarvestDateTo(tomorrow);

        List<TonsToHostDTO> tonsToHostDTOs = new ArrayList<TonsToHostDTO>();
        Object[] objects = new Object[4];
        objects[0] = "Plant Name";
        objects[1] = 1F;
        objects[2] = "2014";
        objects[3] = 2D;
        TonsToHostDTO tonsToHostDTO = new TonsToHostDTO(objects, false);
        tonsToHostDTOs.add(tonsToHostDTO);
        when(tonsReportService.filterTonsToHostReport(1, "l.program", "Program", campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo())).thenReturn(tonsToHostDTOs);
        tonsToHostDTOs = tonsReportService.filterTonsToHostReport(1, "l.program", "Program", campaignTonDTO.getHarvestDateFrom(), campaignTonDTO.getHarvestDateTo());

        model = PowerMockito.mock(Map.class);
        when(model.get("tonsToHostReportPDF")).thenReturn(tonsToHostDTOs);
        when(model.get("campaignTonDTO")).thenReturn(campaignTonDTO);
        when(model.get("weeksTonsToHost")).thenReturn(tonsToHostDTOs);
        when(model.get("_optionFilter")).thenReturn(4);
        Locale locale = LocaleContextHolder.getLocale();
        when(messageSource.getMessage("test", null, locale)).thenReturn("test");
    }

    @Test
    public void buildPdfDocument_whenHasTonsToHost() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        ByteArrayOutputStream baos = PowerMockito.mock(ByteArrayOutputStream.class);
        Document document = new Document(PageSize.A4);
        PdfWriter pdfWriter = PdfWriter.getInstance(document, baos);

        document.open();
        view.buildPdfDocument(model, document, pdfWriter, request, response);
        Assert.assertTrue(pdfWriter.getPageNumber() > 0);
        document.close();
    }

    @Test(expected = Exception.class)
    public void buildPdfDocument_exception() throws Exception {
        HttpServletRequest request = PowerMockito.mock(HttpServletRequest.class);
        HttpServletResponse response = PowerMockito.mock(HttpServletResponse.class);
        view.buildPdfDocument(model, null, null,request, response);
    }

}
