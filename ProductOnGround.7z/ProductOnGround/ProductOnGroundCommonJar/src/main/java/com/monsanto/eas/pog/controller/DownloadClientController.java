package com.monsanto.eas.pog.controller;

import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.util.PogConstants;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 11, 2010 Time: 10:30:40 AM To change this template use File |
 * Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/download")
public class DownloadClientController extends AbstractController {

  @RequestMapping(method = RequestMethod.GET)
  protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws
      Exception {
    PogUser wamUser = (PogUser) request.getSession(true).getAttribute(PogConstants.WAM_POG_USER);
    if (wamUser == null) {
      return new ModelAndView(PogConstants.NOT_AUTHORIZED_VIEW);
    } else {
      if (wamUser.isInSalesRepRole()) {
        return new ModelAndView(PogConstants.DOWNLOAD_CLIENT_VIEW);
      } else {
        return new ModelAndView(PogConstants.NOT_AUTHORIZED_VIEW);
      }
    }
  }
}
