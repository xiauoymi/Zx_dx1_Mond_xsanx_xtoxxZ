package com.monsanto.eas.pog.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 23, 2010 Time: 9:26:17 AM To change this template use File |
 * Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/exception")
public class ExceptionController extends AbstractController {
  @RequestMapping(method = RequestMethod.GET)
  protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws
      Exception {
    return new ModelAndView();
//    return new ModelAndView(PogConstants.ERROR_VIEW);
  }
}
