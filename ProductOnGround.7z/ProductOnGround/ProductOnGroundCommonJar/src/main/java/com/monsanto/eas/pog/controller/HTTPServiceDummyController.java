package com.monsanto.eas.pog.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 25, 2010 Time: 10:24:18 AM To change this template use File |
 * Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/dummyHTTPService")
public class HTTPServiceDummyController extends AbstractController {
  @RequestMapping(method = RequestMethod.GET)
  protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws
      Exception {
    final PrintWriter out = response.getWriter();
    try {
      out.print("Dummy ping to avoid duplicate session issue");
    }
    finally {
      out.close();
    }
    return null;
  }
}
