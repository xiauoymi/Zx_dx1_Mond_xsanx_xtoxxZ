package com.monsanto.eas.pog.controller;

import com.monsanto.eas.pog.services.ProductService;
import com.monsanto.eas.pog.util.PogConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 9, 2010 Time: 11:10:52 AM To change this template use File |
 * Settings | File Templates.
 */
@Controller
@RequestMapping(value = "/refdata")
public class ReferenceDataController extends AbstractController {
  @Autowired
  private ProductService productService;

  @RequestMapping(method = RequestMethod.GET)
  protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws
      Exception {
//    productService.setProductMapInServletContext(getServletContext());
    return new ModelAndView(PogConstants.REF_DATA_VIEW);
  }
}
