package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.Area;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 18, 2010 Time: 2:32:18 PM To change this template use File |
 * Settings | File Templates.
 */
@Transactional
public interface AreaDao extends GenericDao<Area, Long> {
}
