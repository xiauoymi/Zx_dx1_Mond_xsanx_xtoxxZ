package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.Area;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 18, 2010 Time: 2:32:25 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class AreaDaoImpl extends HibernateDao<Area, Long> implements AreaDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, Area.class);
  }
}