package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.BaseUnitOfMeasure;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 6, 2010 Time: 11:30:24 AM To change this template use File |
 * Settings | File Templates.
 */
@Transactional
public interface BaseUnitOfMeasureDao extends GenericDao<BaseUnitOfMeasure, Long> {
}
