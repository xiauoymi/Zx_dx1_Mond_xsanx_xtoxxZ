package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CaptureType;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 21, 2010 Time: 1:13:46 PM To change this template use File |
 * Settings | File Templates.
 */
@Transactional
public interface CaptureTypeDao extends GenericDao<CaptureType, Long> {
}
