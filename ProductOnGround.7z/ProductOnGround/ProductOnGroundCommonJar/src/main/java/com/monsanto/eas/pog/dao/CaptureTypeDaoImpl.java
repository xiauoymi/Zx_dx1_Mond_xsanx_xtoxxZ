package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CaptureType;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 21, 2010 Time: 1:14:11 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class CaptureTypeDaoImpl extends HibernateDao<CaptureType, Long> implements CaptureTypeDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, CaptureType.class);
  }
}
