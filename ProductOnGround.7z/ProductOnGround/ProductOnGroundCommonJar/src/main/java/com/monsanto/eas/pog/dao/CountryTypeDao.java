package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CountryType;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 21, 2010 Time: 2:00:43 PM To change this template use File |
 * Settings | File Templates.
 */
@Transactional
public interface CountryTypeDao extends GenericDao<CountryType, Long>{
  public CountryType lookupByType(String countryType) throws Exception;
}
