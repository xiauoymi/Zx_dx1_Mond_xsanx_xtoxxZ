package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CountryType;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 21, 2010 Time: 2:00:03 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class CountryTypeDaoImpl extends HibernateDao<CountryType, Long> implements CountryTypeDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, CountryType.class);
  }

  public CountryType lookupByType(String countryType) throws Exception {
    CountryType example = new CountryType();
    example.setType(countryType);
    Collection<CountryType> matchingEntry = findByExample(example, new String[0]);
    if (matchingEntry.isEmpty()) {
      throw new Exception("No country type found with type: " + countryType);
    }
    return matchingEntry.iterator().next();
  }
}
