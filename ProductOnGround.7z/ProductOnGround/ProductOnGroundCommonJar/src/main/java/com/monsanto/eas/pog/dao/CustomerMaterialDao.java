package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CustomerMaterial;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Transactional
public interface CustomerMaterialDao extends GenericDao<CustomerMaterial, Long> {
  Collection<CustomerMaterial> lookupByCustomerPk(Long customerPk);
}
