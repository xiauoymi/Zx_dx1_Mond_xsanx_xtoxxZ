package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CustomerMaterial;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Repository
public class CustomerMaterialDaoImpl extends HibernateDao<CustomerMaterial, Long> implements CustomerMaterialDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, CustomerMaterial.class);
  }

  public Collection<CustomerMaterial> lookupByCustomerPk(Long customerPk) {
    Criteria criteria = createCriteria(false);
    criteria.add(Restrictions.eq("pogUser.id", customerPk));
    return criteria.list();
  }
}
