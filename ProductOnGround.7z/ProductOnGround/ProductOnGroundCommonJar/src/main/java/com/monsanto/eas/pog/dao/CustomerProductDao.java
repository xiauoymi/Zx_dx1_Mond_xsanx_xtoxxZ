package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CustomerProduct;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA. User: SSPATI1 Date: Jul 8, 2010 Time: 11:06:56 AM To change this template use File |
 * Settings | File Templates.
 */
@Transactional
public interface CustomerProductDao extends GenericDao<CustomerProduct, Long> {
  CustomerProduct lookupInactiveByDistributorProductCodeAndBaseUomCode(Long distributorId, String productCode,
                                                                       String baseUomCode, String materialId);
}
