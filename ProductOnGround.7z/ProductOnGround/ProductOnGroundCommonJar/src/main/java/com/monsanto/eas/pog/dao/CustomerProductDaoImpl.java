package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CustomerProduct;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * Created by IntelliJ IDEA. User: SSPATI1 Date: Jul 8, 2010 Time: 11:07:04 AM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class CustomerProductDaoImpl extends HibernateDao<CustomerProduct, Long>
    implements CustomerProductDao {

  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, CustomerProduct.class);
  }

  public CustomerProduct lookupInactiveByDistributorProductCodeAndBaseUomCode(Long distributorId, String productCode,
                                                                              String baseUomCode, String materialId) {
    Criteria criteria = createCriteria(true);
    criteria.add(Restrictions.eq("distributor.id", distributorId));
    criteria.createAlias("product", "sProduct");
    criteria.createAlias("sProduct.baseUnitOfMeasure", "baseUom");
    criteria.add(Restrictions.eq("sProduct.code", productCode));
    criteria.add(Restrictions.eq("sProduct.materialId", materialId));
    criteria.add(Restrictions.eq("baseUom.code", baseUomCode));
    return (CustomerProduct) criteria.uniqueResult();
  }
            }
