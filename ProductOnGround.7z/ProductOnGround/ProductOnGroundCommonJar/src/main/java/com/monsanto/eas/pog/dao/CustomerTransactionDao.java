package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CustomerTransaction;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jul 10, 2010 Time: 1:13:06 PM To change this template use File |
 * Settings | File Templates.
 */
@Transactional
public interface CustomerTransactionDao {
  Collection<CustomerTransaction> lookupByDistributorIdYearAndMonthRange(Long distributorId, Long year,
                                                                                    Long month, Long endYear,
                                                                                    Long endMonth);

  Collection<CustomerTransaction> lookupByParentDistributorIdYearAndMonthRange(Long parentDistributorId,
                                                                               Long year,
                                                                               Long month, Long endYear,
                                                                               Long endMonth);
}
