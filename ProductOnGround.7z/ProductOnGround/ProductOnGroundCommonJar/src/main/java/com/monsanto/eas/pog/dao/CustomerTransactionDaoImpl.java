package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CustomerTransaction;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jul 10, 2010 Time: 1:13:29 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class CustomerTransactionDaoImpl extends HibernateDao<CustomerTransaction, Long>
    implements CustomerTransactionDao {

  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, CustomerTransaction.class);
  }

  public Collection<CustomerTransaction> lookupByDistributorIdYearAndMonthRange(Long distributorId, Long year,
                                                                                Long month, Long endYear,
                                                                                Long endMonth) {
    return filterByYearAndMonth(distributorId, false, year, month, endYear, endMonth);
  }

  public Collection<CustomerTransaction> lookupByParentDistributorIdYearAndMonthRange(Long parentDistributorId,
                                                                                      Long year,
                                                                                      Long month, Long endYear,
                                                                                      Long endMonth) {
    Collection<CustomerTransaction> customerTransactions = filterByYearAndMonth(parentDistributorId, true, year, month,
        endYear, endMonth);
    customerTransactions.addAll(filterByYearAndMonth(parentDistributorId, false, year, month, endYear, endMonth));
    return customerTransactions;

  }

  private Collection<CustomerTransaction> filterByYearAndMonth(Long distributorId, boolean isParent, Long year,
                                                               Long month,
                                                               Long endYear, Long endMonth) {
    final Long DECEMBER = (long) 12;
    final Long JANUARY = (long) 1;

    Criteria criteria = createCriteria(true);
    criteria.createAlias("customerProduct", "custProduct");
    criteria.createCriteria("custProduct.distributor", "dist");
    if (isParent) {
      criteria.createCriteria("dist.parentUser", "parent");
      criteria.add(Restrictions.eq("parent.id", distributorId));
    } else {
      criteria.add(Restrictions.eq("dist.id", distributorId));
    }
    criteria.add(Restrictions.eq("custProduct.deleted", false));
    //filter customer transaction by year and month range here

    if (month != null && endMonth != null) {
      //Watch out if endMonth is less than mont. for ex. month = 7 endMonth = 6
      if (month > endMonth) {
        criteria.add(Restrictions.or(
            Restrictions.and(Restrictions.between("month", month, DECEMBER), Restrictions.eq("year", year)),
            Restrictions.and(Restrictions.between("month", JANUARY, endMonth), Restrictions.eq("year", endYear))));
      } else {
        criteria.add(Restrictions.between("month", month, endMonth));
      }
    }

    if (year != null && endYear != null) {
      criteria.add(Restrictions.between("year", year, endYear));
    }
    criteria.createAlias("custProduct.product", "product");
    criteria.createAlias("product.productCode", "productCode");
    criteria.addOrder(Order.asc("productCode.languageProducts"));
    return criteria.list();
  }

}
