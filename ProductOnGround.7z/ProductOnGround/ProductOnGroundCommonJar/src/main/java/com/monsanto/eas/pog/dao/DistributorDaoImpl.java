package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.DistributorType;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * Created by IntelliJ IDEA.
 * User: sspati1
 * Date: 2/28/11
 * Time: 1:38 PM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class DistributorDaoImpl extends HibernateDao<DistributorType, Long> implements DistributorTypeDao {
    @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
        super.setupSessionFactory(sessionFactory, DistributorType.class);
    }
}
