package com.monsanto.eas.pog.dao;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.classic.Session;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import java.io.Serializable;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 18, 2010 Time: 9:59:21 AM To change this template use File |
 * Settings | File Templates.
 */
public class HibernateDao<T, ID extends Serializable> extends HibernateDaoSupport implements GenericDao<T, ID> {
    private Class<? extends T> persistentClass;

    public void setupSessionFactory(SessionFactory sessionFactory, Class<? extends T> persistentClass) {
        this.persistentClass = persistentClass;
        this.setSessionFactory(sessionFactory);
    }

    public T findByPrimaryKey(ID id) {
        return (T) getCurrentSession().get(persistentClass, id);
    }

    public Collection<T> findAll() {
        Criteria criteria = createCriteria(false);
        return criteria.list();
    }

    public Collection<T> findAll(int startIndex, int fetchSize) {
        Criteria criteria = createCriteria(false);
        criteria.setFirstResult(startIndex);
        criteria.setFetchSize(fetchSize);
        return criteria.list();
    }

    public Collection<T> findAll(String key, boolean ascending) {
        Order order = getOrder(key, ascending);
        Criteria criteria = createCriteria(false);
        return criteria.addOrder(order).list();
    }

    public Collection<T> findByExample(T exampleInstance, String[] excludeProperty) {
        Criteria criteria = createCriteria();
        Example example = Example.create(exampleInstance).ignoreCase();
        for (String anExcludeProperty : excludeProperty) {
            example.excludeProperty(anExcludeProperty);
        }
        criteria.add(example);
        return criteria.list();
    }

    public T saveOrUpdate(T entity) {
        getCurrentSession().saveOrUpdate(entity);
        return entity;
    }

    public T merge(T entity) {
        Object object = getCurrentSession().merge(entity);
        return (T) object;
    }

    public void delete(T entity) {
        getCurrentSession().delete(entity);
    }

    public void clear() {
        getCurrentSession().clear();
    }

    public void flush() {
        getCurrentSession().flush();
    }

//  public void beginTransaction() {
//    getCurrentSession().beginTransaction();
//  }
//
//  public void commitTransaction() {
//  }

    public Criteria createCriteria() {
        return getCurrentSession().createCriteria(persistentClass);
    }

    public Criteria createCriteria(boolean isDeleted) {
        Criteria criteria = getCurrentSession().createCriteria(persistentClass);
        if (doesClassHaveIsDeleted()) {
            criteria.add(Restrictions.eq("deleted", isDeleted));
        }
        return criteria;
    }

    public Criteria createCriteria(String alias, boolean isDeleted) {
        Criteria criteria = getCurrentSession().createCriteria(persistentClass, alias);
        if (doesClassHaveIsDeleted()) {
            criteria.add(Restrictions.eq("deleted", isDeleted));
        }
        return criteria;
    }

    private boolean doesClassHaveIsDeleted() {
        try {
            persistentClass.getMethod("isDeleted");
        } catch (NoSuchMethodException e) {
            return false;
        }
        return true;
    }


    private Session getCurrentSession() {
        return getSessionFactory().getCurrentSession();
    }

    private Order getOrder(String key, boolean ascending) {
        Order order;
        if (ascending) {
            order = Order.asc(key);
        } else {
            order = Order.desc(key);
        }
        return order;
    }
}
