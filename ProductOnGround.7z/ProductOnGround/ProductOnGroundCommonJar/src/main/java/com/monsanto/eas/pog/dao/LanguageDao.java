/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.DistributorType;
import com.monsanto.eas.pog.model.hibernate.Language;
import org.springframework.transaction.annotation.Transactional;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Transactional
public interface LanguageDao extends GenericDao<Language, Long> {
}