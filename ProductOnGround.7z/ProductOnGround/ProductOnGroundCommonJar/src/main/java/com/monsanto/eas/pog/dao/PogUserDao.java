package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.dao.exception.UserNotFoundException;
import com.monsanto.eas.pog.model.hibernate.Area;
import com.monsanto.eas.pog.model.hibernate.Locale;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.CustomizedPOGUser;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 18, 2010 Time: 5:28:21 PM To change this template use File |
 * Settings | File Templates.
 */
@Transactional
public interface PogUserDao extends GenericDao<PogUser, Long> {
  PogUser findByUserId(String userId) throws UserNotFoundException;

  Collection<PogUser> lookupAllLevel1DistributorsBySalesRepUserId(String salesRepUserId);

  Collection<PogUser> lookupAllSalesReps();

  Collection<PogUser> lookupSalesRepsByAreaAndCountryType(Area area, String countryTypeName);


  Collection<PogUser> lookupAllInternalUsersForAssociatedAreas(PogUser user);


  Collection<PogUser> lookupAllLevel1DistributorsByAreaFilterAssociatedDistributors(Collection<Area> areaIds);

  Collection<PogUser> lookupSalesRepsByAreaAndCountryType(Collection<Area> areas, String countryTypeName);

  PogUser findBySapId(String sapId) throws UserNotFoundException;

  Collection<PogUser> lookupAllLevel1Distributors();

  Collection<Locale> lookupDistinctLocales();

  Collection<PogUser> lookupAvailableLevel1DistributorsByCountryCode(Collection<String> countryCodes);

  Collection<PogUser> lookupLevel1DistributorsWithNoHomeCountryInUserArea();

  Collection<PogUser> lookupLevel1DistributorsWithUpdatedHomeCountry();

  Collection<CustomizedPOGUser> lookupAdminsWithoutSalesRep();

  void updateAdmins();

  Collection<CustomizedPOGUser> lookupAllSalesRepsNotCapturedMonthlyData(int month, int year);
}
