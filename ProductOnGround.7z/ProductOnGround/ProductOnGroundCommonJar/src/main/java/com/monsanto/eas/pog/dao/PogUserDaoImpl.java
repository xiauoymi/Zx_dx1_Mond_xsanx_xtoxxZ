package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.dao.exception.UserNotFoundException;
import com.monsanto.eas.pog.model.hibernate.*;
import com.monsanto.eas.pog.model.CustomizedPOGUser;
import com.monsanto.eas.pog.util.PogConstants;
import com.monsanto.eas.pog.util.SQLUtil;
import org.hibernate.Criteria;
import org.hibernate.FetchMode;
import org.hibernate.SessionFactory;
import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.hibernate.criterion.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 18, 2010 Time: 5:28:53 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class PogUserDaoImpl extends HibernateDao<PogUser, Long> implements PogUserDao {

  private List<PogUser> adminsWithOutSalesRep;
  private static final String SALES_REP_ROLE_NAME = "SALES_REP";
  private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger
      (PogUserDaoImpl.class.getName());

  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, PogUser.class);
  }

  public PogUser findByUserId(String userId) throws UserNotFoundException {
    PogUser example = new PogUser();
    example.setUserId(userId);
    String[] exclude = new String[3];
    exclude[0] = "internal";
//    exclude[1] = "level";
    exclude[1] = "depth";
    exclude[2] = "deleted";
    Collection<PogUser> pogUsers = findByExample(example, exclude);
    if (pogUsers.isEmpty()) {
      logger.error("User Id " + userId + " not found in the system.");
      throw new UserNotFoundException("No user found with userId: " + userId);
    }
    if (pogUsers.size() > 1) {
      logger.error("More than one user found in the system with userId: " + userId);
      throw new UserNotFoundException("More than one user found with userId: " + userId);
    }
    return pogUsers.iterator().next();
  }

  public PogUser findBySapId(String sapId) throws UserNotFoundException {
    Criteria criteria = createCriteria();
    criteria.add(Restrictions.eq("sapId", sapId));
    List pogUsers = criteria.list();
    if (pogUsers.isEmpty()) {
      logger.error("SAP Id " + sapId + " not found in the system.");
      throw new UserNotFoundException("No user found with sapId: " + sapId);
    }
    if (pogUsers.size() > 1) {
      logger.error("More than one user found in the system with userId: " + sapId);
      throw new UserNotFoundException("More than one user found with userId: " + sapId);
    }

    return pogUsers.isEmpty() ? null : (PogUser) pogUsers.iterator().next();
  }

  public Collection<PogUser> lookupAllLevel1DistributorsBySalesRepUserId(String salesRepUserId) {
    Criteria criteria = createCriteria(false);
//    criteria.add(Restrictions.eq("level", 1));
    criteria.add(Restrictions.isNull("parentUser"));
    criteria.add(Restrictions.eq("internal", false));
    criteria.add(Restrictions.isNotNull("sapId"));
    criteria.createAlias("salesRep", "sr");
    criteria.add(Restrictions.eq("sr.userId", salesRepUserId).ignoreCase());
    criteria.addOrder(Order.asc("firstName"));
    return criteria.list();
  }

  public Collection<PogUser> lookupAllLevel1Distributors() {
    Criteria criteria = createCriteria(false);
    criteria.add(Restrictions.isNull("parentUser"));
    criteria.add(Restrictions.eq("internal", false));
    criteria.createCriteria("userAreas", "ua", CriteriaSpecification.INNER_JOIN);
    criteria.setFetchMode("customerProducts", FetchMode.JOIN);
    return criteria.list();
  }

  public Collection<PogUser> lookupAllSalesReps() {
    return getPosUsersByRoleName(SALES_REP_ROLE_NAME);
  }

  public Collection<PogUser> lookupSalesRepsByAreaAndCountryType(Area area, String countryTypeName) {
    Collection<Area> areas = new ArrayList<Area>();
    areas.add(area);
    return lookupSalesRepsByAreaAndCountryType(areas, countryTypeName);
  }

  public Collection<PogUser> lookupSalesRepsByAreaAndCountryType(Collection<Area> areas, String countryTypeName) {
    Criteria criteria = createCriteria(false);
    criteria.createAlias("roles", "r").add(Restrictions.eq("r.roleName", SALES_REP_ROLE_NAME));

    //We find all the areas where countryType = HOksME
    DetachedCriteria countryTypeCriteria = DetachedCriteria.forClass(CountryType.class);
    countryTypeCriteria.add(Restrictions.eq("type", countryTypeName));
    countryTypeCriteria.setProjection(Projections.property("id"));

    //We find all the user areas
    DetachedCriteria areaCriteria = DetachedCriteria.forClass(UserArea.class);
    areaCriteria.add(Restrictions.in("pk.area", areas));
    areaCriteria.add(Subqueries.propertyIn("pk.countryType.id", countryTypeCriteria));
    areaCriteria.setProjection(Projections.property("pk.pogUser.id"));
    criteria.add(Subqueries.propertyIn("id", areaCriteria));

    criteria.addOrder(Order.asc("firstName"));
    return criteria.list();
  }

  private List<PogUser> getPosUsersByRoleName(String roleName) {
    Criteria criteria = createCriteria(false);
    criteria.createAlias("roles", "r").add(Restrictions.eq("r.roleName", roleName));
    return criteria.list();
  }

  public Collection<PogUser> lookupAllInternalUsersForAssociatedAreas(PogUser user) {
    Collection<UserArea> associatedAreas = user.getAssociatedAreas();
    Collection<Area> areas = new ArrayList<Area>();
    for (UserArea assocArea : associatedAreas) {
      areas.add(assocArea.getPk().getArea());
    }

    Criteria criteria = createCriteria(false);
    criteria.add(Restrictions.eq("internal", true));

    DetachedCriteria countryTypeCriteria = DetachedCriteria.forClass(CountryType.class);
    countryTypeCriteria.add(Restrictions.eq("type", PogConstants.HOME_COUNTRY_TYPE));
    countryTypeCriteria.setProjection(Projections.property("id"));

    //We find all the user areas
    DetachedCriteria areaCriteria = DetachedCriteria.forClass(UserArea.class);
    areaCriteria.add(Restrictions.in("pk.area", areas));
    areaCriteria.add(Subqueries.propertyIn("pk.countryType.id", countryTypeCriteria));
    areaCriteria.setProjection(Projections.property("pk.pogUser.id"));
    criteria.add(Expression.or(Restrictions.eq("id", user.getId()), Subqueries.propertyIn("id", areaCriteria)));
    criteria.addOrder(Order.asc("firstName"));
    return criteria.list();
  }

  public Collection<PogUser> lookupAllLevel1DistributorsByAreaFilterAssociatedDistributors(Collection<Area> areas) {
    List<PogUser> distributorsByArea = new ArrayList<PogUser>();
    Collection<Long> areaIds = new ArrayList<Long>();
    for (Area area : areas) {
      areaIds.add(area.getId());
    }
    Criteria criteria = createCriteria(false);
    criteria.add(Restrictions.isNull("parentUser"));
    criteria.add(Restrictions.eq("internal", false));
    criteria.createAlias("salesRep", "sr");
    criteria.add(Restrictions.isNotNull("sr.id"));
    //We find all the areas where countryType = HOksME
    DetachedCriteria countryTypeCriteria = DetachedCriteria.forClass(CountryType.class);
    countryTypeCriteria.add(Restrictions.eq("type", PogConstants.HOME_COUNTRY_TYPE));
    countryTypeCriteria.setProjection(Projections.property("id"));

    //We find all the user areas
    DetachedCriteria areaCriteria = DetachedCriteria.forClass(UserArea.class);
    areaCriteria.add(Restrictions.in("pk.area.id", areaIds));
    areaCriteria.add(Subqueries.propertyEq("pk.countryType.id", countryTypeCriteria));
    areaCriteria.setProjection(Projections.property("pk.pogUser.id"));
    criteria.add(Subqueries.propertyIn("id", areaCriteria));
    distributorsByArea.addAll(criteria.list());

    return distributorsByArea;
  }

  public Collection<Locale> lookupDistinctLocales() {
    Criteria criteria = createCriteria(false);
    criteria.createAlias("locale", "loc");
    criteria.setProjection(Projections.distinct(Projections.property("locale")));
    return criteria.list();
  }

  public Collection<PogUser> lookupAvailableLevel1DistributorsByCountryCode(Collection<String> countryCodes) {
    Criteria criteria = createCriteria(false);
    criteria.add(Restrictions.isNull("parentUser"));
    criteria.add(Restrictions.eq("internal", false));
    criteria.add(Restrictions.isNull("salesRep"));
    //We find all the areas where countryType = HOksME
    DetachedCriteria countryTypeCriteria = DetachedCriteria.forClass(CountryType.class);
    countryTypeCriteria.add(Restrictions.eq("type", PogConstants.HOME_COUNTRY_TYPE));
    countryTypeCriteria.setProjection(Projections.property("id"));

    DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class);
    areaCriteria.add(Restrictions.in("areaCode", countryCodes));
    areaCriteria.setProjection(Projections.property("id"));

    //We find all the user areas
    DetachedCriteria userAreaCriteria = DetachedCriteria.forClass(UserArea.class);
    userAreaCriteria.add(Subqueries.propertyEq("pk.area", areaCriteria));
    userAreaCriteria.add(Subqueries.propertyEq("pk.countryType.id", countryTypeCriteria));
    userAreaCriteria.setProjection(Projections.property("pk.pogUser.id"));
    criteria.add(Subqueries.propertyIn("id", userAreaCriteria));

    return criteria.list();
  }

  public Collection<PogUser> lookupLevel1DistributorsWithNoHomeCountryInUserArea() {
    Criteria criteria = createCriteria(false);
    criteria.add(Restrictions.isNull("parentUser"));
    criteria.add(Restrictions.isNotNull("sapId"));
    criteria.add(Restrictions.eq("internal", false));
    DetachedCriteria countryTypeCriteria = DetachedCriteria.forClass(CountryType.class);
    countryTypeCriteria.add(Restrictions.eq("type", PogConstants.HOME_COUNTRY_TYPE));
    countryTypeCriteria.setProjection(Projections.property("id"));

    DetachedCriteria userAreaCriteria = DetachedCriteria.forClass(UserArea.class);
    userAreaCriteria.add(Subqueries.propertyEq("pk.countryType.id", countryTypeCriteria));
    userAreaCriteria.setProjection(Projections.property("pk.pogUser.id"));
    criteria.add(Subqueries.propertyNotIn("id", userAreaCriteria));

    return criteria.list();
  }

  public Collection<PogUser> lookupLevel1DistributorsWithUpdatedHomeCountry() {
    Criteria criteria = createCriteria("us", false);
    criteria.add(Restrictions.isNull("us.parentUser"));
    criteria.add(Restrictions.isNotNull("us.sapId"));
    criteria.add(Restrictions.eq("us.internal", false));

    DetachedCriteria countryTypeCriteria = DetachedCriteria.forClass(CountryType.class, "ct");
    countryTypeCriteria.add(Restrictions.eq("ct.type", PogConstants.HOME_COUNTRY_TYPE));
    countryTypeCriteria.setProjection(Projections.property("ct.id"));

    DetachedCriteria areaCriteria = DetachedCriteria.forClass(Area.class, "ar");
    areaCriteria.add(Restrictions.eqProperty("ar.areaCode", "us.countryCode"));
    areaCriteria.setProjection(Projections.property("id"));

    DetachedCriteria userAreaCriteria = DetachedCriteria.forClass(UserArea.class, "ua");
    userAreaCriteria.add(Subqueries.propertyEq("ua.pk.countryType.id", countryTypeCriteria));
    userAreaCriteria.add(Subqueries.propertyEq("ua.pk.area.id", areaCriteria));

    userAreaCriteria.setProjection(Projections.property("ua.pk.pogUser.id"));

    criteria.add(Subqueries.propertyNotIn("us.id", userAreaCriteria));

    return criteria.list();
  }

    public Collection<CustomizedPOGUser> lookupAdminsWithoutSalesRep() {
        Query query = getSessionFactory().getCurrentSession().createSQLQuery(SQLUtil.areaAdmins).setResultTransformer(Transformers.aliasToBean(CustomizedPOGUser.class));
        return query.list();
    }

    public Collection<CustomizedPOGUser> lookupAllSalesRepsNotCapturedMonthlyData(int month, int year) {
        Query query = getSessionFactory().getCurrentSession().createSQLQuery(SQLUtil.salesReps_notCapturedData).setResultTransformer(Transformers.aliasToBean(CustomizedPOGUser.class));
        query.setParameter("month",month);
        query.setParameter("year",year);
        return query.list();
    }


     public void updateAdmins() {
           Query query = getSessionFactory().getCurrentSession().createSQLQuery(SQLUtil.setDealerStatus_adminEmails);
           query.executeUpdate();
         
      }


}
