/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.ProductCode;
import com.monsanto.eas.pog.model.hibernate.Product;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Transactional
public interface ProductCodeDao extends GenericDao<ProductCode, Long> {
    public Collection<ProductCode> lookupProductsByAreaId(Long areaId);
    public Collection<Product> lookupStagedProductsByAreaId(Long areaId);
}