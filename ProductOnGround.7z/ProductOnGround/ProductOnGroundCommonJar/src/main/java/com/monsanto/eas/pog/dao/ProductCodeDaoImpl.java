/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.*;
import com.monsanto.eas.pog.util.SQLUtil;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.Query;
import org.hibernate.criterion.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Repository
public class ProductCodeDaoImpl extends HibernateDao<ProductCode, Long> implements ProductCodeDao {
    @Autowired
    public void setupSessionFactory(SessionFactory sessionFactory) {
        super.setupSessionFactory(sessionFactory, ProductCode.class);
    }

    public Collection<ProductCode> lookupProductsByAreaId(Long areaId) {
        //TODO check whether the commented conditions are needed for Product Tab

        Criteria areaCriteria = getSessionFactory().getCurrentSession().createCriteria(Area.class);
        areaCriteria.add(Restrictions.eq("id", areaId));
        areaCriteria.setProjection(Projections.property("areaCode"));
        String countryCode = areaCriteria.list().get(0).toString();
        String countryBasedQuery = null;

        if ("ES".equalsIgnoreCase(countryCode))
            countryBasedQuery = SQLUtil.spainQuery;
        else if ("GB".equalsIgnoreCase(countryCode))
            countryBasedQuery = SQLUtil.ukQuery;

        //System.out.println("countryBasedQuery : "+countryBasedQuery);

        Query query = getSessionFactory().getCurrentSession().createSQLQuery(countryBasedQuery).addEntity("com.monsanto.eas.pog.model.hibernate.ProductCode");
        List<ProductCode> prodList = query.list();

        return prodList;

    }

    public Collection<Product> lookupStagedProductsByAreaId(Long areaId) {

        Criteria productStagingCriteria = getSessionFactory().getCurrentSession().createCriteria(Product.class);
        productStagingCriteria.add(Restrictions.in("productCode", lookupProductsByAreaId(areaId)));
        //System.out.println("size : " + productStagingCriteria.list().size());
        return productStagingCriteria.list();
        
    }

}