package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.*;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 25, 2011 Time: 1:18:18 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class ProductDaoImpl extends HibernateDao<Product, Long> implements ProductDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, Product.class);
  }

  public Product lookupByCodeBaseUomIdAndMaterialId(String productCode, Long baseUomId, String materialId) {
    Criteria criteria = createCriteria(false);
    criteria.add(Restrictions.eq("code", productCode));
    criteria.add(Restrictions.eq("baseUnitOfMeasure.id", baseUomId));
    criteria.add(Restrictions.eq("materialId", materialId));
    return (Product) criteria.uniqueResult();
  }

  public Collection<Product> lookupBySalesRepUserId(String salesRepUserId) {
    Criteria criteria = createCriteria(false);
    DetachedCriteria userCriteria = DetachedCriteria.forClass(PogUser.class);
    userCriteria.createAlias("salesRep", "sr");
    userCriteria.add(Restrictions.eq("sr.userId", salesRepUserId).ignoreCase());
    userCriteria.setProjection(Projections.property("id"));


    DetachedCriteria customerProductCriteria = DetachedCriteria.forClass(CustomerProduct.class);
    customerProductCriteria.add(Restrictions.eq("deleted", false));
    customerProductCriteria.add(Subqueries.propertyIn("distributor.id", userCriteria));
    customerProductCriteria.setProjection(Projections.property("product.id"));

    criteria.add(Subqueries.propertyIn("id", customerProductCriteria));

    return criteria.list();
  }
}
