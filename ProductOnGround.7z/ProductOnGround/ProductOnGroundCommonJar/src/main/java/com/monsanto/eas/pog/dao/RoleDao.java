package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.Role;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 27, 2010 Time: 9:27:56 AM To change this template use File |
 * Settings | File Templates.
 */
@Transactional
public interface RoleDao extends GenericDao<Role, Long> {
  public Collection<Role> lookupByExample(String roleName) throws Exception;
}
