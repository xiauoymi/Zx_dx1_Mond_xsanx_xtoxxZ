package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.dao.exception.PogRoleNotFoundException;
import com.monsanto.eas.pog.model.hibernate.Role;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 27, 2010 Time: 9:30:13 AM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class RoleDaoImpl extends HibernateDao<Role, Long> implements RoleDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, Role.class);
  }

  public Collection<Role> lookupByExample(String roleName) throws Exception {
    Role role = new Role();
    role.setRoleName(roleName);
    String[] exclude = new String[5];
    exclude[0] = "id";
    exclude[1] = "modUser";
    exclude[2] = "modDate";
    Collection<Role> roles = findByExample(role, exclude);
    if (roles.size() <= 0) {
      throw new PogRoleNotFoundException("Role : " + roleName + " not found");
    }
    return roles;
  }
}
