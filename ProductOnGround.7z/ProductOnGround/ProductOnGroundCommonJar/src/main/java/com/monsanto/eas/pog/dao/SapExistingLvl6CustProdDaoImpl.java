package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.temp.SapExistingCustProd;
import com.monsanto.eas.pog.model.hibernate.temp.SapExistingLvl6CustProd;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 25, 2011 Time: 2:20:56 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository("sapExistingLvl6CustProdDao")
public class SapExistingLvl6CustProdDaoImpl extends HibernateDao<SapExistingCustProd, Long>
    implements SapExistingCustProdDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, SapExistingLvl6CustProd.class);
  }
}
