package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.temp.SapNewCustProd;
import com.monsanto.eas.pog.model.hibernate.temp.SapNewLvl6CustProd;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 25, 2011 Time: 1:41:22 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository("sapNewLvl6CustProdDao")
public class SapNewLvl6CustProdDaoImpl extends HibernateDao<SapNewCustProd, Long>
    implements SapNewCustProdDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, SapNewLvl6CustProd.class);
  }
}
