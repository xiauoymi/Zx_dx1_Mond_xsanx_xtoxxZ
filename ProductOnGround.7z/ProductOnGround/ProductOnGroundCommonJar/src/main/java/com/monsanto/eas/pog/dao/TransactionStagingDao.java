package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.temp.TransactionStaging;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 26, 2011 Time: 1:13:16 PM To change this template use File |
 * Settings | File Templates.
 */
@Transactional
public interface TransactionStagingDao extends GenericDao<TransactionStaging, Long>{
  void updateBatchStatus(String status);
}
