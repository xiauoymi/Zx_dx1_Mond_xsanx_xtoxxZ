package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.temp.TransactionStaging;
import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 26, 2011 Time: 1:13:50 PM To change this template use File |
 * Settings | File Templates.
 */
@Repository
public class TransactionStagingDaoImpl extends HibernateDao<TransactionStaging, Long> implements TransactionStagingDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, TransactionStaging.class);
  }

  public void updateBatchStatus(String status) {
    SQLQuery query = getSession().createSQLQuery("update pog.TRANSACTION_STAGING set mod_user = '" + status + "'");
    query.executeUpdate();
  }
}
