/*
 UserAreaDao was created on Jul 19, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.hibernate.UserArea;
import org.springframework.transaction.annotation.Transactional;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
@Transactional
public interface UserAreaDao extends GenericDao<UserArea, Long> {
  void deleteUserAreasForUser(PogUser user);
}