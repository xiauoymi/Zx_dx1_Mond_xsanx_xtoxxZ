/*
 UserAreaDaoImpl was created on Jul 19, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.hibernate.UserArea;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
@Repository
public class UserAreaDaoImpl extends HibernateDao<UserArea, Long> implements UserAreaDao {
  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    super.setupSessionFactory(sessionFactory, UserArea.class);
  }

  public void deleteUserAreasForUser(PogUser user) {
    Collection<UserArea> areas = user.getUserAreas();
    user.setUserAreas(new ArrayList<UserArea>());
    for (UserArea existingArea : areas) {
      delete(existingArea);
    }
//    String hql = "delete from UserArea ua1 where ua1.pk.pogUser.id = " + user.getId();
//    getSessionFactory().getCurrentSession()
//        .createQuery(hql)
//        .executeUpdate();
  }
}