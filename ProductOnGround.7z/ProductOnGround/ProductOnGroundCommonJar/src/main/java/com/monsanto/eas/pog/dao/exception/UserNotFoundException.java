package com.monsanto.eas.pog.dao.exception;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 19, 2010 Time: 1:48:33 PM To change this template use File |
 * Settings | File Templates.
 */
public class UserNotFoundException extends Exception {

  public UserNotFoundException(String message) {
    super(message);
  }
}
