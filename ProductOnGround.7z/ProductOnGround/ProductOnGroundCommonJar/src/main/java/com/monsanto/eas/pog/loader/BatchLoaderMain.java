package com.monsanto.eas.pog.loader;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Calendar;
import java.util.ResourceBundle;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class BatchLoaderMain {
  private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger
      (BatchLoaderMain.class.getName());
  private static final String ENV_D_PARAM = "env";
  private static final String LSI_FUNCTION = "lsi.function";
  private static final String BATCH_JOB_PROPERTIES = "batch-job";

  public static void main(String... arguments) throws Exception {
    ApplicationContext context =
        new ClassPathXmlApplicationContext("applicationContext-standalone.xml");

    String databaseUrl = null;
    String username = null;
    try {
      databaseUrl = getDatabaseUrl();
      username = getDatabaseUsername();
    } catch (Exception e) {
      System.err.println("No database URL/username found. Please pass a -Denv param with value dev,test or prod. ");
      return;
    }

    BasicDataSource dataSource = (BasicDataSource) context.getBean("dataSource");
    //System.out.println("url = " + databaseUrl);
    //System.out.println("username = " + username);
    dataSource.setUrl(databaseUrl);
    dataSource.setUsername(username);
    dataSource.setPassword(
        EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "pog", "CipherValue.hex", "KeyValue.hex"));
    //dataSource.setPassword("Aug12_POG_USER_Q");

    logger.info("Starting UserAreaLoader");
    UserAreaLoader userAreaLoader = (UserAreaLoader) context.getBean("userAreaLoaderImpl");
    userAreaLoader.addUserAreas();
    userAreaLoader.updateUserAreas();
    logger.info("Done with UserAreaLoader");

    logger.info("Starting TransactionLoader");
    TransactionLoader transactionLoader = (TransactionLoader) context.getBean("sapTransactionLoader");
    transactionLoader.loadCustomerProductsWithTransactions();
    logger.info("Done with TransactionLoader");


    logger.info("Preparing the mail to be sent to respective Admins if a new Distributor Added");
    // Getting all the Admins that has no SalesRep assigned
    /*POGEmailer pogEmailer = (POGEmailer) context.getBean("POGEmailerImpl");
    pogEmailer.sendNotificationMailToAdmins(getEnvironment());*/
    // Mail status updated
    /*pogEmailer.updateAdminMailStatus();
    logger.info("Done with sending Notification Mail to All Admins");*/


    /*Calendar calender = Calendar.getInstance();
    int currentDate = calender.get(Calendar.DATE);
    int month = calender.get(calender.MONTH)+1; //zero-based
    int year = calender.get(calender.YEAR);*/

    /*if(currentDate == getSpecifiedDate()) {
    logger.info("Preparing the reminder mail mail to be sent to respective SalesReps ");
    // Getting all the Admins that has not been assigned to SalesRep
    pogEmailer.sendNotificationMailToSalesReps(month,year,getEnvironment());
    logger.info("Done with sending Notification Mail to All SalesReps");
    }*/

  }

  private static String getDatabaseUrl() throws Exception {
    String env = getEnvironment();
    ResourceBundle bundle = ResourceBundle.getBundle(BATCH_JOB_PROPERTIES);
    return bundle.getString(env + ".connection.url");
  }

  private static String getDatabaseUsername() throws Exception {
    String env = getEnvironment();
    ResourceBundle bundle = ResourceBundle.getBundle(BATCH_JOB_PROPERTIES);
    return bundle.getString(env + ".username");
  }

  private static String getEnvironment() {
    String env = System.getProperty(ENV_D_PARAM);
    if (env == null) {
      env = System.getProperty(LSI_FUNCTION);
    }
    System.out.println("Environment is: " + env);
    return env;
  }

  private static int getSpecifiedDate(){

     Calendar calendar = Calendar.getInstance();
     int lastDate = calendar.getActualMaximum(Calendar.DATE);
     int specifiedDate = lastDate - 5;

     return specifiedDate;
  }
}
