package com.monsanto.eas.pog.loader;

import com.monsanto.eas.pog.model.hibernate.PogUser;

import javax.mail.MessagingException;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Collection;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: SMISH
 * Date: Feb 29, 2012
 * Time: 7:23:28 PM
 * To change this template use File | Settings | File Templates.
 */
public interface POGEmailer {

     public void sendNotificationMailToAdmins(String env) throws UnknownHostException, MessagingException, IOException;
     public void sendNotificationMailToSalesReps(int month, int year, String env) throws UnknownHostException, MessagingException, IOException ;
     public void updateAdminMailStatus();

}
