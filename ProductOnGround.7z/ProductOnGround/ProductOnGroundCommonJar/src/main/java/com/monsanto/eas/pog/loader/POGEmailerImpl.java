package com.monsanto.eas.pog.loader;

import com.monsanto.eas.pog.dao.PogUserDao;
import com.monsanto.eas.pog.model.hibernate.Area;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.hibernate.UserArea;
import com.monsanto.eas.pog.model.CustomizedPOGUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.Properties;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: SMISH
 * Date: Feb 28, 2012
 * Time: 12:07:51 PM
 * To change this template use File | Settings | File Templates.
 */
@Component
@Transactional
public class POGEmailerImpl implements POGEmailer {
    @Autowired
    private PogUserDao pogUserDao;

    private Collection<PogUser> adminsWithNoSalesRepId;

    private Collection<CustomizedPOGUser> adminList;

    private Collection<CustomizedPOGUser> salesReps;

    public static final String TEXT_HTML = "text/html";

    public void sendNotificationMailToAdmins(String env) throws UnknownHostException, MessagingException, IOException {

        Properties props = System.getProperties();
        props.put("mail.smtp.host", "mail.monsanto.com");
        //props.put("mail.smtp.host", "gateway4.monsanto.com");
        Session session = Session.getInstance(props, null);
        //Message message = getEmptyMessage(session);
        MimeMessage message = getEmptyMessage(session);
        message.setFrom(new InternetAddress("POG@monsanto.com"));

        String pogUserId = null;
        String firstName = null;
        String areaName = null;
        String pogUserEmail = null;

        adminList = pogUserDao.lookupAdminsWithoutSalesRep();
        //System.out.println("adminList.size : "+adminList.size());

        if (null != adminList && adminList.size() > 0) {
            for (CustomizedPOGUser pogAdmin : adminList) {
                pogUserId = pogAdmin.getUSER_ID();

                if (pogUserId != null && 'Y' == pogAdmin.getEMAIL_FLAG()) {

                    pogUserEmail = pogUserId.concat("@monsanto.com").trim();
                    InternetAddress inetAdd = new InternetAddress(pogUserEmail);
                    message.setRecipient(Message.RecipientType.TO, inetAdd);

                    firstName = pogAdmin.getFIRST_NAME();
                    areaName = pogAdmin.getAREA_NAME();
                    message.setSubject("POG ( "+env+" )  New Distributor available for " + areaName,"UTF-8");

                    String first_Name = firstName;
                    message.setContent(
                            "<i><BR/>" + "<BR/>" +
                                    "Dear " + first_Name + "," +
                                    "<BR/>" + "<BR/>" +
                                    "This is an automated email - please do not reply. If you need help contact your POG administrator." +
                                    "<BR/>" +
                                    "A new Distributor is available in POG that has not yet been allocated to a User.  To assign the Distributor go to POG, " +
                                    "select 'Add/Edit User' & select the user, then the country, after that you may allocate the Distributor to the User by dragging the Distributor to the 'Selected Distributors' box and clicking save." +
                                    "<BR/>" + "<BR/>" +
                                    "Regards," + "<BR/>" +
                                    "<BR/>" +
                                    "POG System<i>", TEXT_HTML);

                    //System.out.println(message.getSubject());
                    //System.out.println(message.getContent().toString());
                    Transport.send(message);
                }
            }
        }

    }

    public void sendNotificationMailToSalesReps(int month, int year, String env) throws UnknownHostException, MessagingException, IOException {


        Properties props = System.getProperties();
        //props.put("mail.smtp.host", "mail.monsanto.com");
        props.put("mail.smtp.host", "mail.monsanto.com");
        Session session = Session.getInstance(props, null);
        MimeMessage message = getEmptyMessage(session);
        message.setFrom(new InternetAddress("POG@monsanto.com"));

        salesReps = pogUserDao.lookupAllSalesRepsNotCapturedMonthlyData(month, year);

        if (null != salesReps && salesReps.size() > 0) {
            for (CustomizedPOGUser pogSalesRep : salesReps) {
                String pogUserId = pogSalesRep.getUSER_ID();
                String firstName = pogSalesRep.getFIRST_NAME();
                if (pogUserId != null) {
                    String pogUserEmail = pogUserId.concat("@monsanto.com").trim();


                    InternetAddress inetAdd = new InternetAddress(pogUserEmail);
                    message.setRecipient(Message.RecipientType.TO, inetAdd);

                    Date date = new Date();
                    String currentMonth = new SimpleDateFormat("MMMM").format(date);
                    message.setSubject("POG ( " + env + " )" + currentMonth + " Reminder", "UTF-8");

                    String first_Name = firstName;

                    message.setContent(
                            "<i><BR/>" + "<BR/>" +
                                    "Dear " + first_Name + "," +
                                    "<BR/>" + "<BR/>" +
                                    "This is an automated email - please do not reply. If you need help contact your POG administrator." +
                                    "<BR/><BR/>" + "Please capture the inventory data " +
                                    "for the month " + currentMonth + ", into the POG application for some/all of your allocated Customers/Distributors if you have not done." +
                                    "If no data is captured within the next 5 days the Customer/Distributor inventory will be locked and in the event of inventory data capture that falls outside the current active month, will require an administrator to unlock.  Please be aware that the customer inventory will be unlocked when the successive active month is reached but will only be editable for that month." +
                                    "<BR/>" + "<BR/>" +
                                    "Regards," + "<BR/>" +
                                    "<BR/>" +
                                    "POG System</i>", TEXT_HTML);

                    //System.out.println(message.getSubject());
                    //System.out.println(message.getContent().toString());

                    Transport.send(message);
                }

            }
        }

    }

    protected MimeMessage getEmptyMessage(Session session) {
        return new MimeMessage(session);
    }


    public void updateAdminMailStatus() {
        pogUserDao.updateAdmins();        
    }
}

