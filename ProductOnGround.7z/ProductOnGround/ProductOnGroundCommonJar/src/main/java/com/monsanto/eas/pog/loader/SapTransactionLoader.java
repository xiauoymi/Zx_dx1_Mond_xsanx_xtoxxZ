package com.monsanto.eas.pog.loader;

import com.monsanto.eas.pog.dao.CustomerProductDao;
import com.monsanto.eas.pog.dao.SapExistingCustProdDao;
import com.monsanto.eas.pog.dao.SapNewCustProdDao;
import com.monsanto.eas.pog.dao.TransactionStagingDao;
import com.monsanto.eas.pog.model.hibernate.CustomerProduct;
import com.monsanto.eas.pog.model.hibernate.CustomerTransaction;
import com.monsanto.eas.pog.model.hibernate.temp.SapExistingCustProd;
import com.monsanto.eas.pog.model.hibernate.temp.SapNewCustProd;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 26, 2011 Time: 9:14:01 AM To change this template use File |
 * Settings | File Templates.
 */
@Component
@Transactional
//to keep hibernate session open to avoid Lazy Init exceptions
public class SapTransactionLoader implements TransactionLoader {
  @Autowired
  @Qualifier("sapNewLvl6CustProdDao")
  private SapNewCustProdDao sapNewLvl6CustProdDao;
  @Autowired
  @Qualifier("sapExistingLvl6CustProdDao")
  private SapExistingCustProdDao sapExistingLvl6CustProdDao;
  @Autowired
  @Qualifier("sapNewLvl5CustProdDao")
  private SapNewCustProdDao sapNewLvl5CustProdDao;
  @Autowired
  @Qualifier("sapExistingLvl5CustProdDao")
  private SapExistingCustProdDao sapExistingLvl5CustProdDao;
  @Autowired
  private TransactionStagingDao transactionStagingDao;
  @Autowired
  private CustomerProductDao customerProductDao;

  private static final String BATCH_INSERT = "BATCH - INSERT";
  private static final String BATCH_UPDATE = "BATCH - UPDATE";
  private static final String BATCH_PROCESSED = "BATCH - PROCESSED";

  public void loadCustomerProductsWithTransactions() {
    createNewCustomerProductsWithTransactions(sapNewLvl6CustProdDao.findAll());
    createNewCustomerProductsWithTransactions(sapNewLvl5CustProdDao.findAll());
    updateExistingCustomerProductsWithTransactions(sapExistingLvl6CustProdDao.findAll());
    updateExistingCustomerProductsWithTransactions(sapExistingLvl5CustProdDao.findAll());
    transactionStagingDao.updateBatchStatus(BATCH_PROCESSED);
  }

  /*
  Create new relationship between customer and product and add a new customer transaction
  */
  private void createNewCustomerProductsWithTransactions(Collection<SapNewCustProd> newCustProducts) {
    Map<String, CustomerProduct> cpMap = getCustomerProductWithTransactions(newCustProducts);

    for (CustomerProduct cp : cpMap.values()) {
      customerProductDao.saveOrUpdate(cp);
    }
  }

  /*
  Update relationship between customer and product and add/update customer transaction
  */
  private void updateExistingCustomerProductsWithTransactions(Collection<SapExistingCustProd> existingCustProducts) {
    for (SapExistingCustProd existingCustProd : existingCustProducts) {
      CustomerTransaction ct = existingCustProd.getCustomerTransaction();
      CustomerProduct cp = existingCustProd.getPk().getCustomerProduct();
      if (ct == null) {
        ct = new CustomerTransaction();
        ct.setYear(existingCustProd.getPk().getYear());
        ct.setMonth(existingCustProd.getPk().getMonth());
        ct.setFinalInventory(0.0);
        ct.setBudget(0.0);
        ct.setSalesAmount(existingCustProd.getSalesAmount());
        ct.setSapSalesAmount(existingCustProd.getSalesAmount());
        ct.setCustomerProduct(cp);
        ct.setModDate(Calendar.getInstance().getTime());
        ct.setModUser(BATCH_INSERT);
        cp.getCustomerTransactions().add(ct);
      } else {
        if (ct.getSalesAmount().equals(ct.getSapSalesAmount())) {
          ct.setSalesAmount(existingCustProd.getSalesAmount());
        }
        ct.setSapSalesAmount(existingCustProd.getSalesAmount());
        ct.setModDate(Calendar.getInstance().getTime());
        ct.setModUser(BATCH_UPDATE);
      }
      cp.setModDate(Calendar.getInstance().getTime());
      customerProductDao.saveOrUpdate(cp);
    }
  }

  private Map<String, CustomerProduct> getCustomerProductWithTransactions(Collection<SapNewCustProd> newCustProds) {
    Map<String, CustomerProduct> cpMap = new HashMap<String, CustomerProduct>();

    for (SapNewCustProd sapNewCustProd : newCustProds) {
      CustomerProduct cp;
      String key = sapNewCustProd.getPk().getDistributor().getId() + "-" + sapNewCustProd.getPk().getProduct().getId();
      if (cpMap.containsKey(key)) {
        cp = cpMap.get(key);
        CustomerTransaction ct = createCustomerTransaction(sapNewCustProd, cp);
        cp.getCustomerTransactions().add(ct);
      } else {
        cp = createCustomerProduct(sapNewCustProd);
        CustomerTransaction ct = createCustomerTransaction(sapNewCustProd, cp);
        cp.getCustomerTransactions().add(ct);
        cpMap.put(key, cp);
      }
    }
    return cpMap;
  }

  private CustomerProduct createCustomerProduct(SapNewCustProd sapCustProduct) {
    CustomerProduct cp;
    cp = new CustomerProduct();
    cp.setDistributor(sapCustProduct.getPk().getDistributor());
    cp.setProduct(sapCustProduct.getPk().getProduct());
    cp.setModUser(BATCH_INSERT);
    cp.setModDate(Calendar.getInstance().getTime());
    return cp;
  }

  private CustomerTransaction createCustomerTransaction(SapNewCustProd sapCustProduct, CustomerProduct cp) {
    CustomerTransaction ct = new CustomerTransaction();
    ct.setCustomerProduct(cp);
    ct.setSalesAmount(sapCustProduct.getSalesAmount());
    ct.setSapSalesAmount(sapCustProduct.getSalesAmount());
    ct.setFinalInventory(0.0);
    ct.setBudget(0.0);
//    ct.setSalesUom(sapCustProduct.getPk().getSalesUom());
    ct.setYear(sapCustProduct.getPk().getYear());
    ct.setMonth(sapCustProduct.getPk().getMonth());
    ct.setModUser(BATCH_INSERT);
    ct.setModDate(Calendar.getInstance().getTime());
    return ct;
  }

}
