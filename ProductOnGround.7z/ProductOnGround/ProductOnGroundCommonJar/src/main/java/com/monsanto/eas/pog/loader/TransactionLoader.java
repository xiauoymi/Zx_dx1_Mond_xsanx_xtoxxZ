package com.monsanto.eas.pog.loader;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 26, 2011 Time: 9:13:38 AM To change this template use File |
 * Settings | File Templates.
 */
public interface TransactionLoader {
  void loadCustomerProductsWithTransactions();
}
