package com.monsanto.eas.pog.loader;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 25, 2011 Time: 2:39:10 PM To change this template use File |
 * Settings | File Templates.
 */
public class TransactionLoaderMain {
  /**
   * @param arguments - no arguments
   *
   * @exception Exception
   */
  public static void main(String... arguments) throws Exception {
    ApplicationContext context =
        new ClassPathXmlApplicationContext("applicationContext-standalone.xml");

    TransactionLoader transactionLoader = (TransactionLoader) context.getBean("sapTransactionLoader");
    transactionLoader.loadCustomerProductsWithTransactions();
  }
}
