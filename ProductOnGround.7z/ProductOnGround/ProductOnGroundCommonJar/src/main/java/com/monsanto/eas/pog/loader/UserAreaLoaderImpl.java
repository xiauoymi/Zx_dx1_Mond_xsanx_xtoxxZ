/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.loader;

import com.monsanto.eas.pog.dao.*;
import com.monsanto.eas.pog.model.UserAreaPk;
import com.monsanto.eas.pog.model.hibernate.Area;
import com.monsanto.eas.pog.model.hibernate.CountryType;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.hibernate.UserArea;
import com.monsanto.eas.pog.util.PogConstants;
import org.hibernate.NonUniqueObjectException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Component
@Transactional
public class UserAreaLoaderImpl implements UserAreaLoader {
    @Autowired
    private PogUserDao pogUserDao;
    @Autowired
    private AreaDao areaDao;
    @Autowired
    private CountryTypeDao countryTypeDao;

    public void addUserAreas() throws Exception {
        Map<String, Area> areaMapByCode = createAreaMapByCode();
        CountryType homeCountryType = countryTypeDao.lookupByType(PogConstants.HOME_COUNTRY_TYPE);
        addNewUserAreas(areaMapByCode, homeCountryType);
    }

    public void updateUserAreas() throws Exception {
        Map<String, Area> areaMapByCode = createAreaMapByCode();
        CountryType homeCountryType = countryTypeDao.lookupByType(PogConstants.HOME_COUNTRY_TYPE);
        updateUserAreas(areaMapByCode, homeCountryType);
    }

    private void updateUserAreas(Map<String, Area> areaMapByCode, CountryType homeCountryType) {
        Collection<PogUser> pogUsers = pogUserDao.lookupLevel1DistributorsWithUpdatedHomeCountry();
        for (PogUser user : pogUsers) {
            if (areaMapByCode.containsKey(user.getCountryCode())) {
                if (!user.getUserAreas().isEmpty()) {
                    user.getUserAreas().iterator().next().getPk().setActive(false);
                }
                UserArea userArea = new UserArea();
                userArea.setModUser("BATCH");
                userArea.setModDate(new Date());
                UserAreaPk pk = new UserAreaPk();
                pk.setArea(areaMapByCode.get(user.getCountryCode()));
                pk.setPogUser(user);
                pk.setCountryType(homeCountryType);
                pk.setActive(true);
                userArea.setPk(pk);
                user.getUserAreas().add(userArea);
                //existing user area actually doesnt get updated..look into this
                pogUserDao.saveOrUpdate(user);
            }
        }
    }

    private void addNewUserAreas(Map<String, Area> areaMapByCode, CountryType homeCountryType) {
        Collection<PogUser> newUsers = pogUserDao.lookupLevel1DistributorsWithNoHomeCountryInUserArea();
        for (PogUser user : newUsers) {
            if (areaMapByCode.containsKey(user.getCountryCode())) {
                UserArea userArea = new UserArea();
                userArea.setModUser("BATCH");
                userArea.setModDate(new Date());
                UserAreaPk pk = new UserAreaPk();
                pk.setArea(areaMapByCode.get(user.getCountryCode()));
                pk.setPogUser(user);
                pk.setActive(true);
                pk.setCountryType(homeCountryType);
                userArea.setPk(pk);
                user.getUserAreas().add(userArea);
                pogUserDao.saveOrUpdate(user);
            }
        }
    }

    private Map<String, Area> createAreaMapByCode() {
        Collection<Area> areas = areaDao.findAll();
        Map<String, Area> areaMapByCode = new HashMap<String, Area>();
        for (Area area : areas) {
            areaMapByCode.put(area.getAreaCode(), area);
        }
        return areaMapByCode;
    }
}