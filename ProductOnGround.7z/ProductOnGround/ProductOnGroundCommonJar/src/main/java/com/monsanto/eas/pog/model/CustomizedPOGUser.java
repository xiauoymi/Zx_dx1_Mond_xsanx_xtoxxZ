package com.monsanto.eas.pog.model;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigInteger;
import java.math.BigDecimal;


/**
 * Created by IntelliJ IDEA.
 * User: VVPRAS
 * Date: Oct 1, 2012
 * Time: 1:13:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class CustomizedPOGUser implements Serializable {

    private BigDecimal ID;
    private String USER_ID;
    private String FIRST_NAME;
    private String AREA_NAME;
    private char EMAIL_FLAG;
    private BigDecimal SALES_REP_ID;

    public char getEMAIL_FLAG() {
        return EMAIL_FLAG;
    }

    public void setEMAIL_FLAG(char EMAIL_FLAG) {
        this.EMAIL_FLAG = EMAIL_FLAG;
    }

    public BigDecimal getID() {
        return ID;
    }

    public BigDecimal getSALES_REP_ID() {
        return SALES_REP_ID;
    }

    public void setSALES_REP_ID(BigDecimal SALES_REP_ID) {
        this.SALES_REP_ID = SALES_REP_ID;
    }

    public void setID(BigDecimal ID) {
        this.ID = ID;
    }

    public String getUSER_ID() {
        return USER_ID;
    }

    public void setUSER_ID(String USER_ID) {
        this.USER_ID = USER_ID;
    }

    public String getFIRST_NAME() {
        return FIRST_NAME;
    }

    public void setFIRST_NAME(String FIRST_NAME) {
        this.FIRST_NAME = FIRST_NAME;
    }

    public String getAREA_NAME() {
        return AREA_NAME;
    }

    public void setAREA_NAME(String AREA_NAME) {
        this.AREA_NAME = AREA_NAME;
    }
}
