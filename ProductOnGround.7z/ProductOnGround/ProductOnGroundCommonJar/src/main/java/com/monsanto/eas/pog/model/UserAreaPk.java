package com.monsanto.eas.pog.model;

import com.monsanto.eas.pog.model.hibernate.Area;
import com.monsanto.eas.pog.model.hibernate.CountryType;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 21, 2010 Time: 2:19:12 PM To change this template use File |
 * Settings | File Templates.
 */
@Embeddable
public class UserAreaPk implements Serializable {
    @ManyToOne
    @JoinColumn(name = "AREA_ID", referencedColumnName = "ID")
    private Area area;

    @ManyToOne
    @JoinColumn(name = "CUSTOMER_STAGING_ID", referencedColumnName = "ID")
    private PogUser pogUser;

    @ManyToOne
    @JoinColumn(name = "COUNTRY_TYPE_ID", referencedColumnName = "ID")
    private CountryType countryType;

    @Column(name = "IS_ACTIVE", updatable = true, insertable = true)
    @Where(clause = "NVL(IS_ACTIVE, 'N')<>'Y'")
    @Type(type = "yes_no")
    private boolean active;

    public CountryType getCountryType() {
        return countryType;
    }

    public void setCountryType(CountryType countryType) {
        this.countryType = countryType;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public PogUser getPogUser() {
        return pogUser;
    }

    public void setPogUser(PogUser pogUser) {
        this.pogUser = pogUser;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserAreaPk that = (UserAreaPk) o;

        return !(area != null ? !area.equals(that.area) : that.area != null) &&
                !(pogUser != null ? !pogUser.equals(that.pogUser) : that.pogUser != null) &&
                !(active == that.active) &&
                !(countryType != null ? !countryType.equals(that.countryType) : that.countryType != null);

    }

    public int hashCode() {
        int result;
        result = (area != null ? area.hashCode() : 0);
        result = 31 * result + (pogUser != null ? pogUser.hashCode() : 0);
        result = 31 * result + (countryType != null ? countryType.hashCode() : 0);
        return result;
    }

}
