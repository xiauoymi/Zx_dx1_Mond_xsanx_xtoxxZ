package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.util.EntityEqualsUtil;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 14, 2010 Time: 2:56:23 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(schema = "POG", name = "AREA")
public class Area implements Serializable {
  @Id
  @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pogSeq")
  private Long id;

  @Column(name = "MOD_DATE")
  private Date modDate;

  @Column(name = "AREA_NAME")
  private String areaName;

  @Column(name = "AREA_CODE")
  private String areaCode;

  @Column(name = "SUPPORTS_OFFLINE")
  @Type(type = "yes_no")
  private boolean offline;

  @Column(name = "SUPPORTS_ONLINE")
  @Type(type = "yes_no")
  private boolean online;

  @Column(name = "SALES_IN_UNIT")
  @Type(type = "yes_no")
  private boolean salesInUnit;

  @Column(name = "MONTH_END_FROM")
  private int monthendFrom;

  @Column(name = "MONTH_END_TO")
  private int monthendTo;

  @Column(name = "OVERRIDEN_ACTIVE_YEAR")
  private int overridenActiveYear;

  @Column(name = "OVERRIDEN_ACTIVE_MONTH")
  private int overridenActiveMonth;

  @Column(name = "MOD_USER")
  private String modUser;

  @ManyToOne(cascade = CascadeType.ALL)
  @JoinColumn(name = "PARENT_ID", referencedColumnName = "ID")
  private Area parentArea;

  //  @OneToMany(mappedBy = "parentArea", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
  @Transient
  private Collection<Area> childAreas;

  @OneToMany(mappedBy = "area", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
  private Collection<AreaCaptureLevel> captureLevels;

//  @OneToMany(mappedBy = "pk.area", cascade = CascadeType.ALL)
//  private Collection<UserArea> userAreas;

//  @OneToMany(targetEntity = PogUser.class, fetch = FetchType.LAZY, cascade = CascadeType.ALL)
//  @JoinTable(schema = "POG", name = "USER_AREA", joinColumns = @JoinColumn(name = "AREA_ID"),
//      inverseJoinColumns = @JoinColumn(name = "POG_USER_ID"))
//  private Collection<PogUser> pogUsers;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getAreaName() {
    return areaName;
  }

  public void setAreaName(String areaName) {
    this.areaName = areaName;
  }

  public String getAreaCode() {
    return areaCode;
  }

  public void setAreaCode(String areaCode) {
    this.areaCode = areaCode;
  }

  public int getOverridenActiveYear() {
    return overridenActiveYear;
  }

  public void setOverridenActiveYear(int overridenActiveYear) {
    this.overridenActiveYear = overridenActiveYear;
  }

  //  public int getOverridenActiveYear() {
//    return overridenActiveYear == 0 ? getTodaysMonth() : overridenActiveYear;
//  }
//
//  private int getTodaysMonth() {
//    Calendar calendar = Calendar.getInstance();
//    return calendar.get(Calendar.MONTH) + 1;
//  }
//
//  public void setOverridenActiveYear(int overridenActiveYear) {
//    this.overridenActiveYear = overridenActiveYear;
//  }
//
//  public int getOverridenActiveMonth() {
//    return overridenActiveMonth == 0 ? getCurrentYear() : overridenActiveMonth;
//  }

  public int getMonthendFrom() {
    return monthendFrom;
  }

  public void setMonthendFrom(int monthendFrom) {
    this.monthendFrom = monthendFrom;
  }

  public int getMonthendTo() {
    return monthendTo;
  }

  public void setMonthendTo(int monthendTo) {
    this.monthendTo = monthendTo;
  }

  private int getCurrentYear() {
    Calendar calendar = Calendar.getInstance();
    return calendar.get(Calendar.YEAR);
  }

  public void setOverridenActiveMonth(int overridenActiveMonth) {
    this.overridenActiveMonth = overridenActiveMonth;
  }

  public int getOverridenActiveMonth() {
    return overridenActiveMonth;
  }

  public boolean isOffline() {
    return offline;
  }

  public void setOffline(boolean offline) {
    this.offline = offline;
  }

  public boolean isOnline() {
    return online;
  }

  public void setOnline(boolean online) {
    this.online = online;
  }

  public boolean isSalesInUnit() {
    return salesInUnit;
  }

  public void setSalesInUnit(boolean salesInUnit) {
    this.salesInUnit = salesInUnit;
  }
  //  public Collection<UserArea> getUserAreas() {
//    return userAreas;
//  }
//
//  public void setUserAreas(Collection<UserArea> userAreas) {
//    this.userAreas = userAreas;
//  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }


  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public Area getParentArea() {
    return parentArea;
  }

  public void setParentArea(Area parentArea) {
    this.parentArea = parentArea;
  }

  public Collection<Area> getChildAreas() {
    return childAreas;
  }

  public void setChildAreas(Collection<Area> childAreas) {
    this.childAreas = childAreas;
  }

  public Collection<AreaCaptureLevel> getCaptureLevels() {
    return captureLevels;
  }

  public void setCaptureLevels(Collection<AreaCaptureLevel> captureLevels) {
    this.captureLevels = captureLevels;
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }
}
