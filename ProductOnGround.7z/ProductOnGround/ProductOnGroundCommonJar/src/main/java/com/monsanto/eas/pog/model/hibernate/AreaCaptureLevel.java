package com.monsanto.eas.pog.model.hibernate;


import com.monsanto.eas.pog.util.EntityEqualsUtil;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 14, 2010 Time: 2:56:26 PM To change this template use File |
 * Settings | File Templates.
 */
@Table(name = "AREA_CAPTURE_LEVEL", schema = "POG")
@Entity
public class AreaCaptureLevel implements Serializable {
  @Id
  @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pogSeq")
  private Long id;

  @ManyToOne
  @JoinColumn(name = "AREA_ID", referencedColumnName = "ID", nullable = false)
  private Area area;

  @Column(name = "CAPTURE_LEVEL")
  private int captureLevel;

  @ManyToOne
  @JoinColumn(name = "CAPTURE_TYPE_ID ", referencedColumnName = "ID", nullable = false)
  private CaptureType captureType;

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "MOD_DATE")
  private Date modDate;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public int getCaptureLevel() {
    return captureLevel;
  }

  public void setCaptureLevel(int captureLevel) {
    this.captureLevel = captureLevel;
  }

  public Area getArea() {
    return area;
  }

  public void setArea(Area area) {
    this.area = area;
  }

  public CaptureType getCaptureType() {
    return captureType;
  }

  public void setCaptureType(CaptureType captureType) {
    this.captureType = captureType;
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }
}
