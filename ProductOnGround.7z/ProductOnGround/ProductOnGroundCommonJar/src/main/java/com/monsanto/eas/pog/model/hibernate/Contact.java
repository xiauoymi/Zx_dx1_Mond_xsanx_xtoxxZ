/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.util.EntityEqualsUtil;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(schema = "POG", name = "CONTACT")
public class Contact implements Serializable {

  @Id
  @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
  @GeneratedValue(generator = "pogSeq", strategy = GenerationType.SEQUENCE)
  private Long id;

  @Column(name = "NAME")
  private String name;

  @Column(name = "PHONE")
  private String phone;

  @Column(name = "EMAIL")
  private String email;

  @Column(name = "FAX")
  private String fax;

  @ManyToOne
  @JoinColumn(name = "CUSTOMER_ID", referencedColumnName = "ID", nullable = false)
  private PogUser pogUser;

  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
  private boolean deleted;

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "MOD_DATE")
  private Date modDate;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getPhone() {
    return phone;
  }

  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getEmail() {
    return email;
  }

  public String getFax() {
    return fax;
  }

  public void setFax(String fax) {
    this.fax = fax;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public PogUser getPogUser() {
    return pogUser;
  }

  public void setPogUser(PogUser pogUser) {
    this.pogUser = pogUser;
  }

  public boolean isDeleted() {
    return deleted;
  }

  public void setDeleted(boolean deleted) {
    this.deleted = deleted;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }
}