package com.monsanto.eas.pog.model.hibernate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: 3/1/11 Time: 10:56 AM To change this template use File | Settings |
 * File Templates.
 */
@Entity
@Table(schema = "POG", name = "CONVERSION_FACTOR_VW")
@AssociationOverrides({
    @AssociationOverride(name = "pk.product", joinColumns = @JoinColumn(name = "PRODUCT_STAGING_ID")),
    @AssociationOverride(name = "pk.baseUnitOfMeasure", joinColumns = @JoinColumn(name = "TO_BASE_UOM_ID"))
})
public class ConversionFactor implements Serializable {
  @EmbeddedId
  private ConversionFactorPK pk;

  @Column(name = "NUMERATOR", nullable = false)
  private Long numerator;

  @Column(name = "DENOMINATOR", nullable = false)
  private Long denominator;

  @Column(name = "TO_BASE_UOM_CODE")
  private String toBaseUomCode;//Placeholder column - coz cant insert this column into the view

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "MOD_DATE")
  private Date modDate;

  public ConversionFactorPK getPk() {
    return pk;
  }

  public void setPk(ConversionFactorPK pk) {
    this.pk = pk;
  }

  public Long getNumerator() {
    return numerator;
  }

  public void setNumerator(Long numerator) {
    this.numerator = numerator;
  }

  public Long getDenominator() {
    return denominator;
  }

  public void setDenominator(Long denominator) {
    this.denominator = denominator;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public String getToBaseUomCode() {
    return toBaseUomCode;
  }

  public void setToBaseUomCode(String toBaseUomCode) {
    this.toBaseUomCode = toBaseUomCode;
  }

  @Override
  public int hashCode() {
    int result;
    result = (pk != null ? pk.hashCode() : 0);
    return result;
  }

  @Override
  public boolean equals(Object instance) {
    if (instance == null) {
      return false;
    }

    if (!(instance instanceof ConversionFactor)) {
      return false;
    }

    ConversionFactor other = (ConversionFactor) instance;

    return pk.equals(other.getPk());
  }
}
