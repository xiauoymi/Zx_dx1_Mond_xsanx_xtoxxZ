/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.model.hibernate;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Embeddable
public class ConversionFactorPK implements Serializable {

  @ManyToOne
  private Product product;

  @ManyToOne
  private BaseUnitOfMeasure baseUnitOfMeasure;

  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public BaseUnitOfMeasure getBaseUnitOfMeasure() {
    return baseUnitOfMeasure;
  }

  public void setBaseUnitOfMeasure(BaseUnitOfMeasure baseUnitOfMeasure) {
    this.baseUnitOfMeasure = baseUnitOfMeasure;
  }

  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }

    ConversionFactorPK conversionFactorPK = (ConversionFactorPK) o;

    if (product != null ? !product.equals(conversionFactorPK.product) :
        conversionFactorPK.product != null) {
      return false;
    }
    if (baseUnitOfMeasure != null ? !baseUnitOfMeasure.equals(conversionFactorPK.baseUnitOfMeasure) :
        conversionFactorPK.baseUnitOfMeasure != null) {
      return false;
    }

    return true;
  }

  public int hashCode() {
    int result;
    result = (product != null ? product.hashCode() : 0);
    result = 31 * result + (baseUnitOfMeasure != null ? baseUnitOfMeasure.hashCode() : 0);
    return result;
  }

}