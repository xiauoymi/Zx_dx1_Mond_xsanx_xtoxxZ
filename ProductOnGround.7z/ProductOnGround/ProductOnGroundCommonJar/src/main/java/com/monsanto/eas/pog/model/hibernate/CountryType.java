package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.util.EntityEqualsUtil;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 21, 2010 Time: 1:54:59 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(schema = "POG", name = "COUNTRY_TYPE")
public class CountryType implements Serializable {
  @Id
  @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pogSeq")
  private Long id;

  @Column(name = "TYPE")
  private String type;

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "MOD_DATE")
  private Date modDate;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }
}
