package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.util.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(name = "MV_CUSTOMER_MATERIAL", schema = "POG")
public class CustomerMaterial implements Serializable {
  @Id
  @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pogSeq")
  private Long id;

  @ManyToOne
  @JoinColumn(name = "CUSTOMER_STAGING_ID", referencedColumnName = "ID", nullable = false)
  private PogUser pogUser;

  @ManyToOne
  @JoinColumn(name = "PRODUCT_STAGING_ID", referencedColumnName = "ID", nullable = false)
  private Product product;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public PogUser getPogUser() {
    return pogUser;
  }

  public void setPogUser(PogUser pogUser) {
    this.pogUser = pogUser;
  }

  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }
}
