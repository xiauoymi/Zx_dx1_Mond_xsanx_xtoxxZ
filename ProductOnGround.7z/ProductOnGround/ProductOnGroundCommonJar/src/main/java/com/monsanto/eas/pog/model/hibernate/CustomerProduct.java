package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.util.EntityEqualsUtil;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jul 1, 2010 Time: 12:30:14 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(name = "CUSTOMER_PRODUCT", schema = "POG")
public class CustomerProduct implements Serializable, Comparable {
  @Id
  @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pogSeq")
  private Long id;

  @ManyToOne(optional = false)
  @JoinColumn(name = "DISTRIBUTOR_ID", referencedColumnName = "ID", nullable = false)
  private PogUser distributor;

  @ManyToOne(optional = false)
  @JoinColumn(name = "PRODUCT_PK", referencedColumnName = "ID", nullable = false)
  private Product product;

  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
//  @Transient
  private boolean deleted;

  @OneToMany(mappedBy = "customerProduct", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  private Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "MOD_DATE")
  private Date modDate = new Date();

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public boolean isDeleted() {
    return deleted;
  }

  public void setDeleted(boolean deleted) {
    this.deleted = deleted;
  }

  public PogUser getDistributor() {
    return distributor;
  }

  public void setDistributor(PogUser distributor) {
    this.distributor = distributor;
  }

  public Product getProduct() {
    return product;
  }

  public void setProduct(Product product) {
    this.product = product;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public Collection<CustomerTransaction> getCustomerTransactions() {
    return customerTransactions;
  }

  public void setCustomerTransactions(Collection<CustomerTransaction> customerTransactions) {
    this.customerTransactions = customerTransactions;
  }

  public int compareTo(Object o) {
    CustomerProduct that = (CustomerProduct) o;
    if (this.product == null || that.getProduct() == null) {
      return 0;
    } else {
      return this.product.getProductCode().getCode().compareTo(that.getProduct().getProductCode().getCode());
    }
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }
}
