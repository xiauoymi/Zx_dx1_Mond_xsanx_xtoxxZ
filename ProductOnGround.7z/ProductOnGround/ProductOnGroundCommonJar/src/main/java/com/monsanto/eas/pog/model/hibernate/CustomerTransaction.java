package com.monsanto.eas.pog.model.hibernate;


import com.monsanto.eas.pog.util.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 14, 2010 Time: 2:56:26 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(name = "CUSTOMER_TRANSACTION_VIEW", schema = "POG")
public class CustomerTransaction implements Serializable {
  @Id
  @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pogSeq")
  private Long id;

  @ManyToOne(optional = false)
  @JoinColumn(name = "CUSTOMER_PRODUCT_ID", referencedColumnName = "ID", nullable = false)
  private CustomerProduct customerProduct;

  @Column(name = "YEAR")
  private Long year;

  @Column(name = "MONTH")
  private Long month;                                                             

  @Column(name = "FINAL_INVENTORY")
  private Double finalInventory;

  @Column(name = "INITIAL_INVENTORY", updatable = false, insertable = false)
  private Double initialInventory;

  @Column(name = "SALES_AMOUNT")
  private Double salesAmount;

//  @ManyToOne
//  @JoinColumn(name = "SALES_UOM_ID", referencedColumnName = "ID")
//  private BaseUnitOfMeasure salesUom;

  @Column(name = "SAP_SALES_AMOUNT")
  private Double sapSalesAmount;

  @Column(name = "BUDGET")
  private Double budget;

  @Column(name = "SAP_MOD_DATE")
  private Date sapModDate;

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "MOD_DATE")
  private Date modDate = new Date();

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public CustomerProduct getCustomerProduct() {
    return customerProduct;
  }

  public void setCustomerProduct(CustomerProduct customerProduct) {
    this.customerProduct = customerProduct;
  }

  public Long getYear() {
    return year;
  }

  public void setYear(Long year) {
    this.year = year;
  }

  public Long getMonth() {
    return month;
  }

  public void setMonth(Long month) {
    this.month = month;
  }

  public Double getFinalInventory() {
    return finalInventory;
  }

  public void setFinalInventory(Double finalInventory) {
    this.finalInventory = finalInventory;
  }

  public Double getInitialInventory() {
    return initialInventory;
  }

  public void setInitialInventory(Double initialInventory) {
    this.initialInventory = initialInventory;
  }

  public Double getSalesAmount() {
    return salesAmount;
  }

  public void setSalesAmount(Double salesAmount) {
    this.salesAmount = salesAmount;
  }

  public Double getSapSalesAmount() {
    return sapSalesAmount;
  }

  public void setSapSalesAmount(Double sapSalesAmount) {
    this.sapSalesAmount = sapSalesAmount;
  }

  public Date getSapModDate() {
    return sapModDate;
  }

  public void setSapModDate(Date sapModDate) {
    this.sapModDate = sapModDate;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public Double getBudget() {
    return budget;
  }

  public void setBudget(Double budget) {
    this.budget = budget;
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }
}
