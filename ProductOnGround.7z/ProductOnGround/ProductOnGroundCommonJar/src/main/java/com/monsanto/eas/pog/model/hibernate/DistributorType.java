package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.util.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA.
 * User: sspati1
 * Date: 2/28/11
 * Time: 1:23 PM
 * To change this template use File | Settings | File Templates.
 */
@Entity
@Table(schema = "POG", name = "DISTRIBUTOR_TYPE")
public class DistributorType implements Serializable {
    @Id
    @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
    @GeneratedValue(generator = "pogSeq", strategy = GenerationType.SEQUENCE)
    private Long id;

    @Column(name = "TYPE")
    private String type;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public boolean equals(Object o) {
        return EntityEqualsUtil.identifierEquals(this, o);
    }

    @Override
    public int hashCode() {
        return EntityEqualsUtil.identifierHashCode(this);
    }
}
