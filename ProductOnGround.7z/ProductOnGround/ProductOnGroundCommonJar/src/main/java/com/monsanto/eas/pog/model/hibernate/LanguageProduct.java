/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.model.hibernate;


import javax.persistence.*;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(schema = "POG", name = "LAN_PRODUCT_VW")
@AssociationOverrides({
    @AssociationOverride(name = "pk.language", joinColumns = @JoinColumn(name = "LANGUAGE_ID")),
    @AssociationOverride(name = "pk.productCode", joinColumns = @JoinColumn(name = "PRODUCT_ID"))
})

public class LanguageProduct implements Serializable {
  private static final long serialVersionUID = 8464844582412114699L;

  @EmbeddedId
  private LanguageProductPK pk;

  //Placeholder column - coz cant insert this column into the view
  @Column(name = "LANGUAGE_CODE", nullable = false)
  private String languageCode;

  //Placeholder column - coz cant insert this column into the view
  @Column(name = "SAP_PRODUCT_CODE", nullable = false)
  private String productCode;

  @Column(name = "DESCRIPTION", nullable = false)
  private String description;

  @Column(name = "CUSTOM_PRODUCT_DESC")
  private String customDescription;

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public LanguageProductPK getPk() {
    return pk;
  }

  public void setPk(LanguageProductPK pk) {
    this.pk = pk;
  }

  public String getCustomDescription() {
    return customDescription;
  }

  public void setCustomDescription(String customDescription) {
    this.customDescription = customDescription;
  }

  public String getLanguageCode() {
    return languageCode;
  }

  public void setLanguageCode(String languageCode) {
    this.languageCode = languageCode;
  }

  public String getProductCode() {
    return productCode;
  }

  public void setProductCode(String productCode) {
    this.productCode = productCode;
  }

  @Override
  public int hashCode() {
    int result;
    result = (pk != null ? pk.hashCode() : 0);
    return result;
  }

  @Override
  public boolean equals(Object instance) {
    if (instance == null) {
      return false;
    }

    if (!(instance instanceof LanguageProduct)) {
      return false;
    }

    LanguageProduct other = (LanguageProduct) instance;
    if (!(pk.equals(other.getPk()))) {
      return false;
    }

    return true;
  }
}