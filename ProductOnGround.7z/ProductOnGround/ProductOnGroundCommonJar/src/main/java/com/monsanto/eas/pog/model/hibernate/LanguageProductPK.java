/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.model.hibernate;

import javax.persistence.Embeddable;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Embeddable
public class LanguageProductPK implements Serializable {
  @ManyToOne
  private ProductCode productCode;

  @ManyToOne
  private Language language;

  public ProductCode getProductCode() {
    return productCode;
  }

  public void setProductCode(ProductCode productCode) {
    this.productCode = productCode;
  }

  public Language getLanguage() {
    return language;
  }

  public void setLanguage(Language language) {
    this.language = language;
  }

  public boolean equals(Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }

    LanguageProductPK languageProductPK = (LanguageProductPK) o;

    if (language != null ? !language.equals(languageProductPK.getLanguage()) :
        languageProductPK.getLanguage() != null) {
      return false;
    }
    if (productCode != null ? !productCode.equals(languageProductPK.getProductCode()) :
        languageProductPK.getProductCode() != null) {
      return false;
    }

    return true;
  }

  public int hashCode() {
    int result;
    result = (language != null ? language.hashCode() : 0);
    result = 31 * result + (productCode != null ? productCode.hashCode() : 0);
    return result;
  }

}