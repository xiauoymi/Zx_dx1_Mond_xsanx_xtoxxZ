package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.util.EntityEqualsUtil;
import com.monsanto.eas.pog.util.PogConstants;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.Where;

import javax.persistence.*;
import java.io.Serializable;
import java.util.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 14, 2010 Time: 2:56:25 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(schema = "POG", name = "CUSTOMER_STAGING_VIEW")
public class PogUser implements Serializable, Comparable {
  @Id
  @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pogSeq")
  private Long id;

  @Column(name = "USER_ID")
  private String userId;

  @Column(name = "FIRST_NAME")
  private String firstName;

  @Column(name = "LAST_NAME")
  private String lastName;

  @Column(name = "MIDDLE_NAME")
  private String middleName;

  @Column(name = "IS_INTERNAL")
  @Type(type = "yes_no")
  private boolean internal;

  //  @Column(name = "DISTRIBUTOR_LEVEL", updatable = false, insertable = false)
  @Transient
  private int level;

  @Column(name = "DEPTH_OF_CHILD_LEVELS", updatable = false, insertable = false)
//  @Transient
  private int depth;

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "MOD_DATE")
  private Date modDate;

  @OneToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "LOCALE", referencedColumnName = "ID")
  private Locale locale;

  @Column(name = "IS_DELETED")
  @Type(type = "yes_no")
//  @Transient
  private boolean deleted;

  @ManyToOne(targetEntity = PogUser.class, cascade = CascadeType.ALL,fetch = FetchType.LAZY)
  @JoinColumn(name = "PARENT_ID")
  private PogUser parentUser;

  @OneToMany(mappedBy = "parentUser", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
  @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
  private Collection<PogUser> childUsers;

  @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
  @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
  private Collection<CustomerProduct> customerProducts;

  @OneToMany(mappedBy = "pk.pogUser", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
  private Collection<UserArea> userAreas = new ArrayList<UserArea>();

  @OneToMany(targetEntity = Role.class, fetch = FetchType.LAZY)
  @JoinTable(schema = "POG", name = "POG_USER_ROLE", joinColumns = @JoinColumn(name = "POG_USER_ID"),
      inverseJoinColumns = @JoinColumn(name = "ROLE_ID"))
  private Collection<Role> roles;

  @Column(name = "SAP_ID")
  private String sapId;

  @Column(name = "COUNTRY_CODE")
  private String countryCode;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "SALES_REP_ID", referencedColumnName = "ID")
  private PogUser salesRep;

  @OneToOne
  @JoinColumn(name = "DISTRIBUTOR_TYPE_ID", referencedColumnName = "ID")
  private DistributorType distributorType;

  @Column(name = "ADDRESS1")
  private String address1;

  @Column(name = "ADDRESS2")
  private String address2;

  @Column(name = "ADDRESS3")
  private String address3;

  @Column(name = "ADDRESS4")
  private String address4;

  @Column(name = "CITY")
  private String city;

  @Column(name = "PROVINCE")
  private String province;

  @Column(name = "POSTAL_CODE")
  private String postalCode;

  @Column(name = "OVERRIDE")
  @Type(type = "yes_no")
  private boolean override;

  @OneToMany(targetEntity = Contact.class, cascade = CascadeType.ALL,
      mappedBy = "pogUser")
  @Where(clause = "NVL(IS_DELETED, 'N')<>'Y'")
  private Collection<Contact> contacts;

  @Transient
  private Map<String, String> errors = new HashMap<String, String>();

  public Long getId() {
    return this.id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }

  public boolean isDeleted() {
    return deleted;
  }

  public void setDeleted(boolean deleted) {
    this.deleted = deleted;
  }

  public Locale getLocale() {
    return locale;
  }

  public void setLocale(Locale locale) {
    this.locale = locale;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public String getMiddleName() {
    return middleName;
  }

  public void setMiddleName(String middleName) {
    this.middleName = middleName;
  }

  public String getFullName() {
    String fullName = firstName;
    if (middleName != null) {
      fullName += " " + middleName;
    }
    fullName += " " + lastName;
    return fullName;
  }

  public boolean isInternal() {
    return internal;
  }

  public void setInternal(boolean internal) {
    this.internal = internal;
  }

  public int getLevel() {
    if (internal) {
      level = 0;
    } else {
      PogUser parent = parentUser;
      int i = 1;
      while (parent != null) {
        parent = parent.getParentUser();
        i++;
      }
      level = i;
    }
    return level;
  }

  public void setLevel(int level) {
    this.level = level;
  }

  public int getDepth() {
    return depth;
  }

  public void setDepth(int depth) {
    this.depth = depth;
  }

  public String getCountryCode() {
    return countryCode;
  }

  public void setCountryCode(String countryCode) {
    this.countryCode = countryCode;
  }

  public String getModUser() {

    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public Collection<UserArea> getUserAreas() {
    return userAreas;
  }

  public void setUserAreas(Collection<UserArea> userAreas) {
    this.userAreas = userAreas;
  }

  public Collection<PogUser> getChildUsers() {
    return childUsers;
  }

  public void setChildUsers(Collection<PogUser> childUsers) {
    this.childUsers = childUsers;
  }

  public PogUser getParentUser() {
    return parentUser;
  }

  public void setParentUser(PogUser parentUser) {
    this.parentUser = parentUser;
  }

  public Collection<Role> getRoles() {
    return roles == null ? new ArrayList<Role>() : roles;
  }

  public void setRoles(Collection<Role> roles) {
    this.roles = roles;
  }

  public Map<String, String> getErrors() {
    if (errors == null) {
      errors = new HashMap<String, String>();
    }
    return errors;
  }

  public void setErrors(Map<String, String> errors) {
    this.errors = errors;
  }

  public String getSapId() {
    return sapId;
  }

  public void setSapId(String sapId) {
    this.sapId = sapId;
  }

  public PogUser getSalesRep() {
    return salesRep;
  }

  public void setSalesRep(PogUser salesRep) {
    this.salesRep = salesRep;
  }

  public DistributorType getDistributorType() {
    return distributorType;
  }

  public void setDistributorType(DistributorType distributorType) {
    this.distributorType = distributorType;
  }

  public String getAddress1() {
    return address1;
  }

  public void setAddress1(String address1) {
    this.address1 = address1;
  }

  public String getAddress2() {
    return address2;
  }

  public void setAddress2(String address2) {
    this.address2 = address2;
  }

  public String getAddress3() {
    return address3;
  }

  public void setAddress3(String address3) {
    this.address3 = address3;
  }

  public String getAddress4() {
    return address4;
  }

  public void setAddress4(String address4) {
    this.address4 = address4;
  }

  public String getCity() {
    return city;
  }

  public void setCity(String city) {
    this.city = city;
  }

  public String getProvince() {
    return province;
  }

  public void setProvince(String province) {
    this.province = province;
  }

  public String getPostalCode() {
    return postalCode;
  }

  public void setPostalCode(String postalCode) {
    this.postalCode = postalCode;
  }

  public boolean isOverride() {
    return override;
  }

  public void setOverride(boolean override) {
    this.override = override;
  }

  public Collection<Contact> getContacts() {
    return contacts;
  }

  public void setContacts(Collection<Contact> contacts) {
    this.contacts = contacts;
  }

  public int compareTo(Object o) {
    return firstName.compareTo(((PogUser) o).getFirstName());
  }

  public Collection<CustomerProduct> getCustomerProducts() {
    return customerProducts;
  }

  public void setCustomerProducts(Collection<CustomerProduct> customerProducts) {
    this.customerProducts = customerProducts;
  }

  public boolean isInSalesRepRole() {
    return isInRole(PogConstants.SALES_REP);
  }

  public boolean isAdmin() {
    return isInRole(PogConstants.ADMIN);
  }

  private boolean isInRole(String roleName) {
    for (Role role : this.roles) {
      if (roleName.equalsIgnoreCase(role.getRoleName())) {
        return true;
      }
    }
    return false;
  }

  public int getCaptureLevelByType(String captureType) {
    for (UserArea userArea : userAreas) {
      if (PogConstants.HOME_COUNTRY_TYPE.equalsIgnoreCase(userArea.getPk().getCountryType().getType())) {
        for (AreaCaptureLevel acl : userArea.getArea().getCaptureLevels()) {
          if (captureType.equalsIgnoreCase(acl.getCaptureType().getType())) {
            return acl.getCaptureLevel();
          }
        }
      }
    }
    return 0;
  }

  public Collection<UserArea> getAssociatedAreas() {
    Collection<UserArea> associatedAreas = new ArrayList<UserArea>();
    for (UserArea userArea : userAreas) {
      if (PogConstants.ASSOCIATION_COUNTRY_TYPE.equalsIgnoreCase(userArea.getPk().getCountryType().getType())) {
        associatedAreas.add(userArea);
      }
    }
    return associatedAreas;
  }

  public UserArea getHomeCountry() {
    for (UserArea userArea : userAreas) {
      if (PogConstants.HOME_COUNTRY_TYPE.equalsIgnoreCase(userArea.getPk().getCountryType().getType())) {
        return userArea;
      }
    }
    return null;
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }

}
