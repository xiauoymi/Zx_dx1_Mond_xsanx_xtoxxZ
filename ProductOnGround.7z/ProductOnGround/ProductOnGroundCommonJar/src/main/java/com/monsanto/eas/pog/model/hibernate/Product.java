package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.util.EntityEqualsUtil;

import javax.persistence.*;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;
import java.util.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 25, 2011 Time: 12:57:37 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(schema = "POG", name = "PRODUCT_STAGING_VW")
public class Product implements Serializable {
  private static final long serialVersionUID = 8464844582412114689L;

  @Id
  @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pogSeq")
  private Long id;

  @Column(name = "MATERIAL_ID")
  private String materialId;

  @Column(name = "MATERIAL_DESC")
  private String materialDesc;

  @ManyToOne(targetEntity = Product.class, cascade = CascadeType.ALL)
  @JoinColumn(name = "PARENT_ID", updatable = false, insertable = false)
  private Product parentProduct;

  @OneToOne(optional = false)
  @JoinColumn(name = "BASE_UOM_ID", referencedColumnName = "ID", nullable = false, updatable = false, insertable = false)
  private BaseUnitOfMeasure baseUnitOfMeasure;

//  @OneToMany(mappedBy = "pk.product", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
  @Transient
  private Collection<ConversionFactor> conversionFactors = new ArrayList<ConversionFactor>();

  @ManyToOne(optional = false)
  @JoinColumn(name = "PRODUCT_ID", updatable = false, insertable = false)
  private ProductCode productCode;

  @Column
  private Double unit;

  @Column(name = "PRODUCT_LEVEL", updatable = false, insertable = false)
  private Integer level;

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "MOD_DATE")
  private Date modDate;

  //Placeholder column - coz cant insert this column into the view
  @Column(name = "SAP_PARENT_PRODUCT_CODE")
  private String parentCode;

  //Placeholder column - coz cant insert this column into the view
  @Column(name = "BASE_UOM_CODE")
  private String baseUomCode;

  //Placeholder column - coz cant insert this column into the view
  @Column(name = "SAP_PRODUCT_CODE", nullable = false)
  private String code;

  public Product() {
  }

  public ProductCode getProductCode() {
    return productCode;
  }

  public void setProductCode(ProductCode productCode) {
    this.productCode = productCode;
  }


  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public String getMaterialId() {
    return materialId;
  }

  public void setMaterialId(String materialId) {
    this.materialId = materialId;
  }

  public String getMaterialDesc() {
    return materialDesc;
  }

  public void setMaterialDesc(String materialDesc) {
    this.materialDesc = materialDesc;
  }

  public Product getParentProduct() {
    return parentProduct;
  }

  public void setParentProduct(Product parentProduct) {
    this.parentProduct = parentProduct;
  }

  public BaseUnitOfMeasure getBaseUnitOfMeasure() {
    return baseUnitOfMeasure;
  }

  public void setBaseUnitOfMeasure(BaseUnitOfMeasure baseUnitOfMeasure) {
    this.baseUnitOfMeasure = baseUnitOfMeasure;
  }

  public Double getUnit() {
    return unit;
  }

  public void setUnit(Double unit) {
    this.unit = unit;
  }

  public Integer getLevel() {
    return level;
  }

  public void setLevel(Integer level) {
    this.level = level;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }

  public void setParentCode(String parentCode) {
    this.parentCode = parentCode;
  }

  public void setBaseUomCode(String baseUomCode) {
    this.baseUomCode = baseUomCode;
  }

  public String getParentCode() {
    return parentCode;
  }

  public String getBaseUomCode() {
    return baseUomCode;
  }

  public Collection<ConversionFactor> getConversionFactors() {
    return conversionFactors;
  }

  public void setConversionFactors(Collection<ConversionFactor> conversionFactors) {
    this.conversionFactors = conversionFactors;
  }

  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }


}
