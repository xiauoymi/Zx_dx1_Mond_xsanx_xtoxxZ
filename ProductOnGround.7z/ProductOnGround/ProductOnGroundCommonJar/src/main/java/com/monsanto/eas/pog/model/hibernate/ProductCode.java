/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.util.EntityEqualsUtil;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Entity
@Table(schema = "POG", name = "PRODUCT")
public class ProductCode implements Serializable {
  @Id
  @SequenceGenerator(name = "pogSeq", sequenceName = "POG.POG_SEQ")
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pogSeq")
  private Long id;

  @Column(name = "CODE", nullable = false)
  private String code;

  @Column(name = "MOD_USER")
  private String modUser;

  @Column(name = "MOD_DATE")
  private Date modDate;

//  @OneToMany(cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
//  @JoinColumn(name = "PRODUCT_ID", insertable = false, updatable = false)
//  @MapKey(name = "pk.language")
//  private Map<Language, LanguageProduct> languageProductsMap = new HashMap<Language, LanguageProduct>();
//
//  @Transient
//  private Map<String, LanguageProduct> descriptionsByLanguage;
//
//  public Map<Language, LanguageProduct> getLanguageProductsMap() {
//    return languageProductsMap;
//  }
//
//  public void setLanguageProductsMap(Map<Language, LanguageProduct> languageProductsMap) {
//    this.languageProductsMap = languageProductsMap;
//  }
//
//  public Map<String, LanguageProduct> getDescriptionsByLanguage() {
//    Map<String, LanguageProduct> map = new HashMap<String, LanguageProduct>();
//    for (Language language : languageProductsMap.keySet()) {
//      map.put(language.getCode(), languageProductsMap.get(language));
//    }
//    return map;
//  }
//
//  public void setDescriptionsByLanguage(Map<String, LanguageProduct> descriptionsByLanguage) {
//    this.descriptionsByLanguage = descriptionsByLanguage;
//  }


  @OneToMany(cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
  @JoinColumn(name = "PRODUCT_ID", insertable = false, updatable = false)
  private Collection<LanguageProduct> languageProducts;

  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  public String getCode() {
    return code;
  }

  public void setCode(String code) {
    this.code = code;
  }

  public Collection<LanguageProduct> getLanguageProducts() {
    return languageProducts;
  }

  public void setLanguageProducts(Collection<LanguageProduct> languageProducts) {
    this.languageProducts = languageProducts;
  }

  public String getModUser() {
    return modUser;
  }

  public void setModUser(String modUser) {
    this.modUser = modUser;
  }

  public Date getModDate() {
    return modDate;
  }

  public void setModDate(Date modDate) {
    this.modDate = modDate;
  }


  @Override
  public boolean equals(Object o) {
    return EntityEqualsUtil.identifierEquals(this, o);
  }

  @Override
  public int hashCode() {
    return EntityEqualsUtil.identifierHashCode(this);
  }

  //  @OneToMany(cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
//  @JoinColumn(name = "PRODUCT_ID", insertable = false, updatable = false)
//  private Collection<LanguageProduct> lanprodList = new ArrayList<LanguageProduct>();
//
//  public Collection<LanguageProduct> getLanprodList() {
//    return lanprodList;
//  }
//
//  public void setLanprodList(Collection<LanguageProduct> lanprodList) {
//    this.lanprodList = lanprodList;
//  }
//
//  @OneToMany(cascade = {CascadeType.ALL}, fetch = FetchType.LAZY)
//  @JoinColumn(name = "PRODUCT_ID", insertable = false, updatable = false)
//  @MapKey(name = "pk.language")
//  private Map<String, LanguageProduct> map = new HashMap<String, LanguageProduct>();
//
//
//  public Map<String, LanguageProduct> getLanprodsMap() {
//    return map;
//  }
//
//  public void setLanprodsMap(Map<String, LanguageProduct> lanprodsMap) {
//    this.map = lanprodsMap;
//  }

}