package com.monsanto.eas.pog.model.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "POG", name = "PRODUCT_FAMILY_COUNTRY_VW")
public class ProductFamilyCountry {

    @Column(name = "COUNTRY_CODE")
    private String countryCode;

    @Column(name = "COUNTRY_NAME")
    private String countryName;

    @Column(name = "CAPTURE_LEVEL")
    private Integer captureLevel;

    @Id
    @Column(name = "PRODUCT_FAMILY_CODE")
    private String productFamilyCode;

    @Column(name = "PRODUCT_FAMILY_DESCRIPTION")
    private String productFamilyDescription;

    @Column(name = "LANGUAGE")
    private String language;

    @Column(name = "COUNT")
    private Integer count;

    public Integer getCaptureLevel() {
        return captureLevel;
    }

    public void setCaptureLevel(Integer captureLevel) {
        this.captureLevel = captureLevel;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getProductFamilyCode() {
        return productFamilyCode;
    }

    public void setProductFamilyCode(String productFamilyCode) {
        this.productFamilyCode = productFamilyCode;
    }

    public String getProductFamilyDescription() {
        return productFamilyDescription;
    }

    public void setProductFamilyDescription(String productFamilyDescription) {
        this.productFamilyDescription = productFamilyDescription;
    }

}
