package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.model.UserAreaPk;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 21, 2010 Time: 1:48:04 PM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(name = "USER_AREA", schema = "POG")
public class UserArea implements Serializable {
    @EmbeddedId
    private UserAreaPk pk;

    @Column(name = "MOD_USER")
    private String modUser;

    @Column(name = "MOD_DATE")
    private Date modDate;

    @Column(name = "EMAIL_FLAG")
    private String emailFlag;
    public UserAreaPk getPk() {
        return pk;
    }

    public void setPk(UserAreaPk pk) {
        this.pk = pk;
    }

    public Area getArea() {
        return getPk().getArea();
    }

    public PogUser getPogUser() {
        return getPk().getPogUser();
    }

    public CountryType getCountryType() {
        return getPk().getCountryType();
    }

    public boolean isActive() {
        return getPk().isActive();
    }

    public String getModUser() {
        return modUser;
    }

    public void setModUser(String modUser) {
        this.modUser = modUser;
    }

    public Date getModDate() {
        return modDate;
    }

    public void setModDate(Date modDate) {
        this.modDate = modDate;
    }

    public void setEmailFlag(String emailFlag) {
           this.emailFlag = emailFlag;
       }
    public String getEmailFlag() {
        return emailFlag;
    }
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        UserArea that = (UserArea) o;

        if (getArea() != null ? !getArea().equals(that.getArea()) : that.getArea() != null) {
            return false;
        }
        if (getPogUser() != null ? !getPogUser().equals(that.getPogUser()) : that.getPogUser() != null) {
            return false;
        }
        if (isActive() != that.isActive()) {
            return false;
        }
        if (getCountryType() != null ? !getCountryType().equals(that.getCountryType()) : that.getCountryType() != null) {
            return false;
        }

        return true;
    }

    public int hashCode() {
        int result;
        result = (getArea() != null ? getArea().hashCode() : 0);
        result = 31 * result + (getPogUser() != null ? getPogUser().hashCode() : 0);
        result = 31 * result + (getCountryType() != null ? getCountryType().hashCode() : 0);
        return result;
    }

}
