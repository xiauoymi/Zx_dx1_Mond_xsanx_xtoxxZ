package com.monsanto.eas.pog.model.hibernate.temp;

import com.monsanto.eas.pog.model.hibernate.CustomerTransaction;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 26, 2011 Time: 12:32:31 PM To change this template use File |
 * Settings | File Templates.
 */
public interface SapExistingCustProd {
  SapExistingCustProdPk getPk();

  CustomerTransaction getCustomerTransaction();

  Integer getUnit();

  Double getSalesAmount();

}
