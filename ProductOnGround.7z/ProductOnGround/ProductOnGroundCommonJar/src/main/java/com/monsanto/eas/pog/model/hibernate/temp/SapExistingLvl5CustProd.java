package com.monsanto.eas.pog.model.hibernate.temp;

import com.monsanto.eas.pog.model.hibernate.BaseUnitOfMeasure;
import com.monsanto.eas.pog.model.hibernate.CustomerTransaction;

import javax.persistence.*;
import java.io.Serializable;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 26, 2011 Time: 11:29:15 AM To change this template use File |
 * Settings | File Templates.
 */
@Entity
@Table(schema = "POG", name = "SAP_EXISTING_LVL5_CUST_PROD_VW")
public class SapExistingLvl5CustProd implements SapExistingCustProd, Serializable {
  @EmbeddedId
  private SapExistingCustProdPk pk;

  @OneToOne
  @JoinColumn(name = "CUSTOMER_TRANSACTION_ID")
  private CustomerTransaction customerTransaction;

  @Column(name = "UNIT")
  private Integer unit;

  @Column(name = "SALES_AMOUNT")
  private Double salesAmount;


  public SapExistingCustProdPk getPk() {
    return pk;
  }

  public void setPk(SapExistingCustProdPk pk) {
    this.pk = pk;
  }

  public CustomerTransaction getCustomerTransaction() {
    return customerTransaction;
  }

  public void setCustomerTransaction(CustomerTransaction customerTransaction) {
    this.customerTransaction = customerTransaction;
  }

  public Integer getUnit() {
    return unit;
  }

  public void setUnit(Integer unit) {
    this.unit = unit;
  }

  public Double getSalesAmount() {
    return salesAmount;
  }

  public void setSalesAmount(Double salesAmount) {
    this.salesAmount = salesAmount;
  }

  @Override
  public int hashCode() {
    int result;
    result = (pk != null ? pk.hashCode() : 0);
    return result;
  }

  @Override
  public boolean equals(Object instance) {
    if (instance == null)
      return false;

    if (!(instance instanceof SapExistingLvl5CustProd))
      return false;

    SapExistingLvl5CustProd other = (SapExistingLvl5CustProd) instance;

    return pk.equals(other.getPk());
  }
}
