package com.monsanto.eas.pog.model.hibernate.temp;

import com.monsanto.eas.pog.model.hibernate.BaseUnitOfMeasure;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 26, 2011 Time: 11:44:07 AM To change this template use File |
 * Settings | File Templates.
 */
public interface SapNewCustProd {

  SapNewCustProdPk getPk();

  Integer getUnit();

  Double getSalesAmount();

}
