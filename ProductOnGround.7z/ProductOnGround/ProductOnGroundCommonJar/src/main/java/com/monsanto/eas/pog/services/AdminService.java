/*
 AdminService was created on Jul 9, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.Area;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public interface AdminService {
  @RemotingInclude
  PogUser saveOrUpdateUser(PogUser user, Collection<PogUser> selectedDistributors) throws Exception;

  @RemotingInclude
  Collection<PogUser> lookupSalesRepsByAdminId(Long pogUserId) throws Exception;

  @RemotingInclude
  Collection<PogUser> lookupSalesRepsWithAssociatedArea(Area area) throws
      Exception;
}