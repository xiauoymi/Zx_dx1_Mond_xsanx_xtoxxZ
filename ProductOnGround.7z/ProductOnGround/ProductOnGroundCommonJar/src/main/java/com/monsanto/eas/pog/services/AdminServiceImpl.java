/*
 AdminServiceImpl was created on Jul 9, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.*;
import com.monsanto.eas.pog.dao.exception.UserNotFoundException;
import com.monsanto.eas.pog.model.UserAreaPk;
import com.monsanto.eas.pog.model.hibernate.*;
import com.monsanto.eas.pog.util.PogConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
@Service
@RemotingDestination(value = "adminService")
public class AdminServiceImpl implements AdminService {
  @Autowired
  private PogUserDao userDao;
  @Autowired
  private CountryTypeDao countryTypeDao;
  @Autowired
  private AreaDao areaDao;
  @Autowired
  private UserAreaDao userAreaDao;
  @Autowired
  private RoleDao roleDao;
  @Autowired
  private LocaleService localeService;
  private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger
      (AdminServiceImpl.class.getName());

  public AdminServiceImpl() {
  }

  public AdminServiceImpl(PogUserDao userDao, CountryTypeDao countryTypeDao, AreaDao areaDao, RoleDao roleDao,
                          UserAreaDao userAreaDao, LocaleService localeService) {
    this.userDao = userDao;
    this.countryTypeDao = countryTypeDao;
    this.areaDao = areaDao;
    this.roleDao = roleDao;
    this.userAreaDao = userAreaDao;
    this.localeService = localeService;
  }

  @RemotingInclude
  public Collection<PogUser> lookupSalesRepsWithAssociatedArea(Area area) throws
      Exception {
    logger.info("Looking up sales rep who are associated with area : " + area.getAreaName());
    return userDao.lookupSalesRepsByAreaAndCountryType(area, PogConstants.ASSOCIATION_COUNTRY_TYPE);
  }

  @RemotingInclude
  public PogUser saveOrUpdateUser(PogUser user, Collection<PogUser> selectedDistributors) throws Exception {
    //if user is a new user, and user id already exists in the system....throw an error message.
    boolean userAlreadyExists = doesUserAlreadyExists(user);
    if (userAlreadyExists) {
      return user;
    } else {
      Collection<UserArea> userAreasFromApplication = user.getUserAreas();

      CountryType associationCountryType = countryTypeDao.lookupByType(PogConstants.ASSOCIATION_COUNTRY_TYPE);
      CountryType homeCountryType = countryTypeDao.lookupByType(PogConstants.HOME_COUNTRY_TYPE);

      for (UserArea ua : userAreasFromApplication) {
        if (PogConstants.HOME_COUNTRY_TYPE.equalsIgnoreCase(ua.getPk().getCountryType().getType())) {
          setUserAreaAsHomeCountryAssociation(homeCountryType, ua);
        } else {
          addUserAreaToAssociatedCountryTypes(associationCountryType, ua);
        }
      }

      deleteExistingUserAreas(user);

      //If the user is an admin, then associate this user with all the associated areas selected in the application.
      //if there are no sales rep for any of these associated areas, then make the admin the sales rep.
      if (user.isAdmin() && user.isInSalesRepRole()) {
        user.setUserAreas(userAreasFromApplication);
        user.setModDate(new Date());
        PogUser pogUser = user.getId() == null ? userDao.saveOrUpdate(user) : userDao.merge(user);
        return saveSalesRepWithSelectedDistributors(pogUser, selectedDistributors, associationCountryType);
      } else {
        if (user.isInSalesRepRole()) {
          return saveSalesRepWithSelectedDistributors(user, selectedDistributors, associationCountryType);
        } else {
          //is only admin
          user.setUserAreas(userAreasFromApplication);
          checkIfThereAreAnySalesRepForTheAreasSelectedIfNoneMakeAdminTheSalesRep(user);
          user.setModDate(new Date());
          return user.getId() == null ? userDao.saveOrUpdate(user) : userDao.merge(user);
        }
      }
    }
  }

  private void addUserAreaToAssociatedCountryTypes(CountryType associationCountryType,
                                                   UserArea ua) {
    ua.getPk().setCountryType(associationCountryType);
  }

  private UserArea setUserAreaAsHomeCountryAssociation(CountryType homeCountryType, UserArea ua) {
    ua.getPk().setCountryType(homeCountryType);
    return ua;
  }

  private boolean doesUserAlreadyExists(PogUser user) {
    if (user.getId() != null) {
      return false;
    } else {
      try {
        PogUser pogUser = userDao.findByUserId(user.getUserId());
        if (pogUser != null) {
          logger.error("The user " + user.getUserId() + " already exists in the system.\n");
          user.getErrors().put("userAlreadyExists", "This user id already exists in the system.");
          return true;
        }
      } catch (UserNotFoundException ex) {
        //do nothing.
      }
      return false;
    }
  }

  private void deleteExistingUserAreas(PogUser user) throws UserNotFoundException {
    if (user.getId() != null) {
      PogUser existingUser = userDao.findByUserId(user.getUserId());
      userAreaDao.deleteUserAreasForUser(existingUser);
    }
  }

  private void checkIfThereAreAnySalesRepForTheAreasSelectedIfNoneMakeAdminTheSalesRep(PogUser user) throws Exception {
    //if associatated user areas for this user, does not have even one single sales rep assigned, then associate this user area to the admin,
    //and give him the sales rep role.
    Collection<Role> salesRepRoles = roleDao.lookupByExample(PogConstants.SALES_REP);
    Role salesRepRole = salesRepRoles.iterator().next();
    for (UserArea adminUserArea : user.getUserAreas()) {
      if (PogConstants.HOME_COUNTRY_TYPE.equalsIgnoreCase(adminUserArea.getPk().getCountryType().getType())) {
        continue;
      }
      Area adminArea = adminUserArea.getPk().getArea();
      Collection<PogUser> salesReps = userDao
          .lookupSalesRepsByAreaAndCountryType(adminArea, PogConstants.HOME_COUNTRY_TYPE);
      if (salesReps != null && salesReps.isEmpty() && !user.isInSalesRepRole()) {
        user.getRoles().add(salesRepRole);
      }
    }
  }

  private PogUser saveSalesRepWithSelectedDistributors(PogUser salesRep, Collection<PogUser> selectedDistributors,
                                                       CountryType associationCountryType) throws Exception {
    disassociateTheSalesRepForEachOfTheDistributors(salesRep);
    associateTheDistributorAreaWithTheSalesRep(salesRep, selectedDistributors, associationCountryType);
    salesRep.setModDate(new Date());
    PogUser user1 = salesRep.getId() == null ? userDao.saveOrUpdate(salesRep) : userDao.merge(salesRep);

    Locale defaultLocale = localeService.lookupByLocale(PogConstants.DEFAULT_LOCALE);
    for (PogUser distributor : selectedDistributors) {
      //for each distributor set the association with the sales rep.
      //see if this distributor already exists - if yes just update the sales rep else insert a new one
      PogUser existingDistributor = userDao.findBySapId(distributor.getSapId());
      if (existingDistributor == null) {
        distributor.setDeleted(false);
        distributor.setModDate(new Date());
        distributor.setSalesRep(salesRep);
        distributor.setLocale(defaultLocale);
        distributor.setUserId(distributor.getSapId().toString());
        userDao.saveOrUpdate(distributor);
      } else {
        existingDistributor.setDeleted(false);
        existingDistributor.setModDate(new Date());
        existingDistributor.setSalesRep(salesRep);
        userDao.merge(existingDistributor);
      }
    }

    return user1;
  }

  private void associateTheDistributorAreaWithTheSalesRep(PogUser salesRep, Collection<PogUser> selectedDistributors,
                                                          CountryType associationCountryType) throws Exception {
    Collection<UserArea> distributorAreas;
    for (PogUser distributor : selectedDistributors) {
      if (distributor != null && !distributor.getUserAreas().isEmpty()) {
        distributorAreas = distributor.getUserAreas();
        //lookup the area from the database. Distributors only have one user area of type HOME
        UserArea distributorArea = distributorAreas.iterator().next();
        Area distArea = distributorArea.getArea();
//        Area distArea = areaDao.lookupByCriteria(distributorArea.getArea());

        if (!isSalesRepAlreadyAssociatedWithThisArea(salesRep, distArea)) {
          salesRep.getUserAreas().add(createNewUserAreaAssociationForSalesRep(salesRep, associationCountryType,
              distArea));
        }
      }
    }
  }

  private UserArea createNewUserAreaAssociationForSalesRep(PogUser salesRep, CountryType associationCountryType,
                                                           Area distArea) {
    UserArea salesToDistributorAreaRel = new UserArea();
    UserAreaPk userAreaPK = new UserAreaPk();
    userAreaPK.setPogUser(salesRep);
    userAreaPK.setArea(distArea);
    userAreaPK.setCountryType(associationCountryType);
    salesToDistributorAreaRel.setPk(userAreaPK);
    return salesToDistributorAreaRel;
  }

  private boolean isSalesRepAlreadyAssociatedWithThisArea(PogUser user, Area area) {
    for (UserArea ua : user.getUserAreas()) {
      if (ua.getPk().getArea().equals(area)) {
        return true;
      }
    }
    return false;
  }

  private void disassociateTheSalesRepForEachOfTheDistributors(PogUser salesRep) {
    //each time we come to the save Or update user screen, existing user should be disassociated
    // from their children. New relations should be saved.
    Collection<PogUser> distributors = userDao.lookupAllLevel1DistributorsBySalesRepUserId(salesRep.getUserId());
    for (PogUser distributor : distributors) {
      logger.info("Setting sales rep id to null for each of the distributors\n");
      distributor.setSalesRep(null);
      distributor.setModDate(new Date());
      userDao.merge(distributor);
    }
  }

  @RemotingInclude
  public Collection<PogUser> lookupSalesRepsByAdminId(Long pogUserId) throws Exception {
    PogUser admin = userDao.findByPrimaryKey(pogUserId);
    Collection<Area> areas = new ArrayList<Area>();
    for (UserArea userArea : admin.getUserAreas()) {
      if (PogConstants.ASSOCIATION_COUNTRY_TYPE.equalsIgnoreCase(userArea.getPk().getCountryType().getType())) {
        //lookup sales rep for this country
        areas.add(userArea.getArea());
      }
    }
    return userDao.lookupSalesRepsByAreaAndCountryType(areas, PogConstants.HOME_COUNTRY_TYPE);
  }

}