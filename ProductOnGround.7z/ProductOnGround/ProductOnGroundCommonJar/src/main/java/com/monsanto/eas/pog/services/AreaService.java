/*
 AreaService was created on Jun 24, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.Area;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public interface AreaService {
  public Collection<Area> lookupAll();

  Area saveOrUpdate(Area area);
}