/*
 AreaServiceImpl was created on Jun 24, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.AreaDao;
import com.monsanto.eas.pog.model.hibernate.Area;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@Service
@RemotingDestination(value = "areaService")
public class AreaServiceImpl implements AreaService {
  @Autowired
  private AreaDao areaDao;

  public AreaServiceImpl(AreaDao areaDao) {
    this.areaDao = areaDao;
  }

  public AreaServiceImpl() {
  }

  @RemotingInclude
  public Collection<Area> lookupAll() {
    return areaDao.findAll("areaName", true);
  }

  @RemotingInclude
  public Area saveOrUpdate(Area area) {
    return areaDao.saveOrUpdate(area);
  }

}