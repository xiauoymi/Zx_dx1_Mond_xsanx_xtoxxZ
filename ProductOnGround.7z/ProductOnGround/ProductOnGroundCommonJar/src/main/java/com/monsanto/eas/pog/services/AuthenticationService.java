package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.PogUser;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 19, 2010 Time: 4:57:49 PM To change this template use File |
 * Settings | File Templates.
 */
public interface AuthenticationService {
  public boolean isPrinicipalAuthenticated();

  public PogUser authenticatePrincipal(String username, String password);

  public void logoutPrincipal();
}
