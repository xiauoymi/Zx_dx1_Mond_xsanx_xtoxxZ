package com.monsanto.eas.pog.services;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 12, 2010 Time: 3:55:48 PM To change this template use File |
 * Settings | File Templates.
 */

import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.hibernate.Role;
import flex.messaging.FlexContext;
import org.springframework.context.ApplicationContext;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.security.Authentication;
import org.springframework.security.AuthenticationManager;
import org.springframework.security.GrantedAuthority;
import org.springframework.security.context.SecurityContextHolder;
import org.springframework.security.providers.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.web.context.support.WebApplicationContextUtils;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Collection;

@Service
@RemotingDestination(value = "authenticationService")
public class AuthenticationServiceImpl implements AuthenticationService {

  /**
   * Checks if the current user is authenticated by evaluating the FlexContext
   *
   * @return Boolean true if the current user is authenticated and false otherwise
   */
  @RemotingInclude
  public boolean isPrinicipalAuthenticated() {
    Principal userPrincipal = getFlexPrincipal();
    return userPrincipal != null;
  }

  //protected only for testing

  protected Principal getFlexPrincipal() {
    return FlexContext.getUserPrincipal();
  }

  /**
   * Takes the username and password as provided and checks the validity of the credentials. Spring
   * com.monsanto.eas.pog.security is used to check the credentials and to return the authenticated principal with it's
   * authorized roles. An exception is thrown if the authentication fails.
   *
   * @param username String containing the username of the principal to login
   * @param password String containing the password used to identify the current user
   *
   * @return AuthorizationData object containing the name of the principal and the authorized roles.
   */
  @RemotingInclude
  public PogUser authenticatePrincipal(String username, String password) {
    Authentication authentication = getAuthentication(username, password);
    SecurityContextHolder.getContext().setAuthentication(authentication);

    return obtainGrantedAuthorities();
  }

  //protected for testing only

  protected Authentication getAuthentication(String username, String password) {
    ApplicationContext appContext =
        WebApplicationContextUtils.getWebApplicationContext(FlexContext.getServletConfig().getServletContext());
    AuthenticationManager manager = (AuthenticationManager) appContext.getBean("_authenticationManager");
    UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken =
        new UsernamePasswordAuthenticationToken(username, password);

    return manager.authenticate(usernamePasswordAuthenticationToken);
  }

  /**
   * Logout the current principle
   */
  @RemotingInclude
  public void logoutPrincipal() {

    String username = "unknown";
    try {
      username = getAuthentication().getName();
      FlexContext.setUserPrincipal(null);
      FlexContext.getHttpRequest().getSession().invalidate();
      FlexContext.getFlexSession().invalidate();
      SecurityContextHolder.clearContext();
    } catch (RuntimeException e) {
    }
  }

  private PogUser obtainGrantedAuthorities() {
    GrantedAuthority[] authorities = getAuthentication().getAuthorities();
    int numAuthorities = authorities.length;
    Collection<Role> roles = new ArrayList<Role>();
    for (int counter = 0; counter < numAuthorities; counter++) {
      Role role = new Role();
      role.setRoleName(authorities[counter].getAuthority());
      roles.add(role);
    }
    String name = getAuthentication().getName();
    PogUser pogUser = new PogUser();
    pogUser.setFirstName(name);
    pogUser.setRoles(roles);
    return pogUser;
  }

  private Authentication getAuthentication() {
    return SecurityContextHolder.getContext().getAuthentication();
  }

}

