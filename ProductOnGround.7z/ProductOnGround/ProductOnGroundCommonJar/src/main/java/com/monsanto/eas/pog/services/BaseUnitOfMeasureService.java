package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.BaseUnitOfMeasure;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 6, 2010 Time: 3:03:01 PM To change this template use File |
 * Settings | File Templates.
 */
public interface BaseUnitOfMeasureService {
  @RemotingInclude
  Collection<BaseUnitOfMeasure> lookupAll();
}
