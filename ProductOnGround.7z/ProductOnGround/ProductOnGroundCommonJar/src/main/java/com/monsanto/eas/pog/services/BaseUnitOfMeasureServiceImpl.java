package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.BaseUnitOfMeasureDao;
import com.monsanto.eas.pog.model.hibernate.BaseUnitOfMeasure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 6, 2010 Time: 3:03:18 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@RemotingDestination(value = "baseUomService")
public class BaseUnitOfMeasureServiceImpl implements BaseUnitOfMeasureService {
  @Autowired
  private BaseUnitOfMeasureDao baseUnitOfMeasureDao;

  public BaseUnitOfMeasureServiceImpl() {
  }

  public BaseUnitOfMeasureServiceImpl(BaseUnitOfMeasureDao baseUnitOfMeasureDao) {
    this.baseUnitOfMeasureDao = baseUnitOfMeasureDao;
  }

  @RemotingInclude
  public Collection<BaseUnitOfMeasure> lookupAll() {
    return baseUnitOfMeasureDao.findAll();
  }
}
