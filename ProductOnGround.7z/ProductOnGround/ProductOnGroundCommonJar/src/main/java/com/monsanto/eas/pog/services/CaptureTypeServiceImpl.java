package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.CaptureTypeDao;
import com.monsanto.eas.pog.model.hibernate.CaptureType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 25, 2010 Time: 12:10:14 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@RemotingDestination(value = "captureTypeService")
public class CaptureTypeServiceImpl implements CaptureTypeService{
  @Autowired
  private CaptureTypeDao captureTypeDao;

  public CaptureTypeServiceImpl() {
  }

  public CaptureTypeServiceImpl(CaptureTypeDao captureTypeDao) {
    this.captureTypeDao = captureTypeDao;
  }
  
  @RemotingInclude
  public Collection<CaptureType> lookupAll(){
    return captureTypeDao.findAll();
  }
}
