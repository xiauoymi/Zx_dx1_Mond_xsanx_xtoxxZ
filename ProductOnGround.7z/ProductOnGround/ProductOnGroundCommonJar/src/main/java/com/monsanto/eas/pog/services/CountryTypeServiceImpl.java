package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.CountryTypeDao;
import com.monsanto.eas.pog.model.hibernate.CountryType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 25, 2010 Time: 12:16:42 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@RemotingDestination(value = "countryTypeService")
public class CountryTypeServiceImpl implements CountryTypeService{
  @Autowired
  private CountryTypeDao countryTypeDao;

  public CountryTypeServiceImpl() {
  }

  public CountryTypeServiceImpl(CountryTypeDao countryTypeDao) {
    this.countryTypeDao = countryTypeDao;
  }

  @RemotingInclude
  public Collection<CountryType> lookupAll() {
    return countryTypeDao.findAll();
  }

  @RemotingInclude
  public CountryType lookupByType(String type) throws Exception {
    return countryTypeDao.lookupByType(type);
  }
}
