package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.CustomerMaterial;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public interface CustomerMaterialService {

  Collection<CustomerMaterial> lookupByCustomerPk(Long customerPk);
}
