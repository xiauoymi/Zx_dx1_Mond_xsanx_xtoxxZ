package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.CustomerMaterialDao;
import com.monsanto.eas.pog.model.hibernate.CustomerMaterial;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Service
@RemotingDestination(value = "customerMaterialService")
public class CustomerMaterialServiceImpl implements CustomerMaterialService {
  private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger
      (CustomerMaterialServiceImpl.class.getName());

  @Autowired
  private CustomerMaterialDao customerMaterialDao;

  public CustomerMaterialServiceImpl() {
  }

  public CustomerMaterialServiceImpl(CustomerMaterialDao customerMaterialDao) {
    this.customerMaterialDao = customerMaterialDao;
  }

  @RemotingInclude
  public Collection<CustomerMaterial> lookupByCustomerPk(Long customerPk) {
    logger.info("Getting Customer Material lookupByCustomerPk: " + customerPk);
    Collection<CustomerMaterial> customerMaterials = customerMaterialDao.lookupByCustomerPk(customerPk);
    logger.info("Got Customer Material lookupByCustomerPk: " + customerPk);
    Collection<CustomerMaterial> temp = new ArrayList<CustomerMaterial>();
    for (CustomerMaterial cm : customerMaterials) {
      CustomerMaterial tem = new CustomerMaterial();
      tem.setId(cm.getId());
      tem.setProduct(cm.getProduct());
      temp.add(tem);
    }
    return temp;
  }
}
