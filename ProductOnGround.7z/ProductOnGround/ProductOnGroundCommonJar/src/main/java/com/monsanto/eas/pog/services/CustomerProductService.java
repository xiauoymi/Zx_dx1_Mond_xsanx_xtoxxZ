package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.CustomerProduct;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jul 10, 2010 Time: 1:15:59 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
public interface CustomerProductService {
  Collection<CustomerProduct> filterByYearAndMonthRange(PogUser distributor, Long year, Long month, Long endYear,
                                                        Long endMonth);

  CustomerProduct lookupInactiveByDistributorProductCodeAndBaseUomCode(PogUser distributor, String productName,
                                                                       String baseUomCode, String materialId);

  void filterByYearAndMonth(PogUser distributor, Long year, Long month);
}