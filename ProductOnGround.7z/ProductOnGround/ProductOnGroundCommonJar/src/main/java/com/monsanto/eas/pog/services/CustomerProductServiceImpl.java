package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.CustomerProductDao;
import com.monsanto.eas.pog.dao.CustomerTransactionDao;
import com.monsanto.eas.pog.model.hibernate.CustomerProduct;
import com.monsanto.eas.pog.model.hibernate.CustomerTransaction;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jul 10, 2010 Time: 1:16:20 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
public class CustomerProductServiceImpl implements CustomerProductService {
  @Autowired
  private CustomerTransactionDao customerTransactionDao;
  @Autowired
  private CustomerProductDao customerProductDao;

  public CustomerProductServiceImpl() {
  }

  public CustomerProductServiceImpl(CustomerProductDao customerProductDao,
                                    CustomerTransactionDao customerTransactionDao) {
    this.customerProductDao = customerProductDao;
    this.customerTransactionDao = customerTransactionDao;
  }

  public void filterByYearAndMonth(PogUser distributor, Long year, Long month) {
    Collection<CustomerTransaction> transactions = customerTransactionDao
        .lookupByParentDistributorIdYearAndMonthRange(distributor.getId(), month == 1 ? year - 1 : year,
            month == 1 ? 12 : month - 1, year, month);
    Map<String, CustomerTransaction> customerProductIdTransactionMap = new HashMap<String, CustomerTransaction>();
    for (CustomerTransaction transaction : transactions) {
      String key = transaction.getCustomerProduct().getId() + "-" + transaction.getYear()
          + "-" + transaction.getMonth();
      if (customerProductIdTransactionMap.containsKey(key)) {
        CustomerTransaction customerTransaction = customerProductIdTransactionMap.get(key);
        transaction.setSalesAmount(customerTransaction.getSalesAmount() + transaction.getSalesAmount());
        transaction.setSapSalesAmount(customerTransaction.getSapSalesAmount() + transaction.getSapSalesAmount());
        transaction.setFinalInventory(customerTransaction.getFinalInventory() + transaction.getFinalInventory());
        transaction.setInitialInventory(customerTransaction.getInitialInventory() + transaction.getInitialInventory());
        transaction.setBudget(customerTransaction.getBudget() + transaction.getBudget());
      }
      customerProductIdTransactionMap.put(key, transaction);
    }

    setFilteredTransactionsInDistributor(distributor, year, month, customerProductIdTransactionMap);
    setFilteredTransactionsInChildren(distributor, year, month, customerProductIdTransactionMap);
  }

  private CustomerTransaction createNewTransaction(Long year, Long month,
                                                   Map<String, CustomerTransaction> customerProductIdTransactionMap,
                                                   CustomerProduct customerProduct) {
    CustomerTransaction customerTransaction = new CustomerTransaction();
    customerTransaction.setCustomerProduct(customerProduct);
    customerTransaction.setYear(year);
    customerTransaction.setMonth(month);

    CustomerTransaction previousMonthsCustomerTransaction = customerProductIdTransactionMap
        .get(customerProduct.getId() + "-" + (month == 1 ? year - 1 : year) + "-" + (month == 1 ? 12 : month - 1));


    if (previousMonthsCustomerTransaction == null) {
      customerTransaction.setInitialInventory(0.0);
    } else {
      customerTransaction.setInitialInventory(previousMonthsCustomerTransaction.getFinalInventory());
    }
    customerTransaction.setFinalInventory(0.0);
    customerTransaction.setBudget(0.0);
    customerTransaction.setSalesAmount(0D);
    customerTransaction.setSapSalesAmount(0D);
    customerTransaction.setModDate(new Date());
    return customerTransaction;
  }

  public Collection<CustomerProduct> filterByYearAndMonthRange(PogUser distributor, Long year, Long month,
                                                               Long endYear, Long endMonth) {
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();

    Collection<CustomerTransaction> transactions = customerTransactionDao
        .lookupByDistributorIdYearAndMonthRange(distributor.getId(), year, month, endYear, endMonth);
    Map<Long, Collection<CustomerTransaction>> transactionMap = new HashMap<Long, Collection<CustomerTransaction>>();
    for (CustomerTransaction transaction : transactions) {
      Collection<CustomerTransaction> filteredTransactions = new ArrayList<CustomerTransaction>();
      if (transactionMap.containsKey(transaction.getCustomerProduct().getId())) {
        filteredTransactions.addAll(transactionMap.get(transaction.getCustomerProduct().getId()));
      }
      filteredTransactions.add(transaction);
      transactionMap.put(transaction.getCustomerProduct().getId(), filteredTransactions);
    }

    for (CustomerProduct customerProduct : distributor.getCustomerProducts()) {
      if (transactionMap.containsKey(customerProduct.getId())) {
        customerProduct.setCustomerTransactions(transactionMap.get(customerProduct.getId()));
      } else {
        customerProduct.setCustomerTransactions(new ArrayList<CustomerTransaction>());
      }
      customerProducts.add(customerProduct);
    }
    return customerProducts;

  }

  private void setFilteredTransactionsInChildren(PogUser distributor, Long year, Long month,
                                                 Map<String, CustomerTransaction> customerProductIdTransactionMap) {
    for (PogUser child : distributor.getChildUsers()) {
      setFilteredTransactionsInDistributor(child, year, month, customerProductIdTransactionMap);
      setFilteredTransactionsInChildren(child, year, month, customerProductIdTransactionMap);
    }
  }

  private void setFilteredTransactionsInDistributor(PogUser distributor, Long year, Long month,
                                                    Map<String, CustomerTransaction> customerProductIdTransactionMap) {
    for (CustomerProduct customerProduct : distributor.getCustomerProducts()) {
      Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();
      if (customerProductIdTransactionMap.containsKey(customerProduct.getId() + "-" + year + "-" + month)) {
        customerTransactions.add(customerProductIdTransactionMap.get(customerProduct.getId() + "-" + year
            + "-" + month));
      } else {
        customerTransactions
            .add(createNewTransaction(year, month, customerProductIdTransactionMap, customerProduct));
      }
      customerProduct.setCustomerTransactions(customerTransactions);
    }
  }

  public CustomerProduct lookupInactiveByDistributorProductCodeAndBaseUomCode(PogUser distributor, String productName,
                                                                              String baseUomCode, String materialId) {
    return customerProductDao
        .lookupInactiveByDistributorProductCodeAndBaseUomCode(distributor.getId(), productName, baseUomCode,
            materialId);
  }
}