package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.Area;
import com.monsanto.eas.pog.model.hibernate.PogUser;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 24, 2010 Time: 12:02:32 PM To change this template use File |
 * Settings | File Templates.
 */
public interface DistributorService extends UserService {
  Collection<PogUser> lookupAllLevel1DistributorsBySalesRepUserIdForSync(String salesRepUserId, String localeStr) throws Exception;

  PogUser lookupDistributorWithSalesData(PogUser pogUser, Long year, Long month, String localeStr) throws Exception;

  Collection<PogUser> lookupAvailableLevel1DistributorsByCountryCode(Collection<Area> areaIds) throws Exception;

  Collection<PogUser> lookupAllLevel1DistBySalesRepUserId(String salesRepUserId) throws Exception;

  PogUser lookupDistributorWithBudgetData(PogUser pogUser, Long year, Long month, String localeStr) throws Exception;

  PogUser lookupDetailsByIdForEdit(Long id) throws Exception;
}
