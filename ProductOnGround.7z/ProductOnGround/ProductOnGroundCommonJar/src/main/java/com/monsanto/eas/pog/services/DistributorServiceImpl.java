package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.CustomerProductDao;
import com.monsanto.eas.pog.dao.PogUserDao;
import com.monsanto.eas.pog.model.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 24, 2010 Time: 12:02:39 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@Transactional
@RemotingDestination(value = "distributorService")
public class DistributorServiceImpl extends UserServiceImpl implements DistributorService {
    private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger
            (DistributorServiceImpl.class.getName());
    @Autowired
    private PogUserDao pogUserDao;

    @Autowired
    private CustomerProductDao customerProductDao;

    @Autowired
    private CustomerProductService customerProductService;

    @Autowired
    private ProductService productService;

    public DistributorServiceImpl() {
    }

    public DistributorServiceImpl(PogUserDao pogUserDao,
                                  CustomerProductService customerProductService, ProductService productService) {
        super(pogUserDao);
        this.pogUserDao = pogUserDao;
        this.customerProductService = customerProductService;
        this.productService = productService;
    }

    public void setCustomerProductDao(CustomerProductDao customerProductDao) {
        this.customerProductDao = customerProductDao;
    }

    @Override
    public PogUser saveOrUpdate(PogUser user) throws Exception {
        if (user.getId() == null) {
            PogUser savedDistributor = super.saveOrUpdate(user);
            if (savedDistributor.getLevel() > 1) {
                savedDistributor.setUserId(savedDistributor.getId().toString());
                pogUserDao.merge(savedDistributor);
            }
            return savedDistributor;
        } else {
            return updatePogUser(user);
        }
    }

    private PogUser updatePogUser(PogUser user) {
        Collection<CustomerProduct> cps = new ArrayList<CustomerProduct>();
        for (CustomerProduct cp : user.getCustomerProducts()) {
            // if an inactive customer product already exists ..activate it..else create a new one
            CustomerProduct inactiveCP = customerProductService
                    .lookupInactiveByDistributorProductCodeAndBaseUomCode(user, cp.getProduct().getProductCode().getCode(),
                            cp.getProduct().getBaseUnitOfMeasure().getCode(), cp.getProduct().getMaterialId());
            if (inactiveCP == null) {
                if (cp.getId() == null) {
                    Product product = productService
                            .lookupByCodeBaseUomIdAndMaterialId(cp.getProduct().getProductCode().getCode(),
                                    cp.getProduct().getBaseUnitOfMeasure().getId(), cp.getProduct().getMaterialId());
                    cp.setProduct(product);
                }
                cps.add(cp);
            } else {
                inactiveCP.setDeleted(false);
                customerProductDao.saveOrUpdate(inactiveCP);
            }
        }
        user.setCustomerProducts(cps);
        return update(user);
    }

    private PogUser update(PogUser user) {
        pogUserDao.clear();
        pogUserDao.saveOrUpdate(user);
        pogUserDao.flush();
        pogUserDao.clear();
        return pogUserDao.findByPrimaryKey(user.getId());
    }

    @RemotingInclude
    public Collection<PogUser> lookupAllLevel1DistBySalesRepUserId(String salesRepUserId) throws
            Exception {
        logger.info("Getting lookupAllLevel1DistBySalesRepUserId for sales rep user id:." + salesRepUserId);
        Collection<PogUser> pogUsers = this.pogUserDao.lookupAllLevel1DistributorsBySalesRepUserId(salesRepUserId);
        for (PogUser user : pogUsers) {//clear properties not needed in UI to improve performance
            user.setChildUsers(new ArrayList<PogUser>());
            user.setCustomerProducts(new ArrayList<CustomerProduct>());
            user.setContacts(new ArrayList<Contact>());
        }

        logger.info("Got lookupAllLevel1DistBySalesRepUserId for sales rep user id:." + salesRepUserId);
        return pogUsers;
    }

    @RemotingInclude
    public PogUser lookupDetailsByIdForEdit(Long id) throws Exception {
        logger.info("Getting lookupDetailsByIdForEdit: " + id);
        PogUser pogUser = pogUserDao.findByPrimaryKey(id);
        clearDataOfAllParents(pogUser, true, false);
        clearCustomerProductsOfAllChildren(pogUser);
        return pogUser;
    }

    @RemotingInclude
    public Collection<PogUser> lookupAllLevel1DistributorsBySalesRepUserIdForSync(String salesRepUserId,
                                                                                  String localeStr) throws
            Exception {
        logger.info("Getting lookupAllLevel1DistributorsBySalesRepUserId: " + salesRepUserId);
        Collection<PogUser> level1Distributors = this.pogUserDao
                .lookupAllLevel1DistributorsBySalesRepUserId(salesRepUserId);
        logger.info("Got lookupAllLevel1DistributorsBySalesRepUserId: " + salesRepUserId);
        logger.info("done with syncing: ");
        return level1Distributors;
    }

    @RemotingInclude
    public PogUser lookupDistributorWithBudgetData(PogUser pogUser, Long year, Long month, String localeStr) throws
            Exception {
        logger.info("Getting lookupDistributorWithBudgetData: " + pogUser);
        pogUser = pogUserDao.findByPrimaryKey(pogUser.getId());
        pogUser.setChildUsers(new ArrayList<PogUser>());
        Long endYear = month > 1 ? year + 1 : year;
        Long endMonth = month > 1 ? month - 1 : month + 11;
        logger.info("Filtering customer products: " + pogUser);
        pogUser.setCustomerProducts(
                customerProductService.filterByYearAndMonthRange(pogUser, year, month, endYear, endMonth));
        logger.info("Filtered customer products: " + pogUser);
        logger.info("Got lookupDistributorWithBudgetData: " + pogUser);
        return pogUser;
    }

    @RemotingInclude
    public PogUser lookupDistributorWithSalesData(PogUser pogUser, Long year, Long month, String localeStr) throws
            Exception {
        logger.info("Getting lookupDistributorWithSalesData: " + pogUser.getId());
        pogUser = pogUserDao.findByPrimaryKey(pogUser.getId());

        logger.info("Filtering sales data in children ");
        customerProductService.filterByYearAndMonth(pogUser, year, month);
        logger.info("Filtered sales data in children ");

        clearDataOfAllParents(pogUser, true, true);

        logger.info("Got lookupDistributorWithSalesData: " + pogUser);
        return pogUser;
    }

    /*Clearing child users so flex doesnt waste time in mapping these all to valueobjects*/
    /*Have to keep one child in the list to determine level of parent*/
    private void clearDataOfAllParents(PogUser pogUser, boolean clearChildren, boolean clearCustomerProducts) {
        PogUser parent = pogUser.getParentUser();
        while (clearChildren && parent != null) {
            if (clearCustomerProducts) {
                parent.setCustomerProducts(new ArrayList<CustomerProduct>());
            }
            Collection<PogUser> children = parent.getChildUsers();
            Collection<PogUser> childUsers = new ArrayList<PogUser>();
            childUsers.add(children.iterator().next());
            parent.setChildUsers(childUsers);
            parent = parent.getParentUser();
        }
    }

    @RemotingInclude
    public Collection<PogUser> lookupAvailableLevel1DistributorsByCountryCode(Collection<Area> areas) throws
            Exception {
        Collection<String> areasSelected = new ArrayList<String>();
        for (Area area : areas) {
            areasSelected.add(area.getAreaCode());
        }

        return rebuildListForUI(pogUserDao.lookupAvailableLevel1DistributorsByCountryCode(areasSelected));
    }

    private Collection<PogUser> rebuildListForUI(Collection<PogUser> pogUsers) {
        Collection<PogUser> temp = new ArrayList<PogUser>();
        //hide properties not needed by UI to improve performance.
        for (PogUser pogUser : pogUsers) {
            PogUser tem = new PogUser();
            tem.setId(pogUser.getId());
            tem.setSapId(pogUser.getSapId());
            tem.setFirstName(pogUser.getFirstName());
            tem.setLastName(pogUser.getLastName());
            tem.setMiddleName(pogUser.getMiddleName());
            temp.add(tem);
        }
        return temp;
    }

    /*Clearing customer products of all levels of children so flex doesnt waste time in mapping these all to valueobjects*/
    private void clearCustomerProductsOfAllChildren(PogUser pogUser) {
        for (PogUser child : pogUser.getChildUsers()) {
            child.setCustomerProducts(new ArrayList<CustomerProduct>());
            clearCustomerProductsOfAllChildren(child);
        }
    }
}
