package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.DistributorTypeDao;
import com.monsanto.eas.pog.model.hibernate.DistributorType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: sspati1
 * Date: 2/28/11
 * Time: 1:43 PM
 * To change this template use File | Settings | File Templates.
 */
@Service
@RemotingDestination(value = "distributorTypeService")
public class DistributorTypeServiceImpl implements DistributorTypeService {
    @Autowired
    private DistributorTypeDao distributorTypeDao;

    public DistributorTypeServiceImpl() {
    }

    public DistributorTypeServiceImpl(DistributorTypeDao distributorTypeDao) {
        this.distributorTypeDao = distributorTypeDao;
    }

    @RemotingInclude
    public Collection<DistributorType> lookupAll() {
        return this.distributorTypeDao.findAll();
    }
}
