/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.LanguageDao;
import com.monsanto.eas.pog.model.hibernate.Language;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@Service
@RemotingDestination(value = "languageService")
public class LanguageServiceImpl implements LanguageService{
  @Autowired
  private LanguageDao languageDao;

  public LanguageServiceImpl() {
  }

  public LanguageServiceImpl(LanguageDao languageDao) {
    this.languageDao = languageDao;
  }

  @RemotingInclude
  public Collection<Language> lookupAll() {
    return this.languageDao.findAll();
  }
}