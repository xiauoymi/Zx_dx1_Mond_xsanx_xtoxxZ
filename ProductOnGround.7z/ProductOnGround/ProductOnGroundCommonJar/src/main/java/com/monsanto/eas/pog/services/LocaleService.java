package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.Locale;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 25, 2010 Time: 11:51:51 AM To change this template use File |
 * Settings | File Templates.
 */
public interface LocaleService {
  @RemotingInclude
  Collection<Locale> lookupAll();

  @RemotingInclude
  Locale lookupByLocale(String localeStr);
}
