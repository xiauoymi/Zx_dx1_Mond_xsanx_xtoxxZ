package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.LocaleDao;
import com.monsanto.eas.pog.model.hibernate.Locale;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 25, 2010 Time: 11:48:28 AM To change this template use File |
 * Settings | File Templates.
 */
@Service
@RemotingDestination(value = "localeService")
public class LocaleServiceImpl implements LocaleService {
  @Autowired
  private LocaleDao localeDao;

  public LocaleServiceImpl() {
  }

  public LocaleServiceImpl(LocaleDao localeDao) {
    this.localeDao = localeDao;
  }

  @RemotingInclude
  public Collection<Locale> lookupAll() {
    return localeDao.findAll("locale", true);
  }

  @RemotingInclude
  public Locale lookupByLocale(String localeStr) {
    Locale locale = new Locale();
    locale.setLocale(localeStr);
    Collection<Locale> locales = localeDao.findByExample(locale, new String[0]);
    return locales.isEmpty() ? null : locales.iterator().next();
  }
}
