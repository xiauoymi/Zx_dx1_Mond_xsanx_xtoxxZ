package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.hibernate.Product;
import com.monsanto.eas.pog.model.hibernate.ProductCode;
import org.springframework.flex.remoting.RemotingInclude;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 27, 2011 Time: 2:31:38 PM To change this template use File |
 * Settings | File Templates.
 */
public interface ProductService {
  Product lookupByCodeBaseUomIdAndMaterialId(String sapProductCode, Long baseUomId, String materialId);

  Collection<Product> lookupAllProducts();

  Product saveOrUpdate(Product product);

  Collection<Product> lookupBySalesRepUserId(String salesRepUserId);

  Product lookupById(Long productId);
}
