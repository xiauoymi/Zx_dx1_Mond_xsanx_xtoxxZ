package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.ProductCodeDao;
import com.monsanto.eas.pog.dao.ProductDao;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.hibernate.Product;
import com.monsanto.eas.pog.model.hibernate.ProductCode;
import com.monsanto.eas.pog.util.PogConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 27, 2011 Time: 2:31:29 PM To change this template use File |
 * Settings | File Templates.
 */
@Service
@RemotingDestination(value = "productService")
public class ProductServiceImpl implements ProductService {
  @Autowired
  private ProductDao productDao;

   @Autowired
  private ProductCodeDao productCodeDao;


  public ProductServiceImpl() {
  }

  public ProductServiceImpl(ProductDao productDao) {
    this.productDao = productDao;
  }

  @RemotingInclude
  public Collection<Product> lookupAllProducts() {
    return productDao.findAll("level", true);
  }

  @RemotingInclude
  public Collection<Product> lookupBySalesRepUserId(String salesRepUserId) {
    return productDao.lookupBySalesRepUserId(salesRepUserId);
  }

  @RemotingInclude
  public Product lookupById(Long productId) {
    return productDao.findByPrimaryKey(productId);
  }

  @RemotingInclude
  public Collection<Product> lookupStagedProductsByAreaId(Long areaId) {
    return productCodeDao.lookupStagedProductsByAreaId(areaId);
  }

  @RemotingInclude
  public Product saveOrUpdate(Product product) {
    return productDao.saveOrUpdate(product);
  }

  public Product lookupByCodeBaseUomIdAndMaterialId(String sapProductCode, Long baseUomId, String materialId) {
    return productDao.lookupByCodeBaseUomIdAndMaterialId(sapProductCode, baseUomId, materialId);
  }
}
