package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.Role;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 27, 2010 Time: 9:39:48 AM To change this template use File |
 * Settings | File Templates.
 */
public interface RoleService {
  public Collection<Role> lookupAll();
}
