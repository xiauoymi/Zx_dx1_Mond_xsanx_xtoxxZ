package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.RoleDao;
import com.monsanto.eas.pog.model.hibernate.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 27, 2010 Time: 9:39:53 AM To change this template use File |
 * Settings | File Templates.
 */
@Service
@RemotingDestination(value = "roleService")
public class RoleServiceImpl implements RoleService {
  @Autowired
  private RoleDao roleDao;

  public RoleServiceImpl() {
  }

  //for testing only
  public RoleServiceImpl(RoleDao roleDao) {
    this.roleDao = roleDao;
  }
                                                            
  @RemotingInclude
  public Collection<Role> lookupAll() {
    return roleDao.findAll();
  }
}
