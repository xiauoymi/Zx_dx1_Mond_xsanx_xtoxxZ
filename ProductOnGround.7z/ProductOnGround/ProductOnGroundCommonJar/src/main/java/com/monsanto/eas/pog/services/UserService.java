package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.exception.UserNotFoundException;
import com.monsanto.eas.pog.model.hibernate.PogUser;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 27, 2010 Time: 10:48:15 AM To change this template use File |
 * Settings | File Templates.
 */
public interface UserService {
  public PogUser saveOrUpdate(PogUser distributor) throws Exception;

  public PogUser lookupById(Long id);

  public PogUser syncronize(PogUser user);

  public PogUser lookupByUserId(String userId) throws UserNotFoundException;

  public Collection<PogUser> lookupAllInternalUsersForAssociatedAreas(PogUser user);

}
