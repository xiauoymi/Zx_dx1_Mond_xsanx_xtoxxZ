package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.PogUserDao;
import com.monsanto.eas.pog.dao.exception.UserNotFoundException;
import com.monsanto.eas.pog.model.hibernate.CustomerProduct;
import com.monsanto.eas.pog.model.hibernate.CustomerTransaction;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.flex.remoting.RemotingDestination;
import org.springframework.flex.remoting.RemotingInclude;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 27, 2010 Time: 10:49:09 AM To change this template use File |
 * Settings | File Templates.
 */
@Service
@RemotingDestination(value = "userService")
public class UserServiceImpl implements UserService {
  @Autowired
  private PogUserDao pogUserDao;

  private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger
      (UserServiceImpl.class.getName());

  public UserServiceImpl() {
  }

  public UserServiceImpl(PogUserDao pogUserDao) {
    this.pogUserDao = pogUserDao;
  }

  @RemotingInclude
  public PogUser saveOrUpdate(PogUser user) throws Exception {
    logger.info("In save Or Update of User\n");
    Calendar calendar = Calendar.getInstance();
    user.setModDate(calendar.getTime());
    return pogUserDao.saveOrUpdate(user);
  }

  @RemotingInclude
  public PogUser lookupById(Long id) {
    logger.info("Getting userpogUserDao.findByPrimaryKey: " + id);
    PogUser pogUser = pogUserDao.findByPrimaryKey(id);
    logger.info("Got user pogUserDao.findByPrimaryKey: " + id);
    return pogUser;
  }

  @RemotingInclude
  public PogUser lookupByUserId(String userId) throws UserNotFoundException {
    logger.info("Getting user by pogUserDao.findByUserId: " + userId);
    PogUser pogUser = pogUserDao.findByUserId(userId);
    logger.info("Got user pogUserDao.findByUserId: " + userId);
    return pogUser;
  }

  @RemotingInclude
  public PogUser syncronize(PogUser user) {
    logger.info("Synchronize operation for user sapid : " + user.getSapId());
    PogUser userToReturn;
    try {
      PogUser serverUser = getMatchingUserOnServer(user);

      serverUser.setModUser(user.getModUser());
      serverUser.setModDate(user.getModDate());
      for (CustomerProduct clientCustomerProduct : user.getCustomerProducts()) {
        for (CustomerProduct serverCustomerProduct : serverUser.getCustomerProducts()) {
          if (doServerAndClientProductMatch(clientCustomerProduct, serverCustomerProduct)) {
            populateServerCPFromClientCP(clientCustomerProduct, serverCustomerProduct);
            break;
          }
        }
      }
      logger.info("Saving the user on server");
      userToReturn = pogUserDao.saveOrUpdate(serverUser);
    } catch (UserNotFoundException ex) {
      user.setModDate(new Date());
      userToReturn = pogUserDao.saveOrUpdate(user);
    }
//    FlexSession flexSession = FlexContext.getFlexSession();
//    flexSession.invalidate();
    return userToReturn;
  }

  private PogUser getMatchingUserOnServer(PogUser user) throws UserNotFoundException {
    if (!user.isInternal() && user.getParentUser() != null) {
      return pogUserDao.findByUserId(user.getUserId());
    } else {
      return pogUserDao.findBySapId(user.getSapId());
    }
  }

  private void populateServerCPFromClientCP(CustomerProduct clientCustomerProduct,
                                            CustomerProduct serverCustomerProduct) {
    serverCustomerProduct.setModDate(clientCustomerProduct.getModDate());
    serverCustomerProduct.setModUser(clientCustomerProduct.getModUser());
    for (CustomerTransaction clientCustomerTransaction : clientCustomerProduct.getCustomerTransactions()) {
      CustomerTransaction serverTransaction = getMatchingServerTransaction(serverCustomerProduct,
          clientCustomerTransaction);
      if (serverTransaction == null) {//new transaction was created on the client, not yet on server
        serverTransaction = new CustomerTransaction();
        serverTransaction.setCustomerProduct(serverCustomerProduct);
        serverTransaction.setYear(clientCustomerTransaction.getYear());
        serverTransaction.setMonth(clientCustomerTransaction.getMonth());
        serverCustomerProduct.getCustomerTransactions().add(serverTransaction);
      }
      serverTransaction.setFinalInventory(clientCustomerTransaction.getFinalInventory());
      serverTransaction.setSalesAmount(clientCustomerTransaction.getSalesAmount());
      serverTransaction.setSapSalesAmount(clientCustomerTransaction.getSapSalesAmount());
      serverTransaction.setBudget(clientCustomerTransaction.getBudget());
      serverTransaction.setModDate(clientCustomerTransaction.getModDate());
      serverTransaction.setModUser(clientCustomerTransaction.getModUser());
    }
  }

  private boolean doServerAndClientProductMatch(CustomerProduct clientCustomerProduct,
                                                CustomerProduct serverCustomerProduct) {
    boolean match = serverCustomerProduct.getProduct().getProductCode().getCode()
        .equalsIgnoreCase(clientCustomerProduct.getProduct().getProductCode().getCode()) &&
        (serverCustomerProduct.getProduct().getBaseUnitOfMeasure().getCode()
            .equalsIgnoreCase(clientCustomerProduct.getProduct().getBaseUnitOfMeasure().getCode()));
    if (serverCustomerProduct.getProduct().getMaterialId() != null) {
      return match &&
          (serverCustomerProduct.getProduct().getMaterialId()
              .equalsIgnoreCase(clientCustomerProduct.getProduct().getMaterialId()));
    }
    return match;
  }

  private CustomerTransaction getMatchingServerTransaction(CustomerProduct serverCustomerProduct,
                                                           CustomerTransaction clientCustomerTransaction) {
    for (CustomerTransaction serverCustomerTransaction : serverCustomerProduct.getCustomerTransactions()) {
      if (serverCustomerTransaction.getYear().equals(clientCustomerTransaction.getYear()) &&
          serverCustomerTransaction.getMonth().equals(clientCustomerTransaction.getMonth())) {
        return serverCustomerTransaction;
      }
    }
    return null;
  }

  @RemotingInclude
  public Collection<PogUser> lookupAllInternalUsersForAssociatedAreas(PogUser user) {
    logger.info("Looking up all internal users for the logged in users associated areas\n");
    return pogUserDao.lookupAllInternalUsersForAssociatedAreas(user);
  }
}
