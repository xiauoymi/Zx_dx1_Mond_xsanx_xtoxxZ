package com.monsanto.eas.pog.util;

import com.monsanto.eas.pog.model.hibernate.PogUser;

import java.util.Comparator;

/**
 * Created by IntelliJ IDEA. User: NTARDUC Date: Jul 19, 2010 Time: 9:00:58 AM To change this template use File |
 * Settings | File Templates.
 */
public class FirstNameComparator implements Comparator<PogUser> {

  public int compare(PogUser pogUser1, PogUser pogUser2) {
    if (pogUser1 == null || pogUser2 == null || pogUser1.getFirstName() == null || pogUser2.getFirstName() == null){
      return -1;
    }
    String pogUserFirstName1 = pogUser1.getFirstName();
    String pogUserFirstName2 = pogUser2.getFirstName();

    return pogUserFirstName1.compareToIgnoreCase(pogUserFirstName2);
  }


}
