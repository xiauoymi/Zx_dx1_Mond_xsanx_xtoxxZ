package com.monsanto.eas.pog.util;

import flex.messaging.log.AbstractTarget;
import flex.messaging.log.LogEvent;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 9, 2010 Time: 9:10:25 AM To change this template use File |
 * Settings | File Templates.
 */
public class FlexLogger extends AbstractTarget {
  public void logEvent(LogEvent event) {
    // log4j levels:   OFF - FATAL - ERROR - WARN - INFO - DEBUG - TRACE - ALL 
    // blazeds levels:  NONE - FATAL - ERROR - WARN - INFO - DEBUG - ALL

    org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger
        (FlexLogger.class.getName());

    if (event.level >= LogEvent.ERROR)
      log.error(event.message, event.throwable);
    else if (event.level >= LogEvent.WARN)
      log.warn(event.message, event.throwable);
    else if (event.level >= LogEvent.INFO)
      log.info(event.message, event.throwable);
    else if (event.level >= LogEvent.DEBUG)
      log.debug(event.message, event.throwable);
    else
      log.trace(event.message, event.throwable);
  }

}
