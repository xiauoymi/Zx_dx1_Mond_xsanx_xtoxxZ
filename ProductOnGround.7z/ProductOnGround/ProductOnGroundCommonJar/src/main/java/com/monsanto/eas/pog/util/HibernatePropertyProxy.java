/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.util;

import flex.messaging.io.BeanProxy;
import flex.messaging.io.PropertyProxyRegistry;
import org.hibernate.collection.PersistentMap;
import org.hibernate.proxy.HibernateProxy;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class HibernatePropertyProxy extends BeanProxy {
  private static final long serialVersionUID = 1612371743382649972L;

  /**
   * Registers this class with BlazeDS to handle HibernateProxy instances
   */
  public HibernatePropertyProxy() {
    super();
    PropertyProxyRegistry.getRegistry().register(HibernateProxy.class, this);
  }

  @Override
  public Object getInstanceToSerialize(Object instance) {
    Object instanceToSerialize = null;
    if (instance instanceof Map) {
      instanceToSerialize = new HashMap();
      PersistentMap map = (PersistentMap) instance;
      for (Object key : map.keySet()) {
        ((Map) instanceToSerialize).put(key, map.get(key));
      }
    } else {
      instanceToSerialize = super.getInstanceToSerialize(instance);
    }
    return instanceToSerialize;
  }

  /**
   * Get actual name instead of cglib class name with $$enhancerByCglib in it.
   */
  @Override
  public String getClassName(Object o) {
    if (o instanceof HibernateProxy) {
      HibernateProxy object = (HibernateProxy) o;
      return object.getHibernateLazyInitializer().getEntityName();
    } else {
      return super.getClassName(o);
    }

  }
}