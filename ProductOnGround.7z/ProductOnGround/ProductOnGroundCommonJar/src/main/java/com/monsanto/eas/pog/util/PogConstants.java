package com.monsanto.eas.pog.util;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 4, 2010 Time: 10:46:52 AM To change this template use File |
 * Settings | File Templates.
 */
public class PogConstants {
  public static final String PRODUCT_MAP = "prodMap";
  public static final String LAST_MOD_DATE = "lastModDate";
  public static final String DEFAULT_LOCALE = "EN";
  public static final String NOT_AUTHORIZED_VIEW = "notauthorized";
  public static final String REF_DATA_VIEW = "referenceData";
  public static final String HOME_VIEW = "home";
  public static final String DOWNLOAD_CLIENT_VIEW = "downloadclient";
  public static final String SESSION_TIMEOUT_VIEW = "sessiontimeout";
  public static final String ERROR_VIEW = "error";
  public static final String HOME_COUNTRY_TYPE = "HOME";
  public static final String ASSOCIATION_COUNTRY_TYPE = "ASSOCIATION";
  public static final String SALES_REP = "SALES_REP";
  public static final String ADMIN = "ADMIN";
  public static final String WAM_POG_USER = "WAM_POG_USER";
  public static final String WAM_USER_ID = "WAM_USER_ID";
  public static final String PRODUCT_CAPTURE_TYPE = "PRODUCT";
  public static final String GROUP_CAPTURE_TYPE = "GROUP";
  public static final String WAM_COOKIE = "AXMSESSION";
  public static final String LOCALE = "locale";

}
