package com.monsanto.eas.pog.util;

/**
 * Created by IntelliJ IDEA.
 * User: VVPRAS
 * Date: Sep 21, 2012
 * Time: 4:47:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class SQLUtil {
    public static String spainQuery="SELECT * FROM POG.PRODUCT WHERE CODE IN(\n" +
                "SELECT DISTINCT \n" +
                "                      PRODUCT_STAGING_1.SAP_PRODUCT_CODE\n" +
                "FROM         pog.AREA AREA_2 INNER JOIN\n" +
                "                      pog.CUSTOMER_STAGING CUSTOMER_STAGING_2 ON AREA_2.AREA_CODE = CUSTOMER_STAGING_2.COUNTRY_CODE INNER JOIN\n" +
                "                      pog.AREA_CAPTURE_LEVEL AREA_CAPTURE_LEVEL_2 ON AREA_2.ID = AREA_CAPTURE_LEVEL_2.AREA_ID INNER JOIN\n" +
                "                      pog.CAPTURE_TYPE CAPTURE_TYPE_2 ON AREA_CAPTURE_LEVEL_2.CAPTURE_TYPE_ID = CAPTURE_TYPE_2.ID INNER JOIN\n" +
                "                      pog.CUSTOMER_PRODUCT ON CUSTOMER_STAGING_2.ID = CUSTOMER_PRODUCT.DISTRIBUTOR_ID INNER JOIN\n" +
                "                      pog.LAN_PRODUCT LAN_PRODUCT_2 INNER JOIN\n" +
                "                      pog.PRODUCT_STAGING PRODUCT_STAGING_1 ON LAN_PRODUCT_2.SAP_PRODUCT_CODE = PRODUCT_STAGING_1.SAP_PRODUCT_CODE INNER JOIN\n" +
                "                      pog.PRODUCT_STAGING PRODUCT_STAGING_4 ON \n" +
                "                      pog.PRODUCT_STAGING_1.SAP_PRODUCT_CODE = PRODUCT_STAGING_4.SAP_PARENT_PRODUCT_CODE ON \n" +
                "                      pog.CUSTOMER_PRODUCT.PRODUCT_PK = PRODUCT_STAGING_1.ID\n" +
                "WHERE     (CUSTOMER_STAGING_2.COUNTRY_CODE = 'ES') AND (CAPTURE_TYPE_2.\"TYPE\" = 'PRODUCT') AND \n" +
                "                      (AREA_CAPTURE_LEVEL_2.CAPTURE_LEVEL = 5) AND (LAN_PRODUCT_2.LANGUAGE_CODE = 'ES') AND (AREA_2.IS_ACTIVE = 'Y') AND \n" +
                "                      (CUSTOMER_STAGING_2.IS_DELETED = 'N') AND (CUSTOMER_PRODUCT.IS_DELETED = 'N'))";

    public static String ukQuery="SELECT *\n" +
                "FROM pog.PRODUCT PRODUCT\n" +
                "WHERE PRODUCT.CODE IN(\n" +
                "SELECT DISTINCT \n" +
                "                      PRODUCT_STAGING.SAP_PRODUCT_CODE\n" +
                "FROM         pog.LAN_PRODUCT LAN_PRODUCT INNER JOIN\n" +
                "                      pog.PRODUCT_STAGING PRODUCT_STAGING ON LAN_PRODUCT.SAP_PRODUCT_CODE = PRODUCT_STAGING.SAP_PRODUCT_CODE INNER JOIN\n" +
                "                      pog.CUSTOMER_PRODUCT CUSTOMER_PRODUCT ON PRODUCT_STAGING.ID = CUSTOMER_PRODUCT.PRODUCT_PK INNER JOIN\n" +
                "                      pog.AREA AREA INNER JOIN\n" +
                "                      pog.CUSTOMER_STAGING CUSTOMER_STAGING ON AREA.AREA_CODE = CUSTOMER_STAGING.COUNTRY_CODE INNER JOIN\n" +
                "                      pog.AREA_CAPTURE_LEVEL AREA_CAPTURE_LEVEL ON AREA.ID = AREA_CAPTURE_LEVEL.AREA_ID INNER JOIN\n" +
                "                      pog.CAPTURE_TYPE CAPTURE_TYPE ON AREA_CAPTURE_LEVEL.CAPTURE_TYPE_ID = CAPTURE_TYPE.ID ON \n" +
                "                      CUSTOMER_PRODUCT.DISTRIBUTOR_ID = CUSTOMER_STAGING.ID\n" +
                "WHERE     (CUSTOMER_STAGING.COUNTRY_CODE = 'GB') AND (CAPTURE_TYPE.\"TYPE\" = 'PRODUCT') AND (AREA_CAPTURE_LEVEL.CAPTURE_LEVEL = 6) AND \n" +
                "                      (LAN_PRODUCT.LANGUAGE_CODE = 'EN') AND (AREA.IS_ACTIVE = 'Y') AND (CUSTOMER_STAGING.IS_DELETED = 'N') AND \n" +
                "                      (CUSTOMER_PRODUCT.IS_DELETED = 'N')\n" +
                ")";

    public static String areaAdmins="SELECT DISTINCT customer_staging.ID, customer_staging.USER_ID, customer_staging.FIRST_NAME, area.AREA_NAME, user_area.EMAIL_FLAG\n" +
            "           FROM pog.customer_staging,\n" +
            "                pog.ROLE,\n" +
            "                pog.user_area,\n" +
            "                pog.pog_user_role,\n" +
            "                pog.area\n" +
            "          WHERE customer_staging.ID = user_area.customer_staging_id\n" +
            "            AND customer_staging.ID = pog_user_role.pog_user_id\n" +
            "            AND ROLE.ID = pog_user_role.role_id\n" +
            "            AND area.ID = user_area.area_id\n" +
            "            AND ROLE.role_name = 'ADMIN'\n" +
            "            AND user_area.is_active = 'Y'\n" +
            "            AND area.area_code IN (\n" +
            "                   SELECT DISTINCT (customer_staging.country_code)\n" +
            "                              FROM pog.customer_staging, pog.customer_product\n" +
            "                             WHERE customer_staging.ID =\n" +
            "                                               customer_product.distributor_id\n" +
            "                               AND customer_staging.ADMIN_MAIL_SENT_FLAG='N' \n" +
            "                               AND customer_staging.country_code IS NOT NULL\n" +
            "                               AND customer_staging.sap_id IS NOT NULL)\n" +
            "       ORDER BY customer_staging.user_id";

    public static String salesReps_notCapturedData = "SELECT   customer_staging.ID, customer_staging.FIRST_NAME,\n" +
            "         customer_staging.USER_ID\n" +
            "    FROM pog.customer_staging\n" +
            "   WHERE customer_staging.user_id IS NOT NULL\n" +
            "     AND customer_staging.ID IN (\n" +
            "            SELECT DISTINCT customer_staging.sales_rep_id\n" +
            "                       FROM pog.customer_transaction,\n" +
            "                            pog.customer_staging,\n" +
            "                            pog.customer_sales_org,\n" +
            "                            pog.customer_product\n" +
            "                      WHERE customer_staging.ID = customer_product.distributor_id\n" +
            "                        AND customer_product.ID = customer_transaction.customer_product_id\n" +
            "                        AND customer_sales_org.sap_id = customer_staging.sap_id\n" +
            "                        AND customer_transaction.final_inventory = 0\n" +
            "                        AND customer_staging.sales_rep_id IS NOT NULL\n" +
            "                        AND customer_transaction.MONTH = :month \n" +
            "                        AND customer_transaction.YEAR = :year )\n" +
            "ORDER BY customer_staging.sales_rep_id";

    public static String setDealerStatus_adminEmails ="update pog.customer_staging set customer_staging.ADMIN_MAIL_SENT_FLAG = 'Y' \n" +
            "where customer_staging.ID IN(\n" +
            "SELECT customer_staging.ID\n" +
            "FROM pog.customer_staging, pog.customer_product\n" +
            "WHERE customer_staging.ID = customer_product.distributor_id\n" +
            "AND customer_staging.ADMIN_MAIL_SENT_FLAG = 'N'  \n" +
            "AND customer_staging.country_code IS NOT NULL\n" +
            "AND customer_staging.sap_id IS NOT NULL)";
}
