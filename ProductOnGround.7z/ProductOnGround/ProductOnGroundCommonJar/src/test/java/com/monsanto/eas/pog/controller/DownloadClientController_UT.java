package com.monsanto.eas.pog.controller;

import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.hibernate.Role;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 5, 2010 Time: 6:16:52 PM To change this template use File |
 * Settings | File Templates.
 */
public class DownloadClientController_UT extends TestCase {

  @Test
  public void testHandleRequestInternal_NoWamUser_Unauthorized() throws Exception {
    DownloadClientController controller = new DownloadClientController();
    HttpServletRequest request = new MockHttpServletRequest();
    ModelAndView modelAndView = controller.handleRequestInternal(request, null);
    assertEquals("notauthorized", modelAndView.getViewName());
  }

  @Test
  public void testHandleRequestInternal_WamUserIsNotSalesRep_Unauthorized() throws Exception {
    DownloadClientController controller = new DownloadClientController();
    MockHttpSession session = new MockHttpSession();
    PogUser user = new PogUser();
    Collection<Role> roles = new ArrayList<Role>();
    Role role = new Role();
    role.setRoleName("NO_REP");
    roles.add(role);
    user.setRoles(roles);
    session.setAttribute("WAM_POG_USER", user);
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setSession(session);
    ModelAndView modelAndView = controller.handleRequestInternal(request, null);
    assertEquals("notauthorized", modelAndView.getViewName());
  }

  @Test
  public void testHandleRequestInternal_WamUserIsSalesRep_GoesToDownload() throws Exception {
    DownloadClientController controller = new DownloadClientController();
    MockHttpSession session = new MockHttpSession();
    PogUser user = new PogUser();
    Collection<Role> roles = new ArrayList<Role>();
    Role role = new Role();
    role.setRoleName("SALES_REP");
    roles.add(role);
    user.setRoles(roles);
    session.setAttribute("WAM_POG_USER", user);
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setSession(session);
    ModelAndView modelAndView = controller.handleRequestInternal(request, null);
    assertEquals("downloadclient", modelAndView.getViewName());
  }

}