package com.monsanto.eas.pog.controller;

import com.monsanto.eas.pog.model.hibernate.Locale;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 14, 2010 Time: 4:27:14 PM To change this template use File |
 * Settings | File Templates.
 */
public class HomeController_UT extends TestCase {

  @Test
  public void testHandleRequestInternal_NoWamUser_Unauthorized() throws Exception {
    HomeController controller = new HomeController();
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setSession(new MockHttpSession());
    ModelAndView modelAndView = controller.handleRequestInternal(request, null);
    assertEquals("notauthorized", modelAndView.getViewName());
  }

  @Test
  public void testHandleRequestInternal_WamUser_GoesToHome() throws Exception {
    HomeController controller = new HomeController();
    MockHttpSession session = new MockHttpSession();
    PogUser pogUser = new PogUser();
    Locale locale = new Locale();
    locale.setLocale("ES");
    pogUser.setLocale(locale);
    session.setAttribute("WAM_POG_USER", pogUser);
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setSession(session);
    ModelAndView modelAndView = controller.handleRequestInternal(request, null);
    assertEquals("home", modelAndView.getViewName());
    assertEquals(1, modelAndView.getModel().size());
    assertEquals("es", modelAndView.getModel().get("locale"));
  }
}
