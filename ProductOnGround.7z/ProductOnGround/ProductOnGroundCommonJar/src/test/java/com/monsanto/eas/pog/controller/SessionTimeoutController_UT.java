package com.monsanto.eas.pog.controller;

import com.monsanto.eas.pog.util.PogConstants;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.Cookie;


/**
 * Created by IntelliJ IDEA. User: sspati1 Date: 2/8/11 Time: 10:27 AM To change this template use File | Settings |
 * File Templates.
 */
public class SessionTimeoutController_UT extends TestCase {
  @Test
  public void testHandleRequestInternal_NoSession() throws Exception {
    SessionTimeoutController controller = new SessionTimeoutController();
    MockHttpServletRequest request = new MockHttpServletRequest(null);
    request.setCookies(new Cookie[0]);
    ModelAndView modelAndView = controller.handleRequestInternal(request, null);
    assertEquals("sessiontimeout", modelAndView.getViewName());
  }

  @Test
  public void testHandleRequestInternal_WithSession() throws Exception {
    SessionTimeoutController controller = new SessionTimeoutController();
    MockHttpServletRequest request = new MockHttpServletRequest();
    Cookie[] cookies = new Cookie[2];
    cookies[0] = new Cookie(PogConstants.WAM_COOKIE, "test");
    cookies[1] = new Cookie("nil", "test");
    request.setCookies(cookies);
    MockHttpSession session = new MockHttpSession();
    session.setAttribute(PogConstants.WAM_POG_USER, new Object());
    session.setAttribute(PogConstants.WAM_USER_ID, new Object());
    request.setSession(session);
    MockHttpServletResponse response = new MockHttpServletResponse();
    ModelAndView modelAndView = controller.handleRequestInternal(request, response);

    assertEquals("sessiontimeout", modelAndView.getViewName());
    assertNotNull(session);
    assertNull(session.getAttribute(PogConstants.WAM_POG_USER));
    assertNull(session.getAttribute(PogConstants.WAM_USER_ID));
    assertEquals(2, request.getCookies().length);

    Cookie[] cookies1 = response.getCookies();
    assertEquals(1, cookies1.length);
    Cookie c1 = (Cookie) cookies1[0];
    assertEquals(PogConstants.WAM_COOKIE, c1.getName());
    assertEquals(0, c1.getMaxAge());
  }
}
