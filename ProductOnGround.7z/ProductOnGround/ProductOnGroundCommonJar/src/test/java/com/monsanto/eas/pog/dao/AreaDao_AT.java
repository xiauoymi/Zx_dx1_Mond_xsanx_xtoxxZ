package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.UserAreaPk;
import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 18, 2010 Time: 2:32:49 PM To change this template use File |
 * Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class AreaDao_AT extends TestCase {
  @Autowired
  private AreaDao areaDao = null;
  @Autowired
  private CaptureTypeDao captureTypeDao = null;
  @Autowired
  private CountryTypeDao countryTypeDao = null;
  @Autowired
  private PogUserDao pogUserDao = null;

  private Area newArea;
  private CaptureType productCaptureType, distributorCaptureType;
  private CountryType homeCountryType;
  private PogUser newUser;

  @Before
  public void setUp() throws Exception {
    newArea = new Area();
    newArea.setAreaName("New Area from AT");
    newArea.setAreaCode("AT");

    Collection<AreaCaptureLevel> captureLevels = new ArrayList<AreaCaptureLevel>();
    productCaptureType = new CaptureType();
    productCaptureType.setType("PRODUCT");
    captureTypeDao.saveOrUpdate(productCaptureType);

    AreaCaptureLevel captureLevel1 = new AreaCaptureLevel();
    captureLevel1.setArea(newArea);
    captureLevel1.setCaptureLevel(2);
    captureLevel1.setCaptureType(productCaptureType);
    captureLevels.add(captureLevel1);
    AreaCaptureLevel captureLevel2 = new AreaCaptureLevel();
    captureLevel2.setArea(newArea);
    captureLevel2.setCaptureLevel(2);
    captureLevel2.setCaptureType(productCaptureType);
    captureLevels.add(captureLevel2);

    distributorCaptureType = new CaptureType();
    distributorCaptureType.setType("DISTRIBUTOR");
    captureTypeDao.saveOrUpdate(distributorCaptureType);

    AreaCaptureLevel captureLevel3 = new AreaCaptureLevel();
    captureLevel3.setArea(newArea);
    captureLevel3.setCaptureLevel(3);
    captureLevel3.setCaptureType(distributorCaptureType);
    captureLevels.add(captureLevel3);
    AreaCaptureLevel captureLevel4 = new AreaCaptureLevel();
    captureLevel4.setArea(newArea);
    captureLevel4.setCaptureLevel(4);
    captureLevel4.setCaptureType(distributorCaptureType);
    captureLevels.add(captureLevel4);
    newArea.setCaptureLevels(captureLevels);

    Collection<PogUser> users = new ArrayList<PogUser>();
    PogUser user1 = new PogUser();
    user1.setUserId("testId1");
    user1.setFirstName("FirstName 1");
    user1.setLastName("LastName 1");
    users.add(user1);
    PogUser user2 = new PogUser();
    user2.setUserId("testId2");
    user2.setFirstName("FirstName 2");
    user2.setLastName("LastName 2");
    users.add(user2);
//    newArea.setPogUsers(users);

    newUser = new PogUser();
    newUser.setUserId("testId1");
    newUser.setFirstName("FirstName from AT");
    newUser.setLastName("LastName from AT");
    pogUserDao.saveOrUpdate(newUser);

    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    homeCountryType = countryTypeDao.lookupByType("HOME");

    UserArea userArea1 = new UserArea();
    UserAreaPk userAreaPk = new UserAreaPk();

    userAreaPk.setCountryType(homeCountryType);
    userAreaPk.setPogUser(newUser);
    Area area1 = new Area();
    area1.setId(1L);
    userAreaPk.setArea(area1);
    userArea1.setPk(userAreaPk);

    userAreas.add(userArea1);
//    newArea.setUserAreas(userAreas);

    areaDao.saveOrUpdate(newArea);
  }

  @After
  public void tearDown() {
    areaDao.delete(newArea);
    captureTypeDao.delete(productCaptureType);
    captureTypeDao.delete(distributorCaptureType);
    pogUserDao.delete(newUser);
  }

  @Test
  public void testFindByPrimaryKey() throws Exception {
    Area area = areaDao.findByPrimaryKey(newArea.getId());
    assertNotNull(area);
    assertEquals("New Area from AT", area.getAreaName());
    assertEquals("AT", area.getAreaCode());

    assertEquals(4, area.getCaptureLevels().size());

    int productLevels = 0, distributorLevels = 0;
    for (AreaCaptureLevel level : area.getCaptureLevels()) {
      if (level.getCaptureType().getType().equals("PRODUCT")) {
        productLevels++;
      }
      if (level.getCaptureType().getType().equals("DISTRIBUTOR")) {
        distributorLevels++;
      }
    }
    assertEquals(2, productLevels);
    assertEquals(2, distributorLevels);
  }

  @Test
  public void testSave() throws Exception {
    Area areaToSave = new Area();
    areaToSave.setAreaName("New Area to Save");
    areaToSave.setAreaCode("NA");
    Area area = areaDao.saveOrUpdate(areaToSave);
    assertNotNull(area);
    assertNotNull(area.getId());
    assertEquals("New Area to Save", area.getAreaName());
    areaDao.delete(areaToSave);
  }

  @Test
  public void testUpdate() throws Exception {
    Area areaToSave = new Area();
    areaToSave.setAreaName("New Area to Save");
    areaToSave.setAreaCode("NA");
    Area area = areaDao.saveOrUpdate(areaToSave);
    area.setAreaName("Updated New Area to Save");
    area = areaDao.saveOrUpdate(area);
    assertNotNull(area);
    assertNotNull(area.getId());
    assertEquals("Updated New Area to Save", area.getAreaName());
    areaDao.delete(areaToSave);
  }

  @Test
  public void testFindAll() throws Exception {
    Collection<Area> areaList = areaDao.findAll("areaCode", true);
    assertTrue(areaList.size() >= 1);
  }

  @Test
  public void testDelete() throws Exception {
    areaDao.delete(newArea);
    Area area = areaDao.findByPrimaryKey(newArea.getId());
    assertNull(area);
  }

}
