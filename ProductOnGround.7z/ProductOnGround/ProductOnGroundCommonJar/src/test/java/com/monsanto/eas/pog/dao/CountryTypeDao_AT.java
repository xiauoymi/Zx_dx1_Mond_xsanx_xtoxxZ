package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CountryType;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 3, 2010 Time: 10:20:13 AM To change this template use File |
 * Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class CountryTypeDao_AT extends TestCase {
  @Autowired
  private CountryTypeDao countryTypeDao = null;

  private CountryType countryType;

  @Before
  public void setUp() throws Exception {
    countryType = new CountryType();
    countryType.setType("New Country Type");

    countryType = countryTypeDao.saveOrUpdate(countryType);
  }

  @After
  public void tearDown() {
    countryTypeDao.delete(countryType);
  }

  @Test
  public void testFindByExample() throws Exception {
    CountryType type = countryTypeDao.lookupByType("New Country Type");
    assertNotNull(type);
  }

  @Test
  public void testFindByExample_NotFound_ThrowsException() throws Exception {
    try {
      countryTypeDao.lookupByType("not found");
      fail("this should have failed");
    } catch (Exception e) {
      assertEquals("No country type found with type: not found", e.getMessage());
    }

  }
}
