package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.CustomerMaterial;
import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = "/dao-test-config.xml")
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class CustomerMaterialDao_AT extends TestCase {
  @Autowired
  private CustomerMaterialDao customerMaterialDao;

  @Test
  public void testLookupByCustomerId() {
    Collection<CustomerMaterial> customerMaterials = customerMaterialDao.lookupByCustomerPk(1794955L); //798172260L
    assertTrue(customerMaterials.size() > 1);
  }
}
