package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jul 15, 2010 Time: 7:44:31 AM To change this template use File |
 * Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class CustomerProductDao_AT extends TestCase {
  @Autowired
  private PogUserDao pogUserDao = null;
  @Autowired
  private ProductDao productDao = null;
  @Autowired
  private CustomerProductDao customerProductDao = null;
  @Autowired
  private BaseUnitOfMeasureDao baseUomDao = null;

  private PogUser newUser;
  private BaseUnitOfMeasure baseUom;
  private Product product1, product2, product3;

  @Before
  public void setUp() throws Exception {
    baseUom = new BaseUnitOfMeasure();
    baseUom.setCode("ZZ");
    baseUom.setDescription("Liter");
    baseUomDao.saveOrUpdate(baseUom);

    product1 = new Product();
    product1.setCode("AA123");
    product1.setBaseUnitOfMeasure(baseUom);
    product1.setParentCode(null);
    product1.setBaseUomCode("ZZ");
    productDao.saveOrUpdate(product1);

    product2 = new Product();
    product2.setCode("AA124");
    product2.setBaseUnitOfMeasure(baseUom);
    product2.setParentCode(null);
    product2.setBaseUomCode("ZZ");
    productDao.saveOrUpdate(product2);

    product3 = new Product();
    product3.setCode("AA125");
    product3.setBaseUnitOfMeasure(baseUom);
    product3.setParentCode(null);
    product3.setBaseUomCode("ZZ");
    productDao.saveOrUpdate(product3);

    newUser = new PogUser();
    newUser.setUserId("testId1");
    newUser.setFirstName("FirstName from AT");
    newUser.setLastName("LastName from AT");

    newUser.setSapId("123");
    newUser.setAddress1("123 Street");

    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();
    CustomerProduct customerProduct = new CustomerProduct();
    customerProduct.setDistributor(newUser);
    customerProduct.setProduct(product1);
    customerProduct.setModDate(new Date());
    customerProduct.setModUser("Test AT");
    Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();
    CustomerTransaction ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(7L);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(8L);
    customerTransactions.add(ct);
    customerProduct.setCustomerTransactions(customerTransactions);
    customerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    customerProduct.setDistributor(newUser);
    customerProduct.setProduct(product2);
    customerProduct.setModDate(new Date());
    customerProduct.setModUser("Test AT");
    customerTransactions = new ArrayList<CustomerTransaction>();
    ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(7L);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(8L);
    customerTransactions.add(ct);
    customerProduct.setCustomerTransactions(customerTransactions);
    customerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    customerProduct.setDistributor(newUser);
    customerProduct.setProduct(product3);
    customerProduct.setModDate(new Date());
    customerProduct.setModUser("Test AT");
    customerProduct.setDeleted(true);
    customerTransactions = new ArrayList<CustomerTransaction>();
    ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(3L);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(4L);
    customerTransactions.add(ct);
    customerProduct.setCustomerTransactions(customerTransactions);
    customerProducts.add(customerProduct);

    newUser.setCustomerProducts(customerProducts);

    newUser = pogUserDao.saveOrUpdate(newUser);
  }

  @After
  public void tearDown() {
    pogUserDao.delete(newUser);
    productDao.delete(product1);
    productDao.delete(product2);
    productDao.delete(product3);
    baseUomDao.delete(baseUom);
  }

  @Test
  public void testLookupInactiveByDistributorAndProduct() throws Exception {
    CustomerProduct product = customerProductDao
        .lookupInactiveByDistributorProductCodeAndBaseUomCode(1795041L, "AA124117E02ESC","L","NA");
    assertEquals("AA124117E02ESC",product.getProduct().getCode());
  }

}
