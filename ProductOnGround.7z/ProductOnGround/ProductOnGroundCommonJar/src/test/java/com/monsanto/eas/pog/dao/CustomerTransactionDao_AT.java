package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jul 12, 2010 Time: 8:10:05 AM To change this template use File |
 * Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class CustomerTransactionDao_AT extends TestCase {
  @Autowired
  private CustomerTransactionDao customerTransactionDao = null;
  @Autowired
  private PogUserDao pogUserDao = null;
  @Autowired
  private CustomerProductDao customerProductDao = null;
  @Autowired
  private BaseUnitOfMeasureDao baseUomDao = null;
  @Autowired
  private LocaleDao localeDao = null;
  @Autowired
  private ProductDao productDao = null;
  @Autowired
  private CustomerMaterialDao customerMaterialDao = null;

  private PogUser newUser;
  private BaseUnitOfMeasure baseUom;
  private Locale locale;
  private Product product1, product2, product3;

  @Before
  public void setUp() throws Exception {
//    locale = new Locale();
//    locale.setLanguage("French");
//    locale.setLocale("fr");
//    locale.setSapLocale("fr_FR");
//    localeDao.saveOrUpdate(locale);
//
//    newUser = new PogUser();
//    newUser.setUserId("testId1");
//    newUser.setFirstName("FirstName from AT");
//    newUser.setLastName("LastName from AT");
//
//    newUser.setLocale(locale);
//
//    newUser.setSapId("123");
//    newUser.setAddress1("123 Street");
//
//    baseUom = new BaseUnitOfMeasure();
//    baseUom.setCode("ZZ");
//    baseUom.setDescription("Liter");
//    baseUomDao.saveOrUpdate(baseUom);
//
//    product1 = new Product();
//    product1.setCode("AA123");
//    product1.setBaseUnitOfMeasure(baseUom);
//    product1.setBaseUomCode("L");
//    productDao.saveOrUpdate(product1);
//
//    product2 = new Product();
//    product2.setCode("AA124");
//    product2.setBaseUnitOfMeasure(baseUom);
//    product2.setBaseUomCode("ZZ");
//    productDao.saveOrUpdate(product2);
//
//    product3 = new Product();
//    product3.setCode("AA1245");
//    product3.setBaseUnitOfMeasure(baseUom);
//    product3.setBaseUomCode("ZZ");
//    productDao.saveOrUpdate(product3);
//
//    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();
//    CustomerProduct customerProduct = new CustomerProduct();
//    customerProduct.setDistributor(newUser);
//    customerProduct.setProduct(product1);
//    customerProduct.setModDate(new Date());
//    customerProduct.setModUser("Test AT");
//    Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();
//    CustomerTransaction ct = new CustomerTransaction();
//    ct.setCustomerProduct(customerProduct);
//    ct.setYear(2010L);
//    ct.setMonth(7L);
//    ct.setFinalInventory(123.0);
//    customerTransactions.add(ct);
//    ct = new CustomerTransaction();
//    ct.setCustomerProduct(customerProduct);
//    ct.setYear(2010L);
//    ct.setMonth(8L);
//    ct.setFinalInventory(234.0);
//    customerTransactions.add(ct);
//    customerProduct.setCustomerTransactions(customerTransactions);
//    customerProducts.add(customerProduct);
//
//    customerProduct = new CustomerProduct();
//    customerProduct.setDistributor(newUser);
//    customerProduct.setProduct(product2);
//    customerProduct.setModDate(new Date());
//    customerProduct.setModUser("Test AT");
//    customerTransactions = new ArrayList<CustomerTransaction>();
//    ct = new CustomerTransaction();
//    ct.setCustomerProduct(customerProduct);
//    ct.setYear(2010L);
//    ct.setMonth(7L);
//    customerTransactions.add(ct);
//    ct = new CustomerTransaction();
//    ct.setCustomerProduct(customerProduct);
//    ct.setYear(2010L);
//    ct.setMonth(8L);
//    customerTransactions.add(ct);
//    customerProduct.setCustomerTransactions(customerTransactions);
//    customerProducts.add(customerProduct);
//
//    customerProduct = new CustomerProduct();
//    customerProduct.setDistributor(newUser);
//    customerProduct.setProduct(product3);
//    customerProduct.setModDate(new Date());
//    customerProduct.setModUser("Test AT");
//    customerProduct.setDeleted(true);
//    customerTransactions = new ArrayList<CustomerTransaction>();
//    ct = new CustomerTransaction();
//    ct.setCustomerProduct(customerProduct);
//    ct.setYear(2010L);
//    ct.setMonth(3L);
//    customerTransactions.add(ct);
//    ct = new CustomerTransaction();
//    ct.setCustomerProduct(customerProduct);
//    ct.setYear(2010L);
//    ct.setMonth(4L);
//    customerTransactions.add(ct);
//    customerProduct.setCustomerTransactions(customerTransactions);
//    customerProducts.add(customerProduct);
//
//    newUser.setCustomerProducts(customerProducts);
//
//    newUser = pogUserDao.saveOrUpdate(newUser);
  }

/*  @After
  public void tearDown() {
    pogUserDao.delete(newUser);
    localeDao.delete(locale);
    productDao.delete(product1);
    productDao.delete(product2);
    productDao.delete(product3);
    baseUomDao.delete(baseUom);
  }*/

  @Test
  public void testLookupByDistributorIdYearAndMonthRange() throws Exception {
    Collection<CustomerTransaction> transactions = customerTransactionDao
        .lookupByDistributorIdYearAndMonthRange(1795190L, 2010L, 8L,
            2010L, 8L);
    assertEquals(2, transactions.size());
  }

  @Test
  public void testLookupByDistributorIdYearAndMonthRange__AcrossYears() throws Exception {
    Collection<CustomerTransaction> transactions = customerTransactionDao
        .lookupByDistributorIdYearAndMonthRange(1794736L, 2010L, 8L,
            2010L, 8L);
    assertTrue(transactions.size()>=2);
  }

  @Test
  public void testLookupByDistributorIdYearAndMonthRange_SameYear() throws Exception {
    Collection<CustomerTransaction> transactions = customerTransactionDao
        .lookupByDistributorIdYearAndMonthRange(1794736L, 2010L, 8L,
            2010L, 8L);
    assertTrue(transactions.size()>=4);
  }

  @Test
  public void testLookupByDistributorIdYearAndMonthRange_NullYearAndMonth() throws Exception {
    Collection<CustomerTransaction> transactions = customerTransactionDao
        .lookupByDistributorIdYearAndMonthRange(1794736L,  2011L, 8L, 2011L, 8L);
    assertTrue(transactions.size()>=4);
  }

  @Test
  public void testLookupByDistributorIdsYearAndMonthRange_NullYearAndMonth() throws Exception {
    Collection<Long> ids = new ArrayList<Long>();
    Collection<CustomerTransaction> transactions = customerTransactionDao
        .lookupByParentDistributorIdYearAndMonthRange(1794736L, 2011L, 8L, 2011L, 8L);
    assertTrue(transactions.size()>=4);
  }

  @Test
  public void testLookupByDidfgfYearAndMonthRange_NullYearAndMonth() throws Exception {
    Collection<CustomerMaterial> customerMaterials = customerMaterialDao.lookupByCustomerPk(1799889L);
    assertTrue(customerMaterials.size()>=4);
  }
}
