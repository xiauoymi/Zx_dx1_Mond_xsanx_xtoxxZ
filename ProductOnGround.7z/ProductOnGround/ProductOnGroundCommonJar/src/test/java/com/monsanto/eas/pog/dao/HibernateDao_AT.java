package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.UserAreaPk;
import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.impl.CriteriaImpl;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 20, 2010 Time: 10:50:40 AM To change this template use File |
 * Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class HibernateDao_AT extends TestCase {
  private HibernateDao hibernateDao;
  @Autowired
  private PogUserDao pogUserDao = null;
  @Autowired
  private UserAreaDao userAreaDao = null;
  @Autowired
  private LocaleDao localeDao = null;
  @Autowired
  private CountryTypeDao countryTypeDao = null;
  @Autowired
  private AreaDao areaDao = null;
  @Autowired
  private BaseUnitOfMeasureDao baseUomDao = null;
  @Autowired
  private ProductDao productDao = null;

  private PogUser newUser;
  private PogUser salesRep;
  private Locale locale;
  private CountryType homeCountryType;
  private Area newArea;
  private BaseUnitOfMeasure baseUom;
  private Product product1;

  @Autowired
  public void setupSessionFactory(SessionFactory sessionFactory) {
    hibernateDao = new HibernateDao();
    hibernateDao.setupSessionFactory(sessionFactory, PogUser.class);
  }

  @Before
  public void setUp() throws Exception {
    locale = new Locale();
    locale.setLanguage("French");
    locale.setLocale("fr");
    locale.setSapLocale("fr_FR");
    localeDao.saveOrUpdate(locale);

    baseUom = new BaseUnitOfMeasure();
    baseUom.setCode("LTEST");
    baseUom.setDescription("Liter");
    baseUomDao.saveOrUpdate(baseUom);

    newUser = new PogUser();
    newUser.setUserId("testId1");
    newUser.setFirstName("FirstName from AT");
    newUser.setLastName("LastName from AT");
    newUser.setLocale(locale);

    newUser.setSapId("123");
    newUser.setAddress1("123 Street");

    newArea = new Area();
    newArea.setAreaCode("NA");
    newArea.setAreaName("New Area from AT");
    areaDao.saveOrUpdate(newArea);

    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    homeCountryType = countryTypeDao.lookupByType("HOME");

    product1 = new Product();
    product1.setCode("AA123");
    product1.setBaseUnitOfMeasure(baseUom);
    product1.setBaseUomCode("L");
    productDao.saveOrUpdate(product1);

    UserArea userArea1 = new UserArea();
    UserAreaPk userAreaPk = new UserAreaPk();

    userAreaPk.setCountryType(homeCountryType);
    userAreaPk.setPogUser(newUser);
    userAreaPk.setArea(newArea);
    userArea1.setPk(userAreaPk);

    userAreas.add(userArea1);
    CustomerProduct customerProduct = new CustomerProduct();
    customerProduct.setDistributor(newUser);
    customerProduct.setProduct(product1);
    customerProduct.setModDate(new Date());
    customerProduct.setModUser("Test AT");


    salesRep = new PogUser();
    salesRep.setUserId("salesRep1");
    salesRep.setFirstName("FirstName salesRep 1");
    salesRep.setLastName("LastName salesRep 1");
    pogUserDao.saveOrUpdate(salesRep);
    newUser.setSalesRep(salesRep);

    newUser = pogUserDao.saveOrUpdate(newUser);
  }

  @After
  public void tearDown() {
    pogUserDao.delete(newUser);
    pogUserDao.delete(salesRep);
    localeDao.delete(locale);
    areaDao.delete(newArea);
    baseUomDao.delete(baseUom);
    productDao.delete(product1);
  }

  @Test
  public void testFindByPrimaryKey() throws Exception {
    PogUser pogUser = (PogUser) hibernateDao.findByPrimaryKey(newUser.getId());
    assertNotNull(pogUser);
    assertEquals("FirstName from AT", pogUser.getFirstName());
  }

  @Test
  public void testSave() throws Exception {
    PogUser savedUser = new PogUser();
    savedUser.setUserId("testId2");
    savedUser.setFirstName("Saved First Name from AT");
    savedUser.setLastName("Saved Last Name from AT");
    PogUser pogUser = (PogUser) hibernateDao.saveOrUpdate(savedUser);
    assertNotNull(pogUser);
    assertEquals("Saved First Name from AT", pogUser.getFirstName());
    hibernateDao.delete(savedUser);
  }

  @Test
  public void testUpdate() throws Exception {
    newUser.setFirstName("Updated First Name");
    PogUser pogUser = (PogUser) hibernateDao.saveOrUpdate(newUser);
    assertNotNull(pogUser);
    assertEquals("Updated First Name", pogUser.getFirstName());
  }

  @Test
  public void testDelete() throws Exception {
    hibernateDao.delete(newUser);
    PogUser pogUser = (PogUser) hibernateDao.findByPrimaryKey(newUser.getId());
    assertNull(pogUser);
  }

  @Test
  public void testCreateCriteria() throws Exception {
    Criteria criteria = hibernateDao.createCriteria();
    assertNotNull(criteria);
    assertTrue(((CriteriaImpl) criteria).getEntityOrClassName().contains(PogUser.class.getName()));
  }

  @Test
  public void testFindAll() throws Exception {
    Collection<PogUser> pogUsers = hibernateDao.findAll();
    assertTrue(pogUsers.size() >= 1);
  }

  @Test
  public void testFindAll_WithFetchSize() throws Exception {
    Collection<PogUser> pogUsers = hibernateDao.findAll(0, 2);
    assertTrue(pogUsers.size() >= 1);
  }

  @Test
  public void testFindAll_OrderedAsc() throws Exception {
    Collection<PogUser> pogUsers = hibernateDao.findAll("userId", true);
    assertTrue(pogUsers.size() >= 1);
  }

  @Test
  public void testFindAll_OrderedDesc() throws Exception {
    Collection<PogUser> pogUsers = hibernateDao.findAll("userId", false);
    assertTrue(pogUsers.size() >= 1);
  }

  @Test
  public void testFindByExample() throws Exception {
    PogUser exampleUser = new PogUser();
    exampleUser.setFirstName("FirstName from AT");
    Collection<PogUser> pogUsers = hibernateDao.findByExample(exampleUser, new String[0]);
    assertEquals(1, pogUsers.size());
  }

}
