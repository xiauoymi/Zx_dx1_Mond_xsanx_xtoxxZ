package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.dao.exception.UserNotFoundException;
import com.monsanto.eas.pog.model.CustomizedPOGUser;
import com.monsanto.eas.pog.model.UserAreaPk;
import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 18, 2010 Time: 5:27:00 PM To change this template use File |
 * Settings | File Templates.                   lookupSalesRepsWithAssociatedArea
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class PogUserDao_AT extends TestCase {
  @Autowired
  private PogUserDao pogUserDao = null;
  @Autowired
  private UserAreaDao userAreaDao = null;
  @Autowired
  private LocaleDao localeDao = null;
  @Autowired
  private CountryTypeDao countryTypeDao = null;
  @Autowired
  private AreaDao areaDao = null;
  @Autowired
  private BaseUnitOfMeasureDao baseUomDao = null;
  @Autowired
  private RoleDao roleDao = null;
  @Autowired
  private ProductDao productDao = null;

  private PogUser newUser;
  private PogUser salesRep;
  private Locale locale;
  private CountryType homeCountryType, associationCountryType;
  private Role salesRepRole;
  private Area newArea, newArea1, newArea2;
  private BaseUnitOfMeasure baseUom;
  private Product product1;

  @Before
  public void setUp() throws Exception {
    locale = new Locale();
    locale.setLanguage("French");
    locale.setLocale("fr");
    locale.setSapLocale("fr_FR");
    localeDao.saveOrUpdate(locale);

    baseUom = new BaseUnitOfMeasure();
    baseUom.setCode("ZZ");
    baseUom.setDescription("Liter");
    baseUomDao.saveOrUpdate(baseUom);

    product1 = new Product();
    product1.setCode("AA123");
    product1.setBaseUnitOfMeasure(baseUom);
    product1.setBaseUomCode("ZZ");
    productDao.saveOrUpdate(product1);

    newUser = new PogUser();
    newUser.setUserId("testId1");
    newUser.setFirstName("FirstName from AT");
    newUser.setLastName("LastName from AT");
    newUser.setLocale(locale);

    newUser.setSapId("123");
    newUser.setAddress1("123 Street");

//    PogUser parentUser1 = new PogUser();
//    parentUser1.setUserId("parent1");
//    parentUser1.setFirstName("FirstName Parent 1");
//    parentUser1.setLastName("LastName Parent 1");
//    newUser.setParentUser(parentUser1);

//    Collection<PogUser> childUsers = new ArrayList<PogUser>();
//    PogUser child1 = new PogUser();
//    child1.setUserId("child1");
//    child1.setFirstName("FirstName Child 1");
//    child1.setLastName("LastName Child 1");
//    childUsers.add(child1);
//    PogUser child2 = new PogUser();
//    child2.setUserId("child2");
//    child2.setFirstName("FirstName Child 2");
//    child2.setLastName("LastName Child 2");
//    childUsers.add(child2);
//    newUser.setChildUsers(childUsers);

    newArea = new Area();
    newArea.setAreaCode("NA");
    newArea.setAreaName("New Area from AT");
    areaDao.saveOrUpdate(newArea);

    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    homeCountryType = countryTypeDao.lookupByType("HOME");
    associationCountryType = countryTypeDao.lookupByType("ASSOCIATION");

    UserArea userArea1 = new UserArea();
    UserAreaPk userAreaPk = new UserAreaPk();

    userAreaPk.setCountryType(homeCountryType);
    userAreaPk.setPogUser(newUser);
    userAreaPk.setArea(newArea);
    userArea1.setPk(userAreaPk);

    userAreas.add(userArea1);
    newUser.setUserAreas(userAreas);

    Collection<CustomerProduct> customerProductsList = new ArrayList<CustomerProduct>();
    CustomerProduct customerProduct = new CustomerProduct();
    customerProduct.setDistributor(newUser);
    customerProduct.setProduct(product1);
    customerProduct.setModDate(new Date());
    customerProduct.setModUser("Test AT");

//    Collection<CustomerTransaction> customerTransactionList = new ArrayList<CustomerTransaction>();
//    CustomerTransaction customerTransaction1 = new CustomerTransaction();
//    customerTransaction1.setBudget(13L);
//    customerTransaction1.setCustomerProduct(customerProduct);
//    customerTransaction1.setFinalInventory(111L);
//    customerTransaction1.setSalesAmount(222.0);
//    customerTransaction1.setStartMonth(1L);
//    customerTransaction1.setStartYear(2010L);
//    customerTransactionList.add(customerTransaction1);
//
//    CustomerTransaction customerTransaction2 = new CustomerTransaction();
//    customerTransaction2.setBudget(14L);
//    customerTransaction2.setCustomerProduct(customerProduct);
//    customerTransaction2.setFinalInventory(444L);
//    customerTransaction2.setSalesAmount(555.0);
//    customerTransaction2.setStartMonth(2L);
//    customerTransaction2.setStartYear(2010L);
//    customerTransactionList.add(customerTransaction2);

//    customerProduct.setCustomerTransactions(customerTransactionList);

//    customerProductsList.add(customerProduct);

//    newUser.setCustomerProducts(customerProductsList);

    salesRep = new PogUser();
    salesRep.setUserId("salesRep1");
    salesRep.setFirstName("FirstName salesRep 1");
    salesRep.setLastName("LastName salesRep 1");
    salesRep.setLocale(locale);

    Collection<Role> roles = roleDao.lookupByExample("SALES_REP");
    salesRep.setRoles(roles);

    newArea1 = new Area();
    newArea1.setAreaCode("NA1");
    newArea1.setAreaName("New Area 1 from AT");
    areaDao.saveOrUpdate(newArea1);
    newArea2 = new Area();
    newArea2.setAreaCode("NA2");
    newArea2.setAreaName("New Area 2 from AT");
    areaDao.saveOrUpdate(newArea2);

    Collection<UserArea> userAreas1 = new ArrayList<UserArea>();
    userArea1 = new UserArea();
    userAreaPk = new UserAreaPk();
    userAreaPk.setCountryType(homeCountryType);
    userAreaPk.setPogUser(salesRep);
    userAreaPk.setArea(newArea1);
    userArea1.setPk(userAreaPk);
    userAreas1.add(userArea1);
    userArea1 = new UserArea();
    userAreaPk = new UserAreaPk();
    userAreaPk.setCountryType(associationCountryType);
    userAreaPk.setPogUser(salesRep);
    userAreaPk.setArea(newArea2);
    userArea1.setPk(userAreaPk);
    userAreas1.add(userArea1);

    salesRep.setUserAreas(userAreas1);
    pogUserDao.saveOrUpdate(salesRep);
    newUser.setSalesRep(salesRep);

    newUser = pogUserDao.saveOrUpdate(newUser);
  }

  @After
  public void tearDown() {
    pogUserDao.delete(newUser);
    pogUserDao.delete(salesRep);
    localeDao.delete(locale);
    areaDao.delete(newArea);
    areaDao.delete(newArea1);
    areaDao.delete(newArea2);
    productDao.delete(product1);
    baseUomDao.delete(baseUom);
  }

  @Test
  public void testFindByUserId_UserValid_UserFound() throws Exception {
    newUser.setInternal(true);
    PogUser pogUser = pogUserDao.findByUserId(newUser.getUserId());
    assertNotNull(pogUser);
    assertEquals("FirstName from AT", pogUser.getFirstName());
    assertEquals("123 Street", pogUser.getAddress1());
    assertEquals(0, pogUser.getLevel());
    assertEquals(0, pogUser.getDepth());

    assertEquals("French", pogUser.getLocale().getLanguage());
    assertEquals("fr", pogUser.getLocale().getLocale());
    assertEquals("fr_FR", pogUser.getLocale().getSapLocale());
  }

  @Test
  public void testFindBySapId_UserFound_ReturnsUser() throws Exception {
    PogUser pogUser = pogUserDao.findBySapId(newUser.getSapId());
    assertNotNull(pogUser);
    assertEquals("FirstName from AT", pogUser.getFirstName());
  }

  @Test
  public void testFindBySapId_UserNotFound_ReturnsNull() throws Exception {
    PogUser pogUser = pogUserDao.findBySapId("123");
    assertNotNull(pogUser);
  }

  @Test
  public void testFindByUserId_NoUserFound_ThrowsException() throws Exception {
    newUser.setInternal(true);
    try {
      pogUserDao.findByUserId("not found");
      fail("this should have failed");
    } catch (UserNotFoundException e) {
      assertEquals("No user found with userId: not found", e.getMessage());
    }
  }

  @Test
  public void testFindByUserId_MoreThan1UsersFound_ThrowsException() throws Exception {
    newUser.setInternal(true);

    PogUser newUser1 = new PogUser();
    newUser1.setUserId("testId1");
    newUser1.setFirstName("FirstName from AT");
    newUser1.setLastName("LastName from AT");

    pogUserDao.saveOrUpdate(newUser1);

    try {
      pogUserDao.findByUserId("testId1");
      fail("this should have failed");
    } catch (UserNotFoundException e) {
      assertEquals("More than one user found with userId: testId1", e.getMessage());
    } finally {
      pogUserDao.delete(newUser1);
    }
  }

  @Test
  public void testLookupAllLevel1DistributorsBySalesRepUserId_ReturnsDistributors() throws Exception {
    Collection<PogUser> distributors = pogUserDao.lookupAllLevel1DistributorsBySalesRepUserId("VVPRAS");
    assertTrue(distributors.size() >= 1);
  }

  @Test
  public void testLookupAllLevel1Distributors() throws Exception {
    Collection<PogUser> distributors = pogUserDao.lookupAllLevel1Distributors();
    assertTrue(distributors.size() >= 1);
  }

  @Test
  public void testLookupAllSalesReps() throws Exception {
    Collection<PogUser> distributors = pogUserDao.lookupAllSalesReps();
    assertTrue(distributors.size() >= 1);
  }

  @Test
  public void testLookupSalesRepsByArea_Home() throws Exception {
    Area area = new Area();
    area.setId(newArea1.getId());
    Collection<PogUser> salesReps = pogUserDao.lookupSalesRepsByAreaAndCountryType(area, "HOME");
    assertTrue(salesReps.size() == 1);
  }

  @Test
  public void testLookupSalesRepsByArea_Association() throws Exception {
    Area area = new Area();
    area.setId(newArea2.getId());
    Collection<PogUser> salesReps = pogUserDao.lookupSalesRepsByAreaAndCountryType(area, "ASSOCIATION");
    assertTrue(salesReps.size() == 1);
  }

  @Test
  public void testLookupAllDistributorsByArea_ListOfDistributorsReturned() throws Exception {
    Collection<Area> ids = new ArrayList<Area>();
    Area ex = new Area();
    ex.setId(newArea.getId());
    ids.add(ex);
    Collection<PogUser> distributorsByArea = pogUserDao
        .lookupAllLevel1DistributorsByAreaFilterAssociatedDistributors(ids);
    assertTrue(1 <= distributorsByArea.size());
  }

  @Test
  public void testLookupAllInternalUsers_DistributorReturned() throws Exception {
    PogUser user = pogUserDao.findByPrimaryKey(salesRep.getId());
    Collection<PogUser> users = pogUserDao.lookupAllInternalUsersForAssociatedAreas(user);
    assertTrue(users.size() >= 0);
  }

  @Test
  public void testLookupUserById_ExistingUser_ListReturnedContainsOneObject() throws Exception {
    PogUser user = new PogUser();
    user.setUserId(newUser.getUserId());
    String[] exclude = new String[3];
    exclude[0] = "internal";
    exclude[1] = "level";
    exclude[2] = "depth";
    Collection<PogUser> users = pogUserDao.findByExample(newUser, exclude);
    assertEquals(1, users.size());
    assertEquals("testId1", users.iterator().next().getUserId());
  }

  @Test
  public void testLookupUserById_UserDoesNotExist_ListIsEmpty() throws Exception {
    PogUser user = new PogUser();
    user.setUserId("ABCDE");
    String[] exclude = new String[3];
    exclude[0] = "internal";
    exclude[1] = "level";
    exclude[2] = "depth";
    Collection<PogUser> users = pogUserDao.findByExample(user, exclude);
    assertEquals(0, users.size());
  }

  @Test
  public void testLocales() {
    Collection<Locale> localeCollection = pogUserDao.lookupDistinctLocales();
    assertNotNull(localeCollection);
  }

  @Test
  public void testLookupAvailableLevel1DistributorsByCountryCode() {
    Collection<String> codes = new ArrayList<String>();
    codes.add("ES");
    Collection<PogUser> pogUsers = pogUserDao.lookupAvailableLevel1DistributorsByCountryCode(codes);
    assertNotNull(pogUsers);
  }

  @Test
  public void testLookupLevel1DistributorsWithNoHomeCountryInUserArea() {
    Collection<PogUser> pogUsers = pogUserDao.lookupLevel1DistributorsWithNoHomeCountryInUserArea();
    assertNotNull(pogUsers);
  }

  @Test
  public void testLookupLevel1DistributorsWithUpdatedHomeCountry() {
    Collection<PogUser> pogUsers = pogUserDao.lookupLevel1DistributorsWithUpdatedHomeCountry();
    assertNotNull(pogUsers);
  }

  @Test
  public void testLookupAdminsWithoutSalesRep() {
    Collection<CustomizedPOGUser> pogUsers = pogUserDao.lookupAdminsWithoutSalesRep();
    assertNotNull(pogUsers);
  }

  @Test
  public void testUpdateAdmins() {
     pogUserDao.updateAdmins();
  }

  @Test
  public void testLookupAllSalesRepsNotCapturedMonthlyData() {
    Collection<CustomizedPOGUser> pogUsers = pogUserDao.lookupAllSalesRepsNotCapturedMonthlyData(03,06);
    assertNotNull(pogUsers);
  }

}
