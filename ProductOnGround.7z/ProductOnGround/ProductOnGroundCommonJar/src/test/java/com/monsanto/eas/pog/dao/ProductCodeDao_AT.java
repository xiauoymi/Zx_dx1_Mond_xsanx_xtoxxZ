/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.Product;
import com.monsanto.eas.pog.model.hibernate.ProductCode;
import junit.framework.TestCase;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class ProductCodeDao_AT extends TestCase {
  @Autowired
  private ProductCodeDao productCodeDao = null;

  @Test
  public void testLookupProductsByAreaId() {
    Collection<ProductCode> productCodes = productCodeDao.lookupProductsByAreaId(2677L);
    assertNotNull(productCodes);
  }

  @Ignore
  public void testSaveOrUpdate() {
    Collection<ProductCode> all = productCodeDao.lookupProductsByAreaId(2687L);
    ProductCode productCode = all.iterator().next();

    productCode.getLanguageProducts().iterator().next().setCustomDescription("sonal");

    productCodeDao.saveOrUpdate(productCode);
    Collection<ProductCode> productCodes = productCodeDao.lookupProductsByAreaId(2687L);
    assertNotNull(productCodes);
  }

  @Test
  public void testLookupStagedProductsByAreaId() {
    Collection<Product> products = productCodeDao.lookupStagedProductsByAreaId(2677L);
    assertNotNull(products);
  }

}