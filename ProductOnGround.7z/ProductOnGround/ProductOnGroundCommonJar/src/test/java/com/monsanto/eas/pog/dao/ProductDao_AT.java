package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.UserAreaPk;
import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 25, 2011 Time: 1:15:47 PM To change this template use File |
 * Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class ProductDao_AT extends TestCase {
  @Autowired
  private ProductDao productDao = null;
  @Autowired
  private ProductCodeDao productCodeDao = null;
  @Autowired
  private BaseUnitOfMeasureDao baseUnitOfMeasureDao = null;
  @Autowired
  private PogUserDao pogUserDao = null;
  @Autowired
  private AreaDao areaDao = null;
  @Autowired
  private CountryTypeDao countryTypeDao = null;

  private ProductCode productCode1, productCode2, productCode3;
  private Product product1, product2, product3;
  private PogUser newUser, salesRep;
  private BaseUnitOfMeasure baseUom;
  private CountryType homeCountryType;
  private Area newArea;

  @Before
  public void setUp() throws Exception {
    baseUom = new BaseUnitOfMeasure();
    baseUom.setCode("ZZ");
    baseUom.setDescription("Liter");
    baseUnitOfMeasureDao.saveOrUpdate(baseUom);

    productCode1 = new ProductCode();
    productCode1.setCode("AA123-test");
    productCodeDao.saveOrUpdate(productCode1);
    product1 = new Product();
    product1.setCode("AA123");
    product1.setBaseUnitOfMeasure(baseUom);
    product1.setParentCode(null);
    product1.setBaseUomCode("ZZ");
    productDao.saveOrUpdate(product1);

    productCode2 = new ProductCode();
    productCode2.setCode("AA124-test");
    productCodeDao.saveOrUpdate(productCode2);
    product2 = new Product();
    product2.setCode("AA124");
    product2.setBaseUnitOfMeasure(baseUom);
    product2.setParentCode(null);
    product2.setBaseUomCode("ZZ");
    productDao.saveOrUpdate(product2);

    productCode3 = new ProductCode();
    productCode3.setCode("AA125-test");
    productCodeDao.saveOrUpdate(productCode3);
    product3 = new Product();
    product3.setCode("AA125");
    product3.setBaseUnitOfMeasure(baseUom);
    product3.setParentCode(null);
    product3.setBaseUomCode("ZZ");
    productDao.saveOrUpdate(product3);

    salesRep = new PogUser();
    salesRep.setUserId("testId2");
    salesRep.setFirstName("FirstName sales rep from AT");
    salesRep.setLastName("LastName sales rep from AT");
    pogUserDao.saveOrUpdate(salesRep);

    newUser = new PogUser();
    newUser.setUserId("testId1");
    newUser.setFirstName("FirstName from AT");
    newUser.setLastName("LastName from AT");

    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();
    CustomerProduct customerProduct = new CustomerProduct();
    customerProduct.setDistributor(newUser);
    customerProduct.setProduct(product1);
    customerProduct.setModDate(new Date());
    customerProduct.setModUser("Test AT");
    Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();
    CustomerTransaction ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(7L);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(8L);
    customerTransactions.add(ct);
    customerProduct.setCustomerTransactions(customerTransactions);
    customerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    customerProduct.setDistributor(newUser);
    customerProduct.setProduct(product2);
    customerProduct.setModDate(new Date());
    customerProduct.setModUser("Test AT");
    customerTransactions = new ArrayList<CustomerTransaction>();
    ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(7L);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(8L);
    customerTransactions.add(ct);
    customerProduct.setCustomerTransactions(customerTransactions);
    customerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    customerProduct.setDistributor(newUser);
    customerProduct.setProduct(product3);
    customerProduct.setModDate(new Date());
    customerProduct.setModUser("Test AT");
    customerProduct.setDeleted(true);
    customerTransactions = new ArrayList<CustomerTransaction>();
    ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(3L);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setCustomerProduct(customerProduct);
    ct.setYear(2010L);
    ct.setMonth(4L);
    customerTransactions.add(ct);
    customerProduct.setCustomerTransactions(customerTransactions);
    customerProducts.add(customerProduct);

    newUser.setCustomerProducts(customerProducts);

    newArea = new Area();
    newArea.setAreaCode("NA");
    newArea.setAreaName("New Area from AT");
    areaDao.saveOrUpdate(newArea);

    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    homeCountryType = countryTypeDao.lookupByType("HOME");

    UserArea userArea1 = new UserArea();
    UserAreaPk userAreaPk = new UserAreaPk();

    userAreaPk.setCountryType(homeCountryType);
    userAreaPk.setPogUser(newUser);
    userAreaPk.setArea(newArea);
    userArea1.setPk(userAreaPk);

    userAreas.add(userArea1);
    newUser.setUserAreas(userAreas);

    newUser = pogUserDao.saveOrUpdate(newUser);
  }

  @After
  public void tearDown() throws Exception {
    pogUserDao.delete(newUser);
    pogUserDao.delete(salesRep);
    areaDao.delete(newArea);
    productDao.delete(product1);
    productDao.delete(product2);
    productDao.delete(product3);
    baseUnitOfMeasureDao.delete(baseUom);
  }

  @Test
  public void testLookupByCodeAndBaseUom() {
    Product product = productDao.lookupByCodeBaseUomIdAndMaterialId("AA124234001FR25LIT", 51L, "000000000011898285");
    assertNotNull(product);
  }

  @Test
  public void testLookupBySalesRepUserId() {
    Collection<Product> products = productDao.lookupBySalesRepUserId("1857919");
    assertNotNull(products);
    //assertEquals(2, products.size());
  }

  @Test
  public void testLookupById() {
    Product product = productDao.findByPrimaryKey(2058594L);
    assertNotNull(product);
  }
}
