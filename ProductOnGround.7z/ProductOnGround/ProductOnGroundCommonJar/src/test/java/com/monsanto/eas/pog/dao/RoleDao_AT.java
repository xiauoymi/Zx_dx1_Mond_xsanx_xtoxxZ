package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.hibernate.Role;
import com.monsanto.eas.pog.util.PogConstants;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 27, 2010 Time: 9:27:13 AM To change this template use File |
 * Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class RoleDao_AT extends TestCase {
  @Autowired
  private RoleDao roleDao = null;

  private Role newRole;

  @Before
  public void setUp() throws Exception {
    newRole = new Role();
    newRole.setRoleName("New Role from AT");

    newRole = roleDao.saveOrUpdate(newRole);
  }

  @After
  public void tearDown() {
    roleDao.delete(newRole);
  }

  @Test
  public void testFindByPrimaryKey() {
    Role role = roleDao.findByPrimaryKey(newRole.getId());
    assertEquals("New Role from AT", role.getRoleName());
  }

  @Test
  public void testLookupAllRoles() {
    Collection<Role> roleList = roleDao.findAll();
    assertTrue(roleList.size() >= 1);
  }

  @Test
  public void testLookupRoleByExample_RoleReturned() throws Exception {
    Role role = new Role();
    role.setRoleName(PogConstants.SALES_REP);
    Collection<Role> roleList = roleDao.lookupByExample(PogConstants.SALES_REP);
    assertTrue(roleList.size() == 1);
  }

  @Test
  public void testLookupRoleByExample_RoleNotFound() throws Exception {
    Role role = new Role();
    role.setRoleName(PogConstants.SALES_REP);
    try {
      roleDao.lookupByExample("does not exists");
      fail("this should have failed");
    } catch (Exception e) {
      assertEquals("Role : does not exists not found", e.getMessage());
    }
  }
}
