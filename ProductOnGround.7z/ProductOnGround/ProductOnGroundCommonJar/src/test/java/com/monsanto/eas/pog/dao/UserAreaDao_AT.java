package com.monsanto.eas.pog.dao;

import com.monsanto.eas.pog.model.UserAreaPk;
import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 26, 2010 Time: 3:35:27 PM To change this template use File |
 * Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class UserAreaDao_AT extends TestCase {
  @Autowired
  private PogUserDao pogUserDao = null;
  @Autowired
  private UserAreaDao userAreaDao = null;
  @Autowired
  private LocaleDao localeDao = null;
  @Autowired
  private CountryTypeDao countryTypeDao = null;
  @Autowired
  private AreaDao areaDao = null;

  private PogUser newUser;
  private Locale locale;
  private CountryType homeCountryType;
  private Area newArea;

  @Before
  public void setUp() throws Exception {
    locale = new Locale();
    locale.setLanguage("French");
    locale.setLocale("fr");
    locale.setSapLocale("fr_FR");
    localeDao.saveOrUpdate(locale);

    newUser = new PogUser();
    newUser.setUserId("testId1");
    newUser.setFirstName("FirstName from AT");
    newUser.setLastName("LastName from AT");
    newUser.setLocale(locale);

    newArea = new Area();
    newArea.setAreaCode("NA");
    newArea.setAreaName("New Area from AT");
    areaDao.saveOrUpdate(newArea);

    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    homeCountryType = countryTypeDao.lookupByType("HOME");

    UserArea userArea1 = new UserArea();
    UserAreaPk userAreaPk = new UserAreaPk();

    userAreaPk.setCountryType(homeCountryType);
    userAreaPk.setPogUser(newUser);
    userAreaPk.setArea(newArea);
    userArea1.setPk(userAreaPk);

    userAreas.add(userArea1);
    newUser.setUserAreas(userAreas);

    newUser = pogUserDao.saveOrUpdate(newUser);
  }

  @After
  public void tearDown() {
    pogUserDao.delete(newUser);
    localeDao.delete(locale);
    areaDao.delete(newArea);
  }

  @Test
  public void testDeleteUserAreas() throws Exception {
    userAreaDao.deleteUserAreasForUser(newUser);
    assertEquals(0, newUser.getUserAreas().size());
  }

}
