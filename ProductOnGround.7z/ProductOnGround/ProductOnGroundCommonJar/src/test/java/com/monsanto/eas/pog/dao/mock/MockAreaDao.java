/*
 MockAreaDao was created on Jun 24, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.AreaDao;
import com.monsanto.eas.pog.model.hibernate.Area;
import org.hibernate.Criteria;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class MockAreaDao implements AreaDao {
  private Collection<Area> areas;
  private Area area;
  private String key;
  private boolean ascending;
  private Area areaToSave;

  public MockAreaDao(Area area, Collection<Area> allAreas) {
    this.area = area;
    this.areas = allAreas;
  }

  public Area findByPrimaryKey(Long aLong) {
    return area;
  }

  public Collection<Area> findAll() {
    return areas;
  }

  public Collection<Area> findAll(int startIndex, int fetchSize) {
    return null;
  }

  public Collection<Area> findByExample(Area exampleInstance, String[] excludeProperty) {
    return null;
  }

  public Collection<Area> findAll(String key, boolean ascending) {
    this.key = key;
    this.ascending = ascending;
    return areas;
  }

  public Area saveOrUpdate(Area entity) {
    this.areaToSave = entity;
    return null;
  }

  public Area merge(Area entity) {
    return null;
  }

  public void delete(Area entity) {
  }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
    return null;
  }

  public Criteria createCriteria(boolean isDeleted) {
    return null;
  }

  public Area lookupByCriteria(Area example) throws Exception {
    return area;
  }

  public String getKey() {
    return key;
  }

  public boolean isAscending() {
    return ascending;
  }

  public Area getAreaToSave() {
    return areaToSave;
  }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}