package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.BaseUnitOfMeasureDao;
import com.monsanto.eas.pog.model.hibernate.BaseUnitOfMeasure;
import org.hibernate.Criteria;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 6, 2010 Time: 3:07:16 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockBaseUnitOfMeasureDao implements BaseUnitOfMeasureDao {
  private Collection<BaseUnitOfMeasure> baseUoms;
  private BaseUnitOfMeasure baseUom;

  public MockBaseUnitOfMeasureDao(BaseUnitOfMeasure baseUom, Collection<BaseUnitOfMeasure> baseUoms
  ) {
    this.baseUoms = baseUoms;
    this.baseUom = baseUom;
  }

  public BaseUnitOfMeasure findByPrimaryKey(Long aLong) {
    return baseUom;
  }

  public Collection<BaseUnitOfMeasure> findAll() {
    return baseUoms;
  }

  public Collection<BaseUnitOfMeasure> findAll(int startIndex, int fetchSize) {
    return null;
  }

  public Collection<BaseUnitOfMeasure> findByExample(BaseUnitOfMeasure exampleInstance, String[] excludeProperty) {
    return null;
  }

  public Collection<BaseUnitOfMeasure> findAll(String key, boolean ascending) {
    return null;
  }

  public BaseUnitOfMeasure saveOrUpdate(BaseUnitOfMeasure entity) {
    return null;
  }

  public BaseUnitOfMeasure merge(BaseUnitOfMeasure entity) {
    return null;
  }

  public void delete(BaseUnitOfMeasure entity) {

  }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
    return null;
  }

  public Criteria createCriteria(boolean isDeleted) {
    return null;
  }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}
