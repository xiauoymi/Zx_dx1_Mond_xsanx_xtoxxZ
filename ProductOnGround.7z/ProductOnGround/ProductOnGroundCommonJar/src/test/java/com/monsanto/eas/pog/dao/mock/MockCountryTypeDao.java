package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.CountryTypeDao;
import com.monsanto.eas.pog.model.hibernate.CountryType;
import org.hibernate.Criteria;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 25, 2010 Time: 12:14:21 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockCountryTypeDao implements CountryTypeDao {
  private CountryType countryType;
  private Collection<CountryType> mockTypes;

  public MockCountryTypeDao(CountryType countryType, Collection<CountryType> mockTypes) {
    this.countryType = countryType;
    this.mockTypes = mockTypes;
  }

  public Criteria createCriteria(boolean isDeleted) {
    return null;
  }
 
  public CountryType findByPrimaryKey(Long aLong) {
    return countryType;  
  }

  public Collection<CountryType> findAll() {
    return mockTypes;  
  }

  public Collection<CountryType> findAll(int startIndex, int fetchSize) {
    return null;  
  }

  public Collection<CountryType> findByExample(CountryType exampleInstance, String[] excludeProperty) {
    return null;  
  }

  public Collection<CountryType> findAll(String key, boolean ascending) {
    return null;  
  }

  public CountryType saveOrUpdate(CountryType entity) {
    return null;  
  }

  public CountryType merge(CountryType entity) {
    return null;  
  }

  public void delete(CountryType entity) {
    
  }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
    return null;  
  }

  public CountryType lookupByType(String countryType) throws Exception {
    return this.countryType;
  }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}
