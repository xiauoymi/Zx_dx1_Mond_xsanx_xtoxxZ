package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.CustomerProductDao;
import com.monsanto.eas.pog.model.hibernate.CustomerProduct;
import com.monsanto.eas.pog.model.hibernate.Product;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 5, 2010 Time: 3:05:37 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockCustomerProductDao implements CustomerProductDao {
  private Collection<CustomerProduct> customerProducts;
  private CustomerProduct customerProduct;
  private Collection<String> products;

  public MockCustomerProductDao(CustomerProduct customerProduct, Collection<CustomerProduct> customerProducts,
                                Collection<String> products) {
    this.customerProducts = customerProducts;
    this.customerProduct = customerProduct;
    this.products = products;
  }

  public Collection<CustomerProduct> lookupByDistributorIdYearAndMonth(Long distributorId, Long year, Long month) {
    return customerProducts;
  }

  public CustomerProduct lookupInactiveByDistributorProductCodeAndBaseUomCode(Long distributorId, String productCode,
                                                                              String baseUomCode, String materialId) {
    if (customerProduct != null) {
      Product product = new Product();
      product.setCode(productCode);
      customerProduct.setProduct(product);
    }
    return customerProduct;
  }

  public Collection<String> lookupDistinctProductIdsByLevel(int productLevel) {
    if (productLevel < 3) {
      return new ArrayList<String>();
    }
    return products;
  }

  public CustomerProduct findByPrimaryKey(Long aLong) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Collection<CustomerProduct> findAll() {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Collection<CustomerProduct> findAll(int startIndex, int fetchSize) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Collection<CustomerProduct> findByExample(CustomerProduct exampleInstance, String[] excludeProperty) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Collection<CustomerProduct> findAll(String key, boolean ascending) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public CustomerProduct saveOrUpdate(CustomerProduct entity) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public CustomerProduct merge(CustomerProduct entity) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public void delete(CustomerProduct entity) {
    //To change body of implemented methods use File | Settings | File Templates.
  }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Criteria createCriteria(boolean isDeleted) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}
