package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.CustomerTransactionDao;
import com.monsanto.eas.pog.model.hibernate.CustomerTransaction;

import java.util.Calendar;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 5, 2010 Time: 4:02:56 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockCustomerTransactionDao implements CustomerTransactionDao {
  private CustomerTransaction customerTransaction;
  private Collection<CustomerTransaction> customerTransactions;
  private Collection<Long> distributorIds;
  private Long year;
  private Long month;
  private Long endYear;
  private Long endMonth;

  public MockCustomerTransactionDao(CustomerTransaction customerTransaction,
                                    Collection<CustomerTransaction> customerTransactions) {
    this.customerTransaction = customerTransaction;
    this.customerTransactions = customerTransactions;
  }

  public CustomerTransaction lookupByCustomerProductIdYearAndMonth(Long customerProductId, Long year, Long month) {
    if (customerTransaction == null || month == 4L) {
      return null;
    } else {
      customerTransaction.getCustomerProduct().setId(customerProductId);
      customerTransaction.setYear(year);
      customerTransaction.setMonth(month);
      return customerTransaction;
    }
  }

  public Collection<CustomerTransaction> lookupByDistributorIdYearAndMonthRange(Long distributorId, Long year,
                                                                                    Long month, Long endYear,
                                                                                    Long endMonth) {
    return customerTransactions;
  }

  public Collection<CustomerTransaction> lookupByParentDistributorIdYearAndMonthRange(Long parentDistributorId,
                                                                                      Long year, Long month,
                                                                                      Long endYear, Long endMonth) {
    this.distributorIds = distributorIds;
    this.year = year;
    this.month = month;
    this.endYear = endYear;
    this.endMonth = endMonth;
    return customerTransactions;
  }

  public Calendar getOldestTransactionDateByDistributorId(Long distributorId) throws Exception {
    if (distributorId == 11L) {
      Calendar calendar = Calendar.getInstance();
      calendar.add(Calendar.DATE, -2);
      return calendar;
    }
    return null;
  }

  public Calendar getLatestTransactionDateByDistributorId(Long distributorId) throws Exception {
    if (distributorId == 11L) {
      Calendar calendar = Calendar.getInstance();
      calendar.add(Calendar.DATE, +1);
      return calendar;
    }
    return null;
  }

  public Collection<CustomerTransaction> lookupByParentDistributorYearAndMonthRange(Collection<Long> distributorIds,
                                                                                    Long year, Long month, Long endYear,
                                                                                    Long endMonth) {
    this.distributorIds = distributorIds;
    this.year = year;
    this.month = month;
    this.endYear = endYear;
    this.endMonth = endMonth;
    return customerTransactions;
  }

  public Collection<Long> getDistributorIds() {
    return distributorIds;
  }

  public Long getYear() {
    return year;
  }

  public Long getMonth() {
    return month;
  }

  public Long getEndYear() {
    return endYear;
  }

  public Long getEndMonth() {
    return endMonth;
  }
}
