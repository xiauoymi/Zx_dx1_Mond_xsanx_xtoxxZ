package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.DistributorTypeDao;
import com.monsanto.eas.pog.model.hibernate.DistributorType;
import org.hibernate.Criteria;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: sspati1
 * Date: 2/28/11
 * Time: 1:42 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockDistributorTypeDao implements DistributorTypeDao {
    private DistributorType distributorType;
    private Collection<DistributorType> mockTypes;

    public MockDistributorTypeDao(DistributorType distributorType, Collection<DistributorType> mockTypes) {
        this.distributorType = distributorType;
        this.mockTypes = mockTypes;
    }

    public DistributorType findByPrimaryKey(Long aLong) {
        return distributorType;  
    }

    public Collection<DistributorType> findAll() {
        return mockTypes;
    }

    public Collection<DistributorType> findAll(int startIndex, int fetchSize) {
        return null;  
    }

    public Collection<DistributorType> findByExample(DistributorType exampleInstance, String[] excludeProperty) {
        return null;  
    }

    public Collection<DistributorType> findAll(String key, boolean ascending) {
        return null;  
    }

    public DistributorType saveOrUpdate(DistributorType entity) {
        return null;  
    }

    public DistributorType merge(DistributorType entity) {
        return null;  
    }

    public void delete(DistributorType entity) {
        
    }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
        return null;  
    }

    public Criteria createCriteria(boolean isDeleted) {
        return null;  
    }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}
