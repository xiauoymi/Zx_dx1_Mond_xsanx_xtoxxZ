package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.LocaleDao;
import com.monsanto.eas.pog.model.hibernate.Locale;
import org.hibernate.Criteria;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 25, 2010 Time: 11:47:38 AM To change this template use File |
 * Settings | File Templates.
 */
public class MockLocaleDao implements LocaleDao {
  private Locale locale;
  private Collection<Locale> mockLocales;
  private String key;
  private boolean ascending;
  private Locale exampleInstance;
  private String[] excludeProperty;

  public MockLocaleDao(Locale locale, Collection<Locale> mockLocales) {
    this.locale = locale;
    this.mockLocales = mockLocales;
  }

  public Locale findByPrimaryKey(Long aLong) {
    return locale;
  }

  public Criteria createCriteria(boolean isDeleted) {
    return null;
  }

  public Collection<Locale> findAll() {
    return mockLocales;
  }

  public Collection<Locale> findAll(int startIndex, int fetchSize) {
    return null;
  }

  public Collection<Locale> findByExample(Locale exampleInstance, String[] excludeProperty) {
    this.exampleInstance = exampleInstance;
    this.excludeProperty = excludeProperty;
    return mockLocales;
  }

  public Collection<Locale> findAll(String key, boolean ascending) {
    this.key = key;
    this.ascending = ascending;
    return mockLocales;
  }

  public Locale saveOrUpdate(Locale entity) {
    return null;
  }

  public Locale merge(Locale entity) {
    return null;
  }

  public void delete(Locale entity) {

  }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
    return null;
  }

  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public boolean isAscending() {
    return ascending;
  }

  public void setAscending(boolean ascending) {
    this.ascending = ascending;
  }

  public Locale getExampleInstance() {
    return exampleInstance;
  }

  public void setExampleInstance(Locale exampleInstance) {
    this.exampleInstance = exampleInstance;
  }

  public String[] getExcludeProperty() {
    return excludeProperty;
  }

  public void setExcludeProperty(String[] excludeProperty) {
    this.excludeProperty = excludeProperty;
  }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}
