package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.PogUserDao;
import com.monsanto.eas.pog.dao.exception.UserNotFoundException;
import com.monsanto.eas.pog.model.hibernate.Area;
import com.monsanto.eas.pog.model.hibernate.Locale;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.CustomizedPOGUser;
import org.hibernate.Criteria;

import java.util.Collection;
import java.util.List;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 18, 2010 Time: 6:01:22 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockPogUserDao implements PogUserDao {
  private PogUser mockUser;
  private List<PogUser> pogUsers;
  private String salesRepUserId;
  private PogUser mergePogUser;
  private Collection<Area> areaIds;
  private Collection<Locale> locales;

  public MockPogUserDao(PogUser mockUser, List<PogUser> pogUsers, Collection<Locale> locales) {
    this.mockUser = mockUser;
    this.pogUsers = pogUsers;
    this.locales = locales;
  }

  public PogUser findByPrimaryKey(Long aLong) {
    if (this.mockUser == null) {
      if (pogUsers == null) {
        return null;
      } else {
        for (PogUser user : pogUsers) {
          if (aLong.equals(user.getId())) {
            return user;
          }
        }
        return null;
      }
    } else {
      return this.mockUser;
    }
  }

  public List<PogUser> findAll() {
    return null;
  }

  public List<PogUser> findAll(int startIndex, int fetchSize) {
    return null;
  }

  public List<PogUser> findByExample(PogUser exampleInstance, String[] excludeProperty) {
    return this.pogUsers;
  }

  public PogUser saveOrUpdate(PogUser entity) {
    if (entity.getId() == null) {
      entity.setId(123L);
      entity.setUserId("newUserId");
      return entity;
    } else {
      this.mockUser.setModDate(entity.getModDate());
      this.mockUser.setCustomerProducts(entity.getCustomerProducts());
      return this.mockUser;
    }
  }

  public Collection<PogUser> lookupSalesRepsByAreaAndCountryType(Area area, String countryTypeName) {
    return null;
  }

  public void delete(PogUser entity) {
  }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
    return null;
  }

  public Criteria createCriteria(boolean isDeleted) {
    return null;
  }

  public List<PogUser> findAll(String key, boolean ascending) {
    return null;
  }

  public PogUser findByUserId(String userId) throws UserNotFoundException {
    if (this.mockUser == null) {
      throw new UserNotFoundException("User Not Found");
    }
    return this.mockUser;
  }

  public Collection<PogUser> lookupAllLevel1DistributorsBySalesRepUserId(String salesRepUserId) {
    this.salesRepUserId = salesRepUserId;
    return this.pogUsers;
  }

  public Collection<PogUser> lookupAllSalesReps() {
    return this.pogUsers;
  }

  public PogUser merge(PogUser entity) {
    mergePogUser = entity;
    return mergePogUser;
  }

  public Collection<PogUser> lookupAllInternalUsersForAssociatedAreas(PogUser user) {
    return pogUsers;
  }

  public Collection<PogUser> lookupAllLevel1DistributorsByAreaFilterAssociatedDistributors(Collection<Area> areaIds) {
    this.areaIds = areaIds;
    return pogUsers;
  }

  public Collection<PogUser> lookupSalesRepsByAreaAndCountryType(Collection<Area> areas, String countryTypeName) {
    return null;
  }

  public PogUser findBySapId(String sapId) throws UserNotFoundException {
    return null;
  }

  public Collection<PogUser> lookupAllLevel1Distributors() {
    return pogUsers;
  }

  public Collection<Locale> lookupDistinctLocales() {
    return locales;
  }

  public Collection<PogUser> lookupAvailableLevel1DistributorsByCountryCode(Collection<String> countryCodes) {
    return null;
  }

  public Collection<PogUser> lookupLevel1DistributorsWithNoHomeCountryInUserArea() {
    return null;
  }

  public Collection<PogUser> lookupLevel1DistributorsWithUpdatedHomeCountry() {
    return null;
  }

    public Collection<CustomizedPOGUser> lookupAdminsWithoutSalesRep() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void updateAdmins() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Collection<CustomizedPOGUser> lookupAllSalesRepsNotCapturedMonthlyData(int month, int year) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getSalesRepUserId() {
    return salesRepUserId;
  }

  public PogUser getMergePogUser() {
    return mergePogUser;
  }

  public Collection<Area> getAreaIds() {
    return areaIds;
  }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}
