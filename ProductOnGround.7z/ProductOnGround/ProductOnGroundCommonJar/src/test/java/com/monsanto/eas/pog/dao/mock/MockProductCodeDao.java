/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.ProductCodeDao;
import com.monsanto.eas.pog.model.hibernate.Product;
import com.monsanto.eas.pog.model.hibernate.ProductCode;
import org.hibernate.Criteria;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class MockProductCodeDao implements ProductCodeDao{
  private Collection<ProductCode> productCodes;

  public MockProductCodeDao(Collection<ProductCode> productCodes) {
    this.productCodes = productCodes;
  }

  public Collection<ProductCode> lookupProductsByAreaId(Long areaId) {
    return productCodes;
  }

    public Collection<Product> lookupStagedProductsByAreaId(Long areaId) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public ProductCode findByPrimaryKey(Long aLong) {
    return null;
  }

  public Collection<ProductCode> findAll() {
    return productCodes;
  }

  public Collection<ProductCode> findAll(int startIndex, int fetchSize) {
    return null;
  }

  public Collection<ProductCode> findByExample(ProductCode exampleInstance, String[] excludeProperty) {
    return null;
  }

  public Collection<ProductCode> findAll(String key, boolean ascending) {
    return null;
  }

  public ProductCode saveOrUpdate(ProductCode entity) {
    return null;
  }

  public ProductCode merge(ProductCode entity) {
    return null;
  }

  public void delete(ProductCode entity) {
  }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
    return null;
  }

  public Criteria createCriteria(boolean isDeleted) {
    return null;
  }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}