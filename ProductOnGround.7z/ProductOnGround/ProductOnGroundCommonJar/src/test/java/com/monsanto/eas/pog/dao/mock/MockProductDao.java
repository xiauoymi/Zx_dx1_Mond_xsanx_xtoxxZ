package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.ProductDao;
import com.monsanto.eas.pog.model.hibernate.Product;
import com.monsanto.eas.pog.model.hibernate.ProductCode;
import org.hibernate.Criteria;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 27, 2011 Time: 2:40:02 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockProductDao implements ProductDao {
  private Product mockProduct;
  private Collection<Product> products = new ArrayList<Product>();
  private String key;
  private boolean ascending;
  private String salesRepUserId;

  public MockProductDao(Product mockProduct, Collection<Product> products) {
    this.mockProduct = mockProduct;
    this.products = products;
  }

  public Product lookupByCodeBaseUomIdAndMaterialId(String productCode, Long baseUomId, String materialId) {
    return mockProduct;
  }

  public Collection<Product> lookupBySalesRepUserId(String salesRepUserId) {
    this.salesRepUserId = salesRepUserId;
    return products;
  }

  public Product findByPrimaryKey(Long aLong) {
    return this.mockProduct;
  }

  public Collection<Product> findAll() {
    return products;
  }

  public Collection<Product> findAll(int startIndex, int fetchSize) {
    return null;
  }

  public Collection<Product> findByExample(Product exampleInstance, String[] excludeProperty) {
    return null;
  }

  public Collection<Product> findAll(String key, boolean ascending) {
    this.key = key;
    this.ascending = ascending;
    return products;
  }

  public Product saveOrUpdate(Product entity) {
    return entity;
  }

  public Product merge(Product entity) {
    return null;
  }

  public void delete(Product entity) {

  }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
    return null;
  }

  public Criteria createCriteria(boolean isDeleted) {
    return null;
  }

  public String getKey() {
    return key;
  }

  public boolean isAscending() {
    return ascending;
  }

  public String getSalesRepUserId() {
    return salesRepUserId;
  }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}
