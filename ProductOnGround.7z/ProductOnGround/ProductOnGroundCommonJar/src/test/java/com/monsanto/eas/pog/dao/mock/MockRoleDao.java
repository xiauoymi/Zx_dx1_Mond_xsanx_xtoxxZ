package com.monsanto.eas.pog.dao.mock;

import com.monsanto.eas.pog.dao.RoleDao;
import com.monsanto.eas.pog.model.hibernate.Role;
import org.hibernate.Criteria;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 27, 2010 Time: 9:42:43 AM To change this template use File |
 * Settings | File Templates.
 */
public class MockRoleDao implements RoleDao {
  private Role role;
  private Collection<Role> roles;

  public MockRoleDao(Role role, Collection<Role> mockRoles) {
    this.role = role;
    this.roles = mockRoles;
  }

  public Role findByPrimaryKey(Long aLong) {
    return role;
  }

  public Criteria createCriteria(boolean isDeleted) {
    return null;
  }

  public Collection<Role> findAll() {
    return roles;
  }

  public Collection<Role> findAll(int startIndex, int fetchSize) {
    return roles;
  }

  public Collection<Role> findByExample(Role exampleInstance, String[] excludeProperty) {
    return roles;
  }

  public Collection<Role> findAll(String key, boolean ascending) {
    return roles;
  }

  public Role saveOrUpdate(Role entity) {
    return role;
  }

  public void delete(Role entity) {

  }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
    return null;
  }

  public Role merge(Role entity) {
    return null;  //To change body of implemented methods use File | Settings | File Templates.
  }

  public Collection<Role> lookupByExample(String roleName) throws Exception {
    return null;
  }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}
