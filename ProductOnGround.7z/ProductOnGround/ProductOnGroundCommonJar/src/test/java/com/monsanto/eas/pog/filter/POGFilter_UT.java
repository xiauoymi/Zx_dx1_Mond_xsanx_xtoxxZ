package com.monsanto.eas.pog.filter;

import com.monsanto.eas.pog.dao.PogUserDao;
import com.monsanto.eas.pog.dao.mock.MockPogUserDao;
import com.monsanto.eas.pog.model.hibernate.Locale;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.util.PogConstants;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;

import javax.servlet.http.HttpSession;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 5, 2010 Time: 6:21:32 PM To change this template use File |
 * Settings | File Templates.
 */
public class POGFilter_UT extends TestCase {

  @Test
  public void testFilter_UserIdIsNotNull() throws Exception {
    System.setProperty("lsi.function", "win");
    PogUser pogUser = new PogUser();
    pogUser.setId(1234L);
    Locale locale = new Locale();
    locale.setLocale("es");
    pogUser.setLocale(locale);
    PogUserDao pogUserDao = new MockPogUserDao(pogUser, null, null);
    POGFilter filter = new POGFilter(pogUserDao);
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpSession httpSession = new MockHttpSession();
    httpSession.setMaxInactiveInterval(12);
    request.setSession(httpSession);
    MockHttpServletResponse response = new MockHttpServletResponse();
    filter.doFilter(request, response, new MockFilterChain());

    HttpSession session = request.getSession();
    assertEquals("SSPATI1", session.getAttribute(PogConstants.WAM_USER_ID));
    PogUser wamPogUser = (PogUser) session.getAttribute(PogConstants.WAM_POG_USER);
    assertEquals(1234L, wamPogUser.getId().longValue());
    assertEquals("es", session.getAttribute(SessionLocaleResolver.LOCALE_SESSION_ATTRIBUTE_NAME).toString());

    String str = (String) response.getHeader("Refresh");
    assertEquals("12; URL=/servlet/sessiontimeout", str);
  }
}
