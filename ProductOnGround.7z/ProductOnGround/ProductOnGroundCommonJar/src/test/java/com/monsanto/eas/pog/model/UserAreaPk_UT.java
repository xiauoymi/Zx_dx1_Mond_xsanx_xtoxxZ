package com.monsanto.eas.pog.model;

import com.monsanto.eas.pog.model.hibernate.Area;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import junit.framework.TestCase;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 14, 2010 Time: 12:24:07 PM To change this template use File |
 * Settings | File Templates.
 */
public class UserAreaPk_UT extends TestCase {

  @Test
  public void testUserAreaPK() {
    UserAreaPk pk1 = new UserAreaPk();
    UserAreaPk pk2 = new UserAreaPk();

    assertTrue(pk1.equals(pk1));
    assertFalse(pk1.equals(pk2));
    assertFalse(pk1.equals(new PogUser()));
    Area area1 = new Area();
    pk1.setArea(area1);
    area1.setId(11L);
    assertFalse(pk1.equals(pk2));
    Area area2 = new Area();
    area2.setId(11L);
    pk2.setArea(area2);
    assertFalse(pk1.equals(pk2));
    area2.setId(12L);
    assertFalse(pk1.equals(pk2));
  }
}
