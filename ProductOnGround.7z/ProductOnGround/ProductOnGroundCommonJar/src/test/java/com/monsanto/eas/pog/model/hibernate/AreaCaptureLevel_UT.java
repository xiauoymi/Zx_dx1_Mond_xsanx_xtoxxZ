package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 19, 2010 Time: 8:32:46 AM To change this template use File |
 * Settings | File Templates.
 */
public class AreaCaptureLevel_UT extends TestCase {

  @Test
  public void testEquals_IdsAreEqual_ReturnsTrue() throws Exception {
    AreaCaptureLevel obj1 = new AreaCaptureLevel();
    obj1.setId(11L);
    assertEquals(11L, obj1.getId().longValue());
    AreaCaptureLevel obj2 = new AreaCaptureLevel();
    obj2.setId(11L);
    assertTrue(obj1.equals(obj2));
    assertNotNull(obj1.hashCode());
  }

  @Test
  public void testEquals_IdsAreNotEqual_ReturnsFalse() throws Exception {
    AreaCaptureLevel obj1 = new AreaCaptureLevel();
    obj1.setId(11L);
    AreaCaptureLevel obj2 = new AreaCaptureLevel();
    obj2.setId(12L);
    assertFalse(obj1.equals(obj2));
  }

  @Test
  public void testGetters() {
    AreaCaptureLevel cl = new AreaCaptureLevel();
    cl.setModUser("user");
    Date date = Calendar.getInstance().getTime();
    cl.setModDate(date);
    assertEquals("user", cl.getModUser());
    assertTrue(date.equals(cl.getModDate()));
    Area area = new Area();
    area.setId(11L);
    cl.setArea(area);
    assertTrue(area.equals(cl.getArea()));
  }
}
