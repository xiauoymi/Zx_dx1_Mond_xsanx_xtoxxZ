package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 19, 2010 Time: 8:28:59 AM To change this template use File |
 * Settings | File Templates.
 */
public class Area_UT extends TestCase {

  @Test
  public void testEquals_IdsAreEqual_ReturnsTrue() throws Exception {
    Area area1 = new Area();
    area1.setId(11L);
    Area area2 = new Area();
    area2.setId(11L);
    assertTrue(area1.equals(area2));
    assertNotNull(area1.hashCode());
  }

  @Test
  public void testEquals_IdsAreNotEqual_ReturnsFalse() throws Exception {
    Area area1 = new Area();
    area1.setId(11L);
    Area area2 = new Area();
    area2.setId(12L);
    assertFalse(area1.equals(area2));
  }

  @Test
  public void testGetters() {
    Area area = new Area();
    area.setModUser("user");
    Date date = Calendar.getInstance().getTime();
    area.setModDate(date);
    area.setOverridenActiveYear(3);
    area.setOverridenActiveMonth(2009);
    area.setOffline(true);
    area.setOnline(true);
    area.setSalesInUnit(true);
    Area parent = new Area();
    parent.setId(123L);
    area.setParentArea(parent);
    ArrayList<Area> childAreas = new ArrayList<Area>();
    Area child1 = new Area();
    child1.setId(13L);
    childAreas.add(child1);
    area.setChildAreas(childAreas);
    assertEquals("user", area.getModUser());
    assertTrue(date.equals(area.getModDate()));
    assertEquals(3, area.getOverridenActiveYear());
    assertEquals(2009, area.getOverridenActiveMonth());
    Calendar today = Calendar.getInstance();
    area.setOverridenActiveMonth(5);
    assertEquals(5, area.getOverridenActiveMonth());
    area.setOverridenActiveYear(2010);
    assertEquals(2010, area.getOverridenActiveYear());
    assertTrue(parent.equals(area.getParentArea()));
    assertEquals(1, area.getChildAreas().size());
    assertTrue(child1.equals(area.getChildAreas().iterator().next()));

    assertTrue(area.isOffline());
    assertTrue(area.isOnline());
    assertTrue(area.isSalesInUnit());

    assertEquals(0, area.getMonthendFrom());
    assertEquals(0, area.getMonthendTo());

    area.setMonthendFrom(3);
    Calendar instance = Calendar.getInstance();
    instance.add(Calendar.DATE, -4);
    Date currentMonthEndDate = instance.getTime();
    area.setMonthendTo(5);

    assertEquals(3, area.getMonthendFrom());
    assertEquals(5, area.getMonthendTo());
  }
}
