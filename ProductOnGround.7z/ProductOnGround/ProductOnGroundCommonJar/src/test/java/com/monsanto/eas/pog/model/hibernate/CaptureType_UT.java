package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 14, 2010 Time: 12:56:35 PM To change this template use File |
 * Settings | File Templates.
 */
public class CaptureType_UT extends TestCase {

  @Test
  public void testEquals_IdsAreEqual_ReturnsTrue() throws Exception {
    CaptureType type1 = new CaptureType();
    type1.setId(11L);
    CaptureType type2 = new CaptureType();
    type2.setId(11L);
    assertTrue(type1.equals(type2));
  }

  @Test
  public void testGetters() {
    CaptureType type = new CaptureType();
    type.setModUser("user");
    Date date = Calendar.getInstance().getTime();
    type.setModDate(date);
    assertEquals("user", type.getModUser());
    assertTrue(date.equals(type.getModDate()));
  }
}
