/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class Contact_UT extends TestCase {

  @Test
  public void testGetters() {
    Contact contact = new Contact();
    contact.setId(12L);
    contact.setName("TEST NAME");
    contact.setEmail("t@test.com");
    contact.setPhone("1245");

    assertEquals(12L, contact.getId().longValue());
    assertEquals("TEST NAME", contact.getName());
    assertEquals("t@test.com", contact.getEmail());
    assertEquals("1245", contact.getPhone());
  }

  @Test
  public void testEquals() {
    Contact contact1 = new Contact();
    contact1.setId(12L);
    Contact contact2 = new Contact();
    contact2.setId(12L);

    assertTrue(contact1.equals(contact2));

    contact2.setId(11L);
    assertFalse(contact1.equals(contact2));
  }
}