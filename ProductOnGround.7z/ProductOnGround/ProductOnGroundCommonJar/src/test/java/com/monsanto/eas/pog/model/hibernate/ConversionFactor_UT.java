package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: 3/2/11 Time: 1:40 PM To change this template use File | Settings | File
 * Templates.
 */
public class ConversionFactor_UT extends TestCase {

  @Test
  public void testGetters() {
    ConversionFactor factor = new ConversionFactor();
    ConversionFactorPK pk = new ConversionFactorPK();
    factor.setPk(pk);
    factor.setNumerator(23L);
    factor.setDenominator(24L);
    factor.setToBaseUomCode("GAL");
    BaseUnitOfMeasure toBaseUom = new BaseUnitOfMeasure();
    toBaseUom.setId(13L);
    pk.setBaseUnitOfMeasure(toBaseUom);
    Product product = new Product();
    product.setId(14L);
    pk.setProduct(product);
    factor.setModUser("testId");
    Date date = Calendar.getInstance().getTime();
    factor.setModDate(date);

    assertEquals(23, factor.getNumerator().longValue());
    assertEquals(24, factor.getDenominator().longValue());
    assertTrue(toBaseUom.equals(factor.getPk().getBaseUnitOfMeasure()));
    assertTrue(product.equals(factor.getPk().getProduct()));
    assertTrue(date.equals(factor.getModDate()));
    assertEquals("GAL", factor.getToBaseUomCode());
  }
}
