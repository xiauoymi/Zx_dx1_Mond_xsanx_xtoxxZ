package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 14, 2010 Time: 12:49:46 PM To change this template use File |
 * Settings | File Templates.
 */
public class CountryType_UT extends TestCase {

  @Test
  public void testEquals_IdsAreEqual_ReturnsTrue() throws Exception {
    CountryType baseUom1 = new CountryType();
    baseUom1.setId(11L);
    CountryType baseUom2 = new CountryType();
    baseUom2.setId(11L);
    assertTrue(baseUom1.equals(baseUom2));
  }

  @Test
  public void testGetters() {
    CountryType baseUom = new CountryType();
    baseUom.setModUser("user");
    Date date = Calendar.getInstance().getTime();
    baseUom.setModDate(date);
    assertEquals("user", baseUom.getModUser());
    assertTrue(date.equals(baseUom.getModDate()));
  }
}
