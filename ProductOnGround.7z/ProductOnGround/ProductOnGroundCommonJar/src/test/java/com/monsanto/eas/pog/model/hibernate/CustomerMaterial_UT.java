package com.monsanto.eas.pog.model.hibernate;


import junit.framework.TestCase;
import org.junit.Test;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class CustomerMaterial_UT extends TestCase {
  @Test
  public void testGetters() {
    CustomerMaterial customerMaterial = new CustomerMaterial();
    customerMaterial.setId(12L);
    PogUser pogUser = new PogUser();
    pogUser.setId(11L);
    customerMaterial.setPogUser(pogUser);
    Product product = new Product();
    product.setId(13L);
    customerMaterial.setProduct(product);

    assertEquals(12L, customerMaterial.getId().longValue());
    assertEquals(11L, customerMaterial.getPogUser().getId().longValue());
    assertEquals(13L, customerMaterial.getProduct().getId().longValue());
  }

  @Test
  public void testEquals() {
    CustomerMaterial customerMaterial = new CustomerMaterial();
    customerMaterial.setId(12L);
    PogUser pogUser = new PogUser();
    pogUser.setId(11L);
    customerMaterial.setPogUser(pogUser);
    Product product = new Product();
    product.setId(13L);
    customerMaterial.setProduct(product);

    CustomerMaterial customerMaterial2 = new CustomerMaterial();
    customerMaterial2.setId(12L);
    PogUser pogUser2 = new PogUser();
    pogUser2.setId(11L);
    customerMaterial2.setPogUser(pogUser2);
    Product product2 = new Product();
    product2.setId(13L);
    customerMaterial2.setProduct(product2);

    assertTrue(customerMaterial.equals(customerMaterial2));

    customerMaterial2.setId(14L);

    assertFalse(customerMaterial.equals(customerMaterial2));
  }
}
