package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 6, 2010 Time: 12:45:44 PM To change this template use File |
 * Settings | File Templates.
 */
public class CustomerProduct_UT extends TestCase {

  @Test
  public void testCompareTo_ReturnsLessThan0() throws Exception {
    CustomerProduct cp1 = new CustomerProduct();
    Product product1 = new Product();
    ProductCode productCode1 = new ProductCode();
    product1.setProductCode(productCode1);
    productCode1.setCode("Prod 1");
    cp1.setProduct(product1);
    CustomerProduct cp2 = new CustomerProduct();
    Product product2 = new Product();
    product2.setCode("Prod 2");
    ProductCode productCode2 = new ProductCode();
    productCode2.setCode("Prod 2");
    product2.setProductCode(productCode2);
    cp2.setProduct(product2);
    assertTrue(cp1.compareTo(cp2) < 0);
  }

  @Test
  public void testCompareTo_Returns0() throws Exception {
    CustomerProduct cp1 = new CustomerProduct();
    CustomerProduct cp2 = new CustomerProduct();
    assertTrue(cp1.compareTo(cp2) == 0);
  }

  @Test
  public void testCompareTo_ReturnsMoreThan0() throws Exception {
    CustomerProduct cp1 = new CustomerProduct();
    Product product1 = new Product();
    ProductCode productCode1 = new ProductCode();
    product1.setProductCode(productCode1);
    productCode1.setCode("Prod 2");
    cp1.setProduct(product1);
    CustomerProduct cp2 = new CustomerProduct();
    Product product2 = new Product();
    ProductCode productCode2 = new ProductCode();
    productCode2.setCode("Prod 1");
    product2.setProductCode(productCode2);
    cp2.setProduct(product2);
    assertTrue(cp1.compareTo(cp2) > 0);
  }

  @Test
  public void testCompareTo() throws Exception {
    CustomerProduct cp1 = new CustomerProduct();
    CustomerProduct cp2 = new CustomerProduct();
    assertEquals(0, cp1.compareTo(cp2));

    Product prod1 = new Product();
    ProductCode productCode1 = new ProductCode();
    prod1.setProductCode(productCode1);
    productCode1.setCode("AA1234");
    cp1.setProduct(prod1);

    Product prod2 = new Product();
    ProductCode productCode2 = new ProductCode();
    prod2.setProductCode(productCode2);
    productCode2.setCode("AA1234");
    cp2.setProduct(prod2);

    assertEquals(0, cp1.compareTo(cp2));
  }

  @Test
  public void testEquals() throws Exception {
    CustomerProduct cp1 = new CustomerProduct();
    cp1.setId(11L);
    CustomerProduct cp2 = new CustomerProduct();
    cp2.setId(11L);
    assertTrue(cp1.equals(cp2));
  }

  @Test
  public void testGetters() throws Exception {
    CustomerProduct cp1 = new CustomerProduct();
    cp1.setId(11L);
    PogUser distributor = new PogUser();
    distributor.setId(2L);
    cp1.setDistributor(distributor);
    assertEquals(distributor, cp1.getDistributor());
  }
}