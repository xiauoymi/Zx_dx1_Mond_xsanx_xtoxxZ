package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 14, 2010 Time: 12:41:55 PM To change this template use File |
 * Settings | File Templates.
 */
public class CustomerTransaction_UT extends TestCase {

  @Test
  public void testEquals() {
    CustomerTransaction ct1 = new CustomerTransaction();
    ct1.setId(11L);
    assertEquals(11L, ct1.getId().longValue());
    CustomerTransaction ct2 = new CustomerTransaction();
    ct2.setId(11L);
    assertTrue(ct1.equals(ct2));
  }
  
  @Test
  public void testGetters(){
    CustomerTransaction ct1 = new CustomerTransaction();
    Date date = Calendar.getInstance().getTime();
    ct1.setSapModDate(date);
    assertTrue(date.equals(ct1.getSapModDate()));
  }
}
