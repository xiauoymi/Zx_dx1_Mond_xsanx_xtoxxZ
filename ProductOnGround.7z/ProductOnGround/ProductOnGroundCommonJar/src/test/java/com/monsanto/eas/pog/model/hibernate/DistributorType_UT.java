package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: sspati1
 * Date: 2/28/11
 * Time: 1:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class DistributorType_UT extends TestCase {

    @Test
    public void testGetters() {
        DistributorType type = new DistributorType();
        type.setId(1L);
        type.setType("Type 1");
        assertEquals(1L, type.getId().longValue());
        assertEquals("Type 1", type.getType());
    }

    @Test
    public void testEquals() {
        DistributorType type1 = new DistributorType();
        type1.setId(1L);
        type1.setType("Type 1");
        DistributorType type2 = new DistributorType();
        type2.setId(1L);
        type2.setType("Type 2");
        assertTrue(type1.equals(type2));
        type2.setId(2L);
        assertFalse(type1.equals(type2));
    }
}
