/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class LanguageProduct_UT extends TestCase {

  @Test
  public void testGetters() {
    LanguageProduct languageProduct1 = new LanguageProduct();
    languageProduct1.setDescription("TEST PROD");
    languageProduct1.setCustomDescription("TEST CUSTOM PROD");
    LanguageProductPK pk = new LanguageProductPK();
    Language language = new Language();
    language.setId(11L);
    pk.setLanguage(language);
    ProductCode productCode = new ProductCode();
    productCode.setId(12L);
    pk.setProductCode(productCode);
    languageProduct1.setPk(pk);

    assertEquals("TEST PROD", languageProduct1.getDescription());
    assertEquals("TEST CUSTOM PROD", languageProduct1.getCustomDescription());
    assertEquals(11L, languageProduct1.getPk().getLanguage().getId().longValue());
    assertEquals(12L, languageProduct1.getPk().getProductCode().getId().longValue());
  }

  @Test
  public void testEquals() {
    LanguageProduct languageProduct1 = new LanguageProduct();
    languageProduct1.setDescription("TEST PROD");
    languageProduct1.setCustomDescription("TEST CUSTOM PROD");
    LanguageProductPK pk1 = new LanguageProductPK();
    Language language1 = new Language();
    language1.setId(11L);
    pk1.setLanguage(language1);
    ProductCode productCode1 = new ProductCode();
    productCode1.setId(12L);
    pk1.setProductCode(productCode1);
    languageProduct1.setPk(pk1);

    LanguageProduct languageProduct2 = new LanguageProduct();
    languageProduct2.setDescription("TEST PROD");
    languageProduct2.setCustomDescription("TEST CUSTOM PROD");
    LanguageProductPK pk2 = new LanguageProductPK();
    Language language2 = new Language();
    language2.setId(11L);
    pk2.setLanguage(language2);
    ProductCode productCode2 = new ProductCode();
    productCode2.setId(12L);
    pk2.setProductCode(productCode2);
    languageProduct2.setPk(pk2);

    assertTrue(languageProduct1.equals(languageProduct2));

    language2.setId(13L);
    assertFalse(languageProduct1.equals(languageProduct2));
  }
}