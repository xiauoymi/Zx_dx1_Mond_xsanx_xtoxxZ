/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class Language_UT extends TestCase {
  @Test
  public void testGetters() {
    Language language1 = new Language();
    language1.setId(11L);
    language1.setCode("EN");
    language1.setText("English");
    assertEquals(11L, language1.getId().longValue());
    assertEquals("EN", language1.getCode());
    assertEquals("English", language1.getText());
  }

  @Test
  public void testEquals() {
    Language language1 = new Language();
    language1.setId(11L);
    Language language2 = new Language();
    language2.setId(11L);
    assertTrue(language1.equals(language2));
    language2.setId(12L);
    assertFalse(language1.equals(language2));
  }
}