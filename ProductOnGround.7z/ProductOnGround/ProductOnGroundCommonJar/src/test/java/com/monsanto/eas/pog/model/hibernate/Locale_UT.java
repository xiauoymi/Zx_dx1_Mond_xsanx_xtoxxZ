package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 14, 2010 Time: 12:47:30 PM To change this template use File |
 * Settings | File Templates.
 */
public class Locale_UT extends TestCase {

  @Test
  public void testEquals_IdsAreEqual_ReturnsTrue() throws Exception {
    Locale baseUom1 = new Locale();
    baseUom1.setId(11L);
    Locale baseUom2 = new Locale();
    baseUom2.setId(11L);
    assertTrue(baseUom1.equals(baseUom2));
  }

  @Test
  public void testGetters() {
    Locale baseUom = new Locale();
    baseUom.setModUser("user");
    Date date = Calendar.getInstance().getTime();
    baseUom.setModDate(date);
    assertEquals("user", baseUom.getModUser());
    assertTrue(date.equals(baseUom.getModDate()));
  }
}
