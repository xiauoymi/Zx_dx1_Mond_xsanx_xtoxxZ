package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.model.UserAreaPk;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 19, 2010 Time: 8:32:19 AM To change this template use File |
 * Settings | File Templates.
 */
public class PogUser_UT extends TestCase {

  @Test
  public void testGetFullName() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setFirstName("FIRST");
    obj1.setLastName("LAST");
    assertEquals("FIRST LAST", obj1.getFullName());
    obj1.setMiddleName("A");
    assertEquals("FIRST A LAST", obj1.getFullName());
  }

  @Test
  public void testEquals_FirstAndLastNamesAreEqual_ReturnsTrue() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setId(12L);
    obj1.setFirstName("FIRST");
    obj1.setLastName("LAST");
    PogUser obj2 = new PogUser();
    obj2.setId(12L);
    obj2.setFirstName("first");
    obj2.setLastName("last");
    assertTrue(obj1.equals(obj2));
    assertNotNull(obj1.hashCode());
  }

  @Test
  public void testEquals_FirstAndLastNamesAreNotEqual_ReturnsFalse() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setId(12L);
    obj1.setFirstName("FIRST1");
    obj1.setLastName("LAST2");
    PogUser obj2 = new PogUser();
    obj2.setId(13L);
    obj2.setFirstName("first");
    obj2.setLastName("last");
    assertFalse(obj1.equals(obj2));
  }

  @Test
  public void testEquals_LastNameIsNull_ReturnsFalse() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setId(11L);
    obj1.setFirstName("FIRST1");
    PogUser obj2 = new PogUser();
    obj2.setId(12L);
    obj2.setFirstName("first");
    obj2.setLastName("last");
    assertFalse(obj1.equals(obj2));
  }

  @Test
  public void testCompareTo_ReturnLessThan0() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setFirstName("FIRST1");
    PogUser obj2 = new PogUser();
    obj2.setFirstName("first");
    assertTrue(obj1.compareTo(obj2) < 0);
  }

  @Test
  public void testCompareTo_Return0() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setFirstName("FIRST1");
    PogUser obj2 = new PogUser();
    obj2.setFirstName("FIRST1");
    assertTrue(obj1.compareTo(obj2) == 0);
  }

  @Test
  public void testCompareTo_ReturnMoreThan0() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setFirstName("first 14");
    PogUser obj2 = new PogUser();
    obj2.setFirstName("first 13");
    assertTrue(obj1.compareTo(obj2) > 0);
  }

  @Test
  public void testGetLevel_InternalUser_Returns0() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setInternal(true);
    assertEquals(0, obj1.getLevel());
  }

  @Test
  public void testGetLevel_NotInternalUser_Returns1() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setInternal(false);
    assertEquals(1, obj1.getLevel());
  }

  @Test
  public void testGetLevel_NotInternalUser_Returns2() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setInternal(false);
    PogUser parent = new PogUser();
    obj1.setParentUser(parent);
    assertEquals(2, obj1.getLevel());
  }

  @Test
  public void testGetLevel_NotInternalUser_Returns3() throws Exception {
    PogUser obj1 = new PogUser();
    obj1.setInternal(false);
    PogUser parent = new PogUser();
    PogUser grandParent = new PogUser();
    parent.setParentUser(grandParent);
    obj1.setParentUser(parent);
    assertEquals(3, obj1.getLevel());                                             
  }

  @Test
  public void testIsSalesRep_ReturnsTrue() throws Exception {
    PogUser obj1 = new PogUser();
    Collection<Role> roles = new ArrayList<Role>();
    Role role = new Role();
    role.setRoleName("SALES_REP");
    roles.add(role);
    obj1.setRoles(roles);
    assertTrue(obj1.isInSalesRepRole());
  }

  @Test
  public void testIsSalesRep_ReturnsFalse() throws Exception {
    PogUser obj1 = new PogUser();
    Collection<Role> roles = new ArrayList<Role>();
    Role role = new Role();
    role.setRoleName("SALES_REP1");
    roles.add(role);
    obj1.setRoles(roles);
    assertFalse(obj1.isInSalesRepRole());
  }

  @Test
  public void testIsAdmin_ReturnsTrue() throws Exception {
    PogUser obj1 = new PogUser();
    Collection<Role> roles = new ArrayList<Role>();
    Role role = new Role();
    role.setRoleName("ADMIN");
    roles.add(role);
    obj1.setRoles(roles);
    assertTrue(obj1.isAdmin());
  }

  @Test
  public void testIsAdmin_ReturnsFalse() throws Exception {
    PogUser obj1 = new PogUser();
    Collection<Role> roles = new ArrayList<Role>();
    Role role = new Role();
    role.setRoleName("SALES_REP1");
    roles.add(role);
    obj1.setRoles(roles);
    assertFalse(obj1.isAdmin());
  }

  @Test
  public void testGetCaptureLevelByType_ReturnsLevel() throws Exception {
    PogUser obj1 = new PogUser();

    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    UserArea userArea = new UserArea();
    UserAreaPk pk = new UserAreaPk();
    Area area = new Area();
    Collection<AreaCaptureLevel> captureLevels = new ArrayList<AreaCaptureLevel>();
    AreaCaptureLevel areaCaptureLevel = new AreaCaptureLevel();
    areaCaptureLevel.setCaptureLevel(12);
    CaptureType captureType = new CaptureType();
    captureType.setType("TESTTYPE");
    areaCaptureLevel.setCaptureType(captureType);
    captureLevels.add(areaCaptureLevel);
    area.setCaptureLevels(captureLevels);
    pk.setArea(area);
    CountryType countryType = new CountryType();
    countryType.setType("HOME");
    pk.setCountryType(countryType);
    userArea.setPk(pk);
    userAreas.add(userArea);
    obj1.setUserAreas(userAreas);

    assertEquals(12, obj1.getCaptureLevelByType("TESTTYPE"));
  }

  @Test
  public void testGetCaptureLevelByType_Returns0() throws Exception {
    PogUser obj1 = new PogUser();

    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    UserArea userArea = new UserArea();
    UserAreaPk pk = new UserAreaPk();
    Area area = new Area();
    Collection<AreaCaptureLevel> captureLevels = new ArrayList<AreaCaptureLevel>();
    AreaCaptureLevel areaCaptureLevel = new AreaCaptureLevel();
    areaCaptureLevel.setCaptureLevel(12);
    CaptureType captureType = new CaptureType();
    captureType.setType("TESTTYPE");
    areaCaptureLevel.setCaptureType(captureType);
    captureLevels.add(areaCaptureLevel);
    area.setCaptureLevels(captureLevels);
    pk.setArea(area);
    CountryType countryType = new CountryType();
    countryType.setType("HOME");
    pk.setCountryType(countryType);
    userArea.setPk(pk);
    userAreas.add(userArea);
    obj1.setUserAreas(userAreas);

    assertEquals(0, obj1.getCaptureLevelByType("NOTFOUND"));
  }

  @Test
  public void testGetCaptureLevelByType_HomeCountryNotFound_Returns0() throws Exception {
    PogUser obj1 = new PogUser();

    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    UserArea userArea = new UserArea();
    UserAreaPk pk = new UserAreaPk();
    Area area = new Area();
    Collection<AreaCaptureLevel> captureLevels = new ArrayList<AreaCaptureLevel>();
    AreaCaptureLevel areaCaptureLevel = new AreaCaptureLevel();
    areaCaptureLevel.setCaptureLevel(12);
    CaptureType captureType = new CaptureType();
    captureType.setType("TESTTYPE");
    areaCaptureLevel.setCaptureType(captureType);
    captureLevels.add(areaCaptureLevel);
    area.setCaptureLevels(captureLevels);
    pk.setArea(area);
    CountryType countryType = new CountryType();
    countryType.setType("HOME12");
    pk.setCountryType(countryType);
    userArea.setPk(pk);
    userAreas.add(userArea);
    obj1.setUserAreas(userAreas);

    assertEquals(0, obj1.getCaptureLevelByType("TESTTYPE"));
  }

  @Test
  public void testGetAssociatedAreas_Returns2() throws Exception {
    PogUser user = new PogUser();
    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    userAreas.add(getUserArea("HOME"));
    userAreas.add(getUserArea("ASSOCIATION"));
    userAreas.add(getUserArea("ASSOCIATION"));
    user.setUserAreas(userAreas);
    assertEquals(2, user.getAssociatedAreas().size());
  }

  @Test
  public void testGetAssociatedAreas_ReturnsNone() throws Exception {
    PogUser user = new PogUser();
    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    userAreas.add(getUserArea("HOME"));
    userAreas.add(getUserArea("ASSOCIATION1"));
    userAreas.add(getUserArea("ASSOCIATION2"));
    user.setUserAreas(userAreas);
    assertEquals(0, user.getAssociatedAreas().size());
  }

  @Test
  public void testGetHomeCountry_ReturnsCountry() throws Exception {
    PogUser user = new PogUser();
    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    userAreas.add(getUserArea("HOME"));
    userAreas.add(getUserArea("ASSOCIATION1"));
    userAreas.add(getUserArea("ASSOCIATION2"));
    user.setUserAreas(userAreas);
    assertEquals("HOME", user.getHomeCountry().getPk().getCountryType().getType());
  }

  @Test
  public void testGetHomeCountry_ReturnsNull() throws Exception {
    PogUser user = new PogUser();
    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    userAreas.add(getUserArea("HOME1"));
    userAreas.add(getUserArea("ASSOCIATION1"));
    userAreas.add(getUserArea("ASSOCIATION2"));
    user.setUserAreas(userAreas);
    assertNull(user.getHomeCountry());
  }

  private UserArea getUserArea(String countryTypeValue) {
    UserArea userArea = new UserArea();
    UserAreaPk pk = new UserAreaPk();
    CountryType countryType = new CountryType();
    countryType.setType(countryTypeValue);
    pk.setCountryType(countryType);
    userArea.setPk(pk);
    return userArea;
  }
}
