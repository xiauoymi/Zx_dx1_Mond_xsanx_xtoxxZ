/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Date;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class ProductCode_UT extends TestCase {

  @Test
  public void testGetters() {
    ProductCode productCode = new ProductCode();
    productCode.setId(12L);
    productCode.setCode("TEST PROD");
    productCode.setModDate(new Date());
    productCode.setModUser("TESTID");
    ArrayList<LanguageProduct> languageProducts = new ArrayList<LanguageProduct>();
    languageProducts.add(new LanguageProduct());
    languageProducts.add(new LanguageProduct());
    productCode.setLanguageProducts(languageProducts);

    assertEquals(12L, productCode.getId().longValue());
    assertEquals("TEST PROD", productCode.getCode());
    assertEquals("TESTID", productCode.getModUser());
    assertNotNull(productCode.getModDate());
    assertEquals(2, productCode.getLanguageProducts().size());
  }

  @Test
  public void testEquals() {
    ProductCode productCode1 = new ProductCode();
    productCode1.setId(12L);
    ProductCode productCode2 = new ProductCode();
    productCode2.setId(12L);

    assertTrue(productCode1.equals(productCode2));
    productCode2.setId(13L);
    assertFalse(productCode1.equals(productCode2));
  }

}