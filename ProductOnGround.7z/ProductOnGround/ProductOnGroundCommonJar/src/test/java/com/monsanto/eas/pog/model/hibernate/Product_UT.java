package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 25, 2011 Time: 1:05:58 PM To change this template use File |
 * Settings | File Templates.
 */
public class Product_UT extends TestCase {

    @Test
    public void testEquals_IdsAreEqual_ReturnsTrue() throws Exception {
        Product p1 = new Product();
        p1.setId(11L);
        Product p2 = new Product();
        p2.setId(11L);
        assertTrue(p1.equals(p2));
    }

    @Test
    public void testGetters() throws Exception {
        Product p1 = new Product();
        p1.setId(11L);
        BaseUnitOfMeasure baseUnitOfMeasure = new BaseUnitOfMeasure();
        baseUnitOfMeasure.setId(13L);
        p1.setBaseUnitOfMeasure(baseUnitOfMeasure);
        p1.setParentCode("AA-123-PARENT");
        p1.setBaseUomCode("L");
        p1.setCode("AA-123");
        p1.setLevel(2);
        Date time = Calendar.getInstance().getTime();
        p1.setModDate(time);
        p1.setModUser("SSPATI1");
        p1.setUnit(12.0);
        Product parent = new Product();
        parent.setId(15L);
        p1.setParentProduct(parent);
        Collection<ConversionFactor> cfs = new java.util.ArrayList<ConversionFactor>();
        cfs.add(new ConversionFactor());
        p1.setConversionFactors(cfs);

        assertEquals(11L, p1.getId().longValue());
        assertEquals(baseUnitOfMeasure, p1.getBaseUnitOfMeasure());
        assertEquals("AA-123", p1.getCode());
        assertEquals(2, p1.getLevel().intValue());
        assertEquals(12, p1.getUnit().intValue());
        assertEquals("SSPATI1", p1.getModUser());
        assertEquals("L", p1.getBaseUomCode());
        assertEquals("AA-123-PARENT", p1.getParentCode());
        assertEquals(time, p1.getModDate());
        assertEquals(parent, p1.getParentProduct());
        assertEquals(1, p1.getConversionFactors().size());
    }
}
