package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 19, 2010 Time: 8:33:34 AM To change this template use File |
 * Settings | File Templates.
 */
public class Role_UT extends TestCase {

  @Test
  public void testEquals_IdsAreEqual_ReturnsTrue() throws Exception {
    Role obj1 = new Role();
    obj1.setId(11L);
    Role obj2 = new Role();
    obj2.setId(11L);
    assertTrue(obj1.equals(obj2));
    assertNotNull(obj1.hashCode());
  }

  @Test
  public void testEquals_IdsAreNotEqual_ReturnsFalse() throws Exception {
    Role obj1 = new Role();
    obj1.setId(11L);
    Role obj2 = new Role();
    obj2.setId(12L);
    assertFalse(obj1.equals(obj2));
  }
  
  @Test
  public void testGetters(){
    Role role1 = new Role();
    role1.setModUser("user");
    Date date = Calendar.getInstance().getTime();
    role1.setModDate(date);
    assertEquals("user", role1.getModUser());
    assertTrue(date.equals(role1.getModDate()));
  }
}
