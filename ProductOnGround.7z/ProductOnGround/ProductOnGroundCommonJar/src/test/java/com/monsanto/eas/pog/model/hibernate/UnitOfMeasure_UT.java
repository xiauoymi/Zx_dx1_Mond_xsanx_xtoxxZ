package com.monsanto.eas.pog.model.hibernate;

import junit.framework.TestCase;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Sep 14, 2010 Time: 12:57:47 PM To change this template use File |
 * Settings | File Templates.
 */
public class UnitOfMeasure_UT extends TestCase {

  @Test
  public void testEquals_IdsAreEqual_ReturnsTrue() throws Exception {
    UnitOfMeasure baseUom1 = new UnitOfMeasure();
    baseUom1.setId(11L);
    UnitOfMeasure baseUom2 = new UnitOfMeasure();
    baseUom2.setId(11L);
    assertTrue(baseUom1.equals(baseUom2));
  }

  @Test
  public void testGetters() {
    UnitOfMeasure baseUom = new UnitOfMeasure();
    baseUom.setId(12L);
    baseUom.setCode("code");
    baseUom.setDescription("desc");
    assertEquals(12L, baseUom.getId().longValue());
    assertEquals("code", baseUom.getCode());
    assertEquals("desc", baseUom.getDescription());
  }
}
