package com.monsanto.eas.pog.model.hibernate;

import com.monsanto.eas.pog.model.UserAreaPk;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: 2/8/11 Time: 10:21 AM To change this template use File | Settings |
 * File Templates.
 */
public class UserArea_UT extends TestCase {

  @Test
  public void testGetters() {
    UserArea  ua = new UserArea();
    ua.setModUser("SSPATI1");
    Date time = Calendar.getInstance().getTime();
    ua.setModDate(time);
    UserAreaPk pk = new UserAreaPk();
    Area area = new Area();
    area.setId(11L);
    pk.setArea(area);
    CountryType ct = new CountryType();
    ct.setId(12L);
    pk.setCountryType(ct);
    PogUser user = new PogUser();
    user.setId(13L);
    pk.setPogUser(user);
    ua.setPk(pk);

    assertEquals("SSPATI1", ua.getModUser());
    assertEquals(time, ua.getModDate());
    assertEquals(area, ua.getArea());
    assertEquals(ct, ua.getCountryType());
    assertEquals(user, ua.getPogUser());
  }
}
