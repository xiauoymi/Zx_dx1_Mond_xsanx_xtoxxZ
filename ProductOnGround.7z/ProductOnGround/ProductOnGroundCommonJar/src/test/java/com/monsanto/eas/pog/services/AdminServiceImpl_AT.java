/*
 AdminServiceImpl_UT was created on Jul 9, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.*;
import com.monsanto.eas.pog.model.UserAreaPk;
import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class AdminServiceImpl_AT extends TestCase {
  @Autowired
  private PogUserDao userDao = null;
  @Autowired
  private CountryTypeDao countryTypeDao = null;
  @Autowired
  private AreaDao areaDao = null;
  @Autowired
  private RoleDao roleDao = null;
  @Autowired
  private PogUserDao pogUserDao = null;
  @Autowired
  private UserAreaDao userAreaDao = null;
  @Autowired
  private LocaleDao localeDao = null;
  @Autowired
  private LocaleService localeService = null;

  private Locale locale;

  @Before
  public void setUp() throws Exception {
    locale = new Locale();
    locale.setLanguage("French");
    locale.setLocale("fr");
    locale.setSapLocale("fr_FR");
    localeDao.saveOrUpdate(locale);
  }

  @After
  public void tearDown() {
    localeDao.delete(locale);
  }

  @Test
  public void testSaveUserAsAnAdmin_SelectedAreasHaveNoSalesRep_UserSavedWithAdminAndSalesRepRole() throws Exception {
    AdminService service = new AdminServiceImpl(userDao, countryTypeDao, areaDao, roleDao, userAreaDao, null);
    assertNotNull(service);
    PogUser user = new PogUser();
    user.setFirstName("Admin First Name");
    user.setLastName("Admin Last Name");
    user.setInternal(true);
    user.setUserId("ADMIN1");
    user.setParentUser(null);
    user.setLocale(locale);

    CountryType type = countryTypeDao.lookupByType("HOME");
    CountryType associationType = countryTypeDao.lookupByType("ASSOCIATION");

    UserArea userArea = new UserArea();
    UserAreaPk userAreaPK1 = new UserAreaPk();
    Area area1 = new Area();
    area1.setAreaCode("A1");
    area1.setAreaName("Area 1 from AT");
    userAreaPK1.setArea(area1);
    areaDao.saveOrUpdate(area1);
    userAreaPK1.setPogUser(user);
    userAreaPK1.setCountryType(type);
    userArea.setPk(userAreaPK1);
    user.getUserAreas().add(userArea);

    UserArea userArea2 = new UserArea();
    Area area2 = new Area();
    area2.setAreaCode("A2");
    area2.setAreaName("Area 2 from AT");
    UserAreaPk userAreaPK2 = new UserAreaPk();
    userAreaPK2.setArea(area2);
    areaDao.saveOrUpdate(area2);
    userAreaPK2.setPogUser(user);
    userAreaPK2.setCountryType(associationType);
    userArea2.setPk(userAreaPK2);
    user.getUserAreas().add(userArea2);

    UserArea userArea3 = new UserArea();
    UserAreaPk userAreaPK3 = new UserAreaPk();
    Area area3 = new Area();
    area3.setAreaCode("A3");
    area3.setAreaName("Area 3 from AT");
    userAreaPK3.setArea(area3);
    areaDao.saveOrUpdate(area3);
    userAreaPK3.setPogUser(user);
    userAreaPK3.setCountryType(associationType);
    userArea3.setPk(userAreaPK3);
    user.getUserAreas().add(userArea3);

    user.setRoles(roleDao.lookupByExample("ADMIN"));
    PogUser savedUser = service.saveOrUpdateUser(user, null);
    assertNotNull(savedUser);
    assertEquals("Admin First Name", savedUser.getFirstName());
    Collection<UserArea> activeUserAreas = new ArrayList<UserArea>();
    for (UserArea ua : savedUser.getUserAreas()) {
      activeUserAreas.add(ua);
    }
    assertEquals(3, activeUserAreas.size());
    Collection<Role> roles = savedUser.getRoles();
    assertEquals(2, roles.size());
    Iterator<Role> roleIterator = roles.iterator();
    assertEquals("ADMIN", roleIterator.next().getRoleName());
    assertEquals("SALES_REP", roleIterator.next().getRoleName());

    pogUserDao.delete(savedUser);
    areaDao.delete(area1);
    areaDao.delete(area2);
    areaDao.delete(area3);
  }

  @Test
  public void testSaveUserAsAnAdmin_SelectedAreasHaveSalesRep_UserSavedWithAdminRole() throws Exception {
    AdminService service = new AdminServiceImpl(userDao, countryTypeDao, areaDao, roleDao, userAreaDao, null);
    assertNotNull(service);
    PogUser user = new PogUser();
    user.setFirstName("Admin First Name");
    user.setLastName("Admin Last Name");
    user.setInternal(true);
    user.setUserId("ADMIN1");
    user.setParentUser(null);
    user.setLocale(locale);

    CountryType homeCountryType = countryTypeDao.lookupByType("HOME");
    CountryType associationType = countryTypeDao.lookupByType("ASSOCIATION");

    UserArea userArea = new UserArea();
    UserAreaPk userAreaPK1 = new UserAreaPk();
    Area area1 = new Area();
    area1.setAreaCode("A1");
    area1.setAreaName("Area 1 from AT");
    userAreaPK1.setArea(area1);
    areaDao.saveOrUpdate(area1);
    userAreaPK1.setPogUser(user);
    userAreaPK1.setCountryType(homeCountryType);
    userArea.setPk(userAreaPK1);
    user.getUserAreas().add(userArea);

    UserArea userArea2 = new UserArea();
    Area area2 = new Area();
    area2.setAreaCode("A2");
    area2.setAreaName("Area 2 from AT");
    UserAreaPk userAreaPK2 = new UserAreaPk();
    userAreaPK2.setArea(area2);
    areaDao.saveOrUpdate(area2);
    userAreaPK2.setPogUser(user);
    userAreaPK2.setCountryType(associationType);
    userArea2.setPk(userAreaPK2);
    user.getUserAreas().add(userArea2);

    PogUser salesRepForArea1 = new PogUser();
    salesRepForArea1.setFirstName("salesRepForSales1");
    salesRepForArea1.setLastName("salesRepForSales1");
    salesRepForArea1.setInternal(true);
    salesRepForArea1.setUserId("SALESREPAREA1");
    salesRepForArea1.setParentUser(null);
    salesRepForArea1.setLocale(locale);
    UserArea ua = new UserArea();
    UserAreaPk pk = new UserAreaPk();
    pk.setArea(area2);
    pk.setPogUser(salesRepForArea1);
    pk.setCountryType(homeCountryType);
    ua.setPk(pk);
    salesRepForArea1.getUserAreas().add(ua);
    salesRepForArea1.setRoles(roleDao.lookupByExample("SALES_REP"));
    pogUserDao.saveOrUpdate(salesRepForArea1);

    user.setRoles(roleDao.lookupByExample("ADMIN"));
    PogUser savedUser = service.saveOrUpdateUser(user, null);
    assertNotNull(savedUser);
    assertEquals("Admin First Name", savedUser.getFirstName());
    assertEquals(2, savedUser.getUserAreas().size());
    Collection<Role> roles = savedUser.getRoles();
    assertEquals(1, roles.size());
    Iterator<Role> roleIterator = roles.iterator();
    assertEquals("ADMIN", roleIterator.next().getRoleName());

    pogUserDao.delete(salesRepForArea1);
    pogUserDao.delete(savedUser);
    areaDao.delete(area1);
    areaDao.delete(area2);
  }

  @Test
  public void testSaveUserAsAnAdmin_UserIdEnteredExistsInTheSystem_AddsError() throws Exception {
    AdminService service = new AdminServiceImpl(userDao, countryTypeDao, areaDao, roleDao, userAreaDao, null);

    PogUser newUser = new PogUser();
    newUser.setUserId("testId1");
    newUser.setFirstName("FirstName from AT");
    newUser.setLastName("LastName from AT");
    newUser.setLocale(locale);

    Area newArea = new Area();
    newArea.setAreaCode("NA");
    newArea.setAreaName("New Area from AT");
    areaDao.saveOrUpdate(newArea);

    Collection<UserArea> userAreas = new ArrayList<UserArea>();
    CountryType homeCountryType = countryTypeDao.lookupByType("HOME");

    UserArea userArea1 = new UserArea();
    UserAreaPk userAreaPk = new UserAreaPk();

    userAreaPk.setCountryType(homeCountryType);
    userAreaPk.setPogUser(newUser);
    userAreaPk.setArea(newArea);
    userArea1.setPk(userAreaPk);

    userAreas.add(userArea1);
    newUser.setUserAreas(userAreas);

    newUser = pogUserDao.saveOrUpdate(newUser);

    PogUser user = new PogUser();
    user.setId(null);
    user.setUserId(newUser.getUserId());
    user.setParentUser(null);
    user.setLocale(locale);
    PogUser savedUser = service.saveOrUpdateUser(user, null);
    assertEquals(1, savedUser.getErrors().size());
    assertEquals("This user id already exists in the system.", savedUser.getErrors().get("userAlreadyExists"));

    pogUserDao.delete(newUser);
    pogUserDao.delete(savedUser);
    areaDao.delete(newArea);
  }

  @Test
  public void testSaveSalesRep_SalesRepRole_AssociateDistributorsSaved() throws Exception {
    AdminService service = new AdminServiceImpl(userDao, countryTypeDao, areaDao, roleDao, userAreaDao, localeService);
    assertNotNull(service);
    PogUser user = new PogUser();
    user.setFirstName("Test Sales Rep");
    user.setLastName("Test Sales Rep Last");
    user.setInternal(true);
    user.setUserId("SALES1");
    user.setParentUser(null);
    user.setLocale(locale);

    CountryType homeCountryType = countryTypeDao.lookupByType("HOME");
    CountryType associatedType = countryTypeDao.lookupByType("ASSOCIATION");

    user.setRoles(roleDao.lookupByExample("SALES_REP"));

    UserArea userArea = new UserArea();
    UserAreaPk userAreaPK1 = new UserAreaPk();
    Area area1 = new Area();
    area1.setAreaCode("A1");
    area1.setAreaName("Area 1 from AT");
    userAreaPK1.setArea(area1);
    areaDao.saveOrUpdate(area1);
    userAreaPK1.setPogUser(user);
    userAreaPK1.setCountryType(homeCountryType);
    userArea.setPk(userAreaPK1);
    user.getUserAreas().add(userArea);

    UserArea userArea2 = new UserArea();
    Area area2 = new Area();
    area2.setAreaCode("A2");
    area2.setAreaName("Area 2 from AT");
    UserAreaPk userAreaPK2 = new UserAreaPk();
    userAreaPK2.setArea(area2);
    areaDao.saveOrUpdate(area2);
    userAreaPK2.setPogUser(user);
    userAreaPK2.setCountryType(associatedType);
    userArea2.setPk(userAreaPK2);
    user.getUserAreas().add(userArea2);

    UserArea userArea3 = new UserArea();
    UserAreaPk userAreaPK3 = new UserAreaPk();
    Area area3 = new Area();
    area3.setAreaCode("A3");
    area3.setAreaName("Area 3 from AT");
    userAreaPK3.setArea(area3);
    areaDao.saveOrUpdate(area3);
    userAreaPK3.setPogUser(user);
    userAreaPK3.setCountryType(associatedType);
    userArea3.setPk(userAreaPK3);
    user.getUserAreas().add(userArea3);

    PogUser distributor = new PogUser();
    distributor.setFirstName("Test Distributor 1");
    distributor.setLastName("Test Distributor 1 Last");
    distributor.setAddress1("123 Test Lane");
    distributor.setProvince("Test");
    distributor.setSapId("123456652");
    distributor.setInternal(false);
    distributor.setUserId("dist1");
    distributor.setParentUser(null);
    distributor.setLocale(locale);
    Collection<UserArea> distUserAreas = new ArrayList<UserArea>();
    UserArea distUserArea1 = new UserArea();
    UserAreaPk distPk1 = new UserAreaPk();
    distPk1.setArea(area1);
    distPk1.setPogUser(distributor);
    distPk1.setCountryType(homeCountryType);
    distUserArea1.setPk(distPk1);
    distUserAreas.add(distUserArea1);
    distributor.setUserAreas(distUserAreas);

    Collection<PogUser> distributors = new ArrayList<PogUser>();
    distributors.add(distributor);

    PogUser savedUser = service.saveOrUpdateUser(user, distributors);
    assertNotNull(savedUser);
    assertEquals("Test Sales Rep", savedUser.getFirstName());
    Collection<UserArea> activeUserAreas = new ArrayList<UserArea>();
    for (UserArea ua : savedUser.getUserAreas()) {
      activeUserAreas.add(ua);
    }
    assertEquals(3, activeUserAreas.size());
    assertEquals(1, savedUser.getRoles().size());
    assertEquals("SALES_REP", savedUser.getRoles().iterator().next().getRoleName());

    PogUser savedDistributor = pogUserDao.findByUserId("dist2");
    //assertEquals("Test Distributor 1", savedDistributor.getFirstName());
    //assertEquals("EN", savedDistributor.getLocale().getLocale());
    assertFalse(savedDistributor.isDeleted());
    //assertNotNull(savedDistributor.getModDate());
    //assertEquals(savedUser.getId(), savedDistributor.getSalesRep().getId());

    /*pogUserDao.delete(distributor);
    pogUserDao.delete(savedUser);
    areaDao.delete(area1);
    areaDao.delete(area2);
    areaDao.delete(area3);*/
  }

  @Test
  public void testSaveSalesRep_SalesRepRole_AssociateDistributorsAlreadyExists_Saved() throws Exception {
    AdminService service = new AdminServiceImpl(userDao, countryTypeDao, areaDao, roleDao, userAreaDao, localeService);
    assertNotNull(service);
    PogUser user = new PogUser();
    user.setFirstName("Test Sales Rep");
    user.setLastName("Test Sales Rep Last");
    user.setInternal(true);
    user.setUserId("SALES1");
    user.setParentUser(null);
    user.setLocale(locale);

    CountryType homeCountryType = countryTypeDao.lookupByType("HOME");
    CountryType associatedType = countryTypeDao.lookupByType("ASSOCIATION");

    user.setRoles(roleDao.lookupByExample("SALES_REP"));

    UserArea userArea = new UserArea();
    UserAreaPk userAreaPK1 = new UserAreaPk();
    Area area1 = new Area();
    area1.setAreaCode("A1");
    area1.setAreaName("Area 1 from AT");
    userAreaPK1.setArea(area1);
    areaDao.saveOrUpdate(area1);
    userAreaPK1.setPogUser(user);
    userAreaPK1.setCountryType(homeCountryType);
    userArea.setPk(userAreaPK1);
    user.getUserAreas().add(userArea);

    UserArea userArea2 = new UserArea();
    Area area2 = new Area();
    area2.setAreaCode("A2");
    area2.setAreaName("Area 2 from AT");
    UserAreaPk userAreaPK2 = new UserAreaPk();
    userAreaPK2.setArea(area2);
    areaDao.saveOrUpdate(area2);
    userAreaPK2.setPogUser(user);
    userAreaPK2.setCountryType(associatedType);
    userArea2.setPk(userAreaPK2);
    user.getUserAreas().add(userArea2);

    UserArea userArea3 = new UserArea();
    UserAreaPk userAreaPK3 = new UserAreaPk();
    Area area3 = new Area();
    area3.setAreaCode("A3");
    area3.setAreaName("Area 3 from AT");
    userAreaPK3.setArea(area3);
    areaDao.saveOrUpdate(area3);
    userAreaPK3.setPogUser(user);
    userAreaPK3.setCountryType(associatedType);
    userArea3.setPk(userAreaPK3);
    user.getUserAreas().add(userArea3);

    PogUser distributor = new PogUser();
    distributor.setFirstName("Test Distributor 1");
    distributor.setLastName("Test Distributor 1 Last");
    distributor.setAddress1("123 Test Lane");
    distributor.setProvince("Test");
    distributor.setSapId("123456567");
    distributor.setInternal(false);
    distributor.setUserId("dist1");
    distributor.setParentUser(null);
    distributor.setLocale(locale);
    Collection<UserArea> distUserAreas = new ArrayList<UserArea>();
    UserArea distUserArea1 = new UserArea();
    UserAreaPk distPk1 = new UserAreaPk();
    distPk1.setArea(area1);
    distPk1.setPogUser(distributor);
    distPk1.setCountryType(homeCountryType);
    distUserArea1.setPk(distPk1);
    distUserAreas.add(distUserArea1);
    distributor.setUserAreas(distUserAreas);
    pogUserDao.saveOrUpdate(distributor);

    Collection<PogUser> distributors = new ArrayList<PogUser>();
    distributors.add(distributor);

    PogUser savedUser = service.saveOrUpdateUser(user, distributors);
    assertNotNull(savedUser);
    assertEquals("Test Sales Rep", savedUser.getFirstName());
    Collection<UserArea> activeUserAreas = new ArrayList<UserArea>();
    for (UserArea ua : savedUser.getUserAreas()) {
      activeUserAreas.add(ua);
    }
    assertEquals(3, activeUserAreas.size());
    assertEquals(1, savedUser.getRoles().size());
    assertEquals("SALES_REP", savedUser.getRoles().iterator().next().getRoleName());

    PogUser savedDistributor = pogUserDao.findByUserId("dist2");
    assertEquals("Test Distributor 1", savedDistributor.getFirstName());
//    assertEquals("fr", savedDistributor.getLocale().getLocale());
    assertFalse(savedDistributor.isDeleted());
  //  assertNotNull(savedDistributor.getModDate());
    //assertEquals(savedUser.getId(), savedDistributor.getSalesRep().getId());  */

    pogUserDao.delete(distributor);
   /* pogUserDao.delete(savedUser);
    areaDao.delete(area1);
    areaDao.delete(area2);
    areaDao.delete(area3);*/
  }

  @Test
  public void testSaveSalesRep_ExistingSalesRep_AssociateDistributors_Saved() throws Exception {
    AdminService service = new AdminServiceImpl(userDao, countryTypeDao, areaDao, roleDao, userAreaDao, localeService);
    assertNotNull(service);
    PogUser user = new PogUser();
    user.setFirstName("Test Sales Rep");
    user.setLastName("Test Sales Rep Last");
    user.setInternal(true);
    user.setUserId("SALES1");
    user.setParentUser(null);
    user.setLocale(locale);

    CountryType homeCountryType = countryTypeDao.lookupByType("HOME");
    CountryType associatedType = countryTypeDao.lookupByType("ASSOCIATION");

    user.setRoles(roleDao.lookupByExample("SALES_REP"));

    UserArea userArea = new UserArea();
    UserAreaPk userAreaPK1 = new UserAreaPk();
    Area area1 = new Area();
    area1.setAreaCode("A1");
    area1.setAreaName("Area 1 from AT");
    userAreaPK1.setArea(area1);
    areaDao.saveOrUpdate(area1);
    userAreaPK1.setPogUser(user);
    userAreaPK1.setCountryType(homeCountryType);
    userArea.setPk(userAreaPK1);
    user.getUserAreas().add(userArea);

    UserArea userArea2 = new UserArea();
    Area area2 = new Area();
    area2.setAreaCode("A2");
    area2.setAreaName("Area 2 from AT");
    UserAreaPk userAreaPK2 = new UserAreaPk();
    userAreaPK2.setArea(area2);
    areaDao.saveOrUpdate(area2);
    userAreaPK2.setPogUser(user);
    userAreaPK2.setCountryType(associatedType);
    userArea2.setPk(userAreaPK2);
    user.getUserAreas().add(userArea2);

    PogUser distributor = new PogUser();
    distributor.setFirstName("Test Distributor 1");
    distributor.setLastName("Test Distributor 1 Last");
    distributor.setAddress1("123 Test Lane");
    distributor.setProvince("Test");
    distributor.setSapId("123456513");
    distributor.setInternal(false);
    distributor.setUserId("dist1");
    distributor.setParentUser(null);
    distributor.setLocale(locale);
    Collection<UserArea> distUserAreas = new ArrayList<UserArea>();
    UserArea distUserArea1 = new UserArea();
    UserAreaPk distPk1 = new UserAreaPk();
    distPk1.setArea(area1);
    distPk1.setPogUser(distributor);
    distPk1.setCountryType(homeCountryType);
    distUserArea1.setPk(distPk1);
    distUserAreas.add(distUserArea1);
    distributor.setUserAreas(distUserAreas);
    pogUserDao.saveOrUpdate(distributor);

    Collection<PogUser> distributors = new ArrayList<PogUser>();
    distributors.add(distributor);

    PogUser savedUser = service.saveOrUpdateUser(user, distributors);
    assertEquals(2, savedUser.getUserAreas().size());

    PogUser distributor2 = new PogUser();
    distributor2.setFirstName("Test Distributor 2");
    distributor2.setLastName("Test Distributor 2 Last");
    distributor2.setAddress1("123 Test Lane");
    distributor2.setProvince("Test");
    distributor2.setSapId("123456");
    distributor2.setInternal(false);
    distributor2.setUserId("dist2");
    distributor2.setParentUser(null);
    distributor2.setLocale(locale);
    distUserAreas = new ArrayList<UserArea>();
    distUserArea1 = new UserArea();
    distPk1 = new UserAreaPk();
    Area area3 = new Area();
    area3.setAreaCode("A3");
    area3.setAreaName("Area 3 from AT");
    areaDao.saveOrUpdate(area3);
    distPk1.setArea(area3);
    distPk1.setPogUser(distributor2);
    distPk1.setCountryType(homeCountryType);
    distUserArea1.setPk(distPk1);
    distUserAreas.add(distUserArea1);
    distributor2.setUserAreas(distUserAreas);

    distributors = new ArrayList<PogUser>();
    distributors.add(distributor);
    distributors.add(distributor2);

    savedUser = service.saveOrUpdateUser(savedUser, distributors);
    assertNotNull(savedUser);
    assertEquals("Test Sales Rep", savedUser.getFirstName());
    Collection<UserArea> activeUserAreas = new ArrayList<UserArea>();
    for (UserArea ua : savedUser.getUserAreas()) {
      activeUserAreas.add(ua);
    }
    assertEquals(2, activeUserAreas.size()); //area2 not associated anymore
    assertEquals(1, savedUser.getRoles().size());
    assertEquals("SALES_REP", savedUser.getRoles().iterator().next().getRoleName());

    PogUser savedDistributor = pogUserDao.findByUserId("dist2");
    assertEquals("Test Distributor 1", savedDistributor.getFirstName());
//    assertEquals("fr", savedDistributor.getLocale().getLocale());
    assertFalse(savedDistributor.isDeleted());
  //  assertNotNull(savedDistributor.getModDate());
    //assertEquals(savedUser.getId(), savedDistributor.getSalesRep().getId());

    /*savedDistributor = pogUserDao.findByUserId("1234565");
    assertEquals("Test Distributor 2", savedDistributor.getFirstName());
    assertEquals("EN", savedDistributor.getLocale().getLocale());
    assertFalse(savedDistributor.isDeleted());
    assertNotNull(savedDistributor.getModDate());
    assertEquals(savedUser.getId(), savedDistributor.getSalesRep().getId());    */

    pogUserDao.delete(distributor);
    /*pogUserDao.delete(distributor2);
    pogUserDao.delete(savedUser);
    areaDao.delete(area1);
    areaDao.delete(area2);
    areaDao.delete(area3);*/
  }

  @Test
  public void testSaveSalesRep_BothAdminAndSalesRepRole_AssociateDistributors_Saved() throws Exception {
    AdminService service = new AdminServiceImpl(userDao, countryTypeDao, areaDao, roleDao, userAreaDao, localeService);
    assertNotNull(service);
    PogUser user = new PogUser();
    user.setFirstName("Test Sales Rep");
    user.setLastName("Test Sales Rep Last");
    user.setInternal(true);
    user.setUserId("SALES1");
    user.setParentUser(null);
    user.setLocale(locale);

    CountryType homeCountryType = countryTypeDao.lookupByType("HOME");
    CountryType associatedType = countryTypeDao.lookupByType("ASSOCIATION");

    Collection<Role> salesRepRole = roleDao.lookupByExample("SALES_REP");
    Collection<Role> adminRole = roleDao.lookupByExample("ADMIN");
    Collection<Role> roles = new ArrayList<Role>();
    roles.add(salesRepRole.iterator().next());
    roles.add(adminRole.iterator().next());
    user.setRoles(roles);

    UserArea userArea = new UserArea();
    UserAreaPk userAreaPK1 = new UserAreaPk();
    Area area1 = new Area();
    area1.setAreaCode("A1");
    area1.setAreaName("Area 1 from AT");
    userAreaPK1.setArea(area1);
    areaDao.saveOrUpdate(area1);
    userAreaPK1.setPogUser(user);
    userAreaPK1.setCountryType(homeCountryType);
    userArea.setPk(userAreaPK1);
    user.getUserAreas().add(userArea);

    UserArea userArea2 = new UserArea();
    Area area2 = new Area();
    area2.setAreaCode("A2");
    area2.setAreaName("Area 2 from AT");
    UserAreaPk userAreaPK2 = new UserAreaPk();
    userAreaPK2.setArea(area2);
    areaDao.saveOrUpdate(area2);
    userAreaPK2.setPogUser(user);
    userAreaPK2.setCountryType(associatedType);
    userArea2.setPk(userAreaPK2);
    user.getUserAreas().add(userArea2);

    PogUser distributor = new PogUser();
    distributor.setFirstName("Test Distributor 1");
    distributor.setLastName("Test Distributor 1 Last");
    distributor.setAddress1("123 Test Lane");
    distributor.setProvince("Test");
    distributor.setSapId("12345623");
    distributor.setInternal(false);
    distributor.setUserId("dist1");
    distributor.setParentUser(null);
    distributor.setLocale(locale);
    Collection<UserArea> distUserAreas = new ArrayList<UserArea>();
    UserArea distUserArea1 = new UserArea();
    UserAreaPk distPk1 = new UserAreaPk();
    distPk1.setArea(area1);
    distPk1.setPogUser(distributor);
    distPk1.setCountryType(homeCountryType);
    distUserArea1.setPk(distPk1);
    distUserAreas.add(distUserArea1);
    distributor.setUserAreas(distUserAreas);
    pogUserDao.saveOrUpdate(distributor);

    PogUser distributor2 = new PogUser();
    distributor2.setFirstName("Test Distributor 2");
    distributor2.setLastName("Test Distributor 2 Last");
    distributor2.setAddress1("123 Test Lane");
    distributor2.setProvince("Test");
    distributor2.setSapId("123456715");
    distributor2.setInternal(false);
    distributor2.setUserId("dist2");
    distributor2.setParentUser(null);
    distributor2.setLocale(locale);
    distUserAreas = new ArrayList<UserArea>();
    distUserArea1 = new UserArea();
    distPk1 = new UserAreaPk();
    Area area3 = new Area();
    area3.setAreaCode("A3");
    area3.setAreaName("Area 3 from AT");
    areaDao.saveOrUpdate(area3);
    distPk1.setArea(area3);
    distPk1.setPogUser(distributor2);
    distPk1.setCountryType(homeCountryType);
    distUserArea1.setPk(distPk1);
    distUserAreas.add(distUserArea1);
    distributor2.setUserAreas(distUserAreas);

    Collection<PogUser> distributors = new ArrayList<PogUser>();
    distributors.add(distributor);
    distributors.add(distributor2);

    PogUser savedUser = service.saveOrUpdateUser(user, distributors);
    assertNotNull(savedUser);
    assertEquals("Test Sales Rep", savedUser.getFirstName());
    Collection<UserArea> activeUserAreas = new ArrayList<UserArea>();
    for (UserArea ua : savedUser.getUserAreas()) {
      activeUserAreas.add(ua);
    }
    assertTrue(activeUserAreas.size()<=3);
    Collection<Role> userRoles = savedUser.getRoles();
    assertEquals(2, userRoles.size());
    Iterator<Role> roleIterator = userRoles.iterator();
    assertEquals("SALES_REP", roleIterator.next().getRoleName());
    assertEquals("ADMIN", roleIterator.next().getRoleName());

    PogUser savedDistributor = pogUserDao.findByUserId("dist2");
    assertEquals("Test Distributor 1", savedDistributor.getFirstName());
//    assertEquals("fr", savedDistributor.getLocale().getLocale());
    assertFalse(savedDistributor.isDeleted());
  //  assertNotNull(savedDistributor.getModDate());
   // assertEquals(savedUser.getId(), savedDistributor.getSalesRep().getId());

   /*savedDistributor = pogUserDao.findByUserId("1857590");
    //assertEquals("AGRICOLA DEL BURGO", savedDistributor.getFirstName());
    assertEquals("EN", savedDistributor.getLocale().getLocale());
    assertFalse(savedDistributor.isDeleted());
    assertNotNull(savedDistributor.getModDate());
    assertEquals(savedUser.getId(), savedDistributor.getSalesRep().getId());   */

    pogUserDao.delete(distributor);
   /* pogUserDao.delete(distributor2);
    pogUserDao.delete(savedUser);
   areaDao.delete(area1);
    areaDao.delete(area2);
    areaDao.delete(area3);*/
  }

  @Test
  public void testLookupSalesRepsByAdminId() throws Exception {
    AdminService service = new AdminServiceImpl(userDao, countryTypeDao, areaDao, roleDao, userAreaDao, null);
    PogUser user = new PogUser();
    user.setFirstName("Admin First Name");
    user.setLastName("Admin Last Name");
    user.setInternal(true);
    user.setUserId("ADMIN1");
    user.setParentUser(null);
    user.setLocale(locale);

    CountryType homeCountryType = countryTypeDao.lookupByType("HOME");
    CountryType associationType = countryTypeDao.lookupByType("ASSOCIATION");

    UserArea userArea = new UserArea();
    UserAreaPk userAreaPK1 = new UserAreaPk();
    Area area1 = new Area();
    area1.setAreaCode("A1");
    area1.setAreaName("Area 1 from AT");
    userAreaPK1.setArea(area1);
    areaDao.saveOrUpdate(area1);
    userAreaPK1.setPogUser(user);
    userAreaPK1.setCountryType(homeCountryType);
    userArea.setPk(userAreaPK1);
    user.getUserAreas().add(userArea);

    UserArea userArea2 = new UserArea();
    Area area2 = new Area();
    area2.setAreaCode("A2");
    area2.setAreaName("Area 2 from AT");
    UserAreaPk userAreaPK2 = new UserAreaPk();
    userAreaPK2.setArea(area2);
    areaDao.saveOrUpdate(area2);
    userAreaPK2.setPogUser(user);
    userAreaPK2.setCountryType(associationType);
    userArea2.setPk(userAreaPK2);
    user.getUserAreas().add(userArea2);

    UserArea userArea3 = new UserArea();
    UserAreaPk userAreaPK3 = new UserAreaPk();
    Area area3 = new Area();
    area3.setAreaCode("A3");
    area3.setAreaName("Area 3 from AT");
    userAreaPK3.setArea(area3);
    areaDao.saveOrUpdate(area3);
    userAreaPK3.setPogUser(user);
    userAreaPK3.setCountryType(associationType);
    userArea3.setPk(userAreaPK3);
    user.getUserAreas().add(userArea3);

    user.setRoles(roleDao.lookupByExample("ADMIN"));
    PogUser savedUser = service.saveOrUpdateUser(user, null);

    PogUser salesRepForArea1 = new PogUser();
    salesRepForArea1.setFirstName("salesRepForSales1");
    salesRepForArea1.setLastName("salesRepForSales1");
    salesRepForArea1.setInternal(true);
    salesRepForArea1.setUserId("SALESREPAREA1");
    salesRepForArea1.setParentUser(null);
    salesRepForArea1.setLocale(locale);
    UserArea ua = new UserArea();
    UserAreaPk pk = new UserAreaPk();
    pk.setArea(area2);
    pk.setPogUser(salesRepForArea1);
    pk.setCountryType(homeCountryType);
    ua.setPk(pk);
    salesRepForArea1.getUserAreas().add(ua);
    salesRepForArea1.setRoles(roleDao.lookupByExample("SALES_REP"));
    pogUserDao.saveOrUpdate(salesRepForArea1);

    Collection<PogUser> salesReps = service.lookupSalesRepsByAdminId(savedUser.getId());
    assertNotNull(salesReps);
    assertEquals(1, salesReps.size());
    assertEquals("salesRepForSales1", salesReps.iterator().next().getFirstName());

    pogUserDao.delete(savedUser);
    pogUserDao.delete(salesRepForArea1);
    areaDao.delete(area1);
    areaDao.delete(area2);
    areaDao.delete(area3);

  }

  @Test
  public void testLookupSalesRepsWithAssociatedArea() throws Exception {
    AdminService service = new AdminServiceImpl(userDao, countryTypeDao, areaDao, roleDao, userAreaDao, null);

    PogUser user = new PogUser();
    user.setFirstName("SR First Name");
    user.setLastName("SR Last Name");
    user.setInternal(true);
    user.setUserId("SR1");
    user.setParentUser(null);
    user.setLocale(locale);

    CountryType homeCountryType = countryTypeDao.lookupByType("HOME");
    CountryType associationType = countryTypeDao.lookupByType("ASSOCIATION");

    UserArea userArea = new UserArea();
    UserAreaPk userAreaPK1 = new UserAreaPk();
    Area area1 = new Area();
    area1.setAreaCode("A1");
    area1.setAreaName("Area 1 from AT");
    userAreaPK1.setArea(area1);
    areaDao.saveOrUpdate(area1);
    userAreaPK1.setPogUser(user);
    userAreaPK1.setCountryType(homeCountryType);
    userArea.setPk(userAreaPK1);
    user.getUserAreas().add(userArea);

    UserArea userArea2 = new UserArea();
    Area area2 = new Area();
    area2.setAreaCode("A2");
    area2.setAreaName("Area 2 from AT");
    UserAreaPk userAreaPK2 = new UserAreaPk();
    userAreaPK2.setArea(area2);
    areaDao.saveOrUpdate(area2);
    userAreaPK2.setPogUser(user);
    userAreaPK2.setCountryType(associationType);
    userArea2.setPk(userAreaPK2);
    user.getUserAreas().add(userArea2);

    UserArea userArea3 = new UserArea();
    UserAreaPk userAreaPK3 = new UserAreaPk();
    Area area3 = new Area();
    area3.setAreaCode("A3");
    area3.setAreaName("Area 3 from AT");
    userAreaPK3.setArea(area3);
    areaDao.saveOrUpdate(area3);
    userAreaPK3.setPogUser(user);
    userAreaPK3.setCountryType(associationType);
    userArea3.setPk(userAreaPK3);
    user.getUserAreas().add(userArea3);

    user.setRoles(roleDao.lookupByExample("SALES_REP"));
    pogUserDao.saveOrUpdate(user);
    Collection<PogUser> salesReps = service.lookupSalesRepsWithAssociatedArea(area3);

    assertNotNull(salesReps);
    assertEquals(1, salesReps.size());
    assertEquals("SR First Name", salesReps.iterator().next().getFirstName());

    pogUserDao.delete(user);
    areaDao.delete(area1);
    areaDao.delete(area2);
    areaDao.delete(area3);
  }
}