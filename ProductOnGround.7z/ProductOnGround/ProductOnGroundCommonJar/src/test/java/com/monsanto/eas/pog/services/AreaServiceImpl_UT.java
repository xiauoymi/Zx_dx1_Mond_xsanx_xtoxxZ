/*
 AreaServiceImpl_UT was created on Jun 24, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.mock.MockAreaDao;
import com.monsanto.eas.pog.model.hibernate.Area;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class AreaServiceImpl_UT extends TestCase {

  @Test
  public void testLookupAllAreas_ListOfAreasReturned() throws Exception {
    Area area = new Area();
    area.setAreaCode("TH");
    area.setAreaName("Thailand");
    Collection<Area> areas = new ArrayList<Area>();
    areas.add(area);
    area = new Area();
    area.setAreaCode("US");
    area.setAreaName("USA");
    areas.add(area);
    MockAreaDao areaDao = new MockAreaDao(null, areas);

    AreaService service = new AreaServiceImpl(areaDao);
    Collection<Area> areasList = service.lookupAll();
    assertEquals(2, areasList.size());
    for (Area anArea : areasList) {
      assertNotNull(anArea.getAreaCode());
      assertNotNull(anArea.getAreaName());
//    }
//
//    assertEquals("areaName", areaDao.getKey());
//    assertTrue(areaDao.isAscending());
    }

    assertEquals("areaName", areaDao.getKey());
    assertTrue(areaDao.isAscending());
  }

  @Test
  public void testSaveOrUpdate() throws Exception {
    Area area = new Area();
    area.setAreaCode("TH");
    area.setAreaName("Thailand");
    MockAreaDao areaDao = new MockAreaDao(null, null);
    AreaService service = new AreaServiceImpl(areaDao);
    service.saveOrUpdate(area);
    Area areaToSave = areaDao.getAreaToSave();
    assertEquals("TH", areaToSave.getAreaCode());
    assertEquals("Thailand", areaToSave.getAreaName());
  }}