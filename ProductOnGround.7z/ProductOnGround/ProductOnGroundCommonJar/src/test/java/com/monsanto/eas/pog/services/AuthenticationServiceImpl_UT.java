package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.model.hibernate.PogUser;
import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.security.GrantedAuthority;
import org.springframework.security.GrantedAuthorityImpl;
import org.springframework.security.providers.UsernamePasswordAuthenticationToken;
import org.springframework.security.userdetails.User;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 19, 2010 Time: 11:42:56 AM To change this template use File |
 * Settings | File Templates.
 */
public class AuthenticationServiceImpl_UT extends TestCase {

  @Test
  public void testAuthenticatePrincipal_UserIsValid() throws Exception {
    AuthenticationService service = new MockAuthenticationService(getAuthentication(), null);
    PogUser user = service.authenticatePrincipal("testName", "testPass");
    assertNotNull(user);
    assertEquals("testName1", user.getFirstName());
    assertEquals(2, user.getRoles().size());
    assertEquals("role 1", user.getRoles().iterator().next().getRoleName());
  }

  @Test
  public void testIsPrincipalAuthenticated_FlexContextIsNull_ReturnsFalse() throws Exception {
    AuthenticationService service = new MockAuthenticationService(getAuthentication(), null);
    assertFalse(service.isPrinicipalAuthenticated());
  }

  @Test
  public void testIsPrinicipalAuthenticated_FlexContextIsNotNull_ReturnsTTrue() throws Exception {
    AuthenticationService service = new MockAuthenticationService(getAuthentication(),
        new UsernamePasswordAuthenticationToken(null, null));
    assertTrue(service.isPrinicipalAuthenticated());
  }

  private UsernamePasswordAuthenticationToken getAuthentication() {
    GrantedAuthority[] authorities = new GrantedAuthority[2];
    authorities[0] = new GrantedAuthorityImpl("role 1");
    authorities[1] = new GrantedAuthorityImpl("role 2");
    User principle = new User("testName1", "pass", true, true, true, true, authorities);
    return new UsernamePasswordAuthenticationToken(principle, "pass", authorities);
  }

  @Test
  public void testLogoutPrincipal() throws Exception {
    AuthenticationService service = new MockAuthenticationService(getAuthentication(), null);
    service.logoutPrincipal();
  }
}
