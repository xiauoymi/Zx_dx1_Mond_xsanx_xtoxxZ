package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.mock.MockBaseUnitOfMeasureDao;
import com.monsanto.eas.pog.model.hibernate.BaseUnitOfMeasure;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 6, 2010 Time: 3:06:20 PM To change this template use File |
 * Settings | File Templates.
 */
public class BaseUnitOfMeasureServiceImpl_UT extends TestCase {
  @Test
  public void testLookupAllLocales() throws Exception {
    Collection<BaseUnitOfMeasure> mockUoms = new ArrayList<BaseUnitOfMeasure>();
    mockUoms.add(new BaseUnitOfMeasure());
    mockUoms.add(new BaseUnitOfMeasure());
    MockBaseUnitOfMeasureDao mockDao = new MockBaseUnitOfMeasureDao(null, mockUoms);
    BaseUnitOfMeasureService service = new BaseUnitOfMeasureServiceImpl(mockDao);
    Collection<BaseUnitOfMeasure> baseUOMs = service.lookupAll();
    assertEquals(2, baseUOMs.size());
  }
}
