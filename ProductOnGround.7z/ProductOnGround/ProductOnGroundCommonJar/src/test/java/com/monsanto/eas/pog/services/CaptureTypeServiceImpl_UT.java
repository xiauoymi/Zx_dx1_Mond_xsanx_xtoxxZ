package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.mock.MockCaptureTypeDao;
import com.monsanto.eas.pog.model.hibernate.CaptureType;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 25, 2010 Time: 12:08:17 PM To change this template use File |
 * Settings | File Templates.
 */
public class CaptureTypeServiceImpl_UT extends TestCase {

  @Test
  public void testLookupAllTypes() throws Exception {
    Collection<CaptureType> mockTypes = new ArrayList<CaptureType>();
    mockTypes.add(new CaptureType());
    mockTypes.add(new CaptureType());
    CaptureTypeService service = new CaptureTypeServiceImpl(new MockCaptureTypeDao(null, mockTypes));
    Collection<CaptureType> types = service.lookupAll();
    assertEquals(2, types.size());
  }
}
