package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.mock.MockCountryTypeDao;
import com.monsanto.eas.pog.model.hibernate.CountryType;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 25, 2010 Time: 12:13:07 PM To change this template use File |
 * Settings | File Templates.
 */
public class CountryTypeServiceImpl_UT extends TestCase {
    @Test
    public void testLookupAllTypes() throws Exception {
        Collection<CountryType> mockTypes = new ArrayList<CountryType>();
        mockTypes.add(new CountryType());
        mockTypes.add(new CountryType());
        CountryTypeService service = new CountryTypeServiceImpl(new MockCountryTypeDao(null, mockTypes));
        Collection<CountryType> types = service.lookupAll();
        assertEquals(2, types.size());
    }

    @Test
    public void testLookupByType() throws Exception {
        CountryType type = new CountryType();
        type.setType("test");
        CountryTypeService service = new CountryTypeServiceImpl(new MockCountryTypeDao(type, null));
        CountryType countryType = service.lookupByType("test");
        assertEquals("test", countryType.getType());
    }
}
