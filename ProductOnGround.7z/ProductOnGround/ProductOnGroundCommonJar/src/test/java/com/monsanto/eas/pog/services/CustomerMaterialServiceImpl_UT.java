package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.CustomerMaterialDao;
import com.monsanto.eas.pog.model.hibernate.CustomerMaterial;
import junit.framework.TestCase;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class CustomerMaterialServiceImpl_UT extends TestCase {
  @Test
  public void testLookupByCustomerPk() {

    CustomerMaterialDao customerMaterialDao = Mockito.mock(CustomerMaterialDao.class);
    Collection<CustomerMaterial> mockCustomerMaterials = new ArrayList<CustomerMaterial>();
    mockCustomerMaterials.add(new CustomerMaterial());
    mockCustomerMaterials.add(new CustomerMaterial());
    Mockito.when(customerMaterialDao.lookupByCustomerPk(12L)).thenReturn(mockCustomerMaterials);

    CustomerMaterialService service = new CustomerMaterialServiceImpl(customerMaterialDao);
    Collection<CustomerMaterial> customerMaterials = service.lookupByCustomerPk(12L);
    assertEquals(2, customerMaterials.size());
  }
}
