package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.CustomerProductDao;
import com.monsanto.eas.pog.dao.CustomerTransactionDao;
import com.monsanto.eas.pog.dao.mock.MockCustomerProductDao;
import com.monsanto.eas.pog.dao.mock.MockCustomerTransactionDao;
import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 5, 2010 Time: 2:29:12 PM To change this template use File |
 * Settings | File Templates.
 */
public class CustomerProductServiceImpl_UT extends TestCase {

  @Test
  public void testFilterByYearAndMonth_CustomerTransactionExists() throws Exception {
    CustomerTransaction customerTransaction = new CustomerTransaction();
    CustomerProduct cp = new CustomerProduct();
    customerTransaction.setCustomerProduct(cp);
    Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();
    CustomerTransaction ct = new CustomerTransaction();
    ct.setFinalInventory(443.0);
    ct.setYear(2010L);
    ct.setMonth(4L);
    cp = new CustomerProduct();
    cp.setId(11L);
    ct.setCustomerProduct(cp);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setFinalInventory(444.0);
    ct.setYear(2010L);
    ct.setMonth(5L);
    cp = new CustomerProduct();
    cp.setId(12L);
    ct.setCustomerProduct(cp);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setFinalInventory(445.0);
    ct.setYear(2010L);
    ct.setMonth(3L);
    cp = new CustomerProduct();
    cp.setId(13L);
    ct.setCustomerProduct(cp);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setFinalInventory(446.0);
    ct.setYear(2010L);
    ct.setMonth(5L);
    cp = new CustomerProduct();
    cp.setId(14L);
    ct.setCustomerProduct(cp);
    customerTransactions.add(ct);
    MockCustomerTransactionDao customerTransactionDao = new MockCustomerTransactionDao(ct, customerTransactions);
    CustomerProductService service = new CustomerProductServiceImpl(null, customerTransactionDao);
    PogUser distributor = new PogUser();
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();

    CustomerProduct customerProduct = new CustomerProduct();
    customerProduct.setId(11L);
    Product product1 = new Product();
    product1.setCode("AA123");
    customerProduct.setProduct(product1);
    Collection<CustomerTransaction> cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    customerProduct.setId(12L);
    Product product2 = new Product();
    product2.setCode("AA124");
    customerProduct.setProduct(product2);
    cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    Collection<PogUser> children = new ArrayList<PogUser>();
    PogUser child1 = new PogUser();
    child1.setId(111L);
    ArrayList<PogUser> grandChildren = new ArrayList<PogUser>();
    PogUser grandChild1 = new PogUser();
    grandChild1.setId(113L);
    grandChild1.setChildUsers(new ArrayList<PogUser>());
    grandChild1.setCustomerProducts(new ArrayList<CustomerProduct>());
    grandChildren.add(grandChild1);
    child1.setChildUsers(grandChildren);
    Collection<CustomerProduct> customerProductsChild1 = new ArrayList<CustomerProduct>();
    CustomerProduct cProduct = new CustomerProduct();
    cProduct.setId(13L);
    cProduct.setProduct(product1);
    cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cProduct.setCustomerTransactions(cts);
    customerProductsChild1.add(cProduct);
    cProduct = new CustomerProduct();
    cProduct.setId(14L);
    cProduct.setProduct(product2);
    cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cProduct.setCustomerTransactions(cts);
    customerProductsChild1.add(cProduct);
    child1.setCustomerProducts(customerProductsChild1);
    children.add(child1);
    PogUser child2 = new PogUser();
    child2.setId(112L);
    child2.setChildUsers(new ArrayList<PogUser>());
    child2.setCustomerProducts(new ArrayList<CustomerProduct>());
    children.add(child2);
    distributor.setChildUsers(children);

    distributor.setCustomerProducts(customerProducts);
    service.filterByYearAndMonth(distributor, 2010L, 5L);
    Collection<CustomerProduct> customerProductCollection = distributor.getCustomerProducts();
    assertEquals(2, customerProductCollection.size());
    for (CustomerProduct cprod : customerProductCollection) {
      assertEquals(1, cprod.getCustomerTransactions().size());
      if (cprod.getId().equals(11L)) {
        assertEquals(0.0, cprod.getCustomerTransactions().iterator().next().getFinalInventory());
      } else if (cprod.getId().equals(12L)) {
        assertEquals(444.0, cprod.getCustomerTransactions().iterator().next().getFinalInventory());
      }
    }
    PogUser childUser1 = distributor.getChildUsers().iterator().next();
    for (CustomerProduct cprod : childUser1.getCustomerProducts()) {
      assertEquals(1, cprod.getCustomerTransactions().size());
      if (cprod.getId().equals(13L)) {
        assertEquals(0.0, cprod.getCustomerTransactions().iterator().next().getFinalInventory());
      } else if (cprod.getId().equals(14L)) {
        assertEquals(446.0, cprod.getCustomerTransactions().iterator().next().getFinalInventory());
      }
    }

   // assertEquals(4, customerTransactionDao.getDistributorIds().size());
    assertEquals(2010L, customerTransactionDao.getYear().longValue());
    assertEquals(4L, customerTransactionDao.getMonth().longValue());
    assertEquals(2010L, customerTransactionDao.getEndYear().longValue());
    assertEquals(5L, customerTransactionDao.getEndMonth().longValue());
  }

  @Test
  public void testFilterByYearAndMonth_CustomerTransactionDoesntExist_PreviousTransactionDoesntExist() throws
      Exception {
    Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();
    CustomerTransaction ct = new CustomerTransaction();
    ct.setFinalInventory(444.0);
    ct.setYear(2010L);
    ct.setMonth(2L);
    CustomerProduct cp = new CustomerProduct();
    cp.setId(11L);
    ct.setCustomerProduct(cp);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setFinalInventory(444.0);
    ct.setYear(2010L);
    ct.setMonth(5L);
    cp = new CustomerProduct();
    cp.setId(12L);
    ct.setCustomerProduct(cp);
    customerTransactions.add(ct);

    CustomerTransactionDao customerTransactionDao = new MockCustomerTransactionDao(null, customerTransactions);
    CustomerProductService service = new CustomerProductServiceImpl(null, customerTransactionDao);
    PogUser distributor = new PogUser();
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();

    CustomerProduct customerProduct = new CustomerProduct();
    customerProduct.setId(11L);
    Product product1 = new Product();
    product1.setCode("AA123");
    customerProduct.setProduct(product1);
    Collection<CustomerTransaction> cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    customerProduct.setId(12L);
    Product product2 = new Product();
    product2.setCode("AA124");
    customerProduct.setProduct(product2);
    cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    Collection<PogUser> children = new ArrayList<PogUser>();
    PogUser child1 = new PogUser();
    child1.setId(111L);
    child1.setChildUsers(new ArrayList<PogUser>());
    child1.setCustomerProducts(new ArrayList<CustomerProduct>());
    children.add(child1);
    PogUser child2 = new PogUser();
    child2.setId(112L);
    child2.setChildUsers(new ArrayList<PogUser>());
    child2.setCustomerProducts(new ArrayList<CustomerProduct>());
    children.add(child2);
    distributor.setChildUsers(children);

    distributor.setCustomerProducts(customerProducts);
    service.filterByYearAndMonth(distributor, 2010L, 1L);
    Collection<CustomerProduct> customerProductCollection = distributor.getCustomerProducts();
    assertEquals(2, customerProductCollection.size());
    for (CustomerProduct cprod : customerProductCollection) {
      assertEquals(1, cprod.getCustomerTransactions().size());
      CustomerTransaction ct1 = cprod.getCustomerTransactions().iterator().next();
      assertEquals(2010L, ct1.getYear().longValue());
      assertEquals(1L, ct1.getMonth().longValue());
      assertEquals(0L, ct1.getBudget().longValue());
      assertEquals(0L, ct1.getFinalInventory().longValue());
      assertEquals(0D, ct1.getSalesAmount());
      assertEquals(0L, ct1.getInitialInventory().longValue());
    }
  }

  @Test
  public void testFilterByYearAndMonth_CustomerTransactionDoesntExist_PreviousTransactionExist() throws
      Exception {
    Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();
    CustomerTransaction ct = new CustomerTransaction();
    ct.setFinalInventory(444.0);
    ct.setYear(2010L);
    ct.setMonth(3L);
    CustomerProduct cp = new CustomerProduct();
    cp.setId(11L);
    Product product1 = new Product();
    product1.setCode("AA122");
    cp.setProduct(product1);
    ct.setCustomerProduct(cp);
    customerTransactions.add(ct);
    ct = new CustomerTransaction();
    ct.setFinalInventory(444.0);
    ct.setYear(2010L);
    ct.setMonth(3L);
    cp = new CustomerProduct();
    cp.setId(12L);
    ct.setCustomerProduct(cp);
    customerTransactions.add(ct);

    CustomerTransaction previousCustomerTransaction = new CustomerTransaction();
    CustomerProduct custProd = new CustomerProduct();
    custProd.setId(11L);
    previousCustomerTransaction.setCustomerProduct(custProd);
    previousCustomerTransaction.setFinalInventory(444.0);
    MockCustomerTransactionDao customerTransactionDao = new MockCustomerTransactionDao(previousCustomerTransaction,
        customerTransactions);
    CustomerProductService service = new CustomerProductServiceImpl(null, customerTransactionDao);
    PogUser distributor = new PogUser();
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();

    CustomerProduct customerProduct = new CustomerProduct();
    customerProduct.setId(11L);
    customerProduct.setProduct(product1);
    Collection<CustomerTransaction> cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    customerProduct.setId(12L);
    Product product2 = new Product();
    product2.setCode("AA124");
    customerProduct.setProduct(product2);
    cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    Collection<PogUser> children = new ArrayList<PogUser>();
    PogUser child1 = new PogUser();
    child1.setId(111L);
    child1.setChildUsers(new ArrayList<PogUser>());
    child1.setCustomerProducts(new ArrayList<CustomerProduct>());
    children.add(child1);
    PogUser child2 = new PogUser();
    child2.setId(112L);
    child2.setChildUsers(new ArrayList<PogUser>());
    child2.setCustomerProducts(new ArrayList<CustomerProduct>());
    children.add(child2);
    distributor.setChildUsers(children);

    distributor.setCustomerProducts(customerProducts);
    service.filterByYearAndMonth(distributor, 2010L, 4L);
    Collection<CustomerProduct> customerProductCollection = distributor.getCustomerProducts();

    assertEquals(2, customerProductCollection.size());
    for (CustomerProduct cprod : customerProductCollection) {
      assertEquals(1, cprod.getCustomerTransactions().size());
      CustomerTransaction ct1 = cprod.getCustomerTransactions().iterator().next();
      assertEquals(2010L, ct1.getYear().longValue());
      assertEquals(4L, ct1.getMonth().longValue());
      assertEquals(0L, ct1.getBudget().longValue());
      assertEquals(0L, ct1.getFinalInventory().longValue());
      assertEquals(0D, ct1.getSalesAmount());
      assertEquals(444L, ct1.getInitialInventory().longValue());
    }

   // assertEquals(3, customerTransactionDao.getDistributorIds().size());
    assertEquals(2010L, customerTransactionDao.getYear().longValue());
    assertEquals(3L, customerTransactionDao.getMonth().longValue());
    assertEquals(2010L, customerTransactionDao.getEndYear().longValue());
    assertEquals(4L, customerTransactionDao.getEndMonth().longValue());
  }

  @Test
  public void testFilterByYearAndMonthRange() throws Exception {
    Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();
    CustomerTransaction customerTransaction = new CustomerTransaction();
    customerTransaction.setFinalInventory(444.0);
    customerTransaction.setYear(2010L);
    customerTransaction.setMonth(4L);
    CustomerProduct cp = new CustomerProduct();
    cp.setId(11L);
    customerTransaction.setCustomerProduct(cp);
    customerTransactions.add(customerTransaction);
    customerTransaction = new CustomerTransaction();
    customerTransaction.setFinalInventory(444.0);
    customerTransaction.setYear(2010L);
    customerTransaction.setMonth(5L);
    cp = new CustomerProduct();
    cp.setId(11L);
    customerTransaction.setCustomerProduct(cp);
    customerTransactions.add(customerTransaction);
    cp.setCustomerTransactions(customerTransactions);

    Collection<CustomerTransaction> customerTrans = new ArrayList<CustomerTransaction>();
    customerTransaction = new CustomerTransaction();
    customerTransaction.setFinalInventory(444.0);
    customerTransaction.setYear(2010L);
    customerTransaction.setMonth(4L);
    cp = new CustomerProduct();
    cp.setId(12L);
    customerTransaction.setCustomerProduct(cp);
    customerTrans.add(customerTransaction);
    customerTransactions.add(customerTransaction);

    customerTransaction = new CustomerTransaction();
    customerTransaction.setFinalInventory(444.0);
    customerTransaction.setYear(2010L);
    customerTransaction.setMonth(5L);
    cp = new CustomerProduct();
    cp.setId(12L);
    customerTransaction.setCustomerProduct(cp);
    customerTrans.add(customerTransaction);
    customerTransactions.add(customerTransaction);
    cp.setCustomerTransactions(customerTrans);

    CustomerTransactionDao customerTransactionDao = new MockCustomerTransactionDao(null, customerTransactions);
    CustomerProductService service = new CustomerProductServiceImpl(null, customerTransactionDao);
    PogUser distributor = new PogUser();
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();

    CustomerProduct customerProduct = new CustomerProduct();
    customerProduct.setId(11L);
    Product product1 = new Product();
    product1.setCode("AA122");
    customerProduct.setProduct(product1);
    Collection<CustomerTransaction> cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    customerProduct.setId(12L);
    Product product2 = new Product();
    product2.setCode("AA124");
    customerProduct.setProduct(product2);
    cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    distributor.setCustomerProducts(customerProducts);
    Collection<CustomerProduct> customerProductCollection = service
        .filterByYearAndMonthRange(distributor, 2010L, 4L, 2010L, 5L);
    assertEquals(2, customerProductCollection.size());
    for (CustomerProduct cprod : customerProductCollection) {
      assertEquals(2, cprod.getCustomerTransactions().size());
      Collection<CustomerTransaction> transactions = cprod.getCustomerTransactions();
      Iterator<CustomerTransaction> iterator = transactions.iterator();
      CustomerTransaction ct = iterator.next();
      assertEquals(2010L, ct.getYear().longValue());
      assertEquals(4L, ct.getMonth().longValue());
      ct = iterator.next();
      assertEquals(2010L, ct.getYear().longValue());
      assertEquals(5L, ct.getMonth().longValue());
    }
  }

  @Test
  public void testFilterByYearAndMonthRange_TransactionMapDoesntHaveTheProduct() throws Exception {
    Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();
    CustomerTransaction customerTransaction = new CustomerTransaction();
    customerTransaction.setFinalInventory(444.0);
    customerTransaction.setYear(2010L);
    customerTransaction.setMonth(4L);
    CustomerProduct cp = new CustomerProduct();
    cp.setId(11L);
    customerTransaction.setCustomerProduct(cp);
    customerTransactions.add(customerTransaction);
    customerTransaction = new CustomerTransaction();
    customerTransaction.setFinalInventory(444.0);
    customerTransaction.setYear(2010L);
    customerTransaction.setMonth(5L);
    cp = new CustomerProduct();
    cp.setId(11L);
    customerTransaction.setCustomerProduct(cp);
    customerTransactions.add(customerTransaction);
    cp.setCustomerTransactions(customerTransactions);

    Collection<CustomerTransaction> customerTrans = new ArrayList<CustomerTransaction>();
    customerTransaction = new CustomerTransaction();
    customerTransaction.setFinalInventory(444.0);
    customerTransaction.setYear(2010L);
    customerTransaction.setMonth(4L);
    cp = new CustomerProduct();
    cp.setId(12L);
    customerTransaction.setCustomerProduct(cp);
    customerTrans.add(customerTransaction);
    customerTransactions.add(customerTransaction);

    customerTransaction = new CustomerTransaction();
    customerTransaction.setFinalInventory(444.0);
    customerTransaction.setYear(2010L);
    customerTransaction.setMonth(5L);
    cp = new CustomerProduct();
    cp.setId(12L);
    customerTransaction.setCustomerProduct(cp);
    customerTrans.add(customerTransaction);
    customerTransactions.add(customerTransaction);
    cp.setCustomerTransactions(customerTrans);

    CustomerTransactionDao customerTransactionDao = new MockCustomerTransactionDao(null, customerTransactions);
    CustomerProductService service = new CustomerProductServiceImpl(null, customerTransactionDao);
    PogUser distributor = new PogUser();
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();

    CustomerProduct customerProduct = new CustomerProduct();
    customerProduct.setId(11L);
    Product product1 = new Product();
    product1.setCode("AA122");
    customerProduct.setProduct(product1);
    Collection<CustomerTransaction> cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    customerProduct.setId(12L);
    Product product2 = new Product();
    product2.setCode("AA124");
    customerProduct.setProduct(product2);
    cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    customerProduct.setId(13L);
    Product product3 = new Product();
    product3.setCode("AA126");
    customerProduct.setProduct(product3);
    cts = new ArrayList<CustomerTransaction>();
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    cts.add(new CustomerTransaction());
    customerProduct.setCustomerTransactions(cts);
    customerProducts.add(customerProduct);

    distributor.setCustomerProducts(customerProducts);
    Collection<CustomerProduct> customerProductCollection = service
        .filterByYearAndMonthRange(distributor, 2010L, 4L, 2010L, 5L);
    assertEquals(3, customerProductCollection.size());
    for (CustomerProduct cprod : customerProductCollection) {
      if (cprod.getId().equals(13L)) {
        assertEquals(0, cprod.getCustomerTransactions().size());
      } else {
        assertEquals(2, cprod.getCustomerTransactions().size());
        Collection<CustomerTransaction> transactions = cprod.getCustomerTransactions();
        Iterator<CustomerTransaction> iterator = transactions.iterator();
        CustomerTransaction ct = iterator.next();
        assertEquals(2010L, ct.getYear().longValue());
        assertEquals(4L, ct.getMonth().longValue());
        ct = iterator.next();
        assertEquals(2010L, ct.getYear().longValue());
        assertEquals(5L, ct.getMonth().longValue());
      }
    }
  }

  @Test
  public void testLookupInactiveByDistributorAndProduct_ReturnsCP() throws Exception {
    CustomerProduct customerProduct = new CustomerProduct();
    customerProduct.setId(12L);
    CustomerProductDao customerProductDao = new MockCustomerProductDao(customerProduct, null, null);
    CustomerProductService service = new CustomerProductServiceImpl(customerProductDao, null);
    PogUser distributor = new PogUser();
    BaseUnitOfMeasure baseUom = new BaseUnitOfMeasure();
    baseUom.setId(13L);
    CustomerProduct cp = service.lookupInactiveByDistributorProductCodeAndBaseUomCode(distributor, "AA123", baseUom.getCode(),
        "123455");
    assertEquals(12L, cp.getId().longValue());
    assertEquals("AA123", cp.getProduct().getCode());
  }
}
