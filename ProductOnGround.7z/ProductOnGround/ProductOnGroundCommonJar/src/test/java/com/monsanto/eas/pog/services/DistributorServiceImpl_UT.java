package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.PogUserDao;
import com.monsanto.eas.pog.dao.PogUserDaoImpl;
import com.monsanto.eas.pog.dao.mock.MockPogUserDao;
import com.monsanto.eas.pog.model.UserAreaPk;
import com.monsanto.eas.pog.model.hibernate.*;
import com.monsanto.eas.pog.services.mock.MockCustomerProductService;
import com.monsanto.eas.pog.services.mock.MockProductService;
import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 24, 2010 Time: 11:32:54 AM To change this template use File |
 * Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = true)
@Transactional
public class DistributorServiceImpl_UT extends TestCase {

  @Autowired
  private PogUserDao pogUserDao = null;

  @Test
  public void testLookupAllLevel1DistributorsBySalesRepUserIdForSync_TransactionsAndProductsPopulatedFromSAP() throws
      Exception {
    List<PogUser> distributors = getMockDistributors();
    MockCustomerProductService customerProductService = new MockCustomerProductService(null, null);
    MockPogUserDao pogUserDao = new MockPogUserDao(null, distributors, null);
    DistributorService service = new DistributorServiceImpl(pogUserDao, customerProductService, null);

    Collection<PogUser> pogUsersForSync = service.lookupAllLevel1DistributorsBySalesRepUserIdForSync("sspati1", "en");
    assertEquals(3, pogUsersForSync.size());
    assertEquals("sspati1", pogUserDao.getSalesRepUserId());

    Iterator<PogUser> distributorIterator = pogUsersForSync.iterator();
    PogUser level1Dist = distributorIterator.next();
    assertEquals(11L, level1Dist.getId().longValue());
    assertEquals("name 1", level1Dist.getFirstName());
    assertEquals("1234", level1Dist.getSapId());
    assertNull(level1Dist.getAddress1());
    assertNull("", level1Dist.getAddress2());
    assertNull("", level1Dist.getProvince());
    assertNull("", level1Dist.getPostalCode());

    Contact contact = level1Dist.getContacts().iterator().next();
//    assertEquals("sap email 1", contact.getEmail());
    assertEquals("contact name 1", contact.getName());
    assertEquals("contact phone 1", contact.getPhone());
//    assertEquals("sap fax 1", contact.getFax());

    Collection<PogUser> childUsers = level1Dist.getChildUsers();
    assertEquals(1, childUsers.size());
    PogUser childUser = childUsers.iterator().next();
    Collection<CustomerProduct> childCustomerProducts = childUser.getCustomerProducts();
    assertEquals(1, childCustomerProducts.size());
    CustomerProduct childCustomerProduct = childCustomerProducts.iterator().next();
    assertEquals("AA12345", childCustomerProduct.getProduct().getCode());
    assertEquals(41L, childCustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", childCustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", childCustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    Collection<PogUser> grranChildUsers = childUser.getChildUsers();
    assertEquals(1, grranChildUsers.size());
    PogUser grandChildUser = grranChildUsers.iterator().next();
    Collection<CustomerProduct> grandCustomerProducts = grandChildUser.getCustomerProducts();
    assertEquals(1, grandCustomerProducts.size());
    CustomerProduct grandCustomerProduct = grandCustomerProducts.iterator().next();
    assertEquals("AA12345", grandCustomerProduct.getProduct().getCode());
    assertEquals(41L, grandCustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", grandCustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", grandCustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    Collection<CustomerProduct> level1CustomerProducts1 = level1Dist.getCustomerProducts();
    assertEquals(3, level1CustomerProducts1.size());
    Iterator<CustomerProduct> customerProductIterator1 = level1CustomerProducts1.iterator();
    CustomerProduct level1CustomerProduct1 = customerProductIterator1.next();
    assertEquals("AA12345", level1CustomerProduct1.getProduct().getCode());
    assertEquals(41L, level1CustomerProduct1.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", level1CustomerProduct1.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", level1CustomerProduct1.getProduct().getBaseUnitOfMeasure().getDescription());

    Collection<CustomerTransaction> transactions = level1CustomerProduct1.getCustomerTransactions();
    assertEquals(2, transactions.size());
    Iterator<CustomerTransaction> customerTransactionIterator = transactions.iterator();
    CustomerTransaction customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(8L, customerTransaction.getMonth().longValue());
    assertEquals(34.45, customerTransaction.getFinalInventory());
    assertEquals(234.34, customerTransaction.getSalesAmount());
    assertEquals(56.45, customerTransaction.getBudget());
    customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(7L, customerTransaction.getMonth().longValue());
    assertEquals(43.45, customerTransaction.getFinalInventory());
    assertEquals(243.34, customerTransaction.getSalesAmount());
    assertEquals(65.45, customerTransaction.getBudget());
    assertNull(customerTransaction.getCustomerProduct());

    level1CustomerProduct1 = customerProductIterator1.next();
    assertEquals("AA12345", level1CustomerProduct1.getProduct().getCode());
    assertEquals(42L, level1CustomerProduct1.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("LB", level1CustomerProduct1.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Pound", level1CustomerProduct1.getProduct().getBaseUnitOfMeasure().getDescription());

    level1CustomerProduct1 = customerProductIterator1.next();
    assertEquals("AA23456", level1CustomerProduct1.getProduct().getCode());
    assertEquals(43L, level1CustomerProduct1.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("GAL", level1CustomerProduct1.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Gallon", level1CustomerProduct1.getProduct().getBaseUnitOfMeasure().getDescription());
    Collection<CustomerProduct> level1CustomerProducts;
    Iterator<CustomerProduct> customerProductIterator;
    CustomerProduct level1CustomerProduct;

    level1Dist = distributorIterator.next();
    assertEquals(12L, level1Dist.getId().longValue());
    assertNull("", level1Dist.getFirstName());
//    assertEquals("2345", level1Dist.getSapId());
    assertNull(level1Dist.getAddress1());
    assertNull("", level1Dist.getAddress2());
    assertNull("", level1Dist.getProvince());
    assertNull("", level1Dist.getPostalCode());
    contact = level1Dist.getContacts().iterator().next();

//    assertEquals("sap email 2", contact.getEmail());
    assertEquals("contact name 2", contact.getName());
    assertEquals("contact phone 2", contact.getPhone());
//    assertEquals("sap fax 2", contact.getFax());
    level1CustomerProducts = level1Dist.getCustomerProducts();
    assertEquals(1, level1CustomerProducts.size());
    customerProductIterator = level1CustomerProducts.iterator();
    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals(41L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
    assertEquals(0, level1CustomerProduct.getCustomerTransactions().size());

    level1Dist = distributorIterator.next();
    assertEquals(13L, level1Dist.getId().longValue());
    assertNull("sap first name 3", level1Dist.getFirstName());
    assertEquals("4567", level1Dist.getSapId());
    assertNull(level1Dist.getAddress1());
    assertNull("sap address 3", level1Dist.getAddress2());
    assertNull("sap province 3", level1Dist.getProvince());
    assertNull("sap postal 3", level1Dist.getPostalCode());
    contact = level1Dist.getContacts().iterator().next();
//    assertEquals("sap email 3", contact .getEmail());
    assertEquals("contact name 3", contact.getName());
    assertEquals("contact phone 3", contact.getPhone());
//    assertEquals("sap fax 3", contact.getFax());
    level1CustomerProducts = level1Dist.getCustomerProducts();
    assertEquals(0, level1CustomerProducts.size());
  }

  private Collection<PogUser> getMockSapDistributors() {
    Collection<PogUser> sapPogUsers = new ArrayList<PogUser>();
    PogUser sapUser1 = new PogUser();
    sapUser1.setFirstName("sap first name 1");
    sapUser1.setSapId("1234");
    Collection<Contact> contacts = new ArrayList<Contact>();
    Contact contact = new Contact();
    contact.setName("sap contact name 1");
    contact.setPhone("sap contact phone 1");
    contact.setEmail("sap email 1");
    contact.setFax("sap fax 1");
    contacts.add(contact);
    sapUser1.setContacts(contacts) ;

    sapUser1.setAddress1("sap address 1");
    sapUser1.setAddress2("sap address 2");
    sapUser1.setPostalCode("sap postal 1");
    sapUser1.setProvince("sap province 1");
    sapPogUsers.add(sapUser1);
    PogUser sapUser2 = new PogUser();
    sapUser2.setFirstName("sap first name 2");
    sapUser2.setSapId("2345");
    contacts = new ArrayList<Contact>();
    contact = new Contact();
    contact.setName("sap contact name 2");
    contact.setPhone("sap contact phone 2");
    contact.setEmail("sap email 2");
    contact.setFax("sap fax 2");
    contacts.add(contact);
    sapUser2.setContacts(contacts) ;

    sapUser2.setAddress2("sap address 2");
    sapUser2.setAddress2("sap address 2");
    sapUser2.setPostalCode("sap postal 2");
    sapUser2.setProvince("sap province 2");
    sapPogUsers.add(sapUser2);
    return sapPogUsers;
  }

  private List<PogUser> getMockDistributors() {
    List<PogUser> distributors = new ArrayList<PogUser>();
    PogUser dist1 = new PogUser();
    dist1.setId(11L);
    dist1.setFirstName("name 1");
    dist1.setUserAreas(getUserAreas());
    Collection<PogUser> childUsers1 = new ArrayList<PogUser>();
    PogUser child1 = new PogUser();
    Collection<CustomerProduct> child1CustomerProducts1 = new ArrayList<CustomerProduct>();
    CustomerProduct child1CustomerProduct1 = new CustomerProduct();
    BaseUnitOfMeasure childBaseUom1 = getLiterUom();
    Product child1Product1 = new Product();
    child1Product1.setCode("AA12345");
    child1Product1.setBaseUnitOfMeasure(childBaseUom1);
    child1CustomerProduct1.setProduct(child1Product1);
    child1CustomerProducts1.add(child1CustomerProduct1);
    child1.setCustomerProducts(child1CustomerProducts1);

    Collection<PogUser> childUsers11 = new ArrayList<PogUser>();
    PogUser child11 = new PogUser();
    Collection<CustomerProduct> childCustomerProducts11 = new ArrayList<CustomerProduct>();
    CustomerProduct childCustomerProduct11 = new CustomerProduct();
    Product childProduct11 = new Product();
    childProduct11.setCode("AA12345");
    childProduct11.setBaseUnitOfMeasure(getLiterUom());
    childCustomerProduct11.setProduct(childProduct11);
    childCustomerProducts11.add(childCustomerProduct11);
    child11.setChildUsers(new ArrayList<PogUser>());
    child11.setCustomerProducts(childCustomerProducts11);
    childUsers11.add(child11);
    child1.setChildUsers(childUsers11);

    childUsers1.add(child1);
    dist1.setChildUsers(childUsers1);
    Collection<CustomerProduct> customerProducts1 = new ArrayList<CustomerProduct>();
    CustomerProduct customerProduct1 = new CustomerProduct();
    Product product1 = new Product();
    product1.setBaseUnitOfMeasure(getLiterUom());
    product1.setId(22L);
    product1.setCode("AA12345");
    customerProduct1.setProduct(product1);
    Collection<CustomerTransaction> customerTransactions1 = new ArrayList<CustomerTransaction>();
    CustomerTransaction transaction1 = new CustomerTransaction();
    transaction1.setYear(2010L);
    transaction1.setMonth(8L);
    transaction1.setSalesAmount(234.34);
    transaction1.setFinalInventory(34.45);
    transaction1.setBudget(56.45);
    customerTransactions1.add(transaction1);
    CustomerTransaction transaction2 = new CustomerTransaction();
    transaction2.setYear(2010L);
    transaction2.setMonth(7L);
    transaction2.setSalesAmount(243.34);
    transaction2.setFinalInventory(43.45);
    transaction2.setBudget(65.45);
    customerTransactions1.add(transaction2);
    customerProduct1.setCustomerTransactions(customerTransactions1);
    customerProducts1.add(customerProduct1);

    CustomerProduct customerProduct2 = new CustomerProduct();
    Product product2 = new Product();
    product2.setBaseUnitOfMeasure(getPoundUom());
    product2.setId(23L);
    product2.setCode("AA12345");
    customerProduct2.setProduct(product2);
    customerProducts1.add(customerProduct2);
    CustomerProduct customerProduct3 = new CustomerProduct();
    Product product3 = new Product();
    product3.setBaseUnitOfMeasure(getGallonUom());
    product3.setId(24L);
    product3.setCode("AA23456");
    customerProduct3.setProduct(product3);
    customerProducts1.add(customerProduct3);
    dist1.setCustomerProducts(customerProducts1);

    dist1.setSapId("1234");

    Collection<Contact> contacts = new ArrayList<Contact>();
    Contact contact = new Contact();
    contact.setName("contact name 1");
    contact.setPhone("contact phone 1");
    contacts.add(contact);
    dist1.setContacts(contacts) ;

    dist1.setOverride(true);
    distributors.add(dist1);
    PogUser dist2 = new PogUser();
    dist2.setId(12L);
    dist2.setChildUsers(new ArrayList<PogUser>());

    contacts = new ArrayList<Contact>();
    contact = new Contact();
    contact.setName("contact name 2");
    contact.setPhone("contact phone 2");
    contacts.add(contact);
    dist2.setContacts(contacts) ;

    Collection<CustomerProduct> customerProducts2 = new ArrayList<CustomerProduct>();
    CustomerProduct customerProduct21 = new CustomerProduct();
    Product product21 = new Product();
    product21.setCode("AA12345");
    product21.setBaseUnitOfMeasure(getLiterUom());
    customerProduct21.setProduct(product21);
    customerProducts2.add(customerProduct21);
    dist2.setCustomerProducts(customerProducts2);
    dist2.setUserAreas(getUserAreas());
    distributors.add(dist2);

    PogUser dist3 = new PogUser();
    dist3.setId(13L);
    dist3.setChildUsers(new ArrayList<PogUser>());
    dist3.setSapId("4567");

    contacts = new ArrayList<Contact>();
    contact = new Contact();
    contact.setName("contact name 3");
    contact.setPhone("contact phone 3");
    contacts.add(contact);
    dist3.setContacts(contacts) ;

    dist3.setCustomerProducts(new ArrayList<CustomerProduct>());
    dist3.setUserAreas(getUserAreas());
    distributors.add(dist3);
    return distributors;
  }

  private BaseUnitOfMeasure getGallonUom() {
    BaseUnitOfMeasure baseUom3 = new BaseUnitOfMeasure();
    baseUom3.setId(43L);
    baseUom3.setCode("GAL");
    baseUom3.setDescription("Gallon");
    return baseUom3;
  }

  private BaseUnitOfMeasure getPoundUom() {
    BaseUnitOfMeasure sapProductBaseUom1 = new BaseUnitOfMeasure();
    sapProductBaseUom1.setId(42L);
    sapProductBaseUom1.setCode("LB");
    sapProductBaseUom1.setDescription("Pound");
    return sapProductBaseUom1;
  }

  private BaseUnitOfMeasure getLiterUom() {
    BaseUnitOfMeasure childBaseUom1 = new BaseUnitOfMeasure();
    childBaseUom1.setId(41L);
    childBaseUom1.setCode("L");
    childBaseUom1.setDescription("Liter");
    return childBaseUom1;
  }

  private Collection<UserArea> getUserAreas() {
    Collection<UserArea> userAreas1 = new ArrayList<UserArea>();
    UserArea userArea1 = new UserArea();
    UserAreaPk pk1 = new UserAreaPk();
    CountryType homeCountryType = new CountryType();
    homeCountryType.setType("HOME");
    pk1.setCountryType(homeCountryType);
    Area area1 = new Area();
    Collection<AreaCaptureLevel> captureLevels1 = new ArrayList<AreaCaptureLevel>();
    AreaCaptureLevel areaCaptureLevel1 = new AreaCaptureLevel();
    CaptureType productCaptureType = new CaptureType();
    productCaptureType.setType("PRODUCT");
    areaCaptureLevel1.setCaptureLevel(5);
    areaCaptureLevel1.setCaptureType(productCaptureType);
    captureLevels1.add(areaCaptureLevel1);
    AreaCaptureLevel areaCaptureLevel2 = new AreaCaptureLevel();
    CaptureType groupCaptureType = new CaptureType();
    groupCaptureType.setType("GROUP");
    areaCaptureLevel2.setCaptureType(groupCaptureType);
    areaCaptureLevel2.setCaptureLevel(3);
    captureLevels1.add(areaCaptureLevel2);
    area1.setCaptureLevels(captureLevels1);
    pk1.setArea(area1);
    userArea1.setPk(pk1);
    userAreas1.add(userArea1);
    return userAreas1;
  }

  @Test
  public void testSaveOrUpdate_NewLevel1Distributor_Saved() throws Exception {
    MockPogUserDao pogUserDao = new MockPogUserDao(null, null, null);
    DistributorService service = new DistributorServiceImpl(pogUserDao, null, null);
    PogUser distributorToSave = new PogUser();
    Calendar calendar = Calendar.getInstance();
    calendar.add(Calendar.DATE, -1);
    distributorToSave.setModDate(calendar.getTime());
    PogUser savedDistributor = service.saveOrUpdate(distributorToSave);
    assertFalse(distributorToSave.getModDate().before(savedDistributor.getModDate()));
    assertEquals(123L, savedDistributor.getId().longValue());
    assertEquals("newUserId", savedDistributor.getUserId());

    assertNull(pogUserDao.getMergePogUser());
  }

  @Test
  public void testSaveOrUpdate_ExistingLevel1Distributor_NoCustomerProducts_Merged() throws Exception {
    PogUser mockUser = new PogUser();
    mockUser.setId(234L);
    mockUser.setUserId("userId123");
    MockPogUserDao pogUserDao = new MockPogUserDao(mockUser, null, null);
    DistributorService service = new DistributorServiceImpl(pogUserDao, null, null);
    PogUser distributorToSave = new PogUser();
    distributorToSave.setId(234L);
    distributorToSave.setUserId("userId");
    distributorToSave.setCustomerProducts(new ArrayList<CustomerProduct>());
    Calendar calendar = Calendar.getInstance();
    calendar.add(Calendar.DATE, -1);
    distributorToSave.setModDate(calendar.getTime());
    PogUser pogUser = service.saveOrUpdate(distributorToSave);

    assertNotNull(pogUser);
    assertFalse(distributorToSave.getModDate().before(pogUser.getModDate()));
    assertEquals(234L, pogUser.getId().longValue());
    assertEquals("userId123", pogUser.getUserId());
    assertEquals(0, pogUser.getCustomerProducts().size());
  }

  @Test
  public void testSaveOrUpdate_ExistingLevel1Distributor_WithOldAndNewProducts_Merged() throws Exception {
    PogUser mockUser = new PogUser();
    mockUser.setId(234L);
    mockUser.setUserId("userId123");
    mockUser.setCustomerProducts(new ArrayList<CustomerProduct>());
    MockPogUserDao pogUserDao = new MockPogUserDao(mockUser, null, null);
    CustomerProduct inactiveCP = new CustomerProduct();
    inactiveCP.setDeleted(true);
    inactiveCP.setId(22L);
    MockCustomerProductService customerProductService = new MockCustomerProductService(inactiveCP, null);

    Product product1 = new Product();
    product1.setCode("AA12345");

    ProductCode prodCode1 = new ProductCode();
    prodCode1.setCode("AA124117E02DK220LT");
    product1.setProductCode(prodCode1);

    BaseUnitOfMeasure baseUom1 = new BaseUnitOfMeasure();
    baseUom1.setCode("L");
    product1.setBaseUnitOfMeasure(baseUom1);

    DistributorService service = new DistributorServiceImpl(pogUserDao, customerProductService, new MockProductService(product1, null,
        null));
    PogUser distributorToSave = new PogUser();
    distributorToSave.setId(234L);
    distributorToSave.setUserId("userId");
    ArrayList<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();
    CustomerProduct cp1 = new CustomerProduct();
    cp1.setId(123L);
    cp1.setProduct(product1);
    customerProducts.add(cp1);
    CustomerProduct cp2 = new CustomerProduct();
    Product product2 = new Product();
    product2.setCode("AA23455");

    ProductCode prodCode2 = new ProductCode();
    prodCode2.setCode("AA124117E02DK25LIT");
    product2.setProductCode(prodCode2);

    BaseUnitOfMeasure baseUom2 = new BaseUnitOfMeasure();
    baseUom2.setCode("LB");
    product2.setBaseUnitOfMeasure(baseUom2);
    cp2.setProduct(product2);
    customerProducts.add(cp2);
    CustomerProduct cp3 = new CustomerProduct();
    cp3.setId(345L);
    Product product3 = new Product();
    product3.setCode("AA12345");

    ProductCode prodCode3 = new ProductCode();
    prodCode3.setCode("AA124117E02DK21000");
    product3.setProductCode(prodCode2);

    product3.setBaseUnitOfMeasure(baseUom2);
    cp3.setProduct(product3);
    customerProducts.add(cp3);
    distributorToSave.setCustomerProducts(customerProducts);
    Calendar calendar = Calendar.getInstance();
    calendar.add(Calendar.DATE, -1);
    distributorToSave.setModDate(calendar.getTime());
    PogUser pogUser = service.saveOrUpdate(distributorToSave);

    assertNotNull(pogUser);
    assertFalse(distributorToSave.getModDate().before(pogUser.getModDate()));
    assertEquals(234L, pogUser.getId().longValue());
    assertEquals("userId123", pogUser.getUserId());
    Collection<CustomerProduct> customerProductCollection = pogUser.getCustomerProducts();
    assertEquals(3, customerProductCollection.size());
    Iterator<CustomerProduct> cpIterator = customerProductCollection.iterator();
    CustomerProduct cp = cpIterator.next();
    assertTrue(cp.getId().longValue()>=22L);
    assertFalse(cp.isDeleted());
    cp = cpIterator.next();
    assertNull(cp.getId());
    assertEquals("AA12345", cp.getProduct().getCode());
    assertFalse(cp.isDeleted());
  }

  @Test
  public void testSaveOrUpdate_NewNonLeve1Distributor_Saved() throws Exception {
    MockPogUserDao pogUserDao = new MockPogUserDao(null, null, null);
    DistributorService service = new DistributorServiceImpl(pogUserDao, null, null);
    PogUser distributorToSave = new PogUser();
    Calendar calendar = Calendar.getInstance();
    calendar.add(Calendar.DATE, -1);
    distributorToSave.setModDate(calendar.getTime());
    distributorToSave.setParentUser(new PogUser());
    PogUser savedDistributor = service.saveOrUpdate(distributorToSave);
    assertFalse(distributorToSave.getModDate().before(savedDistributor.getModDate()));
    assertEquals(123L, savedDistributor.getId().longValue());
    assertEquals("123", savedDistributor.getUserId());

    assertNotNull(pogUserDao.getMergePogUser());
  }

  @Test
  public void testLookupAllLevel1DistBySalesRepUserId_ReturnsSalesRep() throws Exception {
    MockPogUserDao pogUserDao = new MockPogUserDao(null, getMockDistributors(), null);

    DistributorService service = new DistributorServiceImpl(pogUserDao, null, null);
    Collection<PogUser> level1Distributors = service.lookupAllLevel1DistBySalesRepUserId("sspati1");

    assertEquals("sspati1", pogUserDao.getSalesRepUserId());

    Iterator<PogUser> distributorIterator = level1Distributors.iterator();
    PogUser level1Dist = distributorIterator.next();
    assertEquals(11L, level1Dist.getId().longValue());
    assertEquals("name 1", level1Dist.getFirstName());
    assertEquals("1234", level1Dist.getSapId());
    assertNull(level1Dist.getAddress1());
    assertNull("", level1Dist.getAddress2());
    assertNull("", level1Dist.getProvince());
    assertNull("", level1Dist.getPostalCode());

     if(level1Dist.getContacts().iterator().hasNext()){
        Contact contact = level1Dist.getContacts().iterator().next();
//    assertEquals("sap email 1", contact.getEmail());
      assertEquals("contact name 1", contact.getName());
      assertEquals("contact phone 1", contact.getPhone());
//    assertEquals("sap fax 1", contact.getFax());
      assertEquals(0, level1Dist.getChildUsers().size());
      assertEquals(0, level1Dist.getCustomerProducts().size());
     }

    level1Dist = distributorIterator.next();
    assertEquals(12L, level1Dist.getId().longValue());
    assertNull("", level1Dist.getFirstName());
    //assertEquals("2345", level1Dist.getSapId());
    assertNull(level1Dist.getAddress1());
    assertNull("", level1Dist.getAddress2());
    assertNull("", level1Dist.getProvince());
    assertNull("", level1Dist.getPostalCode());
    if(level1Dist.getContacts().iterator().hasNext()){
        Contact contact = level1Dist.getContacts().iterator().next();
    //    assertEquals("sap email 2", contact.getEmail());
        assertEquals("contact name 2", contact.getName());
        assertEquals("contact phone 2", contact.getPhone());
    //    assertEquals("sap fax 2", contact.getFax());
    }
    assertEquals(0, level1Dist.getChildUsers().size());
    assertEquals(0, level1Dist.getCustomerProducts().size());

    level1Dist = distributorIterator.next();
    assertEquals(13L, level1Dist.getId().longValue());
    assertNull("", level1Dist.getFirstName());
    assertEquals("4567", level1Dist.getSapId());
    assertNull(level1Dist.getAddress1());
    assertNull("sap address 3", level1Dist.getAddress2());
    assertNull("sap province 3", level1Dist.getProvince());
    assertNull("sap postal 3", level1Dist.getPostalCode());
      if(level1Dist.getContacts().iterator().hasNext()){
       Contact contact = level1Dist.getContacts().iterator().next();
//      assertEquals("sap email 3", contact.getEmail());
        assertEquals("contact name 3", contact.getName());
        assertEquals("contact phone 3", contact.getPhone());
//      assertEquals("sap fax 3", contact.getFax());
      }
    assertEquals(0, level1Dist.getChildUsers().size());
    assertEquals(0, level1Dist.getCustomerProducts().size());
  }

  @Test
  public void testLookupDetailsByIdForEdit_WithParentUser() throws Exception {
    List<PogUser> pogUsers = getMockDistributors();
    PogUser user = pogUsers.iterator().next();
    PogUser parent1 = new PogUser();
    ArrayList<CustomerProduct> parent1CPs = new ArrayList<CustomerProduct>();
    parent1CPs.add(new CustomerProduct());
    parent1CPs.add(new CustomerProduct());
    parent1.setCustomerProducts(parent1CPs);
    parent1.setUserAreas(user.getUserAreas());
    Collection<PogUser> parent1Children = new ArrayList<PogUser>();
    parent1Children.add(new PogUser());
    parent1Children.add(new PogUser());
    parent1Children.add(user);
    parent1.setChildUsers(parent1Children);
    user.setParentUser(parent1);

    PogUser parent11 = new PogUser();
    ArrayList<CustomerProduct> parent11CPs = new ArrayList<CustomerProduct>();
    parent11CPs.add(new CustomerProduct());
    parent11CPs.add(new CustomerProduct());
    parent11.setCustomerProducts(parent1CPs);
    parent11.setUserAreas(user.getUserAreas());
    Collection<PogUser> parent11Children = new ArrayList<PogUser>();
    parent11Children.add(new PogUser());
    parent11Children.add(new PogUser());
    parent11Children.add(parent1);
    parent11.setChildUsers(parent11Children);
    parent1.setParentUser(parent11);

    MockPogUserDao pogUserDao = new MockPogUserDao(user, pogUsers, null);
    DistributorService service = new DistributorServiceImpl(pogUserDao, null, null);
    PogUser level1Dist = service.lookupDetailsByIdForEdit(user.getId());

    assertEquals(11L, level1Dist.getId().longValue());
    PogUser parentUser1 = level1Dist.getParentUser();
    assertEquals(1, parentUser1.getChildUsers().size());
    assertEquals(2, parentUser1.getCustomerProducts().size());
    assertEquals(1, parentUser1.getParentUser().getChildUsers().size());
    assertEquals(2, parentUser1.getParentUser().getCustomerProducts().size());

    Collection<CustomerProduct> level1CustomerProducts = level1Dist.getCustomerProducts();
    assertEquals(3, level1CustomerProducts.size());
    Iterator<CustomerProduct> customerProductIterator = level1CustomerProducts.iterator();
    CustomerProduct level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals(41L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals("LB", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Pound", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
    assertEquals(0, level1CustomerProduct.getCustomerTransactions().size());

    assertEquals(1, level1Dist.getChildUsers().size());
    PogUser child11 = level1Dist.getChildUsers().iterator().next();
    assertEquals(0, child11.getCustomerProducts().size());
    assertEquals(1, child11.getChildUsers().size());
    assertEquals(0, child11.getChildUsers().iterator().next().getCustomerProducts().size());
  }

  @Test
  public void testLookupDistributorWithBudgetData_Level1Distributor() throws Exception {
    List<PogUser> pogUsers = getMockDistributors();
    PogUser user = pogUsers.iterator().next();
    MockPogUserDao pogUserDao = new MockPogUserDao(user, pogUsers, null);
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();
    customerProducts.addAll(user.getCustomerProducts());

    MockCustomerProductService customerProductService = new MockCustomerProductService(null, customerProducts);
    DistributorService service = new DistributorServiceImpl(pogUserDao, customerProductService, null);
    PogUser userWithBudget = service.lookupDistributorWithBudgetData(user, 2010L, 8L, "EN");

    assertEquals(2010L, customerProductService.getStartYear().longValue());
    assertEquals(8L, customerProductService.getStartMonth().longValue());
    assertEquals(2011L, customerProductService.getEndYear().longValue());
    assertEquals(7L, customerProductService.getEndMonth().longValue());
    assertTrue(user.equals(customerProductService.getDistributor()));

    assertEquals(11L, userWithBudget.getId().longValue());
    assertEquals("name 1", userWithBudget.getFirstName()); //not going to sap for details
    assertEquals("1234", userWithBudget.getSapId());
    assertNull(userWithBudget.getAddress1());
    assertNull(userWithBudget.getAddress2());
    assertNull(userWithBudget.getPostalCode());
    Contact contact = userWithBudget.getContacts().iterator().next();
    assertNull(contact.getEmail());
    assertEquals("contact name 1", contact.getName());
    assertEquals("contact phone 1", contact.getPhone());
    assertNull(contact.getFax());
    assertEquals(0, userWithBudget.getChildUsers().size());

    Collection<CustomerProduct> level1CustomerProducts = userWithBudget.getCustomerProducts();
    assertEquals(3, level1CustomerProducts.size());
    Iterator<CustomerProduct> customerProductIterator = level1CustomerProducts.iterator();
    CustomerProduct level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals(41L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    Collection<CustomerTransaction> transactions = level1CustomerProduct.getCustomerTransactions();
    assertEquals(2, transactions.size());
    Iterator<CustomerTransaction> customerTransactionIterator = transactions.iterator();
    CustomerTransaction customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(8L, customerTransaction.getMonth().longValue());
    assertEquals(34.45, customerTransaction.getFinalInventory());
    assertEquals(234.34, customerTransaction.getSalesAmount());
    assertEquals(56.45, customerTransaction.getBudget());
    customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(7L, customerTransaction.getMonth().longValue());
    assertEquals(43.45, customerTransaction.getFinalInventory());
    assertEquals(243.34, customerTransaction.getSalesAmount());
    assertEquals(65.45, customerTransaction.getBudget());
    assertNull(customerTransaction.getCustomerProduct());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals(42L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("LB", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Pound", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA23456", level1CustomerProduct.getProduct().getCode());
    assertEquals(43L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("GAL", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Gallon", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
  }

  @Test
  public void testLookupDistributorWithBudgetData_MonthIs1_Level1Distributor() throws Exception {
    List<PogUser> pogUsers = getMockDistributors();
    PogUser user = pogUsers.iterator().next();
    MockPogUserDao pogUserDao = new MockPogUserDao(user, pogUsers, null);
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();
    customerProducts.addAll(user.getCustomerProducts());

    MockCustomerProductService customerProductService = new MockCustomerProductService(null, customerProducts);
    DistributorService service = new DistributorServiceImpl(pogUserDao, customerProductService, null);
    PogUser userWithBudget = service.lookupDistributorWithBudgetData(user, 2010L, 1L, "EN");

    assertEquals(2010L, customerProductService.getStartYear().longValue());
    assertEquals(1L, customerProductService.getStartMonth().longValue());
    assertEquals(2010L, customerProductService.getEndYear().longValue());
    assertEquals(12L, customerProductService.getEndMonth().longValue());
    assertTrue(user.equals(customerProductService.getDistributor()));

    assertEquals(11L, userWithBudget.getId().longValue());
    assertEquals("name 1", userWithBudget.getFirstName()); //not going to sap for details
    assertEquals("1234", userWithBudget.getSapId());
    assertNull(userWithBudget.getAddress1());
    assertNull(userWithBudget.getAddress2());
    assertNull(userWithBudget.getPostalCode());
    Contact contact = userWithBudget.getContacts().iterator().next();
    assertNull(contact.getEmail());
    assertEquals("contact name 1", contact.getName());
    assertEquals("contact phone 1", contact.getPhone());
    assertNull(contact.getFax());
    assertEquals(0, userWithBudget.getChildUsers().size());

    Collection<CustomerProduct> level1CustomerProducts = userWithBudget.getCustomerProducts();
    assertEquals(3, level1CustomerProducts.size());
    Iterator<CustomerProduct> customerProductIterator = level1CustomerProducts.iterator();
    CustomerProduct level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals(41L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    Collection<CustomerTransaction> transactions = level1CustomerProduct.getCustomerTransactions();
    assertEquals(2, transactions.size());
    Iterator<CustomerTransaction> customerTransactionIterator = transactions.iterator();
    CustomerTransaction customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(8L, customerTransaction.getMonth().longValue());
    assertEquals(34.45, customerTransaction.getFinalInventory());
    assertEquals(234.34, customerTransaction.getSalesAmount());
    assertEquals(56.45, customerTransaction.getBudget());
    customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(7L, customerTransaction.getMonth().longValue());
    assertEquals(43.45, customerTransaction.getFinalInventory());
    assertEquals(243.34, customerTransaction.getSalesAmount());
    assertEquals(65.45, customerTransaction.getBudget());
    assertNull(customerTransaction.getCustomerProduct());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals(42L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("LB", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Pound", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA23456", level1CustomerProduct.getProduct().getCode());
    assertEquals(43L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("GAL", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Gallon", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
  }

  @Test
  public void testLookupDistributorWithBudgetData_NonLevel1Distributor() throws Exception {
    List<PogUser> pogUsers = getMockDistributors();
    PogUser user = pogUsers.iterator().next();
    user.setParentUser(new PogUser());
    MockPogUserDao pogUserDao = new MockPogUserDao(user, pogUsers, null);
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();
    customerProducts.addAll(user.getCustomerProducts());

    MockCustomerProductService customerProductService = new MockCustomerProductService(null, customerProducts);
    DistributorService service = new DistributorServiceImpl(pogUserDao, customerProductService,
        null);
    PogUser userWithBudget = service.lookupDistributorWithBudgetData(user, 2010L, 8L, "en");

    assertEquals(2010L, customerProductService.getStartYear().longValue());
    assertEquals(8L, customerProductService.getStartMonth().longValue());
    assertEquals(2011L, customerProductService.getEndYear().longValue());
    assertEquals(7L, customerProductService.getEndMonth().longValue());
    assertTrue(user.equals(customerProductService.getDistributor()));

    assertEquals(11L, userWithBudget.getId().longValue());
    assertEquals("name 1", userWithBudget.getFirstName());
    assertEquals(0, userWithBudget.getChildUsers().size());

    Collection<CustomerProduct> level1CustomerProducts = userWithBudget.getCustomerProducts();
    assertEquals(3, level1CustomerProducts.size());
    Iterator<CustomerProduct> customerProductIterator = level1CustomerProducts.iterator();
    CustomerProduct level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals(41L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    Collection<CustomerTransaction> transactions = level1CustomerProduct.getCustomerTransactions();
    assertEquals(2, transactions.size());
    Iterator<CustomerTransaction> customerTransactionIterator = transactions.iterator();
    CustomerTransaction customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(8L, customerTransaction.getMonth().longValue());
    assertEquals(34.45, customerTransaction.getFinalInventory());
    assertEquals(234.34, customerTransaction.getSalesAmount());
    assertEquals(56.45, customerTransaction.getBudget());
    customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(7L, customerTransaction.getMonth().longValue());
    assertEquals(43.45, customerTransaction.getFinalInventory());
    assertEquals(243.34, customerTransaction.getSalesAmount());
    assertEquals(65.45, customerTransaction.getBudget());
    assertNull(customerTransaction.getCustomerProduct());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals(42L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("LB", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Pound", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA23456", level1CustomerProduct.getProduct().getCode());
    assertEquals(43L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("GAL", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Gallon", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
  }

  @Test
  public void testLookupDistributorAndSalesData_Level1Distributor() throws Exception {
    List<PogUser> pogUsers = getMockDistributors();
    PogUser user = pogUsers.iterator().next();

    PogUser parent1 = new PogUser();
    ArrayList<CustomerProduct> parent1CPs = new ArrayList<CustomerProduct>();
    parent1CPs.add(new CustomerProduct());
    parent1CPs.add(new CustomerProduct());
    parent1.setCustomerProducts(parent1CPs);
    parent1.setUserAreas(user.getUserAreas());
    Collection<PogUser> parent1Children = new ArrayList<PogUser>();
    parent1Children.add(new PogUser());
    parent1Children.add(new PogUser());
    parent1Children.add(user);
    parent1.setChildUsers(parent1Children);
    user.setParentUser(parent1);

    PogUser parent11 = new PogUser();
    ArrayList<CustomerProduct> parent11CPs = new ArrayList<CustomerProduct>();
    parent11CPs.add(new CustomerProduct());
    parent11CPs.add(new CustomerProduct());
    parent11.setCustomerProducts(parent1CPs);
    parent11.setUserAreas(user.getUserAreas());
    Collection<PogUser> parent11Children = new ArrayList<PogUser>();
    parent11Children.add(new PogUser());
    parent11Children.add(new PogUser());
    parent11Children.add(parent1);
    parent11.setChildUsers(parent11Children);
    parent1.setParentUser(parent11);

    MockPogUserDao pogUserDao = new MockPogUserDao(user, pogUsers, null);
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();
    customerProducts.addAll(user.getCustomerProducts());

    MockCustomerProductService customerProductService = new MockCustomerProductService(null, customerProducts);
    DistributorService service = new DistributorServiceImpl(pogUserDao, customerProductService, null);
    PogUser userWithBudget = service.lookupDistributorWithSalesData(user, 2010L, 8L, "en");

    PogUser parentUser1 = userWithBudget.getParentUser();
    assertEquals(1, parentUser1.getChildUsers().size());
    assertEquals(0, parentUser1.getCustomerProducts().size());
    assertEquals(1, parentUser1.getParentUser().getChildUsers().size());
    assertEquals(0, parentUser1.getParentUser().getCustomerProducts().size());

    assertEquals(2010L, customerProductService.getYear().longValue());
    assertEquals(8L, customerProductService.getMonth().longValue());
    assertNull(customerProductService.getEndYear());
    assertNull(customerProductService.getEndMonth());

    assertEquals(11L, userWithBudget.getId().longValue());
    assertEquals("name 1", userWithBudget.getFirstName());
    assertEquals("1234", userWithBudget.getSapId());
    assertNull(userWithBudget.getAddress1());
    assertNull(userWithBudget.getAddress1());
    assertNull(userWithBudget.getAddress2());
    assertNull(userWithBudget.getProvince());
    assertNull(userWithBudget.getPostalCode());

    Contact contact = userWithBudget.getContacts().iterator().next();
    assertNull(contact.getEmail());
    assertEquals("contact name 1", contact.getName());
    assertEquals("contact phone 1", contact.getPhone());
    assertNull(contact.getFax());

    Collection<PogUser> childUsers = userWithBudget.getChildUsers();
    assertEquals(1, childUsers.size());
    PogUser childUser = childUsers.iterator().next();
    Collection<CustomerProduct> childCustomerProducts = childUser.getCustomerProducts();
    assertEquals(1, childCustomerProducts.size()); //child transactions are filtered
    CustomerProduct childCustomerProduct = childCustomerProducts.iterator().next();
    //child SapProduct details are not populated
    assertEquals("AA12345", childCustomerProduct.getProduct().getCode());
    assertEquals(41L, childCustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", childCustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", childCustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
    assertEquals(0, childCustomerProduct.getCustomerTransactions().size());//child transactions are filtered

    Collection<PogUser> grranChildUsers = childUser.getChildUsers();
    assertEquals(1, grranChildUsers.size());
    PogUser grandChildUser = grranChildUsers.iterator().next();
    Collection<CustomerProduct> grandCustomerProducts = grandChildUser.getCustomerProducts();
    assertEquals(1, grandCustomerProducts.size());
    CustomerProduct grandCustomerProduct = grandCustomerProducts.iterator().next();
    assertEquals("AA12345", childCustomerProduct.getProduct().getCode());
    assertEquals(41L, grandCustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", grandCustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", grandCustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
    assertEquals(0, grandCustomerProduct.getCustomerTransactions().size());//child transactions are filtered

    Collection<CustomerProduct> level1CustomerProducts = userWithBudget.getCustomerProducts();
    assertEquals(3, level1CustomerProducts.size());
    Iterator<CustomerProduct> customerProductIterator = level1CustomerProducts.iterator();
    CustomerProduct level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", childCustomerProduct.getProduct().getCode());
    assertEquals(41L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    Collection<CustomerTransaction> transactions = level1CustomerProduct.getCustomerTransactions();
    assertEquals(2, transactions.size());
    Iterator<CustomerTransaction> customerTransactionIterator = transactions.iterator();
    CustomerTransaction customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(8L, customerTransaction.getMonth().longValue());
    assertEquals(34.45, customerTransaction.getFinalInventory());
    assertEquals(234.34, customerTransaction.getSalesAmount());
    assertEquals(56.45, customerTransaction.getBudget());
    customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(7L, customerTransaction.getMonth().longValue());
    assertEquals(43.45, customerTransaction.getFinalInventory());
    assertEquals(243.34, customerTransaction.getSalesAmount());
    assertEquals(65.45, customerTransaction.getBudget());
    assertNull(customerTransaction.getCustomerProduct());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals(42L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("LB", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Pound", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA23456", level1CustomerProduct.getProduct().getCode());
    assertEquals(43L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("GAL", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Gallon", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
  }

  @Test
  public void testLookupDistributorAndSalesData_NonLevel1Distributor() throws Exception {
    List<PogUser> pogUsers = getMockDistributors();
    PogUser user = pogUsers.iterator().next();
    PogUser parent = new PogUser();
    Collection<PogUser> parentsChildren = new ArrayList<PogUser>();
    parentsChildren.add(new PogUser());
    parentsChildren.add(new PogUser());
    parent.setChildUsers(parentsChildren);
    user.setParentUser(parent);
    MockPogUserDao pogUserDao = new MockPogUserDao(user, pogUsers, null);
    Collection<CustomerProduct> customerProducts = new ArrayList<CustomerProduct>();
    customerProducts.addAll(user.getCustomerProducts());

    MockCustomerProductService customerProductService = new MockCustomerProductService(null, customerProducts);
    DistributorService service = new DistributorServiceImpl(pogUserDao, customerProductService,
        null);
    PogUser userWithSalesData = service.lookupDistributorWithSalesData(user, 2010L, 8L, "en");

    assertEquals(2010L, customerProductService.getYear().longValue());
    assertEquals(8L, customerProductService.getMonth().longValue());
    assertNull(customerProductService.getEndYear());
    assertNull(customerProductService.getEndMonth());

    assertEquals(11L, userWithSalesData.getId().longValue());
    assertEquals("name 1", userWithSalesData.getFirstName());
    assertEquals(1, userWithSalesData.getParentUser().getChildUsers().size());
    assertEquals(0, userWithSalesData.getParentUser().getCustomerProducts().size());

    Collection<PogUser> childUsers = userWithSalesData.getChildUsers();
    assertEquals(1, childUsers.size());
    PogUser childUser = childUsers.iterator().next();
    Collection<CustomerProduct> childCustomerProducts = childUser.getCustomerProducts();
    assertEquals(1, childCustomerProducts.size()); //child transactions are filtered
    CustomerProduct childCustomerProduct = childCustomerProducts.iterator().next();
    //child SapProduct details are not populated
    assertEquals("AA12345", childCustomerProduct.getProduct().getCode());
    assertEquals(41L, childCustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", childCustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", childCustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
    assertEquals(0, childCustomerProduct.getCustomerTransactions().size());//child transactions are filtered

    Collection<PogUser> grranChildUsers = childUser.getChildUsers();
    assertEquals(1, grranChildUsers.size());
    PogUser grandChildUser = grranChildUsers.iterator().next();
    Collection<CustomerProduct> grandCustomerProducts = grandChildUser.getCustomerProducts();
    assertEquals(1, grandCustomerProducts.size());
    CustomerProduct grandCustomerProduct = grandCustomerProducts.iterator().next();
    assertEquals("AA12345", childCustomerProduct.getProduct().getCode());
    assertEquals(41L, grandCustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", grandCustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", grandCustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
    assertEquals(0, grandCustomerProduct.getCustomerTransactions().size());//child transactions are filtered

    Collection<CustomerProduct> level1CustomerProducts = userWithSalesData.getCustomerProducts();
    assertEquals(3, level1CustomerProducts.size());
    Iterator<CustomerProduct> customerProductIterator = level1CustomerProducts.iterator();
    CustomerProduct level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", childCustomerProduct.getProduct().getCode());
    assertEquals(41L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("L", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Liter", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    Collection<CustomerTransaction> transactions = level1CustomerProduct.getCustomerTransactions();
    assertEquals(2, transactions.size());
    Iterator<CustomerTransaction> customerTransactionIterator = transactions.iterator();
    CustomerTransaction customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(8L, customerTransaction.getMonth().longValue());
    assertEquals(34.45, customerTransaction.getFinalInventory());
    assertEquals(234.34, customerTransaction.getSalesAmount());
    assertEquals(56.45, customerTransaction.getBudget());
    customerTransaction = customerTransactionIterator.next();
    assertEquals(2010L, customerTransaction.getYear().longValue());
    assertEquals(7L, customerTransaction.getMonth().longValue());
    assertEquals(43.45, customerTransaction.getFinalInventory());
    assertEquals(243.34, customerTransaction.getSalesAmount());
    assertEquals(65.45, customerTransaction.getBudget());
    assertNull(customerTransaction.getCustomerProduct());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA12345", level1CustomerProduct.getProduct().getCode());
    assertEquals(42L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("LB", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Pound", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());

    level1CustomerProduct = customerProductIterator.next();
    assertEquals("AA23456", level1CustomerProduct.getProduct().getCode());
    assertEquals(43L, level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getId().longValue());
    assertEquals("GAL", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getCode());
    assertEquals("Gallon", level1CustomerProduct.getProduct().getBaseUnitOfMeasure().getDescription());
  }

  @Test
  public void testLookupAllLevel1DistributorsByAreaFromMasterData() throws Exception {
    List<PogUser> users = new ArrayList<PogUser>();
    PogUser user1 = new PogUser();
    user1.setFirstName("first 1");
    user1.setLastName("last 1");
    users.add(user1);
    PogUser user2 = new PogUser();
    user2.setFirstName("first 4");
    user2.setLastName("last 4");
    users.add(user2);
  //  MockPogUserDao pogUserDao = new MockPogUserDao(null, users, null);

    Collection<PogUser> sapUsers = new ArrayList<PogUser>();
    PogUser sapUser1 = new PogUser();
    sapUser1.setFirstName("first 1");
    sapUser1.setLastName("last 1");
    sapUsers.add(sapUser1);
    PogUser sapUser2 = new PogUser();
    sapUser2.setFirstName("first 2");
    sapUser2.setLastName("last 2");
    sapUsers.add(sapUser2);
    PogUser sapUser3 = new PogUser();
    sapUser3.setFirstName("first 3");
    sapUser3.setLastName("last 3");
    sapUsers.add(sapUser3);
    DistributorService service = new DistributorServiceImpl(pogUserDao, null, null);
    Collection<Area> areas = new ArrayList<Area>();
    Area area1 = new Area();
    area1.setAreaCode("ES");
    areas.add(area1);
    Area area2 = new Area();
    area2.setAreaCode("UK");
    areas.add(area2);
    Collection<PogUser> level1Distributors = service.lookupAvailableLevel1DistributorsByCountryCode(areas);
      if(null != level1Distributors)
            assertTrue(level1Distributors.size()>2);
  }
}
