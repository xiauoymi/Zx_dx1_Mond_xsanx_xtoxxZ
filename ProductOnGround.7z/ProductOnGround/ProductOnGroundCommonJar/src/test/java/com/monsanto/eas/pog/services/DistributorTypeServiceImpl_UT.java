package com.monsanto.eas.pog.services;


import com.monsanto.eas.pog.dao.mock.MockDistributorTypeDao;
import com.monsanto.eas.pog.model.hibernate.DistributorType;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: sspati1
 * Date: 2/28/11
 * Time: 1:40 PM
 * To change this template use File | Settings | File Templates.
 */
public class DistributorTypeServiceImpl_UT extends TestCase {
    @Test
    public void testLookupAll() throws Exception {
        Collection<DistributorType> mockTypes = new ArrayList<DistributorType>();
        mockTypes.add(new DistributorType());
        mockTypes.add(new DistributorType());
        DistributorTypeService service = new DistributorTypeServiceImpl(new MockDistributorTypeDao(null, mockTypes));
        Collection<DistributorType> types = service.lookupAll();
        assertEquals(2, types.size());
    }
}
