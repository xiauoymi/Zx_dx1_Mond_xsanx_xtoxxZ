/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.mock.MockDistributorTypeDao;
import com.monsanto.eas.pog.model.hibernate.DistributorType;
import com.monsanto.eas.pog.model.hibernate.Language;
import com.monsanto.eas.pog.services.mock.MockLanguageDao;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class LanguageServiceImpl_UT extends TestCase {
  @Test
  public void testLookupAll() throws Exception {
    Collection<Language> lans = new ArrayList<Language>();
    lans.add(new Language());
    lans.add(new Language());
    LanguageService service = new LanguageServiceImpl(new MockLanguageDao(null, lans));
    Collection<Language> types = service.lookupAll();
    assertEquals(2, types.size());
  }
}