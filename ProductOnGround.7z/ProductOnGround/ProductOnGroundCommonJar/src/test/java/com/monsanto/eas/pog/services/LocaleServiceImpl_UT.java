package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.mock.MockLocaleDao;
import com.monsanto.eas.pog.model.hibernate.Locale;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jun 25, 2010 Time: 11:45:48 AM To change this template use File |
 * Settings | File Templates.
 */
public class LocaleServiceImpl_UT extends TestCase {

  @Test
  public void testLookupAllLocales() throws Exception {
    Collection<Locale> mockLocales = new ArrayList<Locale>();
    mockLocales.add(new Locale());
    mockLocales.add(new Locale());
    MockLocaleDao mockLocaleDao = new MockLocaleDao(null, mockLocales);
    LocaleService service = new LocaleServiceImpl(mockLocaleDao);
    Collection<Locale> locales = service.lookupAll();
    assertEquals(2, locales.size());
    assertEquals("locale", mockLocaleDao.getKey());
    assertTrue(mockLocaleDao.isAscending());
  }

  @Test
  public void testLookupByLocale_Found() throws Exception {
    Collection<Locale> mockLocales = new ArrayList<Locale>();
    Locale locale1 = new Locale();
    locale1.setId(11L);
    mockLocales.add(locale1);
    mockLocales.add(new Locale());
    MockLocaleDao mockLocaleDao = new MockLocaleDao(null, mockLocales);
    LocaleService service = new LocaleServiceImpl(mockLocaleDao);
    Locale locale = service.lookupByLocale("ES");
    assertEquals(11L, locale.getId().longValue());

    Locale exampleLocale = mockLocaleDao.getExampleInstance();
    assertEquals("ES", exampleLocale.getLocale());
    assertEquals(0, mockLocaleDao.getExcludeProperty().length);
  }

  @Test
  public void testLookupByLocale_NotFound() throws Exception {
    Collection<Locale> mockLocales = new ArrayList<Locale>();
    MockLocaleDao mockLocaleDao = new MockLocaleDao(null, mockLocales);
    LocaleService service = new LocaleServiceImpl(mockLocaleDao);
    Locale locale = service.lookupByLocale("ES");
    assertNull(locale);
  }
}
