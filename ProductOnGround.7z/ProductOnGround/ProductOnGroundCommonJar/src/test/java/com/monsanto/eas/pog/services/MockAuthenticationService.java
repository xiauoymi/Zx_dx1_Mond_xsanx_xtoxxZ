package com.monsanto.eas.pog.services;

import org.springframework.security.Authentication;
import org.springframework.security.providers.UsernamePasswordAuthenticationToken;

import java.security.Principal;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 19, 2010 Time: 12:05:36 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockAuthenticationService extends AuthenticationServiceImpl {
  private UsernamePasswordAuthenticationToken authentication;
  private Principal flexPrincipal;

  public MockAuthenticationService(UsernamePasswordAuthenticationToken authentication, Principal flexPrincipal) {
    this.authentication = authentication;
    this.flexPrincipal = flexPrincipal;
  }

  @Override
  protected Authentication getAuthentication(String username, String password) {
    return authentication;
  }

  @Override
  protected Principal getFlexPrincipal() {
    return flexPrincipal;
  }
}
