/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.ProductCodeDao;
import com.monsanto.eas.pog.dao.mock.MockProductCodeDao;
import com.monsanto.eas.pog.model.hibernate.LanguageProduct;
import com.monsanto.eas.pog.model.hibernate.ProductCode;
import junit.framework.TestCase;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class ProductCodeServiceImpl_UT extends TestCase {
    @Autowired
    ProductCodeService service;
    ProductCode productCode = null;
    Collection<LanguageProduct> languageProducts = null;

   @Before
   public void setUp()throws Exception{
        productCode = new ProductCode();
        productCode.setId(1790255L);
        productCode.setCode("AA124117E02GB9");
        productCode.setModDate(new Date(System.currentTimeMillis()));
        productCode.setModUser("BW");
        productCode.setLanguageProducts(languageProducts);
    }


  @Test
  public void testLookupProductsByAreaId() {
    Collection<ProductCode> productCodes = new ArrayList<ProductCode>();
    ProductCode productCode = new ProductCode();
    productCode.setId(1L);
    productCode.setCode("prod 1");
    productCodes.add(productCode);
    productCodes.add(new ProductCode());
    ProductCodeDao productCodeDao = new MockProductCodeDao(productCodes);
    ProductCodeService service = new ProductCodeServiceImpl(productCodeDao);
    Collection<ProductCode> products = service.lookupProductsByAreaId(40L);
    assertNotNull(products);
    assertEquals(2, products.size());
    assertEquals(1L, products.iterator().next().getId().longValue());
    assertEquals("prod 1", products.iterator().next().getCode());
  }

  @Test
  public void testLookupAllProductCodes() {
    Collection<ProductCode> products = new ArrayList<ProductCode>();
    products.add(new ProductCode());
    products.add(new ProductCode());
    MockProductCodeDao productCodeDao = new MockProductCodeDao(products);
    ProductCodeService service = new ProductCodeServiceImpl(productCodeDao);
    Collection<ProductCode> productCollection = service.lookupAllProductsCodes();
    assertEquals(2, productCollection.size());
  }

 @Test
  public void testSaveOrUpdate() {
       //ProductCodeService service = new ProductCodeServiceImpl();
       service.saveOrUpdate(productCode);
  }

}