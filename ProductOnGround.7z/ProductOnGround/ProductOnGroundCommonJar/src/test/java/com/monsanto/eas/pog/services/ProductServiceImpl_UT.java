package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.ProductDao;
import com.monsanto.eas.pog.dao.mock.MockProductDao;
import com.monsanto.eas.pog.model.UserAreaPk;
import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Jan 27, 2011 Time: 2:18:09 PM To change this template use File |
 * Settings | File Templates.
 */
public class ProductServiceImpl_UT extends TestCase {

  @Test
  public void testLookupAllProducts() {
    Collection<Product> products = new ArrayList<Product>();
    products.add(new Product());
    products.add(new Product());
    MockProductDao productDao = new MockProductDao(null, products);
    ProductService service = new ProductServiceImpl(productDao);
    Collection<Product> productCollection = service.lookupAllProducts();
    assertEquals(2, productCollection.size());
    assertEquals("level", productDao.getKey());
    assertTrue(productDao.isAscending());
  }

  @Test
  public void testLookupById() {
    Product mockProduct = new Product();
    mockProduct.setId(1L);
    MockProductDao productDao = new MockProductDao(mockProduct, null);
    ProductService service = new ProductServiceImpl(productDao);
    Product product = service.lookupById(1L);
    assertNotNull(product);
    assertEquals(1L, product.getId().longValue());
  }

  @Test
  public void testLookupByLevel() {
    Collection<Product> products = new ArrayList<Product>();
    products.add(new Product());
    products.add(new Product());
    MockProductDao productDao = new MockProductDao(null, products);
    ProductService service = new ProductServiceImpl(productDao);
    Collection<Product> productCollection = service.lookupBySalesRepUserId("testId");
    assertEquals(2, productCollection.size());
    assertEquals("testId", productDao.getSalesRepUserId());
  }

  @Test
  public void testGetProductByCodeAndBaseUom() {
    Product mockProduct = new Product();
    mockProduct.setId(1L);
    ProductDao productDao = new MockProductDao(mockProduct, null);
    ProductService service = new ProductServiceImpl(productDao);
    Product product = service.lookupByCodeBaseUomIdAndMaterialId("testCode", 40L, null);
    assertNotNull(product);
    assertEquals(1L, product.getId().longValue());
  }

  @Test
  public void testSaveOrUpdate() {
    Product mockProduct = new Product();
    mockProduct.setId(1L);
    ProductDao productDao = new MockProductDao(null, null);
    ProductService service = new ProductServiceImpl(productDao);
    Product product = service.saveOrUpdate(mockProduct);
    assertNotNull(product);
    assertEquals(1L, product.getId().longValue());
  }
}
