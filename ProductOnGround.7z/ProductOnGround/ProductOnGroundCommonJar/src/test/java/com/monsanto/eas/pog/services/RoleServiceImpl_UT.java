package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.mock.MockRoleDao;
import com.monsanto.eas.pog.model.hibernate.Role;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 27, 2010 Time: 9:39:00 AM To change this template use File |
 * Settings | File Templates.
 */
public class RoleServiceImpl_UT extends TestCase {

  @Test
  public void testLookupAllRoles() throws Exception {
    Collection<Role> mockRoles = new ArrayList<Role>();
    mockRoles.add(new Role());
    mockRoles.add(new Role());
    RoleService service = new RoleServiceImpl(new MockRoleDao(null, mockRoles));
    Collection<Role> roles = service.lookupAll();
    assertEquals(2, roles.size());
  }
}
