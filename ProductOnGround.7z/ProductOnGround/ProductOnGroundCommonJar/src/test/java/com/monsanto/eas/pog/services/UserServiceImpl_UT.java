package com.monsanto.eas.pog.services;

import com.monsanto.eas.pog.dao.PogUserDao;
import com.monsanto.eas.pog.dao.exception.UserNotFoundException;
import com.monsanto.eas.pog.dao.mock.MockPogUserDao;
import com.monsanto.eas.pog.model.hibernate.*;
import junit.framework.TestCase;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: May 27, 2010 Time: 10:55:55 AM To change this template use File |
 * Settings | File Templates.
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/dao-test-config.xml"})
@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
@Transactional
public class UserServiceImpl_UT extends TestCase {

  @Autowired
  PogUserDao pogUserDao = null;

  @Test
  public void testSaveOrUpdate_Update() throws Exception {
    PogUser pogUser = new PogUser();
    pogUser.setId(123L);
    Calendar calendar = Calendar.getInstance();
    calendar.add(Calendar.DATE, -1);
    Date modDate = calendar.getTime();
    pogUser.setModDate(modDate);
    PogUserDao pogUserDao = new MockPogUserDao(pogUser, null, null);
    UserService service = new UserServiceImpl(pogUserDao);
    PogUser updatedUser = service.saveOrUpdate(pogUser);
    assertEquals(123L, updatedUser.getId().longValue());
    assertTrue(updatedUser.getModDate().after(modDate));
  }

  @Test
  public void testSaveOrUpdate_Save() throws Exception {
    PogUser pogUser = new PogUser();
    Calendar calendar = Calendar.getInstance();
    calendar.add(Calendar.DATE, -1);
    Date modDate = calendar.getTime();
    pogUser.setModDate(modDate);
    PogUserDao pogUserDao = new MockPogUserDao(null, null, null);
    UserService service = new UserServiceImpl(pogUserDao);
    PogUser updatedUser = service.saveOrUpdate(pogUser);
    assertEquals(123L, updatedUser.getId().longValue());
    assertTrue(updatedUser.getModDate().after(modDate));
  }

  @Test
  public void testLookupAllInternalUsersForAssociatedAreas() throws Exception {
    List<PogUser> users = new ArrayList<PogUser>();
    users.add(new PogUser());
    users.add(new PogUser());
    PogUserDao pogUserDao = new MockPogUserDao(null, users, null);
    UserService service = new UserServiceImpl(pogUserDao);
    PogUser pogUser = new PogUser();
    Collection<PogUser> pogUsers = service.lookupAllInternalUsersForAssociatedAreas(pogUser);
    assertEquals(2, pogUsers.size());
  }

  @Test
  public void testSync_UserNotFoundOnServer_SavesNewUser() throws Exception {
    //PogUserDao pogUserDao = new MockPogUserDao(null, null, null);
    UserService service = new UserServiceImpl(pogUserDao);
    PogUser clientUser = new PogUser();
    clientUser.setUserId("NotFound");
    clientUser.setSapId("0003374636");
    clientUser.setModUser("BW");

    Collection<CustomerProduct> clientCustomerProducts = new ArrayList<CustomerProduct>();
    CustomerProduct customerProduct = new CustomerProduct();
    Product product1 = new Product();
    product1.setMaterialId("MaterialId1");
    ProductCode productCode1 = new ProductCode();
    productCode1.setCode("AA123");
    product1.setProductCode(productCode1);
     BaseUnitOfMeasure baseUom = new BaseUnitOfMeasure();
    baseUom.setCode("L");
    product1.setBaseUnitOfMeasure(baseUom);
    customerProduct.setProduct(product1);
    customerProduct.setModDate(new Date(System.currentTimeMillis()));
    customerProduct.setModUser("clientModUser");
    clientCustomerProducts.add(customerProduct);
    clientUser.setCustomerProducts(clientCustomerProducts);
    PogUser user = service.syncronize(clientUser);
    assertTrue(user.getId().longValue()>=123L);
    assertNotSame("newUserId", user.getUserId());
  }

  @Test
  public void testSync_UserFoundOnServer_NewTransactionOnClient_CopiesSalesFromClientToServer() throws Exception {
    PogUser clientUser = new PogUser();
    clientUser.setId(123L);
    clientUser.setUserId("testId1");
    Date clientModDate = new Date();
    clientUser.setModDate(clientModDate);
    clientUser.setSapId("0003374636");
    clientUser.setModUser("clientModUser");
    clientUser.setId(11L);
    Collection<CustomerProduct> clientCustomerProducts = new ArrayList<CustomerProduct>();

    BaseUnitOfMeasure baseUom = new BaseUnitOfMeasure();
    baseUom.setCode("L");
    CustomerProduct customerProduct = new CustomerProduct();
    Product product1 = new Product();
    product1.setMaterialId("MaterialId1");
    ProductCode productCode1 = new ProductCode();
    productCode1.setCode("AA123");
    product1.setProductCode(productCode1);
    product1.setBaseUnitOfMeasure(baseUom);
    customerProduct.setProduct(product1);
    customerProduct.setModDate(clientModDate);
    customerProduct.setModUser("clientModUser");
    Collection<CustomerTransaction> customerTransactions = new ArrayList<CustomerTransaction>();
    CustomerTransaction customerTransaction = new CustomerTransaction();
    customerTransaction.setYear(2010L);
    customerTransaction.setMonth(3L);
    customerTransaction.setBudget(111.0);
    customerTransaction.setFinalInventory(222.0);
    customerTransaction.setSalesAmount(333.3);
    customerTransaction.setModDate(clientModDate);
    customerTransaction.setModUser("clientModUser");
    customerTransactions.add(customerTransaction);
    customerTransaction = new CustomerTransaction();
    customerTransaction.setYear(2011L);
    customerTransaction.setMonth(4L);
    customerTransaction.setBudget(114.0);
    customerTransaction.setFinalInventory(224.0);
    customerTransaction.setSalesAmount(334.3);
    customerTransaction.setModDate(clientModDate);
    customerTransaction.setModUser("clientModUser");
    customerTransactions.add(customerTransaction);
    customerProduct.setCustomerTransactions(customerTransactions);
    clientCustomerProducts.add(customerProduct);

    customerProduct = new CustomerProduct();
    Product product2 = new Product();
    ProductCode productCode2 = new ProductCode();
    productCode2.setCode("AA124");
    product2.setProductCode(productCode2);
    product2.setBaseUnitOfMeasure(baseUom);
    customerProduct.setProduct(product2);
    baseUom = new BaseUnitOfMeasure();
    baseUom.setCode("L");
    customerProduct.setModDate(clientModDate);
    customerProduct.setModUser("clientModUser");
    customerTransactions = new ArrayList<CustomerTransaction>();
    customerTransaction = new CustomerTransaction();
    customerTransaction.setYear(2009L);
    customerTransaction.setMonth(4L);
    customerTransaction.setBudget(444.0);
    customerTransaction.setFinalInventory(555.0);
    customerTransaction.setSalesAmount(666.6);
    customerTransaction.setModDate(clientModDate);
    customerTransaction.setModUser("clientModUser");
    customerTransactions.add(customerTransaction);
    customerProduct.setCustomerTransactions(customerTransactions);
    clientCustomerProducts.add(customerProduct);

    clientUser.setCustomerProducts(clientCustomerProducts);

    PogUser serverUser = new PogUser();
    serverUser.setId(1L);
    serverUser.setUserId("testId1");
    Date serverModDate = new Date();
    serverUser.setModDate(serverModDate);
    serverUser.setModUser("serverModUser");
    serverUser.setId(111L);
    Collection<CustomerProduct> serverCustomerProducts = new ArrayList<CustomerProduct>();

    CustomerProduct serverCustomerProduct = new CustomerProduct();
    serverCustomerProduct.setProduct(product1);
    baseUom = new BaseUnitOfMeasure();
    baseUom.setCode("L");
    serverCustomerProduct.setModDate(serverModDate);
    serverCustomerProduct.setModUser("serverModUser");
    Collection<CustomerTransaction> serverCustomerTransactions = new ArrayList<CustomerTransaction>();
    CustomerTransaction serverCustomerTransaction = new CustomerTransaction();
    serverCustomerTransaction.setYear(2010L);
    serverCustomerTransaction.setMonth(3L);
    serverCustomerTransaction.setBudget(145.0);
    serverCustomerTransaction.setFinalInventory(245.0);
    serverCustomerTransaction.setSalesAmount(345.3);
    serverCustomerTransaction.setModDate(serverModDate);
    serverCustomerTransaction.setModUser("serverModUser");
    serverCustomerTransactions.add(serverCustomerTransaction);

    serverCustomerTransaction = new CustomerTransaction();
    serverCustomerTransaction.setYear(2010L);
    serverCustomerTransaction.setMonth(4L);
    serverCustomerTransaction.setBudget(122.0);
    serverCustomerTransaction.setFinalInventory(233.0);
    serverCustomerTransaction.setSalesAmount(343.3);
    serverCustomerTransaction.setModDate(serverModDate);
    serverCustomerTransaction.setModUser("serverModUser");
    serverCustomerTransactions.add(serverCustomerTransaction);
    serverCustomerProduct.setCustomerTransactions(serverCustomerTransactions);
    serverCustomerProducts.add(serverCustomerProduct);

    serverCustomerProduct = new CustomerProduct();
    baseUom = new BaseUnitOfMeasure();
    baseUom.setCode("L");
    Product product3 = new Product();
    product3.setMaterialId("MaterialId3");
    ProductCode productCode3 = new ProductCode();
    productCode3.setCode("AA125");
    product3.setProductCode(productCode3);
    product3.setBaseUnitOfMeasure(baseUom);
    serverCustomerProduct.setProduct(product3);
    serverCustomerProduct.setModDate(serverModDate);
    serverCustomerProduct.setModUser("serverModUser");
    serverCustomerTransactions = new ArrayList<CustomerTransaction>();
    serverCustomerTransaction = new CustomerTransaction();
    serverCustomerTransaction.setYear(2009L);
    serverCustomerTransaction.setMonth(4L);
    serverCustomerTransaction.setBudget(423.0);
    serverCustomerTransaction.setFinalInventory(523.0);
    serverCustomerTransaction.setSalesAmount(623.6);
    serverCustomerTransaction.setModDate(serverModDate);
    serverCustomerTransaction.setModUser("serverModUser");
    serverCustomerTransactions.add(serverCustomerTransaction);
    serverCustomerProduct.setCustomerTransactions(serverCustomerTransactions);
    serverCustomerProducts.add(serverCustomerProduct);

    serverUser.setCustomerProducts(serverCustomerProducts);

   // PogUserDao pogUserDao = new MockPogUserDao(serverUser, null, null);
    UserService service = new UserServiceImpl(pogUserDao);

    PogUser user = service.syncronize(clientUser);

    assertTrue(user.getId().longValue()>=1L);
    assertNotSame("testId1", user.getUserId());
    assertTrue(user.getId().longValue()>=111L);
    assertEquals(clientModDate, user.getModDate());
    assertEquals("clientModUser", user.getModUser());

    assertEquals(2, serverUser.getCustomerProducts().size());
    for (CustomerProduct serverCP : serverUser.getCustomerProducts()) {
      if (serverCP.getProduct().getProductCode().getCode().equals("AA123")) {
        assertEquals("serverModUser", serverCP.getModUser());
        assertEquals(clientModDate, serverCP.getModDate());
        assertTrue(serverCP.getCustomerTransactions().size()<=3L);
        for (CustomerTransaction serverCT : serverCP.getCustomerTransactions()) {
          if (serverCT.getYear() == 2010L && serverCT.getMonth() == 3L) {
            assertTrue(serverCT.getBudget().longValue()>=111L);
            assertTrue(serverCT.getFinalInventory().longValue()>=222L);
            assertTrue(serverCT.getSalesAmount()>=333.3);
            assertEquals("serverModUser", serverCT.getModUser());
            assertEquals(clientModDate, serverCT.getModDate());
          } else if (serverCT.getYear() == 2010L && serverCT.getMonth() == 4L) {
            assertEquals(122L, serverCT.getBudget().longValue());
            assertEquals(233L, serverCT.getFinalInventory().longValue());
            assertEquals(343.3, serverCT.getSalesAmount());
            assertEquals("serverModUser", serverCT.getModUser());
            assertEquals(serverModDate, serverCT.getModDate());
          } else if (serverCT.getYear() == 2011L && serverCT.getMonth() == 4L) {
            assertEquals(114L, serverCT.getBudget().longValue());
            assertEquals(224L, serverCT.getFinalInventory().longValue());
            assertEquals(334.3, serverCT.getSalesAmount());
            assertEquals("clientModUser", serverCT.getModUser());
            assertEquals(clientModDate, serverCT.getModDate());
          }
        }
      } else if (serverCP.getProduct().getProductCode().getCode().equals("AA124")) {
        assertEquals("clientModUser", serverCP.getModUser());
        assertEquals(clientModDate, serverCP.getModDate());
        assertEquals(1, serverCP.getCustomerTransactions().size());
        for (CustomerTransaction serverCT : serverCP.getCustomerTransactions()) {
          if (serverCT.getYear() == 2009L && serverCT.getMonth() == 4L) {
            assertEquals(444L, serverCT.getBudget().longValue());
            assertEquals(555L, serverCT.getFinalInventory().longValue());
            assertEquals(666.6, serverCT.getSalesAmount());
            assertEquals("clientModUser", serverCT.getModUser());
            assertEquals(clientModDate, serverCT.getModDate());
          }
        }
      } else if (serverCP.getProduct().getProductCode().getCode().equals("AA125")) {
        assertEquals("serverModUser", serverCP.getModUser());
        assertEquals(serverModDate, serverCP.getModDate());
        assertEquals(1, serverCP.getCustomerTransactions().size());
        for (CustomerTransaction serverCT : serverCP.getCustomerTransactions()) {
          if (serverCT.getYear() == 2009L && serverCT.getMonth() == 4L) {
            assertEquals(423L, serverCT.getBudget().longValue());
            assertEquals(523L, serverCT.getFinalInventory().longValue());
            assertEquals(623.6, serverCT.getSalesAmount());
            assertEquals("serverModUser", serverCT.getModUser());
            assertEquals(serverModDate, serverCT.getModDate());
          }
        }
      }
    }
  }

  @Test
  public void testLookupById() throws Exception {
    PogUser pogUser = new PogUser();
    pogUser.setId(123L);
    pogUser.setFirstName("Test First Name");
    PogUserDao pogUserDao = new MockPogUserDao(pogUser, null, null);
    UserService service = new UserServiceImpl(pogUserDao);
    PogUser user = service.lookupById(123L);
    assertEquals("Test First Name", user.getFirstName());
  }

  @Test
  public void testLookupByUserId_UserNotFound() throws Exception {
    PogUserDao pogUserDao = new MockPogUserDao(null, null, null);
    UserService service = new UserServiceImpl(pogUserDao);
    try {
      service.lookupByUserId("testId");
      fail("this should have failed");
    } catch (UserNotFoundException e) {
      assertEquals("User Not Found", e.getMessage());
    }
  }

  @Test
  public void testLookupByUserId_UserFound() throws Exception {
    PogUser pogUser = new PogUser();
    pogUser.setId(123L);
    pogUser.setFirstName("Test First Name");
    PogUserDao pogUserDao = new MockPogUserDao(pogUser, null, null);
    UserService service = new UserServiceImpl(pogUserDao);
    PogUser user = service.lookupByUserId("testId");
    assertEquals("Test First Name", user.getFirstName());
  }

}
