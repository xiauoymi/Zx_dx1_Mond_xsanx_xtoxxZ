package com.monsanto.eas.pog.services.mock;

import com.monsanto.eas.pog.model.hibernate.Area;
import com.monsanto.eas.pog.services.AreaService;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 27, 2010 Time: 1:01:33 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockAreaService implements AreaService {
  private Area area;
  private Collection<Area> areas;

  public MockAreaService(Area area, Collection<Area> areas) {
    this.area = area;
    this.areas = areas;
  }

  public Collection<Area> lookupAll() {
    return areas;
  }

  public Area saveOrUpdate(Area area) {
    return null;
  }
}
