package com.monsanto.eas.pog.services.mock;

import com.monsanto.eas.pog.model.hibernate.CountryType;
import com.monsanto.eas.pog.services.CountryTypeService;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 27, 2010 Time: 1:02:08 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockCountryTypeService implements CountryTypeService {
  private Collection<CountryType> countryTypes;
  private CountryType countryType;

  public MockCountryTypeService(CountryType countryType, Collection<CountryType> countryTypes) {
    this.countryTypes = countryTypes;
    this.countryType = countryType;
  }

  public Collection<CountryType> lookupAll() {
    return countryTypes;
  }

  public CountryType lookupByType(String type) throws Exception {
    return countryType;
  }
}
