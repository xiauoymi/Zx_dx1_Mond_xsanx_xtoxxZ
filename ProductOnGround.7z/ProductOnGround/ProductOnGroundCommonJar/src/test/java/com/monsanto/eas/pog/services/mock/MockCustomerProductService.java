package com.monsanto.eas.pog.services.mock;

import com.monsanto.eas.pog.model.hibernate.CustomerProduct;
import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.services.CustomerProductService;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Aug 17, 2010 Time: 1:20:46 PM To change this template use File |
 * Settings | File Templates.
 */
public class MockCustomerProductService implements CustomerProductService {
  private CustomerProduct inactiveCustomerProduct;
  private Collection<CustomerProduct> customerProducts;
  private PogUser distributor;
  private Long year;
  private Long month;
  private Long startYear;
  private Long startMonth;
  private Long endYear;
  private Long endMonth;

  public MockCustomerProductService(CustomerProduct inactiveCustomerProduct,
                                    Collection<CustomerProduct> customerProducts) {
    this.inactiveCustomerProduct = inactiveCustomerProduct;
    this.customerProducts = customerProducts;
  }

  public Collection<CustomerProduct> filterByYearAndMonthRange(PogUser distributor, Long year, Long month, Long endYear,
                                                               Long endMonth) {
    this.distributor = distributor;
    startYear = year;
    startMonth = month;
    this.endYear = endYear;
    this.endMonth = endMonth;
    return customerProducts;
  }

  public CustomerProduct lookupInactiveByDistributorProductCodeAndBaseUomCode(PogUser distributor, String productName,
                                                                              String baseUomCode, String materialId) {
    return productName.equalsIgnoreCase("AA12345") ? inactiveCustomerProduct : null;
  }

  public void filterByYearAndMonth(PogUser distributor, Long year, Long month) {
    this.distributor = distributor;
    this.year = year;
    this.month = month;
    distributor.setCustomerProducts(customerProducts);
  }

  public Long getStartYear() {
    return startYear;
  }

  public Long getStartMonth() {
    return startMonth;
  }

  public Long getEndYear() {
    return endYear;
  }

  public Long getEndMonth() {
    return endMonth;
  }

  public Long getYear() {
    return year;
  }

  public Long getMonth() {
    return month;
  }

  public PogUser getDistributor() {
    return distributor;
  }
}
