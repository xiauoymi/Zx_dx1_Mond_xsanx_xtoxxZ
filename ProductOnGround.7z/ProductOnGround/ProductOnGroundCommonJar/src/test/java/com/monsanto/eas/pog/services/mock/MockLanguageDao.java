/*
 Copyright:  Copyright � 2011 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.eas.pog.services.mock;

import com.monsanto.eas.pog.dao.LanguageDao;
import com.monsanto.eas.pog.model.hibernate.Language;
import org.hibernate.Criteria;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author sspati1
 * @version $Revision$
 */
public class MockLanguageDao implements LanguageDao {
  private Language language;
  private Collection<Language> languages;

  public MockLanguageDao(Language language, Collection<Language> languages) {
    this.language = language;
    this.languages = languages;
  }

  public Language findByPrimaryKey(Long aLong) {
    return null;
  }

  public Collection<Language> findAll() {
    return languages;
  }

  public Collection<Language> findAll(int startIndex, int fetchSize) {
    return null;
  }

  public Collection<Language> findByExample(Language exampleInstance, String[] excludeProperty) {
    return null;
  }

  public Collection<Language> findAll(String key, boolean ascending) {
    return null;
  }

  public Language saveOrUpdate(Language entity) {
    return null;
  }

  public Language merge(Language entity) {
    return null;
  }

  public void delete(Language entity) {
  }

    public void flush() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public void clear() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    public Criteria createCriteria() {
    return null;
  }

  public Criteria createCriteria(boolean isDeleted) {
    return null;
  }

  public Criteria createCriteria(String alias, boolean isDeleted) {
    return null;
  }
}