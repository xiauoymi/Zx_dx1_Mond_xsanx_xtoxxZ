package com.monsanto.eas.pog.services.mock;

import com.monsanto.eas.pog.model.hibernate.PogUser;
import com.monsanto.eas.pog.model.hibernate.Product;
import com.monsanto.eas.pog.model.hibernate.ProductCode;
import com.monsanto.eas.pog.services.ProductService;

import java.util.Collection;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: 2/7/11 Time: 1:42 PM To change this template use File | Settings | File
 * Templates.
 */
public class MockProductService implements ProductService {
  private Product product;
  private Collection<Product> products;
  private Collection<ProductCode> productCodes;
  private String salesRepUserId;

  public MockProductService(Product product, Collection<Product> products, Collection<ProductCode> productCodes) {
    this.product = product;
    this.products = products;
    this.productCodes = productCodes;
  }

  public Product saveOrUpdate(Product product) {
    return product;
  }

  public Collection<Product> lookupDistributorSpecificProducts(PogUser distributor, String localeStr) throws Exception {
    return null;
  }

  public Collection<Product> lookupBySalesRepUserId(String salesRepUserId) {
    this.salesRepUserId = salesRepUserId;
    return this.products;
  }

  public Product lookupById(Long productId) {
    return this.product;
  }

  public Product lookupByCodeBaseUomIdAndMaterialId(String sapProductCode, Long baseUomId, String materialId) {
    return product;
  }

  public Collection<Product> lookupAllProducts() {
    return products;
  }

}
