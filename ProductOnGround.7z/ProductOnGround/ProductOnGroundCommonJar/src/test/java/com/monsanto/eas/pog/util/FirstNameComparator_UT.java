package com.monsanto.eas.pog.util;

import com.monsanto.eas.pog.model.hibernate.PogUser;
import junit.framework.TestCase;
import org.junit.Test;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: NTARDUC
 * Date: Jul 19, 2010
 * Time: 10:53:42 AM
 * To change this template use File | Settings | File Templates.
 */
public class FirstNameComparator_UT extends TestCase {
    
  @Test
  public void testSortPogUserFirstNameComparator() throws Exception {
    PogUser pogUser1 = new PogUser();
    pogUser1.setFirstName("Sonal");

    PogUser pogUser2 = new PogUser();
    pogUser2.setFirstName("Nicolas");

    PogUser pogUser3 = new PogUser();
    pogUser3.setFirstName("Alexander");

    PogUser pogUser4 = new PogUser();
    pogUser4.setFirstName("Williams");

    List<PogUser> pogUsers = new ArrayList<PogUser>();
    pogUsers.add(pogUser1);
    pogUsers.add(pogUser2);
    pogUsers.add(pogUser3);
    pogUsers.add(pogUser4);

    System.out.println(" Before sort..");
    Iterator it = pogUsers.iterator();
    while ( it.hasNext()) {
        PogUser pogUser = (PogUser)it.next();
        System.out.println( "PogUser - name :: " + pogUser.getFirstName() );
    }

    try{
        Collections.sort(pogUsers, new FirstNameComparator());
    }
    catch ( Exception e) {
        assertEquals("FirstNameComparator failed", e.getMessage());
    }
    System.out.println(" After sort..");
    while ( it.hasNext()) {
        PogUser pogUser = (PogUser)it.next();
        System.out.println( "PogUser - name :: " + pogUser.getFirstName() );
    }

    PogUser pog1 = (PogUser)pogUsers.get(0);
    assertEquals(pog1.getFirstName(),"Alexander");
  }

  @Test
  public void testSortByFirsNameCollectionUtils() throws Exception {
    PogUser pogUser1 = new PogUser();
    pogUser1.setFirstName("Sonal");

    PogUser pogUser2 = new PogUser();
    pogUser2.setFirstName("Nicolas");

    PogUser pogUser3 = new PogUser();
    pogUser3.setFirstName("Alexander");

    PogUser pogUser4 = new PogUser();
    pogUser4.setFirstName("Williams");

    Collection<PogUser> pogUsersNotSorted = new ArrayList<PogUser>();
    pogUsersNotSorted.add(pogUser1);
    pogUsersNotSorted.add(pogUser2);
    pogUsersNotSorted.add(pogUser3);
    pogUsersNotSorted.add(pogUser4);

    List<PogUser> sorted = new ArrayList<PogUser>();
    for(PogUser pog: pogUsersNotSorted){
      sorted.add(pog);
    }

    System.out.println(" Before sort..");
    Iterator it = pogUsersNotSorted.iterator();
    while ( it.hasNext()) {
        PogUser pogUser = (PogUser)it.next();
        System.out.println( "PogUser - name :: " + pogUser.getFirstName() );
    }

    try{
      Collections.sort(sorted, new FirstNameComparator());
    }
    catch ( Exception e) {
        assertEquals("FirstNameComparator failed", e.getMessage());
    }

    assertTrue(true);
    //We test if the first user now is Alexander and it is not Sonal after call sort.
//    PogUser pog1 = (PogUser)pogUsersNotSorted.get(0);
//    assertEquals(pog1.getFirstName(),"Alexander");
  }

}
