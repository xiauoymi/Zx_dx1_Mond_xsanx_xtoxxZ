/*
 POGSAPData_Constants was created on Jun 23, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class SAPDataConstants {

  public static final String ENV_VARIABLE_MONCRYPTJV = "MONCRYPTJV";
  public static final String FILE_ENCRYPTED_PWD_VALUE = "CipherValue.hex";
  public static final String FILE_ENCRYPTED_PWD_KEY = "KeyValue.hex";
  public static final String QaaWS = "qaaws";
  public static final String LSI_FUNCTION = "lsi.function";
  public static final String AUTHENTICATION_TYPE = "secLDAP";


}