/*
 RequiredParametersNotSetException was created on Jul 7, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.sapclient;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class RequiredParametersNotSetException extends Exception{

  public RequiredParametersNotSetException(String message) {
    super(message);
  }
}