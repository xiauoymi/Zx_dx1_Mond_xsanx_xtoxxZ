/*
 CustomerProductMasterDataClient was created on Aug 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.sapclient.customerProduct;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.pog.sapclient.RequiredParametersNotSetException;
import com.monsanto.eas.pog.sapclient.customerProduct.schema.QaaWSHeader;
import com.monsanto.eas.pog.sapclient.customerProduct.schema.Row;
import com.monsanto.eas.pog.sapclient.customerProduct.schema.RunQueryAsAService;
import com.monsanto.eas.pog.sapclient.customerProduct.schema.RunQueryAsAServiceResponse;
import com.monsanto.eas.pog.sapclient.customerProduct.service.POGProdTransWithCustomer;
import com.monsanto.eas.pog.sapclient.customerProduct.service.QueryAsAServiceSoap;
import com.monsanto.eas.pog.utils.QaaWSClientConnection;

import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class CustomerProductMasterDataClient {
  private final static org.apache.log4j.Logger logger =  org.apache.log4j.Logger.getLogger
        (CustomerProductMasterDataClient.class.getName());

  public Collection<Row> getProductsSpecificToACustomer(String locale, Collection<String> customerIds) throws Exception {
    logger.info("Getting products specific to customers.\n");
    if (StringUtils.isNullOrEmpty(locale)) {
      logger.error("Customer Product Service - getProductsSpecificToACustomer : The required input parameter locale is not set.\n");
      throw new RequiredParametersNotSetException(
          "Customer Product Service : The required input parameter locale is not set.");
    }
    QaaWSClientConnection qaawsClient = new QaaWSClientConnection();
    String win_account = qaawsClient.accountNameForQaaWSService();
    String password = qaawsClient.passwordForQaaWSService();

    QaaWSHeader header = new QaaWSHeader();
    QueryAsAServiceSoap productMasterService = new POGProdTransWithCustomer().getQueryAsAServiceSoap();
    RunQueryAsAService runQryService = new RunQueryAsAService();
    runQryService.setLogin(win_account);
    runQryService.setPassword(password);
    runQryService.setLanguageKey(locale);
    if (customerIds != null && customerIds.size() >= 1){
      runQryService.getCustomer().addAll(customerIds);
    }
    RunQueryAsAServiceResponse serviceResponse = productMasterService.runQueryAsAService(runQryService, header);
    logger.info("Got products specific to customers.\n");
    return serviceResponse.getTable().getRow();
  }
}