
package com.monsanto.eas.pog.sapclient.customerProduct.schema;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.monsanto.eas.pog.sapclient.customerProduct.schema package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _QaaWSHeaderSessionID_QNAME = new QName("POG_Prod_Trans_With_Customer", "sessionID");
    private final static QName _QaaWSHeaderSerializedSession_QNAME = new QName("POG_Prod_Trans_With_Customer", "serializedSession");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.monsanto.eas.pog.sapclient.customerProduct.schema
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RunQueryAsAServiceEx }
     * 
     */
    public RunQueryAsAServiceEx createRunQueryAsAServiceEx() {
        return new RunQueryAsAServiceEx();
    }

    /**
     * Create an instance of {@link LovValueIndex }
     * 
     */
    public LovValueIndex createLovValueIndex() {
        return new LovValueIndex();
    }

    /**
     * Create an instance of {@link Row }
     * 
     */
    public Row createRow() {
        return new Row();
    }

    /**
     * Create an instance of {@link RunQueryAsAServiceExResponse }
     * 
     */
    public RunQueryAsAServiceExResponse createRunQueryAsAServiceExResponse() {
        return new RunQueryAsAServiceExResponse();
    }

    /**
     * Create an instance of {@link Table }
     * 
     */
    public Table createTable() {
        return new Table();
    }

    /**
     * Create an instance of {@link ValuesOfCustomer }
     * 
     */
    public ValuesOfCustomer createValuesOfCustomer() {
        return new ValuesOfCustomer();
    }

    /**
     * Create an instance of {@link Lov }
     * 
     */
    public Lov createLov() {
        return new Lov();
    }

    /**
     * Create an instance of {@link ValuesOfLanguageKey }
     * 
     */
    public ValuesOfLanguageKey createValuesOfLanguageKey() {
        return new ValuesOfLanguageKey();
    }

    /**
     * Create an instance of {@link ValuesOfCustomerResponse }
     * 
     */
    public ValuesOfCustomerResponse createValuesOfCustomerResponse() {
        return new ValuesOfCustomerResponse();
    }

    /**
     * Create an instance of {@link ValuesOfLanguageKeyResponse }
     * 
     */
    public ValuesOfLanguageKeyResponse createValuesOfLanguageKeyResponse() {
        return new ValuesOfLanguageKeyResponse();
    }

    /**
     * Create an instance of {@link RunQueryAsAService }
     * 
     */
    public RunQueryAsAService createRunQueryAsAService() {
        return new RunQueryAsAService();
    }

    /**
     * Create an instance of {@link RunQueryAsAServiceResponse }
     * 
     */
    public RunQueryAsAServiceResponse createRunQueryAsAServiceResponse() {
        return new RunQueryAsAServiceResponse();
    }

    /**
     * Create an instance of {@link QaaWSHeader }
     * 
     */
    public QaaWSHeader createQaaWSHeader() {
        return new QaaWSHeader();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "POG_Prod_Trans_With_Customer", name = "sessionID", scope = QaaWSHeader.class)
    public JAXBElement<String> createQaaWSHeaderSessionID(String value) {
        return new JAXBElement<String>(_QaaWSHeaderSessionID_QNAME, String.class, QaaWSHeader.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "POG_Prod_Trans_With_Customer", name = "serializedSession", scope = QaaWSHeader.class)
    public JAXBElement<String> createQaaWSHeaderSerializedSession(String value) {
        return new JAXBElement<String>(_QaaWSHeaderSerializedSession_QNAME, String.class, QaaWSHeader.class, value);
    }

}
