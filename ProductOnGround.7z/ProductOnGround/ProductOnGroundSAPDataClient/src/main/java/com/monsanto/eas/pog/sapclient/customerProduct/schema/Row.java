
package com.monsanto.eas.pog.sapclient.customerProduct.schema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Row complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Row">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Customer_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_1_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_1_Desc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Leve_2_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_2_Desc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_3_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_3_Desc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_4_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_4_Desc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_5_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_5_Desc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_6_ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Prod_Level_6_Desc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UOM_Code" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="UOM_Desc" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Number_of_Records" type="{http://www.w3.org/2001/XMLSchema}double"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Row", propOrder = {
    "customerID",
    "prodLevel1ID",
    "prodLevel1Desc",
    "prodLeve2ID",
    "prodLevel2Desc",
    "prodLevel3ID",
    "prodLevel3Desc",
    "prodLevel4ID",
    "prodLevel4Desc",
    "prodLevel5ID",
    "prodLevel5Desc",
    "prodLevel6ID",
    "prodLevel6Desc",
    "uomCode",
    "uomDesc",
    "numberOfRecords"
})
public class Row {

    @XmlElement(name = "Customer_ID", required = true, nillable = true)
    protected String customerID;
    @XmlElement(name = "Prod_Level_1_ID", required = true, nillable = true)
    protected String prodLevel1ID;
    @XmlElement(name = "Prod_Level_1_Desc", required = true, nillable = true)
    protected String prodLevel1Desc;
    @XmlElement(name = "Prod_Leve_2_ID", required = true, nillable = true)
    protected String prodLeve2ID;
    @XmlElement(name = "Prod_Level_2_Desc", required = true, nillable = true)
    protected String prodLevel2Desc;
    @XmlElement(name = "Prod_Level_3_ID", required = true, nillable = true)
    protected String prodLevel3ID;
    @XmlElement(name = "Prod_Level_3_Desc", required = true, nillable = true)
    protected String prodLevel3Desc;
    @XmlElement(name = "Prod_Level_4_ID", required = true, nillable = true)
    protected String prodLevel4ID;
    @XmlElement(name = "Prod_Level_4_Desc", required = true, nillable = true)
    protected String prodLevel4Desc;
    @XmlElement(name = "Prod_Level_5_ID", required = true, nillable = true)
    protected String prodLevel5ID;
    @XmlElement(name = "Prod_Level_5_Desc", required = true, nillable = true)
    protected String prodLevel5Desc;
    @XmlElement(name = "Prod_Level_6_ID", required = true, nillable = true)
    protected String prodLevel6ID;
    @XmlElement(name = "Prod_Level_6_Desc", required = true, nillable = true)
    protected String prodLevel6Desc;
    @XmlElement(name = "UOM_Code", required = true, nillable = true)
    protected String uomCode;
    @XmlElement(name = "UOM_Desc", required = true, nillable = true)
    protected String uomDesc;
    @XmlElement(name = "Number_of_Records", required = true, type = Double.class, nillable = true)
    protected Double numberOfRecords;

    /**
     * Gets the value of the customerID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomerID() {
        return customerID;
    }

    /**
     * Sets the value of the customerID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomerID(String value) {
        this.customerID = value;
    }

    /**
     * Gets the value of the prodLevel1ID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel1ID() {
        return prodLevel1ID;
    }

    /**
     * Sets the value of the prodLevel1ID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel1ID(String value) {
        this.prodLevel1ID = value;
    }

    /**
     * Gets the value of the prodLevel1Desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel1Desc() {
        return prodLevel1Desc;
    }

    /**
     * Sets the value of the prodLevel1Desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel1Desc(String value) {
        this.prodLevel1Desc = value;
    }

    /**
     * Gets the value of the prodLeve2ID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLeve2ID() {
        return prodLeve2ID;
    }

    /**
     * Sets the value of the prodLeve2ID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLeve2ID(String value) {
        this.prodLeve2ID = value;
    }

    /**
     * Gets the value of the prodLevel2Desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel2Desc() {
        return prodLevel2Desc;
    }

    /**
     * Sets the value of the prodLevel2Desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel2Desc(String value) {
        this.prodLevel2Desc = value;
    }

    /**
     * Gets the value of the prodLevel3ID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel3ID() {
        return prodLevel3ID;
    }

    /**
     * Sets the value of the prodLevel3ID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel3ID(String value) {
        this.prodLevel3ID = value;
    }

    /**
     * Gets the value of the prodLevel3Desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel3Desc() {
        return prodLevel3Desc;
    }

    /**
     * Sets the value of the prodLevel3Desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel3Desc(String value) {
        this.prodLevel3Desc = value;
    }

    /**
     * Gets the value of the prodLevel4ID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel4ID() {
        return prodLevel4ID;
    }

    /**
     * Sets the value of the prodLevel4ID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel4ID(String value) {
        this.prodLevel4ID = value;
    }

    /**
     * Gets the value of the prodLevel4Desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel4Desc() {
        return prodLevel4Desc;
    }

    /**
     * Sets the value of the prodLevel4Desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel4Desc(String value) {
        this.prodLevel4Desc = value;
    }

    /**
     * Gets the value of the prodLevel5ID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel5ID() {
        return prodLevel5ID;
    }

    /**
     * Sets the value of the prodLevel5ID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel5ID(String value) {
        this.prodLevel5ID = value;
    }

    /**
     * Gets the value of the prodLevel5Desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel5Desc() {
        return prodLevel5Desc;
    }

    /**
     * Sets the value of the prodLevel5Desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel5Desc(String value) {
        this.prodLevel5Desc = value;
    }

    /**
     * Gets the value of the prodLevel6ID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel6ID() {
        return prodLevel6ID;
    }

    /**
     * Sets the value of the prodLevel6ID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel6ID(String value) {
        this.prodLevel6ID = value;
    }

    /**
     * Gets the value of the prodLevel6Desc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProdLevel6Desc() {
        return prodLevel6Desc;
    }

    /**
     * Sets the value of the prodLevel6Desc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProdLevel6Desc(String value) {
        this.prodLevel6Desc = value;
    }

    /**
     * Gets the value of the uomCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUOMCode() {
        return uomCode;
    }

    /**
     * Sets the value of the uomCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUOMCode(String value) {
        this.uomCode = value;
    }

    /**
     * Gets the value of the uomDesc property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUOMDesc() {
        return uomDesc;
    }

    /**
     * Sets the value of the uomDesc property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUOMDesc(String value) {
        this.uomDesc = value;
    }

    /**
     * Gets the value of the numberOfRecords property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getNumberOfRecords() {
        return numberOfRecords;
    }

    /**
     * Sets the value of the numberOfRecords property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setNumberOfRecords(Double value) {
        this.numberOfRecords = value;
    }

}
