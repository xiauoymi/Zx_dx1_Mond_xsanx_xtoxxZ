@javax.xml.bind.annotation.XmlSchema(namespace = "POG_Prod_Trans_With_Customer", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.monsanto.eas.pog.sapclient.customerProduct.schema;
