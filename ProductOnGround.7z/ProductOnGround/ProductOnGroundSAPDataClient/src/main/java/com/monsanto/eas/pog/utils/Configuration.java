/*
 Configuration was created on Jun 23, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.utils;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.pog.SAPDataConstants;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import java.util.MissingResourceException;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class Configuration {
  // The Singleton instance of this class.
  private static Configuration instance = null;

  // Used to load the name-value pairs.
  public static final String BO_DEV_URL = "http://widwls21:14132/dswsbobje/services/session";

  Map<String, String> environmentToAccountMap = null;

  private static final String LSI_FUNCTION = "lsi.function";
  private static final String WIN = "win";
  private static final String DEV = "dev";
  private static final String TEST = "it";
  private static final String PS = "ps";
  private static final String PROD = "prod";

// Defined property names.

  private Logger logger = Logger.getLogger(Configuration.class);
  private HashMap<String, String> prefixMap = null;

  private static final String CONFIG_FILE = "QaaWS.properties";
  private static final String POG_QaaWS = "pog";

  /**
   * Private constructor.
   */
  private Configuration() {
    initConfiguration();
  }

  private void initConfiguration() {
    logger.debug("Initializing system configuration properties.");
    logger.info("The lsi function is : " + System.getProperty(SAPDataConstants.LSI_FUNCTION));
    try {
      prefixMap = new HashMap<String, String>();
      prefixMap.put(WIN, WIN);
      prefixMap.put(DEV, DEV);
      prefixMap.put(TEST, TEST);
      prefixMap.put(PS, PS);
      prefixMap.put(PROD, PROD);
      populateEnvironmentToAccountMap();
    } catch (Exception e) {
      logger.error(e.getMessage());
      logger.error(e);
      e.printStackTrace();
    }
  }

  private void populateEnvironmentToAccountMap() throws Exception {
    environmentToAccountMap = new HashMap<String, String>();
    String storageLocation = System
        .getProperty(SAPDataConstants.ENV_VARIABLE_MONCRYPTJV);   // requires defining a -D param
    String filename = new StringBuffer(storageLocation).append("/").append(POG_QaaWS).append("/").append(CONFIG_FILE)
        .toString();
    BufferedReader brIn;
    String line;
    try {
      brIn = new BufferedReader(new FileReader(filename));
      while ((line = brIn.readLine()) != null) {
        if (!StringUtils.isNullOrEmpty(line)) {
          String[] strings = line.split(":=");
          environmentToAccountMap.put(strings[0], strings[1]);
        }
      }
    }
    catch (FileNotFoundException ex) {
      ex.printStackTrace();
      throw new Exception("Invalid file name (" + filename + ").");
    }
  }

  /**
   * Returns the Singleton instance of this class.
   *
   * @return Configuration the singleton instance of this class
   */
  public static final synchronized Configuration getInstance() {
    if (instance == null) {
      instance = new Configuration();
    }
    return instance;
  }

  /**
   * Returns the value associated with the supplied name.
   *
   * @return String the property value
   */
  public String getProperty(String aName) throws Exception {

    String lValue = null;
    try {
//      String environment = getPropertyPrefix();
      logger.debug("The propery being looked up is " + aName.trim());
      lValue = environmentToAccountMap.get(aName.trim()).trim();

    } catch (MissingResourceException e) {
      e.printStackTrace();
      logger.debug("The lsi function is " + getPropertyPrefix());
      logger.debug("The propery being looked up is default" + "." + aName.trim());
      lValue = environmentToAccountMap.get("default").trim();
    } catch (Exception e) {
        logger.debug("The lsi function is " + getPropertyPrefix());
      logger.debug("The propery being looked up is default" + "." + aName.trim());
      logger.error(e);
      e.printStackTrace();
      throw (e);
    }

    return lValue;
  }

  private String getPropertyPrefix() throws Exception {
    String prefix = System.getProperty(LSI_FUNCTION);
    if (StringUtils.isNullOrEmpty(prefix)) {
      throw new Exception("Bad value of lsi.function = " + prefix);
    }
    return prefixMap.get(prefix);
  }
}
