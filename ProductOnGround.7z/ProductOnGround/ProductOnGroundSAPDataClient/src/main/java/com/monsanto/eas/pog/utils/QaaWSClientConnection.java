/*
 PasswordForQaawsClient was created on Jun 23, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.utils;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.eas.pog.SAPDataConstants;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class QaaWSClientConnection {
  public String passwordForQaaWSService() throws Exception {
    String qaaws_account = SAPDataConstants.QaaWS;
    return EncryptionUtils.GetDecryptedStringFromExternalStorage(
        SAPDataConstants.ENV_VARIABLE_MONCRYPTJV,
        "pog",
        qaaws_account + "_" + SAPDataConstants.FILE_ENCRYPTED_PWD_VALUE,
        qaaws_account + "_" + SAPDataConstants.FILE_ENCRYPTED_PWD_KEY);
  }

  public String accountNameForQaaWSService() throws Exception {
    Configuration configuration = Configuration.getInstance();
    return configuration.getProperty("pog");
  }
}