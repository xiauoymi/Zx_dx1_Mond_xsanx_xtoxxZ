/*
 CustomerProductMasterDataClient_AT was created on Aug 5, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.sapclient;

import com.monsanto.eas.pog.sapclient.customerProduct.CustomerProductMasterDataClient;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class CustomerProductMasterDataClient_AT extends TestCase {
public void testReadProductsSpecificToACustomer_NoCriteriaSpecified_DataNotReturned() throws Exception {

    CustomerProductMasterDataClient client = new CustomerProductMasterDataClient();
  Collection<String> customerIds = new ArrayList<String>();
  customerIds.add("1000025");
  Collection<com.monsanto.eas.pog.sapclient.customerProduct.schema.Row> rows = client
      .getProductsSpecificToACustomer("EN", customerIds);
  assertNotNull(rows);
  }
}