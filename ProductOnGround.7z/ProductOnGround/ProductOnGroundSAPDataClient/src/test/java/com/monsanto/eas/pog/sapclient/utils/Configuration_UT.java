/*
 Configuration_UT was created on Jun 24, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.pog.sapclient.utils;

import com.monsanto.eas.pog.SAPDataConstants;
import com.monsanto.eas.pog.utils.Configuration;
import junit.framework.TestCase;
import org.junit.Before;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class Configuration_UT extends TestCase {
  private Configuration config;

  @Before
  public void setUp() throws Exception {
    config = Configuration.getInstance();
  }
  public void testConstructor_ObjectNotNull() throws Exception {
    assertNotNull(config);
  }

  public void testGetPropertyFromConfigFile_ValueReturned() throws Exception {
    System.setProperty(SAPDataConstants.LSI_FUNCTION, "win");

    String qaaWSAccount = config.getProperty("pog");
    assertEquals("NA1000SVC-POG", qaaWSAccount);
  }

   public void testGetPropertyForCustomerMasterWinFromConfigFile_ValueReturned() throws Exception {
    System.setProperty(SAPDataConstants.LSI_FUNCTION, "win");

    String qaaWSAccount = config.getProperty("win.qaawsURL.customerMaster");
    assertNotNull(qaaWSAccount);
  }
}