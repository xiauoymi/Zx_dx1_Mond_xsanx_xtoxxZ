package com.monsanto.eas.reportingservice.clientutil;

import java.util.HashMap;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Created by IntelliJ IDEA.
 * User: sspati1
 * Date: Apr 14, 2010
 * Time: 10:23:37 AM
 * To change this template use File | Settings | File Templates.
 */
public class Configuration {
    private static Configuration instance = null;
    private ResourceBundle resourceBundle = null;
    private String CONFIG_FILE = "wsdl";
    public static final String OSB_URL = "osb_url";
    public static final String RETRIEVE_DOCUMENT_SERVICE = "reporting_retrievedocument_uri";
    public static final String RETRIEVE_LIST_OF_CRITERIA_SERVICE = "reporting_retrievelistofcriteria_uri";
    public static final String RETRIEVE_REPORT_FOR_CRITERIA_SERVICE = "reporting_retrievereportforcriteria_uri";
    private HashMap<EnvironmentEnum, String> prefixMap = null;
  public static final String VIEW_REPORTS_SERVICE = "reporting_viewreports_uri";

  private Configuration() {
        initConfiguration();
    }

    private void initConfiguration() {
//        logger = Logger.getLogger(Configuration.class);
//        logger.debug("Initializing system configuration properties.");
        try {
            prefixMap = new HashMap<EnvironmentEnum, String>();
            prefixMap.put(EnvironmentEnum.DEV_EXT, EnvironmentEnum.DEV_EXT.toString());
            prefixMap.put(EnvironmentEnum.DEV_INT, EnvironmentEnum.DEV_INT.toString());
            resourceBundle = ResourceBundle.getBundle(CONFIG_FILE);
        } catch (Exception e) {
//            logger.error(e.getMessage());
//            logger.error(e);
        }
    }

    /**
     * Returns the Singleton instance of this class.
     *
     * @return Configuration the singleton instance of this class
     */
    public static final synchronized Configuration getInstance() {
        if (instance == null) {
            instance = new Configuration();
        }
        return instance;
    }

    public String getWsdlLocation(EnvironmentEnum environment, String serviceName) throws Exception {
        return getProperty(environment, OSB_URL) + getProperty(environment, serviceName);
    }

    /**
     * Returns the value associated with the supplied name.
     *
     * @return String the property value
     */
    public String getProperty(EnvironmentEnum env, String aName) throws Exception {

        String lValue = null;
        try {
            String envPropertyPrefix = getPropertyPrefix(env);
            try {
                lValue = resourceBundle.getString(envPropertyPrefix + "_" + aName).trim();
            } catch (MissingResourceException e) {
                lValue = resourceBundle.getString("default_" + aName).trim();
            }
        } catch (Exception e) {
//            logger.error(e);
            throw (e);
        }

        return lValue;
    }

    private String getPropertyPrefix(EnvironmentEnum env) throws Exception {
        if (env == null) {
            throw new Exception("Bad value of Environment = " + env);
        }
        return prefixMap.get(env);
    }
}

