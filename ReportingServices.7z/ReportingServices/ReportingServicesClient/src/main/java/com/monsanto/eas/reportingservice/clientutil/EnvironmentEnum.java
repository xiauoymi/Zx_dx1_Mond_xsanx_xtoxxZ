package com.monsanto.eas.reportingservice.clientutil;

/**
 * Created by IntelliJ IDEA.
 * User: sspati1
 * Date: Apr 14, 2010
 * Time: 10:21:06 AM
 * To change this template use File | Settings | File Templates.
 */
public enum EnvironmentEnum {
    DEV_EXT,
    DEV_INT,
    IT_EXT,
    IT_INT,
    PS_EXT,
    PS_INT,
    PROD_EXT,
    PROD_INT;

    public static EnvironmentEnum fromValue(String value) {
        return valueOf(value);
    }

    public String toString() {
        return name();
    }
}
