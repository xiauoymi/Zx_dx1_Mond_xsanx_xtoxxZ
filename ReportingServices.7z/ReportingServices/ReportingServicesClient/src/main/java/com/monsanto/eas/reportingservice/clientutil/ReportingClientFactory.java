package com.monsanto.eas.reportingservice.clientutil;


//import com.monsanto.eas.reportingservice.schema.RetrieveReportRequestType;
//import com.monsanto.eas.reportingservice.schema.RetrieveReportResponseType;

import com.monsanto.eas.reportingservice.service.RetrieveDocumentService_Service;
import com.monsanto.eas.reportingservice.service.RetrieveListOfCriteriaForDocumentService_Service;
import com.monsanto.eas.reportingservice.service.RetrieveReportForCriteriaService_Service;
import com.monsanto.eas.reportingservice.service.ViewReportsService_Service;
import com.monsanto.eas.reportingservice.schema.RetrieveReportRequestType;
import com.monsanto.eas.reportingservice.schema.RetrieveReportResponseType;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.RetrieveDocumentRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.RetrieveDocumentResponseType;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.RetrieveListOfCriteriaRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.RetrieveListOfCriteriaResponseType;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.RetrieveReportForCriteriaRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.RetrieveReportForCriteriaResponseType;

import javax.activation.DataHandler;
import javax.xml.namespace.QName;
import java.io.InputStream;
import java.net.URL;


/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Apr 14, 2010 Time: 10:12:19 AM To change this template use File |
 * Settings | File Templates.
 */
public class ReportingClientFactory {
  public static QName RETRIEVE_DOCUMENT_QNAME = new QName(
      "urn:monsanto:enterprise:services:wsdl:reporting:viewdocument:1:0", "RetrieveReportsServiceSoapBindingQSService");
  public static QName RETRIEVE_REPORT_FOR_CRITERIA_QNAME = new QName(
      "urn:monsanto:enterprise:services:wsdl:reporting:retrieveReportForCriteria:1:0",
      "RetrieveReportForCriteriaServiceSoapBindingQSService");
  public static QName RETRIEVE_LIST_OF_CRITERIA_FOR_DOCUMENT_QNAME = new QName(
      "urn:monsanto:enterprise:services:wsdl:reporting:retrieveListOfCriteria:1:0",
      "RetrieveListOfCriteriaForDocumentServiceSoapBindingQSService");
  public static QName VIEW_REPORTS_QNAME = new QName("urn:monsanto:enterprise:services:wsdl:reporting:viewreport:1:0",
      "ViewReportsServiceSoapBindingQSService");

  public static InputStream getRetrieveDocument(EnvironmentEnum environment,
                                                      RetrieveDocumentRequestType request) throws Exception {
    String wsdlLocation = Configuration.getInstance()
        .getWsdlLocation(environment, Configuration.RETRIEVE_DOCUMENT_SERVICE);
    URL url = new URL(wsdlLocation);
    RetrieveDocumentService_Service service = new RetrieveDocumentService_Service(url, RETRIEVE_DOCUMENT_QNAME);
    RetrieveDocumentResponseType documentResponseType = service.getRetrieveDocumentServicePort().retrieveDocument(request);
//    RetrieveDocumentResponseType documentResponseType = service.getRetrieveDocumentServicePort()
//        .retrieveDocument(request);
    DataHandler dataHandler = documentResponseType.getDocumentDetails().getView().getDocumentViewDetails()
        .getContent();
    return dataHandler.getInputStream();
  }


  public static RetrieveListOfCriteriaResponseType getRetrieveListOfCriteriaForDocument(
      EnvironmentEnum environment, RetrieveListOfCriteriaRequestType request) throws Exception {
    String wsdlLocation = Configuration.getInstance()
        .getWsdlLocation(environment, Configuration.RETRIEVE_LIST_OF_CRITERIA_SERVICE);
    URL url = new URL(wsdlLocation);
    RetrieveListOfCriteriaForDocumentService_Service service = new RetrieveListOfCriteriaForDocumentService_Service(url,
        RETRIEVE_LIST_OF_CRITERIA_FOR_DOCUMENT_QNAME);
    return service.getRetrieveListOfCriteriaForDocumentPort()
        .retrieveListOfCriteriaForDocument(request);
  }

  public static RetrieveReportResponseType getViewReports(EnvironmentEnum environment,
                                                                RetrieveReportRequestType request) throws Exception {
    String wsdlLocation = Configuration.getInstance()
        .getWsdlLocation(environment, Configuration.VIEW_REPORTS_SERVICE);
    URL url = new URL(wsdlLocation);
    ViewReportsService_Service service = new ViewReportsService_Service(url, VIEW_REPORTS_QNAME);
    return service.getViewReportsServicePort().getReports(request);
  }

  public static InputStream getRetrieveReportForCriteria(EnvironmentEnum environment,
                                                               RetrieveReportForCriteriaRequestType request) throws
      Exception {
    String wsdlLocation = Configuration.getInstance()
        .getWsdlLocation(environment, Configuration.RETRIEVE_REPORT_FOR_CRITERIA_SERVICE);
    URL url = new URL(wsdlLocation);
    RetrieveReportForCriteriaService_Service service = new RetrieveReportForCriteriaService_Service(url,
        RETRIEVE_REPORT_FOR_CRITERIA_QNAME);
    RetrieveReportForCriteriaResponseType retrieveReportForCriteriaResponseType = service
        .getRetrieveReportForCriteriaPort().
            retrieveReportForCriteria(request);
    DataHandler dataHandler = retrieveReportForCriteriaResponseType.getNewDocument().getOutputView().getDocumentViewDetails().getContent();
    return dataHandler.getInputStream();
  }

//  public void writeToFile(InputStream is, File file) {
//    try {
//      DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
//      int c;
//      while ((c = is.read()) != -1) {
//        out.writeByte(c);
//      }
//      is.close();
//      out.close();
//    }
//    catch (IOException e) {
//      System.err.println("Error Writing/Reading Streams.");
//    }
//  }
}
