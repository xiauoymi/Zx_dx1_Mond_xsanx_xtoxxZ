package com.monsanto.eas.reportingservice.clientutil;

import com.monsanto.eas.reportingservice.schema.BoDocument;
import com.monsanto.eas.reportingservice.schema.RetrieveReportRequestType;
import com.monsanto.eas.reportingservice.schema.RetrieveReportResponseType;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.OutputFormat;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.RetrieveDocumentRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.CriteriaInfo;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.RetrieveListOfCriteriaRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.RetrieveListOfCriteriaResponseType;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.BoFillPromptValue;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.CriteriaInfoFromRequest;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.ListOfCriteria;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.RetrieveReportForCriteriaRequestType;
import com.monsanto.eas.reportingservice.service.RetrieveDocumentFault;
import junit.framework.TestCase;

import java.io.*;
import java.util.List;

import com.monsanto.eas.reportingservice.schema.retrieveDocument.OutputFormat;

/**
 * Created by IntelliJ IDEA. User: sspati1 Date: Apr 14, 2010 Time: 10:48:33 AM To change this template use File |
 * Settings | File Templates.
 */
public class ReportingClientFactory_AT extends TestCase {
  private static final String PDF_FORMAT = "PDF";

  public void testRetrieveDocumentClient_InvalidDocumentId_InputStreamReturnedIsNull() throws Exception {
    RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
    request.setRoleName("role");
    request.setApplicationName("test");
    request.setDocumentId("90700");
    request.setFormat(OutputFormat.fromValue(PDF_FORMAT));
    try {
      ReportingClientFactory
          .getRetrieveDocument(EnvironmentEnum.DEV_EXT, request);
      fail();
    } catch (Exception e) {
      if (e.getClass().isInstance(RetrieveDocumentFault.class)) {
        assertEquals("Error occurred during operation: getDocumentById : The document reference 90700 is invalid. (WRE 02501)", e.getMessage());
      } else {
        assertTrue(e.getMessage() != null);
       assertEquals("Error occurred during operation: getDocumentById : The document reference 90700 is invalid. (WRE 02501)", e.getMessage());
      }
    }
  }

  public void testRetrieveDocumentClient_RequestIsValid_InputStreamReturnedIsNotNull() throws Exception {
    RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
    request.setRoleName("role");
    request.setApplicationName("test");
    request.setDocumentId("109674");
    request.setFormat(OutputFormat.fromValue(PDF_FORMAT));
    InputStream inputStream = ReportingClientFactory
        .getRetrieveDocument(EnvironmentEnum.DEV_EXT, request);
    assertNotNull(inputStream);
  }

  public void testRetrieveDocumentForCriteria_RequestIsValid_InputStreamReturned() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    request.setApplicationName("test");
    request.setRoleName("role");
    request.setDocumentId("109674");

    ListOfCriteria criteriaList = new ListOfCriteria();
    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("Enter value(s) for Project Nbr:");
    criteria.setName("Enter value(s) for Project Nbr:");
    criteria.setAllowMultiValues(true);
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("16100");
    criteriaValue.setValue("ECS01149");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("46651");
    criteriaValue.setValue("11111111");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("Enter Duct Size(Start):");
    criteria.setName("Enter Duct Size(Start):");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("");
    criteriaValue.setValue("4.0");
    criteria.getCriteriaValues().add(criteriaValue);
    criteria.setAllowMultiValues(false);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("Enter Duct Size(End):");
    criteria.setName("Enter Duct Size(End):");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("");
    criteriaValue.setValue("12.0");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    request.setListOfCriteria(criteriaList);
    InputStream inputStream = ReportingClientFactory
        .getRetrieveReportForCriteria(EnvironmentEnum.DEV_EXT, request);
    assertNotNull(inputStream);
  }


  public void testRetrieveDocumentForCriteria_RequestIsInValid_InputStreamIsNull() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    request.setApplicationName("test");
    request.setRoleName("role");
    request.setDocumentId("109674");

    ListOfCriteria criteriaList = new ListOfCriteria();

    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("Enter Duct Size(End):");
    criteria.setName("Enter Duct Size(End):");
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("");
    criteriaValue.setValue("12.0");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    request.setListOfCriteria(criteriaList);
    try {
      ReportingClientFactory
          .getRetrieveReportForCriteria(EnvironmentEnum.DEV_EXT, request);
    } catch (Exception e) {
      assertEquals(
          "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : The number of criteria in request does not match the report\n",
          e.getMessage());
    }
  }

  public void testRetrieveDocumentForCriteria_RequestIsInValid_InputStreamIsNullSonal() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    request.setRoleName("BO-APOLLO");
    request.setApplicationName("APOLLO");
    request.setDocumentId("FtMSrkwPDQsA5Q0AAKDLRlsBACToe.hu");
    request.setFormat(com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.OutputFormat.PDF);

    ListOfCriteria criteriaList = new ListOfCriteria();

    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("Enter Date Design Created:");
    criteria.setName("Enter Date Design Created:");
    criteria.setPromptType("DATETIME");
    criteria.setAllowMultiValues(false);
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("1");
    criteriaValue.setValue("10/20/2010 09:56:40 AM");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    request.setListOfCriteria(criteriaList);
    try {
      ReportingClientFactory
          .getRetrieveReportForCriteria(EnvironmentEnum.DEV_EXT, request);
    } catch (Exception e) {
      assertEquals(
          "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : The number of criteria in request does not match the report\n",
          e.getMessage());
    }
  }


  public void testRetrieveListOfCriteriaForReport_RequestIsInValid_ResponseIsNull() throws Exception {

    RetrieveListOfCriteriaRequestType request = new RetrieveListOfCriteriaRequestType();
    request.setRoleName("role");
    request.setApplicationName("test");
    request.setDocumentId("90700");

    try {
      ReportingClientFactory
          .getRetrieveListOfCriteriaForDocument(EnvironmentEnum.DEV_EXT, request);
    } catch (Exception e) {
      assertEquals(
          "Error occurred during operation: getListOfCriteria : The document reference 90700 is invalid. (WRE 02501)",
          e.getMessage());
    }
  }


  public void testRetrieveListOfCriteriaForReport_RequestIsValid_ResponseIsSet() throws Exception {

    RetrieveListOfCriteriaRequestType request = new RetrieveListOfCriteriaRequestType();
    request.setRoleName("role");
    request.setApplicationName("test");
    request.setDocumentId("109674");

    RetrieveListOfCriteriaResponseType retrieveListOfCriteriaForDocumentClient = ReportingClientFactory
        .getRetrieveListOfCriteriaForDocument(EnvironmentEnum.DEV_EXT, request);
    assertNotNull(retrieveListOfCriteriaForDocumentClient);
    List<CriteriaInfo> criteriaList = retrieveListOfCriteriaForDocumentClient.getCriteriaInfo();
    assertEquals(3, criteriaList.size());
    CriteriaInfo criteriaInfo = criteriaList.get(0);
    assertEquals("ROOT.0", criteriaInfo.getID());
    assertEquals("TEXT", criteriaInfo.getPromptType());
    assertTrue(criteriaInfo.isHasLOV());
    assertTrue(1 < criteriaInfo.getLOV().getValues().size());
    criteriaInfo = criteriaList.get(1);
    assertEquals("ROOT.1", criteriaInfo.getID());
    assertEquals("NUMERIC", criteriaInfo.getPromptType());
    assertFalse(criteriaInfo.isHasLOV());
    criteriaInfo = criteriaList.get(2);
    assertEquals("ROOT.2", criteriaInfo.getID());
    assertEquals("NUMERIC", criteriaInfo.getPromptType());
    assertFalse(criteriaInfo.isHasLOV());
  }


  public void testViewListOfReportsForARole_RequestIsValid_ResponseIsSet() throws Exception {

    RetrieveReportRequestType request = new RetrieveReportRequestType();
    request.setRoleName("BO-APOLLO");
    request.setApplicationName("APOLLO");
    request.setPathToFolder("US/TPS/Field Testing/Apollo");

    RetrieveReportResponseType response = ReportingClientFactory
        .getViewReports(EnvironmentEnum.DEV_EXT, request);
    assertNotNull(response);
    assertTrue(1 < response.getBoDocument().size());
    BoDocument boDocument = response.getBoDocument().get(0);
//    assertEquals("109057", boDocument.getId());
    assertEquals("Apollo Testing Report", boDocument.getName());
  }


  public void testViewListOfReportsForARole_RequestIsInValid_ResponseIsNull() throws Exception {

    RetrieveReportRequestType request = new RetrieveReportRequestType();
    request.setRoleName("role");
    request.setApplicationName("test");
    try {
      RetrieveReportResponseType response = ReportingClientFactory
          .getViewReports(EnvironmentEnum.DEV_EXT, request);
    } catch (Exception e) {
      assertEquals("Error occurred during operation: getReports : Received in-complete RetrieveReportsRequest object",
          e.getMessage());
    }
  }

  public void writeToFile(InputStream is, File file) {
    try {
      DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(file)));
      int c;
      while ((c = is.read()) != -1) {
        out.writeByte(c);
      }
      is.close();
      out.close();
    }

    catch (IOException e) {
      System.err.println("Error Writing/Reading Streams.");
    }
  }
}
