package com.monsanto.eas.reportingservice.helper;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import com.monsanto.eas.reportingservice.reportingengine.*;
import com.monsanto.eas.reportingservice.utils.Configuration;

public class ReportEngineConnectionHelper {

    public static ConnectionObjectBO getCredentialsAndConnection(String roleName) throws Exception {
        Configuration roleToApplicationMapping = new Configuration();
        String applicationAccountForRole = roleToApplicationMapping.getProperty(roleName);
        String passwordForApplicationAccount = passwordForAppAccount(applicationAccountForRole);
        BusinessObjectsConnectorFactory businessObjectsConnectorFactory = (BusinessObjectsConnectorFactory) ConnectionFactory
              .getReportingEngineConnectionFactory(ConnectionFactory.BUSINESS_OBJECTS);

        String cmsName = roleToApplicationMapping.getProperty(BOConstants.CMS_NAME);
        return businessObjectsConnectorFactory.getCMSConnection(cmsName, applicationAccountForRole, passwordForApplicationAccount);
    }

    private static String passwordForAppAccount(String reportEngineAppAccount) throws EncryptorException {
      return EncryptionUtils.GetDecryptedStringFromExternalStorage(
          BOConstants.ENV_VARIABLE_MONCRYPTJV,
          "reportingservice",
          reportEngineAppAccount + "_" + BOConstants.FILE_ENCRYPTED_PWD_VALUE,
          reportEngineAppAccount + "_" + BOConstants.FILE_ENCRYPTED_PWD_KEY);
    }
}