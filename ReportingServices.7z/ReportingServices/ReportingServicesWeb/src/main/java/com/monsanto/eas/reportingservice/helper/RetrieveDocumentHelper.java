/*
 RetrieveDocumentHelper was created on Apr 7, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.helper;

import com.businessobjects.rebean.wi.*;
import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.occa.infostore.CePropertyID;
import com.crystaldecisions.sdk.occa.infostore.IInfoObject;
import com.crystaldecisions.sdk.occa.infostore.IInfoStore;
import com.crystaldecisions.sdk.occa.infostore.RightDescriptor;
import com.crystaldecisions.sdk.occa.managedreports.IReportAppFactory;
import com.crystaldecisions.sdk.occa.report.application.OpenReportOptions;
import com.crystaldecisions.sdk.occa.report.application.ReportClientDocument;
import com.crystaldecisions.sdk.occa.report.data.Fields;
import com.crystaldecisions.sdk.occa.report.data.IParameterField;
import com.crystaldecisions.sdk.occa.report.document.ISummaryInfo;
import com.crystaldecisions.sdk.occa.report.exportoptions.ReportExportFormat;
import com.crystaldecisions.sdk.occa.report.lib.ReportSDKException;
import com.crystaldecisions.sdk.plugin.desktop.report.CeReportRightID;
import com.crystaldecisions.sdk.plugin.desktop.report.IReport;
import com.crystaldecisions.sdk.properties.IProperties;
import com.crystaldecisions.sdk.properties.IProperty;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.reportingservice.reportingengine.BOConstants;
import com.monsanto.eas.reportingservice.reportingengine.ConnectionObjectBO;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.*;
import com.monsanto.eas.reportingservice.service.RetrieveDocumentFault;
import org.apache.log4j.Logger;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import java.io.InputStream;
import java.util.Calendar;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class RetrieveDocumentHelper {

    private Logger loggerForRetrieveDocument = Logger.getLogger(this.getClass());
    private static final String FILE_NAME = "document";
    public static final String MIME_TYPE = "application/";
    public static final String REFRESH_KIND = "Webi";
    public static final String REFRESH_KIND_CR = "CrystalReport";
    private final static String CUID_PROTOCOL = "cuid://<";
    private final static String CUID_CLOSE_PROTOCOL = ">";
    private final static String APOLLO_ROLE_NAME = "BO-APOLLO";
    private final static String APOLLO_DOCUMENT_UID = "Fp3EBE7ibgAAPF8AAKA78VoCACToe.kW";
    public static final String WEBI_KIND = "Webi";
    public static final String REPORT_FACTORY = "RASReportFactory";

    public RetrieveDocumentResponseType getDocumentById(RetrieveDocumentRequestType request) throws RetrieveDocumentFault {
        RetrieveDocumentResponseType responseType = null;
        try {
            validateRetrieveDocumentRequest(request);
            ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(request.getRoleName());
            IInfoObject document = RetrieveDocumentHelper.getDocumentByUID(request.getDocumentId(), boConnector.getInfoStore());
            if(document != null) {
                DocumentDetails detailForBODocument = getDocumentDetails(boConnector, document, request);
                boConnector.logout();
                responseType = new RetrieveDocumentResponseType();
                responseType.setDocumentDetails(detailForBODocument);
            }
        } catch (Exception e) {
            e.printStackTrace();
            loggerForRetrieveDocument.error("Exception occured in getDocumentById : " + e.getMessage());
            throwFault(e, "getDocumentById");
        }
        return responseType;
    }

    private DocumentDetails getDocumentDetails(ConnectionObjectBO boConnector, IInfoObject document, RetrieveDocumentRequestType request) throws Exception {
        DocumentDetails detailForBODocument = new DocumentDetails();
        DocumentViewDetails details = new DocumentViewDetails();
        String kind = document.properties().getProperty(CePropertyID.SI_KIND) != null ? (String)document.properties().getProperty(CePropertyID.SI_KIND).getValue() : null;
        if(kind != null && !kind.contains(WEBI_KIND)) {
            processCrystalReport(detailForBODocument, details, boConnector, document, request);
        } else {
            processWebi(detailForBODocument, details, boConnector, document, request);
        }
        return detailForBODocument;
    }

    private byte[] getCrystalReportView(ReportClientDocument documentInstance, RetrieveDocumentRequestType request) throws Exception {
        InputStream byteArrayInputStream =
                documentInstance.getPrintOutputController().export(getCrystalReportOutputFormat(request));
        byte[] byteArray = new byte[byteArrayInputStream.available()];
        byteArrayInputStream.read(byteArray, 0, byteArrayInputStream.available());
        byteArrayInputStream.close();
        return byteArray;
    }

    private void processCrystalReport(DocumentDetails detailForBODocument, DocumentViewDetails details, ConnectionObjectBO boConnector,
                                      IInfoObject document, RetrieveDocumentRequestType request) throws Exception {
        IInfoObject report = RetrieveListOfCriteriaForDocumentHelper.getPromptsDocumentByUID(String.valueOf(document.getID()), boConnector.getInfoStore());
        IReportAppFactory reportAppFactory = (IReportAppFactory)boConnector.getSession().getService(REPORT_FACTORY);
        ReportClientDocument documentInstance = reportAppFactory.openDocument(report, OpenReportOptions._openAsReadOnly, java.util.Locale.US);
        detailForBODocument.setUID(request.getDocumentId());
        if(meetRequiredDefaultValues(documentInstance)) {
            byte[] docBinaryView = getCrystalReportView(documentInstance, request);
            OutputView outputView = createViewObjectCrystalReportToSetInResponse(document, documentInstance, docBinaryView, report);
            setDocumentContent(null, request, details, outputView, detailForBODocument, docBinaryView);
            documentInstance.close();
        }
    }

    private void processWebi(DocumentDetails detailForBODocument, DocumentViewDetails details, ConnectionObjectBO boConnector, IInfoObject document, RetrieveDocumentRequestType request) throws Exception {
        ReportEngine reportEngine = boConnector.getReportEngine();
        DocumentInstance documentInstance = reportEngine.openDocument(document.getID());
        BinaryView docBinaryView = (BinaryView) documentInstance.getView(getOutputFormat(request));
        detailForBODocument.setUID(request.getDocumentId());
        OutputView outputView = createViewObjectToSetInResponse(document, documentInstance, docBinaryView, reportEngine);
        setDocumentContent(docBinaryView, request, details, outputView, detailForBODocument, null);
        documentInstance.closeDocument();
        reportEngine.close();
    }

    private void setDocumentContent(BinaryView docBinaryView, RetrieveDocumentRequestType request, DocumentViewDetails details, OutputView outputView, DocumentDetails detailForBODocument, byte[] docCRBinaryView) throws Exception {
        if(docBinaryView != null || docCRBinaryView != null) {
            DataHandler dataHandler = new DataHandler(new FileDataSource(getFileName(request)));
            if(docBinaryView != null) {
                dataHandler.getOutputStream().write((docBinaryView.getContent()));
            } else {
                dataHandler.getOutputStream().write(docCRBinaryView);
            }
            details.setContent(dataHandler);
            outputView.setDocumentViewDetails(details);
            detailForBODocument.setView(outputView);
        }
    }

    private String getFileName(RetrieveDocumentRequestType request) {
        return FILE_NAME + "." +
                (OutputFormat.PDF.equals(request.getFormat()) ? BOConstants.VIEW_PDF_FORMAT : BOConstants.VIEW_EXCEL_FORMAT);
    }

    private OutputView createViewObjectToSetInResponse(IInfoObject document, DocumentInstance documentInstance, BinaryView docBinaryView, ReportEngine reportEngine) throws SDKException {
        OutputView outputView = new OutputView();
        outputView.setMustFillPassword(documentInstance.getMustFillPassword());
        outputView.setMustFillPrompts(documentInstance.getMustFillPrompts());
        outputView.setMustFillQueryContexts(documentInstance.getMustFillContexts());
        outputView.setContentLength(docBinaryView.getContentLength());
        outputView.setDrillable(reportEngine.getCanDrillInDocument());
        outputView.setName(document.getTitle());
        addPropertiesType(outputView, documentInstance.getProperties());
        addCEProperties(outputView, document.properties(), document, REFRESH_KIND);
        loggerForRetrieveDocument.info("Service Name: RetrieveDocumentService Response Name: " + outputView.getName() + ", ContentLength: " +  outputView.getContentLength());
        return outputView;
    }

    private OutputView createViewObjectCrystalReportToSetInResponse(IInfoObject document, ReportClientDocument documentInstance,
                                                                    byte[] docBinaryView, IInfoObject report) throws Exception {
        OutputView outputView = new OutputView();
        outputView.setContentLength(docBinaryView.length);
        outputView.setName(document.getTitle());
        addCrystalReportPropertiesType(outputView, documentInstance, report);
        addCEProperties(outputView, document.properties(), document, REFRESH_KIND_CR);
        loggerForRetrieveDocument.info("Service Name: RetrieveDocumentService Response Name: " + outputView.getName() + ", ContentLength: " +  outputView.getContentLength());
        return outputView;
    }

    private boolean meetRequiredDefaultValues(ReportClientDocument documentInstance) throws ReportSDKException {
        Fields<IParameterField> parameterFields = documentInstance.getDataDefController().getDataDefinition().getParameterFields();
        if(parameterFields != null && !parameterFields.isEmpty()) {
            for(int parameterNum = 0; parameterNum < parameterFields.size(); parameterNum++) {
                IParameterField parameterField = (IParameterField)parameterFields.getField(parameterNum);
                if( parameterField.getIsPromptToUser() && !parameterField.getIsOptionalPrompt() &&
                    parameterField.getDefaultValues().size() == 0)  {
                    return false;
                }
            }
        }
        return true;
    }

    private void addCrystalReportPropertiesType(OutputView outputView, ReportClientDocument documentInstance, IInfoObject report) throws ReportSDKException {
        ISummaryInfo reportInfo = documentInstance.getReportDocument().getSummaryInfo();
        outputView.setAuthor(reportInfo != null ? reportInfo.getAuthor() : null);
        outputView.setMimeType(((IReport)report).getMimeType());
    }

    private void addPropertiesType(OutputView outputView, Properties properties) throws SDKException {
        outputView.setAuthor(properties.getProperty(PropertiesType.AUTHOR) != null ? properties.getProperty(PropertiesType.AUTHOR) : null);
        outputView.setMimeType(properties.getProperty(PropertiesType.DOCUMENT_TYPE) != null ? MIME_TYPE + properties.getProperty(PropertiesType.DOCUMENT_TYPE).toLowerCase() : null);
        outputView.setRefreshOnOpen(properties.getProperty(PropertiesType.REFRESH_ON_OPEN) != null ?
                Boolean.valueOf(properties.getProperty(PropertiesType.REFRESH_ON_OPEN)) : null);
    }

    private void addCEProperties(OutputView outputView, IProperties properties, IInfoObject document, String refreshKind) throws SDKException {
        IProperty creationTimeProperty = properties.getProperty(CePropertyID.SI_CREATION_TIME);
        if(creationTimeProperty != null) {
            Calendar creationTime = Calendar.getInstance();
            creationTime.setTimeZone(TimeZone.getTimeZone(ConnectionObjectBO.DEFAULT_TIME_ZONE));
            creationTime.setTime((java.util.Date) creationTimeProperty.getValue());
            outputView.setCreationDate(creationTime);
        }
        RightDescriptor refreshReportRight = new RightDescriptor(CeReportRightID.REFRESH_ON_DEMAND, refreshKind, true);
        outputView.setRefreshable(document.getSecurityInfo2().checkRight(refreshReportRight, false));
    }

  private void validateRetrieveDocumentRequest(RetrieveDocumentRequestType request) throws Exception {
    if ((request == null) || StringUtils.isNullOrEmpty(request.getApplicationName()) ||
        StringUtils.isNullOrEmpty(request.getDocumentId()) || StringUtils.isNullOrEmpty(request.getRoleName())
        || (request.getFormat() == null || StringUtils.isNullOrEmpty(request.getFormat().value()))) {
      throw new Exception("Received in-complete Retrieve Document object");
    }

    if (!OutputFormat.PDF.equals(request.getFormat()) && !OutputFormat.XLS.equals(request.getFormat())) {
      throw new Exception("Received incorrect view format for  ViewDocumentRequest object");
    }

    loggerForRetrieveDocument.info("Service Name: RetrieveDocumentService Request RoleName: " + request.getRoleName() +
            ", ApplicationName: " +  request.getApplicationName() + ", DocumentId: " + request.getDocumentId() + ", Format: " + request.getFormat().value());
  }

    private OutputFormatType getOutputFormat(RetrieveDocumentRequestType request) {
        return request.getFormat().value().equalsIgnoreCase(BOConstants.VIEW_PDF_FORMAT) ? OutputFormatType.PDF : OutputFormatType.XLS;
    }

    private ReportExportFormat getCrystalReportOutputFormat(RetrieveDocumentRequestType request) {
        return request.getFormat().value().equalsIgnoreCase(BOConstants.VIEW_PDF_FORMAT) ? ReportExportFormat.PDF : ReportExportFormat.MSExcel;
    }

  private void throwFault(Throwable error, String operationName) throws RetrieveDocumentFault {
    loggerForRetrieveDocument.error(error);
    ExceptionType exception = new ExceptionType();
    exception.setFaultCode(error.getMessage());
    exception.setFaultMessage(getStackTrace(error));
    throw new RetrieveDocumentFault("Error occurred during operation: " + operationName + " : " + error.getMessage(),
        exception, error);
  }

  private String getStackTrace(Throwable error) {
    StringBuffer stringBuffer = new StringBuffer();
    for (int index = 0; index < error.getStackTrace().length; index++) {
      stringBuffer.append(error.getStackTrace()[index].toString());
      stringBuffer.append("\n");
    }
    return stringBuffer.toString();
  }

    public static IInfoObject getDocumentByUID(String documentUID, IInfoStore infoStore) throws SDKException {
        String queryString = CUID_PROTOCOL + documentUID + CUID_CLOSE_PROTOCOL + ViewReportsHelper.FIELDS_INCLUDED;
        List<IInfoObject> documents = ViewReportsHelper.obtainDocuments(queryString, infoStore);
        if(documents != null && !documents.isEmpty()) {
            return documents.get(0);
        }
        return null;
    }

    public static void initEnterpriseEngine() {
        try {
            ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(APOLLO_ROLE_NAME);
            IInfoObject document = RetrieveDocumentHelper.getDocumentByUID(APOLLO_DOCUMENT_UID, boConnector.getInfoStore());
            RetrieveListOfCriteriaForDocumentHelper.getPromptsDocumentByUID(String.valueOf(document.getID()), boConnector.getInfoStore());
        } catch (Exception e) {}
    }

}