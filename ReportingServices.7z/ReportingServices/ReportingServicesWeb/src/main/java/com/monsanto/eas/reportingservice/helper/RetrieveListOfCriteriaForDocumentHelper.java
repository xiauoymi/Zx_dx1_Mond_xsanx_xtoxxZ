/*
 RetrieveListOfCriteriaForDocumentHelper was created on Apr 8, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.helper;

import com.businessobjects.rebean.wi.*;
import com.businessobjects.sdk.plugin.desktop.webi.IWebi;
import com.businessobjects.sdk.plugin.desktop.webi.IWebiDocPrompt;
import com.businessobjects.sdk.plugin.desktop.webi.IWebiDocPrompts;
import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.occa.infostore.CePropertyID;
import com.crystaldecisions.sdk.occa.infostore.IInfoObject;
import com.crystaldecisions.sdk.occa.infostore.IInfoObjects;
import com.crystaldecisions.sdk.occa.infostore.IInfoStore;
import com.crystaldecisions.sdk.plugin.desktop.common.*;
import com.crystaldecisions.sdk.plugin.desktop.report.IReport;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.reportingservice.reportingengine.BOConstants;
import com.monsanto.eas.reportingservice.reportingengine.ConnectionObjectBO;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.*;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.Lov;
import com.monsanto.eas.reportingservice.service.RetrieveCriteriaForDocumentFault;
import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class RetrieveListOfCriteriaForDocumentHelper {

    private Logger loggerForRetrieveCriteria = Logger.getLogger(this.getClass());
    private final static String DOCUMENT_QUERY = "select * from CI_INFOOBJECTS WHERE SI_INSTANCE = 0 AND SI_ID = ";
    public static final String CR_BOOLEAN = "BOOLEAN";
    public static final String CR_CURRENCY = "CURRENCY";
    public static final String CR_DATE = "DATE";
    public static final String CR_DATE_TIME = "DATE_TIME";
    public static final String CR_NUMERIC = "NUMERIC";
    public static final String CR_TEXT = "TEXT";
    public static final String CR_TIME = "TIME";
    private static final String NULL_VALUE = "NULL";
    public static final String WEBI_PROMPT_TYPE_MULTI = "Multi";


  public RetrieveListOfCriteriaResponseType getListOfCriteria(RetrieveListOfCriteriaRequestType request) throws RetrieveCriteriaForDocumentFault {
      RetrieveListOfCriteriaResponseType response = new RetrieveListOfCriteriaResponseType();
      try {
          validateRequest(request);
          ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(request.getRoleName());
          IInfoObject document = RetrieveDocumentHelper.getDocumentByUID(request.getDocumentId(), boConnector.getInfoStore());
          if(document != null) {
              getCriteriaInfo(boConnector, document, response);
              boConnector.logout();
            }
      } catch (Exception e) {
          e.printStackTrace();
          loggerForRetrieveCriteria.error("Exception in getListOfCriteria  : " + e.getMessage());
          throwFault(e, "getListOfCriteria");
      }
      return response;
  }

    private void getCriteriaInfo(ConnectionObjectBO boConnector, IInfoObject document, RetrieveListOfCriteriaResponseType response) throws Exception {
        String kind = document.properties().getProperty(CePropertyID.SI_KIND) != null ? (String)document.properties().getProperty(CePropertyID.SI_KIND).getValue() : null;
        if(kind != null && !kind.contains(RetrieveDocumentHelper.WEBI_KIND)) {
            IInfoObject report = RetrieveListOfCriteriaForDocumentHelper.getPromptsDocumentByUID(String.valueOf(document.getID()), boConnector.getInfoStore());
            processCrystalReportPrompts((IReport)report, response);
        } else {
            com.businessobjects.rebean.wi.ReportEngine reportEngine = boConnector.getReportEngine();
            DocumentInstance documentInstance = reportEngine.openDocument(document.getID());
            IInfoObject documentPrompt =  RetrieveListOfCriteriaForDocumentHelper.getPromptsDocumentByUID(String.valueOf(document.getID()), boConnector.getInfoStore());
            Map<String, IWebiDocPrompt> docPromptsMap = addProperties(documentPrompt);
            processPrompts(documentInstance, docPromptsMap, response);
            documentInstance.closeDocument();
            reportEngine.close();
        }
    }

    private void processPrompts(DocumentInstance documentInstance, Map<String, IWebiDocPrompt> docPromptsMap, RetrieveListOfCriteriaResponseType response) {
        Prompts prompts = documentInstance.getPrompts();
        for(int promptNum = 0; promptNum < prompts.getCount(); promptNum++) {
            CriteriaInfo criteria = new CriteriaInfo();
            Prompt promptInfo = prompts.getItem(promptNum);
            setPropertiesForCriteriaObject(promptInfo, criteria);
            setAdditionalPropertiesForCriteriaObject(docPromptsMap, promptInfo, criteria);
            Lov listOfValue = forEachPromptSetTheLOV(promptInfo);
            criteria.setLOV(listOfValue);
            loggerForRetrieveCriteria.info("Service Name: RetrieveListOfCriteriaForDocumentService Response ID: " + criteria.getID() + ", Name: " + criteria.getName());
            response.getCriteriaInfo().add(criteria);
        }
    }

    private void processCrystalReportPrompts(IReport report, RetrieveListOfCriteriaResponseType response) throws SDKException {
        List boParamList = (List)report.getReportParameters();
        if(boParamList != null && !boParamList.isEmpty()) {
            Iterator paramIterator = boParamList.iterator();
            while(paramIterator.hasNext()) {
                IReportParameter reportParameter = (IReportParameter)paramIterator.next();
                if(reportParameter.getParameterField().getIsPromptToUser()) {
                    CriteriaInfo criteria = new CriteriaInfo();
                    setPropertiesCrystalReportForCriteriaObject(reportParameter, criteria);
                    loggerForRetrieveCriteria.info("Service Name: RetrieveListOfCriteriaForDocumentService Response ID: " + criteria.getID() + ", Name: " + criteria.getName());
                    response.getCriteriaInfo().add(criteria);
                }
            }
        }
    }

    private Map<String, IWebiDocPrompt> addProperties(IInfoObject documentPrompt) throws Exception {
        Map<String, IWebiDocPrompt> docPromptsMap = null;
        IWebi report = (IWebi)documentPrompt;
        if(report.hasPrompts()) {
            IWebiDocPrompts docPrompts = report.getDocumentPrompts();
            docPromptsMap = new HashMap<String, IWebiDocPrompt>();
            for(int reportPrompt = 0; reportPrompt < docPrompts.count(); reportPrompt++) {
                docPromptsMap.put(docPrompts.item(reportPrompt).getID(), docPrompts.item(reportPrompt));
            }
        }
        return docPromptsMap;
    }

    private Lov forEachPromptSetTheLOV(Prompt promptInfo) {
        Lov listOfValue = new Lov();
        if(promptInfo.hasLOV()) {
            com.businessobjects.rebean.wi.Lov promptLov = promptInfo.getLOV();
            Values values = addLovHeaders(promptLov, listOfValue);
            listOfValue.setRowIndexed(promptInfo.isRowIndexed());
            listOfValue.setSorted(promptLov.isSorted());
            listOfValue.setSortedColumnIndex(new Integer(promptLov.getSortedColumnIndex()));
            for(String batch: promptLov.getBatchNames()) {
                listOfValue.getBatchNameArray().add(batch);
            }
            populateValuesForLov(listOfValue, values);
        }
        return listOfValue;
    }

    private Values addLovHeaders(com.businessobjects.rebean.wi.Lov promptLov, Lov listOfValue) {
        Values values = promptLov.getAllValues();
        if(values != null && values.getCount() > 0) {
            for(int headerCounter = 0; headerCounter < values.getRowValue(0).getCount(); headerCounter++) {
                listOfValue.getHeaderArray().add(values.getRowValue(0).getHeader(headerCounter));
            }
        }
        return values;
    }

    private void populateValuesForLov(Lov listOfValue, Values valuesForPrompt) {
        if(valuesForPrompt != null && valuesForPrompt.getCount() > 0) {
            for(int counter = 0; counter < valuesForPrompt.getCount(); counter++) {
                LovValues values = new LovValues();
                if(valuesForPrompt.isMultiColumns()) {
                    for(int i = 0; i < valuesForPrompt.getRowValue(counter).getCount(); i++) {
                        values.getColumns().add(valuesForPrompt.getRowValue(counter).getItem(i));
                    }
                } else {
                    values.getColumns().add(valuesForPrompt.getValue(counter));
                }
                values.setIsDefault(valuesForPrompt.isDefault(counter));
                values.setWasSelected(valuesForPrompt.wasSelected(counter));
                values.setRowIndex(valuesForPrompt.getValueFromLov(counter).getRowIndex());
                listOfValue.getValues().add(values);
            }
        }
    }

    private void setAdditionalPropertiesForCriteriaObject(Map<String, IWebiDocPrompt> docPromptsMap, Prompt promptInfo, CriteriaInfo criteria) {
        if(docPromptsMap != null && !docPromptsMap.isEmpty()) {
            criteria.setLocalizedQuestion(docPromptsMap.get(promptInfo.getID()) != null ? docPromptsMap.get(promptInfo.getID()).getQuestion() : promptInfo.getName());
        }
    }

    private void setPropertiesForCriteriaObject(Prompt promptInfo, CriteriaInfo criteria) {
        criteria.setID(promptInfo.getID());
        criteria.setName(promptInfo.getName());
        criteria.setPromptType(promptInfo.getObjectType().toString());
        criteria.setConstrained(promptInfo.isConstrained());
        criteria.setRequireAnswers(promptInfo.requireAnswer());
        criteria.setHasLOV(promptInfo.hasLOV());
        criteria.setAllowMultiValues(promptInfo.getType().toString().contains(WEBI_PROMPT_TYPE_MULTI) ? true : false);
        criteria.setAllowDiscreteValue(true);
        criteria.setOptional(promptInfo.isOptional());
        criteria.setPromptValueFormat(new String[] {promptInfo.getInputFormat()});
        addPreviousValues(promptInfo, criteria);
        addDataProviders(promptInfo, criteria);
    }

    private void setPropertiesCrystalReportForCriteriaObject(IReportParameter reportParameter, CriteriaInfo criteria) {
        criteria.setID(reportParameter.getParameterField().getFormulaForm());
        criteria.setName(reportParameter.getParameterName());
        criteria.setPromptType(getCrystalReportPromptType(reportParameter));
        criteria.setRequireAnswers(!reportParameter.isOptionalPrompt());
        criteria.setAllowMultiValues(reportParameter.isMultipleValuesEnabled());
        criteria.setAllowDiscreteValue(reportParameter.isDiscreteValueSupported());
        criteria.setAllowRangeValue(reportParameter.isRangeValueSupported());
        criteria.setOptional(reportParameter.isOptionalPrompt());
        criteria.setPromptValueFormat(new String[] {reportParameter.getEditMask()});
        criteria.setDescription(reportParameter.getPrompt());
        criteria.setLocalizedQuestion(reportParameter.getValueDisplayString(java.util.Locale.US));
        addCrystalReportPreviousValues(reportParameter, criteria);
    }

    private String getCrystalReportPromptType(IReportParameter reportParameter) {
        switch(reportParameter.getValueType()) {
            case IReportParameter.ReportVariableValueType.BOOLEAN:
                return CR_BOOLEAN;
            case IReportParameter.ReportVariableValueType.CURRENCY:
                return CR_CURRENCY;
            case IReportParameter.ReportVariableValueType.DATE:
                return CR_DATE;
            case IReportParameter.ReportVariableValueType.DATE_TIME:
                return CR_DATE_TIME;
            case IReportParameter.ReportVariableValueType.NUMBER:
                return CR_NUMERIC;
            case IReportParameter.ReportVariableValueType.STRING:
                return CR_TEXT;
            case IReportParameter.ReportVariableValueType.TIME:
                return CR_TIME;
        }
        return null;
    }

    private void addPreviousValues(Prompt promptInfo, CriteriaInfo criteria) {
        int count = 0;
        for(String previousValue : promptInfo.getPreviousValues()) {
            BoPromptValue previousValueForCriteria = new BoPromptValue();
            setPromptValueAsADiscretePrompt(previousValue, previousValueForCriteria);
            criteria.getPreviousValues().add(count, previousValueForCriteria);
            count++;
        }
    }

    private void addCrystalReportPreviousValues(IReportParameter reportParameter, CriteriaInfo criteria) {
        int count = 0;
        IReportParameterValues reportParameterValues = reportParameter.getCurrentValues();
        if(reportParameterValues != null && !reportParameterValues.isEmpty() && !reportParameterValues.isNoValue()) {
            Iterator reportParameterValuesIterator = reportParameterValues.iterator();
            while(reportParameterValuesIterator.hasNext()) {
                IReportParameterValue reportParameterValue = (IReportParameterValue)reportParameterValuesIterator.next();
                BoPromptValue previousValueForCriteria = new BoPromptValue();
                if(reportParameterValue instanceof IReportParameterSingleValue && !reportParameterValue.isNull()) {
                    setPromptValueAsADiscretePrompt(((IReportParameterSingleValue)reportParameterValue).getValue(), previousValueForCriteria);
                } else if(reportParameterValue instanceof IReportParameterRangeValue && !reportParameterValue.isNull()) {
                    setPromptValueAsARangePrompt((IReportParameterRangeValue) reportParameterValue, previousValueForCriteria);
                }
                criteria.getPreviousValues().add(count++, previousValueForCriteria);
            }
        }
    }

    private void setPromptValueAsARangePrompt(IReportParameterRangeValue rangePromptValue, BoPromptValue previousValueForCriteria) {
        if(previousValueForCriteria == null) {
            previousValueForCriteria = new BoPromptValue();
        }
        if(rangePromptValue != null) {
            previousValueForCriteria.setType(BOConstants.RANGE_PROMPT_VALUE);
            previousValueForCriteria.setStartValue(rangePromptValue.getFromValue().isNull() ? null : rangePromptValue.getFromValue().getValue());
            previousValueForCriteria.setEndValue(rangePromptValue.getToValue().isNull() ? null : rangePromptValue.getToValue().getValue());
            previousValueForCriteria.setStartValueInclusive(rangePromptValue.isLowerBoundIncluded());
            previousValueForCriteria.setEndValueInclusive(rangePromptValue.isUpperBoundIncluded());
            previousValueForCriteria.setStartValueUnbound(rangePromptValue.isLowerBoundNotAvailable());
            previousValueForCriteria.setEndValueUnbound(rangePromptValue.isUpperBoundNotAvailable());
            previousValueForCriteria.setIsNilStartValue(rangePromptValue.getFromValue().isNull());
            previousValueForCriteria.setIsNilEndValue(rangePromptValue.getToValue().isNull());
        }
    }

    private void setPromptValueAsADiscretePrompt(String previousValue, BoPromptValue previousValueForCriteria) {
        if(previousValueForCriteria == null) {
            previousValueForCriteria = new BoPromptValue();
        }
        if(previousValue != null && !previousValue.equalsIgnoreCase(NULL_VALUE)) {
            previousValueForCriteria.setType(BOConstants.DISCRETE_PROMPT_VALUE);
            previousValueForCriteria.setValue(previousValue);
        }
    }

    private void addDataProviders(Prompt promptInfo, CriteriaInfo criteria) {
        DataProvider[] dataProviders = promptInfo.getDataProviders();
        if(dataProviders.length > 0) {
            String[] dataProvidersId = new String[dataProviders.length];
            int dataProvidersIdCount = 0;
            for(DataProvider dataProvider : dataProviders) {
                dataProvidersId[dataProvidersIdCount++] = dataProvider.getID();
            }
            criteria.setDataProviderIDS(dataProvidersId);
        }
    }

  private void validateRequest(RetrieveListOfCriteriaRequestType request) throws Exception {
    if ((request == null) || StringUtils.isNullOrEmpty(request.getApplicationName()) ||
        StringUtils.isNullOrEmpty(request.getDocumentId()) || StringUtils.isNullOrEmpty(request.getRoleName())) {
      throw new Exception("Received in-complete RetrieveListOfCriteriaForDocumentRequest object");
    }
    loggerForRetrieveCriteria.info("Service Name: RetrieveListOfCriteriaForDocumentService Request RoleName: " + request.getRoleName() +
            ", ApplicationName: " +  request.getApplicationName() + ", DocumentId: " + request.getDocumentId());
  }

   private void throwFault(Throwable error, String operationName) throws RetrieveCriteriaForDocumentFault {
        loggerForRetrieveCriteria.error(error);
        ExceptionType type = new ExceptionType();
        type.setFaultCode(error.getMessage());
        type.setFaultMessage(getStackTrace(error));
        throw new RetrieveCriteriaForDocumentFault("Error occurred during operation: " + operationName + " : " + error.getMessage(), type, error);
    }

  private String getStackTrace(Throwable error) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int index = 0; index < error.getStackTrace().length; index++) {
            stringBuffer.append(error.getStackTrace()[index].toString());
            stringBuffer.append("\n");
        }
        return stringBuffer.toString();
    }

    public static IInfoObject getPromptsDocumentByUID(String documentUID, IInfoStore infoStore) throws SDKException {
        String queryString = DOCUMENT_QUERY + documentUID;
        IInfoObjects infoObjects = infoStore.query(queryString);
        if(infoObjects != null && !infoObjects.isEmpty()) {
            return (IInfoObject)infoObjects.get(0);
        }
        return null;
    }

}