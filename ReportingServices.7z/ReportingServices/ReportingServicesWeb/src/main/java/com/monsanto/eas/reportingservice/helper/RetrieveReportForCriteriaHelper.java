/*
 RetrieveReportForCriteriaHelper was created on Apr 10, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.helper;

import com.businessobjects.rebean.wi.*;
import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.occa.infostore.CePropertyID;
import com.crystaldecisions.sdk.occa.infostore.IInfoObject;
import com.crystaldecisions.sdk.occa.infostore.RightDescriptor;
import com.crystaldecisions.sdk.occa.managedreports.IReportAppFactory;
import com.crystaldecisions.sdk.occa.report.application.OpenReportOptions;
import com.crystaldecisions.sdk.occa.report.application.ReportClientDocument;
import com.crystaldecisions.sdk.occa.report.data.*;
import com.crystaldecisions.sdk.occa.report.document.ISummaryInfo;
import com.crystaldecisions.sdk.occa.report.exportoptions.ReportExportFormat;
import com.crystaldecisions.sdk.occa.report.lib.ReportSDKException;
import com.crystaldecisions.sdk.plugin.desktop.report.CeReportRightID;
import com.crystaldecisions.sdk.plugin.desktop.report.IReport;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.reportingservice.reportingengine.BOConstants;
import com.monsanto.eas.reportingservice.reportingengine.ConnectionObjectBO;
import com.monsanto.eas.reportingservice.reportingengine.PromptInfoException;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.*;
import com.monsanto.eas.reportingservice.service.RetrieveReportForCriteriaFault;
import org.apache.log4j.Logger;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import java.io.InputStream;
import java.util.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class RetrieveReportForCriteriaHelper {

    private Logger logger = Logger.getLogger(this.getClass());
    private static final String FILE_NAME = "documentFromCriteria";
    private static final String VIEW_MODE = "DOCUMENT";
    private static final String VIEW_TYPE = "BINARY";

    public RetrieveReportForCriteriaResponseType setCriteriaFromRequestAndRetrieveReport(
            RetrieveReportForCriteriaRequestType request) throws RetrieveReportForCriteriaFault {
        RetrieveReportForCriteriaResponseType response = new RetrieveReportForCriteriaResponseType();
        try {
            validateRequest(request);
            ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(request.getRoleName());
            IInfoObject document = RetrieveDocumentHelper.getDocumentByUID(request.getDocumentId(), boConnector.getInfoStore());
            if(document != null) {
                String kind = document.properties().getProperty(CePropertyID.SI_KIND) != null ? (String)document.properties().getProperty(CePropertyID.SI_KIND).getValue() : null;
                if(kind != null && !kind.contains(RetrieveDocumentHelper.WEBI_KIND)) {
                    processCrystalReport(boConnector, document, request, response);
                } else {
                    processWebi(boConnector, document, request, response);
                }
                boConnector.logout();
            }
        } catch (Exception e) {
            e.printStackTrace();
            throwFault(e, "setCriteriaFromRequestAndRetrieveReport");
        }
        return response;
    }

    private void processCrystalReport(ConnectionObjectBO boConnector, IInfoObject document, RetrieveReportForCriteriaRequestType request,
                             RetrieveReportForCriteriaResponseType response) throws Exception {
        IInfoObject report = RetrieveListOfCriteriaForDocumentHelper.getPromptsDocumentByUID(String.valueOf(document.getID()), boConnector.getInfoStore());
        IReportAppFactory reportAppFactory = (IReportAppFactory)boConnector.getSession().getService(RetrieveDocumentHelper.REPORT_FACTORY);
        ReportClientDocument documentInstance = reportAppFactory.openDocument(report, OpenReportOptions._openAsReadOnly, java.util.Locale.US);
        setCrystalReportDocumentDetails(document, request, documentInstance, response, report);
        documentInstance.close();
    }

    private void processWebi(ConnectionObjectBO boConnector, IInfoObject document, RetrieveReportForCriteriaRequestType request,
                             RetrieveReportForCriteriaResponseType response) throws Exception {
        com.businessobjects.rebean.wi.ReportEngine reportEngine = boConnector.getReportEngine();
        DocumentInstance documentInstance = reportEngine.openDocument(document.getID());
        documentInstance.refresh();
        setDocumentDetails(document, request, documentInstance, reportEngine, response);
        documentInstance.closeDocument();
        reportEngine.close();
    }

    private void setCrystalReportDocumentDetails(IInfoObject document, RetrieveReportForCriteriaRequestType request, ReportClientDocument documentInstance,
                                    RetrieveReportForCriteriaResponseType response, IInfoObject report) throws Exception {
        ListOfCriteria listOfCriteria = request.getListOfCriteria();
        Fields<IParameterField> parameterFields = documentInstance.getDataDefController().getDataDefinition().getParameterFields();
        validatePrompts(null, request, listOfCriteria, parameterFields);
        Map<String, Object[]> fillPromptMap = createCrystalReportPromptMap(parameterFields, listOfCriteria);
        setCrystalReportPrompts(parameterFields, fillPromptMap, documentInstance);
        byte[] docBinaryView = getCrystalReportView(documentInstance, request);
        populateCrystalReportResponse(request, response, document, documentInstance, docBinaryView, report);
    }

    private byte[] getCrystalReportView(ReportClientDocument documentInstance, RetrieveReportForCriteriaRequestType request) throws Exception {
        InputStream byteArrayInputStream =
                documentInstance.getPrintOutputController().export(getCrystalReportOutputFormat(request));
        byte[] byteArray = new byte[byteArrayInputStream.available()];
        byteArrayInputStream.read(byteArray, 0, byteArrayInputStream.available());
        byteArrayInputStream.close();
        return byteArray;
    }

    private void setDocumentDetails(IInfoObject document, RetrieveReportForCriteriaRequestType request, DocumentInstance documentInstance,
                                    com.businessobjects.rebean.wi.ReportEngine reportEngine, RetrieveReportForCriteriaResponseType response) throws Exception {
        ListOfCriteria listOfCriteria = request.getListOfCriteria();
        Prompts prompts = documentInstance.getPrompts();
        validatePrompts(prompts, request, listOfCriteria, null);
        Map<String, List<Object>> fillPromptMap = createPromptMap(prompts, listOfCriteria);
        setReportPrompts(prompts, fillPromptMap, documentInstance);
        com.businessobjects.rebean.wi.BinaryView docBinaryView = (com.businessobjects.rebean.wi.BinaryView) documentInstance.getView(getOutputFormat(request));
        populateResponse(request, response, document, documentInstance, docBinaryView, reportEngine);
    }

    private void setCrystalReportPrompts(Fields<IParameterField> parameterFields, Map<String, Object[]> fillPromptMap, ReportClientDocument documentInstance) throws ReportSDKException {
        if(parameterFields != null && !parameterFields.isEmpty()) {
            for(int parameterNum = 0; parameterNum < parameterFields.size(); parameterNum++) {
                IParameterField parameterField = (IParameterField)parameterFields.getField(parameterNum);
                if(parameterField.getIsPromptToUser()) {
                    Object[] setPrompts = fillPromptMap.get(parameterField.getFormulaForm());
                    if(setPrompts != null && setPrompts.length > 0) {
                        documentInstance.getDataDefController().getParameterFieldController().setCurrentValues("", parameterField.getName(), setPrompts);
                    }
                }
            }
        }
    }

    private void setReportPrompts(Prompts prompts, Map<String, List<Object>> fillPromptMap, DocumentInstance documentInstance) {
        for(int promptNum = 0; promptNum < prompts.getCount(); promptNum++) {
            Prompt promptFill = prompts.getItem(promptNum);
            List<Object> setPrompts = fillPromptMap.get(promptFill.getID());
            if(setPrompts != null && !setPrompts.isEmpty()) {
                if( setPrompts.get(0) != null && setPrompts.get(0) instanceof List &&
                    !((List)setPrompts.get(0)).isEmpty()) {
                    String[] values = new String[((List)setPrompts.get(0)).size()];
                    ((List)setPrompts.get(0)).toArray(values);
                    promptFill.enterValues(values);
                }
                if( setPrompts.get(1) != null && setPrompts.get(1) instanceof List &&
                    !((List)setPrompts.get(1)).isEmpty()) {
                    ValueFromLov[] valuesFromLov = new ValueFromLov[((List)setPrompts.get(1)).size()];
                    ((List)setPrompts.get(1)).toArray(valuesFromLov);
                    promptFill.enterValues(valuesFromLov);
                }
            }
        }
        documentInstance.setPrompts();
    }

    private Map<String, Object[]> createCrystalReportPromptMap(Fields<IParameterField> parameterFields, ListOfCriteria listOfCriteria) throws PromptInfoException {
        Map<String, Object[]> fillPromptMap = new HashMap<String, Object[]>(listOfCriteria.getCriteriaInfoFromRequest().size());
        if(parameterFields != null && !parameterFields.isEmpty()) {
            for(int parameterNum = 0; parameterNum < parameterFields.size(); parameterNum++) {
                IParameterField parameterField = (IParameterField)parameterFields.getField(parameterNum);
                if(parameterField.getIsPromptToUser()) {
                    for(CriteriaInfoFromRequest requestPrompt : listOfCriteria.getCriteriaInfoFromRequest()) {
                        if(parameterField.getFormulaForm().equals(requestPrompt.getID())) {
                            if(!parameterField.getName().equalsIgnoreCase(requestPrompt.getName())) {
                                throw new PromptInfoException("Prompt with id " + requestPrompt.getID() +
                                        " does not match prompt " + parameterField.getFormulaForm() + " in business objects");
                            }
                            populateTheFillCrystalReportPromptList(fillPromptMap, parameterField, requestPrompt);
                            break;
                        }
                    }
                }
            }
        }
        return fillPromptMap;
    }

    private Map<String, List<Object>> createPromptMap(Prompts prompts, ListOfCriteria listOfCriteria) throws PromptInfoException {
        Map<String, List<Object>> fillPromptMap = new HashMap<String, List<Object>>(listOfCriteria.getCriteriaInfoFromRequest().size());
        for(int promptNum = 0; promptNum < prompts.getCount(); promptNum++) {
            Prompt promptInfo = prompts.getItem(promptNum);
            for(CriteriaInfoFromRequest requestPrompt : listOfCriteria.getCriteriaInfoFromRequest()) {
                if(promptInfo.getID().equals(requestPrompt.getID())) {
                    if(!promptInfo.getName().equalsIgnoreCase(requestPrompt.getName())) {
                        throw new PromptInfoException("Prompt with id " + requestPrompt.getID() +
                                " does not match prompt " + promptInfo.getID() + " in business objects");
                    }
                    populateTheFillPromptList(fillPromptMap, promptInfo, requestPrompt);
                    break;
                }
            }
        }
        return fillPromptMap;
    }

    private com.businessobjects.rebean.wi.OutputFormatType getOutputFormat(RetrieveReportForCriteriaRequestType request) {
        return request.getFormat().value().equalsIgnoreCase(BOConstants.VIEW_PDF_FORMAT) ? com.businessobjects.rebean.wi.OutputFormatType.PDF : com.businessobjects.rebean.wi.OutputFormatType.XLS;
    }

    private ReportExportFormat getCrystalReportOutputFormat(RetrieveReportForCriteriaRequestType request) {
        return request.getFormat().value().equalsIgnoreCase(BOConstants.VIEW_PDF_FORMAT) ? ReportExportFormat.PDF : ReportExportFormat.MSExcel;
    }

    private void populateCrystalReportResponse(RetrieveReportForCriteriaRequestType request, RetrieveReportForCriteriaResponseType response,
                                  IInfoObject document, ReportClientDocument documentInstance, byte[] docBinaryView, IInfoObject report) throws Exception {
        NewDocument newDocumentFromCriteria = new NewDocument();
        newDocumentFromCriteria.setUID(request.getDocumentId());
        DocumentViewDetails details = new DocumentViewDetails();
        DocViewSupport docViewSupport = new DocViewSupport();
        OutputView outputView = createViewObjectCrystalReportToSetInResponse(document, documentInstance, docBinaryView, request, report);
        setDocumentContent(null, request, details, outputView, docViewSupport, docBinaryView);
        newDocumentFromCriteria.setOutputView(outputView);
        response.setNewDocument(newDocumentFromCriteria);
    }

    private void populateResponse(RetrieveReportForCriteriaRequestType request, RetrieveReportForCriteriaResponseType response,
                                  IInfoObject document, DocumentInstance documentInstance, com.businessobjects.rebean.wi.BinaryView docBinaryView,
                                  com.businessobjects.rebean.wi.ReportEngine reportEngine) throws Exception {
        NewDocument newDocumentFromCriteria = new NewDocument();
        newDocumentFromCriteria.setUID(request.getDocumentId());
        OutputView outputView = createViewObjectToSetInResponse(document, documentInstance, docBinaryView, reportEngine, request);
        DocumentViewDetails details = new DocumentViewDetails();
        DocViewSupport docViewSupport = new DocViewSupport();
        setDocumentContent(docBinaryView, request, details, outputView, docViewSupport, null);
        newDocumentFromCriteria.setOutputView(outputView);
        response.setNewDocument(newDocumentFromCriteria);
    }

    private void setDocumentContent(BinaryView docBinaryView, RetrieveReportForCriteriaRequestType request, DocumentViewDetails details,
                                    OutputView outputView, DocViewSupport docViewSupport, byte[] docCRBinaryView) throws Exception {
        if(docBinaryView != null || docCRBinaryView != null) {
            DataHandler dataHandler = new DataHandler(new FileDataSource(getFileName(request)));
            if(docBinaryView != null) {
                dataHandler.getOutputStream().write((docBinaryView.getContent()));
                logger.info("The response content length is  : " + docBinaryView.getContentLength());
            } else {
                dataHandler.getOutputStream().write(docCRBinaryView);
                logger.info("The response content length is  : " + docCRBinaryView.length);
            }
            details.setContent(dataHandler);
            docViewSupport.setViewMode(VIEW_MODE);
            docViewSupport.setOutputFormat(request.getFormat().value());
            docViewSupport.setViewType(VIEW_TYPE);
            details.setDocumentViewSupport(docViewSupport);
            outputView.setDocumentViewDetails(details);
        }
    }

    private OutputView createViewObjectToSetInResponse(IInfoObject document, DocumentInstance documentInstance, BinaryView docBinaryView,
                                                       ReportEngine reportEngine, RetrieveReportForCriteriaRequestType request) throws SDKException {
        OutputView outputView = new OutputView();
        outputView.setName(document.getTitle());
        outputView.setDocumentReference(request.getDocumentId());
        outputView.setContentLength(docBinaryView.getContentLength());
        outputView.setMustFillPassword(documentInstance.getMustFillPassword());
        outputView.setMustFillQueryContexts(documentInstance.getMustFillContexts());
        outputView.setMustFillPrompts(documentInstance.getMustFillPrompts());
        RightDescriptor refreshReportRight = new RightDescriptor(CeReportRightID.REFRESH_ON_DEMAND, RetrieveDocumentHelper.REFRESH_KIND, true);
        outputView.setRefreshable(document.getSecurityInfo2().checkRight(refreshReportRight, false));
        outputView.setDrillable(reportEngine.getCanDrillInDocument());
        addPropertiesType(outputView, documentInstance.getProperties());
        logger.info("Service Name: RetrieveReportForCriteriaService Response Name: " + outputView.getName() + ", ContentLength: " + outputView.getContentLength());
        return outputView;
    }

    private OutputView createViewObjectCrystalReportToSetInResponse(IInfoObject document, ReportClientDocument documentInstance,
                                                                    byte[] docBinaryView, RetrieveReportForCriteriaRequestType request, IInfoObject report) throws Exception {
        OutputView outputView = new OutputView();
        outputView.setName(document.getTitle());
        outputView.setDocumentReference(request.getDocumentId());
        outputView.setContentLength(docBinaryView.length);
        RightDescriptor refreshReportRight = new RightDescriptor(CeReportRightID.REFRESH_ON_DEMAND, RetrieveDocumentHelper.REFRESH_KIND_CR, true);
        outputView.setRefreshable(document.getSecurityInfo2().checkRight(refreshReportRight, false));
        addCrystalReportPropertiesType(outputView, documentInstance, report);
        logger.info("Service Name: RetrieveReportForCriteriaService Response Name: " + outputView.getName() + ", ContentLength: " + outputView.getContentLength());
        return outputView;
    }

    private void addCrystalReportPropertiesType(OutputView outputView, ReportClientDocument documentInstance, IInfoObject report) throws ReportSDKException {
        ISummaryInfo reportInfo = documentInstance.getReportDocument().getSummaryInfo();
        outputView.setAuthor(reportInfo != null ? reportInfo.getAuthor() : null);
        outputView.setMimeType(((IReport)report).getMimeType());
    }

    private void addPropertiesType(OutputView outputView, Properties properties) throws SDKException {
        outputView.setAuthor(properties.getProperty(PropertiesType.AUTHOR) != null ? properties.getProperty(PropertiesType.AUTHOR) : null);
        outputView.setMimeType(properties.getProperty(PropertiesType.DOCUMENT_TYPE) != null ? RetrieveDocumentHelper.MIME_TYPE + properties.getProperty(PropertiesType.DOCUMENT_TYPE).toLowerCase() : null);
        outputView.setRefreshOnOpen(properties.getProperty(PropertiesType.REFRESH_ON_OPEN) != null ?
                Boolean.valueOf(properties.getProperty(PropertiesType.REFRESH_ON_OPEN)) : null);
    }

    private String getFileName(RetrieveReportForCriteriaRequestType request) {
        return FILE_NAME + "." +
                (OutputFormat.PDF.equals(request.getFormat()) ? BOConstants.VIEW_PDF_FORMAT : BOConstants.VIEW_EXCEL_FORMAT);
    }

    private void populateTheFillPromptList(Map<String, List<Object>> fillPromptMap, Prompt boPrompt,
                                           CriteriaInfoFromRequest requestPrompt) throws PromptInfoException {
        if(requestPrompt.isAllowDiscreteValue()) {
            List<Object> valuesList = new ArrayList<Object>(2);
            List<String> dpv = new ArrayList<String>(requestPrompt.getCriteriaValues().size());
            List<ValueFromLov> vpv = new ArrayList<ValueFromLov>(requestPrompt.getCriteriaValues().size());
            if(!boPrompt.getType().toString().contains(RetrieveListOfCriteriaForDocumentHelper.WEBI_PROMPT_TYPE_MULTI)) {
                validateIfSingleValuePrompt(requestPrompt);
            }
            fillDiscreteTypePromptValue(requestPrompt, dpv, vpv, boPrompt);
            valuesList.add(dpv);
            valuesList.add(vpv);
            fillPromptMap.put(requestPrompt.getID(), valuesList);
        } else {
            throw new PromptInfoException("Prompt " + requestPrompt.getName() + " is not a DiscreteValue.\n");
        }
    }

    private void populateTheFillCrystalReportPromptList(Map<String, Object[]> fillPromptMap, IParameterField boPrompt,
                                           CriteriaInfoFromRequest requestPrompt) throws PromptInfoException {
        if(requestPrompt.isAllowDiscreteValue()) {
            if(!boPrompt.getAllowMultiValue()) {
                validateIfSingleValuePrompt(requestPrompt);
            }
            ParameterFieldDiscreteValue[] dpv = new ParameterFieldDiscreteValue[requestPrompt.getCriteriaValues().size()];
            fillDiscreteTypeCrystalReportPromptValue(requestPrompt, dpv);
            fillPromptMap.put(requestPrompt.getID(), dpv);
        } else if(requestPrompt.isAllowRangeValue()) {
            if(!boPrompt.getAllowMultiValue()) {
                validateIfSingleValuePrompt(requestPrompt);
            }
            ParameterFieldRangeValue[] rpv = new ParameterFieldRangeValue[requestPrompt.getCriteriaValues().size()];
            fillRangeTypePromptValue(requestPrompt, rpv);
            fillPromptMap.put(requestPrompt.getID(), rpv);
        } else {
          throw new PromptInfoException(
              "Prompt " + requestPrompt.getName() + " is neither a DiscreteValue or a RangeValue.\n");
        }
    }

    private void fillRangeTypePromptValue(CriteriaInfoFromRequest requestPrompt, ParameterFieldRangeValue[] rpv) {
        int index = 0;
        for(BoFillPromptValue promptValue : requestPrompt.getCriteriaValues()) {
            logger.info("The prompt value is set so setting the range prompt array, startValue : " +
                    promptValue.getStartValue() + " , endValue : " + promptValue.getEndValue());
            rpv[index] = new ParameterFieldRangeValue();
            rpv[index].setBeginValue(
                    (promptValue.getStartValue() != null && !promptValue.getStartValue().equals("")) ? promptValue.getStartValue() : null);
            rpv[index].setEndValue(
                    (promptValue.getEndValue() != null && !promptValue.getEndValue().equals("")) ? promptValue.getEndValue() : null);
            if(promptValue.isStartValueInclusive()) {
                rpv[index].setLowerBoundType(RangeValueBoundType.inclusive);
            } else {
                rpv[index].setLowerBoundType(RangeValueBoundType.exclusive);
            }
            if(promptValue.isEndValueInclusive()) {
                rpv[index].setUpperBoundType(RangeValueBoundType.inclusive);
            } else {
                rpv[index].setUpperBoundType(RangeValueBoundType.exclusive);
            }
            if(promptValue.isStartValueUnbound()) {
                rpv[index].setLowerBoundType(RangeValueBoundType.noBound);
            }
            if(promptValue.isEndValueUnbound()) {
                rpv[index].setUpperBoundType(RangeValueBoundType.noBound);
            }
            index++;
        }
    }

    private void fillDiscreteTypeCrystalReportPromptValue(CriteriaInfoFromRequest requestPrompt, ParameterFieldDiscreteValue[] dpv) {
        int index = 0;
        for(BoFillPromptValue promptValue : requestPrompt.getCriteriaValues()) {
            if(promptValue.getValue() != null && !"null".equalsIgnoreCase(promptValue.getValue()) &&
                    !"".equalsIgnoreCase(promptValue.getValue())) {
                logger.info("The prompt value is set so setting the discrete prompt array : " + promptValue.getValue());
                dpv[index] = new ParameterFieldDiscreteValue();
                dpv[index].setValue(promptValue.getValue());
            }
            index++;
        }
    }

    private void fillDiscreteTypePromptValue(CriteriaInfoFromRequest requestPrompt, List<String> dpv,
                                             List<ValueFromLov> vpv, Prompt boPrompt) {
        for(BoFillPromptValue promptValue : requestPrompt.getCriteriaValues()) {
            if( promptValue.getValue() != null && !"null".equalsIgnoreCase(promptValue.getValue()) &&
                    !"".equalsIgnoreCase(promptValue.getValue())) {
                if(boPrompt.hasLOV()) {
                    if( promptValue.getRowIndex() != null && !"null".equalsIgnoreCase(promptValue.getRowIndex()) &&
                    !"".equalsIgnoreCase(promptValue.getRowIndex())) {
                        logger.info("The prompt index is  : " + promptValue.getRowIndex());
                        logger.info("The prompt value is  : " + promptValue.getValue());
                        vpv.add(new ValueFromLov(promptValue.getRowIndex(), promptValue.getValue()));
                    } else {
                        logger.info("The prompt value is  : " + promptValue.getValue());
                        dpv.add(promptValue.getValue());
                    }
                } else {
                    logger.info("The prompt value is  : " + promptValue.getValue());
                    dpv.add(promptValue.getValue());
                }
            }
        }
    }

    private void validatePrompts(Prompts prompts, RetrieveReportForCriteriaRequestType request, ListOfCriteria listOfCriteria, Fields<IParameterField> parameterFields)
            throws PromptInfoException {
        int mandatoryPrompts = 0;
        int numPrompts = 0;
        if(prompts != null) {
            numPrompts = prompts.getCount();
            for(int promptNum = 0; promptNum < prompts.getCount(); promptNum++) {
                Prompt promptInfo = prompts.getItem(promptNum);
                if(!promptInfo.isOptional()) {
                    mandatoryPrompts++;
                }
            }
        } else if(parameterFields != null && !parameterFields.isEmpty()) {
            for(int parameterNum = 0; parameterNum < parameterFields.size(); parameterNum++) {
                IParameterField parameterField = (IParameterField)parameterFields.getField(parameterNum);
                if(parameterField.getIsPromptToUser()) {
                    numPrompts++;
                    if(!parameterField.getIsOptionalPrompt()) {
                        mandatoryPrompts++;
                    }
                }
            }
        }

        logger.info("The document Id queried for is: " + request.getDocumentId());
        logger.info("The number of mandatory prompts are: " + mandatoryPrompts);
        logger.info("The number of prompts in the report is: " + numPrompts);
        if(listOfCriteria.getCriteriaInfoFromRequest().size() < mandatoryPrompts) {
            throw new PromptInfoException("The required prompts are not set in the criteria for this report\n");
        }
        if(listOfCriteria.getCriteriaInfoFromRequest().size() > numPrompts) {
            throw new PromptInfoException(
                    "The number of prompts specified in the request does not match the number of prompts in the report.\n");
        }
    }

    private void validateIfSingleValuePrompt(CriteriaInfoFromRequest requestPrompt) throws PromptInfoException {
        if(requestPrompt.getCriteriaValues().size() > 1) {
            throw new PromptInfoException(
                    "Prompt " + requestPrompt.getName() + " does not accept Multi values. Please set a single value.");
        }
    }

  private void validateRequest(RetrieveReportForCriteriaRequestType request) throws Exception {
    if ((request == null) || StringUtils.isNullOrEmpty(request.getRoleName()) ||
        StringUtils.isNullOrEmpty(request.getApplicationName()) ||
        StringUtils.isNullOrEmpty(request.getDocumentId()) ||
        (request.getFormat() == null || StringUtils.isNullOrEmpty(request.getFormat().value())) ||
        request.getListOfCriteria() == null) {
      throw new Exception("Received in-complete RetrieveReportForCriteriaRequest object");
    }

    logger.info("Service Name: RetrieveReportForCriteriaService Request RoleName: " + request.getRoleName() +
            ", ApplicationName: " +  request.getApplicationName() + ", DocumentId: " + request.getDocumentId() +
            ", Format: " + (request.getFormat() != null ? request.getFormat().value() : ""));

    if (request.getListOfCriteria().getCriteriaInfoFromRequest() == null) {
      throw new Exception("Received in-complete RetrieveReportForCriteriaRequest object");
    }

    ListOfCriteria criteria = request.getListOfCriteria();
    List<CriteriaInfoFromRequest> criteriaInformationList = criteria.getCriteriaInfoFromRequest();
    for (CriteriaInfoFromRequest criteriaInfo : criteriaInformationList) {
        logger.info("CriteriaInfoFromRequest: ID: " + criteriaInfo.getID() + ", Name: " + criteriaInfo.getName());
      if (!criteriaInfo.isAllowMultiValues() && criteriaInfo.getCriteriaValues().size() > 1) {
        throw new Exception("This criteria with id " + criteriaInfo.getName() + "  does not require multiple values");
      }
    }
  }

  private void throwFault(Throwable error, String operationName) throws RetrieveReportForCriteriaFault {
    logger.error(error);
    ExceptionType type = new ExceptionType();
    type.setFaultCode(error.getMessage());
    type.setFaultMessage(getStackTrace(error));
    throw new RetrieveReportForCriteriaFault(
        "Error occurred during operation: " + operationName + " : " + error.getMessage(), type, error);
  }

  private String getStackTrace(Throwable error) {
    StringBuffer stringBuffer = new StringBuffer();
    for (int index = 0; index < error.getStackTrace().length; index++) {
      stringBuffer.append(error.getStackTrace()[index].toString());
      stringBuffer.append("\n");
    }
    return stringBuffer.toString();
  }
}