/*
 ViewReportsHelper was created on Mar 31, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.helper;

import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.occa.infostore.CePropertyID;
import com.crystaldecisions.sdk.occa.infostore.IInfoObject;
import com.crystaldecisions.sdk.occa.infostore.IInfoStore;
import com.crystaldecisions.sdk.properties.IProperties;
import com.crystaldecisions.sdk.properties.IProperty;
import com.crystaldecisions.sdk.uri.IPageResult;
import com.crystaldecisions.sdk.uri.IStatelessPageInfo;
import com.crystaldecisions.sdk.uri.PagingQueryOptions;
import com.monsanto.Util.StringUtils;
import com.monsanto.eas.reportingservice.reportingengine.ConnectionObjectBO;
import com.monsanto.eas.reportingservice.schema.BoDocument;
import com.monsanto.eas.reportingservice.schema.ExceptionType;
import com.monsanto.eas.reportingservice.schema.RetrieveReportRequestType;
import com.monsanto.eas.reportingservice.schema.RetrieveReportResponseType;
import com.monsanto.eas.reportingservice.service.ViewReportsFault;
import org.apache.log4j.Logger;

import java.util.*;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class ViewReportsHelper {

    private Logger logger = Logger.getLogger(this.getClass());
    public final static String DEFAULT_PATH_TO_INFOPATH_FOLDER = "path://InfoObjects/Root Folder/";
    public final static int MAX_ITEMS_PER_PAGE = 100;
    public final static String PATH_SEARCH_CRITERIA =  "/**[(SI_KIND='Webi' OR SI_KIND='CrystalReport') AND SI_INSTANCE = 0]";
    public final static String FIELDS_INCLUDED =  "@SI_ID, SI_CUID, SI_PARENT_CUID, SI_RUID, SI_NAME, SI_CREATION_TIME, SI_DESCRIPTION, SI_KEYWORD, SI_KIND, SI_OWNER, SI_LAST_SUCCESSFUL_INSTANCE_ID";

    public RetrieveReportResponseType getReports(RetrieveReportRequestType request) throws ViewReportsFault {
        RetrieveReportResponseType retrieveReportResponseType = null;
        try {
            validateRetrieveReportRequest(request);
            ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(request.getRoleName());
            List<BoDocument> documents = new ArrayList<BoDocument>();
            addDocumentsToList(request, boConnector, documents);
            retrieveReportResponseType = new RetrieveReportResponseType();
            retrieveReportResponseType.getBoDocument().addAll(documents);
            boConnector.logout();
        } catch (Exception e) {
            throwFault(e, "getReports");
        }
        return retrieveReportResponseType;
    }

    private void addDocumentsToList(RetrieveReportRequestType request, ConnectionObjectBO boConnector, List<BoDocument> documents) throws SDKException {
        List<IInfoObject> infoObjectDocuments = ViewReportsHelper.getDocumentsFromFolder(request.getPathToFolder(), boConnector.getInfoStore());
        Iterator<IInfoObject> infoObjectIterator = infoObjectDocuments.iterator();
        while(infoObjectIterator.hasNext()) {
            documents.add(createBODocument(infoObjectIterator.next()));
        }
    }

    private BoDocument createBODocument(IInfoObject report) throws SDKException {
        BoDocument document = new BoDocument();
        document.setId(Integer.toString(report.getID()));
        document.setCuid(report.getCUID());
        document.setParentCUID(report.getParentCUID());
        document.setRuid(report.getRUID());
        document.setName(report.getTitle());
        document.setDescription(report.getDescription());
        document.setKeywords(report.getKeyword());
        document.setKind(report.getKind());
        document.setOwner(report.getOwner());
        addCEProperties(document, report.properties());
        logger.info("Service Name: ViewReportsService Response ID: " + document.getId() + ", Name: " + document.getName() + ", CUID: " + document.getCuid());
        return document;
    }

    private void addCEProperties(BoDocument document, IProperties properties) throws SDKException {
        IProperty creationTimeProperty = properties.getProperty(CePropertyID.SI_CREATION_TIME);
        if(creationTimeProperty != null) {
            Calendar creationTime = Calendar.getInstance();
            creationTime.setTimeZone(TimeZone.getTimeZone(ConnectionObjectBO.DEFAULT_TIME_ZONE));
            creationTime.setTime((java.util.Date) creationTimeProperty.getValue());
            document.setCreationTime(creationTime);
        }
        document.setLastSuccessfullInstance(
            properties.getProperty(CePropertyID.SI_LAST_SUCCESSFUL_INSTANCE_ID) != null ?
            ((Integer)properties.getProperty(CePropertyID.SI_LAST_SUCCESSFUL_INSTANCE_ID).getValue()).toString() : null);
    }

    private void validateRetrieveReportRequest(RetrieveReportRequestType request) throws Exception {
        if ((request == null) || StringUtils.isNullOrEmpty(request.getRoleName()) ||
                StringUtils.isNullOrEmpty(request.getApplicationName()) || StringUtils.isNullOrEmpty(request.getPathToFolder())) {
            throw new Exception("Received in-complete RetrieveReportsRequest object");
        }
        logger.info("Service Name: ViewReportsService Request RoleName: " + request.getRoleName() + ", ApplicationName: " +  request.getApplicationName() + ", PathToFolder: " + request.getPathToFolder());
        if (request.getPathToFolder().charAt(request.getPathToFolder().length() - 1) != '/'){
            StringBuffer pathToFolder = new StringBuffer(request.getPathToFolder());
            pathToFolder.append("/");
            request.setPathToFolder(pathToFolder.toString());
        }
    }

    private void throwFault(Throwable error, String operationName) throws ViewReportsFault {
        logger.error(error);
        ExceptionType type = new ExceptionType();
        type.setFaultCode(error.getMessage());
        type.setFaultMessage(getStackTrace(error));
        throw new ViewReportsFault("Error occurred during operation: " + operationName + " : " + error.getMessage(), type, error);
    }

    private String getStackTrace(Throwable error) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int index = 0; index < error.getStackTrace().length; index++) {
            stringBuffer.append(error.getStackTrace()[index].toString());
            stringBuffer.append("\n");
        }
        return stringBuffer.toString();
    }

    public static List<IInfoObject> getDocumentsFromFolder(String pathToFolder, IInfoStore infoStore) throws SDKException {
        String queryString = DEFAULT_PATH_TO_INFOPATH_FOLDER + pathToFolder + PATH_SEARCH_CRITERIA + FIELDS_INCLUDED;
        return obtainDocuments(queryString, infoStore);
    }

    public static List<IInfoObject> obtainDocuments(String queryString, IInfoStore infoStore) throws SDKException {
        List<IInfoObject> documents = new ArrayList<IInfoObject>();
        PagingQueryOptions options = new PagingQueryOptions(MAX_ITEMS_PER_PAGE);
        IPageResult pageResult = infoStore.getPagingQuery(queryString, options);
        int pageCount = pageResult.getPageCount();
        for(int pageNum = 1; pageNum <= pageCount; pageNum++) {
            IStatelessPageInfo pageInfo = infoStore.getStatelessPageInfo(pageResult.getPageURI(pageNum), options);
            documents.addAll(infoStore.query(pageInfo.getPageSQL()));
        }
        return documents;
    }

}