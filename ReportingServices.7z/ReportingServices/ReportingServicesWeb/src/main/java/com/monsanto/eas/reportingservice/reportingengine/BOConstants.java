/*
 BusinessObjectsConstants was created on Mar 31, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.reportingengine;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class BOConstants {

  public static final String LDAP_SECURITY = "secLDAP";
  public static final String ENV_VARIABLE_MONCRYPTJV = "MONCRYPTJV";
  public static final String FILE_ENCRYPTED_PWD_VALUE = "CipherValue.hex";
  public static final String FILE_ENCRYPTED_PWD_KEY = "KeyValue.hex";
  public static final String CMS_NAME = "boCMS";
  public static final String VIEW_PDF_FORMAT = "PDF";
  public static final String VIEW_EXCEL_FORMAT = "XLS";
  public static final String DISCRETE_PROMPT_VALUE = "DiscretePromptValue";
  public static final String RANGE_PROMPT_VALUE = "RangePromptValue";

}