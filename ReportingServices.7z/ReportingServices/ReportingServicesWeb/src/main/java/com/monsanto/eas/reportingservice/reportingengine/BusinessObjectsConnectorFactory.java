package com.monsanto.eas.reportingservice.reportingengine;

import com.crystaldecisions.sdk.exception.SDKException;
import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: JHERN10
 * Date: 5/27/13
 * Time: 3:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class BusinessObjectsConnectorFactory extends ConnectionFactory {

    Logger logger = Logger.getLogger(BusinessObjectsConnectorFactory.class);

    public ConnectionObjectBO getCMSConnection(String cmsName, String applicationAccount, String password) {
        try {
            logger.info("The CMS is: " + cmsName);
            ConnectionObjectBO connector = new ConnectionObjectBO(cmsName, applicationAccount, password, BOConstants.LDAP_SECURITY);
            connector.logon();
            return connector;
        } catch (SDKException sdkException) {
            sdkException.printStackTrace();
            logger.error("Error is : " + sdkException.getMessage());
            throw new RuntimeException(sdkException);
        }
    }

}
