/*
 ReportingEngineConnectorFactory was created on Mar 31, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.reportingengine;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public abstract class ConnectionFactory {

    public static final String BUSINESS_OBJECTS = "BUSINESS_OBJECTS";


    public abstract ConnectionObjectBO getCMSConnection(String cmsName, String applicationAccount,
                                                         String password);

    public static ConnectionFactory getReportingEngineConnectionFactory(String whichType){
        if(BUSINESS_OBJECTS.equalsIgnoreCase(whichType)) {
            return new BusinessObjectsConnectorFactory();
        } else {
            return null;
        }
    }

}