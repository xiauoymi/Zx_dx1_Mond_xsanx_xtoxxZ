package com.monsanto.eas.reportingservice.reportingengine;


import com.businessobjects.rebean.wi.ReportEngine;
import com.businessobjects.rebean.wi.ReportEngines;
import com.crystaldecisions.sdk.exception.SDKException;
import com.crystaldecisions.sdk.framework.CrystalEnterprise;
import com.crystaldecisions.sdk.framework.IEnterpriseSession;
import com.crystaldecisions.sdk.occa.infostore.IInfoStore;

import java.util.Locale;

/**
 * Created by IntelliJ IDEA.
 * User: JHERN10
 * Date: 5/27/13
 * Time: 3:15 PM
 * To change this template use File | Settings | File Templates.
 */
public class ConnectionObjectBO {

    private final static String REPORT_ENGINES = "ReportEngines";
    private final static String INFO_STORE_SERVICE = "InfoStore";
    public final static String DEFAULT_TIME_ZONE = "GMT+00:00";

    private String cmsName;
    private String userId;
    private String password;
    private String authType;
    private IEnterpriseSession session;
    private ReportEngines reportEngines;
    private ReportEngine reportEngine;
    private IInfoStore infoStore;

    public ConnectionObjectBO(String cmsName, String userId, String password, String authType) {
		this.cmsName = cmsName;
		this.userId = userId;
		this.password = password;
		this.authType = authType;
	}

    public String getCmsName() {
        return cmsName;
    }

    public String getUserId() {
        return userId;
    }

    public String getPassword() {
        return password;
    }

    public IEnterpriseSession getSession() {
        return session;
    }

    public IEnterpriseSession logon() throws SDKException {
		if (session == null) {
			session = CrystalEnterprise.getSessionMgr().logon(userId, password, cmsName, authType);
            session.setLocale(Locale.US);
		}

        // Obtain the Report Engines Service
        reportEngines = (ReportEngines)session.getService(REPORT_ENGINES);
        // Obtain the Web Intelligence Report Engine
        reportEngine = reportEngines.getService(ReportEngines.ReportEngineType.WI_REPORT_ENGINE);

        // Obtain the Infostore Service
        infoStore = (IInfoStore)session.getService(INFO_STORE_SERVICE);
		return session;
	}

    public void logout() throws SDKException {
        if (reportEngines != null) {
			reportEngines.close();
		}
        if (session != null) {
			session.logoff();
		}
	}

    public ReportEngine getReportEngine() throws SDKException {
		return reportEngine;
	}

    public IInfoStore getInfoStore() {
        return infoStore;
    }

}
