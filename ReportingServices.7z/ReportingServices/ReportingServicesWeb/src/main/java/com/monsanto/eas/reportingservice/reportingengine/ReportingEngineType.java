package com.monsanto.eas.reportingservice.reportingengine;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public enum ReportingEngineType {
  BusinessObjects, CrystalReports;
}
