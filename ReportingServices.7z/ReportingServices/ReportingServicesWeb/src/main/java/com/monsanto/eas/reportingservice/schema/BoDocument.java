
package com.monsanto.eas.reportingservice.schema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import java.util.Calendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Description" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CUID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="RUID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Kind" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="Owner" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ParentCUID" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CreationTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Keywords" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="ChildrenObjects" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="Instance" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="InfoObjSchedulingInfo" type="{urn:monsanto:enterprise:services:reporting:viewreport}objectSchedulingInfo"/>
 *         &lt;element name="InfoObjFileProperties" type="{urn:monsanto:enterprise:services:reporting:viewreport}objectFileProperties"/>
 *         &lt;element name="HasDocumentInstance" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="LastSuccessfullInstance" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "id",
    "name",
    "description",
    "cuid",
    "ruid",
    "kind",
    "owner",
    "parentCUID",
    "creationTime",
    "keywords",
    "childrenObjects",
    "instance",
    "infoObjSchedulingInfo",
    "infoObjFileProperties",
    "hasDocumentInstance",
    "lastSuccessfullInstance"
})
@XmlRootElement(name = "boDocument")
public class BoDocument {

    @XmlElement(name = "ID", required = true)
    protected String id;
    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "Description", required = true)
    protected String description;
    @XmlElement(name = "CUID", required = true)
    protected String cuid;
    @XmlElement(name = "RUID", required = true)
    protected String ruid;
    @XmlElement(name = "Kind", required = true)
    protected String kind;
    @XmlElement(name = "Owner", required = true)
    protected String owner;
    @XmlElement(name = "ParentCUID", required = true)
    protected String parentCUID;
    @XmlElement(name = "CreationTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected Calendar creationTime;
    @XmlElement(name = "Keywords", required = true)
    protected String keywords;
    @XmlElement(name = "ChildrenObjects")
    protected long childrenObjects;
    @XmlElement(name = "Instance")
    protected boolean instance;
    @XmlElement(name = "InfoObjSchedulingInfo", required = true)
    protected ObjectSchedulingInfo infoObjSchedulingInfo;
    @XmlElement(name = "InfoObjFileProperties", required = true)
    protected ObjectFileProperties infoObjFileProperties;
    @XmlElement(name = "HasDocumentInstance")
    protected boolean hasDocumentInstance;
    @XmlElement(name = "LastSuccessfullInstance", required = true)
    protected String lastSuccessfullInstance;
    @XmlAttribute(name = "Type")
    protected String type;

    /**
     * Gets the value of the id property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the value of the id property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setId(String value) {
        this.id = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the cuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCuid() {
        return cuid;
    }

    /**
     * Sets the value of the cuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCuid(String value) {
        this.cuid = value;
    }

    /**
     * Gets the value of the ruid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRuid() {
        return ruid;
    }

    /**
     * Sets the value of the ruid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRuid(String value) {
        this.ruid = value;
    }

    /**
     * Gets the value of the kind property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKind() {
        return kind;
    }

    /**
     * Sets the value of the kind property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKind(String value) {
        this.kind = value;
    }

    /**
     * Gets the value of the owner property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOwner() {
        return owner;
    }

    /**
     * Sets the value of the owner property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOwner(String value) {
        this.owner = value;
    }

    /**
     * Gets the value of the parentCUID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getParentCUID() {
        return parentCUID;
    }

    /**
     * Sets the value of the parentCUID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setParentCUID(String value) {
        this.parentCUID = value;
    }

    /**
     * Gets the value of the creationTime property.
     * 
     * @return
     *     possible object is
     *     {@link Calendar }
     *     
     */
    public Calendar getCreationTime() {
        return creationTime;
    }

    /**
     * Sets the value of the creationTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link Calendar }
     *     
     */
    public void setCreationTime(Calendar value) {
        this.creationTime = value;
    }

    /**
     * Gets the value of the keywords property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKeywords() {
        return keywords;
    }

    /**
     * Sets the value of the keywords property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKeywords(String value) {
        this.keywords = value;
    }

    /**
     * Gets the value of the childrenObjects property.
     * 
     */
    public long getChildrenObjects() {
        return childrenObjects;
    }

    /**
     * Sets the value of the childrenObjects property.
     * 
     */
    public void setChildrenObjects(long value) {
        this.childrenObjects = value;
    }

    /**
     * Gets the value of the instance property.
     * 
     */
    public boolean isInstance() {
        return instance;
    }

    /**
     * Sets the value of the instance property.
     * 
     */
    public void setInstance(boolean value) {
        this.instance = value;
    }

    /**
     * Gets the value of the infoObjSchedulingInfo property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectSchedulingInfo }
     *     
     */
    public ObjectSchedulingInfo getInfoObjSchedulingInfo() {
        return infoObjSchedulingInfo;
    }

    /**
     * Sets the value of the infoObjSchedulingInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectSchedulingInfo }
     *     
     */
    public void setInfoObjSchedulingInfo(ObjectSchedulingInfo value) {
        this.infoObjSchedulingInfo = value;
    }

    /**
     * Gets the value of the infoObjFileProperties property.
     * 
     * @return
     *     possible object is
     *     {@link ObjectFileProperties }
     *     
     */
    public ObjectFileProperties getInfoObjFileProperties() {
        return infoObjFileProperties;
    }

    /**
     * Sets the value of the infoObjFileProperties property.
     * 
     * @param value
     *     allowed object is
     *     {@link ObjectFileProperties }
     *     
     */
    public void setInfoObjFileProperties(ObjectFileProperties value) {
        this.infoObjFileProperties = value;
    }

    /**
     * Gets the value of the hasDocumentInstance property.
     * 
     */
    public boolean isHasDocumentInstance() {
        return hasDocumentInstance;
    }

    /**
     * Sets the value of the hasDocumentInstance property.
     * 
     */
    public void setHasDocumentInstance(boolean value) {
        this.hasDocumentInstance = value;
    }

    /**
     * Gets the value of the lastSuccessfullInstance property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLastSuccessfullInstance() {
        return lastSuccessfullInstance;
    }

    /**
     * Sets the value of the lastSuccessfullInstance property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLastSuccessfullInstance(String value) {
        this.lastSuccessfullInstance = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

}
