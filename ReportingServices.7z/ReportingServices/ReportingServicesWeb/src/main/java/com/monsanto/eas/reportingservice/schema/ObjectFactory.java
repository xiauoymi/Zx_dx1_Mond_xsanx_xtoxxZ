
package com.monsanto.eas.reportingservice.schema;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.monsanto.eas.reportingservice.schema package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RetrieveReportFault_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewreport", "retrieveReportFault");
    private final static QName _RoleName_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewreport", "roleName");
    private final static QName _PathToFolder_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewreport", "pathToFolder");
    private final static QName _RetrieveReportResponse_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewreport", "retrieveReportResponse");
    private final static QName _ApplicationName_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewreport", "applicationName");
    private final static QName _RetrieveReportRequest_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewreport", "retrieveReportRequest");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.monsanto.eas.reportingservice.schema
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link InfoObjFile }
     * 
     */
    public InfoObjFile createInfoObjFile() {
        return new InfoObjFile();
    }

    /**
     * Create an instance of {@link ObjectFileProperties }
     * 
     */
    public ObjectFileProperties createObjectFileProperties() {
        return new ObjectFileProperties();
    }

    /**
     * Create an instance of {@link BoDocument }
     * 
     */
    public BoDocument createBoDocument() {
        return new BoDocument();
    }

    /**
     * Create an instance of {@link InfoObjFiles }
     * 
     */
    public InfoObjFiles createInfoObjFiles() {
        return new InfoObjFiles();
    }

    /**
     * Create an instance of {@link ExceptionType }
     * 
     */
    public ExceptionType createExceptionType() {
        return new ExceptionType();
    }

    /**
     * Create an instance of {@link RetrieveReportResponseType }
     * 
     */
    public RetrieveReportResponseType createRetrieveReportResponseType() {
        return new RetrieveReportResponseType();
    }

    /**
     * Create an instance of {@link ObjectSchedulingInfo }
     * 
     */
    public ObjectSchedulingInfo createObjectSchedulingInfo() {
        return new ObjectSchedulingInfo();
    }

    /**
     * Create an instance of {@link RetrieveReportRequestType }
     * 
     */
    public RetrieveReportRequestType createRetrieveReportRequestType() {
        return new RetrieveReportRequestType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExceptionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewreport", name = "retrieveReportFault")
    public JAXBElement<ExceptionType> createRetrieveReportFault(ExceptionType value) {
        return new JAXBElement<ExceptionType>(_RetrieveReportFault_QNAME, ExceptionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewreport", name = "roleName")
    public JAXBElement<String> createRoleName(String value) {
        return new JAXBElement<String>(_RoleName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewreport", name = "pathToFolder")
    public JAXBElement<String> createPathToFolder(String value) {
        return new JAXBElement<String>(_PathToFolder_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveReportResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewreport", name = "retrieveReportResponse")
    public JAXBElement<RetrieveReportResponseType> createRetrieveReportResponse(RetrieveReportResponseType value) {
        return new JAXBElement<RetrieveReportResponseType>(_RetrieveReportResponse_QNAME, RetrieveReportResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewreport", name = "applicationName")
    public JAXBElement<String> createApplicationName(String value) {
        return new JAXBElement<String>(_ApplicationName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveReportRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewreport", name = "retrieveReportRequest")
    public JAXBElement<RetrieveReportRequestType> createRetrieveReportRequest(RetrieveReportRequestType value) {
        return new JAXBElement<RetrieveReportRequestType>(_RetrieveReportRequest_QNAME, RetrieveReportRequestType.class, null, value);
    }

}
