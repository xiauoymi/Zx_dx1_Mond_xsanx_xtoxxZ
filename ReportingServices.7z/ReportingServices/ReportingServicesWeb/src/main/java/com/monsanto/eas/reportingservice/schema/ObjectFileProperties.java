
package com.monsanto.eas.reportingservice.schema;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for objectFileProperties complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="objectFileProperties">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="InfoObjectFiles" type="{urn:monsanto:enterprise:services:reporting:viewreport}infoObjFiles" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "objectFileProperties", propOrder = {
    "infoObjectFiles"
})
public class ObjectFileProperties {

    @XmlElement(name = "InfoObjectFiles", required = true)
    protected List<InfoObjFiles> infoObjectFiles;

    /**
     * Gets the value of the infoObjectFiles property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the infoObjectFiles property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getInfoObjectFiles().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link InfoObjFiles }
     * 
     * 
     */
    public List<InfoObjFiles> getInfoObjectFiles() {
        if (infoObjectFiles == null) {
            infoObjectFiles = new ArrayList<InfoObjFiles>();
        }
        return this.infoObjectFiles;
    }

}
