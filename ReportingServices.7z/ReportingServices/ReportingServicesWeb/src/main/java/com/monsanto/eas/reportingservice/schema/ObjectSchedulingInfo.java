
package com.monsanto.eas.reportingservice.schema;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for objectSchedulingInfo complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="objectSchedulingInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="ScheduleType" type="{urn:monsanto:enterprise:services:reporting:viewreport}scheduleTypes"/>
 *         &lt;element name="Flags" type="{urn:monsanto:enterprise:services:reporting:viewreport}scheduleTypeFlags"/>
 *         &lt;element name="ErrorMessage" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "objectSchedulingInfo", propOrder = {
    "scheduleType",
    "flags",
    "errorMessage"
})
public class ObjectSchedulingInfo {

    @XmlElement(name = "ScheduleType", required = true)
    protected ScheduleTypes scheduleType;
    @XmlElement(name = "Flags", required = true)
    protected ScheduleTypeFlags flags;
    @XmlElement(name = "ErrorMessage", required = true)
    protected String errorMessage;

    /**
     * Gets the value of the scheduleType property.
     * 
     * @return
     *     possible object is
     *     {@link ScheduleTypes }
     *     
     */
    public ScheduleTypes getScheduleType() {
        return scheduleType;
    }

    /**
     * Sets the value of the scheduleType property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScheduleTypes }
     *     
     */
    public void setScheduleType(ScheduleTypes value) {
        this.scheduleType = value;
    }

    /**
     * Gets the value of the flags property.
     * 
     * @return
     *     possible object is
     *     {@link ScheduleTypeFlags }
     *     
     */
    public ScheduleTypeFlags getFlags() {
        return flags;
    }

    /**
     * Sets the value of the flags property.
     * 
     * @param value
     *     allowed object is
     *     {@link ScheduleTypeFlags }
     *     
     */
    public void setFlags(ScheduleTypeFlags value) {
        this.flags = value;
    }

    /**
     * Gets the value of the errorMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * Sets the value of the errorMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorMessage(String value) {
        this.errorMessage = value;
    }

}
