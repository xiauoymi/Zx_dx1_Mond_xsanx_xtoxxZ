
package com.monsanto.eas.reportingservice.schema;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for scheduleTypeFlags.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="scheduleTypeFlags">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PAUSE"/>
 *     &lt;enumeration value="RESUME"/>
 *     &lt;enumeration value="RETIRED"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "scheduleTypeFlags")
@XmlEnum
public enum ScheduleTypeFlags {

    PAUSE,
    RESUME,
    RETIRED;

    public String value() {
        return name();
    }

    public static ScheduleTypeFlags fromValue(String v) {
        return valueOf(v);
    }

}
