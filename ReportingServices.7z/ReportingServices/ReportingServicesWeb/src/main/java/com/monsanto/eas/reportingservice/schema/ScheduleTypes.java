
package com.monsanto.eas.reportingservice.schema;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for scheduleTypes.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="scheduleTypes">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CALENDAR"/>
 *     &lt;enumeration value="CALENDAR_TEMPLATE"/>
 *     &lt;enumeration value="DAILY"/>
 *     &lt;enumeration value="FIRSTMONDAY"/>
 *     &lt;enumeration value="HOURLY"/>
 *     &lt;enumeration value="ONCE"/>
 *     &lt;enumeration value="NTH DAY"/>
 *     &lt;enumeration value="MONTHLY"/>
 *     &lt;enumeration value="LAST DAY"/>
 *     &lt;enumeration value="WEEKLY"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "scheduleTypes")
@XmlEnum
public enum ScheduleTypes {

    CALENDAR("CALENDAR"),
    CALENDAR_TEMPLATE("CALENDAR_TEMPLATE"),
    DAILY("DAILY"),
    FIRSTMONDAY("FIRSTMONDAY"),
    HOURLY("HOURLY"),
    ONCE("ONCE"),
    @XmlEnumValue("NTH DAY")
    NTH_DAY("NTH DAY"),
    MONTHLY("MONTHLY"),
    @XmlEnumValue("LAST DAY")
    LAST_DAY("LAST DAY"),
    WEEKLY("WEEKLY");
    private final String value;

    ScheduleTypes(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ScheduleTypes fromValue(String v) {
        for (ScheduleTypes c: ScheduleTypes.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
