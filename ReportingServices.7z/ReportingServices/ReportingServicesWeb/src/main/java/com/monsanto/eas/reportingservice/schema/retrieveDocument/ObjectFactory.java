
package com.monsanto.eas.reportingservice.schema.retrieveDocument;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.monsanto.eas.reportingservice.schema.retrieveDocument package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RoleName_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewdocument", "roleName");
    private final static QName _RetrieveDocumentRequest_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewdocument", "retrieveDocumentRequest");
    private final static QName _RetrieveDocumentResponse_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewdocument", "retrieveDocumentResponse");
    private final static QName _DocumentId_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewdocument", "documentId");
    private final static QName _RetrieveDocumentFault_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewdocument", "retrieveDocumentFault");
    private final static QName _ApplicationName_QNAME = new QName("urn:monsanto:enterprise:services:reporting:viewdocument", "applicationName");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.monsanto.eas.reportingservice.schema.retrieveDocument
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DocumentViewDetails }
     * 
     */
    public DocumentViewDetails createDocumentViewDetails() {
        return new DocumentViewDetails();
    }

    /**
     * Create an instance of {@link DocViewSupport }
     * 
     */
    public DocViewSupport createDocViewSupport() {
        return new DocViewSupport();
    }

    /**
     * Create an instance of {@link RetrieveDocumentRequestType }
     * 
     */
    public RetrieveDocumentRequestType createRetrieveDocumentRequestType() {
        return new RetrieveDocumentRequestType();
    }

    /**
     * Create an instance of {@link ExceptionType }
     * 
     */
    public ExceptionType createExceptionType() {
        return new ExceptionType();
    }

    /**
     * Create an instance of {@link DocumentDetails }
     * 
     */
    public DocumentDetails createDocumentDetails() {
        return new DocumentDetails();
    }

    /**
     * Create an instance of {@link OutputView }
     * 
     */
    public OutputView createOutputView() {
        return new OutputView();
    }

    /**
     * Create an instance of {@link RetrieveDocumentResponseType }
     * 
     */
    public RetrieveDocumentResponseType createRetrieveDocumentResponseType() {
        return new RetrieveDocumentResponseType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewdocument", name = "roleName")
    public JAXBElement<String> createRoleName(String value) {
        return new JAXBElement<String>(_RoleName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveDocumentRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewdocument", name = "retrieveDocumentRequest")
    public JAXBElement<RetrieveDocumentRequestType> createRetrieveDocumentRequest(RetrieveDocumentRequestType value) {
        return new JAXBElement<RetrieveDocumentRequestType>(_RetrieveDocumentRequest_QNAME, RetrieveDocumentRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveDocumentResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewdocument", name = "retrieveDocumentResponse")
    public JAXBElement<RetrieveDocumentResponseType> createRetrieveDocumentResponse(RetrieveDocumentResponseType value) {
        return new JAXBElement<RetrieveDocumentResponseType>(_RetrieveDocumentResponse_QNAME, RetrieveDocumentResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewdocument", name = "documentId")
    public JAXBElement<String> createDocumentId(String value) {
        return new JAXBElement<String>(_DocumentId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExceptionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewdocument", name = "retrieveDocumentFault")
    public JAXBElement<ExceptionType> createRetrieveDocumentFault(ExceptionType value) {
        return new JAXBElement<ExceptionType>(_RetrieveDocumentFault_QNAME, ExceptionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:viewdocument", name = "applicationName")
    public JAXBElement<String> createApplicationName(String value) {
        return new JAXBElement<String>(_ApplicationName_QNAME, String.class, null, value);
    }

}
