
package com.monsanto.eas.reportingservice.schema.retrieveDocument;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for outputFormat.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="outputFormat">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="PDF"/>
 *     &lt;enumeration value="XLS"/>
 *     &lt;enumeration value="DOC"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "outputFormat")
@XmlEnum
public enum OutputFormat {

    PDF,
    XLS,
    DOC;

    public String value() {
        return name();
    }

    public static OutputFormat fromValue(String v) {
        return valueOf(v);
    }

}
