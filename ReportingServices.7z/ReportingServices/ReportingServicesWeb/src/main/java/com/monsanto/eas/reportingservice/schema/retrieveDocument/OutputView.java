
package com.monsanto.eas.reportingservice.schema.retrieveDocument;

import javax.xml.bind.annotation.*;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.Calendar;


/**
 * <p>Java class for outputView complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="outputView">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Name" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="DocumentReference" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="LastChunk" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ContentLength" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ChunkSize" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="MimeType" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="MustFillPassword" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="MustFillQueryContexts" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="MustFillPrompts" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="MustFillDBLogons" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Refreshable" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="ViewChunkable" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Drillable" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="RefreshOnOpen" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="Author" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="CreationDate" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="DocumentViewDetails" type="{urn:monsanto:enterprise:services:reporting:viewdocument}documentViewDetails"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "outputView", propOrder = {
    "name",
    "documentReference",
    "lastChunk",
    "contentLength",
    "chunkSize",
    "mimeType",
    "mustFillPassword",
    "mustFillQueryContexts",
    "mustFillPrompts",
    "mustFillDBLogons",
    "refreshable",
    "viewChunkable",
    "drillable",
    "refreshOnOpen",
    "author",
    "creationDate",
    "documentViewDetails"
})
public class OutputView {

    @XmlElement(name = "Name", required = true)
    protected String name;
    @XmlElement(name = "DocumentReference", required = true)
    protected String documentReference;
    @XmlElement(name = "LastChunk")
    protected boolean lastChunk;
    @XmlElement(name = "ContentLength")
    protected int contentLength;
    @XmlElement(name = "ChunkSize")
    protected int chunkSize;
    @XmlElement(name = "MimeType", required = true)
    protected String mimeType;
    @XmlElement(name = "MustFillPassword")
    protected boolean mustFillPassword;
    @XmlElement(name = "MustFillQueryContexts")
    protected boolean mustFillQueryContexts;
    @XmlElement(name = "MustFillPrompts")
    protected boolean mustFillPrompts;
    @XmlElement(name = "MustFillDBLogons")
    protected boolean mustFillDBLogons;
    @XmlElement(name = "Refreshable")
    protected boolean refreshable;
    @XmlElement(name = "ViewChunkable")
    protected boolean viewChunkable;
    @XmlElement(name = "Drillable")
    protected boolean drillable;
    @XmlElement(name = "RefreshOnOpen")
    protected boolean refreshOnOpen;
    @XmlElement(name = "Author", required = true)
    protected String author;
    @XmlElement(name = "CreationDate", required = true)
    @XmlSchemaType(name = "date")
    protected Calendar creationDate;
    @XmlElement(name = "DocumentViewDetails", required = true)
    protected DocumentViewDetails documentViewDetails;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the documentReference property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentReference() {
        return documentReference;
    }

    /**
     * Sets the value of the documentReference property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentReference(String value) {
        this.documentReference = value;
    }

    /**
     * Gets the value of the lastChunk property.
     * 
     */
    public boolean isLastChunk() {
        return lastChunk;
    }

    /**
     * Sets the value of the lastChunk property.
     * 
     */
    public void setLastChunk(boolean value) {
        this.lastChunk = value;
    }

    /**
     * Gets the value of the contentLength property.
     * 
     */
    public int getContentLength() {
        return contentLength;
    }

    /**
     * Sets the value of the contentLength property.
     * 
     */
    public void setContentLength(int value) {
        this.contentLength = value;
    }

    /**
     * Gets the value of the chunkSize property.
     * 
     */
    public int getChunkSize() {
        return chunkSize;
    }

    /**
     * Sets the value of the chunkSize property.
     * 
     */
    public void setChunkSize(int value) {
        this.chunkSize = value;
    }

    /**
     * Gets the value of the mimeType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMimeType() {
        return mimeType;
    }

    /**
     * Sets the value of the mimeType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMimeType(String value) {
        this.mimeType = value;
    }

    /**
     * Gets the value of the mustFillPassword property.
     * 
     */
    public boolean isMustFillPassword() {
        return mustFillPassword;
    }

    /**
     * Sets the value of the mustFillPassword property.
     * 
     */
    public void setMustFillPassword(boolean value) {
        this.mustFillPassword = value;
    }

    /**
     * Gets the value of the mustFillQueryContexts property.
     * 
     */
    public boolean isMustFillQueryContexts() {
        return mustFillQueryContexts;
    }

    /**
     * Sets the value of the mustFillQueryContexts property.
     * 
     */
    public void setMustFillQueryContexts(boolean value) {
        this.mustFillQueryContexts = value;
    }

    /**
     * Gets the value of the mustFillPrompts property.
     * 
     */
    public boolean isMustFillPrompts() {
        return mustFillPrompts;
    }

    /**
     * Sets the value of the mustFillPrompts property.
     * 
     */
    public void setMustFillPrompts(boolean value) {
        this.mustFillPrompts = value;
    }

    /**
     * Gets the value of the mustFillDBLogons property.
     * 
     */
    public boolean isMustFillDBLogons() {
        return mustFillDBLogons;
    }

    /**
     * Sets the value of the mustFillDBLogons property.
     * 
     */
    public void setMustFillDBLogons(boolean value) {
        this.mustFillDBLogons = value;
    }

    /**
     * Gets the value of the refreshable property.
     * 
     */
    public boolean isRefreshable() {
        return refreshable;
    }

    /**
     * Sets the value of the refreshable property.
     * 
     */
    public void setRefreshable(boolean value) {
        this.refreshable = value;
    }

    /**
     * Gets the value of the viewChunkable property.
     * 
     */
    public boolean isViewChunkable() {
        return viewChunkable;
    }

    /**
     * Sets the value of the viewChunkable property.
     * 
     */
    public void setViewChunkable(boolean value) {
        this.viewChunkable = value;
    }

    /**
     * Gets the value of the drillable property.
     * 
     */
    public boolean isDrillable() {
        return drillable;
    }

    /**
     * Sets the value of the drillable property.
     * 
     */
    public void setDrillable(boolean value) {
        this.drillable = value;
    }

    /**
     * Gets the value of the refreshOnOpen property.
     * 
     */
    public boolean isRefreshOnOpen() {
        return refreshOnOpen;
    }

    /**
     * Sets the value of the refreshOnOpen property.
     * 
     */
    public void setRefreshOnOpen(boolean value) {
        this.refreshOnOpen = value;
    }

    /**
     * Gets the value of the author property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Sets the value of the author property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthor(String value) {
        this.author = value;
    }

    /**
     * Gets the value of the creationDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public Calendar getCreationDate() {
        return creationDate;
    }

    /**
     * Sets the value of the creationDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setCreationDate(Calendar value) {
        this.creationDate = value;
    }

    /**
     * Gets the value of the documentViewDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DocumentViewDetails }
     *     
     */
    public DocumentViewDetails getDocumentViewDetails() {
        return documentViewDetails;
    }

    /**
     * Sets the value of the documentViewDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocumentViewDetails }
     *     
     */
    public void setDocumentViewDetails(DocumentViewDetails value) {
        this.documentViewDetails = value;
    }

}
