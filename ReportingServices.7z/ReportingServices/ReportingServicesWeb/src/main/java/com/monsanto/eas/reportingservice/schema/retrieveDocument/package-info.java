@javax.xml.bind.annotation.XmlSchema(namespace = "urn:monsanto:enterprise:services:reporting:viewdocument", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.monsanto.eas.reportingservice.schema.retrieveDocument;
