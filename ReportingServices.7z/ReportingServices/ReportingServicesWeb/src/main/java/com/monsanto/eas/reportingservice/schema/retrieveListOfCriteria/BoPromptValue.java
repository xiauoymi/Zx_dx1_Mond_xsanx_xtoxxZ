
package com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for boPromptValue complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="boPromptValue">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Value" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="StartValue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="EndValue" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="StartValueInclusive" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="EndValueInclusive" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="StartValueUnbound" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="EndValueUnbound" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsNilStartValue" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsNilEndValue" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsSetStartValue" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsSetStartValueInclusive" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsSetStartValueUnbound" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsSetEndValueInclusive" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="IsSetEndValueUnbound" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *       &lt;/sequence>
 *       &lt;attribute name="RowIndex" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="Type" type="{http://www.w3.org/2001/XMLSchema}string" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "boPromptValue", propOrder = {
    "value",
    "startValue",
    "endValue",
    "startValueInclusive",
    "endValueInclusive",
    "startValueUnbound",
    "endValueUnbound",
    "isNilStartValue",
    "isNilEndValue",
    "isSetStartValue",
    "isSetStartValueInclusive",
    "isSetStartValueUnbound",
    "isSetEndValueInclusive",
    "isSetEndValueUnbound"
})
public class BoPromptValue {

    @XmlElement(name = "Value", required = true)
    protected String value;
    @XmlElement(name = "StartValue", required = true)
    protected String startValue;
    @XmlElement(name = "EndValue", required = true)
    protected String endValue;
    @XmlElement(name = "StartValueInclusive")
    protected boolean startValueInclusive;
    @XmlElement(name = "EndValueInclusive")
    protected boolean endValueInclusive;
    @XmlElement(name = "StartValueUnbound")
    protected boolean startValueUnbound;
    @XmlElement(name = "EndValueUnbound")
    protected boolean endValueUnbound;
    @XmlElement(name = "IsNilStartValue")
    protected boolean isNilStartValue;
    @XmlElement(name = "IsNilEndValue")
    protected boolean isNilEndValue;
    @XmlElement(name = "IsSetStartValue")
    protected boolean isSetStartValue;
    @XmlElement(name = "IsSetStartValueInclusive")
    protected boolean isSetStartValueInclusive;
    @XmlElement(name = "IsSetStartValueUnbound")
    protected boolean isSetStartValueUnbound;
    @XmlElement(name = "IsSetEndValueInclusive")
    protected boolean isSetEndValueInclusive;
    @XmlElement(name = "IsSetEndValueUnbound")
    protected boolean isSetEndValueUnbound;
    @XmlAttribute(name = "RowIndex")
    protected String rowIndex;
    @XmlAttribute(name = "Type")
    protected String type;

    /**
     * Gets the value of the value property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getValue() {
        return value;
    }

    /**
     * Sets the value of the value property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Gets the value of the startValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStartValue() {
        return startValue;
    }

    /**
     * Sets the value of the startValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStartValue(String value) {
        this.startValue = value;
    }

    /**
     * Gets the value of the endValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEndValue() {
        return endValue;
    }

    /**
     * Sets the value of the endValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEndValue(String value) {
        this.endValue = value;
    }

    /**
     * Gets the value of the startValueInclusive property.
     * 
     */
    public boolean isStartValueInclusive() {
        return startValueInclusive;
    }

    /**
     * Sets the value of the startValueInclusive property.
     * 
     */
    public void setStartValueInclusive(boolean value) {
        this.startValueInclusive = value;
    }

    /**
     * Gets the value of the endValueInclusive property.
     * 
     */
    public boolean isEndValueInclusive() {
        return endValueInclusive;
    }

    /**
     * Sets the value of the endValueInclusive property.
     * 
     */
    public void setEndValueInclusive(boolean value) {
        this.endValueInclusive = value;
    }

    /**
     * Gets the value of the startValueUnbound property.
     * 
     */
    public boolean isStartValueUnbound() {
        return startValueUnbound;
    }

    /**
     * Sets the value of the startValueUnbound property.
     * 
     */
    public void setStartValueUnbound(boolean value) {
        this.startValueUnbound = value;
    }

    /**
     * Gets the value of the endValueUnbound property.
     * 
     */
    public boolean isEndValueUnbound() {
        return endValueUnbound;
    }

    /**
     * Sets the value of the endValueUnbound property.
     * 
     */
    public void setEndValueUnbound(boolean value) {
        this.endValueUnbound = value;
    }

    /**
     * Gets the value of the isNilStartValue property.
     * 
     */
    public boolean isIsNilStartValue() {
        return isNilStartValue;
    }

    /**
     * Sets the value of the isNilStartValue property.
     * 
     */
    public void setIsNilStartValue(boolean value) {
        this.isNilStartValue = value;
    }

    /**
     * Gets the value of the isNilEndValue property.
     * 
     */
    public boolean isIsNilEndValue() {
        return isNilEndValue;
    }

    /**
     * Sets the value of the isNilEndValue property.
     * 
     */
    public void setIsNilEndValue(boolean value) {
        this.isNilEndValue = value;
    }

    /**
     * Gets the value of the isSetStartValue property.
     * 
     */
    public boolean isIsSetStartValue() {
        return isSetStartValue;
    }

    /**
     * Sets the value of the isSetStartValue property.
     * 
     */
    public void setIsSetStartValue(boolean value) {
        this.isSetStartValue = value;
    }

    /**
     * Gets the value of the isSetStartValueInclusive property.
     * 
     */
    public boolean isIsSetStartValueInclusive() {
        return isSetStartValueInclusive;
    }

    /**
     * Sets the value of the isSetStartValueInclusive property.
     * 
     */
    public void setIsSetStartValueInclusive(boolean value) {
        this.isSetStartValueInclusive = value;
    }

    /**
     * Gets the value of the isSetStartValueUnbound property.
     * 
     */
    public boolean isIsSetStartValueUnbound() {
        return isSetStartValueUnbound;
    }

    /**
     * Sets the value of the isSetStartValueUnbound property.
     * 
     */
    public void setIsSetStartValueUnbound(boolean value) {
        this.isSetStartValueUnbound = value;
    }

    /**
     * Gets the value of the isSetEndValueInclusive property.
     * 
     */
    public boolean isIsSetEndValueInclusive() {
        return isSetEndValueInclusive;
    }

    /**
     * Sets the value of the isSetEndValueInclusive property.
     * 
     */
    public void setIsSetEndValueInclusive(boolean value) {
        this.isSetEndValueInclusive = value;
    }

    /**
     * Gets the value of the isSetEndValueUnbound property.
     * 
     */
    public boolean isIsSetEndValueUnbound() {
        return isSetEndValueUnbound;
    }

    /**
     * Sets the value of the isSetEndValueUnbound property.
     * 
     */
    public void setIsSetEndValueUnbound(boolean value) {
        this.isSetEndValueUnbound = value;
    }

    /**
     * Gets the value of the rowIndex property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRowIndex() {
        return rowIndex;
    }

    /**
     * Sets the value of the rowIndex property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRowIndex(String value) {
        this.rowIndex = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

}
