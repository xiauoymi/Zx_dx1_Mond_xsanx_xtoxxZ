
package com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for lov complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="lov">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="HeaderArray" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded"/>
 *         &lt;element name="Values" type="{urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria}lovValues" maxOccurs="unbounded"/>
 *         &lt;element name="BatchNameArray" type="{http://www.w3.org/2001/XMLSchema}string" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *       &lt;attribute name="Sorted" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="SortedColumnIndex" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="SortType" type="{http://www.w3.org/2001/XMLSchema}string" />
 *       &lt;attribute name="SearchActivated" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="CurrentBatchIndex" type="{http://www.w3.org/2001/XMLSchema}int" />
 *       &lt;attribute name="RowIndexed" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="PartialResult" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *       &lt;attribute name="RefreshDate" type="{http://www.w3.org/2001/XMLSchema}date" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "lov", propOrder = {
    "headerArray",
    "values",
    "batchNameArray"
})
public class Lov {

    @XmlElement(name = "HeaderArray", required = true)
    protected List<String> headerArray;
    @XmlElement(name = "Values", required = true)
    protected List<LovValues> values;
    @XmlElement(name = "BatchNameArray", required = true)
    protected List<String> batchNameArray;
    @XmlAttribute(name = "Sorted")
    protected Boolean sorted;
    @XmlAttribute(name = "SortedColumnIndex")
    protected Integer sortedColumnIndex;
    @XmlAttribute(name = "SortType")
    protected String sortType;
    @XmlAttribute(name = "SearchActivated")
    protected Boolean searchActivated;
    @XmlAttribute(name = "CurrentBatchIndex")
    protected Integer currentBatchIndex;
    @XmlAttribute(name = "RowIndexed")
    protected Boolean rowIndexed;
    @XmlAttribute(name = "PartialResult")
    protected Boolean partialResult;
    @XmlAttribute(name = "RefreshDate")
    @XmlSchemaType(name = "date")
    protected XMLGregorianCalendar refreshDate;

    /**
     * Gets the value of the headerArray property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the headerArray property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHeaderArray().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getHeaderArray() {
        if (headerArray == null) {
            headerArray = new ArrayList<String>();
        }
        return this.headerArray;
    }

    /**
     * Gets the value of the values property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the values property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getValues().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link LovValues }
     * 
     * 
     */
    public List<LovValues> getValues() {
        if (values == null) {
            values = new ArrayList<LovValues>();
        }
        return this.values;
    }

    /**
     * Gets the value of the batchNameArray property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the batchNameArray property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getBatchNameArray().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link String }
     * 
     * 
     */
    public List<String> getBatchNameArray() {
        if (batchNameArray == null) {
            batchNameArray = new ArrayList<String>();
        }
        return this.batchNameArray;
    }

    /**
     * Gets the value of the sorted property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSorted() {
        return sorted;
    }

    /**
     * Sets the value of the sorted property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSorted(Boolean value) {
        this.sorted = value;
    }

    /**
     * Gets the value of the sortedColumnIndex property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getSortedColumnIndex() {
        return sortedColumnIndex;
    }

    /**
     * Sets the value of the sortedColumnIndex property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setSortedColumnIndex(Integer value) {
        this.sortedColumnIndex = value;
    }

    /**
     * Gets the value of the sortType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSortType() {
        return sortType;
    }

    /**
     * Sets the value of the sortType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSortType(String value) {
        this.sortType = value;
    }

    /**
     * Gets the value of the searchActivated property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isSearchActivated() {
        return searchActivated;
    }

    /**
     * Sets the value of the searchActivated property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setSearchActivated(Boolean value) {
        this.searchActivated = value;
    }

    /**
     * Gets the value of the currentBatchIndex property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getCurrentBatchIndex() {
        return currentBatchIndex;
    }

    /**
     * Sets the value of the currentBatchIndex property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setCurrentBatchIndex(Integer value) {
        this.currentBatchIndex = value;
    }

    /**
     * Gets the value of the rowIndexed property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRowIndexed() {
        return rowIndexed;
    }

    /**
     * Sets the value of the rowIndexed property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRowIndexed(Boolean value) {
        this.rowIndexed = value;
    }

    /**
     * Gets the value of the partialResult property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isPartialResult() {
        return partialResult;
    }

    /**
     * Sets the value of the partialResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setPartialResult(Boolean value) {
        this.partialResult = value;
    }

    /**
     * Gets the value of the refreshDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getRefreshDate() {
        return refreshDate;
    }

    /**
     * Sets the value of the refreshDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setRefreshDate(XMLGregorianCalendar value) {
        this.refreshDate = value;
    }

}
