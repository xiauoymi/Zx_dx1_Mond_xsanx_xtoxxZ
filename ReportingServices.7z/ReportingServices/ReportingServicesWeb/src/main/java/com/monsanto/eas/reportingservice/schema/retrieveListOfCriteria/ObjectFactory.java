
package com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ApplicationName_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", "applicationName");
    private final static QName _RetrieveListOfCriteriaForDocumentFault_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", "retrieveListOfCriteriaForDocumentFault");
    private final static QName _RoleName_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", "roleName");
    private final static QName _RetrieveListOfCriteriaForDocumentRequest_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", "retrieveListOfCriteriaForDocumentRequest");
    private final static QName _DocumentId_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", "documentId");
    private final static QName _RetrieveListOfCriteriaForDocumentResponse_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", "retrieveListOfCriteriaForDocumentResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Lov }
     * 
     */
    public Lov createLov() {
        return new Lov();
    }

    /**
     * Create an instance of {@link BoNativeValue }
     * 
     */
    public BoNativeValue createBoNativeValue() {
        return new BoNativeValue();
    }

    /**
     * Create an instance of {@link BoPromptValue }
     * 
     */
    public BoPromptValue createBoPromptValue() {
        return new BoPromptValue();
    }

    /**
     * Create an instance of {@link RetrieveListOfCriteriaRequestType }
     * 
     */
    public RetrieveListOfCriteriaRequestType createRetrieveListOfCriteriaRequestType() {
        return new RetrieveListOfCriteriaRequestType();
    }

    /**
     * Create an instance of {@link LovValues }
     * 
     */
    public LovValues createLovValues() {
        return new LovValues();
    }

    /**
     * Create an instance of {@link CriteriaInfo }
     * 
     */
    public CriteriaInfo createCriteriaInfo() {
        return new CriteriaInfo();
    }

    /**
     * Create an instance of {@link RetrieveListOfCriteriaResponseType }
     * 
     */
    public RetrieveListOfCriteriaResponseType createRetrieveListOfCriteriaResponseType() {
        return new RetrieveListOfCriteriaResponseType();
    }

    /**
     * Create an instance of {@link ExceptionType }
     * 
     */
    public ExceptionType createExceptionType() {
        return new ExceptionType();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", name = "applicationName")
    public JAXBElement<String> createApplicationName(String value) {
        return new JAXBElement<String>(_ApplicationName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExceptionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", name = "retrieveListOfCriteriaForDocumentFault")
    public JAXBElement<ExceptionType> createRetrieveListOfCriteriaForDocumentFault(ExceptionType value) {
        return new JAXBElement<ExceptionType>(_RetrieveListOfCriteriaForDocumentFault_QNAME, ExceptionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", name = "roleName")
    public JAXBElement<String> createRoleName(String value) {
        return new JAXBElement<String>(_RoleName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveListOfCriteriaRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", name = "retrieveListOfCriteriaForDocumentRequest")
    public JAXBElement<RetrieveListOfCriteriaRequestType> createRetrieveListOfCriteriaForDocumentRequest(RetrieveListOfCriteriaRequestType value) {
        return new JAXBElement<RetrieveListOfCriteriaRequestType>(_RetrieveListOfCriteriaForDocumentRequest_QNAME, RetrieveListOfCriteriaRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", name = "documentId")
    public JAXBElement<String> createDocumentId(String value) {
        return new JAXBElement<String>(_DocumentId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveListOfCriteriaResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria", name = "retrieveListOfCriteriaForDocumentResponse")
    public JAXBElement<RetrieveListOfCriteriaResponseType> createRetrieveListOfCriteriaForDocumentResponse(RetrieveListOfCriteriaResponseType value) {
        return new JAXBElement<RetrieveListOfCriteriaResponseType>(_RetrieveListOfCriteriaForDocumentResponse_QNAME, RetrieveListOfCriteriaResponseType.class, null, value);
    }

}
