
package com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria;

import javax.activation.DataHandler;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMimeType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for documentViewDetails complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="documentViewDetails">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DocumentViewSupport" type="{urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria}docViewSupport"/>
 *         &lt;element name="Content" type="{http://www.w3.org/2001/XMLSchema}base64Binary"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "documentViewDetails", propOrder = {
    "documentViewSupport",
    "content"
})
public class DocumentViewDetails {

    @XmlElement(name = "DocumentViewSupport", required = true)
    protected DocViewSupport documentViewSupport;
    @XmlElement(name = "Content", required = true)
    @XmlMimeType("application/*")
    protected DataHandler content;

    /**
     * Gets the value of the documentViewSupport property.
     * 
     * @return
     *     possible object is
     *     {@link DocViewSupport }
     *     
     */
    public DocViewSupport getDocumentViewSupport() {
        return documentViewSupport;
    }

    /**
     * Sets the value of the documentViewSupport property.
     * 
     * @param value
     *     allowed object is
     *     {@link DocViewSupport }
     *     
     */
    public void setDocumentViewSupport(DocViewSupport value) {
        this.documentViewSupport = value;
    }

    /**
     * Gets the value of the content property.
     * 
     * @return
     *     possible object is
     *     {@link DataHandler }
     *     
     */
    public DataHandler getContent() {
        return content;
    }

    /**
     * Sets the value of the content property.
     * 
     * @param value
     *     allowed object is
     *     {@link DataHandler }
     *     
     */
    public void setContent(DataHandler value) {
        this.content = value;
    }

}
