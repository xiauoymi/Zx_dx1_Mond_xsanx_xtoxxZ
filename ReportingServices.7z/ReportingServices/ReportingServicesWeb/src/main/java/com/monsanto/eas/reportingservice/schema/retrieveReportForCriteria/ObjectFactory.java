
package com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RetrieveReportForCriteriaRequest_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", "retrieveReportForCriteriaRequest");
    private final static QName _RoleName_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", "roleName");
    private final static QName _DocumentId_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", "documentId");
    private final static QName _RetrieveReportForCriteriaFault_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", "retrieveReportForCriteriaFault");
    private final static QName _RetrieveReportForCriteriaResponse_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", "retrieveReportForCriteriaResponse");
    private final static QName _ApplicationName_QNAME = new QName("urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", "applicationName");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link DocumentViewDetails }
     * 
     */
    public DocumentViewDetails createDocumentViewDetails() {
        return new DocumentViewDetails();
    }

    /**
     * Create an instance of {@link RetrieveReportForCriteriaResponseType }
     * 
     */
    public RetrieveReportForCriteriaResponseType createRetrieveReportForCriteriaResponseType() {
        return new RetrieveReportForCriteriaResponseType();
    }

    /**
     * Create an instance of {@link ExceptionType }
     * 
     */
    public ExceptionType createExceptionType() {
        return new ExceptionType();
    }

    /**
     * Create an instance of {@link CriteriaInfoFromRequest }
     * 
     */
    public CriteriaInfoFromRequest createCriteriaInfoFromRequest() {
        return new CriteriaInfoFromRequest();
    }

    /**
     * Create an instance of {@link ListOfCriteria }
     * 
     */
    public ListOfCriteria createListOfCriteria() {
        return new ListOfCriteria();
    }

    /**
     * Create an instance of {@link RetrieveReportForCriteriaRequestType }
     * 
     */
    public RetrieveReportForCriteriaRequestType createRetrieveReportForCriteriaRequestType() {
        return new RetrieveReportForCriteriaRequestType();
    }

    /**
     * Create an instance of {@link OutputView }
     * 
     */
    public OutputView createOutputView() {
        return new OutputView();
    }

    /**
     * Create an instance of {@link NewDocument }
     * 
     */
    public NewDocument createNewDocument() {
        return new NewDocument();
    }

    /**
     * Create an instance of {@link DocViewSupport }
     * 
     */
    public DocViewSupport createDocViewSupport() {
        return new DocViewSupport();
    }

    /**
     * Create an instance of {@link BoFillPromptValue }
     * 
     */
    public BoFillPromptValue createBoFillPromptValue() {
        return new BoFillPromptValue();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveReportForCriteriaRequestType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", name = "retrieveReportForCriteriaRequest")
    public JAXBElement<RetrieveReportForCriteriaRequestType> createRetrieveReportForCriteriaRequest(RetrieveReportForCriteriaRequestType value) {
        return new JAXBElement<RetrieveReportForCriteriaRequestType>(_RetrieveReportForCriteriaRequest_QNAME, RetrieveReportForCriteriaRequestType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", name = "roleName")
    public JAXBElement<String> createRoleName(String value) {
        return new JAXBElement<String>(_RoleName_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", name = "documentId")
    public JAXBElement<String> createDocumentId(String value) {
        return new JAXBElement<String>(_DocumentId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ExceptionType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", name = "retrieveReportForCriteriaFault")
    public JAXBElement<ExceptionType> createRetrieveReportForCriteriaFault(ExceptionType value) {
        return new JAXBElement<ExceptionType>(_RetrieveReportForCriteriaFault_QNAME, ExceptionType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveReportForCriteriaResponseType }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", name = "retrieveReportForCriteriaResponse")
    public JAXBElement<RetrieveReportForCriteriaResponseType> createRetrieveReportForCriteriaResponse(RetrieveReportForCriteriaResponseType value) {
        return new JAXBElement<RetrieveReportForCriteriaResponseType>(_RetrieveReportForCriteriaResponse_QNAME, RetrieveReportForCriteriaResponseType.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", name = "applicationName")
    public JAXBElement<String> createApplicationName(String value) {
        return new JAXBElement<String>(_ApplicationName_QNAME, String.class, null, value);
    }

}
