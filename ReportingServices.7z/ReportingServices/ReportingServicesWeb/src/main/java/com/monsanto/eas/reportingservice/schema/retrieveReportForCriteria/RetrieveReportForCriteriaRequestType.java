
package com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for retrieveReportForCriteriaRequestType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveReportForCriteriaRequestType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria}roleName"/>
 *         &lt;element ref="{urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria}applicationName"/>
 *         &lt;element ref="{urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria}documentId"/>
 *         &lt;element name="format" type="{urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria}outputFormat"/>
 *         &lt;element name="listOfCriteria" type="{urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria}listOfCriteria"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveReportForCriteriaRequestType", propOrder = {
    "roleName",
    "applicationName",
    "documentId",
    "format",
    "listOfCriteria"
})
public class RetrieveReportForCriteriaRequestType {

    @XmlElement(required = true)
    protected String roleName;
    @XmlElement(required = true)
    protected String applicationName;
    @XmlElement(required = true)
    protected String documentId;
    @XmlElement(required = true)
    protected OutputFormat format;
    @XmlElement(required = true)
    protected ListOfCriteria listOfCriteria;

    /**
     * Gets the value of the roleName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * Sets the value of the roleName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoleName(String value) {
        this.roleName = value;
    }

    /**
     * Gets the value of the applicationName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getApplicationName() {
        return applicationName;
    }

    /**
     * Sets the value of the applicationName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setApplicationName(String value) {
        this.applicationName = value;
    }

    /**
     * Gets the value of the documentId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDocumentId() {
        return documentId;
    }

    /**
     * Sets the value of the documentId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDocumentId(String value) {
        this.documentId = value;
    }

    /**
     * Gets the value of the format property.
     * 
     * @return
     *     possible object is
     *     {@link OutputFormat }
     *     
     */
    public OutputFormat getFormat() {
        return format;
    }

    /**
     * Sets the value of the format property.
     * 
     * @param value
     *     allowed object is
     *     {@link OutputFormat }
     *     
     */
    public void setFormat(OutputFormat value) {
        this.format = value;
    }

    /**
     * Gets the value of the listOfCriteria property.
     * 
     * @return
     *     possible object is
     *     {@link ListOfCriteria }
     *     
     */
    public ListOfCriteria getListOfCriteria() {
        return listOfCriteria;
    }

    /**
     * Sets the value of the listOfCriteria property.
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfCriteria }
     *     
     */
    public void setListOfCriteria(ListOfCriteria value) {
        this.listOfCriteria = value;
    }

}
