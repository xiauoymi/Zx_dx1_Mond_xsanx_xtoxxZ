
package com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for retrieveReportForCriteriaResponseType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="retrieveReportForCriteriaResponseType">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element ref="{urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria}newDocument"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "retrieveReportForCriteriaResponseType", propOrder = {
    "newDocument"
})
public class RetrieveReportForCriteriaResponseType {

    @XmlElement(required = true)
    protected NewDocument newDocument;

    /**
     * Gets the value of the newDocument property.
     * 
     * @return
     *     possible object is
     *     {@link NewDocument }
     *     
     */
    public NewDocument getNewDocument() {
        return newDocument;
    }

    /**
     * Sets the value of the newDocument property.
     * 
     * @param value
     *     allowed object is
     *     {@link NewDocument }
     *     
     */
    public void setNewDocument(NewDocument value) {
        this.newDocument = value;
    }

}
