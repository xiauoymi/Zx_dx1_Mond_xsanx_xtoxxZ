@javax.xml.bind.annotation.XmlSchema(namespace = "urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria;
