/*
 RetrieveDocumentServiceImpl was created on Apr 7, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.service.impl;

import com.monsanto.eas.reportingservice.helper.RetrieveDocumentHelper;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.RetrieveDocumentRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.RetrieveDocumentResponseType;
import com.monsanto.eas.reportingservice.service.RetrieveDocumentFault;
import com.monsanto.eas.reportingservice.service.RetrieveDocumentService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import weblogic.jws.WLHttpTransport;

import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.ws.BindingType;
import javax.xml.ws.soap.MTOM;
import javax.xml.ws.soap.SOAPBinding;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@MTOM(threshold = 0, enabled = true)
@WebService(endpointInterface = "com.monsanto.eas.reportingservice.service.RetrieveDocumentService")
@WLHttpTransport(serviceUri = "RetrieveDocumentService", portName = "RetrieveDocumentServicePort")
@BindingType(value = SOAPBinding.SOAP11HTTP_MTOM_BINDING)
public class RetrieveDocumentServiceImpl implements RetrieveDocumentService {

  public RetrieveDocumentResponseType retrieveDocument(@WebParam(name = "retrieveDocumentRequest",
      targetNamespace = "urn:monsanto:enterprise:services:reporting:viewdocument",
      partName = "request") RetrieveDocumentRequestType request) throws RetrieveDocumentFault {
    ApplicationContext appContext = new ClassPathXmlApplicationContext("spring-reportingservice-beans.xml");
    RetrieveDocumentHelper helper = (RetrieveDocumentHelper) appContext.getBean("retrieveDocumentHelper");

    return helper.getDocumentById(request);
  }
}
