/*
 RetrieveListOfCriteriaForDocumentServiceImpl was created on Apr 8, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.service.impl;

import com.monsanto.eas.reportingservice.helper.RetrieveListOfCriteriaForDocumentHelper;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.RetrieveListOfCriteriaRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.RetrieveListOfCriteriaResponseType;
import com.monsanto.eas.reportingservice.service.RetrieveCriteriaForDocumentFault;
import com.monsanto.eas.reportingservice.service.RetrieveListOfCriteriaForDocumentService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import weblogic.jws.WLHttpTransport;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
@WebService(endpointInterface = "com.monsanto.eas.reportingservice.service.RetrieveListOfCriteriaForDocumentService")
@WLHttpTransport(serviceUri = "RetrieveListOfCriteriaForDocumentService", portName = "RetrieveDocumentServicePort")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)
public class RetrieveListOfCriteriaForDocumentServiceImpl implements RetrieveListOfCriteriaForDocumentService {
  @WebMethod
  public RetrieveListOfCriteriaResponseType retrieveListOfCriteriaForDocument(
      @WebParam(name = "retrieveListOfCriteriaForDocumentRequest",
          targetNamespace = "urn:monsanto:enterprise:services:reporting:retrieveListOfCriteria",
          partName = "request") RetrieveListOfCriteriaRequestType request) throws RetrieveCriteriaForDocumentFault {
    ApplicationContext appContext = new ClassPathXmlApplicationContext("spring-reportingservice-beans.xml");
    RetrieveListOfCriteriaForDocumentHelper helper = (RetrieveListOfCriteriaForDocumentHelper) appContext
        .getBean("retrieveListOfCriteriaForDocumentHelper");
    return helper.getListOfCriteria(request);
  }
}