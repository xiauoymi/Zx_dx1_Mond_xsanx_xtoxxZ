/*
 RetrieveReportForCriteriaServiceImpl was created on Apr 10, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.service.impl;

import com.monsanto.eas.reportingservice.helper.RetrieveReportForCriteriaHelper;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.RetrieveReportForCriteriaRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.RetrieveReportForCriteriaResponseType;
import com.monsanto.eas.reportingservice.service.RetrieveReportForCriteriaFault;
import com.monsanto.eas.reportingservice.service.RetrieveReportForCriteriaService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import weblogic.jws.WLHttpTransport;

import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.ws.BindingType;
import javax.xml.ws.soap.MTOM;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */

@MTOM(threshold = 0, enabled = true)
@WebService(endpointInterface = "com.monsanto.eas.reportingservice.service.RetrieveReportForCriteriaService")
@WLHttpTransport(serviceUri = "RetrieveReportForCriteriaService", portName = "RetrieveReportForCriteriaServicePort")
@BindingType(value = javax.xml.ws.soap.SOAPBinding.SOAP11HTTP_MTOM_BINDING)
public class RetrieveReportForCriteriaServiceImpl implements RetrieveReportForCriteriaService{
  public RetrieveReportForCriteriaResponseType retrieveReportForCriteria(
      @WebParam(name = "retrieveReportForCriteriaRequest",
          targetNamespace = "urn:monsanto:enterprise:services:reporting:retrieveReportForCriteria",
          partName = "request") RetrieveReportForCriteriaRequestType request) throws RetrieveReportForCriteriaFault {
    ApplicationContext appContext = new ClassPathXmlApplicationContext("spring-reportingservice-beans.xml");
    RetrieveReportForCriteriaHelper helper = (RetrieveReportForCriteriaHelper) appContext.getBean("retrieveDocumentForCriteriaHelper");
    return helper.setCriteriaFromRequestAndRetrieveReport(request);
  }
}