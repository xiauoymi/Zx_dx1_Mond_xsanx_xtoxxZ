/*
 ViewReportsServiceImpl was created on Mar 31, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.service.impl;

import com.monsanto.eas.reportingservice.helper.ViewReportsHelper;
import com.monsanto.eas.reportingservice.schema.RetrieveReportRequestType;
import com.monsanto.eas.reportingservice.schema.RetrieveReportResponseType;
import com.monsanto.eas.reportingservice.service.ViewReportsFault;
import com.monsanto.eas.reportingservice.service.ViewReportsService;
import org.springframework.remoting.jaxrpc.ServletEndpointSupport;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import weblogic.jws.WLHttpTransport;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *po
 * @author rrmall
 * @version $Revision$
 */
@WebService(endpointInterface = "com.monsanto.eas.reportingservice.service.ViewReportsService")
@WLHttpTransport(serviceUri = "ViewReportsService", portName = "ViewReportsServicePort")
@SOAPBinding(parameterStyle= SOAPBinding.ParameterStyle.BARE)
public class ViewReportsServiceImpl extends ServletEndpointSupport implements ViewReportsService{

  @WebMethod
  public RetrieveReportResponseType getReports(@WebParam(name = "retrieveReportRequest",
      targetNamespace = "urn:monsanto:enterprise:services:reporting:viewreport",
      partName = "request") RetrieveReportRequestType request) throws ViewReportsFault {
    ApplicationContext appContext = new ClassPathXmlApplicationContext("spring-reportingservice-beans.xml");
    ViewReportsHelper helper = (ViewReportsHelper )appContext.getBean("viewReportsHelper");
    return helper.getReports(request);
  }
}