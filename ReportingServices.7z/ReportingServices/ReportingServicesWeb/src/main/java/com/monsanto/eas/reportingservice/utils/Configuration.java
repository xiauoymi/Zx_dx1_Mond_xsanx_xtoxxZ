/*
 Configuration was created on Mar 31, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.utils;

import com.monsanto.Util.StringUtils;
import com.monsanto.eas.reportingservice.reportingengine.BOConstants;
import org.apache.log4j.Logger;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import java.util.MissingResourceException;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class Configuration {

    Map<String, String> roleToAccountMap = null;

    private static final String LSI_FUNCTION = "lsi.function";


// Defined property names.

    private Logger logger =   Logger.getLogger(Configuration.class);

    private static final String CONFIG_FILE = "RoleToAccountMapping.properties";
    private static final String REPORTINGSERVICE = "reportingservice";

    /**
     * Private constructor.
     */
    public Configuration() {
        initConfiguration();
    }

    private void initConfiguration() {
        logger.debug("Initializing system configuration properties.");
        try {
            populateRoleToAccountMap();
        } catch (Exception e) {
            logger.error(e.getMessage());
            logger.error(e);
        }
    }

    private void populateRoleToAccountMap() throws Exception {
        roleToAccountMap = new HashMap<String, String>();
        String storageLocation = System.getProperty(BOConstants.ENV_VARIABLE_MONCRYPTJV);
        logger.info("The environment variable for MONCRYTJV is : " + storageLocation);
        String filename = new StringBuffer(storageLocation).append(File.separator).append(REPORTINGSERVICE).append(File.separator).append(CONFIG_FILE).toString();
        logger.info("The filename is : " + filename);
        BufferedReader brIn;
        String line;
        try {
            brIn = new BufferedReader(new FileReader(filename));
            while ((line = brIn.readLine()) != null) {
                if (!StringUtils.isNullOrEmpty(line)) {
                    String[] strings = line.split("=");
                    roleToAccountMap.put(strings[0], strings[1]);
                }
            }
        }
        catch (FileNotFoundException ex) {
            throw new Exception("Invalid file name (" + filename + ").");
        }
    }

    /**
     * Returns the value associated with the supplied name.
     *
     * @param aName: property key
     * @return String the property value
     * @throws Exception: 
     */
    public String getProperty(String aName) throws Exception {
        String lValue;
        String environment = getPropertyPrefix().trim();
        try {
            logger.debug("The lsi function is " + environment);
            logger.debug("The property being looked up is " + environment + "." + aName.trim());
            lValue = roleToAccountMap.get(environment + "." + aName).trim();

        } catch (MissingResourceException e) {
            logger.debug("The lsi function is " + getPropertyPrefix());
            logger.debug("The property being looked up is default" + "." + aName.trim());
            lValue = roleToAccountMap.get("default." + aName).trim();
        } catch (Exception e) {
            logger.error("Undefined Property: " + environment + "." + aName);
            throw (e);
        }

        return lValue;
    }

    private String getPropertyPrefix() throws Exception {
        String prefix = System.getProperty(LSI_FUNCTION);
        if (StringUtils.isNullOrEmpty(prefix)) {
            throw new Exception("Bad value of lsi.function = " + prefix);
        }
        return prefix;
    }
}