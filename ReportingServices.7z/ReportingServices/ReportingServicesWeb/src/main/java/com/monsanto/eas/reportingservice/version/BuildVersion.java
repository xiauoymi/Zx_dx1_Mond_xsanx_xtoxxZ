package com.monsanto.eas.reportingservice.version;

/**
 * Created by IntelliJ IDEA.
 * User: JHERN10
 * Date: 5/7/13
 * Time: 3:34 PM
 * To change this template use File | Settings | File Templates.
 */
public interface BuildVersion {

    void setBuildInfo() throws Exception;
    void logBuildInfo();

}
