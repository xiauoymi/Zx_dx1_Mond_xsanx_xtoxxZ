package com.monsanto.eas.reportingservice.version;

import org.apache.log4j.Logger;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

/**
 * Created by IntelliJ IDEA.
 * User: JHERN10
 * Date: 5/6/13
 * Time: 12:59 PM
 * To change this template use File | Settings | File Templates.
 */
@Aspect
public class ServiceVersion {

    private Logger logger = Logger.getLogger(this.getClass());

    private BuildVersion buildVersion;

    public ServiceVersion(BuildVersion buildVersion) {
        this.buildVersion = buildVersion;
    }

    @Pointcut("execution(* com.monsanto.eas.reportingservice.helper.*.*(..))")
    public void executeService(){
    }

    @Before("executeService()")
    public void printVersion()  {
        try {
            buildVersion.setBuildInfo();
            buildVersion.logBuildInfo();
        } catch (Exception e) {
           logger.error(e.getMessage());
        }
    }
}
