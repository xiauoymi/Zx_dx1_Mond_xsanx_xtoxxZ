package com.monsanto.eas.reportingservice.version;

import com.monsanto.eas.reportingservice.helper.RetrieveDocumentHelper;
import com.monsanto.eas.reportingservice.version.impl.BuildVersionImpl;
import org.apache.log4j.Logger;
import org.springframework.core.io.InputStreamResource;

import javax.servlet.http.HttpServlet;
import java.io.InputStream;

/**
 * Created by IntelliJ IDEA.
 * User: PKGUND
 * Date: Apr 9, 2012
 * Time: 1:50:39 PM
 */
public class VersionServlet extends HttpServlet {

    private Logger logger =   Logger.getLogger(VersionServlet.class);

    public void init(){
        try {
            InputStream is = getServletContext().getResourceAsStream("/WEB-INF/classes/version.txt");
            BuildVersion buildVersion = new BuildVersionImpl(new InputStreamResource(is));
            buildVersion.setBuildInfo();
            buildVersion.logBuildInfo();
            RetrieveDocumentHelper.initEnterpriseEngine();
        } catch (Exception e) {
            logger.error("Error occurred while obtaining version information.");
        }

    }

}
