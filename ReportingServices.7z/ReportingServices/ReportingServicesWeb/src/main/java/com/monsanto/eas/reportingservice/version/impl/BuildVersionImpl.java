package com.monsanto.eas.reportingservice.version.impl;

import com.monsanto.eas.reportingservice.version.BuildVersion;
import org.apache.log4j.Logger;
import org.springframework.core.io.Resource;

import java.util.jar.Attributes;
import java.util.jar.Manifest;

/**
 * Created by IntelliJ IDEA.
 * User: JHERN10
 * Date: 5/10/13
 * Time: 9:47 AM
 * To change this template use File | Settings | File Templates.
 */
public class BuildVersionImpl implements BuildVersion {

    private final static String BUILD_VERSION = "Build-Version";
    private final static String BUILT_DATE = "Built-Date";
    private final static String ATTRIBUTE_EXCEPTION = "Received in-complete Attributes to obtain the Build Info";
    private final static String RESOURCE_EXCEPTION = "The source doesn´t exist to obtain the Build Info";

    private Resource versionResource;

    public BuildVersionImpl(Resource versionResource) {
        this.versionResource = versionResource;
    }

    private Logger logger = Logger.getLogger(this.getClass());

    private String buildVersion;
    private String buildDate;
    private Attributes attributes;

    public String getBuildVersion() {
        return this.buildVersion;
    }

    public String getBuildDate() {
        return this.buildDate;
    }

    public void setBuildInfo() throws Exception {
        if(versionResource == null || !versionResource.exists()) {
            throw new Exception(RESOURCE_EXCEPTION);
        }
        setBuildAttributes();
        if( attributes == null || attributes.getValue(BUILD_VERSION) == null ||
            attributes.getValue(BUILT_DATE) == null) {
            throw new Exception(ATTRIBUTE_EXCEPTION);
        }
        this.buildVersion = attributes.getValue(BUILD_VERSION);
        this.buildDate = attributes.getValue(BUILT_DATE);
    }

    private void setBuildAttributes() throws Exception {
        Manifest mf = new Manifest();
        mf.read(versionResource.getInputStream());
        this.attributes = mf.getMainAttributes();
    }

    public void logBuildInfo() {
       logger.info("Build Version: " + this.buildVersion + "  Build Date: " + this.buildDate);
    }
}
