/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Oct 21, 2007
 * Time: 11:20:17 PM
 */
public class BusinessObjectsEntity {
    private String name;
    private String description;
    private String id;
    private String author;

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getContentsInHTMLFormat(){
        return "<li class=\"listItemClass\"><a href=\"javascript:getReport('"+getId()+"');\">"+getName()+"</a></li>";
    }

    public String getUID(){
        return getId()+":"+getName();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
