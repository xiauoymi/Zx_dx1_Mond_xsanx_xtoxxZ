
import java.util.List;
import java.util.Iterator;

public class FolderTO extends BusinessObjectsEntity {    
    private List contents;

    public String getContentsInHTMLFormat() {
        Iterator it = null;
        StringBuffer htmlOutput = new StringBuffer();
        htmlOutput.append("<ul>").append(super.getContentsInHTMLFormat());
        it = getContents().iterator();
             while (it.hasNext()){
                 htmlOutput.append("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;").append(((BusinessObjectsEntity)it.next()).getContentsInHTMLFormat());
             }
       return htmlOutput.append("</ul>").toString();
    }

    public String getUID(){
        Iterator it = null;
        StringBuffer htmlOutput = new StringBuffer();
        htmlOutput.append("\n").append(super.getUID());
        it = getContents().iterator();
             while (it.hasNext()){
                 htmlOutput.append("\n").append(((BusinessObjectsEntity)it.next()).getUID());
             }
       return htmlOutput.toString();
    }

    public List getContents() {
        return contents;
    }

    public void setContents(List contents) {
        this.contents = contents;
    }
}
