package com.monsanto.eas.reportingservice.helper;

import com.monsanto.eas.reportingservice.reportingengine.ConnectionObjectBO;
import com.monsanto.eas.reportingservice.uat.ReportingServiceTestUtil;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: JHERN10
 * Date: 5/31/13
 * Time: 8:38 AM
 * To change this template use File | Settings | File Templates.
 */
public class ReportEngineConnectionHelper_UT {

    @Test
    public void testGetCredentialsAndConnection_Success() throws Exception {
        String roleName = ReportingServiceTestUtil.APOLLO_ROLE_NAME;
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(roleName);
        assertNotNull(boConnector);
        assertNotNull(boConnector.getCmsName());
        assertNotNull(boConnector.getUserId());
        assertNotNull(boConnector.getPassword());
        assertNotNull(boConnector.getSession());
    }

    @Test
    public void testGetCredentialsAndConnection_ExceptionThrown() throws Exception {
        String roleName = "BO-INEXISTENT";
        try {
            ReportEngineConnectionHelper.getCredentialsAndConnection(roleName);
            fail("this should fail");
        } catch (Exception e) {
            assertTrue(e instanceof NullPointerException);
        }
    }

}
