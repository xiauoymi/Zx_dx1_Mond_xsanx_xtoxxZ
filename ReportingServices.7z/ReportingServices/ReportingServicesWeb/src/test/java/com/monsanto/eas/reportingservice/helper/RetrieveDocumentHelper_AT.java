/*
 RetrieveDocumentHelper_AT was created on Apr 10, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.helper;

import com.crystaldecisions.sdk.occa.infostore.IInfoObject;
import com.monsanto.eas.reportingservice.reportingengine.ConnectionObjectBO;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.OutputFormat;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.RetrieveDocumentRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.RetrieveDocumentResponseType;
import com.monsanto.eas.reportingservice.service.RetrieveDocumentFault;
import com.monsanto.eas.reportingservice.uat.ReportingServiceTestUtil;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class RetrieveDocumentHelper_AT extends TestCase {

  public RetrieveDocumentHelper_AT(String name) {
    super(name);
  }

  public void testRetrieveDocument_RequestNotSet_ThrowsException() throws Exception {
    RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
    RetrieveDocumentHelper helper = new RetrieveDocumentHelper();
    try {
      helper.getDocumentById(request);
      fail("this should fail");
    } catch (Exception e) {
      assertEquals("Error occurred during operation: getDocumentById : Received in-complete Retrieve Document object",
          e.getMessage());
    }
  }

  public void testRetrieveDocument_RequestSetOutputFormatNotSet_ThrowsException() throws Exception {
    RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
    RetrieveDocumentHelper helper = new RetrieveDocumentHelper();
    try {
      request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
      request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
      request.setDocumentId("Fh8f7U0HAQUAkTYAAKALJlsCACToe.kW");
      helper.getDocumentById(request);
      fail("this should fail");
    } catch (RetrieveDocumentFault e) {
      assertEquals("Error occurred during operation: getDocumentById : Received in-complete Retrieve Document object",
          e.getMessage());
    }
  }

  public void testRetrieveDocument_RequestSetOutputFormatIncorrect_ThrowsException() throws Exception {
    RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
    RetrieveDocumentHelper helper = new RetrieveDocumentHelper();
    try {
      request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
      request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
      request.setDocumentId("Fh8f7U0HAQUAkTYAAKALJlsCACToe.kW");
      request.setFormat(OutputFormat.fromValue("ABC"));
      helper.getDocumentById(request);
      fail("this should fail");
    } catch (Exception e) {
      assertEquals("No enum const class com.monsanto.eas.reportingservice.schema.retrieveDocument.OutputFormat.ABC",
          e.getMessage());
    }
  }

    public void testGetDocumentByUID_Success() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String documentId = "Fp3EBE7ibgAAPF8AAKA78VoCACToe.kW";
        IInfoObject infoObjectDocument = RetrieveDocumentHelper.getDocumentByUID(documentId, boConnector.getInfoStore());
        assertNotNull(infoObjectDocument);
    }

    public void testGetDocumentByUID_ExceptionThrown() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String documentId = "InvalidDocumentId";
        try {
            RetrieveDocumentHelper.getDocumentByUID(documentId, boConnector.getInfoStore());
            fail("this should fail");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("The path node '" + documentId + "' does not exist in the repository"));
        }
    }

  public void testRetrieveDocument_XLS_RequestObjectSet_DocumentRetrieved() throws Exception {
    RetrieveDocumentHelper helper = new RetrieveDocumentHelper();
    RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("FkySSU0kZAAApwsAAKAr7VoBACToe.hu");
    request.setFormat(OutputFormat.XLS);
    RetrieveDocumentResponseType response = helper.getDocumentById(request);
    assertNotNull(response);
    assertEquals("FkySSU0kZAAApwsAAKAr7VoBACToe.hu", response.getDocumentDetails().getUID());
    assertNotNull(response.getDocumentDetails().getView());
    assertEquals("TCWHIT1", response.getDocumentDetails().getView().getAuthor());
    assertEquals("Apollo Testing Report", response.getDocumentDetails().getView().getName());
  }

  public void testRetrieveDocument_PDF_RequestObjectSet_DocumentRetrieved() throws Exception {
    RetrieveDocumentHelper helper = new RetrieveDocumentHelper();
    RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("FkySSU0kZAAApwsAAKAr7VoBACToe.hu");
    request.setFormat(OutputFormat.PDF);
    RetrieveDocumentResponseType response = helper.getDocumentById(request);
    assertNotNull(response);
    assertEquals("FkySSU0kZAAApwsAAKAr7VoBACToe.hu", response.getDocumentDetails().getUID());
    assertNotNull(response.getDocumentDetails().getView());
    assertEquals("TCWHIT1", response.getDocumentDetails().getView().getAuthor());
    assertEquals("Apollo Testing Report", response.getDocumentDetails().getView().getName());
  }

  public void testRetrieveDocument_RequestObjectSet_DocumentDoesNotExistExceptionThrown() throws Exception {
    RetrieveDocumentHelper helper = new RetrieveDocumentHelper();
    RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("90765");
    request.setFormat(OutputFormat.PDF);
    RetrieveDocumentResponseType response = null;
    try {
      response = helper.getDocumentById(request);
    } catch (Exception e) {
      assertEquals(
          "Error occurred during operation: getDocumentById : The document reference 90765 is invalid. (WRE 02501)",
          e.getMessage());
    }
    assertNull(response);
  }


  public void testRetrieveDocumentTPS_RequestObjectSet_DocumentDoesNotExistExceptionThrown() throws Exception {
    RetrieveDocumentHelper helper = new RetrieveDocumentHelper();
    RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName("Appolo");
    request.setDocumentId("90765");
    request.setFormat(OutputFormat.PDF);
    RetrieveDocumentResponseType response = null;
    try {
      response = helper.getDocumentById(request);
    } catch (Exception e) {
      assertEquals(
          "Error occurred during operation: getDocumentById : The document reference 90765 is invalid. (WRE 02501)",
          e.getMessage());
    }
    assertNull(response);
  }

  public void testRetrieveDocument_RoleAndApplicationNameDontMatch_ExceptionThrown() throws Exception {
    RetrieveDocumentHelper helper = new RetrieveDocumentHelper();
    RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
    request.setRoleName("BO-TEST");
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("109674");
    request.setFormat(OutputFormat.PDF);
    RetrieveDocumentResponseType response = null;
    try {
      response = helper.getDocumentById(request);
    } catch (Exception e) {
      assertEquals("Error occurred during operation: getDocumentById : null", e.getMessage());
      assertNull(response);
    }
  }

    public void testRetrieveDocument_ReportIsACrystalReport() throws Exception {
        RetrieveDocumentHelper helper = new RetrieveDocumentHelper();
        RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
        request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
        request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
        // Report Name: Fall Financing Report
        request.setDocumentId("FspYUEySKgIABz8AAKB7wlsBACToe.hu");
        request.setFormat(OutputFormat.PDF);
        RetrieveDocumentResponseType response = helper.getDocumentById(request);
        assertEquals("FspYUEySKgIABz8AAKB7wlsBACToe.hu", response.getDocumentDetails().getUID());
    }

}