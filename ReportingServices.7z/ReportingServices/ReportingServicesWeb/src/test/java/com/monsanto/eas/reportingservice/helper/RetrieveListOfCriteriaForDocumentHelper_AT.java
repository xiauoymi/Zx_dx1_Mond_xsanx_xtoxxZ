/*
 RetrieveListOfCriteriaForDocumentHelper_AT was created on Apr 11, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.helper;

import com.crystaldecisions.sdk.occa.infostore.IInfoObject;
import com.monsanto.eas.reportingservice.reportingengine.ConnectionObjectBO;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.CriteriaInfo;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.RetrieveListOfCriteriaRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.RetrieveListOfCriteriaResponseType;
import com.monsanto.eas.reportingservice.uat.ReportingServiceTestUtil;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class RetrieveListOfCriteriaForDocumentHelper_AT extends TestCase {
  public void testRequestObjectNotSet_ExceptionThrown() throws Exception {
    RetrieveListOfCriteriaRequestType request = new RetrieveListOfCriteriaRequestType();
    RetrieveListOfCriteriaForDocumentHelper helper = new RetrieveListOfCriteriaForDocumentHelper();
    try {
      helper.getListOfCriteria(request);
    } catch (Exception e) {
      assertEquals("Error occurred during operation: getListOfCriteria : Received in-complete RetrieveListOfCriteriaForDocumentRequest object",
          e.getMessage());
    }
  }

  public void testRequestSet_ListOfCriteriaForDocumentReturned() throws Exception {
    RetrieveListOfCriteriaForDocumentHelper helper = new RetrieveListOfCriteriaForDocumentHelper();
    RetrieveListOfCriteriaRequestType request = new RetrieveListOfCriteriaRequestType();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("Fsb8vUzWlwsAOB4AAKAbiFoBACToe.hu");
    RetrieveListOfCriteriaResponseType response = helper.getListOfCriteria(request);
    System.out.println("response.toString() = " + response.toString());
    assertNotNull(response);
    assertEquals(1, response.getCriteriaInfo().size());
  }

  public void testRequestSetforTourSheet_ListOfCriteriaForDocumentReturned() throws Exception {
    RetrieveListOfCriteriaForDocumentHelper helper = new RetrieveListOfCriteriaForDocumentHelper();
    RetrieveListOfCriteriaRequestType request = new RetrieveListOfCriteriaRequestType();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("FjNfqE0uGwsAIX4AAKB7UlsCACToe.kW");
    RetrieveListOfCriteriaResponseType response = helper.getListOfCriteria(request);
    System.out.println("response.toString() = " + response.toString());
    assertNotNull(response);
    assertEquals(1, response.getCriteriaInfo().size());

  }

    public void testGetPromptsDocumentByUID_Success() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String documentId = "Fp3EBE7ibgAAPF8AAKA78VoCACToe.kW";
        IInfoObject document = RetrieveDocumentHelper.getDocumentByUID(documentId, boConnector.getInfoStore());
        assertNotNull(document);
        IInfoObject infoObjectDocument = RetrieveListOfCriteriaForDocumentHelper.getPromptsDocumentByUID(String.valueOf(document.getID()), boConnector.getInfoStore());
        assertNotNull(infoObjectDocument);
    }

    public void testGetPromptsDocumentByUID_NotExist() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String documentId = "InvalidDocumentId";
        IInfoObject infoObjectDocument = RetrieveListOfCriteriaForDocumentHelper.getPromptsDocumentByUID(documentId, boConnector.getInfoStore());
        assertNull(infoObjectDocument);
    }


  public void testRequestSetforProtocolDetailReport_ListOfCriteriaForDocumentReturned() throws Exception {
    RetrieveListOfCriteriaForDocumentHelper helper = new RetrieveListOfCriteriaForDocumentHelper();
    RetrieveListOfCriteriaRequestType request = new RetrieveListOfCriteriaRequestType();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("Fm4gwE3IaQcAEXYAAKBL5FoBACToe.hu");
    RetrieveListOfCriteriaResponseType response = helper.getListOfCriteria(request);
    System.out.println("response.toString() = " + response.toString());
    assertNotNull(response);
    assertEquals(1, response.getCriteriaInfo().size());
  }

  public void testRequestSetforPlantingSheetReport_ListOfCriteriaForDocumentReturned() throws Exception {
    RetrieveListOfCriteriaForDocumentHelper helper = new RetrieveListOfCriteriaForDocumentHelper();
    RetrieveListOfCriteriaRequestType request = new RetrieveListOfCriteriaRequestType();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("Fl8kkUwCfgMAn3oAAKArrFoBACToe.hu");
    RetrieveListOfCriteriaResponseType response = helper.getListOfCriteria(request);
    System.out.println("response.toString() = " + response.toString());
    assertNotNull(response);
    assertEquals(1, response.getCriteriaInfo().size());
    List<CriteriaInfo> criteriaInfos = response.getCriteriaInfo();
    for (CriteriaInfo criteria: criteriaInfos){
      assertFalse(criteria.isOptional());
    }
  }

  public void testRequestSetforSpraySheetReport_ListOfCriteriaForDocumentReturned() throws Exception {
    RetrieveListOfCriteriaForDocumentHelper helper = new RetrieveListOfCriteriaForDocumentHelper();
    RetrieveListOfCriteriaRequestType request = new RetrieveListOfCriteriaRequestType();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("Fp3EBE7ibgAAPF8AAKA78VoCACToe.kW");
    RetrieveListOfCriteriaResponseType response = helper.getListOfCriteria(request);
    System.out.println("response.toString() = " + response.toString());
    assertNotNull(response);
    assertEquals(17, response.getCriteriaInfo().size());
    List<CriteriaInfo> criteriaInfos = response.getCriteriaInfo();
    for (CriteriaInfo criteria: criteriaInfos){
      assertFalse(criteria.isOptional());
    }
  }

    public void testRequestSetforCrystalReport_ListOfCriteriaForDocumentReturned() throws Exception {
        RetrieveListOfCriteriaForDocumentHelper helper = new RetrieveListOfCriteriaForDocumentHelper();
        RetrieveListOfCriteriaRequestType request = new RetrieveListOfCriteriaRequestType();
        request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
        request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
        // Report Name: Fall Financing Report
        request.setDocumentId("FspYUEySKgIABz8AAKB7wlsBACToe.hu");
        RetrieveListOfCriteriaResponseType response = helper.getListOfCriteria(request);
        assertNotNull(response);
        assertEquals(3, response.getCriteriaInfo().size());
    }

}