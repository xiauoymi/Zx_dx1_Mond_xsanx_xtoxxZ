/*
 RetrieveReportForCriteriaHelper_AT was created on Apr 11, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.helper;

import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.*;
import com.monsanto.eas.reportingservice.service.RetrieveReportForCriteriaFault;
import com.monsanto.eas.reportingservice.uat.ReportingServiceTestUtil;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author RRMALL
 * @version $Revision$
 */
public class RetrieveReportForCriteriaHelper_AT extends TestCase {
  public void testRequestObjectNotSet_ThrowsException() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    try {
      helper.setCriteriaFromRequestAndRetrieveReport(request);
      fail("this should fail");
    } catch (Exception e) {
      assertEquals(
          "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : Received in-complete RetrieveReportForCriteriaRequest object",
          e.getMessage());
    }

  }

  public void testRequestObjectNotSet_FormatNotSet_ThrowsException() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    try {
      request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
      request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
      request.setDocumentId("109674");
      helper.setCriteriaFromRequestAndRetrieveReport(request);
      fail("this should fail");
    } catch (Exception e) {
      assertEquals(
          "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : Received in-complete RetrieveReportForCriteriaRequest object",
          e.getMessage());
    }
  }

  public void testRequestObjectNotSet_FormatNotCorrect_ThrowsException() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    try {
      request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
      request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
      request.setDocumentId("109674");
      request.setFormat(OutputFormat.fromValue("ABC"));
      helper.setCriteriaFromRequestAndRetrieveReport(request);
      fail("this should fail");
    } catch (Exception e) {
      assertEquals(
          "No enum const class com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.OutputFormat.ABC",
          e.getMessage());
    }
  }

  public void testRequestSet_XLS_DocumentRetrieved() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("FoI9yU0m4wgAQicAAKBr31oBACToe.hu");
    request.setFormat(OutputFormat.XLS);

    ListOfCriteria criteriaList = new ListOfCriteria();
    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("Enter Protocol Id in Test Set:");
    criteria.setName("Enter Protocol Id in Test Set:");
    criteria.setAllowMultiValues(true);
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("16100");
    criteriaValue.setValue("584707401777152");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);
    request.setListOfCriteria(criteriaList);

    RetrieveReportForCriteriaResponseType response = helper.setCriteriaFromRequestAndRetrieveReport(request);
    assertNotNull(response);
    assertTrue(response.getNewDocument().getOutputView().getContentLength() > 0);
  }

  public void testRequestSet_PDF_DocumentRetrieved() throws Exception {
      RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
      RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
      request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
      request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
      // Report Name: Protocol Detail Report
      request.setDocumentId("Fm4gwE3IaQcAEXYAAKBL5FoBACToe.hu");
      request.setFormat(OutputFormat.PDF);

      ListOfCriteria criteriaList = new ListOfCriteria();
      CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
      criteria.setID("Enter Protocol ID:");
      criteria.setName("Enter Protocol ID:");
      criteria.setPromptType("NUMERIC");
      criteria.setAllowMultiValues(true);
      criteria.setAllowDiscreteValue(true);
      BoFillPromptValue criteriaValue = new BoFillPromptValue();
      criteriaValue.setValue("27");
      criteria.getCriteriaValues().add(criteriaValue);
      criteriaList.getCriteriaInfoFromRequest().add(criteria);
      request.setListOfCriteria(criteriaList);
      RetrieveReportForCriteriaResponseType response = helper.setCriteriaFromRequestAndRetrieveReport(request);
      assertNotNull(response);
      assertTrue(response.getNewDocument().getOutputView().getContentLength() > 0);
  }

    public void testRequestSetVisionReport_AllMandatoryPromptsSet_DocumentRetrieved() throws Exception {
        RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
        RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
        request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
        request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
        request.setFormat(OutputFormat.PDF);
        // Report Name: Customer Profile
        request.setDocumentId("Fknvb02q7gQAZAQAAKBrvFoBACToe.hu");

        ListOfCriteria criteriaList = new ListOfCriteria();
        CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();

        criteria.setID("1 Sales Org");
        criteria.setName("1 Sales Org");
        criteria.setPromptType("TEXT");
        criteria.setAllowDiscreteValue(true);
        criteria.setAllowMultiValues(true);
        BoFillPromptValue criteriaValue = new BoFillPromptValue();
        criteriaValue.setRowIndex("[YASISORG].[US31]");
        criteriaValue.setValue("US31");
        criteria.getCriteriaValues().add(criteriaValue);
        criteriaValue = new BoFillPromptValue();
        criteriaValue.setRowIndex("[YASISORG].[US32]");
        criteriaValue.setValue("US32");
        criteria.getCriteriaValues().add(criteriaValue);
        criteriaList.getCriteriaInfoFromRequest().add(criteria);

        criteria = new CriteriaInfoFromRequest();
        criteria.setID("8 Sales Year");
        criteria.setName("8 Sales Year");
        criteria.setPromptType("TEXT");
        criteria.setAllowDiscreteValue(true);
        criteria.setAllowMultiValues(false);
        criteriaValue = new BoFillPromptValue();
        criteriaValue.setRowIndex("[0FISCYEAR].[Z42011]");
        criteriaValue.setValue("2011");
        criteria.getCriteriaValues().add(criteriaValue);
        criteriaList.getCriteriaInfoFromRequest().add(criteria);

        request.setListOfCriteria(criteriaList);
        RetrieveReportForCriteriaResponseType response = helper.setCriteriaFromRequestAndRetrieveReport(request);
        assertNotNull(response);
    }

  public void testRequestSetVisionReportOnDevelopment_AllMandatoryPromptsSet_DocumentRetrieved() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
    request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
    request.setFormat(OutputFormat.PDF);
    request.setDocumentId("FmHXakwzCQQAKRIAAKDLBVsBACToe.hu");

    ListOfCriteria criteriaList = new ListOfCriteria();

    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();

    criteria.setID("1 Sales Org");
    criteria.setName("1 Sales Org");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteria.setAllowMultiValues(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("[YASISORG].[US31]");
    criteriaValue.setValue("US31");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("[YASISORG].[US32]");
    criteriaValue.setValue("US32");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID(" 9 As of Date");
    criteria.setName(" 9 As of Date");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteria.setAllowMultiValues(true);
    criteriaValue.setValue("01/07/2011 04:47:31 PM");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("As Is Date (Single Value)");
    criteria.setName("As Is Date (Single Value)");
    criteria.setPromptType("DATETIME");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("");
    criteriaValue.setValue("8/13/2010 12:00:00 AM");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("8 Sales Year");
    criteria.setName("8 Sales Year");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("[0FISCYEAR].[Z42010]");
    criteriaValue.setValue("Z4/2010");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("Sales Org (Mandatory, Multiple Single)");
    criteria.setName("Sales Org (Mandatory, Multiple Single)");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("[YASISORG].[US31]");
    criteriaValue.setValue("Channel");
    criteria.setAllowMultiValues(true);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);
    request.setListOfCriteria(criteriaList);
    RetrieveReportForCriteriaResponseType response = helper.setCriteriaFromRequestAndRetrieveReport(request);
    assertNotNull(response);
  }

    public void testRequestSetVisionReport_MandatoryPromptsNotSet_ExceptionThrown() throws Exception {
        RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
        RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
        request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
        request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
        request.setFormat(OutputFormat.PDF);
        // Report Name: Customer Profile
        request.setDocumentId("Fknvb02q7gQAZAQAAKBrvFoBACToe.hu");

        ListOfCriteria criteriaList = new ListOfCriteria();
        CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();

        criteria.setID("1 Sales Org");
        criteria.setName("1 Sales Org");
        criteria.setPromptType("TEXT");
        criteria.setAllowDiscreteValue(true);
        criteria.setAllowMultiValues(true);
        BoFillPromptValue criteriaValue = new BoFillPromptValue();
        criteriaValue.setRowIndex("[YASISORG].[US31]");
        criteriaValue.setValue("US31");
        criteria.getCriteriaValues().add(criteriaValue);
        criteriaValue = new BoFillPromptValue();
        criteriaValue.setRowIndex("[YASISORG].[US32]");
        criteriaValue.setValue("US32");
        criteria.getCriteriaValues().add(criteriaValue);
        criteriaList.getCriteriaInfoFromRequest().add(criteria);

        request.setListOfCriteria(criteriaList);
        try {
            helper.setCriteriaFromRequestAndRetrieveReport(request);
            fail("This should have thrown an exception");
        } catch (RetrieveReportForCriteriaFault ex) {
            assertEquals("Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : " +
                        "The required prompts are not set in the criteria for this report", ex.getMessage().trim());
        }
    }

  public void testRequestForApollo_DestroyedMaterialReport() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    // Report Name: Destroyed Material Report
    request.setDocumentId("Fl8kkUwCfgMAn3oAAKArrFoBACToe.hu");
    request.setFormat(OutputFormat.PDF);

    ListOfCriteria criteriaList = new ListOfCriteria();
    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("Enter value(s) for Program ID:");
    criteria.setName("Enter value(s) for Program ID:");
    criteria.setPromptType("NUMERIC");
    criteria.setAllowMultiValues(true);
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setValue("360972288");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    request.setListOfCriteria(criteriaList);
    try {
        helper.setCriteriaFromRequestAndRetrieveReport(request);
        System.out.println("");
    } catch (RetrieveReportForCriteriaFault ex) {
      assertEquals(
          "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : The number of prompts specified in the request does not match the number of prompts in the report.",
          ex.getMessage().trim());
    }

  }

  public void testRequestForApollo_ProtocolDetailReport() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("FgNkiky.MAsArUIAAKBbKlsBACToe.hu");
    request.setFormat(OutputFormat.PDF);

    ListOfCriteria criteriaList = new ListOfCriteria();
    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("{?ProtocolId}");
    criteria.setName("ProtocolId");
    criteria.setPromptType("NUMERIC");
    criteria.setAllowMultiValues(true);
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setValue("27");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    request.setListOfCriteria(criteriaList);
    try {
      helper.setCriteriaFromRequestAndRetrieveReport(request);
    } catch (RetrieveReportForCriteriaFault ex) {
     // Assert.assertEquals(
       //   "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : The number of prompts specified in the request does not match the number of prompts in the report.",
         // ex.getMessage().trim());
    }

  }
public void testRequestForApollo_PlantingSheetReport() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("FnF2t0xY_wEAuDIAAKArjFoBACToe.hu");
    request.setFormat(OutputFormat.PDF);

    ListOfCriteria criteriaList = new ListOfCriteria();
    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("{?Prompt_NSFTO3456390251}");
    criteria.setName("Prompt_NSFTO3456390251");
    criteria.setPromptType("NUMERIC");
    criteria.setAllowMultiValues(true);
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setValue("6226441");
    criteria.getCriteriaValues().add(criteriaValue);
  criteriaList.getCriteriaInfoFromRequest().add(criteria);

    CriteriaInfoFromRequest criteria1 = new CriteriaInfoFromRequest();
    criteria.setID("{?MinPlotNumberForEntry_Query_Prompt1}");
    criteria.setName("{?MinPlotNumberForEntry_Query_Prompt1}");
    criteria.setPromptType("NUMERIC");
    criteria.setAllowMultiValues(true);
    criteria.setAllowDiscreteValue(true);
   BoFillPromptValue  criteriaValue1 = new BoFillPromptValue();
    criteriaValue1.setValue("12345");
    criteria1.getCriteriaValues().add(criteriaValue1);

    criteriaList.getCriteriaInfoFromRequest().add(criteria1);

    request.setListOfCriteria(criteriaList);
    try {
      helper.setCriteriaFromRequestAndRetrieveReport(request);
    } catch (RetrieveReportForCriteriaFault ex) {
//      assertEquals(
//          "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : The required prompts are not set in the criteria for this report",
//          ex.getMessage().trim());
    }

  }
  
   public void testRequestSetVisionReportCrystalReport_MandatoryPromptsSet_ReportRetrieved() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
    request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
    request.setFormat(OutputFormat.PDF);
    // Report Name: Fall Financing Report
    request.setDocumentId("FspYUEySKgIABz8AAKB7wlsBACToe.hu");

    ListOfCriteria criteriaList = new ListOfCriteria();

    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("{?[YGDEAL]}");
    criteria.setName("[YGDEAL]");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setValue("null");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("{?[YG_YARGROWR_SEL_OPT]}");
    criteria.setName("[YG_YARGROWR_SEL_OPT]");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setValue("null");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("{?[YGARDSM]}");
    criteria.setName("[YGARDSM]");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteria.setAllowMultiValues(true);
    criteriaValue.setValue("null");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);
    request.setListOfCriteria(criteriaList);
    RetrieveReportForCriteriaResponseType response = helper.setCriteriaFromRequestAndRetrieveReport(request);
    assertNotNull(response);
  }

  public void testRequestSetVisionReportCrystalReport_MandatoryPromptsSet_OneOfTheValueIsNullReportRetrieved() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
    request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
    // Report Name: Customer Attrition Analysis
    request.setDocumentId("Fiyif0xhWQwAOlwAAKBbmFoBACToe.kW");
    request.setFormat(OutputFormat.PDF);

    ListOfCriteria criteriaList = new ListOfCriteria();

    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID(" 1 Sales Org");
    criteria.setName(" 1 Sales Org");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("[YASISORG].[US31]");
    criteriaValue.setValue("Channel");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID(" 8 Sales Year");
    criteria.setName(" 8 Sales Year");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteria.setAllowMultiValues(true);
    criteriaValue.setRowIndex("[0FISCYEAR].[Z42011]");
    criteriaValue.setValue("Z4/2011");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID(" 9 As of Date");
    criteria.setName(" 9 As of Date");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteria.setAllowMultiValues(true);
    criteriaValue.setValue("01/07/2011 04:47:31 PM");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("As Is Date (Single Value)");
    criteria.setName("As Is Date (Single Value)");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteria.setAllowMultiValues(true);
    criteriaValue.setValue("01/07/2011 04:47:31 PM");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("Sales Org (Mandatory, Multiple Single)");
    criteria.setName("Sales Org (Mandatory, Multiple Single)");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("[YASISORG].[US31]");
    criteriaValue.setValue("Channel");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    request.setListOfCriteria(criteriaList);
    RetrieveReportForCriteriaResponseType response = helper.setCriteriaFromRequestAndRetrieveReport(request);
    assertNotNull(response);
  }

  public void testRequestSetVisionReportCustomerAttritionAnalysisReport_MandatoryPromptsSet_OneOfTheValueIsNullReportRetrieved() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
    request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
    // Report Name: Customer Attrition Analysis
    request.setDocumentId("Fiyif0xhWQwAOlwAAKBbmFoBACToe.kW");
    request.setFormat(OutputFormat.PDF);

    ListOfCriteria criteriaList = new ListOfCriteria();

    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("{?[YGDEAL]}");
    criteria.setName("[YGDEAL]");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setValue("0003166451");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("{?[YGGROW]}");
    criteria.setName("[YGGROW]");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setValue("null");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("{?[YGARDSM]}");
    criteria.setName("[YGARDSM]");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteria.setAllowMultiValues(true);
    criteriaValue.setValue("L1O");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("As Is Date (Single Value)");
    criteria.setName("As Is Date (Single Value)");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteria.setAllowMultiValues(true);
    criteriaValue.setValue("01/07/2011 04:47:31 PM");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    criteria = new CriteriaInfoFromRequest();
    criteria.setID("Sales Org (Mandatory, Multiple Single)");
    criteria.setName("Sales Org (Mandatory, Multiple Single)");
    criteria.setPromptType("TEXT");
    criteria.setAllowDiscreteValue(true);
    criteriaValue = new BoFillPromptValue();
    criteriaValue.setRowIndex("[YASISORG].[US31]");
    criteriaValue.setValue("Channel");
    criteria.setAllowMultiValues(false);
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    request.setListOfCriteria(criteriaList);
    RetrieveReportForCriteriaResponseType response = helper.setCriteriaFromRequestAndRetrieveReport(request);
    assertNotNull(response);
  }


   public void testRequestForApollo_ProtocolDetailReport_ExcelFormat() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("FoI9yU0m4wgAQicAAKBr31oBACToe.hu");
    request.setFormat(OutputFormat.XLS);

    ListOfCriteria criteriaList = new ListOfCriteria();
    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("Enter Protocol Id in Test Set:");
    criteria.setName("Enter Protocol Id in Test Set:");
    criteria.setPromptType("NUMERIC");
    criteria.setAllowMultiValues(true);
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setValue("584707401777152");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    request.setListOfCriteria(criteriaList);
    try {
      helper.setCriteriaFromRequestAndRetrieveReport(request);
    } catch (RetrieveReportForCriteriaFault ex) {
      assertEquals(
          "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : The number of prompts specified in the request does not match the number of prompts in the report.",
          ex.getMessage().trim());
    }

  }

   public void testRequestForApollo_ProtocolDetailReport_PDFlFormat() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("FoI9yU0m4wgAQicAAKBr31oBACToe.hu");
    request.setFormat(OutputFormat.PDF);

    ListOfCriteria criteriaList = new ListOfCriteria();
    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("Enter Protocol Id in Test Set:");
    criteria.setName("Enter Protocol Id in Test Set:");
    criteria.setPromptType("NUMERIC");
    criteria.setAllowMultiValues(true);
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setValue("584707401777152");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    request.setListOfCriteria(criteriaList);
    try {
      helper.setCriteriaFromRequestAndRetrieveReport(request);
    } catch (RetrieveReportForCriteriaFault ex) {
      assertEquals(
          "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : The number of prompts specified in the request does not match the number of prompts in the report.",
          ex.getMessage().trim());
    }

  }


   public void testRequestForApollo_ProtocolDetailReportIssuesWithProdVersion_PDFlFormat() throws Exception {
    RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
    RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
    request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
    request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
    request.setDocumentId("Fm4gwE3IaQcAEXYAAKBL5FoBACToe.hu");
    request.setFormat(OutputFormat.PDF);

    ListOfCriteria criteriaList = new ListOfCriteria();
    CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
    criteria.setID("Enter Protocol ID:");
    criteria.setName("Enter Protocol ID:");
    criteria.setPromptType("NUMERIC");
    criteria.setAllowMultiValues(false);
    criteria.setAllowDiscreteValue(true);
    BoFillPromptValue criteriaValue = new BoFillPromptValue();
    criteriaValue.setValue("612039339671552");
    criteria.getCriteriaValues().add(criteriaValue);
    criteriaList.getCriteriaInfoFromRequest().add(criteria);

    request.setListOfCriteria(criteriaList);
    try {
      helper.setCriteriaFromRequestAndRetrieveReport(request);
    } catch (RetrieveReportForCriteriaFault ex) {
      assertEquals(
          "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : The number of prompts specified in the request does not match the number of prompts in the report.",
          ex.getMessage().trim());
    }

  }

    public void testRequestForApollo_ProtocolDetailReportIssuesWithProdVersion_PDF2Format() throws Exception {
        RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
        RetrieveReportForCriteriaHelper helper = new RetrieveReportForCriteriaHelper();
        request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
        request.setDocumentId("Fm4gwE3IaQcAEXYAAKBL5FoBACToe.hu");
        request.setFormat(OutputFormat.PDF);

        ListOfCriteria criteriaList = new ListOfCriteria();
        CriteriaInfoFromRequest criteria = new CriteriaInfoFromRequest();
        criteria.setID("Enter Protocol ID:");
        criteria.setName("Enter Protocol ID:");
        criteria.setPromptType("NUMERIC");
        criteria.setAllowMultiValues(false);
        criteria.setAllowDiscreteValue(true);
        BoFillPromptValue criteriaValue = new BoFillPromptValue();
        criteriaValue.setValue("689452111101953");
        criteria.getCriteriaValues().add(criteriaValue);
        criteriaList.getCriteriaInfoFromRequest().add(criteria);

        request.setListOfCriteria(criteriaList);
        try {
          helper.setCriteriaFromRequestAndRetrieveReport(request);
        } catch (RetrieveReportForCriteriaFault ex) {
          assertEquals(
              "Error occurred during operation: setCriteriaFromRequestAndRetrieveReport : The number of prompts specified in the request does not match the number of prompts in the report.",
              ex.getMessage().trim());
        }

      }

}