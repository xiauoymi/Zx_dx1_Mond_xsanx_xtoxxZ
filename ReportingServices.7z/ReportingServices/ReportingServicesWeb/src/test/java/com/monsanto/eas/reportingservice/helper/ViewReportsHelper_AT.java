/*
 ViewReportsHelper_AT was created on May 10, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.helper;

import com.crystaldecisions.sdk.occa.infostore.IInfoObject;
import com.monsanto.eas.reportingservice.reportingengine.ConnectionObjectBO;
import com.monsanto.eas.reportingservice.schema.RetrieveReportRequestType;
import com.monsanto.eas.reportingservice.schema.RetrieveReportResponseType;
import com.monsanto.eas.reportingservice.schema.BoDocument;
import com.monsanto.eas.reportingservice.service.ViewReportsFault;
import com.monsanto.eas.reportingservice.uat.ReportingServiceTestUtil;
import junit.framework.TestCase;

import java.util.List;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class ViewReportsHelper_AT extends TestCase {

    public void testRetrieveListOfReportsForARole_RequestNotSet_ThrowsException() throws Exception {
        RetrieveReportRequestType request = new RetrieveReportRequestType();
        ViewReportsHelper helper = new ViewReportsHelper();
        try {
            helper.getReports(request);
        } catch (Exception e) {
            assertEquals("Error occurred during operation: getReports : Received in-complete RetrieveReportsRequest object", e.getMessage());
        }
    }

    public void testViewListOfReportsForARole_Success() throws Exception {
        RetrieveReportRequestType request = new RetrieveReportRequestType();
        request.setRoleName(ReportingServiceTestUtil.SRP_ROLE_NAME);
        request.setApplicationName(ReportingServiceTestUtil.SRP_APPLICATION_NAME);
        request.setPathToFolder(ReportingServiceTestUtil.SRP_PATH_FOLDER);
        ViewReportsHelper helper = new ViewReportsHelper();
        RetrieveReportResponseType response = helper.getReports(request);
        assertNotNull(response);
        assertTrue(1 <= response.getBoDocument().size());
    }

    public void testIncorrectPath_ExceptionThrown() throws Exception {
        RetrieveReportRequestType request = new RetrieveReportRequestType();
        String path = "InvalidPath";
        request.setRoleName(ReportingServiceTestUtil.SRP_ROLE_NAME);
        request.setApplicationName(ReportingServiceTestUtil.SRP_APPLICATION_NAME);
        request.setPathToFolder(path);
        ViewReportsHelper helper = new ViewReportsHelper();
        try {
            helper.getReports(request);
            fail("this should fail");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("The path node '" + path + "' does not exist in the repository"));
        }
    }

    public void testIncorrectPath_ViewReportsFaultThrown() throws Exception {
        RetrieveReportRequestType request = new RetrieveReportRequestType();
        String path = "InvalidPath";
        request.setRoleName(ReportingServiceTestUtil.SRP_ROLE_NAME);
        request.setApplicationName(ReportingServiceTestUtil.SRP_APPLICATION_NAME);
        request.setPathToFolder(path);
        ViewReportsHelper helper = new ViewReportsHelper();
        try {
            helper.getReports(request);
            fail("this should fail");
        } catch (ViewReportsFault e) {
            assertTrue(e.getMessage().contains("The path node '" + path + "' does not exist in the repository"));
        }
    }

    public void testGetDocumentsFromFolder_Success() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        List<IInfoObject> infoObjectDocuments = ViewReportsHelper.getDocumentsFromFolder(ReportingServiceTestUtil.APOLLO_PATH_FOLDER, boConnector.getInfoStore());
        assertNotNull(infoObjectDocuments);
        assertTrue(!infoObjectDocuments.isEmpty());
    }


    public void testGetDocumentsFromFolder_ExceptionThrown() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String pathFolder = "InvalidPath";
        try {
            ViewReportsHelper.getDocumentsFromFolder(pathFolder, boConnector.getInfoStore());
            fail("this should fail");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("The path node '" + pathFolder + "' does not exist in the repository"));
        }
    }

    public void testObtainDocumentsSuccess() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String pathFolder = ReportingServiceTestUtil.APOLLO_PATH_FOLDER;
        String queryString = ViewReportsHelper.DEFAULT_PATH_TO_INFOPATH_FOLDER + pathFolder + ViewReportsHelper.PATH_SEARCH_CRITERIA + ViewReportsHelper.FIELDS_INCLUDED;
        List<IInfoObject> infoObjectDocuments = ViewReportsHelper.obtainDocuments(queryString, boConnector.getInfoStore());
        assertNotNull(infoObjectDocuments);
        assertTrue(!infoObjectDocuments.isEmpty());
    }

    public void testViewListOfReportsForARole_RequestIsValid_ResponseIsSet() throws Exception {
        RetrieveReportRequestType request = new RetrieveReportRequestType();
        request.setRoleName(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        request.setApplicationName(ReportingServiceTestUtil.APOLLO_APPLICATION_NAME);
        request.setPathToFolder(ReportingServiceTestUtil.APOLLO_PATH_FOLDER);
        ViewReportsHelper helper = new ViewReportsHelper();
        RetrieveReportResponseType response = helper.getReports(request);
        assertNotNull(response);
        assertTrue(1 <= response.getBoDocument().size());
        boolean webiReportFound = false;
        for (BoDocument document : response.getBoDocument()) {
            if(document.getKind().equalsIgnoreCase("Webi")){
                webiReportFound = true;
            }
        }
        assertTrue("Webi report found", webiReportFound);
    }

    public void testViewListOfCrystalReportsForARole_RequestIsValid_ResponseIsSet() throws Exception {
        RetrieveReportRequestType request = new RetrieveReportRequestType();
        request.setRoleName(ReportingServiceTestUtil.VISION_ROLE_NAME);
        request.setApplicationName(ReportingServiceTestUtil.VISION_APPLICATION_NAME);
        request.setPathToFolder(ReportingServiceTestUtil.VISION_AR_PATH_FOLDER);
        ViewReportsHelper helper = new ViewReportsHelper();
        RetrieveReportResponseType response = helper.getReports(request);

        assertNotNull(response);
        assertTrue(1 <= response.getBoDocument().size());
        boolean crystalReportFound = false;
        for (BoDocument document : response.getBoDocument()) {
            if(document.getKind().equalsIgnoreCase("CrystalReport")){
                crystalReportFound = true;
            }
        }

        assertTrue("Crystal report found", crystalReportFound);
    }

}