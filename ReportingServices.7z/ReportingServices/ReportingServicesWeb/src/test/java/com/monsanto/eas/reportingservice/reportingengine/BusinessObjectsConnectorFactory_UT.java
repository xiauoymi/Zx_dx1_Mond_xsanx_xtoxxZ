package com.monsanto.eas.reportingservice.reportingengine;

import com.monsanto.eas.reportingservice.helper.ReportEngineConnectionHelper;
import com.monsanto.eas.reportingservice.uat.ReportingServiceTestUtil;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: JHERN10
 * Date: 5/31/13
 * Time: 9:06 AM
 * To change this template use File | Settings | File Templates.
 */
public class BusinessObjectsConnectorFactory_UT {

    @Test
    public void testGetCMSConnection_Success() throws Exception {
        String roleName = ReportingServiceTestUtil.APOLLO_ROLE_NAME;
        BusinessObjectsConnectorFactory boConnectorFactory = new BusinessObjectsConnectorFactory();
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(roleName);
        boConnectorFactory.getCMSConnection(boConnector.getCmsName(), boConnector.getUserId(), boConnector.getPassword());
        assertNotNull(boConnectorFactory);
    }

    @Test
    public void testIncorrectCMSName_ExceptionThrown() throws Exception {
        String roleName = ReportingServiceTestUtil.APOLLO_ROLE_NAME;
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(roleName);
        String cmsName = "cmsName:7001";
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        BusinessObjectsConnectorFactory boConnectorFactory = new BusinessObjectsConnectorFactory();
        try {
            boConnectorFactory.getCMSConnection(cmsName, userName, password);
            fail("this should fail");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("not found or server may be down"));
        }
    }

    @Test
    public void testIncorrectUserName_ExceptionThrown() throws Exception {
        String roleName = ReportingServiceTestUtil.APOLLO_ROLE_NAME;
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(roleName);
        String cmsName = boConnector.getCmsName();
        String userName = "InvalidUser";
        String password = boConnector.getPassword();
        BusinessObjectsConnectorFactory boConnectorFactory = new BusinessObjectsConnectorFactory();
        try {
            boConnectorFactory.getCMSConnection(cmsName, userName, password);
            fail("this should fail");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("Invalid username or password"));
        }
    }

    @Test
    public void testIncorrectPassword_ExceptionThrown() throws Exception {
        String roleName = ReportingServiceTestUtil.APOLLO_ROLE_NAME;
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(roleName);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = "InvalidPassword";
        BusinessObjectsConnectorFactory boConnectorFactory = new BusinessObjectsConnectorFactory();
        try {
            boConnectorFactory.getCMSConnection(cmsName, userName, password);
            fail("this should fail");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("Invalid username or password"));
        }
    }

}
