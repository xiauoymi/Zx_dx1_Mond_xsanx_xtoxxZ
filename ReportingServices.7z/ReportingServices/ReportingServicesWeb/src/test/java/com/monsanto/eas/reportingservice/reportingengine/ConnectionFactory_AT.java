/*
 ReportingEngineConnectionFactory_UT was created on Mar 31, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.reportingengine;

import com.monsanto.eas.reportingservice.helper.ReportEngineConnectionHelper;
import com.monsanto.eas.reportingservice.uat.ReportingServiceTestUtil;
import junit.framework.TestCase;


/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class ConnectionFactory_AT extends TestCase {

    private ConnectionFactory reportEngineInstance;

    public void testInstantiateNewBOConnectionFromTheFactory_ObjectCreated() throws Exception {
        String reportingEngineType = ConnectionFactory.BUSINESS_OBJECTS;
        String roleName = ReportingServiceTestUtil.APOLLO_ROLE_NAME;

        BusinessObjectsConnectorFactory boFactoryInstance =
                (BusinessObjectsConnectorFactory) ConnectionFactory.getReportingEngineConnectionFactory(reportingEngineType);
        assertNotNull(boFactoryInstance);

        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(roleName);
        ConnectionObjectBO cmsConnection = boFactoryInstance.getCMSConnection(boConnector.getCmsName(), boConnector.getUserId(), boConnector.getPassword());
        assertNotNull(cmsConnection);
    }

    public void testInstantiateNewBOConnectionFromTheFactory_NotExists() throws Exception {
        String reportingEngineType = "InvalidReportEngine";
        ConnectionFactory boFactoryInstance =
                ConnectionFactory.getReportingEngineConnectionFactory(reportingEngineType);
        assertNull(boFactoryInstance);
    }

    public void testInstantiateNewCrystalReportsConnectionFromTheFactory_ObjectIsNull() throws Exception {
        String REPORTING_ENGINE_TYPE = "CRYSTAL_REPORTS";
        reportEngineInstance = ConnectionFactory.getReportingEngineConnectionFactory(REPORTING_ENGINE_TYPE);
        assertNull(reportEngineInstance);
    }

}