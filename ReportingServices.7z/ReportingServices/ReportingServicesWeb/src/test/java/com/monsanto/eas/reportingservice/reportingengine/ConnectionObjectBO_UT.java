package com.monsanto.eas.reportingservice.reportingengine;

import com.monsanto.eas.reportingservice.helper.ReportEngineConnectionHelper;
import com.monsanto.eas.reportingservice.uat.ReportingServiceTestUtil;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: JHERN10
 * Date: 5/31/13
 * Time: 10:41 AM
 * To change this template use File | Settings | File Templates.
 */
public class ConnectionObjectBO_UT {

    @Test
    public void testGetSession() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        connectionObjectBO4.logon();
        assertNotNull(connectionObjectBO4.getSession());
    }

    @Test
    public void testSessionNotSet() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        assertNull(connectionObjectBO4.getSession());
    }

    @Test
    public void testLogon() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        assertNull(connectionObjectBO4.getSession());
        connectionObjectBO4.logon();
        assertNotNull(connectionObjectBO4.getSession());
    }

    @Test
    public void testLogonSessionExists() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        assertNull(connectionObjectBO4.getSession());
        connectionObjectBO4.logon();
        assertNotNull(connectionObjectBO4.getSession());
        connectionObjectBO4.logon();
        assertNotNull(connectionObjectBO4.getSession());
    }

    @Test
    public void testInvalidLogon_ExceptionThrown() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = "InvalidUser";
        String password = boConnector.getUserId();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        assertNull(connectionObjectBO4.getSession());
        try {
            connectionObjectBO4.logon();
            fail("this should fail");
        } catch (Exception e) {
            assertTrue(e.getMessage().contains("Invalid username or password"));
        }
    }

    @Test
    public void testLogout() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        assertNull(connectionObjectBO4.getSession());
        connectionObjectBO4.logon();
        assertNotNull(connectionObjectBO4.getSession());
        connectionObjectBO4.logout();
    }

    @Test
    public void testLogoutSessionNotExists() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        assertNull(connectionObjectBO4.getSession());
        connectionObjectBO4.logout();
        assertNull(connectionObjectBO4.getSession());
    }

    @Test
    public void testReportEngine() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        connectionObjectBO4.logon();
        assertNotNull(connectionObjectBO4.getReportEngine());
    }

    @Test
    public void testInfoStore() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        connectionObjectBO4.logon();
        assertNotNull(connectionObjectBO4.getInfoStore());
    }

    @Test
    public void testReportEngineNotSet() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        assertNull(connectionObjectBO4.getReportEngine());
    }

    @Test
    public void testInfoStoreNotSet() throws Exception {
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(ReportingServiceTestUtil.APOLLO_ROLE_NAME);
        String cmsName = boConnector.getCmsName();
        String userName = boConnector.getUserId();
        String password = boConnector.getPassword();
        ConnectionObjectBO connectionObjectBO4 = new ConnectionObjectBO(cmsName, userName, password, BOConstants.LDAP_SECURITY);
        assertNull(connectionObjectBO4.getInfoStore());
    }

}
