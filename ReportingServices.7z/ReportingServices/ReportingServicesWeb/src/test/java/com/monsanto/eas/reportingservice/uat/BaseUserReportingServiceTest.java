package com.monsanto.eas.reportingservice.uat;

import com.monsanto.eas.reportingservice.schema.RetrieveReportRequestType;
import com.monsanto.eas.reportingservice.schema.RetrieveReportResponseType;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.OutputFormat;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.RetrieveDocumentRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveDocument.RetrieveDocumentResponseType;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.RetrieveListOfCriteriaRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.RetrieveListOfCriteriaResponseType;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.RetrieveReportForCriteriaRequestType;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.RetrieveReportForCriteriaResponseType;
import com.monsanto.eas.reportingservice.service.*;
import com.monsanto.eas.reportingservice.service.impl.RetrieveDocumentServiceImpl;
import com.monsanto.eas.reportingservice.service.impl.RetrieveListOfCriteriaForDocumentServiceImpl;
import com.monsanto.eas.reportingservice.service.impl.RetrieveReportForCriteriaServiceImpl;
import com.monsanto.eas.reportingservice.service.impl.ViewReportsServiceImpl;
import org.apache.log4j.Logger;
import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.InvocationTargetException;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

/**
 * Created by IntelliJ IDEA.
 * User: PKGUND
 * Date: Mar 21, 2012
 * Time: 2:47:14 PM
 */
public abstract class BaseUserReportingServiceTest {
    private Logger log = Logger.getLogger(this.getClass());
    RetrieveDocumentService retrieveDocumentService;
    ViewReportsService viewReportsService;
    RetrieveListOfCriteriaForDocumentService retrieveListOfCriteriaForDocumentService;
    RetrieveReportForCriteriaService retrieveReportForCriteriaService;

    @Before
    public void setUp(){
        retrieveDocumentService = new RetrieveDocumentServiceImpl();
        viewReportsService =  new ViewReportsServiceImpl();
        retrieveListOfCriteriaForDocumentService = new RetrieveListOfCriteriaForDocumentServiceImpl();
        retrieveReportForCriteriaService = new RetrieveReportForCriteriaServiceImpl();
    }

    @Test
    public void testViewListOfReportsForARole() throws Exception {
        RetrieveReportRequestType request = new RetrieveReportRequestType();
        request.setRoleName(getRoleName());
        request.setApplicationName(getApplicationName());
        request.setPathToFolder(getPathToFolder());

        RetrieveReportResponseType response = viewReportsService.getReports(request);

        assertNotNull(response);
        assertTrue(response.getBoDocument().size() > 0);

        String docId = response.getBoDocument().get(0).getId();
        ReportingServiceTestUtil.getDocIds().clear();
        ReportingServiceTestUtil.getDocIds().add(docId);
        log.info("Document ID:" + docId);
        log.info("Document Description:" + response.getBoDocument().get(0).getDescription());
    }

    @Test
    public void testRetrieveDocument() throws RetrieveDocumentFault {
        String docId = ReportingServiceTestUtil.getDocIds().get(0);
        OutputFormat outputFormat = OutputFormat.PDF;
        RetrieveDocumentRequestType request = new RetrieveDocumentRequestType();
        request.setRoleName(getRoleName());
        request.setApplicationName(getApplicationName());
        request.setDocumentId(docId);
        request.setFormat(outputFormat);
        RetrieveDocumentResponseType response = retrieveDocumentService.retrieveDocument(request);

        assertNotNull(response);
        assertNotNull(response.getDocumentDetails());

        log.info("Document UID:" + response.getDocumentDetails().getUID());
    }

    @Test
    public void testRetrieveListOfCriteria() throws RetrieveCriteriaForDocumentFault {
        String docId = ReportingServiceTestUtil.getDocIds().get(0);
        RetrieveListOfCriteriaRequestType request = new RetrieveListOfCriteriaRequestType();
        request.setApplicationName(getApplicationName());
        request.setDocumentId(docId);
        request.setRoleName(getRoleName());

        RetrieveListOfCriteriaResponseType response = retrieveListOfCriteriaForDocumentService.retrieveListOfCriteriaForDocument(request);

        assertNotNull(response);

        ReportingServiceTestUtil.getCriteriaInfoList().clear();        
        ReportingServiceTestUtil.getCriteriaInfoList().addAll(response.getCriteriaInfo());

        log.info("Criteria found:" + response.getCriteriaInfo().size());
    }

    @Test
    public void testRetrieveReportForCriteria() throws RetrieveCriteriaForDocumentFault, InvocationTargetException, IllegalAccessException, RetrieveReportForCriteriaFault {
        String docId = ReportingServiceTestUtil.getDocIds().get(0);
        RetrieveReportForCriteriaRequestType request = new RetrieveReportForCriteriaRequestType();
        request.setApplicationName(getApplicationName());
        request.setDocumentId(docId);
        request.setRoleName(getRoleName());
        com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.OutputFormat outputFormat = com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.OutputFormat.PDF;
        request.setFormat(outputFormat);
        request.setListOfCriteria(ReportingServiceTestUtil.transformCriteriaInfoListToListOfCriteria());
        RetrieveReportForCriteriaResponseType response = retrieveReportForCriteriaService.retrieveReportForCriteria(request);
        assertNotNull(response);
        assertNotNull(response.getNewDocument());

        log.info("Document UID:" + response.getNewDocument().getUID());

    }


    protected abstract String getPathToFolder();

    protected abstract String getApplicationName();

    protected abstract String getRoleName();
}
