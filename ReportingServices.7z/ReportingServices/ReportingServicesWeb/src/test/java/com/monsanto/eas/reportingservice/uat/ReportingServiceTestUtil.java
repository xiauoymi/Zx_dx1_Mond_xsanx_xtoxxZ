package com.monsanto.eas.reportingservice.uat;


import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.BoPromptValue;
import com.monsanto.eas.reportingservice.schema.retrieveListOfCriteria.CriteriaInfo;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.BoFillPromptValue;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.CriteriaInfoFromRequest;
import com.monsanto.eas.reportingservice.schema.retrieveReportForCriteria.ListOfCriteria;
import org.apache.commons.beanutils.BeanUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
/**
 * Created by IntelliJ IDEA.
 * User: PKGUND
 * Date: Mar 21, 2012
 * Time: 1:47:04 PM
 */
public class ReportingServiceTestUtil {

    private static List<String> docIds = new ArrayList<String>();
    private static List<CriteriaInfo> criteriaInfoList = new ArrayList<CriteriaInfo>();

    public final static String APOLLO_ROLE_NAME = "BO-APOLLO";
    public final static String APOLLO_APPLICATION_NAME = "APOLLO";
    public final static String APOLLO_PATH_FOLDER = "US/TPS/Field Testing/Apollo";
    public final static String APOLLO_SPRAY_SHEET_DOCUMENT_UID = "Fp3EBE7ibgAAPF8AAKA78VoCACToe.kW";
    public final static String SRP_ROLE_NAME = "BO-SRP";
    public final static String SRP_APPLICATION_NAME = "SRP";
    public final static String SRP_PATH_FOLDER = "Canada/JRS";
    public final static String VISION_ROLE_NAME = "BO-VISION";
    public final static String VISION_APPLICATION_NAME = "VISION";
    public final static String VISION_AR_PATH_FOLDER = "US/USST/Channel\\/Regional Brands Reporting/AR Reports";

    public static List<CriteriaInfo> getCriteriaInfoList() {
        return criteriaInfoList;
    }

    public static List<String> getDocIds() {
        return docIds;
    }

    public static ListOfCriteria transformCriteriaInfoListToListOfCriteria() throws InvocationTargetException, IllegalAccessException {
        ListOfCriteria listOfCriteria = new ListOfCriteria();
        List<CriteriaInfoFromRequest>  criteriaInfoFromRequestList = new ArrayList<CriteriaInfoFromRequest>();
        for(CriteriaInfo criteriaInfo : criteriaInfoList){
            CriteriaInfoFromRequest criteriaInfoFromRequest = new CriteriaInfoFromRequest();
            BeanUtils.copyProperties(criteriaInfoFromRequest, criteriaInfo);
            List<BoFillPromptValue> boFillPromptValueList = new ArrayList<BoFillPromptValue>();
            for(BoPromptValue boPromptValue : criteriaInfo.getDefaultValues()){
                BoFillPromptValue boFillPromptValue = new BoFillPromptValue();
                BeanUtils.copyProperties(boFillPromptValue, boFillPromptValue);
                boFillPromptValueList.add(boFillPromptValue);
            }
            criteriaInfoFromRequestList.add(criteriaInfoFromRequest);
        }
        listOfCriteria.getCriteriaInfoFromRequest().addAll(criteriaInfoFromRequestList);
        return listOfCriteria;
    }
}
