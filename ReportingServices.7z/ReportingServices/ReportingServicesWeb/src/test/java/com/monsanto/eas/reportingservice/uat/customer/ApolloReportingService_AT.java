package com.monsanto.eas.reportingservice.uat.customer;

import com.monsanto.eas.reportingservice.uat.BaseUserReportingServiceTest;

/**
 * Created by IntelliJ IDEA.
 * User: PKGUND
 * Date: Mar 21, 2012
 * Time: 10:13:59 AM
 */
public class ApolloReportingService_AT extends BaseUserReportingServiceTest {

    @Override
    protected String getPathToFolder() {
        return "US/TPS/Field Testing/Apollo";
    }

    @Override
    protected String getApplicationName() {
        return "APOLLO";
    }

    @Override
    protected String getRoleName() {
        return "BO-APOLLO";
    }

}
