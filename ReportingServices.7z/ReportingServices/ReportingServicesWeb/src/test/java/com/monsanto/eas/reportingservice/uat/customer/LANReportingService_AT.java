package com.monsanto.eas.reportingservice.uat.customer;

import com.monsanto.eas.reportingservice.uat.BaseUserReportingServiceTest;

public class LANReportingService_AT extends BaseUserReportingServiceTest{
    @Override
    protected String getPathToFolder() {
        //return "US/USST/Channel\\/Regional Brands Reporting";
        return "LAN/Customer Link";
    }

    @Override
    protected String getApplicationName() {
        return "LAN";
    }

    @Override
    protected String getRoleName() {
        return "BO-LAN";
    }
}
