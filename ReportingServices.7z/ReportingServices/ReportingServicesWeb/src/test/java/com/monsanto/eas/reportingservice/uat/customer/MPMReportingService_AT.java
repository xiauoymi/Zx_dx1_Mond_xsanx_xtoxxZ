package com.monsanto.eas.reportingservice.uat.customer;

import com.monsanto.eas.reportingservice.uat.BaseUserReportingServiceTest;

public class MPMReportingService_AT extends BaseUserReportingServiceTest {

    @Override
    protected String getPathToFolder() {
        return "US/USST/MPM";
    }

    @Override
    protected String getApplicationName() {
        return "MPM";
    }

    @Override
    protected String getRoleName() {
        return "BO-MPM";
    }
}