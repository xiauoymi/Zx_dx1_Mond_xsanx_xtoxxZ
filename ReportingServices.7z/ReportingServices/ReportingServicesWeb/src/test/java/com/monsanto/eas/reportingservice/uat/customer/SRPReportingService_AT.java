package com.monsanto.eas.reportingservice.uat.customer;

import com.monsanto.eas.reportingservice.uat.BaseUserReportingServiceTest;


public class SRPReportingService_AT extends BaseUserReportingServiceTest {

    @Override
    protected String getPathToFolder() {
        return "Canada/JRS";
    }

    @Override
    protected String getApplicationName() {
        return "SRP";
    }

    @Override
    protected String getRoleName() {
        return "BO-SRP";
    }
}
