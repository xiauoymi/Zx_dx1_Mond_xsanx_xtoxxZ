package com.monsanto.eas.reportingservice.uat.customer;

import com.monsanto.eas.reportingservice.uat.BaseUserReportingServiceTest;

public class USSalesForceReportingService_AT extends BaseUserReportingServiceTest{
    @Override
    protected String getPathToFolder() {
        return "US/USST/Ascend Reporting/Four Year History";
    }

    @Override
    protected String getApplicationName() {
        return "USSF";
    }

    @Override
    protected String getRoleName() {
        return "BO-USSF";
    }
}
