package com.monsanto.eas.reportingservice.uat.customer;

import com.monsanto.eas.reportingservice.uat.BaseUserReportingServiceTest;

public class VisionReportingService_AT extends BaseUserReportingServiceTest{
    @Override
    protected String getPathToFolder() {
        //return "US/USST/Channel\\/Regional Brands Reporting";
        return "US/USST/Channel\\/Regional Brands Reporting/OTC Reports/Separation of Duties";
    }

    @Override
    protected String getApplicationName() {
        return "VISION";
    }

    @Override
    protected String getRoleName() {
        return "BO-VISION";  
    }
}
