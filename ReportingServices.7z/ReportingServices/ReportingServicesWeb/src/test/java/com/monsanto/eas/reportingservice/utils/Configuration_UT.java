/*
 Configuration_UT was created on Mar 31, 2010 using Monsanto 
 resources and is the sole property of Monsanto.  Any duplication of the 
 code and/or logic is a direct infringement of Monsanto's copyright.
*/
package com.monsanto.eas.reportingservice.utils;

import com.monsanto.eas.reportingservice.helper.ReportEngineConnectionHelper;
import com.monsanto.eas.reportingservice.reportingengine.ConnectionObjectBO;
import com.monsanto.eas.reportingservice.uat.ReportingServiceTestUtil;
import junit.framework.TestCase;
import com.monsanto.eas.reportingservice.reportingengine.BOConstants;

/**
 * Filename:    $RCSfile$ Label:       $Name$ Last Change: $Author$    	 On:	$Date$
 *
 * @author rrmall
 * @version $Revision$
 */
public class Configuration_UT extends TestCase {
  public Configuration_UT(String name) {
    super(name);
  }

    public void testReadThePropertyFile_ReturnsContent() throws Exception{
        String roleName = ReportingServiceTestUtil.APOLLO_ROLE_NAME;
        ConnectionObjectBO boConnector = ReportEngineConnectionHelper.getCredentialsAndConnection(roleName);
        String cmsName = boConnector.getCmsName();
        Configuration configuration = new Configuration();
        assertEquals(cmsName, configuration.getProperty(BOConstants.CMS_NAME));
    }

}