package com.monsanto.eas.reportingservice.version;

import com.monsanto.eas.reportingservice.version.impl.BuildVersionImpl;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import static org.junit.Assert.*;

/**
 * Created by IntelliJ IDEA.
 * User: JHERN10
 * Date: 5/8/13
 * Time: 2:58 PM
 * To change this template use File | Settings | File Templates.
 */
public class BuildVersion_UT {

    @Test
    public void testResourceNotExistsBuildInfo_ExceptionThrown() throws Exception {
        String wrongPath = "log/version.txt";
        Resource versionResource = new ClassPathResource(wrongPath);
        BuildVersion buildVersion = new BuildVersionImpl(versionResource);
        try {
            buildVersion.setBuildInfo();
            fail("this should fail");
        } catch (Exception e) {
            assertEquals("The source doesn´t exist to obtain the Build Info", e.getMessage());
        }
    }

    @Test
    public void testResourceNullBuildInfo_ExceptionThrown() throws Exception {
        Resource versionResource = null;
        BuildVersion buildVersion = new BuildVersionImpl(versionResource);
        try {
            buildVersion.setBuildInfo();
            fail("this should fail");
        } catch (Exception e) {
            assertEquals("The source doesn´t exist to obtain the Build Info", e.getMessage());
        }
    }

    @Test
    public void testIncorrectNameAttributeBuildInfo_ExceptionThrown() throws Exception {
        String path = "version-incomplete.txt";
        Resource versionResource = new ClassPathResource(path);
        BuildVersion buildVersion = new BuildVersionImpl(versionResource);
        try {
            buildVersion.setBuildInfo();
            fail("this should fail");
        } catch (Exception e) {
            assertEquals("Received in-complete Attributes to obtain the Build Info", e.getMessage());
        }
    }

    @Test
    public void testSetBuildInfo_Success() throws Exception {
        String path = "version.txt";
        Resource versionResource = new ClassPathResource(path);
        BuildVersionImpl buildVersion = new BuildVersionImpl(versionResource);
        buildVersion.setBuildInfo();
        assertNotNull(buildVersion.getBuildDate());
        assertNotNull(buildVersion.getBuildVersion());
    }

    @Test
    public void testLogBuildInfo() throws Exception {
        String path = "version.txt";
        Resource versionResource = new ClassPathResource(path);
        BuildVersionImpl buildVersion = new BuildVersionImpl(versionResource);
        buildVersion.setBuildInfo();
        buildVersion.logBuildInfo();
    }

}
