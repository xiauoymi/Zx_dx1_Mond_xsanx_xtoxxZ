package com.monsanto.eas.reportingservice.version;

import org.junit.Before;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: JHERN10
 * Date: 5/8/13
 * Time: 4:18 PM
 * To change this template use File | Settings | File Templates.
 */
public class ServiceVersion_UT {

    private BuildVersion buildVersion;
    private ServiceVersion serviceVersion;

    @Before
    public void setUp() throws Exception {
        buildVersion = new StubBuildVersion();
        serviceVersion = new ServiceVersion(buildVersion);
    }

    @Test
    public void testPrintVersion() throws Exception {
        // Invoking print version
        serviceVersion.printVersion();
    }

    @Test
    public void testExecuteService() throws Exception {
        // It can´t be tested
        serviceVersion.executeService();
    }

    @Test
    public void testBuildInfoNotFoundPrintVersion() throws Exception {
        serviceVersion = new ServiceVersion(new StubExceptionBuildVersion());
        serviceVersion.printVersion();
    }

    class StubBuildVersion implements BuildVersion {

        public void setBuildInfo() throws Exception {
            // Setting build info
        }

        public void logBuildInfo() {
            // Logging build info
        }
    }

    class StubExceptionBuildVersion implements BuildVersion {

        public void setBuildInfo() throws Exception {
            throw new Exception("Build info not found");
        }

        public void logBuildInfo() {
            // Logging build info
        }
    }

}
