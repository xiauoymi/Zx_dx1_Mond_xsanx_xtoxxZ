package com.monsanto.dctm.jobmethods.agregulatorysops;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.util.*;

public class DocumentStateChange implements IDmMethod {
    private static final String LIFECYCLE_NAME = "Reg SOPs";
    private static final Map attributePromotionAssociations = new HashMap();
    private static final Map attributeSuspensionAssociations = new HashMap();
    private static final Map attributeUpdateWhenSuspended = new HashMap();

    private IDfSessionManager sessionManager;
    private String docbase;
    private String userName;
    private IDfSession session;
    private String password;

    public DocumentStateChange() {
        attributePromotionAssociations.put("Approved", "approved_date");
        attributePromotionAssociations.put("Effective", "effective_date");
        attributePromotionAssociations.put("Retired", "retired_date");
        attributeSuspensionAssociations.put("Superseded", "superseded_sops");
        attributeUpdateWhenSuspended.put("Superseded", "superceded_date");
    }

    public void execute(Map parameters, OutputStream output) throws DfException {
        parseJobParameters(parameters);
        try {
            createSession();
            processDocuments();
        }
        finally {
            releaseSession();
        }
    }

    private void parseJobParameters(Map parameters) {
        if (parameters != null) {
            Iterator i = parameters.keySet().iterator();
            while (i.hasNext()) {
                String key = (String) i.next();
                String[] values = (String[]) parameters.get(key);

                if ((key == null) || (key.length() == 0) || (values == null) || (values.length < 1)) {
                    continue;
                }
                if (key.equalsIgnoreCase("docbase_name")) {
                    docbase = values[0];
                } else if (key.equalsIgnoreCase("user_name")) {
                    userName = values[0];
                } else if (key.equalsIgnoreCase("password")) {
                    password = values[0];
                }
            }
        }
    }

    private void createSession() throws DfException {
        IDfLoginInfo login = new DfLoginInfo();
        if (userName != null && userName.length() > 0) {
            login.setUser(userName);
        }
        if (password != null && password.length() > 0) {
            login.setPassword(password);
        }
        sessionManager = DfClient.getLocalClient().newSessionManager();
        if (docbase != null && docbase.length() > 0) {
            sessionManager.setIdentity(docbase, login);
            session = sessionManager.getSession(docbase);
        }
    }

    private void releaseSession() {
        if (session != null)
            sessionManager.release(session);
    }

    private void processDocuments() throws DfException {
        if (session != null) {
            IDfSysObject lifecycle = (IDfSysObject) session
                    .getObjectByQualification("dm_sysobject where object_name = '" + LIFECYCLE_NAME + "'");
            List stateNamesList = getRepeatingAsList(lifecycle, "state_name");
            Iterator stateNames = stateNamesList.iterator();
            for (int i = 0; stateNames.hasNext(); i++) {
                stateNames.next();
                if (stateNames.hasNext()) {
                    String nextState = stateNamesList.get(i + 1).toString();
                    String suspendState = lifecycle.getRepeatingString("exception_state", i + 1);
                    String qualification = "dm_sysobject where r_policy_id = '" + lifecycle.getObjectId().toString() +
                                           "' and r_current_state = " + i;
                    List documentList = getListByQualification(qualification);
                    Iterator documents = documentList.iterator();
                    while (documents.hasNext()) {
                        IDfSysObject document = (IDfSysObject) documents.next();
                        if (nextState != null && nextState.length() > 0 &&
                            attributePromotionAssociations.containsKey(nextState)) {
                            String promotionAttribute = attributePromotionAssociations.get(nextState).toString();
                            promoteDocument(document, promotionAttribute, suspendState);
                        }
                    }
                }
            }
        }
    }

    private void promoteDocument(IDfSysObject document, String promotionAttribute, String suspendState) throws
                                                                                                        DfException {
        IDfTime today = new DfTime();
        IDfTime promoteDate = document.getTime(promotionAttribute);

        if (promoteDate.isValid() && !promoteDate.isNullDate() && today.compareTo(promoteDate) > -1 &&
            document.getPolicyId() != null && document.getPolicyId().getId() != "0000000000000000") {
            document.promote(null, false, false);

            if (suspendState != null && suspendState.length() > 0 &&
                attributeSuspensionAssociations.containsKey(suspendState)) {
                String suspendAttribute = attributeSuspensionAssociations.get(suspendState).toString();
                String updateAttribute = attributeUpdateWhenSuspended.get(suspendState).toString();
                suspendDocuments(document, suspendAttribute, updateAttribute);
            }
        }
    }

    private void suspendDocuments(IDfSysObject document, String suspendAttribute, String updateAttribute) throws
                                                                                                          DfException {
        Iterator documentsToSuspend = getRepeatingAsList(document, suspendAttribute).iterator();
        while (documentsToSuspend.hasNext()) {
            String documentNameToSuspend = documentsToSuspend.next().toString();
            IDfSysObject documentToSuspend = (IDfSysObject) session
                    .getObjectByQualification("dm_sysobject where object_name = '" + documentNameToSuspend + "'");
            if (documentToSuspend != null) {
                if (documentToSuspend.getPolicyId() != null &&
                    documentToSuspend.getPolicyId().getId() != "0000000000000000")
                    documentToSuspend.suspend(null, false, false);
                if (updateAttribute != null && updateAttribute.length() > 0)
                    updateAttributeToToday(documentToSuspend, updateAttribute);
            }
        }
    }

    private void updateAttributeToToday(IDfSysObject document, String updateAttribute) throws DfException {
        document.setTime(updateAttribute, new DfTime());
        document.save();
    }

    private List getRepeatingAsList(IDfSysObject sysObject, String attribute) throws DfException {
        List list = new ArrayList();
        int valueCount = sysObject.getValueCount(attribute);
        for (int i = 0; i < valueCount; i++) {
            list.add(sysObject.getRepeatingString(attribute, i));
        }
        return list;
    }

    private List getListByQualification(String queryString) throws DfException {
        IDfCollection col = null;
        List results = new ArrayList();
        try {
            IDfClientX clientx = new DfClientX();
            IDfQuery q = clientx.getQuery();
            q.setDQL("select r_object_id from " + queryString);
            col = q.execute(session, IDfQuery.DF_READ_QUERY);
            while (col.next()) {
                results.add(session.getObject(col.getTypedObject().getId("r_object_id")));
            }
        }
        finally {
            if (col != null)
                col.close();
        }
        return results;
    }
}