/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.agregulatorysops.test;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.monsanto.dctm.jobmethods.agregulatorysops.DocumentStateChange;
import junit.framework.TestCase;

import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: DocumentStateChange_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2006-11-14 21:07:57 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class DocumentStateChange_UT extends TestCase {
    private static final String DOCBASE = "mtctst01";
    private static final String USERNAME = "devl07";
    private static final String PASSWORD = "devl07";

    private DocumentStateChange documentStateChange;
    private IDfSessionManager sessionManager;
    private Map parameters;

    protected void setUp() throws Exception {
        super.setUp();
        String[] docbaseParam = new String[1];
        docbaseParam[0] = DOCBASE;
        parameters = new HashMap();
        parameters.put("docbase_name", docbaseParam);

        String[] usernameParam = new String[1];
        usernameParam[0] = USERNAME;
        parameters.put("user_name", usernameParam);

        String[] passwordParam = new String[1];
        passwordParam[0] = PASSWORD;
        parameters.put("password", usernameParam);

        documentStateChange = new DocumentStateChange();
        sessionManager = createSessionManager(DOCBASE, USERNAME, PASSWORD);
    }

    protected void tearDown() throws Exception {
        sessionManager = null;
        documentStateChange = null;
        super.tearDown();
    }

    public void testExecuteWithNoErrors() throws Exception {
        documentStateChange.execute(parameters, System.out);
    }

    public void testNullParams() throws Exception {
        documentStateChange.execute(null, null);
    }

    public void testAutoPromotion() throws Exception {
        IDfSession session = null;
        IDfPersistentObject testObject = null;
        try {
            session = sessionManager.getSession(DOCBASE);
            testObject = createAutoPromotionTestObject(session);
            runJobAndFlushCache(session);
            assertEquals("current state should be Approved", "Approved", getCurrentStateName(session, testObject));

            setEffectiveDateToNow(testObject);
            runJobAndFlushCache(session);
            assertEquals("current state should be Effective", "Effective", getCurrentStateName(session, testObject));

            setRetiredDateToNow(testObject);
            runJobAndFlushCache(session);
            assertEquals("current state should be Retired", "Retired", getCurrentStateName(session, testObject));
        } finally {
            if (testObject != null) {
                testObject.destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    public void testObjectIsSuperseded() throws Exception {
        IDfSession session = null;
        IDfPersistentObject supersededObject = null;
        IDfPersistentObject supersedingObject = null;
        try {
            session = sessionManager.getSession(DOCBASE);
            supersededObject = createSupersededTestObject(session);
            runJobAndFlushCache(session);
            assertEquals("current state should be Approved", "Approved", getCurrentStateName(session, supersededObject));

            setEffectiveDateToNow(supersededObject);
            runJobAndFlushCache(session);
            assertEquals("current state should be Effective", "Effective", getCurrentStateName(session, supersededObject));

            supersedingObject = createSupersedingTestObject(session);
            runJobAndFlushCache(session);
            assertEquals("current state should be Approved", "Approved", getCurrentStateName(session, supersedingObject));

            setEffectiveDateToNow(supersedingObject);
            runJobAndFlushCache(session);
            assertEquals("current state should be Effective", "Effective", getCurrentStateName(session, supersedingObject));
            assertEquals("current state should be Superseded", "Superseded", getCurrentStateName(session, supersededObject));
            assertNotNull("superceded_date should be set", supersededObject.getTime("superceded_date"));

        } finally {
            if (supersededObject != null) {
                supersededObject.destroy();
            }
            if (supersedingObject != null) {
                supersedingObject.destroy();
            }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }

    private void setRetiredDateToNow(IDfPersistentObject testObject) throws DfException {
        testObject.setTime("retired_date", new DfTime());
        testObject.save();
    }

    private IDfPersistentObject createAutoPromotionTestObject(IDfSession session) throws DfException {
        IDfPersistentObject testObject;
        testObject = session.newObject("ag_regulatory_sops");
        testObject.setString("sop_group", "Agricultural Research");
        testObject.setString("sop_type", "Equipment");
        testObject.setTime("approved_date", new DfTime());
        testObject.setString("object_name", "first_test_object");
        testObject.save();
        return testObject;
    }

    private void setEffectiveDateToNow(IDfPersistentObject object) throws DfException {
        object.setTime("effective_date", new DfTime());
        object.save();
    }

    private void runJobAndFlushCache(IDfSession session) throws DfException {
        documentStateChange.execute(parameters, System.out);
        session.flush("persistentcache", null);
    }

    private IDfPersistentObject createSupersedingTestObject(IDfSession session) throws DfException {
        IDfPersistentObject supersedingObject;
        supersedingObject = session.newObject("ag_regulatory_sops");
        supersedingObject.setString("sop_group", "Agricultural Research");
        supersedingObject.setString("sop_type", "Equipment");
        supersedingObject.setTime("approved_date", new DfTime());
        supersedingObject.appendString("superseded_sops", "superseded_test_object");
        supersedingObject.setString("object_name", "superseding_test_object");
        supersedingObject.save();
        return supersedingObject;
    }

    private IDfPersistentObject createSupersededTestObject(IDfSession session) throws DfException {
        IDfPersistentObject supersededObject;
        supersededObject = session.newObject("ag_regulatory_sops");
        supersededObject.setString("sop_group", "Agricultural Research");
        supersededObject.setString("sop_type", "Equipment");
        supersededObject.setTime("approved_date", new DfTime());
        supersededObject.setString("object_name", "superseded_test_object");
        supersededObject.save();
        return supersededObject;
    }

    private String getCurrentStateName(IDfSession session, IDfPersistentObject testObject) throws DfException {
        String currentState = testObject.getString("r_current_state");
        IDfId policyId = ((IDfSysObject) testObject).getPolicyId();
        assertNotNull("testObject should have a lifecycle attached", policyId);
        IDfPersistentObject policy = session.getObject(policyId);
        int lifecycleStateIndex = getLifecycleStateIndex(policy, currentState);
        currentState = policy.getRepeatingString("state_name", lifecycleStateIndex);
        return currentState;
    }

    private int getLifecycleStateIndex(IDfPersistentObject policy, String strValue) throws DfException {
        int nLifecycleStateIndex = 0;
        int nState = Integer.parseInt(strValue);
        int nCount = policy.getValueCount("i_state_no");
        int nStateNo = 0;
        int i = 0;
        do {
            if (i >= nCount)
                break;
            nStateNo = policy.getRepeatingInt("i_state_no", i);
            if (nState == nStateNo) {
                nLifecycleStateIndex = i;
                break;
            }
            i++;
        } while (true);
        return nLifecycleStateIndex;
    }

    public static IDfSessionManager createSessionManager(String docbase, String user, String pass) throws DfException {
        IDfClientX clientx = new DfClientX();
        IDfClient client = clientx.getLocalClient();
        IDfSessionManager sMgr = client.newSessionManager();
        IDfLoginInfo loginInfoObj = clientx.getLoginInfo();
        loginInfoObj.setUser(user);
        loginInfoObj.setPassword(pass);
        loginInfoObj.setDomain(null);
        sMgr.setIdentity(docbase, loginInfoObj);
        return sMgr;
    }    
}