/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.externalreporting;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.mthdservlet.IDmMethod;
import com.documentum.com.IDfClientX;
import com.documentum.com.DfClientX;
import com.documentum.operations.IDfDeleteOperation;
import com.documentum.operations.IDfDeleteNode;
import com.monsanto.dctm.utils.DFCSessionUtils;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

/**
 * Filename:    $RCSfile: DeleteDocumentsBasedOnDestructionDate.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-08-04 21:28:53 $
 *
 * @author rrkaur
 * @version $Revision: 1.2 $
 */
public class DeleteDocumentsBasedOnDestructionDate implements
    IDmMethod {
  private IDfSessionManager sessionManager;

  private String docbase;
  private String userName;
  private String password;
  private IDfSession session;
  private IDfClientX clientx = new DfClientX();

  public void execute(Map map, OutputStream outputStream) throws Exception {


    try {
      if(validateArguments(map,outputStream)){
      session = getSession(docbase,userName,password);

        deleteDocumentsBasedOnDestructionDate(outputStream);
      }
    }
    finally {
      releaseSession();
    }
  }

  protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
    return DFCSessionUtils.createSessionManager(docbase, userid, password);
  }
  protected IDfSession getSession(String docbase, String userid, String password) throws DfException {
    sessionManager = getSessionManager(docbase, userid, password);
    return sessionManager.getSession(docbase);
  }
  private void releaseSession() {
    if (session != null)
      sessionManager.release(session);
  }
  public void deleteDocumentsBasedOnDestructionDate(OutputStream outputStream) throws DfException,IOException {
    IDfCollection coll =  null;
    try {
      coll = execQuery(getQuery());
      if(coll != null){

        while(coll.next()){
          IDfSysObject sysobjDoc = (IDfSysObject) session.getObject(coll.getId("r_object_id"));
          IDfDeleteOperation operation =  clientx.getDeleteOperation ();
          operation.setVersionDeletionPolicy ( IDfDeleteOperation.ALL_VERSIONS );
          IDfDeleteNode node = (IDfDeleteNode) operation.add (sysobjDoc);
          if (operation.execute())
          {
            DfLogger.debug(this,"All versions of the document have been deleted" ,null,null);
            writeMessage(outputStream, "All versions of the document have been deleted");

          }else{
            DfLogger.debug(this,"Deletion of document " + sysobjDoc.getString("r_object_id") + " " + sysobjDoc.getObjectName() + " failed",null,null);
            writeMessage(outputStream, "Deletion of document " + sysobjDoc.getObjectName() + " failed");

          }
        }
      }else{
        DfLogger.debug(this,"There are no documents to be deleted.",null,null);
        writeMessage(outputStream, "There are no documents to be deleted.");
      }
    } catch (DfException e) {
      DfLogger.debug(this,"DfException in executing the query :   "+ e.getMessage(),null,null);
      throw e;

    } finally {

      DfLogger.debug(this,"Closing collections",null,null);
      if(coll != null)
        coll.close();
    }

  }

  private IDfCollection execQuery(String strQuery) throws DfException {
    IDfClientX clientx = new DfClientX();
    IDfQuery q = clientx.getQuery();
    q.setDQL(strQuery);
    return q.execute(session, IDfQuery.DF_QUERY);
  }

  public String getQuery(){
    StringBuffer strbuff = new StringBuffer();
    strbuff.append("select r_object_id,destruction_date from ext_rpt_doc");
    strbuff.append(" where destruction_date is not nulldate");
    strbuff.append(" and datediff(day,destruction_date, date(today)) >1");
    return strbuff.toString();
  }

  private boolean validateArguments(Map map, OutputStream outputStream) throws IOException {
    boolean validArguments = true;

    if (map.containsKey("docbase_name")) {
      docbase = ((String[]) map.get("docbase_name"))[0];
    }
    if (map.containsKey("user_name")) {
      userName = ((String[]) map.get("user_name"))[0];
    }
    if (map.containsKey("password")) {
      password = ((String[]) map.get("password"))[0];
    }

    if (docbase == null || docbase.length() <= 0) {
      if (validArguments) {
        writeMessage(outputStream, "Error:");
      }
      writeMessage(outputStream, "must supply docbase");
      validArguments = false;
    }
    if (userName == null || userName.length() <= 0) {
      if (validArguments) {
        writeMessage(outputStream, "Error:");
      }
      writeMessage(outputStream, "must supply userid");
      validArguments = false;
    }
    if (password == null || password.length() <= 0) {
      if (validArguments) {
        writeMessage(outputStream, "Error:");
      }
      writeMessage(outputStream, "must supply ticket");
      validArguments = false;
    }
    return validArguments;
  }

  private void writeMessage(OutputStream outputStream, String message) throws IOException {
    outputStream.write((message + "\n").getBytes());
  }
}