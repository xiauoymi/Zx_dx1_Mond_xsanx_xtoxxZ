/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.externalreporting.test;

import com.monsanto.dctm.jobmethods.externalreporting.DeleteDocumentsBasedOnDestructionDate;
import com.monsanto.dctm.utils.DFCSessionUtils;
import com.documentum.fc.client.*;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: DeleteDocumentBasedOnDestructionDate_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-08-04 21:28:53 $
 *
 * @author rrkaur
 * @version $Revision: 1.2 $
 */
public class DeleteDocumentBasedOnDestructionDate_AT extends TestCase {
  private Map testArgs;
  private ByteArrayOutputStream outputStream;

  private static final String TESTDOCBASE = "stltst03";
  private static final String TESTUSERID = "dmadmin";
  private static final String TESTTICKET = "NewDctm5";


  private static final String DOCBASE_ARG_NAME = "docbase_name";
  private static final String USERID_ARG_NAME = "user_name";
  private static final String TICKET_ARG_NAME = "password";


  protected void setUp() throws Exception {

    outputStream = new ByteArrayOutputStream();
    testArgs = new HashMap();
    testArgs.put(DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
    testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERID});
    testArgs.put(TICKET_ARG_NAME, new String[]{TESTTICKET});
  }

  public void testDocumentWithDestructionDatePriorToTodayDate() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, TESTUSERID, TESTTICKET);
    IDfSession session = null;
    IDfSysObject sysObject = null;
    try {
      session = sessionManager.getSession(DeleteDocumentBasedOnDestructionDate_AT.TESTDOCBASE);
      sysObject = (IDfSysObject) session.newObject("ext_rpt_doc");
      sysObject.setString("object_name","External Reporting test doc for job");
      sysObject.setString("destruction_date","5/23/2008 12:00:00 AM");

      sysObject.save();

      DeleteDocumentsBasedOnDestructionDate deleteDocs = new DeleteDocumentsBasedOnDestructionDate();
      deleteDocs.execute(testArgs,outputStream);
      assertEquals("All versions of the document have been deleted\n", outputStream.toString());

    } catch (Exception e) {
      e.printStackTrace();
    } finally {

      if (session != null && session.isConnected()) {
        sessionManager.release(session);
      }

    }

  }
  public void testDocumentWithDestructionDatePriorToTodayDateAndHaveMultipleVersions() throws Exception {
      IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, TESTUSERID, TESTTICKET);
      IDfSession session = null;
      IDfSysObject sysObject = null;
      try {
        session = sessionManager.getSession(DeleteDocumentBasedOnDestructionDate_AT.TESTDOCBASE);
        sysObject = (IDfSysObject) session.newObject("ext_rpt_doc");
        sysObject.setString("object_name","External Reporting test doc for job");
        sysObject.setString("destruction_date","5/23/2008 12:00:00 AM");

        sysObject.save();
        sysObject.checkoutEx(sysObject.getString("r_version_label"),null,null);
        sysObject.checkinEx(false,null,null,null,null,null);
        sysObject.save();

        DeleteDocumentsBasedOnDestructionDate deleteDocs = new DeleteDocumentsBasedOnDestructionDate();
        deleteDocs.execute(testArgs,outputStream);
        assertEquals("All versions of the document have been deleted\n", outputStream.toString());

      } catch (Exception e) {
        e.printStackTrace();
      } finally {

        if (session != null && session.isConnected()) {
          sessionManager.release(session);
        }

      }

    }

  public void testDocumentWithDestructionDateSetToNull() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, TESTUSERID, TESTTICKET);
    IDfSession session = null;
    IDfSysObject sysObject = null;

    try {
      session = sessionManager.getSession(DeleteDocumentBasedOnDestructionDate_AT.TESTDOCBASE);
      sysObject = (IDfSysObject) session.newObject("ext_rpt_doc");
      sysObject.setString("object_name","External Reporting test doc for job");

      sysObject.save();

       if (session != null) {
        sessionManager.release(session);
         session = null;
      }

      DeleteDocumentsBasedOnDestructionDate deleteDocs = new DeleteDocumentsBasedOnDestructionDate();
      deleteDocs.execute(testArgs,outputStream);
      assertNotNull(sysObject);
      assertEquals("External Reporting test doc for job",sysObject.getObjectName());
      assertEquals("nulldate",sysObject.getString("destruction_date"));
      assertEquals("", outputStream.toString());

    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      sysObject.destroy();

      if (session != null && session.isConnected()) {
        sessionManager.release(session);
      }
    }
  }

   public void testDocumentObjectWithDestructionDateLaterThanTodayDate() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, TESTUSERID, TESTTICKET);
    IDfSession session = null;
    IDfSysObject sysObject = null;

    try {
      session = sessionManager.getSession(DeleteDocumentBasedOnDestructionDate_AT.TESTDOCBASE);
      sysObject = (IDfSysObject) session.newObject("ext_rpt_doc");
      sysObject.setString("object_name","External Reporting test doc for job");
      sysObject.setString("destruction_date","7/23/2008 12:00:00 AM");

      sysObject.save();

      if (session != null) {
        sessionManager.release(session);
        session = null;
      }

      DeleteDocumentsBasedOnDestructionDate deleteDocs = new DeleteDocumentsBasedOnDestructionDate();
      deleteDocs.execute(testArgs,outputStream);
      assertEquals("All versions of the document have been deleted\n", outputStream.toString());


    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      sysObject.destroy();

      //System.out.println("sysObject.isDeleted() = " + sysObject.isDeleted());

      if (session != null && session.isConnected()) {
        sessionManager.release(session);
      }
      //System.out.println("sysObject.isDeleted() = " + sysObject.isDeleted());
    }

  }
}