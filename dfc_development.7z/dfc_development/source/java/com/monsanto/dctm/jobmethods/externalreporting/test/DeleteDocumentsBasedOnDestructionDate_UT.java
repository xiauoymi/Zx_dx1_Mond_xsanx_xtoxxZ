/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.externalreporting.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.jobmethods.externalreporting.DeleteDocumentsBasedOnDestructionDate;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockSysObject;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: DeleteDocumentsBasedOnDestructionDate_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-08-04 21:28:53 $
 *
 * @author rrkaur
 * @version $Revision: 1.2 $
 */
public class DeleteDocumentsBasedOnDestructionDate_UT extends TestCase {

  private MockDfSessionManager sessionManager;
  private Map testArgs;
  private ByteArrayOutputStream outputStream;

  private static final String TESTDOCBASE = "testdocbase";
  private static final String TESTUSERID = "testuserid";
  private static final String TESTTICKET = "testticket";

  private static final String DOCBASE_ARG_NAME = "docbase_name";
  private static final String USERID_ARG_NAME = "user_name";
  private static final String TICKET_ARG_NAME = "password";

  protected void setUp(){
    sessionManager = new MockDfSessionManager();
    outputStream = new ByteArrayOutputStream();
    testArgs = new HashMap();
    testArgs.put(DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
    testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERID});
    testArgs.put(TICKET_ARG_NAME, new String[]{TESTTICKET});
    //testArgs.put(PACKAGEID_ARG_NAME, new String[]{TESTPACKAGEID});
  }
  public void testCreate() throws Exception {
    DeleteDocumentsBasedOnDestructionDate externalReportingDeleteDocumentsBasedOnDestructionDate = new DeleteDocumentsBasedOnDestructionDate();
    assertNotNull(externalReportingDeleteDocumentsBasedOnDestructionDate);
    assertTrue(externalReportingDeleteDocumentsBasedOnDestructionDate instanceof IDmMethod);
  }

  public void testValidateArguments() throws Exception {
    MockDeleteDocumentsBasedOnDestructionDate mock = new MockDeleteDocumentsBasedOnDestructionDate(sessionManager);

    testArgs.remove(DOCBASE_ARG_NAME);
    testArgs.remove(USERID_ARG_NAME);
    testArgs.remove(TICKET_ARG_NAME);
    //mock.getSession(TESTDOCBASE,TESTUSERID,TESTTICKET);
    mock.execute(testArgs, outputStream);

    assertEquals("Error:\nmust supply docbase\nmust supply userid\nmust supply ticket\n",
        outputStream.toString());

    outputStream.reset();
    testArgs.put(DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
    mock.execute(testArgs, outputStream);
    assertEquals("Error:\nmust supply userid\nmust supply ticket\n", outputStream.toString());

    outputStream.reset();
    testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERID});
    mock.execute(testArgs, outputStream);
    assertEquals("Error:\nmust supply ticket\n", outputStream.toString());

  }

  public void testGotUserSession() throws Exception {

    MockDeleteDocumentsBasedOnDestructionDate mock = new MockDeleteDocumentsBasedOnDestructionDate(sessionManager);
    //login details and set up session
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);

    //mock.execute(testArgs, outputStream);

    IDfSession userSession = mock.getSession(TESTDOCBASE, TESTUSERID,TESTTICKET);
    assertNotNull(userSession);
    assertEquals(TESTUSERID, userSession.getLoginUserName());
    assertEquals(TESTUSERID, userSession.getLoginInfo().getUser());
    assertEquals(TESTTICKET, userSession.getLoginInfo().getPassword());

  }
  public void testDeletedAllVersionsOfDocumentsWhenDestructionDateIsEarlierThanTodayDate() throws Exception {
    MockDeleteDocumentsBasedOnDestructionDate mock = new MockDeleteDocumentsBasedOnDestructionDate(sessionManager);
    //login details and set up session
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);

    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);

    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","09876543682");
    sysObject.setString("object_name","External Reporting Test Doc");
    //sysObject.setString("destruction_date","5/5/2008 12:00:00 AM");
    sysObject.setString("r_object_type","ext_rpt_doc");
    sysObject.setString("a_category","category");
    sysObject.setString("title","title");
    session.setDocbaseName(TESTDOCBASE);
    session.addObject(sysObject,"09876543682");
    MockSysObject nullDate = new MockSysObject();

    session.addObject(sysObject,"query_cmd,s0,F,F,,,,,select r_object_id,destruction_date from ext_rpt_doc where destruction_date is not nulldate and datediff(day,destruction_date, date(today)) >1");

    mock.execute(testArgs, outputStream);
    //assertEquals("There are no documents to be deleted.", outputStream.toString());
    assertEquals("All versions of the document have been deleted\n", outputStream.toString());
  


  }
}