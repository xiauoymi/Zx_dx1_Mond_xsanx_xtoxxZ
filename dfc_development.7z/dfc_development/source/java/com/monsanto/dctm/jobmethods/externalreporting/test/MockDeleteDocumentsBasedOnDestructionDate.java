/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.externalreporting.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
import com.monsanto.dctm.test.MockDfSessionManager;

/**
 * Filename:    $RCSfile: MockDeleteDocumentsBasedOnDestructionDate.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-08-04 21:28:53 $
 *
 * @author rrkaur
 * @version $Revision: 1.2 $
 */
public class MockDeleteDocumentsBasedOnDestructionDate extends com.monsanto.dctm.jobmethods.externalreporting.DeleteDocumentsBasedOnDestructionDate {
  public MockDfSessionManager sessionManager;

  MockDeleteDocumentsBasedOnDestructionDate(MockDfSessionManager sessionManager){
    this.sessionManager = sessionManager;

  }

  protected IDfSession getSession(String docbase, String userid, String password) throws DfException {
     return super.getSession(docbase,userid,password);
   }

  protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
    IDfLoginInfo loginInfoObj = new DfLoginInfo();
    loginInfoObj.setUser(userid);
    loginInfoObj.setPassword(password);
    loginInfoObj.setDomain(null);
    sessionManager.setIdentity(docbase, loginInfoObj);
    return sessionManager;
  }
}