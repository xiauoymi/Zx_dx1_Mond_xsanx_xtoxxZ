/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.pmfluling;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

/**
 *
 * @author tsvedan
 */
public class PMFReviewNotification {

    /**
     * Creates a new instance of com.monsanto.dctm.pmfluling.jobmethods.PMFReviewNotification
     */
    public PMFReviewNotification() {
        sMgr = null;
        session = null;
    }

    private String getQuery() {
        StringBuffer sbQuery = new StringBuffer();
        sbQuery.append("select r_object_id from pmf_doc_luling ");
        sbQuery.append("where revision_date is not nulldate and ");
        sbQuery.append("datediff(day, date(today), revision_date) < 31");
        return sbQuery.toString();
    }

    private String getUnitCode(IDfSysObject sysObj) throws DfException {
        String result = null;
        StringBuffer query = new StringBuffer("select coded_value from dm_dbo.code_lookup");
        query.append(" where decoded_value='").append(sysObj.getString("mfg_unit")).append("'");
        query.append(" and code_type='pmf_luling_unit'");
        IDfCollection coll = execQuery(query.toString());
        if(coll != null && coll.next()){
            result = coll.getString("coded_value");
            coll.close();
        }
        return result;
    }

    private IDfList buildNotifyGroups(String unit) throws DfException {
        IDfList groupList = new DfList();
        String mfgtct = "lul_" + unit + "_mfg_tct";
        String psmclerk = "lul_" + unit + "_psm_clerk";
        IDfGroup tct = session.getGroup(mfgtct);
        IDfGroup psm = session.getGroup(psmclerk);
        if (tct == null || tct.getUsersNamesCount() < 1)
            System.out.println("<<<<<< Notification group " + mfgtct + " is either unavailable or empty");
        else groupList.appendString(mfgtct);
        if (psm == null || psm.getUsersNamesCount() < 1)
            System.out.println("<<<<<< Notification group " + psmclerk + " is either unavailable or empty");
        else groupList.appendString(psmclerk);

        return groupList;
    }

    public void login(String docbase, String user) {
        IDfClientX clientX = new DfClientX();
        try {
            IDfClient client = clientX.getLocalClient();
            sMgr = client.newSessionManager();
            IDfLoginInfo loginInfo = clientX.getLoginInfo();
            loginInfo.setUser(user);
            loginInfo.setPassword("");
            loginInfo.setDomain("");
            sMgr.setIdentity(docbase, loginInfo);
            session = sMgr.getSession(docbase);
        } catch(DfException e) {
            System.out.println("Error connecting to docbase:: " + e.toString());
        }
    }

    public void sendReviewNotices() {
        IDfCollection coll = null;
        IDfSysObject sysObj = null;
        try {
            coll = execQuery(getQuery());
            if (coll != null){
                while(coll.next()){
                    sysObj = (IDfSysObject) session.getObject(coll.getId("r_object_id"));
                    System.out.println("@@@@@ " + sysObj.getObjectName() + " @@@@@");
                    sendNotification(sysObj);
                }
                coll.close();
            }
        } catch (DfException e) {
            System.out.println(e);
        } finally {
            if(session != null)
                sMgr.release(session);
        }
    }

    protected void sendNotification(IDfSysObject sysObj) throws DfException {

        if(isAlreadyInWorkflow(sysObj)) return;
        IDfList groupList = buildNotifyGroups(getUnitCode(sysObj));
        if (groupList.getCount() < 1){
            System.out.println("<<<<<< Could not send notification for " + sysObj.getObjectName());
            return;
        }
        IDfList objList = new DfList();
        objList.append(sysObj.getId("r_object_id"));
        int flags = 0;
        System.out.println(">>>>>SENDING NOTIFICATION FOR DOC: " + sysObj.getObjectName());
        session.sendToDistributionListEx(null, groupList, "   This document is up for review - " + sysObj.getObjectName(),objList,10,flags);
    }

    private boolean isAlreadyInWorkflow(IDfSysObject sysObj) throws DfException {

        IDfSysObject version = null;
        IDfCollection coll = null;
        IDfCollection wcoll = null;
        boolean inWorkflow = false;

        if ((coll = sysObj.getVersions("r_modify_date, r_object_id")) != null){
            while (coll.next()){
                version = (IDfSysObject) session.getObject(
                        coll.getId("r_object_id"));
                if ((wcoll = version.getWorkflows("", "")) != null){
                    while (wcoll.next()){
                        if (isNonMOCWorkflow(wcoll.getString("r_workflow_id"))){
                            System.out.println("<<<<<<<<THIS OBJECT ALREADY PARTICIPATES IN A WORKFLOW");
                            inWorkflow = true;
                            break;
                        }
                    }
                    if (inWorkflow) break;
                }
            }
        }
        if (wcoll != null)
            wcoll.close();
        if (coll != null)
            coll.close();

        return inWorkflow;
    }

    private boolean isNonMOCWorkflow(String workflowId) throws DfException {
        boolean nonmoc = false;
        IDfWorkflow workflow = (IDfWorkflow) session.getObject(new DfId(workflowId));
        IDfProcess process = (IDfProcess) session.getObject(workflow.getProcessId());
        String procName = process.getObjectName();
        if (procName.indexOf("MOC") < 0 && procName.indexOf("PMF") >= 0){
            System.out.println("Process Name = " + procName + "   workflowId = " + workflowId);
            nonmoc = true;
        }
        return nonmoc;
    }

    private IDfCollection execQuery(String strQuery) throws DfException {
        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        String result = null;
        q.setDQL(strQuery);
        return q.execute(session, IDfQuery.DF_QUERY);
    }


    public static void main(String args[]) {

        PMFReviewNotification pmf = null;
        if(args.length == 2) {
            pmf = new PMFReviewNotification();
            pmf.login(args[0], args[1]);
            pmf.sendReviewNotices();
        } else {
            System.out.println("************ERROR IN PASSING PARAMETERS**************");
            System.out.println("Please check the method parameters/arguments.");
            System.out.println("Must be in the following order: docbase username");
            System.out.println("*****************************************************");
            System.exit(0);
        }
    }

    private IDfSessionManager sMgr;
    private IDfSession session;

}
