package com.monsanto.dctm.jobmethods.queueitems;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.DfId;
import com.documentum.com.IDfClientX;
import com.documentum.com.DfClientX;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.utils.DFCSessionUtils;
import java.util.Map;
import java.util.StringTokenizer;
import java.io.OutputStream;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: May 27, 2009
 * Time: 2:10:43 PM
 * To change this template use File | Settings | File Templates.
 */
public class QueueitemsForDeletion  implements IDmMethod {
    private IDfSessionManager sessionManager;
    private String docbase;
    private String userName;
    private String password = "";
    private IDfSession session;
    private String jobid;
    public String whereclause_arg_name;
    public String whereClause;
    public void execute(Map map, OutputStream outputStream) throws Exception {
        try {
            if(validateArguments(map,outputStream)){
                session = getSession(docbase,userName,password);
                if (extractWhereClause()) {
                    markQuequeItemsForDeletion(outputStream);
                }
                else
                {
                    writeMessage(outputStream, "No where clause provided");
                }
            }
        }
        finally {
            releaseSession();
        }
    }
    protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
        return DFCSessionUtils.createSessionManager(docbase, userid, password);
    }
    protected IDfSession getSession(String docbase, String userid, String password) throws DfException {
        sessionManager = getSessionManager(docbase, userid, password);
        return sessionManager.getSession(docbase);
    }
    private void releaseSession() {
        if (session != null)
            sessionManager.release(session);
    }
    protected boolean validateArguments(Map map, OutputStream outputStream) throws IOException {
        boolean validArguments = true;

        if (map.containsKey("docbase_name")) {
            docbase = ((String[]) map.get("docbase_name"))[0];
        }
        if (map.containsKey("user_name")) {
            userName = ((String[]) map.get("user_name"))[0];
        }
        if (map.containsKey("job_id")) {
            jobid = ((String[]) map.get("job_id"))[0];
        }
        if (docbase == null || docbase.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply docbase");
            validArguments = false;
        }
        if (userName == null || userName.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply userid");
            validArguments = false;
        }
        if (jobid == null || jobid.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply job id");
            validArguments = false;
        }
        System.out.println("QueueitemsForDeletion.validateArguments: " + "validArguments = " + validArguments);
        return validArguments;
    }
    private void writeMessage(OutputStream outputStream, String message) throws IOException {
        outputStream.write((message + "\n").getBytes());
        System.out.println("QueueitemsForDeletion.writeMessage: "+ "message = " + message);
    }
    protected boolean extractWhereClause() throws DfException {
        DfLogger.debug(this, "Job Id: " + jobid, null, null);
        System.out.println("QueueitemsForDeletion.extractWhereClause: "+"jobid = " + jobid);
        IDfSysObject job = (IDfSysObject)session.getObject(new DfId(jobid));
        System.out.println("job = " + job);
        String methodargs = job.getAllRepeatingStrings("method_arguments", "`");
        StringTokenizer st = new StringTokenizer(methodargs, "`");
        System.out.println("methodargs = " + methodargs);
        boolean bolWhereClause = false;
        int i = 0;
        if (st.countTokens() != 0){
            while(i <= st.countTokens())
            {
                whereClause = st.nextToken();
                System.out.println("whereClause = " + whereClause);
                i++;
                bolWhereClause = true;
            }
        }
        else {
            bolWhereClause = false;
        }
        return bolWhereClause;
    }
    protected String formQueryToMarkQueueItemsForDeletion(OutputStream outputStream) throws IOException {
        String queueitemsUpdateQuery = "update dmi_queue_item objects\n" +
                "set delete_flag = 1 where delete_flag != 1 and " ;
        String finalQuery = queueitemsUpdateQuery + whereClause;
        System.out.println("QueueitemsForDeletion.formQueryToMarkQueueItemsForDeletion: "+ "finalQuery = " + finalQuery);
        DfLogger.debug(this, "QueueItems marked for deletion query = " + finalQuery, null, null);
        return finalQuery;
    }
    protected void markQuequeItemsForDeletion(OutputStream outputStream) throws DfException, IOException {
        String queryString = formQueryToMarkQueueItemsForDeletion(outputStream);
        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        q.setDQL(queryString);
        q.execute(session, IDfQuery.DF_EXEC_QUERY);
        DfLogger.debug(this,"Queueitems have been marked for deletion" ,null,null);
        writeMessage(outputStream, "Queueitems have been marked for deletion");
    }
}
