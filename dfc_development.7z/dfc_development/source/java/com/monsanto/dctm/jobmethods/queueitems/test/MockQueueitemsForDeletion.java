package com.monsanto.dctm.jobmethods.queueitems.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.common.DfLoginInfo;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.jobmethods.queueitems.QueueitemsForDeletion;
import java.util.Map;
import java.io.OutputStream;
import java.io.IOException;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: May 27, 2009
 * Time: 2:34:27 PM
 * To change this template use File | Settings | File Templates.
 */
public class MockQueueitemsForDeletion extends QueueitemsForDeletion {

    public MockDfSessionManager sessionManager;
    protected String whereclause_arg_name;
    protected String testWhereClause;

    MockQueueitemsForDeletion(MockDfSessionManager sessionManager){
        this.sessionManager = sessionManager;

    }
    protected IDfSession getSession(String docbase, String userid, String password) throws DfException {
        System.out.println("MockQueueitemsForDeletion.getSession");
        return super.getSession(docbase,userid,password);
    }
    protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
        IDfLoginInfo loginInfoObj = new DfLoginInfo();
        loginInfoObj.setUser(userid);
        loginInfoObj.setPassword(password);
        loginInfoObj.setDomain(null);
        sessionManager.setIdentity(docbase, loginInfoObj);
        return sessionManager;
    }
    protected boolean validateArguments(Map map, OutputStream outputStream) throws IOException {
        return super.validateArguments(map, outputStream);
    }
    protected boolean extractWhereClause() throws DfException{
        boolean bolWhereClause = super.extractWhereClause();
        whereclause_arg_name = super.whereclause_arg_name;
        testWhereClause = super.whereClause;
        return bolWhereClause;
    }

    protected String formQueryToMarkQueueItemsForDeletion(OutputStream outputStream) throws IOException {
        return super.formQueryToMarkQueueItemsForDeletion(outputStream);
    }
}
