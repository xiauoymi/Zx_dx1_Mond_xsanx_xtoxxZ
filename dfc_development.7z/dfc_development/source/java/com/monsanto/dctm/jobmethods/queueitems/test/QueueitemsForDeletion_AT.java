package com.monsanto.dctm.jobmethods.queueitems.test;

import junit.framework.TestCase;

import java.util.Map;
import java.util.HashMap;
import java.io.ByteArrayOutputStream;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.utils.DFCSessionUtils;
import com.monsanto.dctm.jobmethods.externalreporting.DeleteDocumentsBasedOnDestructionDate;
import com.monsanto.dctm.jobmethods.queueitems.QueueitemsForDeletion;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: May 28, 2009
 * Time: 11:49:46 AM
 * To change this template use File | Settings | File Templates.
 */
public class QueueitemsForDeletion_AT extends TestCase {
    private Map testArgs;
    private ByteArrayOutputStream outputStream;
    private static final String TESTDOCBASE = "stltst03";
    //please use superuser account
    private static final String TESTUSERID = "devl30";
    private static final String TESTTICKET = "devl30";
    private static final String DOCBASE_ARG_NAME = "docbase_name";
    private static final String USERID_ARG_NAME = "user_name";
    private static final String TICKET_ARG_NAME = "password";
    private static final String JOBID_ARG_NAME = "job_id";
    private static final String TESTJOBID = "08001abe801e05fc";
    protected void setUp() throws Exception {
        outputStream = new ByteArrayOutputStream();
        testArgs = new HashMap();
        testArgs.put(DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
        testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERID});
        testArgs.put(TICKET_ARG_NAME, new String[]{TESTTICKET});
        testArgs.put(JOBID_ARG_NAME, new String[]{TESTJOBID});
    }
   public void testMarkQuequeItemsForDeletion() throws DfException {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, TESTUSERID, TESTTICKET);
    IDfSession session = null;
    try {
      session = sessionManager.getSession(QueueitemsForDeletion_AT.TESTDOCBASE);
      QueueitemsForDeletion queueitemsForDeletion = new QueueitemsForDeletion();
      queueitemsForDeletion.execute(testArgs,outputStream);
      assertEquals("Queueitems have been marked for deletion\n", outputStream.toString());

    } catch (Exception e) {
      e.printStackTrace();
    } finally {

      if (session != null && session.isConnected()) {
        sessionManager.release(session);
      }
    }
   }
}
