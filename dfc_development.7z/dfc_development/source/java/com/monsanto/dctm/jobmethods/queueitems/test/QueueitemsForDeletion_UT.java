package com.monsanto.dctm.jobmethods.queueitems.test;

import junit.framework.TestCase;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockSysObject;
import com.monsanto.dctm.jobmethods.queueitems.QueueitemsForDeletion;
import com.documentum.fc.client.MockSession;
import com.documentum.mthdservlet.IDmMethod;
import java.util.Map;
import java.util.HashMap;
import java.util.ArrayList;
import java.io.ByteArrayOutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: May 27, 2009
 * Time: 2:13:01 PM
 * To change this template use File | Settings | File Templates.
 */
public class QueueitemsForDeletion_UT extends TestCase {
    private MockDfSessionManager sessionManager;
    private Map testArgs;
    private ByteArrayOutputStream outputStream;
    private static final String TESTDOCBASE = "testdocbase";
    private static final String TESTUSERID = "testuserid";
    private static final String DOCBASE_ARG_NAME = "docbase_name";
    private static final String USERID_ARG_NAME = "user_name";
    private static final String TESTWHERECLAUSE = "event = 'dm_policy_uninstalled' and name like 'Sing%'";
    private static final String JOBID_ARG_NAME = "job_id";
    private static final String TESTJOBID = "1234";
    private static final String QUEUEITEMS_QUERY = "update dmi_queue_item objects\n" +
            "set delete_flag = 1 where delete_flag != 1 and " + TESTWHERECLAUSE;

    protected void setUp(){
        sessionManager = new MockDfSessionManager();
        outputStream = new ByteArrayOutputStream();
        testArgs = new HashMap();
        testArgs.put(DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
        testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERID});
        testArgs.put(JOBID_ARG_NAME, new String[]{TESTJOBID});
    }
    public void testCreate() throws Exception {
        QueueitemsForDeletion ququeItemsForDeletion= new QueueitemsForDeletion();
        assertNotNull(ququeItemsForDeletion);
        assertTrue(ququeItemsForDeletion instanceof IDmMethod);
    }

    public void testValidateArguments() throws Exception {
        MockQueueitemsForDeletion mock = new MockQueueitemsForDeletion(sessionManager);
        testArgs.remove(DOCBASE_ARG_NAME);
        testArgs.remove(USERID_ARG_NAME);
        testArgs.remove(JOBID_ARG_NAME);
        mock.validateArguments(testArgs, outputStream);
        assertEquals("Error:\nmust supply docbase\nmust supply userid\nmust supply job id\n",
                outputStream.toString());

        outputStream.reset();
        testArgs.put(DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
        mock.validateArguments(testArgs, outputStream);
        assertEquals("Error:\nmust supply userid\nmust supply job id\n", outputStream.toString());

        outputStream.reset();
        testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERID});
        mock.validateArguments(testArgs, outputStream);
        assertEquals("Error:\nmust supply job id\n", outputStream.toString());

        outputStream.reset();
        testArgs.put(JOBID_ARG_NAME, new String[]{TESTJOBID});
        mock.validateArguments(testArgs, outputStream);
        assertEquals("", outputStream.toString());
    }
    public void testGotUserSession() throws Exception {
        MockQueueitemsForDeletion mock = new MockQueueitemsForDeletion(sessionManager);
        MockSession userSession = (MockSession) mock.getSession(TESTDOCBASE, TESTUSERID,"");

        assertNotNull(userSession);

        assertEquals(TESTUSERID, userSession.getLoginUserName());
        assertEquals(TESTUSERID, userSession.getLoginInfo().getUser());
    }
    public void testExtractWhereClause() throws Exception {
        MockQueueitemsForDeletion mock = new MockQueueitemsForDeletion(sessionManager);
        MockSysObject jobObject = new MockSysObject();
        jobObject.setString("r_object_id","1234");
        ArrayList methodValues =  new ArrayList();
        methodValues.add(TESTWHERECLAUSE);
        jobObject.setRepeatingStrings("method_arguments",methodValues);
        MockSession userSession = (MockSession) mock.getSession(TESTDOCBASE, TESTUSERID,"");
        userSession.addObject(jobObject,TESTJOBID);
        jobObject.setSession(userSession);

        mock.execute(testArgs, outputStream);

        assertEquals(TESTWHERECLAUSE,mock.testWhereClause);
    }
    public void testNoWhereClause() throws Exception {
        MockQueueitemsForDeletion mock = new MockQueueitemsForDeletion(sessionManager);
        MockSysObject jobObject = new MockSysObject();
        jobObject.setString("r_object_id","1234");
        ArrayList methodValues =  new ArrayList();
        methodValues.add("");
        jobObject.setRepeatingStrings("method_arguments",methodValues);
        MockSession userSession = (MockSession) mock.getSession(TESTDOCBASE, TESTUSERID,"");
        userSession.addObject(jobObject,TESTJOBID);
        jobObject.setSession(userSession);

        mock.execute(testArgs, outputStream);

        assertEquals("No where clause provided\n", outputStream.toString());
    }
    public void testFormQuery() throws Exception {
        MockQueueitemsForDeletion mock = new MockQueueitemsForDeletion(sessionManager);
        MockSysObject jobObject = new MockSysObject();
        jobObject.setString("r_object_id","1234");
        ArrayList methodValues =  new ArrayList();
        methodValues.add(TESTWHERECLAUSE);
        jobObject.setRepeatingStrings("method_arguments",methodValues);
        MockSession userSession = (MockSession) mock.getSession(TESTDOCBASE, TESTUSERID,"");
        userSession.addObject(jobObject,TESTJOBID);
        jobObject.setSession(userSession);
        mock.execute(testArgs, outputStream);

        String queueitems_query = mock.formQueryToMarkQueueItemsForDeletion(outputStream);

        assertEquals(QUEUEITEMS_QUERY, queueitems_query);
    }
}
