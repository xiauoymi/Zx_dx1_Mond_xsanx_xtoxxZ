/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.suppliercontracts;

/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

import java.util.*;

/**
 * Filename:    $RCSfile: SupplierContractsReviewNotifications.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-02-04 18:58:06 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class SupplierContractsReviewNotifications {

  public SupplierContractsReviewNotifications() {
    sMgr = null;
    session = null;

    m_processName = "Supplier Contract Review Workflow";
  }


  public void login(String docbase, String user, String password) {
    IDfClientX clientX = new DfClientX();
    try {
      IDfClient client = clientX.getLocalClient();
      sMgr = client.newSessionManager();
      IDfLoginInfo loginInfo = clientX.getLoginInfo();
      loginInfo.setUser(user);
      loginInfo.setPassword(password);
      loginInfo.setDomain("");
      sMgr.setIdentity(docbase, loginInfo);
      session = sMgr.getSession(docbase);
      setProcessId(m_processName);
      initCostCenterMap();
    } catch (DfException e) {
      e.getMessage();
      System.out.println("Error connecting to docbase:: " + e.toString());
    }
  }

  public void startWorkflows() {
    IDfCollection coll = null;
    IDfCollection wcoll = null;
    IDfSysObject sysObj = null;
    IDfWorkflow workflow = null;
    boolean inSCReviewWorkflow = false;
    int daysPastDue = 0;
    try {
      coll = execQuery(getQuery());
      if (coll != null) {
        while (coll.next()) {
          sysObj = (IDfSysObject) session.getObject(coll.getId("r_object_id"));
          daysPastDue = coll.getInt("over_due");
          System.out.println(
              "\nReview of contract \"" + sysObj.getObjectName() + "\" is " + daysPastDue + " day(s) overdue.");
          if ((wcoll = sysObj.getWorkflows("", "")) != null) {
            while (wcoll.next()) {
              workflow = (IDfWorkflow) session.getObject(wcoll.getId("r_workflow_id"));
              if (workflow.getProcessId().equals(m_processId) && workflow.getRuntimeState() == 1) {
                inSCReviewWorkflow = true;
                break;
              }
            }
            wcoll.close();
          }
          if (inSCReviewWorkflow) {
            String supervisor = workflow.getSupervisorName();
            System.out.println("This contract already participates in the following workflow..");
            System.out.println("Workflow name:: " + workflow.getObjectName());
            System.out.println("Workflow supervisor:: " + supervisor);
            if (daysPastDue == 7 || daysPastDue == 14) {
              sendNotification(sysObj, supervisor, "Task Pending",
                  SupplierContractsReviewNotifications.TASK_REMINDER_MESSAGE);
            } else if (daysPastDue >= 21 && daysPastDue < 28) {
              sendNotification(sysObj, supervisor, "Task Pending",
                  SupplierContractsReviewNotifications.TASK_REMINDER_MESSAGE);
            } else if (daysPastDue >= 28) {
              sendNotification(sysObj, supervisor, "Task Pending",
                  SupplierContractsReviewNotifications.TASK_REMINDER_MESSAGE);
              sendNotification(sysObj, "supplier_contracts_procurement", "Contract Pending",
                  "Review of the following contract is more than 4 weeks overdue. The owner of this contract is " +
                      supervisor + ".");
              sendNotification(sysObj, "supplier_contracts_escalation", "Contract Pending",
                  "Review of the following contract is more than 4 weeks overdue. The owner of this contract is " +
                      supervisor + ".");
            }
          } else {
            String costCenter = sysObj.getString("cost_center_primary");
            String supervisor = getUserName(costCenter);
//                        String supervisor = "Vedantam Tejaswi S";
            if (supervisor != null) {
              startWorkflow(sysObj, supervisor);
            } else {
              System.out.println("The cost center manager for this contract could not be found..");
              if (daysPastDue == 0 || daysPastDue == 7 || daysPastDue == 14) {
                sendNotification(sysObj, "supplier_contracts_finance", "Cost Center Error",
                    getCostCenterErrorMessage(sysObj.getString("cost_center_primary"), daysPastDue));
              } else if (daysPastDue >= 21 && daysPastDue < 28) {
                sendNotification(sysObj, "supplier_contracts_finance", "Cost Center Error",
                    getCostCenterErrorMessage(sysObj.getString("cost_center_primary"), daysPastDue));
              } else if (daysPastDue >= 28) {
                sendNotification(sysObj, "supplier_contracts_finance", "Cost Center Error",
                    getCostCenterErrorMessage(sysObj.getString("cost_center_primary"), daysPastDue));
                sendNotification(sysObj, "supplier_contracts_procurement", "Cost Center Error",
                    getCostCenterErrorMessage(sysObj.getString("cost_center_primary"), daysPastDue));
                sendNotification(sysObj, "supplier_contracts_escalation", "Cost Center Error",
                    getCostCenterErrorMessage(sysObj.getString("cost_center_primary"), daysPastDue));
              }
            }
          }
          inSCReviewWorkflow = false;
        }
        coll.close();
      }
    } catch (DfException e) {
      System.out.println("ERROR:: " + e.getMessage());
      e.printStackTrace();
    } finally {
      if (session != null)
        sMgr.release(session);
    }
  }

  private void startWorkflow(IDfSysObject sysObj, String supervisor) throws DfException {

    try {
      IDfSession session = sysObj.getSession();
      IDfId processId = getProcessId();
      if (processId == null) {
        System.out.println("No valid processes to start");
        return;
      }
      IDfWorkflowBuilder wfBuilder =
          session.newWorkflowBuilder(processId);
      wfBuilder.initWorkflow();
      wfBuilder.runWorkflow();
      IDfWorkflow workflow = wfBuilder.getWorkflow();

      workflow.updateSupervisorName(supervisor);

      String activityName = null;
      String packageName = null;
      String portName = null;

      if (getActivityId() == null) //choose first start activity by default
      {
        IDfList activityIds = wfBuilder.getStartActivityIds();
        setActivityId((IDfId) activityIds.get(0));
      }

      IDfActivity activity =
          (IDfActivity) session.getObject(getActivityId());
      activityName = activity.getString("object_name");

      if (getPortName() == null) //choose first input port by default
      {
        for (int cntrPort = 0; cntrPort < activity.getPortCount(); cntrPort++) {
          if (activity.getPortType(cntrPort).equals("INPUT")) {
            portName = activity.getPortName(cntrPort);
            packageName = activity.getPackageName(cntrPort);
            break;
          }
        }
      } else {
        portName = getPortName();
        for (int i = 0; i < activity.getPortCount(); i++) {
          if (activity.getPortName(i).equals(portName)) {
            packageName = activity.getPackageName(i);
            break;
          }
        }
      }

      String strObjectType = sysObj.getTypeName();
      DfList list = new DfList();
      list.append(sysObj.getId("r_object_id"));
      workflow.addPackage(
          activityName,
          portName,
          packageName,
          strObjectType,
          "",
          false,
          list);
      System.out.println("Started workflow with id: " + workflow.getObjectId().getId());
      System.out.println("Workflow name: " + workflow.getObjectName());
      System.out.println("The workflow supervisor is: " + workflow.getSupervisorName());
      System.out.println("Added package with doc id: " + sysObj.getId("r_object_id"));
    } catch (DfException dfe) {
      dfe.printStackTrace();
      throw dfe;
    }

  }

  private void sendNotification(
      IDfSysObject sysObj,
      String notifyGroup,
      String event,
      String message) throws DfException {

    IDfUser user = session.getUser(notifyGroup);
    if (user == null) {
      System.out.println("@@@@@@<<<<<< Notification user/group " + notifyGroup + " is unavailable!");
      return;
    } else if (user.isGroup()) {
      IDfGroup group = session.getGroup(notifyGroup);
      if (group.getAllUsersNamesCount() < 1) {
        System.out.println("@@@@@@<<<<<< Notification group " + notifyGroup + " is empty!");
        return;
      }
    }
    System.out.println("SENDING NOTIFICATION FOR DOC: " + sysObj.getObjectName());
    sysObj.queue(notifyGroup, event, 10, true, null, message);
  }

  private String getUserName(String costCenter) throws DfException {
    IDfCollection userColl = null;
    String userOSName = null;
    String username = null;
    Vector managers = (Vector) map.get(costCenter);
    if (managers == null) return null;
    StringBuffer query = new StringBuffer("select user_name from dm_user where UPPER(user_os_name) in (");
    for (Enumeration e = managers.elements(); e.hasMoreElements(); query.append(",")) {
      userOSName = (String) e.nextElement();
      query.append("'").append(userOSName).append("'");
    }
    query.replace(query.length() - 1, query.length(), ")");
    userColl = execQuery(query.toString());
    if (userColl != null) {
      if (userColl.next()) {
        username = userColl.getString("user_name");
        System.out.println("The cost center manager responsible for this contract is " + username);
      }
      userColl.close();
    }
    return username;
  }

  private String getQuery() {
    StringBuffer strbuff = new StringBuffer();
    strbuff.append("select r_object_id, datediff(day, contract_review_date, date(today)) as over_due ");
    strbuff.append("from supplier_contract where contract_status='Approved Effective' and ");
    strbuff.append("contract_review_date is not nulldate and ");
    strbuff.append("datediff(day, contract_review_date, date(today)) >= 0");
    return strbuff.toString();
  }

  private String getCostCenterErrorMessage(String costcenter, int due) {
    StringBuffer strbuff = new StringBuffer();
    strbuff.append("Unable to find the cost center manager for the following contract that is up for review. ");
    strbuff.append("Please make sure the cost center manager for \"").append(costcenter);
    strbuff.append("\" is entered correctly in SAP and the user exists in Documentum.");
    if (due > 0)
      strbuff.append(" The intended review of this contract is ").append(due).append(" days overdue.");
    return strbuff.toString();
  }

  private IDfCollection execQuery(String strQuery) throws DfException {
    IDfClientX clientx = new DfClientX();
    IDfQuery q = clientx.getQuery();
    String result = null;
    q.setDQL(strQuery);
    return q.execute(session, IDfQuery.DF_QUERY);
  }

  private void setProcessId(String processName) throws DfException {

    try {
      IDfCollection Workflows = session.getRunnableProcesses("");
      IDfId processID = null;
      while (Workflows.next()) {
        IDfTypedObject Next = Workflows.getTypedObject();
        if (Next.getString("object_name").equals(processName)) {
          processID = Next.getId("r_object_id");
          m_processId = processID;
          System.out.println("Workflow name: " + Next.getString("object_name"));
          System.out.println("Set the process id: " + processID.toString());
          break;
        }
      }
      Workflows.close();
    } catch (DfException dfe) {
      throw dfe;
    }
  }

  private void initCostCenterMap() throws DfException {
    HashMap hMap = new HashMap();
    StringBuffer strbuff = new StringBuffer(512);
    strbuff.append("select cc.cost_center_id, cc.cost_center_manager from dm_dbo.cost_center cc ");
    strbuff.append("where cc.action_type in ('A', 'U') and cc.valid_to_date > date(today) and cc.row_update_date in ");
    strbuff.append("(select max(cc2.row_update_date) from dm_dbo.cost_center cc2 ");
    strbuff.append(
        "where cc.cost_center_id = cc2.cost_center_id and cc2.valid_to_date > date(today)) and cc.cost_center_id in ");
    strbuff.append("(select distinct cost_center_primary from supplier_contract)");
    IDfCollection coll = execQuery(strbuff.toString());
    String costCenter = null;
    String mgr = null;
    Vector managers = new Vector();
    while (coll.next()) {
      if (costCenter == null) {
        costCenter = coll.getString("cost_center_id");
        managers.add(coll.getString("cost_center_manager"));
      } else {
        if (costCenter.equals(coll.getString("cost_center_id"))) {
          mgr = coll.getString("cost_center_manager");
          if (!managers.contains(mgr))
            managers.add(mgr);
        } else {
          hMap.put(costCenter, managers);
          costCenter = coll.getString("cost_center_id");
          managers = new Vector();
          managers.add(coll.getString("cost_center_manager"));
        }
      }
    }
    hMap.put(costCenter, managers);
    map = (Map) hMap;
//        printCostCenterMap();
  }

  private void printCostCenterMap() {
    Set set = map.keySet();
    String cc = null;
    for (Iterator iter = set.iterator(); iter.hasNext();) {
      cc = (String) iter.next();
      System.out.print(cc + " ->");
      Vector v = (Vector) map.get(cc);
      for (Enumeration e = v.elements(); e.hasMoreElements();)
        System.out.print("  " + e.nextElement().toString());
      System.out.println("");
    }
  }

  private IDfId getProcessId() throws DfException {
    return m_processId;
  }

  private IDfId getActivityId() {
    return m_activityId;
  }

  private String getPackageName() {
    return m_strPackageName;
  }

  private String getPortName() {
    return m_strPortName;
  }

  private void setActivityId(IDfId activityId) {
    m_activityId = activityId;
  }

  private void setPackageName(String packageName) {
    m_strPackageName = packageName;
  }

  private void setPortName(String strPort) {
    m_strPortName = strPort;
  }


  public static void main(String args[]) {

    SupplierContractsReviewNotifications scn = null;
    if (args.length == 3) {
      scn = new SupplierContractsReviewNotifications();
      scn.login(args[0], args[1], args[2]);
      scn.startWorkflows();
    } else if (args.length == 2) {
      scn = new SupplierContractsReviewNotifications();
      scn.login(args[0], args[1], "");
      scn.startWorkflows();
    } else {
      System.out.println("************ERROR IN PASSING PARAMETERS**************");
      System.out.println("Please check the method parameters/arguments.");
      System.out.println("Must be in the following order: docbase username password");
      System.out.println("*****************************************************");
      System.exit(0);
    }
  }

  private IDfSessionManager sMgr;
  private IDfSession session;
  private Map map;

  private IDfId m_activityId = null;
  private IDfId m_processId = null;
  private String m_strPackageName = null;
  private String m_strPortName = null;
  private String m_processName;

  private static final String TASK_REMINDER_MESSAGE = "Please finish the task containing this contract to start the review process";

}