/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.trasetrak;

import com.documentum.mthdservlet.IDmMethod;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.com.IDfClientX;
import com.documentum.com.DfClientX;
import com.documentum.operations.IDfDeleteOperation;
import com.documentum.operations.IDfDeleteNode;
import com.monsanto.dctm.utils.DFCSessionUtils;

import java.io.OutputStream;
import java.io.IOException;
import java.util.Map;

/**
 * Filename:    $RCSfile: TraseTrakDocsDeletion.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2007-06-11 17:58:39 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public class TraseTrakDocsDeletion implements IDmMethod {
  private static final String CLASSNAME = "com.monsanto.dctm.jobmethods.trasetrak.TraseTrakDocsDeletion";
  private IDfSessionManager sessionManager;
  private String docbase;
  private String userName;
  private String password;
  private OutputStream out;
  private IDfSession session;
  private IDfClientX clientx = new DfClientX();
  //IDfSysObject sysobjDoc;

  /**the entry method for processing documents up for annual review
   *
   * @param parameters
   * @param output
   * @throws com.documentum.fc.common.DfException
   * @throws java.io.IOException
   */
  public void execute(Map parameters, OutputStream output) throws DfException, IOException {
    this.out = output;
    boolean validParameters = validateArguments(parameters, output);
    if (validParameters) {
      try {
        createSession();
        deleteDocuments();
      }
      finally {
        releaseSession();
      }
    }
  }

  /** Form the query to get the documents that are 7 years old for deletion
   *
   * @return String
   */
  private String getQuery() {
    StringBuffer strbuff = new StringBuffer();
    strbuff.append("select r_object_id from trasetrak_pos_doc ");
    strbuff.append("where DATEDIFF(year,r_creation_date,date(today)) = 7 ");
    //System.out.println(strbuff);
    return strbuff.toString();
  }

  /**Gets the query for execution
   *
   * @param strQuery
   * @return
   * @throws DfException
   */
  private IDfCollection execQuery(String strQuery) throws DfException {

    IDfQuery q = clientx.getQuery();
    q.setDQL(strQuery);
    //System.out.println(strQuery);
    return q.execute(session, IDfQuery.DF_QUERY);
  }

  /** Get the documents that are 7 years old for deletion
   */
  private void deleteDocuments() {
    IDfCollection coll = null;
    try {
      coll = execQuery(getQuery());
      if (coll != null) {
        while (coll.next()) {
          IDfSysObject sysobjDoc = (IDfSysObject) session.getObject(coll.getId("r_object_id"));
          //delete the document
          System.out.println("Deleting object: " + sysobjDoc.getObjectName());
          IDfDeleteOperation operation =  clientx.getDeleteOperation ();
          operation.setVersionDeletionPolicy ( IDfDeleteOperation.ALL_VERSIONS );
          IDfDeleteNode node = (IDfDeleteNode) operation.add (sysobjDoc);
          if (operation.execute())
          {
            System.out.println ( "Deletion of "  + sysobjDoc +  " complete." );
          }
        }
        coll.close();
      }else {
        System.out.println("coll = " + coll.toString());
      }

    } catch (DfException de) {
      DfLogger.debug(CLASSNAME, "Error during query execution " + de.getMessage(), null, null);
    }
  }


  /**Make sure all the parameters are given to create a session.
   *
   * @param map
   * @param outputStream
   * @return boolean
   * @throws IOException
   */

    private boolean validateArguments(Map map, OutputStream outputStream) throws IOException {
        boolean validArguments = true;

        if (map.containsKey("docbase")) {
            docbase = ((String[]) map.get("docbase"))[0];
        }
        if (map.containsKey("userid")) {
            userName = ((String[]) map.get("userid"))[0];
        }
        if (map.containsKey("ticket")) {
            password = ((String[]) map.get("ticket"))[0];
        }

        if (docbase == null || docbase.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply docbase");
            validArguments = false;
        }
        if (userName == null || userName.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply userid");
            validArguments = false;
        }
        if (password == null || password.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply ticket");
            validArguments = false;
        }
         return validArguments;
    }
  private void createSession() throws DfException {
      sessionManager = getSessionManager(docbase, userName, password);
      session = sessionManager.getSession(docbase);
      //System.out.println("Successfully logged into " + docbase + " as " + userName);
  }

  protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
    return DFCSessionUtils.createSessionManager(docbase, userid, password);
  }
  private void releaseSession() {
    //System.out.println("Releasing session... ");
    if (session != null)
      sessionManager.release(session);
  }
    private void writeMessage(OutputStream outputStream, String message) throws IOException {
        outputStream.write((message + "\n").getBytes());
    }
 }
