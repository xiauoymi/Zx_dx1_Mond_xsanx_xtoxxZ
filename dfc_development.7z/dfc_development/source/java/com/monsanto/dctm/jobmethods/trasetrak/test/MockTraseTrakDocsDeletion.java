/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.trasetrak.test;

import com.monsanto.dctm.jobmethods.trasetrak.TraseTrakDocsDeletion;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.common.DfLoginInfo;

/**
 * Filename:    $RCSfile: MockTraseTrakDocsDeletion.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2007-06-11 17:59:06 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public class MockTraseTrakDocsDeletion extends TraseTrakDocsDeletion {
      public MockDfSessionManager sessionManager;

    public MockTraseTrakDocsDeletion(MockDfSessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }

    protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
        IDfLoginInfo loginInfoObj = new DfLoginInfo();
        loginInfoObj.setUser(userid);
        loginInfoObj.setPassword(password);
        loginInfoObj.setDomain(null);
        sessionManager.setIdentity(docbase, loginInfoObj);
        return sessionManager;
    }
}