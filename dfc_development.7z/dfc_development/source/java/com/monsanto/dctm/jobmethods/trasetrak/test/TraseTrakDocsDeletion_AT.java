/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.trasetrak.test;

import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.jobmethods.trasetrak.TraseTrakDocsDeletion;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * Filename:    $RCSfile: TraseTrakDocsDeletion_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-02-04 17:53:20 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class TraseTrakDocsDeletion_AT extends TestCase {
 // private MockDfSessionManager sessionManager;
  private Map testArgs;
  private ByteArrayOutputStream outputStream;
  TraseTrakDocsDeletion deleteDocs;

  private static final String TESTDOCBASE = "stltst03";
  private static final String TESTUSERID = "devl01";
  private static final String TESTTICKET = "devl01"; 
  //private static final String TESTJOBID = "testjobid";

  private static final String DOCBASE_ARG_NAME = "docbase";
  private static final String USERID_ARG_NAME = "userid";
  private static final String TICKET_ARG_NAME = "ticket";
  //private static final String JOBID_ARG_NAME = "jobid";


  protected void setUp() throws Exception {

    deleteDocs = new TraseTrakDocsDeletion();
    outputStream = new ByteArrayOutputStream();
    testArgs = new HashMap();
    testArgs.put(DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
    testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERID});
    testArgs.put(TICKET_ARG_NAME, new String[]{TESTTICKET});
    //testArgs.put(JOBID_ARG_NAME, new String[]{TESTJOBID});

  }
  public void testCreate() throws Exception {
    TraseTrakDocsDeletion method = new TraseTrakDocsDeletion();
    assertTrue(method instanceof IDmMethod);
  }

   public void testExecute()throws Exception {
     deleteDocs.execute(testArgs, outputStream);
   }

}