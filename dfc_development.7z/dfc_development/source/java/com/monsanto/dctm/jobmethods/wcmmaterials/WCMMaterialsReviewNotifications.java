/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.jobmethods.wcmmaterials;

/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.mthdservlet.IDmMethod;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.client.*;
import com.documentum.com.IDfClientX;
import com.documentum.com.DfClientX;

import java.util.Map;
import java.util.Iterator;
import java.io.OutputStream;

/**
 * Filename:    $RCSfile: WCMMaterialsReviewNotifications.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-02-04 17:47:46 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public class WCMMaterialsReviewNotifications implements IDmMethod {


  public void execute(Map parameters, OutputStream output) throws DfException {
    this.out = output;
    parseJobParameters(parameters);
    try {
      createSession();
      sendReviewNotifications();
    }
    finally {
      releaseSession();
    }
  }

  private String getQuery() {
    StringBuffer strbuff = new StringBuffer();
    strbuff.append("select r_object_id,object_name, doc_owner from wcm_materials_doc");
    strbuff.append("where annually_reviewed = 1 and");
    strbuff.append("dateadd(day,0,r_creation_date) <= date(today)");
    return strbuff.toString();
  }

  private IDfCollection execQuery(String strQuery) throws DfException {
    IDfClientX clientx = new DfClientX();
    IDfQuery q = clientx.getQuery();
    q.setDQL(strQuery);
    return q.execute(session, IDfQuery.DF_QUERY);
  }

  public void sendReviewNotifications() {
    IDfCollection coll = null;
    try {
      coll = execQuery(getQuery());
      System.out.println("Executed query...   got collection..");
      String performerName = null;
      String message = null;
      if (coll != null) {
        while (coll.next()) {
          IDfSysObject sysobj = (IDfSysObject) session.getObject(
              coll.getId("r_object_id"));
          performerName= coll.getString("doc_owner");
          message = "The following " + coll.getString("object_name") + " document is due for annual review.";
          sysobj.queue(performerName, "Review Due", 10, true, null, message);
        }
        coll.close();
      }
    } catch (DfException e) {
    }
  }

  private void parseJobParameters(Map parameters) {
    Iterator i = parameters.keySet().iterator();
    while (i.hasNext()) {
      String key = (String) i.next();
      String[] values = (String[]) parameters.get(key);

      if ((key == null) || (key.length() == 0) || (values == null) || (values.length < 1)) {
        continue;
      }
      if (key.equalsIgnoreCase("docbase_name")) {
        docbase = values[0];
      } else if (key.equalsIgnoreCase("user_name")) {
        userName = values[0];
      } else if (key.equalsIgnoreCase("job_id")) {
        strJobID = values[0];
      }
    }
  }

  private void createSession() {
    try {
      IDfLoginInfo login = new DfLoginInfo();
      login.setUser(userName);
      sessionManager = DfClient.getLocalClient().newSessionManager();
      sessionManager.setIdentity(docbase, login);
      session = sessionManager.getSession(docbase);
      System.out.println("Successfully logged into " + docbase + " as " + userName);
    }
    catch (Exception e) {
      e.printStackTrace(System.out);
      //System.exit(1);
    }
  }

  private void releaseSession() {
    System.out.println("Releasing session... ");
    if (session != null)
      sessionManager.release(session);
  }

  private IDfSessionManager sessionManager;
  private String docbase;
  private String userName;
  private String strJobID;
  private OutputStream out;
  private IDfSession session;
}
