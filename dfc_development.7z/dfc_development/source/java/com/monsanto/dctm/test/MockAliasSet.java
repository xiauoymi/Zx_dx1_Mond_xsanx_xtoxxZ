/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.IDfAliasSet;
import com.documentum.fc.common.DfException;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: MockAliasSet.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrkaur $    	 On:	$Date: 2008-03-11 19:13:46 $
 *
 * @author rrkaur
 * @version $Revision: 1.3 $
 */
public class MockAliasSet extends MockPersistentObject implements IDfAliasSet {
  List alias= new ArrayList();

  public String getOwnerName() throws DfException {
    return null;
  }

  public void setOwnerName(String string) throws DfException {
  }

  public String getObjectName() throws DfException {
    return null;
  }

  public void setObjectName(String string) throws DfException {
  }

  public String getObjectDescription() throws DfException {
    return null;
  }

  public void setObjectDescription(String string) throws DfException {
  }

  public int getAliasCount() throws DfException {
    return 0;
  }

  public String getAliasName(int i) throws DfException {
    return null;
  }

  public void setAliasName(int i, String string) throws DfException {
  }

  public String getAliasValue(int i) throws DfException {
     //TODO need to implement this method


    return alias.get(i).toString();
  }

  public void setAliasValue(int i, String string) throws DfException {
    alias.add(i,string);
  }

  public int getAliasCategory(int i) throws DfException {
    return 0;
  }

  public void setAliasCategory(int i, int i1) throws DfException {
  }

  public int getAliasUserCategory(int i) throws DfException {
    return 0;
  }

  public void setAliasUserCategory(int i, int i1) throws DfException {
  }

  public String getAliasDescription(int i) throws DfException {
    return null;
  }

  public void setAliasDescription(int i, String string) throws DfException {
  }

  public int appendAlias(String string, String string1, int i, int i1, String string2) throws DfException {
    return 0;
  }

  public void removeAlias(String string) throws DfException {
  }

  public int findAliasIndex(String string) throws DfException {

    return alias.size()-1;
  }

  public void removeAllAliases() throws DfException {
  }
}