/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.IDfACL;
import com.documentum.fc.client.IDfPermit;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfList;

/**
 * Filename:    $RCSfile: MockDfACL.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-05-14 21:38:20 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockDfACL extends MockPersistentObject implements IDfACL {
    public String docbaseOwnerName;
    public String aclName;

    public MockDfACL(String docbaseOwnerName, String aclName) {
        this.docbaseOwnerName = docbaseOwnerName;
        this.aclName = aclName;
    }

    public void setObjectName(String string) throws DfException {
    }

    public String getObjectName() throws DfException {
        return null;
    }

    public void setDescription(String string) throws DfException {
    }

    public String getDescription() throws DfException {
        return null;
    }

    public void setDomain(String string) throws DfException {
    }

    public String getDomain() throws DfException {
        return null;
    }

    public boolean isInternal() throws DfException {
        return false;
    }

    public int getAccessorCount() throws DfException {
        return 0;
    }

    public String getAccessorName(int i) throws DfException {
        return null;
    }

    public int getAccessorPermit(int i) throws DfException {
        return 0;
    }

    public int getAccessorPermitType(int i) throws DfException {
        return 0;
    }

    public int getAccessorXPermit(int i) throws DfException {
        return 0;
    }

    public boolean isGroup(int i) throws DfException {
        return false;
    }

    public boolean isGloballyManaged() throws DfException {
        return false;
    }

    public boolean hasPermission(String string, String string1) throws DfException {
        return false;
    }

    public String getAccessorXPermitNames(int i) throws DfException {
        return null;
    }

    public int getPermit(String string) throws DfException {
        return 0;
    }

    public int getXPermit(String string) throws DfException {
        return 0;
    }

    public String getXPermitNames(String string) throws DfException {
        return null;
    }

    public String getXPermitList() throws DfException {
        return null;
    }

    public void grant(String string, int i, String string1) throws DfException {
    }

    public void grantPermit(IDfPermit iDfPermit) throws DfException {
    }

    public void revoke(String string, String string1) throws DfException {
    }

    public void revokePermit(IDfPermit iDfPermit) throws DfException {
    }

    public IDfList getPermissions() throws DfException {
        return null;
    }

    public void destroyACL(boolean b) throws DfException {
    }

    public int getACLClass() throws DfException {
        return 0;
    }

    public void setACLClass(int i) throws DfException {
    }
}