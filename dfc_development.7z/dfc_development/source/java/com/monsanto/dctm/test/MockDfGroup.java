/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfTime;

import java.util.*;

/**
 * Filename:    $RCSfile: MockDfGroup.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: rrkaur $    	 On:	$Date: 2008-03-11 19:15:20 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class MockDfGroup extends MockPersistentObject implements IDfGroup {
    private String groupName;
    private Map groupMap = new HashMap();
    private List results;


    public String getOwnerName() throws DfException {
        return null;
    }

    public String getGroupName() throws DfException {
        return groupName;
    }

  public List setResults(List results){
    this.results = results;

    return results;
  }

    public String getGroupAddress() throws DfException {
        return null;
    }

    public String getUsersNames(int i) throws DfException {
        return null;
    }

    public int getUsersNamesCount() throws DfException {
        return 0;
    }

    public String getGroupsNames(int i) throws DfException {
        return null;//(String)groups.get(i);
    }

    public int getGroupsNamesCount() throws DfException {
        return 0;//groups.size();
    }

    public boolean isPrivate() throws DfException {
        return false;
    }

    public String getDescription() throws DfException {
        return null;
    }

    public String getAllUsersNames(int i) throws DfException {
        return null;
    }

    public int getAllUsersNamesCount() throws DfException {
      //ToDO
      if(groupMap.values().size()>0){
        
        StringTokenizer users = new StringTokenizer(groupMap.get(getGroupName()).toString(),",");
        ArrayList noOfUsers = new ArrayList();
        for(int i = 0; users.hasMoreTokens();i++){
          noOfUsers.add(users.nextToken());
        }

        return noOfUsers.size();
      }
      else
      return groupMap.size();
    }

    public boolean isGloballyManaged() throws DfException {
        return false;
    }

    public IDfTime getModifyDate() throws DfException {
        return null;
    }

    public IDfId getAliasSetId() throws DfException {
        return null;
    }

    public void setAliasSetId(IDfId iDfId) throws DfException {
    }

    public boolean isUserInGroup(String user) throws DfException {
     return groupMap.containsValue(user);
     }

    public boolean isGroupInGroup(String group) throws DfException {
      return groupMap.containsKey(group);
      }

    public void renameGroup(String attrName, boolean b, boolean b1, boolean b2) throws DfException {
    }

    public void setGroupName(String groupName) throws DfException {
        this.groupName = groupName;
    }

    public void setGroupAddress(String attrName) throws DfException {
    }

    public void setDescription(String attrName) throws DfException {
    }

    public void setPrivate(boolean b) throws DfException {
    }

    public void setOwnerName(String attrName) throws DfException {
    }

    public void setGloballyManaged(boolean b) throws DfException {
    }

    public boolean addUser(String user) throws DfException {

      if(groupMap.containsValue(user)){
            return false;
      }else if(groupMap.containsKey(getGroupName()) ){
        StringBuffer anotherUser = new StringBuffer();
        anotherUser.append(groupMap.get(getGroupName()).toString());
        anotherUser.append(",");
        anotherUser.append(user);
        groupMap.put(getGroupName(),anotherUser.toString());
       return true;
    }else{
        groupMap.put(getGroupName(),user);

        return true;
      }
    }

    public boolean addGroup(String group) throws DfException {

      if(groupMap.containsKey(getGroupName())){
        StringBuffer subGroup = new StringBuffer();
        subGroup.append(getGroupName());
        subGroup.append("_subGroup");

        groupMap.put(subGroup.toString(),group);
        return false;
      }else{
        groupMap.put(getGroupName(),"");
        return true;
      }
    }

    public boolean removeUser(String user) throws DfException {
//      if (users.contains(user)) {
//            users.remove(user);
//            return true;
//        } else {
//            return false;
//        }
      return false;
    }

    public boolean removeGroup(String group) throws DfException {
      if(groupMap.containsKey(group)){
        groupMap.remove(group);
        return true;
      }else{
        return false;
      }
    }

    public void removeAllUsers() throws DfException {
      groupMap.remove(getGroupName());
      groupMap.put(getGroupName(),"");
    }

    public void removeAllGroups() throws DfException {
      groupMap.clear();

    }

    public IDfCollection getUsersNames() throws DfException {
        return null;
    }

    public IDfCollection getGroupsNames() throws DfException {
      IDfCollection collection = new MockDfCollection(true, results);
      return collection;
    }

    public void setGroupClass(String attrName) throws DfException {
    }

    public String getGroupClass() throws DfException {
        return null;
    }

    public void setGroupAdmin(String attrName) throws DfException {
    }

    public String getGroupAdmin() throws DfException {
        return null;
    }

    public void setDynamic(boolean b) throws DfException {
    }

    public boolean getDynamic() throws DfException {
        return false;
    }

    public void setDynamicDefault(boolean b) throws DfException {
    }

    public boolean getDynamicDefault() throws DfException {
        return false;
    }

    public String getGroupDisplayName() throws DfException {
        return null;
    }

    public void setGroupDisplayName(String attrName) throws DfException {
    }

    public IDfId getGroupNativeRoomId() throws DfException {
        return null;
    }

    public void setGroupNativeRoomId(IDfId iDfId) throws DfException {
    }



}
//}