/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * Filename:    $RCSfile: MockSysObject.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2009-02-18 20:10:37 $
 *
 * @author lakench
 * @version $Revision: 1.4 $
 */
public class MockSysObject extends MockPersistentObject implements IDfSysObject {

    private String fileName;
    private long contentSize;
    private String contentType;
    public boolean wasQueueCalled = false;
    public boolean wasDestroyAllCalled = false;
    public List link = new ArrayList();
    public MockDfACL iDfACL;
    private List results;
    public String targetObjName=null;
    public static int queueCount;

    public String getObjectName() throws DfException {
        return getString("object_name");
    }

    public void setObjectName(String objectName) throws DfException {
        setString("object_name", objectName);
    }

    public String getTypeName() throws DfException {
        return getString("r_object_type");
    }

    public String getTitle() throws DfException {
        return getString("title");
    }

    public void setTitle(String title) throws DfException {
        setString("title", title);
    }

    public String getSubject() throws DfException {
        return getString("subject");
    }

    public void setSubject(String subject) throws DfException {
        setString("subject", subject);
    }

    public String getAuthors(int i) throws DfException {
        return getRepeatingString("authors", i);
    }

    public int getAuthorsCount() throws DfException {
        return getValueCount("authors");
    }

    public void setAuthors(int i, String value) throws DfException {
        setRepeatingString("authors", i, value);
    }

    public String getKeywords(int i) throws DfException {
        return getRepeatingString("keywords", i);
    }

    public int getKeywordsCount() throws DfException {
        return getValueCount("keywords");
    }

    public void setKeywords(int i, String string) throws DfException {
        setRepeatingString("keywords", i, string);
    }

    public String getApplicationType() throws DfException {
        return null;
    }

    public void setApplicationType(String string) throws DfException {
    }

    public String getStatus() throws DfException {
        return null;
    }

    public void setStatus(String string) throws DfException {
    }

    public IDfTime getCreationDate() throws DfException {
        return null;
    }

    public IDfTime getModifyDate() throws DfException {
        return null;
    }

    public String getModifier() throws DfException {
        return null;
    }

    public IDfTime getAccessDate() throws DfException {
        return null;
    }

    public boolean isHidden() throws DfException {
        return false;
    }

    public void setHidden(boolean b) throws DfException {
    }

    public IDfTime getRetentionDate() throws DfException {
        return null;
    }

    public boolean isArchived() throws DfException {
        return false;
    }

    public void setArchived(boolean b) throws DfException {
    }

    public String getCompoundArchitecture() throws DfException {
        return null;
    }

    public void setCompoundArchitecture(String string) throws DfException {
    }

    public boolean isLinkResolved() throws DfException {
        return false;
    }

    public void setLinkResolved(boolean b) throws DfException {
    }

    public int getReferenceCount() throws DfException {
        return 0;
    }

    public boolean getHasFolder() throws DfException {
        return false;
    }

    public IDfId getFolderId(int i) throws DfException {
      System.out.println("MockSysObject.getFolderId");
      System.out.println("results.get(i) = " + results.get(i));
      return (DfId)results.get(i);
     // return null;
    }


    public int getFolderIdCount() throws DfException {
        return 0;
    }

    public int getLinkCount() throws DfException {
        return 0;
    }

    public int getLinkHighCount() throws DfException {
        return 0;
    }

    public IDfId getAssembledFromId() throws DfException {
        return null;
    }

    public int getFrozenAssemblyCount() throws DfException {
        return 0;
    }

    public boolean getHasFrozenAssembly() throws DfException {
        return false;
    }

    public String getResolutionLabel() throws DfException {
        return null;
    }

    public void setResolutionLabel(String string) throws DfException {
    }

    public IDfId getContentsId() throws DfException {
        return null;
    }

    public String getContentType() throws DfException {
        return contentType;
    }

    public void setContentType(String contentType) throws DfException {
        this.contentType = contentType;
    }

    public int getPageCount() throws DfException {
        return 0;
    }

    public long getContentSize() throws DfException {
        return contentSize;
    }

    public boolean getFullText() throws DfException {
        return false;
    }

    public void setFullText(boolean b) throws DfException {
    }

    public String getStorageType() throws DfException {
        return null;
    }

    public void setStorageType(String string) throws DfException {
    }

    public IDfId getCabinetId() throws DfException {
        return null;
    }

    public String getOwnerName() throws DfException {
        return null;
    }

    public void setOwnerName(String string) throws DfException {
    }

    public int getOwnerPermit() throws DfException {
        return 0;
    }

    public void setOwnerPermit(int i) throws DfException {
    }

    public String getGroupName() throws DfException {
        return null;
    }

    public void setGroupName(String string) throws DfException {
    }

    public int getGroupPermit() throws DfException {
        return 0;
    }

    public void setGroupPermit(int i) throws DfException {
    }

    public int getWorldPermit() throws DfException {
        return 0;
    }

    public void setWorldPermit(int i) throws DfException {
    }

    public IDfId getAntecedentId() throws DfException {
        return null;
    }

    public IDfId getChronicleId() throws DfException {
        return null;
    }

    public boolean getLatestFlag() throws DfException {
        return false;
    }

    public String getLockOwner() throws DfException {
        return null;
    }

    public IDfTime getLockDate() throws DfException {
        return null;
    }

    public String getLockMachine() throws DfException {
        return null;
    }

    public String getLogEntry() throws DfException {
        return null;
    }

    public void setLogEntry(String string) throws DfException {
    }

    public String getVersionLabel(int i) throws DfException {
        return null;
    }

    public String getImplicitVersionLabel() throws DfException {
        return null;
    }

    public int getVersionLabelCount() throws DfException {
        return 0;
    }

    public int getBranchCount() throws DfException {
        return 0;
    }

    public String getDirectDescendant() throws DfException {
        return null;
    }

    public boolean isImmutable() throws DfException {
        return false;
    }

    public boolean isFrozen() throws DfException {
        return false;
    }

    public boolean getHasEvents() throws DfException {
        return false;
    }

    public String getACLDomain() throws DfException {
        return null;
    }

    public void setACLDomain(String string) throws DfException {
    }

    public String getACLName() throws DfException {
        return null;
    }

    public void setACLName(String string) throws DfException {
    }

    public String getSpecialApp() throws DfException {
        return null;
    }

    public void setSpecialApp(String string) throws DfException {
    }

    public boolean isReference() throws DfException {
        return false;
    }

    public String getCreatorName() throws DfException {
        return null;
    }

    public boolean isPublic() throws DfException {
        return false;
    }

    public IDfId getPolicyId() throws DfException {
        return getId("r_policy_id");
    }

    public String getPolicyName() throws DfException {
        IDfId policyId = getPolicyId();
        if (!policyId.getId().equals("0000000000000000")) {
            IDfPersistentObject lifecycleObject = getSession().getObject(policyId);
            return lifecycleObject.getString("object_name");
        } else {
            return null;
        }
    }

    public int getResumeState() throws DfException {
        return 0;
    }

    public String getResumeStateName() throws DfException {
        return null;
    }

    public int getCurrentState() throws DfException {
        return getInt("r_current_state");
    }

    public String getCurrentStateName() throws DfException {
      System.out.println("MockSysObject.getCurrentStateName");
      //System.out.println("getInt(\"r_current_state\") = " + getInt("r_current_state"));
      System.out.println("getPolicyId() = " + getPolicyId());
        IDfPersistentObject lifecycleObject = getSession().getObject(getPolicyId());
      System.out.println("lifecycleObject = " + lifecycleObject);
        return lifecycleObject.getRepeatingString("state_name", getCurrentState());
    }

    public IDfId getAliasSetId() throws DfException {
        return null;
    }

    public String getAliasSet() throws DfException {
        return null;
    }

    public String getPreviousStateName() throws DfException {
        IDfPersistentObject lifecycleObject = getSession().getObject(getPolicyId());
        return lifecycleObject.getRepeatingString("state_name", getCurrentState() - 1);
    }

    public String getNextStateName() throws DfException {
        IDfPersistentObject lifecycleObject = getSession().getObject(getPolicyId());
        return lifecycleObject.getRepeatingString("state_name", getCurrentState() + 1);
    }

    public int getPermit() throws DfException {
        return 0;
    }

    public int getAccessorCount() throws DfException {
        return 0;
    }

    public String getAccessorName(int i) throws DfException {
        return null;
    }

    public int getAccessorPermitType(int i) throws DfException {
        return 0;
    }

    public String getAccessorPermit(int i) throws DfException {
        return null;
    }

    public int getXPermit(String string) throws DfException {
        return 0;
    }

    public int getAccessorXPermit(int i) throws DfException {
        return 0;
    }

    public String getAccessorXPermitNames(int i) throws DfException {
        return null;
    }

    public String getAccessorApplicationPermit(int i) throws DfException {
        return null;
    }

    public String getXPermitNames(String string) throws DfException {
        return null;
    }

    public String getXPermitList() throws DfException {
        return null;
    }

    public boolean getAclRefValid() throws DfException {
        return false;
    }

    public IDfId getComponentId(int i) throws DfException {
        return null;
    }

    public int getComponentIdCount() throws DfException {
        return 0;
    }

    public IDfId getContainId(int i) throws DfException {
        return null;
    }

    public int getContainIdCount() throws DfException {
        return 0;
    }

    public int getContentState(int i) throws DfException {
        return 0;
    }

    public int getContentStateCount() throws DfException {
        return 0;
    }

    public String getMasterDocbase() throws DfException {
        return null;
    }

    public boolean areAttributesModifiable() throws DfException {
        return false;
    }

    public IDfFormat getFormat() throws DfException {
        return null;
    }

    public void checkout() throws DfException {
    }

    public IDfId checkoutEx(String string, String string1, String string2) throws DfException {
        return null;
    }

    public void cancelCheckout() throws DfException {
    }

    public void cancelCheckoutEx(boolean b, String string, String string1) throws DfException {
    }

    public IDfId checkin(boolean b, String string) throws DfException {
        return null;
    }

    public IDfId checkinEx(boolean b, String string, String string1, String string2, String string3, String string4) throws
                                                                                                                     DfException {
        return null;
    }

    public IDfId branch(String string) throws DfException {
        return null;
    }

    public boolean isCheckedOut() throws DfException {
        return false;
    }

    public boolean isCheckedOutBy(String string) throws DfException {
        return false;
    }

    public void mark(String string) throws DfException {
    }

    public void unmark(String string) throws DfException {
    }

    public IDfCollection getVersions(String string) throws DfException {
        return null;
    }

    public IDfVersionPolicy getVersionPolicy() throws DfException {
        return null;
    }

    public IDfId saveAsNew(boolean b) throws DfException {
        return null;
    }

    public void saveLock() throws DfException {
    }

    public void destroyAllVersions() throws DfException {
      wasDestroyAllCalled= true;

    }

    public String getFile(String string) throws DfException {
        return fileName;
    }

    public String getFileEx(String string, String string1, int i, boolean b) throws DfException {
        return fileName;
    }

    public String getFileEx2(String string, String string1, int i, String string2, boolean b) throws DfException {
        return fileName;
    }

    public void setFile(String fileName) throws DfException {
        this.fileName = fileName;
    }

    public void setFileEx(String fileName, String formatName, int pageNumber, String otherFile) throws DfException {

        this.fileName = fileName;
    }

    public ByteArrayInputStream getContent() throws DfException {
        return null;
    }

    public IDfCollection getCollectionForContent(String string, int i) throws DfException {
        return null;
    }

    public IDfCollection getCollectionForContentEx2(String string, int i, String string1) throws DfException {
        return null;
    }

    public ByteArrayInputStream getContentEx(String string, int i) throws DfException {
        return null;
    }

    public ByteArrayInputStream getContentEx2(String string, int i, String string1) throws DfException {
        return null;
    }

    public boolean setContent(ByteArrayOutputStream byteArrayOutputStream) throws DfException {
        return false;
    }

    public boolean setContentEx(ByteArrayOutputStream byteArrayOutputStream, String string, int i) throws DfException {
        return false;
    }

    public void addRendition(String fileName, String format) throws DfException {
        MockSysObject renditionObject = new MockSysObject();
        renditionObject.setString("r_object_id", fileName);
        renditionObject.setString("full_format", format);
        ((MockSession) getSession()).addObject(renditionObject, fileName);
        MockSysObject queryObject = new MockSysObject();
        queryObject.setString("r_object_id", fileName);
        ((MockSession) getSession()).addObject(queryObject,
                                               "query_cmd,s0,T,F,,,,,select r_object_id from dmr_content where any(parent_id_i=id('" +
                                               getObjectId() + "') and page=0)");
    }

    public void addRenditionEx(String string, String string1, int i, String string2, boolean b) throws DfException {
    }

    public void addRenditionEx2(String string, String string1, int i, String string2, String string3, boolean b, boolean b1, boolean b2) throws
                                                                                                                                         DfException {
    }

    public void removeRendition(String string) throws DfException {
    }

    public void removeRenditionEx(String string, int i, boolean b) throws DfException {
    }

    public void removeRenditionEx2(String string, int i, String string1, boolean b) throws DfException {
    }

    public void appendContent(ByteArrayOutputStream byteArrayOutputStream) throws DfException {
    }

    public void appendFile(String string) throws DfException {
    }

    public void bindFile(int i, IDfId iDfId, int i1) throws DfException {
    }

    public String getPath(int i) throws DfException {
        return null;
    }

    public String getPathEx(int i, String string) throws DfException {
        return null;
    }

    public void insertContent(ByteArrayOutputStream byteArrayOutputStream, int i) throws DfException {
    }

    public void insertFile(String string, int i) throws DfException {
    }

    public void removeContent(int i) throws DfException {
    }

    public void setPath(String string, String string1, int i, String string2) throws DfException {
    }

    public IDfCollection getRenditions(String string) throws DfException {
        String strDQL =
                "select r_object_id from dmr_content where any(parent_id_i=id('" + getObjectId() + "') and page=0)";
        DfQuery myQuery = new DfQuery();
        myQuery.setDQL(strDQL);
        return myQuery.execute(getSession(), 0);
    }

    public void addNote(IDfId iDfId, boolean b) throws DfException {
    }

    public void removeNote(IDfId iDfId) throws DfException {
    }

    public IDfId appendPart(IDfId iDfId, String string, boolean b, boolean b1, int i) throws DfException {
        return null;
    }

    public IDfCollection assemble(IDfId iDfId, int i, String string, String string1) throws DfException {
        return null;
    }

    public void disassemble() throws DfException {
    }

    public void freeze(boolean b) throws DfException {
    }

    public IDfId insertPart(IDfId iDfId, String string, IDfId iDfId1, double v, boolean b, boolean b1, boolean b2, int i) throws
                                                                                                                          DfException {
        return null;
    }

    public void removePart(IDfId iDfId, double v, boolean b) throws DfException {
    }

    public boolean isVirtualDocument() throws DfException {
        return false;
    }

    public void setIsVirtualDocument(boolean b) throws DfException {
    }

    public void unfreeze(boolean b) throws DfException {
    }

    public void updatePart(IDfId iDfId, String string, double v, boolean b, boolean b1, int i) throws DfException {
    }

    public void attachPolicy(IDfId policyId, String stateName, String scope) throws DfException {
        setId("r_policy_id", policyId);
        int stateNameIndex;
        IDfPersistentObject lifecycleObject = getSession().getObject(policyId);
        if (stateName == null || stateName.length() == 0) {
            stateName = "0";
        }
        if (!Pattern.matches("^\\d+$", stateName)) {
            stateNameIndex = lifecycleObject.findString("state_name", stateName);
        } else {
            stateNameIndex = Integer.parseInt(stateName);
        }
        setInt("r_current_state", stateNameIndex);
        setString("_current_state", lifecycleObject.getRepeatingString("state_name", stateNameIndex));
        setString("_policy_name", lifecycleObject.getString("object_name"));
    }

    public void detachPolicy() throws DfException {
    }

    public void promote(String stateName, boolean b, boolean b1) throws DfException {
      System.out.println("MockSysObject.promote");
      System.out.println("stateName = " + stateName);
        if (stateName != null && stateName.length() > 0) {
            int indexOfStateName = getSession().getObject(getPolicyId()).findString("state_name", stateName);
            if ((indexOfStateName - getInt("r_current_state")) == 1 ||
                getSession().getObject(getPolicyId()).getRepeatingBoolean("allow_promote", indexOfStateName)) {
                setInt("r_current_state", indexOfStateName);
            } else {
                throw new DfException("can't promote to state: " + stateName);
            }
        } else {
            setInt("r_current_state", getInt("r_current_state") + 1);
        }
    }

    public boolean canPromote() throws DfException {
        return false;
    }

    public void schedulePromote(String string, IDfTime iDfTime, boolean b) throws DfException {
    }

    public void cancelScheduledPromote(IDfTime iDfTime) throws DfException {
    }

    public void demote(String stateName, boolean b) throws DfException {
        if (stateName != null && stateName.length() > 0) {
            int indexOfStateName = getSession().getObject(getPolicyId()).findString("state_name", stateName);
            if (((getInt("r_current_state") - indexOfStateName) == 1) ||
                getSession().getObject(getPolicyId()).getRepeatingBoolean("allow_demote", indexOfStateName)) {
                setInt("r_current_state", indexOfStateName);
            } else {
                throw new DfException("can't demote to state: " + stateName);
            }
        } else {
            setInt("r_current_state", getInt("r_current_state") - 1);
        }
    }

    public void scheduleDemote(String string, IDfTime iDfTime) throws DfException {
    }

    public void cancelScheduledDemote(IDfTime iDfTime) throws DfException {
    }

    public void suspend(String string, boolean b, boolean b1) throws DfException {
    }

    public boolean canSuspend() throws DfException {
        return false;
    }

    public void scheduleSuspend(String string, IDfTime iDfTime, boolean b) throws DfException {
    }

    public void cancelScheduledSuspend(IDfTime iDfTime) throws DfException {
    }

    public void resume(String string, boolean b, boolean b1, boolean b2) throws DfException {
    }

    public boolean canResume() throws DfException {
        return false;
    }

    public void scheduleResume(String string, IDfTime iDfTime, boolean b, boolean b1) throws DfException {
    }

    public void cancelScheduledResume(IDfTime iDfTime) throws DfException {
    }

    public IDfId addReference(IDfId iDfId, String string, String string1) throws DfException {
        return null;
    }

    public void refreshReference() throws DfException {
    }

    public IDfId getRemoteId() throws DfException {
        return null;
    }

    public IDfACL getACL() throws DfException {
        return iDfACL;
    }

    public void grant(String string, int i, String string1) throws DfException {
    }

    public void grantPermit(IDfPermit iDfPermit) throws DfException {
    }

    public boolean hasPermission(String string, String string1) throws DfException {
        return false;
    }

    public void revertACL() throws DfException {
    }

    public void revoke(String string, String string1) throws DfException {
    }

    public void revokePermit(IDfPermit iDfPermit) throws DfException {
    }

    public void setACL(IDfACL iDfACL) throws DfException {
       this.iDfACL = (MockDfACL) iDfACL;
    }

    public void useACL(String string) throws DfException {
    }

    public IDfList getPermissions() throws DfException {
        return null;
    }

    public IDfCollection getLocations(String string) throws DfException {
        return null;
    }

    public void link(String string) throws DfException {
      System.out.println("MockSysObject.link");
      System.out.println("string = " + string);

      link.add(string);

    }

    public void unlink(String string) throws DfException {
      System.out.println("MockSysObject.unlink");
      System.out.println("string = " + string);
      System.out.println("link.contains(string) = " + link.contains(string));
      System.out.println("link.size() = " + link.size());
      //link.clear();
      if(link.contains(string)&& link.size()>0){
        System.out.println("Found and now removing");
        link.remove(string);
      }


    }

    public String print(String string, boolean b, boolean b1, int i, int i1, int i2) throws DfException {
        return null;
    }

    public void prune(boolean b) throws DfException {
    }

    public IDfId queue(String string, String string1, int i, boolean b, IDfTime iDfTime, String string2) throws
                                                                                                         DfException {
      this.wasQueueCalled = true;
      this.targetObjName=string;
      queueCount++;
        return null;

    }

    public void registerEvent(String string, String string1, int i, boolean b) throws DfException {
    }

    public void unRegisterEvent(String string) throws DfException {
    }

    public IDfCollection getWorkflows(String string, String string1) throws DfException {
        return null;
    }

    public IDfCollection getRouters(String string, String string1) throws DfException {
        return null;
    }

    public IDfVersionLabels getVersionLabels() throws DfException {
        return null;
    }

    public IDfVirtualDocument asVirtualDocument(String string, boolean b) throws DfException {
        return null;
    }

    public boolean canDemote() throws DfException {
        return false;
    }

    public boolean isSuspended() throws DfException {
        return false;
    }

    public String getExceptionStateName() throws DfException {
        return null;
    }

    public String resolveAlias(String string) throws DfException {
        return null;
    }

    public void mount(String string) throws DfException {
    }

    public int getPermitEx(String string) throws DfException {
        return 0;
    }

    public void updatePartEx(IDfId iDfId, String string, double v, boolean b, boolean b1, int i, String string1, String string2) throws
                                                                                                                                 DfException {
    }

    public void lock() throws DfException {
    }

    public IDfId addESignature(String string, String string1, String string2, String string3, String string4, String string5, String string6, String string7, String string8, String string9) throws
                                                                                                                                                                                              DfException {
        return null;
    }

    public void verifyESignature() throws DfException {
    }

    public void addRenditionEx3(String string, String string1, int i, String string2, String string3, boolean b, boolean b1, boolean b2, String string4) throws
                                                                                                                                                         DfException {
    }

    public ByteArrayInputStream getContentEx3(String string, int i, String string1, boolean b) throws DfException {
        return null;
    }

    public boolean setContentEx2(ByteArrayOutputStream byteArrayOutputStream, String string, int i, boolean b) throws
                                                                                                               DfException {
        return false;
    }

    public String getPathEx2(String string, int i, String string1, boolean b) throws DfException {
        return null;
    }

    public void appendFileEx(String string, String string1) throws DfException {
    }

    public void appendContentEx(ByteArrayOutputStream byteArrayOutputStream, boolean b) throws DfException {
    }

    public void insertContentEx(ByteArrayOutputStream byteArrayOutputStream, int i, boolean b) throws DfException {
    }

    public void insertFileEx(String string, int i, String string1) throws DfException {
    }

    public IDfCollection getCollectionForContentEx3(String string, int i, String string1, boolean b) throws
                                                                                                     DfException {
        return null;
    }
  public List setResults(List results){
    System.out.println("results = " + results);
    System.out.println("this.results = " + this.results);
    this.results = results;
    return results;
  }
}