/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

import java.io.ByteArrayInputStream;
import java.util.*;

/**
 * Filename:    $RCSfile: MockTypedObject.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $
 * On:	$Date: 2009-06-05 19:06:20 $
 *
 * @author LAKENCH
 * @version $Revision: 1.3 $
 */
public class MockTypedObject implements IDfTypedObject, IDfTypedObjectInternal {
  private Map attributes = new HashMap();
  private IDfSessionManager iDfSessionManager;
  private IDfSession session;

  public IDfSession getSession() {
    if (session == null) {
      try {
        session = iDfSessionManager.getSession(null);
      } catch (DfServiceException e) {
        e.printStackTrace();
      }
    }
    return session;
  }

  public IDfId getObjectId() throws DfException {
    return new DfId(getString("r_object_id"));
  }

  public void appendBoolean(String string, boolean b) throws DfException {
  }

  public void appendDouble(String string, double v) throws DfException {
  }

  public void appendId(String string, IDfId iDfId) throws DfException {
  }

  public void appendInt(String string, int i) throws DfException {
  }

  public void appendString(String attrName, String value) throws DfException {
    if (!attributes.containsKey(attrName))
      attributes.put(attrName, new ArrayList());
    ((List) attributes.get(attrName)).add(value);
  }

  public void appendTime(String string, IDfTime iDfTime) throws DfException {
  }

  public void appendValue(String string, IDfValue iDfValue) throws DfException {
  }

  public boolean getBoolean(String string) throws DfException {
    return false;
  }

  public double getDouble(String string) throws DfException {
    return 0;
  }

  public IDfId getId(String string) throws DfException {
    return new DfId(getString(string));
  }

  public int getInt(String attrName) throws DfException {
    return Integer.parseInt(getString(attrName));
  }

  public String getString(String attrName) throws DfException {
    return getRepeatingString(attrName, 0);
  }

  public IDfTime getTime(String attrName) throws DfException {
    return (IDfTime) attributes.get(attrName);
  }

  public IDfValue getValue(String string) throws DfException {
    return null;
  }

  public boolean getRepeatingBoolean(String string, int i) throws DfException {
    return Boolean.valueOf(getRepeatingString(string, i)).booleanValue();
  }

  public double getRepeatingDouble(String string, int i) throws DfException {
    return 0;
  }

  public IDfId getRepeatingId(String string, int i) throws DfException {
    return null;
  }

  public int getRepeatingInt(String string, int i) throws DfException {
    return 0;
  }

  public String getRepeatingString(String string, int i) throws DfException {
    String value = null;
    if (attributes.containsKey(string)) {
      List values = (List) attributes.get(string);
      if (!values.isEmpty()) {
        value = (String) values.get(i);
      }
    } else {
      throw new DfException("attribute, \"" + string + "\" not found");
    }
    return value;
  }

  public IDfTime getRepeatingTime(String string, int i) throws DfException {
    return null;
  }

  public IDfValue getRepeatingValue(String string, int i) throws DfException {
    return null;
  }

 public String getAllRepeatingStrings(String string, String string1) throws DfException {
      String value = "";
      if ((string1 == null) || (string1 == "")) {
        string1 = ",";
    }
      if (attributes.containsKey(string)) {
            List values = (List) attributes.get(string);
            for (int i = 0;  i < values.size(); i++)
            {
              if (value == ""){
              value =  (String) values.get(i) ;
              }else{
              value =  (String) values.get(i)  + string1 + value;
              }
            }
        } else {
          throw new DfException("attribute, \"" + string + "\" not found");
      }

        return value;
    }

  public void insertBoolean(String string, int i, boolean b) throws DfException {
  }

  public void insertDouble(String string, int i, double v) throws DfException {
  }

  public void insertId(String string, int i, IDfId iDfId) throws DfException {
  }

  public void insertInt(String string, int i, int i1) throws DfException {
  }

  public void insertString(String string, int i, String string1) throws DfException {
  }

  public void insertTime(String string, int i, IDfTime iDfTime) throws DfException {
  }

  public void insertValue(String string, int i, IDfValue iDfValue) throws DfException {
  }

  public int findBoolean(String string, boolean b) throws DfException {
    return 0;
  }

  public int findDouble(String string, double v) throws DfException {
    return 0;
  }

  public int findId(String string, IDfId iDfId) throws DfException {
    return 0;
  }

  public int findInt(String string, int i) throws DfException {
    return 0;
  }

  public int findString(String attrName, String value) throws DfException {
    return ((List) attributes.get(attrName)).indexOf(value);
  }

  public int findTime(String string, IDfTime iDfTime) throws DfException {
    return 0;
  }

  public int findValue(String string, IDfValue iDfValue) throws DfException {
    return 0;
  }

  public void setBoolean(String string, boolean b) throws DfException {
  }

  public void setDouble(String string, double v) throws DfException {
  }

  public void setId(String attrName, IDfId value) throws DfException {
    setRepeatingId(attrName, 0, value);
  }

  public void setInt(String attrName, int value) throws DfException {
    setRepeatingInt(attrName, 0, value);
  }

  public void setString(String attrName, String value) throws DfException {
    setRepeatingString(attrName, 0, value);
  }

  public void setTime(String attrName, IDfTime iDfTime) throws DfException {
     attributes.put(attrName,iDfTime);
  }

  public void setValue(String string, IDfValue iDfValue) throws DfException {
  }

  public void setRepeatingBoolean(String string, int i, boolean b) throws DfException {
  }

  public void setRepeatingDouble(String string, int i, double v) throws DfException {
  }

  public void setRepeatingId(String attrName, int i, IDfId value) throws DfException {
    setRepeatingString(attrName, i, value.getId());
  }

  public void setRepeatingInt(String attrName, int i, int value) throws DfException {
    setRepeatingString(attrName, i, Integer.toString(value));
  }

  public void setRepeatingStrings(String attrName, List values) {
    if (!attributes.containsKey(attrName))
      attributes.put(attrName, new ArrayList(values.size()));
    ((List) attributes.get(attrName)).addAll(values);
  }

  public void setRepeatingString(String attrName, int i, String value) throws DfException {
    if (!attributes.containsKey(attrName))
      attributes.put(attrName, new ArrayList());
    ((List) attributes.get(attrName)).add(i, value);
  }

  public void setRepeatingTime(String string, int i, IDfTime iDfTime) throws DfException {
  }

  public void setRepeatingValue(String string, int i, IDfValue iDfValue) throws DfException {
  }

  public int getValueCount(String string) throws DfException {
    if (attributes.containsKey(string)) {
      return ((List) attributes.get(string)).size();
    } else {
      throw new DfException("attribute, \"" + string + "\" not found");
    }
  }

  public String dump() throws DfException {
    return null;
  }

  public Enumeration enumAttrs() throws DfException {
    return null;
  }

  public int findAttrIndex(String string) throws DfException {
    return 0;
  }

  public IDfAttr getAttr(int i) throws DfException {
    return new MockDfAttr((String) attributes.keySet().toArray()[i]);
  }

  public int getAttrCount() throws DfException {
    return attributes.size();
  }

  public int getAttrDataType(String string) throws DfException {
    return 0;
  }

  public boolean hasAttr(String string) throws DfException {
    return false;
  }

  public boolean isAttrRepeating(String string) throws DfException {
    return getValueCount(string) > 1;
  }

  public void remove(String string, int i) throws DfException {
    if (attributes.containsKey(string)) {
      ((List) attributes.get(string)).remove(i);
    } else {
      throw new DfException("attribute, \"" + string + "\" not found");
    }
  }

  public void removeAll(String string) throws DfException {
  }

  public void truncate(String string, int i) throws DfException {
  }

  public boolean isNull(String string) throws DfException {
    return false;
  }

  public void setNull(String string) throws DfException {
  }

  public IDfValue getValueAt(int i) throws DfException {
    return null;
  }

  public void setSessionManager(IDfSessionManager iDfSessionManager) throws DfException {
    this.iDfSessionManager = iDfSessionManager;
  }

  public IDfSessionManager getSessionManager() {
    return iDfSessionManager;
  }

  public long getLong(String string) throws DfException {
    return 0;
  }

  public long getRepeatingLong(String string, int i) throws DfException {
    return 0;
  }

  public String getLoginUserName() throws DfException {
    return null;
  }

  public IDfType getType(String string) throws DfException {
    return null;
  }

  public Enumeration enumValidationAttrNames() {
    return null;
  }

  public void removeValidationAttrName(String string) {
  }

  public void addValidationAttrName(String string) {
  }

  public void setSession(IDfSession session) {
    this.session = session;
  }

  public IDfCollection executeDocbaseScopedQuery(IDfId iDfId, IDfQuery iDfQuery, int i) throws DfException {
    return null;
  }

  public IDfAttr getAttr(String string) throws DfException {
    return null;
  }

  public IDfCollection executeQuery(IDfQuery iDfQuery, int i) throws DfException {
    return null;
  }

  public String apiGet(String string, String string1) throws DfException {
    return null;
  }

  public ByteArrayInputStream apiGetBytes(String string, String string1, String string2, int i) throws DfException {
    return null;
  }

  public IDfTypedObject makeTypedObject(String string) throws DfException {
    return null;
  }

  public IDfFolder getFolderByPath(String string) throws DfException {
    return null;
  }

  public IDfPersistentObject newObject(String string) throws DfException {
    return null;
  }

  public IDfPersistentObject getObject(IDfId iDfId) throws DfException {
    return null;
  }

  public IDfPersistentObject getObjectByQualification(String string) throws DfException {
    return null;
  }

  public IDfId getIdByQualification(String string) throws DfException {
    return null;
  }

  public String getDocbaseScope() throws DfException {
    return null;
  }

  public IDfUser getUser(String string) throws DfException {
    return null;
  }

  public IDfSession getSessionThatNeedsToBeReleased() throws DfException {
    return null;
  }

  public void releaseSession(IDfSession session) {
  }

  public IDfSession connectToDMCL(boolean b) throws DfException {
    return null;
  }

  public void disconnectFromDMCL(boolean b) throws DfException {
  }

  public void processPendingDisconnects() throws DfException {
  }

  public void cleanupSessionBeforeRelease(IDfSession session) throws DfException {
  }

  public IDfSession getAttachedSession() {
    return new MockSession("test_docbase_owner");
  }

  public void subscribeTransactionEvents() throws DfException {
  }

  public void refreshCachedData() throws DfException {
  }

  public void setSessionWithNewHelper(IDfSession session) {
  }

  public DfCommandBuffer buildCommandRoot(String method) throws DfException {
    DfCommandBuffer command = new DfCommandBuffer(method);
    command.appendArgument("s0");
    return command;
  }

  public DfAttrTable getAttrTable() throws DfException {
    return null;
  }
}