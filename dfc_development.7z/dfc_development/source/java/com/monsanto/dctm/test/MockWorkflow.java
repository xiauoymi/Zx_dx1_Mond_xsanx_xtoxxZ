/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.IDfWorkflow;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfWorkflowAttachment;
import com.documentum.fc.common.*;

/**
 * Filename:    $RCSfile: MockWorkflow.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrkaur $    	 On:	$Date: 2008-03-11 19:16:00 $
 *
 * @author rrkaur
 * @version $Revision: 1.2 $
 */
public class MockWorkflow extends MockPersistentObject implements IDfWorkflow {
  String objectName = null;
  String aliasId = null;
  public void execute() throws DfException {
  }

  public void restart(int i) throws DfException {
  }

  public void restartEx(int i, boolean b) throws DfException {
  }

  public void halt(int i) throws DfException {
  }

  public void haltEx(int i, int i1) throws DfException {
  }

  public void resume(int i) throws DfException {
  }

  public void abort() throws DfException {
  }

  public IDfId queue(String string, String string1, int i, boolean b, IDfTime iDfTime, String string2) throws DfException {
    return null;
  }

  public IDfId addPackage(String string, String string1, String string2, String string3, String string4, boolean b, IDfList iDfList) throws DfException {
    return null;
  }

  public IDfId addPackageEx(String string, String string1, String string2, String string3, String string4, boolean b, IDfList iDfList, int i) throws DfException {
    return null;
  }

  public void removePackage(String string, String string1, String string2) throws DfException {
  }

  public String getObjectName() throws DfException {
    return objectName;
  }

  public void setObjectName(String objName) throws DfException {
    objectName = objName;
  }

  public IDfId getProcessId() throws DfException {
    return null;
  }

  public void setProcessId(IDfId iDfId) throws DfException {
  }

  public String getCreatorName() throws DfException {
    return null;
  }

  public String getSupervisorName() throws DfException {
    return null;
  }

  public void setSupervisorName(String string) throws DfException {
  }

  public int getRuntimeState() throws DfException {
    return 0;
  }

  public IDfTime getStartDate() throws DfException {
    return null;
  }

  public int getNextSeqno() throws DfException {
    return 0;
  }

  public int getActivityCount() throws DfException {
    return 0;
  }

  public int getActSeqno(int i) throws DfException {
    return 0;
  }

  public String getActName(int i) throws DfException {
    return null;
  }

  public IDfId getActDefId(int i) throws DfException {
    return null;
  }

  public int getActErrorno(int i) throws DfException {
    return 0;
  }

  public int getActState(int i) throws DfException {
    return 0;
  }

  public boolean getRepeatInvoke(int i) throws DfException {
    return false;
  }

  public int getTriggerThresh(int i) throws DfException {
    return 0;
  }

  public int getTriggerInput(int i) throws DfException {
    return 0;
  }

  public int getTriggerRevert(int i) throws DfException {
    return 0;
  }

  public IDfTime getPreTimer(int i) throws DfException {
    return null;
  }

  public IDfTime getPostTimer(int i) throws DfException {
    return null;
  }

  public int getTotalWitem(int i) throws DfException {
    return 0;
  }

  public int getCompleteWitem(int i) throws DfException {
    return 0;
  }

  public String getLastPerformer(int i) throws DfException {
    return null;
  }

  public IDfId getLastWitemId(int i) throws DfException {
    return null;
  }

  public int getPerformerFlag(int i) throws DfException {
    return 0;
  }

  public void haltAll() throws DfException {
  }

  public void resumeAll() throws DfException {
  }

  public IDfId getAliasSetId() throws DfException {
    //TODO implement
    return new DfId((String) aliasId);
  }
  public String setAliasId(String aliasId){
    return this.aliasId = aliasId;
  }

  public int getInstructionsCount() throws DfException {
    return 0;
  }

  public String getInstructions(int i) throws DfException {
    return null;
  }

  public void setInstructions(int i, String string) throws DfException {
  }

  public void setPerformers(String string, IDfList iDfList) throws DfException {
  }

  public IDfList getPerformerActivityNames() throws DfException {
    return null;
  }

  public IDfList getPerformers(String string) throws DfException {
    return null;
  }

  public void updateSupervisorName(String string) throws DfException {
  }

  public IDfId addAttachment(String string, IDfId iDfId) throws DfException {
    return null;
  }

  public void removeAttachment(IDfId iDfId) throws DfException {
  }

  public IDfCollection getAttachments() throws DfException {
    return null;
  }

  public IDfWorkflowAttachment getAttachment(IDfId iDfId) throws DfException {
    return null;
  }

  public void setPackageSkillLevel(String string, int i) throws DfException {
  }

  public int getPackageSkillLevel(String string) throws DfException {
    return 0;
  }
}