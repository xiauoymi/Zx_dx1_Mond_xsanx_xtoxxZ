/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

import java.util.List;

/**
 * Filename:    $RCSfile: MockWorkitem.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: rrkaur $    	 On:	$Date: 2008-03-11 19:16:23 $
 *
 * @author rrkaur
 * @version $Revision: 1.3 $
 */
public class MockWorkitem extends MockPersistentObject implements IDfWorkitem {
  public boolean isAqcquirecalled = false;
  private List results;

  public IDfList getNextActivityNames() throws DfException {
    return null;
  }

  public IDfList getPreviousActivityNames() throws DfException {
    return null;
  }

  public IDfCollection getPackages(String string) throws DfException {
    IDfCollection collection = new MockDfCollection(true, results);
    return collection;
  }
  public List setResults(List results){
    this.results = results;
    return results;
  }

  public IDfId addPackage(String string, String string1, IDfList iDfList) throws DfException {
    return null;
  }

  public IDfId addPackageEx(String string, String string1, IDfList iDfList, int i) throws DfException {
    return null;
  }

  public IDfPackage getPackage(IDfId iDfId) throws DfException {
    return null;
  }

  public void removePackage(String string) throws DfException {
  }

  public void acquire() throws DfException {
    isAqcquirecalled = true;
  }

  public void repeat(IDfList iDfList) throws DfException {
  }

  public void setOutput(IDfList iDfList) throws DfException {
  }

  public void delegateTask(String string) throws DfException {
  }

  public IDfActivity getActivity() throws DfException {
    return null;
  }

  public boolean isDelegatable() throws DfException {
    return false;
  }

  public boolean isRepeatable() throws DfException {
    return false;
  }

  public void pause() throws DfException {
  }

  public void resume() throws DfException {
  }

  public void complete() throws DfException {
  }

  public void completeEx2(int i, String string, IDfId iDfId, int i1, double v) throws DfException {
  }

  public IDfId getWorkflowId() throws DfException {
    Object id = "123455";
    return new DfId((String) id);
  }

  public int getActSeqno() throws DfException {
    return 0;
  }

  public String getPerformerName() throws DfException {
    return null;
  }

  public IDfTime getCreationDate() throws DfException {
    return null;
  }

  public IDfTime getDueDate() throws DfException {
    return null;
  }

  public int getPriority() throws DfException {
    return 0;
  }

  public IDfId getAutoMethodId() throws DfException {
    return null;
  }

  public int getReturnValue() throws DfException {
    return 0;
  }

  public IDfId getExecResultId() throws DfException {
    return null;
  }

  public boolean isExecLaunch() throws DfException {
    return false;
  }

  public boolean isExecTimeOut() throws DfException {
    return false;
  }

  public String getExecOsError() throws DfException {
    return null;
  }

  public String getOutputPort(int i) throws DfException {
    return null;
  }

  public int getOutputPortCount() throws DfException {
    return 0;
  }

  public String getExtendedPerformer(int i) throws DfException {
    return null;
  }

  public int getExtendedPerformerCount() throws DfException {
    return 0;
  }

  public int getRuntimeState() throws DfException {
    return 0;
  }

  public IDfId getQueueItemId() throws DfException {
    return null;
  }

  public IDfId getActDefId() throws DfException {
    return null;
  }

  public boolean isSignOffRequired() throws DfException {
    return false;
  }

  public boolean isManualTransition() throws DfException {
    return false;
  }

  public IDfList getRejectActivities() throws DfException {
    return null;
  }

  public IDfList getForwardActivities() throws DfException {
    return null;
  }

  public void setOutputByActivities(IDfList iDfList) throws DfException {
  }

  public IDfCollection getMissingOutputPackages() throws DfException {
    return null;
  }

  public void completeEx(int i, String string, IDfId iDfId) throws DfException {
  }

  public boolean isManualExecution() throws DfException {
    return false;
  }

  public IDfTime getLaunchTimeout() throws DfException {
    return null;
  }

  public void setPerformers(String string, IDfList iDfList) throws DfException {
  }

  public void setPriority(int i) throws DfException {
  }

  public IDfId addAttachment(String string, IDfId iDfId) throws DfException {
    return null;
  }

  public void removeAttachment(IDfId iDfId) throws DfException {
  }

  public IDfCollection getAttachments() throws DfException {
    return null;
  }

  public IDfWorkflowAttachment getAttachment(IDfId iDfId) throws DfException {
    return null;
  }

  public IDfCollection getAllPackages(String string) throws DfException {
    return null;
  }

  public double getUserCost() throws DfException {
    return 0;
  }

  public int getUserTime() throws DfException {
    return 0;
  }

  public IDfId queue(String string, String string1, int i, boolean b, IDfTime iDfTime, String string2) throws
      DfException {
    return null;
  }

  public void setPackageSkillLevel(String string, int i) throws DfException {
  }

  public int getSkillLevel() throws DfException {
    return 0;
  }
}