/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn;

import com.documentum.fc.client.*;
import com.documentum.fc.commands.admin.DfAdminCommand;
import com.documentum.fc.commands.admin.DfImportUser;
import com.documentum.fc.commands.admin.IDfAdminCommand;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.impl.DfLdifFileReader;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.utils.DFCSessionUtils;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Filename:    $RCSfile: ImportUserMethod.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2008-08-05 13:46:07 $
 *
 * @author lakench
 * @version $Revision: 1.5 $
 */
public class ImportUserMethod implements IDmMethod {
    private String docbase = null;
    private String userid = null;
    private String ticket = null;
    private String userinfoid = null;
    private String additionalGroups = null;
    private IDfSessionManager superUserSessionManager;
    public List importFileContents;

    public void execute(Map map, OutputStream outputStream) throws Exception {
        IDfSession session = null;
        try {
            boolean validArguments = validateArguments(map, outputStream);
            if (map.containsKey("additional_groups")) {
                additionalGroups = ((String[]) map.get("additional_groups"))[0];
            }
            if (validArguments) {
                session = getSuperUserSession(docbase, userid, ticket, outputStream);
                if (session != null) {
                    createDctmUserObject(session);
                }
            }
            boolean success = validArguments && session != null;
            if (success) writeMessage(outputStream, "17000," +
                                                    getAttributeFromImportFileContents("user_os_name").toUpperCase() +
                                                    ",1");
        } catch (Exception e) {
            DfLogger.error(this, "couldn't import/update user", null, e);
            throw e;
        } finally {
            if (session != null) {
                superUserSessionManager.release(session);
            }
        }
    }

    private void createDctmUserObject(IDfSession session) throws DfException {
        IDfSysObject userInfoObject = (IDfSysObject) session.getObject(new DfId(userinfoid));
        DfImportUser importUserObj = (DfImportUser) DfAdminCommand.getCommand(IDfAdminCommand.IMPORT_USER);
        importUserObj.setFilePath(userInfoObject.getFile(null));
        importUserObj.setOverwriteUser(true);
        importUserObj.setDefaultHomeDocbase(session.getDocbaseName());
        importUserObj.execute(session);
        DfLdifFileReader reader = new DfLdifFileReader(userInfoObject.getFile(null));
        try {
            reader.open();
            importFileContents = reader.readSection();
            addUserToAdditionalGroups(session, getAttributeFromImportFileContents("user_name"), additionalGroups);
        } catch (IOException e) {
            throw new DfException("Error: couldn't add user to groups", e);
        }
    }

    private void addUserToAdditionalGroups(IDfSession session, String userName, String additionalGroups) throws
                                                                                                         DfException {
        if (additionalGroups != null && additionalGroups.length() > 0) {
            StringTokenizer groups = new StringTokenizer(additionalGroups, ",");
            while (groups.hasMoreTokens()) {
                String group = groups.nextToken().trim();
                IDfGroup groupObject = session.getGroup(group);
                groupObject.addUser(userName);
                groupObject.save();
            }
        }
    }
    private String getAttributeFromImportFileContents(String attribute) {
        Iterator lines = importFileContents.iterator();
        while (lines.hasNext()) {
            String[] line = (String[]) lines.next();
            if (line[0].equals(attribute)) {
                return line[1];
            }
        }
        return null;
    }

    private IDfSession getSuperUserSession(String docbase, String userid, String ticket, OutputStream outputStream) throws
                                                                                                              DfException,
                                                                                                                    IOException {
        IDfSession userSession = null;
        IDfSessionManager sessionManager = null;
        IDfSession superUserSession = null;
        IDfCollection groupCollection = null;
        boolean isUserInGroup = false;
        boolean haveClientCapability = false;
        boolean isGroupNull = false;

        try {
          sessionManager = getSessionManager(docbase, userid, ticket);
          userSession = sessionManager.getSession(docbase);
          superUserSession = null;
          IDfUser user = userSession.getUser(null);
          if (user != null && user.getClientCapability() >= DfUser.DF_CAPABILITY_COORDINATOR) {
            haveClientCapability = true;
            IDfGroup group = userSession.getGroup("authorized_requestors");
            if (group != null) {
              isGroupNull = true;
              if (group.isUserInGroup(user.getUserName())) {
                superUserSession = getSessionIfUserIsFoundInGroup(userSession,superUserSession,user,group);
                isUserInGroup = true;
              }else{
                groupCollection = group.getGroupsNames();
                while(groupCollection.next()){
                  group = userSession.getGroup(groupCollection.getString("groups_names"));
                  if(group!=null){
                    if(group.isUserInGroup(user.getUserName())){
                      superUserSession = getSessionIfUserIsFoundInGroup(userSession,superUserSession,user,group);
                      isUserInGroup = true;
                    }
                  }
                }
              }
            }
          }
          writeRespectiveMessage(haveClientCapability,isGroupNull,isUserInGroup,outputStream);
        }finally {
          releaseSessionAndCollection(groupCollection,userSession, sessionManager);
        }
        return superUserSession;
    }


  private void releaseSessionAndCollection(IDfCollection groupCollection, IDfSession userSession, IDfSessionManager sessionManager)
      throws DfException {
    if(groupCollection !=null){
      groupCollection.close();
    }
    if (userSession != null) {
      sessionManager.release(userSession);
    }
  }
  private void writeRespectiveMessage(boolean haveClientCapability, boolean isGroupNull , boolean isUserInGroup, OutputStream outputStream)throws
                                                                                                              IOException{
    if(!haveClientCapability){
      writeMessage(outputStream, "Error: You don't have permission to add users");
    }else if(!isGroupNull){
      writeMessage(outputStream, "Error: Couldn't find authorized requestors group");
    }else if (!isUserInGroup) {
      writeMessage(outputStream,"Error: Couldn't find user in authorized requestors group or sub group");
    }

  }
  private IDfSession getSessionIfUserIsFoundInGroup(IDfSession userSession,IDfSession superUserSession,IDfUser user,IDfGroup group) throws
                                                                                                              DfException{
     String installOwner = userSession.getServerConfig().getString("r_install_owner");
     superUserSessionManager = getSessionManager(docbase, installOwner, "");
     superUserSession = superUserSessionManager.getSession(docbase);
     return superUserSession;

   }
    protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
      return DFCSessionUtils.createSessionManager(docbase, userid, password);
    }

    private boolean validateArguments(Map map, OutputStream outputStream) throws IOException {
        boolean validArguments = true;

        if (map.containsKey("docbase")) {
            docbase = ((String[]) map.get("docbase"))[0];
        }
        if (map.containsKey("userid")) {
            userid = ((String[]) map.get("userid"))[0];
        }
        if (map.containsKey("ticket")) {
            ticket = ((String[]) map.get("ticket"))[0];
        }
        if (map.containsKey("userinfoid")) {
            userinfoid = ((String[]) map.get("userinfoid"))[0];
        }

        if (docbase == null || docbase.length() <= 0) {
            writeMessage(outputStream, "Error:");
            writeMessage(outputStream, "must supply docbase");
            validArguments = false;
        }
        if (userid == null || userid.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply userid");
            validArguments = false;
        }
        if (ticket == null || ticket.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply ticket");
            validArguments = false;
        }
        if (userinfoid == null || userinfoid.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply userinfoid");
            validArguments = false;
        }
        return validArguments;
    }

    private void writeMessage(OutputStream outputStream, String message) throws IOException {
        outputStream.write((message + "\n").getBytes());
    }
}