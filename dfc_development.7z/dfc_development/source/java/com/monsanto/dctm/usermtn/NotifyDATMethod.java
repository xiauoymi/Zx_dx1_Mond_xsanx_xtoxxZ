/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfAttr;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.JavaMail.JavaMailMailDocument;
import com.monsanto.Mail.MailDocument;
import com.monsanto.Mail.MessageParseException;
import com.monsanto.Util.FileUtil;
import com.monsanto.Util.StringUtils;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.dctm.utils.DFCSessionUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: NotifyDATMethod.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2008-01-25 19:45:10 $
 *
 * @author LAKENCH
 * @version $Revision: 1.8 $
 */
public class NotifyDATMethod implements IDmMethod {

    private String docbase = null;
    private String userid = null;

    public static final String DOCBASE_ARG_NAME = "docbase_name";
    public static final String USERID_ARG_NAME = "user";
    private IDfSessionManager sessionManager;
    public static final String EMAILBODY = "The users in the attached csv have been added to Documentum";
    public static final String EMAILSUBJECT = "[STLSA]EEDOCU";
    public static final String EMAILRECIPIENT1 = "magictsd@monsanto.com";
    public static final String EMAILRECIPIENT2 = "dgt@monsanto.com";
    public static final String EMAILSENDER = "eedocu@monsanto.com";

    public static final String RECIPIENT_ARG_NAME = "recipients";
//    private String recipient = EMAILRECIPIENT1;
    public static List recipients = new ArrayList();
    private String sender = EMAILSENDER;
    private static final String LINESEPARATOR = System.getProperty("line.separator");
    private static final String QUERY = "select r_object_id from dm_document where object_name = 'Result.import_user' and title like '%status code (0)' and FOLDER('/Temp')";
    private static final String HEADERROW = "SystemID,UserCode,Active" + LINESEPARATOR;
    public static final String SENDER_ARG_NAME = "sender";

    public void execute(Map map, OutputStream outputStream) throws Exception {
        recipients.add(EMAILRECIPIENT1);
        recipients.add(EMAILRECIPIENT2);
        boolean validArguments = validateArguments(map, outputStream);
        if (validArguments) {
            IDfSession session = null;
            File attachment = null;
            try {
                session = getSession(docbase, userid);
                Iterator results = executeDQL(QUERY, session).iterator();
                attachment = getTempFile();
                StringBuffer attachmentContent = new StringBuffer(HEADERROW);
                List objectsToDestroy = new ArrayList();
                while (results.hasNext()) {
                    IDfSysObject result = (IDfSysObject) session.getObject(new DfId(((String[]) results.next())[0]));
                    String fileName = result.getFile(null);
                    String resultContent = FileUtil.read(fileName);
                    if (resultContent.toLowerCase().indexOf("error") == -1) {
                        attachmentContent.append(resultContent);
                        objectsToDestroy.add(result);
                    }
                }
                FileUtil.write(attachment.getAbsolutePath(), attachmentContent.toString());
                generateMailDocument(recipients, sender, attachment.getAbsolutePath()).send();
                destroyObjects(objectsToDestroy.iterator());
                writeMessage(outputStream, "success");
                writeMessage(outputStream, attachmentContent.toString());
            } finally {
                if (session != null) {
                    sessionManager.release(session);
                }
                if (attachment != null) {
                    deleteTempFile(attachment);
                }
            }
        }
    }

    private void destroyObjects(Iterator objectsToDestroy) throws DfException {
        while (objectsToDestroy.hasNext()) {
            ((IDfSysObject) objectsToDestroy.next()).destroy();
        }

    }

    protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
        return DFCSessionUtils.createSessionManager(docbase, userid, password);
    }

    protected IDfQuery createIDfQuery(String query) {
        IDfQuery dfQuery = new DfQuery();
        dfQuery.setDQL(query);
        return dfQuery;
    }

    protected File getTempFile() throws IOException {
        return File.createTempFile("Documentum_Users", ".csv");
    }

    protected void deleteTempFile(File file) {
        file.delete();
    }

    private boolean validateArguments(Map map, OutputStream outputStream) throws IOException {
        boolean validArguments = true;

        if (map.containsKey(DOCBASE_ARG_NAME)) {
            docbase = ((String[]) map.get(DOCBASE_ARG_NAME))[0];
        }
        if (map.containsKey(USERID_ARG_NAME)) {
            userid = ((String[]) map.get(USERID_ARG_NAME))[0];
        }
        if (map.containsKey(RECIPIENT_ARG_NAME)) {
//          recipients.add(EMAILRECIPIENT1);
//          recipients.add(EMAILRECIPIENT2);
          recipients = (List) map.get(RECIPIENT_ARG_NAME);
        }
        if (map.containsKey(SENDER_ARG_NAME)) {
            sender = ((String[]) map.get(SENDER_ARG_NAME))[0];
        }

        if (docbase == null || docbase.length() <= 0) {
            writeMessage(outputStream, "Error:");
            writeMessage(outputStream, "must supply docbase");
            validArguments = false;
        }
        if (userid == null || userid.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply userid");
            validArguments = false;
        }
        return validArguments;
    }

    private void writeMessage(OutputStream outputStream, String message) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
        bufferedWriter.write((message));
        bufferedWriter.newLine();
        bufferedWriter.flush();
    }

    private IDfSession getSession(String docbase, String userid) throws DfException {
        sessionManager = getSessionManager(docbase, userid, null);
        return sessionManager.getSession(docbase);
    }

    private List createListFromCollection(IDfCollection col) throws DfException {
        String value;
        ArrayList list = new ArrayList();
        while (col.next()) {
            int attrCount = col.getAttrCount();
            String[] row = new String[attrCount];
            for (int i = 0; i < attrCount; i++) {
                IDfAttr attr = col.getAttr(i);
                String attrName = attr.getName();
                value = col.getString(attrName);
                row[i] = value;
            }
            list.add(row);
        }
        return list;
    }

    private List executeDQL(String query, IDfSession sess) throws DfException {
        IDfCollection col = null;
        IDfQuery qry = createIDfQuery(query);
        List results = new ArrayList();
        try {
            col = qry.execute((IDfSession) sess, IDfQuery.DF_READ_QUERY);
            results = createListFromCollection(col);
        } finally {
            if (col != null) {
                col.close();
            }
        }
        return results;
    }

    protected MailDocument generateMailDocument(List recipients, String sender, String attachmentFilename) throws
                                                                                                            MessageParseException {
        return new JavaMailMailDocument(generateMailRequestXML(recipients, sender, attachmentFilename));
    }

    private Document generateMailRequestXML(List recipients, String sender, String attachmentFilename) {
        Document outputDoc = DOMUtil.newDocument();
        Element rootElement = outputDoc.createElement("REQUEST");
        outputDoc.appendChild(rootElement);

        // Build the response message header information.
        Element emailHeader = outputDoc.createElement("HEADER");
        for (int i = 0; i < recipients.size(); i++)
        {
          DOMUtil.addChildElement(emailHeader, "TO", recipients.get(i).toString());
        }
        DOMUtil.addChildElement(emailHeader, "FROM", sender);
        DOMUtil.addChildElement(emailHeader, "SUBJECT", EMAILSUBJECT);

        //Add the header to outgoing message
        rootElement.appendChild(emailHeader);

        Element emailBody = outputDoc.createElement("BODY");
        DOMUtil.addChildElement(emailBody, "LINE", EMAILBODY);
        rootElement.appendChild(emailBody);

        if (!StringUtils.isNullOrEmpty(attachmentFilename)) {
            Element attachment = outputDoc.createElement("ATTACHMENT");
            DOMUtil.addChildElement(attachment, "FILENAME", attachmentFilename);
            rootElement.appendChild(attachment);
        }
        return outputDoc;
    }
}