/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfList;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: ImportUserMethod_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2008-08-05 13:45:43 $
 *
 * @author lakench
 * @version $Revision: 1.6 $
 */
public class ImportUserMethod_AT extends TestCase {
    private static final String TESTUSER_JOEMINER = "Joe Miner";
    private static final String TESTUSERID_JOEMINER = "joeminer";
    private static final String TESTDOMAIN = "north_america";
    public static final String TESTEMAILSUFFIX = "@monsanto.com";
    private static final String TESTADDRESS_JOEMINER = TESTUSERID_JOEMINER + TESTEMAILSUFFIX;
    private static final String TESTUSERSOURCE = "domain only";
    private static final String TESTACLNAME = "testaclname";
    private static final String TESTACLDOMAIN = "stltst03";
    private static final String TESTDOCBASE = "stltst03";
    private static final String TESTFOLDER = "/testfolder";
    private static final String TESTANOTHERFOLDER = "/testanotherfolder";
    private static final int TESTUSERCLIENTCAPABILITY = DfUser.DF_CAPABILITY_CONSUMER;
    private static final int TESTAUTHORCLIENTCAPABILITY = DfUser.DF_CAPABILITY_CONTRIBUTOR;
    private static final String TESTUSERGROUP = "testusergroup1";
    private static final String ANOTHER_USER_GROUP = "testusergroup2";
    private static final String ONE_MORE_USER_GROUP = "testusergroup3";
    private static final String TESTAUTHORGROUP = "testauthorgroup1";
    private static final String ANOTHER_AUTHOR_GROUP = "testauthorgroup2";
    private static final String ONE_MORE_AUTHOR_GROUP = "testauthorgroup3";

    private IDfCollection methodResults = null;

    public static final String USER_NAME = "user_name";
    public static final String USER_OS_NAME = "user_os_name";
    public static final String USER_OS_DOMAIN = "user_os_domain";
    public static final String USER_ADDRESS = "user_address";
    public static final String USER_SOURCE = "user_source";
    public static final String USER_GROUP_NAME = "user_group_name";
    public static final String ACL_NAME = "acl_name";
    public static final String ACL_DOMAIN = "acl_domain";
    public static final String DEFAULT_FOLDER = "default_folder";
    public static final String CLIENT_CAPABILITY = "client_capability";
    public static final String OBJECT_TYPE = "object_type";
    public static final String DM_USER = "dm_user";
    public static final String ELEMENT_SEPARATOR = ";#";
    public static final String NAME_VALUE_SEPARATOR = ":";
    public static final String ADDITIONAL_GROUPS = "additional_groups";
    public static final String DEFAULT_DOMAIN = "north_america";
    public static final String EMAIL_SUFFIX = "@monsanto.com";
    public static final String DEFUALT_USER_SOURCE = "domain only";
  public static final String USER_LOGIN_DOMAIN = "user_login_domain";
  public static final String USER_LOGIN_NAME = "user_login_name";

  public void testCreateNewUserThenUpdate() throws Exception {
      IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, "devl30", "devl30");
      IDfSession session = null;
      IDfUser user = null;
      try {
          session = sessionManager.getSession(TESTDOCBASE);

          runImportUserMethod(session, TESTUSERCLIENTCAPABILITY, TESTFOLDER,
                              TESTUSERGROUP, ANOTHER_USER_GROUP + "," + ONE_MORE_USER_GROUP);

          IDfId newUserResultsId = assertSuccessfulResultsCollection();
          session.getObject(newUserResultsId).destroy();
          user = session.getUser(TESTUSER_JOEMINER);
          assertUserState(user, session);

          runImportUserMethod(session, TESTAUTHORCLIENTCAPABILITY, TESTANOTHERFOLDER, TESTAUTHORGROUP,
                              ANOTHER_AUTHOR_GROUP + "," + ONE_MORE_AUTHOR_GROUP);

          IDfId updatedUserResultsId = assertSuccessfulResultsCollection();
          session.getObject(updatedUserResultsId).destroy();
          user = session.getUser(TESTUSER_JOEMINER);

          assertAuthorState(user, session);
          assertTrue(session.getGroup(TESTUSERGROUP).isUserInGroup(TESTUSER_JOEMINER));
          assertAdditionalUserGroupMembership(session);
      } finally {
          if (session != null) {
              if (user != null) {
                  IDfSessionManager sysAdminSessionManager = DFCSessionUtils
                          .createSessionManager(TESTDOCBASE, "devl29", "devl29");
                  IDfSession sysAdminSession = sysAdminSessionManager.getSession(TESTDOCBASE);
                  sysAdminSession.getUser(TESTUSER_JOEMINER).destroy();
                  sysAdminSessionManager.release(sysAdminSession);
              }
              sessionManager.release(session);
          }
      }
  }

    public void testCreateNewUserThenUpdateUsingUserWithSpacesInName() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, "devl24", "devl24");
        IDfSession session = null;
        IDfUser user = null;
        try {
            session = sessionManager.getSession(TESTDOCBASE);
            runImportUserMethod(session, TESTUSERCLIENTCAPABILITY, TESTFOLDER,
                                TESTUSERGROUP, ANOTHER_USER_GROUP + "," + ONE_MORE_USER_GROUP);

            IDfId newUserResultsId = assertSuccessfulResultsCollection();
            session.getObject(newUserResultsId).destroy();
            user = session.getUser(TESTUSER_JOEMINER);
            assertUserState(user, session);

            runImportUserMethod(session, TESTAUTHORCLIENTCAPABILITY, TESTANOTHERFOLDER, TESTAUTHORGROUP,
                                ANOTHER_AUTHOR_GROUP + "," + ONE_MORE_AUTHOR_GROUP);

            IDfId updatedUserResultsId = assertSuccessfulResultsCollection();
            session.getObject(updatedUserResultsId).destroy();
            user = session.getUser(TESTUSER_JOEMINER);
            assertAuthorState(user, session);
            assertTrue(session.getGroup(TESTUSERGROUP).isUserInGroup(TESTUSER_JOEMINER));
            assertAdditionalUserGroupMembership(session);
        } finally {
            if (session != null) {
                if (user != null) {
                    IDfSessionManager sysAdminSessionManager = DFCSessionUtils
                            .createSessionManager(TESTDOCBASE, "devl29", "devl29");
                    IDfSession sysAdminSession = sysAdminSessionManager.getSession(TESTDOCBASE);
                    sysAdminSession.getUser(TESTUSER_JOEMINER).destroy();
                    sysAdminSessionManager.release(sysAdminSession);
                }
                sessionManager.release(session);
            }
        }
    }

  public void testCreateNewUserThenUpdateUsingUserWithinGroup() throws Exception {
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, "devl15", "devl15");
        IDfSession session = null;
        IDfUser user = null;
        try {
            session = sessionManager.getSession(TESTDOCBASE);

            runImportUserMethod(session, TESTUSERCLIENTCAPABILITY, TESTFOLDER,
                                TESTUSERGROUP, ANOTHER_USER_GROUP + "," + ONE_MORE_USER_GROUP);

            IDfId newUserResultsId = assertSuccessfulResultsCollection();
          //System.out.println("newUserResultsId = " + newUserResultsId);
            session.getObject(newUserResultsId).destroy();
            user = session.getUser(TESTUSER_JOEMINER);
          //System.out.println("user = " + user);
            assertUserState(user, session);

            runImportUserMethod(session, TESTAUTHORCLIENTCAPABILITY, TESTANOTHERFOLDER, TESTAUTHORGROUP,
                                ANOTHER_AUTHOR_GROUP + "," + ONE_MORE_AUTHOR_GROUP);

            IDfId updatedUserResultsId = assertSuccessfulResultsCollection();
            session.getObject(updatedUserResultsId).destroy();
            user = session.getUser(TESTUSER_JOEMINER);

            assertAuthorState(user, session);
            assertTrue(session.getGroup(TESTUSERGROUP).isUserInGroup(TESTUSER_JOEMINER));
            assertAdditionalUserGroupMembership(session);
        } finally {
            if (session != null) {
                if (user != null) {
                    IDfSessionManager sysAdminSessionManager = DFCSessionUtils
                            .createSessionManager(TESTDOCBASE, "devl29", "devl29");
                    IDfSession sysAdminSession = sysAdminSessionManager.getSession(TESTDOCBASE);
                    sysAdminSession.getUser(TESTUSER_JOEMINER).destroy();
                    sysAdminSessionManager.release(sysAdminSession);
                }
                sessionManager.release(session);
            }
        }
    }

    private void assertAuthorState(IDfUser user, IDfSession session) throws DfException {
        assertMostOfUserProperties(user, TESTAUTHORGROUP);
        assertEquals(TESTANOTHERFOLDER, user.getDefaultFolder());
        assertEquals(TESTAUTHORCLIENTCAPABILITY, user.getClientCapability());
        assertTrue(session.getGroup(TESTAUTHORGROUP).isUserInGroup(TESTUSER_JOEMINER));
        assertAdditionalAuthorGroupMembership(session);
    }

    private void assertUserState(IDfUser user, IDfSession session) throws DfException {
        assertNotNull(user);
        assertMostOfUserProperties(user, TESTUSERGROUP);
        assertEquals(TESTFOLDER, user.getDefaultFolder());
        assertEquals(TESTUSERCLIENTCAPABILITY, user.getClientCapability());
        assertTrue(session.getGroup(TESTUSERGROUP).isUserInGroup(TESTUSER_JOEMINER));
        assertAdditionalUserGroupMembership(session);
    }

    private void assertAdditionalAuthorGroupMembership(IDfSession session) throws DfException {
        assertTrue(session.getGroup(ANOTHER_AUTHOR_GROUP).isUserInGroup(TESTUSER_JOEMINER));
        assertTrue(session.getGroup(ONE_MORE_AUTHOR_GROUP).isUserInGroup(TESTUSER_JOEMINER));
    }

    private void assertAdditionalUserGroupMembership(IDfSession session) throws DfException {
        assertTrue(session.getGroup(ANOTHER_USER_GROUP).isUserInGroup(TESTUSER_JOEMINER));
        assertTrue(session.getGroup(ONE_MORE_USER_GROUP).isUserInGroup(TESTUSER_JOEMINER));
    }

    private IDfId assertSuccessfulResultsCollection() throws DfException {
        assertNotNull(methodResults);
        assertTrue(methodResults.next());
        assertFalse(methodResults.getBoolean("launch_failed"));
        assertNotNull(methodResults.getId("result"));
        assertEquals(0, methodResults.getInt("method_return_val"));
        assertFalse(methodResults.getBoolean("timed_out"));
        IDfId resultsId = methodResults.getId("result_doc_id");
        assertNotNull(resultsId);
        assertFalse(methodResults.next());
        methodResults.close();
        return resultsId;
    }

    private void assertMostOfUserProperties(IDfUser user, String defaultGroup) throws DfException {
        assertEquals(TESTUSER_JOEMINER, user.getUserName());
        assertEquals(TESTUSERID_JOEMINER, user.getUserOSName());
        assertEquals(TESTDOMAIN, user.getUserOSDomain());
        assertEquals(TESTADDRESS_JOEMINER, user.getUserAddress());
        assertEquals(TESTUSERSOURCE, user.getUserSourceAsString());
        assertEquals(defaultGroup, user.getUserGroupName());
        assertEquals(TESTACLNAME, user.getACLName());
        assertEquals(TESTACLDOMAIN, user.getACLDomain());
        assertEquals(TESTUSERID_JOEMINER, user.getUserLoginName());
        assertEquals(TESTDOMAIN, user.getString("user_login_domain"));
    }

    private File getUserFile(int clientCapability, String testfolder, String defaultGroup) throws DfException {
        return getTempFile(getUserInfo(clientCapability, testfolder, defaultGroup));
    }

    private String getUserInfo(int clientCapability, String testfolder, String defaultGroup) {
        StringBuffer strbuff = new StringBuffer(OBJECT_TYPE).append(NAME_VALUE_SEPARATOR).append(DM_USER);
        addNameValuePair(strbuff, USER_NAME, TESTUSER_JOEMINER);
        addNameValuePair(strbuff, USER_OS_NAME, TESTUSERID_JOEMINER);
        addNameValuePair(strbuff, USER_OS_DOMAIN, TESTDOMAIN);
        addNameValuePair(strbuff, USER_ADDRESS, TESTUSERID_JOEMINER + TESTEMAILSUFFIX);
        addNameValuePair(strbuff, USER_SOURCE, TESTUSERSOURCE);
        addNameValuePair(strbuff, USER_GROUP_NAME, defaultGroup);
        addNameValuePair(strbuff, ACL_NAME, TESTACLNAME);
        addNameValuePair(strbuff, ACL_DOMAIN, TESTACLDOMAIN);
        addNameValuePair(strbuff, DEFAULT_FOLDER, testfolder);
        addNameValuePair(strbuff, CLIENT_CAPABILITY, Integer.toString(clientCapability));
        return strbuff.toString();
    }

    private void addNameValuePair(StringBuffer strbuff, String name, String value) {
        strbuff.append(ELEMENT_SEPARATOR).append(name).append(NAME_VALUE_SEPARATOR).append(value);
    }

    private File getTempFile(String userInfo) throws DfException {
        PrintWriter pw = null;
        File file = null;
        try {
            file = File.createTempFile("users", ".txt");
            pw = new PrintWriter(new FileWriter(file, true));
            String [] lines = userInfo.split(";#");
            for (int j = 0; j < lines.length; j++) {
                pw.println(lines[j]);
            }
            pw.println();
            pw.close();
        } catch (IOException ioe) {
            throw new DfException("Couldn't generate user import file", ioe);
        }
        return file;
    }

    private void runImportUserMethod(IDfSession session, int clientCapability, String folder, String defaultGroup, String additionalGroups) throws DfException {
        String userInfoObjectId = createUserInfoObject(session, clientCapability, folder, defaultGroup);
        List argumentNames = Arrays.asList(new String[]{"METHOD", "SAVE_RESULTS", "ARGUMENTS"});
        List argumentTypes = Arrays.asList(new String[]{"S", "B", "S"});

        List argumentValues = Arrays.asList(new String[]{"import_user", "TRUE", "'-docbase " + session.getDocbaseName() +
                                                                                " -userid " +
                                                                                session.getLoginInfo().getUser() +
                                                                                " -ticket " + session.getLoginTicket() +
                                                                                " -userinfoid " + userInfoObjectId +
                                                                                " -additional_groups " + additionalGroups + "'"});
        methodResults = session
                .apply(null, "DO_METHOD", createDfListFromList(argumentNames), createDfListFromList(argumentTypes),
                       createDfListFromList(argumentValues));
        IDfPersistentObject object = session.getObject(new DfId(userInfoObjectId));
        if (object != null) {
            object.destroy();
        }

    }

    private IDfList createDfListFromList(List list) throws DfException {
        DfClientX client = new DfClientX();
        IDfList dfList = client.getList();
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            dfList.appendString((String) iterator.next());
        }
        return dfList;
    }

    private String createUserInfoObject(IDfSession session, int clientCapability, String folder, String defaultGroup) throws DfException {
        File userFile = getUserFile(clientCapability, folder, defaultGroup);
        IDfSysObject document = (IDfSysObject) session.newObject("dm_document");
        document.setObjectName("New Users");
        document.setContentType("crtext");
        document.setFileEx(userFile.getAbsolutePath(), "crtext", 0, null);
        document.link("/Temp");
        document.save();
        userFile.delete();
        return document.getObjectId().getId();
    }
}