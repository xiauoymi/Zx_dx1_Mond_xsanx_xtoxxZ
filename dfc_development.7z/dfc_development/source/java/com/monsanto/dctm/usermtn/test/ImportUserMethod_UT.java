/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.test.MockDfGroup;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockDfUser;
import com.monsanto.dctm.test.MockSysObject;
import com.monsanto.dctm.usermtn.ImportUserMethod;
import junit.framework.TestCase;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: ImportUserMethod_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $
 * On:	$Date: 2008-08-05 13:45:52 $
 *
 * @author lakench
 * @version $Revision: 1.6 $
 */
public class ImportUserMethod_UT extends TestCase {
  private MockDfSessionManager sessionManager;
  private MockImportUserMethod mock;
  private ByteArrayOutputStream outputStream;
  private Map testArgs;
  //private List mockResults;

  private static final String TESTDOCBASE = "testdocbase";
  private static final String TESTUSERID = "testuserid";
  private static final String TESTUSERIDWITHSPACES = "test userid";
  private static final String TESTUSERWITHINSUBGROUP = "test subGroup";
  private static final String TESTTICKET = "testticket";
  private static final String TESTUSERINFOID = "testuserinfoid";
  private static final String DOCBASE_ARG_NAME = "docbase";
  private static final String USERID_ARG_NAME = "userid";
  private static final String TICKET_ARG_NAME = "ticket";
  private static final String USERINFOID_ARG_NAME = "userinfoid";
  private static final String ADDITIONALGROUPS_ARG_NAME = "additional_groups";
  private static final String TESTINVALIDUSERID = "testinvaliduserid";
  private static final String TESTDOMAIN = "testdomain";
  private static final String TESTUSERSOURCE = "testusersource";
  private static final String TESTGROUPNAME = "testgroupname";
  private static final String TESTACLNAME = "testaclname";
  private static final String TESTACLDOMAIN = "testacldomain";
  private static final int TESTCLIENTCAPABILITY = DfUser.DF_CAPABILITY_CONSUMER;
  private static final String TESTFOLDER = "/testfolder";
  private static final String TESTUSEROSNAME = "joeminer";
  private static final String TESTUSERADDRESS = TESTUSEROSNAME + "@monsanto.com";
  private static final String TESTUSERNAME = "Joe Miner";
  private static final String TESTINSTALLOWNER = "testinstallowner";
  private static final String ANOTHERTESTGROUPNAME = "anothertestgroupname";
  private static final String ANOTHERTESTACLNAME = "anothertestaclname";
  private static final String ANOTHER_USER_GROUP = "testusergroup1";
  private static final String ONE_MORE_USER_GROUP = "testusergroup2";
  private static final String ANOTHER_AUTHOR_GROUP = "testauthorgroup1";
  private static final String ONE_MORE_AUTHOR_GROUP = "testauthorgroup2";
  private static final String AUTHORIZED_REQUESTORS = "authorized_requestors";
  private static final String SUBGROUP = "subGroup";
  public MockSession superUserSession;

  protected void setUp() throws Exception {
    super.setUp();
    sessionManager = new MockDfSessionManager();
    mock = new MockImportUserMethod(sessionManager);
    outputStream = new ByteArrayOutputStream();
    testArgs = new HashMap();
    //mockResults = setupResults();
    testArgs.put(DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
    testArgs.put(TICKET_ARG_NAME, new String[]{TESTTICKET});
    testArgs.put(USERINFOID_ARG_NAME, new String[]{TESTUSERINFOID});
    testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERID});
    testArgs.put(ADDITIONALGROUPS_ARG_NAME, new String[]{ANOTHER_USER_GROUP + "," + ONE_MORE_USER_GROUP});
  }
  public void testCreate() throws Exception {
    ImportUserMethod method = new ImportUserMethod();
    assertTrue(method instanceof IDmMethod);
  }
  public void testValidateArguments() throws Exception {
    addUserProfileObjectToSuperUserSession();
    addValidUserToSession();
    testArgs.remove(DOCBASE_ARG_NAME);
    testArgs.remove(USERID_ARG_NAME);
    testArgs.remove(TICKET_ARG_NAME);
    testArgs.remove(USERINFOID_ARG_NAME);
    testArgs.remove(ADDITIONALGROUPS_ARG_NAME);

    mock.execute(testArgs, outputStream);

    assertEquals("Error:\nmust supply docbase\nmust supply userid\nmust supply ticket\nmust supply userinfoid\n",
        outputStream.toString());

    outputStream.reset();
    testArgs.put(DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
    mock.execute(testArgs, outputStream);
    assertEquals("Error:\nmust supply userid\nmust supply ticket\nmust supply userinfoid\n", outputStream.toString());

    outputStream.reset();
    testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERID});
    mock.execute(testArgs, outputStream);
    assertEquals("Error:\nmust supply ticket\nmust supply userinfoid\n", outputStream.toString());

    outputStream.reset();
    testArgs.put(TICKET_ARG_NAME, new String[]{TESTTICKET});
    mock.execute(testArgs, outputStream);
    assertEquals("Error:\nmust supply userinfoid\n", outputStream.toString());

    outputStream.reset();
    testArgs.put(USERINFOID_ARG_NAME, new String[]{TESTUSERINFOID});
    mock.execute(testArgs, outputStream);
    assertEquals("17000," + TESTUSEROSNAME.toUpperCase() + ",1\n", outputStream.toString());
  }
  public void testGotUserSession() throws Exception {
    addUserProfileObjectToSuperUserSession();
    addValidUserToSession();

    mock.execute(testArgs, outputStream);

    assertEquals("17000," + TESTUSEROSNAME.toUpperCase() + ",1\n", outputStream.toString());
    IDfSession userSession = mock.sessionManager.getSession(TESTDOCBASE, TESTUSERID);
    assertNotNull(userSession);
    assertEquals(TESTUSERID, userSession.getLoginUserName());
    assertEquals(TESTUSERID, userSession.getLoginInfo().getUser());
    assertEquals(TESTTICKET, userSession.getLoginInfo().getPassword());
    assertTrue(((MockSession) userSession).wasReleaseCalled);
  }
  public void testGotUserSessionForUserWithSpaces() throws Exception {
    testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERIDWITHSPACES});
    addUserProfileObjectToSuperUserSession();
    addUserWithSpacesToSession();

    mock.execute(testArgs, outputStream);

    assertEquals("17000," + TESTUSEROSNAME.toUpperCase() + ",1\n", outputStream.toString());
    IDfSession userSession = mock.sessionManager.getSession(TESTDOCBASE, TESTUSERIDWITHSPACES);
    assertNotNull(userSession);
    assertEquals(TESTUSERIDWITHSPACES, userSession.getLoginUserName());
    assertEquals(TESTUSERIDWITHSPACES, userSession.getLoginInfo().getUser());
    assertEquals(TESTTICKET, userSession.getLoginInfo().getPassword());
    assertTrue(((MockSession) userSession).wasReleaseCalled);

  }
  public void testGotUserSessionForUserWithinGroup() throws Exception{
      testArgs.put(USERID_ARG_NAME, new String[]{TESTUSERWITHINSUBGROUP});
      addUserProfileObjectToSuperUserSession();
      addUserWithinSubGroupToSession();

      mock.execute(testArgs, outputStream);

      assertEquals("17000," + TESTUSEROSNAME.toUpperCase() + ",1\n", outputStream.toString());
      IDfSession userSession = mock.sessionManager.getSession(TESTDOCBASE, TESTUSERWITHINSUBGROUP);
      assertNotNull(userSession);
      assertEquals(TESTUSERWITHINSUBGROUP, userSession.getLoginUserName());
      assertEquals(TESTUSERWITHINSUBGROUP, userSession.getLoginInfo().getUser());
      assertEquals(TESTTICKET, userSession.getLoginInfo().getPassword());
      assertTrue(((MockSession) userSession).wasReleaseCalled);

}
  public void testGotSuperUserSession() throws Exception {
    addValidUserToSession();

    try {
      mock.execute(testArgs, outputStream);
    } catch (DfException e) {
      //expected path
      IDfSession userSession = mock.sessionManager.getSession(TESTDOCBASE, TESTUSERID);
      assertNotNull(userSession);
      assertEquals(TESTUSERID, userSession.getLoginUserName());
      assertEquals(TESTUSERID, userSession.getLoginInfo().getUser());
      assertEquals(TESTTICKET, userSession.getLoginInfo().getPassword());
      assertTrue(((MockSession) userSession).wasReleaseCalled);

      assertEquals(sessionManager, mock.sessionManager);
      IDfSession actualSuperUserSession = mock.sessionManager.getSession(TESTDOCBASE, TESTINSTALLOWNER);
      assertNotNull(actualSuperUserSession);
      assertEquals(TESTINSTALLOWNER, actualSuperUserSession.getLoginUserName());
      assertEquals(TESTINSTALLOWNER, actualSuperUserSession.getLoginInfo().getUser());
      assertEquals("", actualSuperUserSession.getLoginInfo().getPassword());
      assertTrue(((MockSession) actualSuperUserSession).wasReleaseCalled);
    }
  }
  public void testShouldntGetSuperUserSessionDueToWrongClientCapability() throws Exception {
    addUserWithBadClientCapabilityToSession();
    testArgs.put(USERID_ARG_NAME, new String[]{TESTINVALIDUSERID});

    mock.execute(testArgs, outputStream);

    assertEquals("Error: You don't have permission to add users\n", outputStream.toString());
    IDfSession actualSuperUserSession = mock.sessionManager.getSession(TESTDOCBASE, TESTINSTALLOWNER);
    assertNull(actualSuperUserSession);
  }
  public void testShouldntGetSuperUserSessionDueToNotInRightGroup() throws Exception {
    addUserNotInRightGroupToSession();
    testArgs.put(USERID_ARG_NAME, new String[]{TESTINVALIDUSERID});

    mock.execute(testArgs, outputStream);

    assertEquals("Error: Couldn't find user in authorized requestors group or sub group\n", outputStream.toString());
    IDfSession actualSuperUserSession = mock.sessionManager.getSession(TESTDOCBASE, TESTINSTALLOWNER);
    assertNull(actualSuperUserSession);
  }
  public void testGroupDoesntExist() throws Exception {
    addValidUserButNotTheGroupToSession();

    mock.execute(testArgs, outputStream);

    assertEquals("Error: Couldn't find authorized requestors group\n", outputStream.toString());
    IDfSession actualSuperUserSession = mock.sessionManager.getSession(TESTDOCBASE, TESTINSTALLOWNER);
    assertNull(actualSuperUserSession);
  }
  public void testUserObjectCreated() throws Exception {
    addValidUserToSession();
    addUserProfileObjectToSuperUserSession();

    mock.execute(testArgs, outputStream);

    assertEquals("17000," + TESTUSEROSNAME.toUpperCase() + ",1\n", outputStream.toString());
    assertNewUser(superUserSession);
  }
  public void testUserObjectUpdated() throws Exception {
    addValidUserToSession();
    addUserProfileObjectToSuperUserSession();

    mock.execute(testArgs, outputStream);

    assertEquals("17000," + TESTUSEROSNAME.toUpperCase() + ",1\n", outputStream.toString());
    assertNewUser(superUserSession);

    addDifferentUserProfileObjectToSuperUserSession();
    outputStream.reset();
    testArgs.put(ADDITIONALGROUPS_ARG_NAME, new String[]{ANOTHER_AUTHOR_GROUP + "," + ONE_MORE_AUTHOR_GROUP});

    mock.execute(testArgs, outputStream);

    assertEquals("17000," + TESTUSEROSNAME.toUpperCase() + ",1\n", outputStream.toString());
    assertDifferentNewUser(superUserSession);

  }
  private void assertDifferentNewUser(IDfSession session) throws DfException {
    IDfUser newUser = (IDfUser) session.getObjectByQualification("dm_user where user_name='" + TESTUSERNAME + "'");
    assertNotNull(newUser);
    assertEquals(TESTUSERNAME, newUser.getUserName());
    assertEquals(TESTDOMAIN, newUser.getUserOSDomain());
    assertEquals(TESTUSEROSNAME, newUser.getUserLoginName());
    assertEquals(TESTDOMAIN, newUser.getString("user_login_domain"));
    assertEquals(TESTUSERSOURCE, newUser.getUserSourceAsString());
    assertEquals(ANOTHERTESTGROUPNAME, newUser.getUserGroupName());
    assertEquals(ANOTHERTESTACLNAME, newUser.getACLName());
    assertEquals(TESTACLDOMAIN, newUser.getACLDomain());
    assertEquals(TESTCLIENTCAPABILITY, newUser.getClientCapability());
    assertEquals(TESTFOLDER, newUser.getDefaultFolder());
    assertEquals(TESTUSERADDRESS, newUser.getUserAddress());
    assertEquals(TESTUSEROSNAME, newUser.getUserOSName());
    assertTrue(((MockSession) session).wasReleaseCalled);

    assertTrue(session.getGroup(TESTGROUPNAME).isUserInGroup(TESTUSERNAME));
    assertTrue(session.getGroup(ANOTHERTESTGROUPNAME).isUserInGroup(TESTUSERNAME));
    assertAdditionalUserGroupMembership(superUserSession);
    assertAdditionalAuthorGroupMembership(superUserSession);
  }
  private void assertNewUser(IDfSession session) throws DfException {
    IDfUser newUser = (IDfUser) session.getObjectByQualification("dm_user where user_name='" + TESTUSERNAME + "'");
    assertNotNull(newUser);
    assertEquals(TESTUSERNAME, newUser.getUserName());
    assertEquals(TESTDOMAIN, newUser.getUserOSDomain());
    assertEquals(TESTUSEROSNAME, newUser.getUserLoginName());
    assertEquals(TESTDOMAIN, newUser.getString("user_login_domain"));
    assertEquals(TESTUSERSOURCE, newUser.getUserSourceAsString());
    assertEquals(TESTGROUPNAME, newUser.getUserGroupName());
    assertEquals(TESTACLNAME, newUser.getACLName());
    assertEquals(TESTACLDOMAIN, newUser.getACLDomain());
    assertEquals(TESTCLIENTCAPABILITY, newUser.getClientCapability());
    assertEquals(TESTFOLDER, newUser.getDefaultFolder());
    assertEquals(TESTUSERADDRESS, newUser.getUserAddress());
    assertEquals(TESTUSEROSNAME, newUser.getUserOSName());
    assertTrue(((MockSession) session).wasReleaseCalled);

    assertTrue(session.getGroup(TESTGROUPNAME).isUserInGroup(TESTUSERNAME));
    assertAdditionalUserGroupMembership(session);
  }
  private void assertAdditionalAuthorGroupMembership(IDfSession session) throws DfException {
    assertTrue(session.getGroup(ANOTHER_AUTHOR_GROUP).isUserInGroup(TESTUSERNAME));
    assertTrue(((MockDfGroup) session.getGroup(ANOTHER_AUTHOR_GROUP)).wasSaveCalled);
    assertTrue(session.getGroup(ONE_MORE_AUTHOR_GROUP).isUserInGroup(TESTUSERNAME));
    assertTrue(((MockDfGroup) session.getGroup(ONE_MORE_AUTHOR_GROUP)).wasSaveCalled);
  }
  private void assertAdditionalUserGroupMembership(IDfSession session) throws DfException {
    assertTrue(session.getGroup(ANOTHER_USER_GROUP).isUserInGroup(TESTUSERNAME));
    assertTrue(((MockDfGroup) session.getGroup(ANOTHER_USER_GROUP)).wasSaveCalled);
    assertTrue(session.getGroup(ONE_MORE_USER_GROUP).isUserInGroup(TESTUSERNAME));
    assertTrue(((MockDfGroup) session.getGroup(ONE_MORE_USER_GROUP)).wasSaveCalled);
  }
  private void addUserProfileObjectToSuperUserSession() throws DfException {
    initializeSuperUserSession(TESTINSTALLOWNER);
    superUserSession.setDocbaseName(TESTDOCBASE);
    MockSysObject userProfileObject = new MockSysObject();
    userProfileObject.setFile(getUserFile().getAbsolutePath());
    superUserSession.addObject(userProfileObject, TESTUSERINFOID);
    addGroupsToSession(superUserSession);
  }
  private void addDifferentUserProfileObjectToSuperUserSession() throws DfException {
    superUserSession.setDocbaseName(TESTDOCBASE);
    MockSysObject userProfileObject = new MockSysObject();
    userProfileObject.setFile(getDifferentUserFile().getAbsolutePath());
    superUserSession.addObject(userProfileObject, TESTUSERINFOID);
  }
  private void initializeSuperUserSession(String user) throws DfServiceException {
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(user);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    superUserSession = new MockSession(sessionManager);
    sessionManager.setSession(TESTDOCBASE, user, superUserSession);
  }
  private File getDifferentUserFile() throws DfException {
    String userInfo = getUserInfo(ANOTHERTESTGROUPNAME, ANOTHERTESTACLNAME);
    PrintWriter pw = null;
    File file = null;
    try {
      file = File.createTempFile("users", ".txt");
      pw = new PrintWriter(new FileWriter(file, true));
      String [] lines = userInfo.split(";#");
      for (int j = 0; j < lines.length; j++) {
        pw.println(lines[j]);
      }
      pw.println();
      pw.close();
    } catch (IOException ioe) {
      throw new DfException("Couldn't generate user import file", ioe);
    }

    return file;
  }
  private File getUserFile() throws DfException {
    String userInfo = getUserInfo(TESTGROUPNAME, TESTACLNAME);
    PrintWriter pw = null;
    File file = null;
    try {
      file = File.createTempFile("users", ".txt");
      pw = new PrintWriter(new FileWriter(file, true));
      String [] lines = userInfo.split(";#");
      for (int j = 0; j < lines.length; j++) {
        pw.println(lines[j]);
      }
      pw.println();
      pw.close();
    } catch (IOException ioe) {
      throw new DfException("Couldn't generate user import file", ioe);
    }

    return file;
  }
  private String getUserInfo(String groupName, String aclName) {
    StringBuffer strbuff = new StringBuffer(ImportUserMethod_AT.OBJECT_TYPE)
        .append(ImportUserMethod_AT.NAME_VALUE_SEPARATOR).append(ImportUserMethod_AT.DM_USER);
    addNameValuePair(strbuff, ImportUserMethod_AT.USER_NAME, TESTUSERNAME);
    addNameValuePair(strbuff, ImportUserMethod_AT.USER_OS_NAME, TESTUSEROSNAME);
    addNameValuePair(strbuff, ImportUserMethod_AT.USER_OS_DOMAIN, TESTDOMAIN);
    addNameValuePair(strbuff, ImportUserMethod_AT.USER_LOGIN_NAME, TESTUSEROSNAME);
    addNameValuePair(strbuff, ImportUserMethod_AT.USER_LOGIN_DOMAIN, TESTDOMAIN);
    addNameValuePair(strbuff, ImportUserMethod_AT.USER_ADDRESS,
        TESTUSEROSNAME + ImportUserMethod_AT.TESTEMAILSUFFIX);
    addNameValuePair(strbuff, ImportUserMethod_AT.USER_SOURCE, TESTUSERSOURCE);
    addNameValuePair(strbuff, ImportUserMethod_AT.USER_GROUP_NAME, groupName);
    addNameValuePair(strbuff, ImportUserMethod_AT.ACL_NAME, aclName);
    addNameValuePair(strbuff, ImportUserMethod_AT.ACL_DOMAIN, TESTACLDOMAIN);
    addNameValuePair(strbuff, ImportUserMethod_AT.DEFAULT_FOLDER, TESTFOLDER);
    addNameValuePair(strbuff, ImportUserMethod_AT.CLIENT_CAPABILITY, Integer.toString(TESTCLIENTCAPABILITY));
    return strbuff.toString();
  }
  private void addNameValuePair(StringBuffer strbuff, String name, String value) {
    strbuff.append(ImportUserMethod_AT.ELEMENT_SEPARATOR).append(name)
        .append(ImportUserMethod_AT.NAME_VALUE_SEPARATOR).append(value);
  }
  private void addValidUserButNotTheGroupToSession() throws DfException {
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    session.setDocbaseName(TESTDOCBASE);
    MockDfUser user = new MockDfUser();
    user.setUserName(TESTUSERID);
    user.setClientCapability(DfUser.DF_CAPABILITY_COORDINATOR);
    session.addUser(user);
  }
  private void addUserWithBadClientCapabilityToSession() throws DfException {
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTINVALIDUSERID);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    session.setDocbaseName(TESTDOCBASE);
    MockDfUser user = new MockDfUser();
    user.setUserName(TESTINVALIDUSERID);
    user.setClientCapability(DfUser.DF_CAPABILITY_CONSUMER);
    session.addUser(user);
    addGroupToSession(AUTHORIZED_REQUESTORS, TESTINVALIDUSERID, session);
  }
  private void addGroupsToSession(MockSession session) throws DfException {
    addGroupToSession(TESTGROUPNAME, null, session);
    addGroupToSession(ANOTHERTESTGROUPNAME, null, session);
    addGroupToSession(ANOTHER_USER_GROUP, null, session);
    addGroupToSession(ONE_MORE_USER_GROUP, null, session);
    addGroupToSession(ANOTHER_AUTHOR_GROUP, null, session);
    addGroupToSession(ONE_MORE_AUTHOR_GROUP, null, session);
  }
  private void addGroupToSession(String groupName, String initialUser, MockSession session) throws DfException {
    MockDfGroup group = new MockDfGroup();
    group.setResults(setupResults());
    group.setGroupName(groupName);
    if (initialUser != null && initialUser.length() > 0) {
      group.addUser(initialUser);
    }
    session.addGroup(group);
  }
  private void addGroupToGroup(String groupName, String subGroup,MockSession session, String user) throws DfException{
    MockDfGroup group = new MockDfGroup();
    group.setGroupName(groupName);
    group.addGroup(groupName);
    if(subGroup != null && subGroup.length()>0){
      group.addGroup(subGroup);
      group.setGroupName(subGroup);
      if (user != null && user.length() > 0) {
        group.addUser(user);
      }
    }
    session.addGroup(group);
    group.setGroupName(groupName);
 }
  private void addUserNotInRightGroupToSession() throws DfException {
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTINVALIDUSERID);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    session.setDocbaseName(TESTDOCBASE);
    MockDfUser user = new MockDfUser();
    user.setUserName(TESTINVALIDUSERID);
    user.setClientCapability(DfUser.DF_CAPABILITY_COORDINATOR);
    session.addUser(user);
    addGroupToSession(AUTHORIZED_REQUESTORS, null, session);
  }
  private void addValidUserToSession() throws DfException {
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    session.setDocbaseName(TESTDOCBASE);
    MockDfUser user = new MockDfUser();
    user.setUserName(TESTUSERID);
    user.setClientCapability(DfUser.DF_CAPABILITY_COORDINATOR);
    session.addUser(user);
    addGroupToSession(AUTHORIZED_REQUESTORS, TESTUSERID, session);
  }
  private void addUserWithSpacesToSession() throws DfException {
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERIDWITHSPACES);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    session.setDocbaseName(TESTDOCBASE);
    MockDfUser user = new MockDfUser();
    user.setUserName(TESTUSERIDWITHSPACES);
    user.setClientCapability(DfUser.DF_CAPABILITY_COORDINATOR);
    session.addUser(user);
    addGroupToSession(AUTHORIZED_REQUESTORS, TESTUSERIDWITHSPACES, session);
  }
  private void addUserWithinSubGroupToSession() throws DfException{
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERWITHINSUBGROUP);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    session.setDocbaseName(TESTDOCBASE);
    MockDfUser user = new MockDfUser();
    user.setUserName(TESTUSERWITHINSUBGROUP);
    user.setClientCapability(DfUser.DF_CAPABILITY_COORDINATOR);
    session.addUser(user);

    addGroupToSession(AUTHORIZED_REQUESTORS, null, session);
    addGroupToSession(SUBGROUP,TESTUSERWITHINSUBGROUP,session);
    addGroupToGroup(AUTHORIZED_REQUESTORS,SUBGROUP,session,TESTUSERWITHINSUBGROUP);

  }
  private List setupResults() {
                 Map row1 = new HashMap();
                 List objectIds1 = new ArrayList();
                 objectIds1.add(0, "subGroup");
                 row1.put("groups_names", objectIds1);

                 Map row2 = new HashMap();
                 List objectIds2 = new ArrayList();
                 objectIds2.add(0, "authorized_requestors");
                 row2.put("groups_names", objectIds2);

                 Map row3 = new HashMap();
                 List objectIds3 = new ArrayList();
                 objectIds3.add(0, "testGroup1");
                 row3.put("groups_names", objectIds3);

                 Map row4 = new HashMap();
                 List objectIds4 = new ArrayList();
                 objectIds4.add(0, "testGroup2");
                 row4.put("groups_names", objectIds4);

                 List results = new ArrayList();
                 results.add(row2);
                 results.add(row1);
                 results.add(row3);
                 results.add(row4);
                 return results;
             }

}