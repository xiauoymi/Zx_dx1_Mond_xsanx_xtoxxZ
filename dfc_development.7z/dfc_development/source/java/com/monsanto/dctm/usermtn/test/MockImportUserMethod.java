/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.usermtn.ImportUserMethod;

/**
 * Filename:    $RCSfile: MockImportUserMethod.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-05-14 15:53:50 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class MockImportUserMethod extends ImportUserMethod {
    public MockDfSessionManager sessionManager;

    public MockImportUserMethod(MockDfSessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }

    protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
        IDfLoginInfo loginInfoObj = new DfLoginInfo();
        loginInfoObj.setUser(userid);
        loginInfoObj.setPassword(password);
        loginInfoObj.setDomain(null);
        sessionManager.setIdentity(docbase, loginInfoObj);
        return sessionManager;
    }
}