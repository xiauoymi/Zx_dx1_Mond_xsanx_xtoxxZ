/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.com.DfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfList;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.usermtn.NotifyDATMethod;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: NotifyDATMethod_AT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2008-01-25 19:45:37 $
 *
 * @author lakench
 * @version $Revision: 1.3 $
 */
public class NotifyDATMethod_AT extends TestCase {
    private static final String TESTUSER_JOEMINER = "Joe Miner";
    private static final String TESTUSERID_JOEMINER = "joeminer";
    private static final String TESTUSER_ANOTHERUSER = "Another User";
    private static final String TESTUSERID_ANOTHERUSER = "anotheruser";
    private static final String TESTDOMAIN = "north_america";
    private static final String TESTEMAILSUFFIX = "@monsanto.com";
    private static final String TESTUSERSOURCE = "domain only";
    private static final String TESTACLNAME = "testaclname";
    private static final String TESTACLDOMAIN = "stltst03";
    private static final String TESTDOCBASE = "stltst03";
    private static final String TESTFOLDER = "/testfolder";
    private static final int TESTUSERCLIENTCAPABILITY = DfUser.DF_CAPABILITY_CONSUMER;
    private static final String TESTUSERGROUP = "testusergroup1";

    private IDfCollection methodResults = null;

    private static final String USER_NAME = "user_name";
    private static final String USER_OS_NAME = "user_os_name";
    private static final String USER_OS_DOMAIN = "user_os_domain";
    private static final String USER_ADDRESS = "user_address";
    private static final String USER_SOURCE = "user_source";
    private static final String USER_GROUP_NAME = "user_group_name";
    private static final String ACL_NAME = "acl_name";
    private static final String ACL_DOMAIN = "acl_domain";
    private static final String DEFAULT_FOLDER = "default_folder";
    private static final String CLIENT_CAPABILITY = "client_capability";
    private static final String OBJECT_TYPE = "object_type";
    private static final String DM_USER = "dm_user";
    private static final String ELEMENT_SEPARATOR = ";#";
    private static final String NAME_VALUE_SEPARATOR = ":";
    private static final String BADGROUP = "bad_group_name";
    private static final String RECIPIENT1 = "ussing@monsanto.com";
    private static final String RECIPIENT2 = "rrkaur@monsanto.com";
    private static final List RECIPIENTS = new ArrayList(); //"testrecipient@monsanto.com";
    private static final String SENDER = "testsender@monsanto.com";
    private static final String NOTIFY_DAT_METHOD_NAME = "notify_dat";
    private static final String IMPORT_USER_METHOD_NAME = "import_user";

    public void testSendEmail() throws Exception {
        String goodUserResultsObjectId = createUser(TESTUSERGROUP, TESTUSER_JOEMINER, TESTUSERID_JOEMINER);
        String badUserResultsObjectId = createUser(BADGROUP, TESTUSER_ANOTHERUSER, TESTUSERID_ANOTHERUSER);
        IDfSessionManager sysAdminSessionManager = DFCSessionUtils
                .createSessionManager(NotifyDATMethod_AT.TESTDOCBASE, "devl30", "devl30");
        IDfSession sysAdminSession = sysAdminSessionManager.getSession(NotifyDATMethod_AT.TESTDOCBASE);
        RECIPIENTS.add(RECIPIENT1);
        RECIPIENTS.add(RECIPIENT2);
        runMethod(sysAdminSession, NOTIFY_DAT_METHOD_NAME,
                  "'-" + NotifyDATMethod.DOCBASE_ARG_NAME + " " + sysAdminSession.getDocbaseName() +
                  " -" + NotifyDATMethod.USERID_ARG_NAME + " dmadmin" +
                  " -" + NotifyDATMethod.RECIPIENT_ARG_NAME + " " + RECIPIENTS +
                  " -" + NotifyDATMethod.SENDER_ARG_NAME + " " + SENDER + "'");

        String notifyDATResultsID = assertSuccessfulResultsCollection();

        IDfSysObject goodUserResultsObject = null;
        try {
            goodUserResultsObject = (IDfSysObject) sysAdminSession.getObject(new DfId(goodUserResultsObjectId));
        } catch (DfIdNotFoundException e) {
            //expected path - indicates the goodUserResultsObject was deleted
            assertNull(goodUserResultsObject);
        }
        IDfSysObject badUserResultsObject = (IDfSysObject) sysAdminSession.getObject(new DfId(badUserResultsObjectId));
        assertNotNull(badUserResultsObject);
        badUserResultsObject.destroy();
        IDfSysObject notifyDATResultsObject = (IDfSysObject) sysAdminSession.getObject(new DfId(notifyDATResultsID));
        assertNotNull(notifyDATResultsObject);
        notifyDATResultsObject.destroy();
        sysAdminSessionManager.release(sysAdminSession);
    }

    private String createUser(String defaultGroup, String userName, String userId) throws DfException {
        String resultsObjectId = null;
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, "devl30", "devl30");
        IDfSession session = null;
        IDfUser user = null;
        try {
            session = sessionManager.getSession(TESTDOCBASE);
            String userInfoObjectId = createUserInfoObject(session, userName, userId, defaultGroup);
            runMethod(session, IMPORT_USER_METHOD_NAME, "'-docbase " + session.getDocbaseName() +
                                                        " -userid " +
                                                        session.getLoginUserName() +
                                                        " -ticket " + session.getLoginTicket() +
                                                        " -userinfoid " + userInfoObjectId + "'"
            );
            IDfPersistentObject object = session.getObject(new DfId(userInfoObjectId));
            if (object != null) {
                object.destroy();
            }
            user = session.getUser(userName);
            methodResults.next();
            resultsObjectId = methodResults.getString("result_doc_id");
            methodResults.close();
        } finally {
            if (session != null) {
                if (user != null) {
                    IDfSessionManager sysAdminSessionManager = DFCSessionUtils
                            .createSessionManager(TESTDOCBASE, "devl29", "devl29");
                    IDfSession sysAdminSession = sysAdminSessionManager.getSession(NotifyDATMethod_AT.TESTDOCBASE);
                    sysAdminSession.getUser(userName).destroy();
                    sysAdminSessionManager.release(sysAdminSession);
                }
                sessionManager.release(session);
            }
        }
        return resultsObjectId;
    }

    private String assertSuccessfulResultsCollection() throws DfException {
        assertNotNull(methodResults);
        assertTrue(methodResults.next());
        assertFalse(methodResults.getBoolean("launch_failed"));
        assertNotNull(methodResults.getId("result"));
        assertEquals(0, methodResults.getInt("method_return_val"));
        assertFalse(methodResults.getBoolean("timed_out"));
        IDfId resultsId = methodResults.getId("result_doc_id");
        assertNotNull(resultsId);
        assertFalse(methodResults.next());
        methodResults.close();
        return resultsId.getId();
    }

    private File getUserFile(String userName, String userId, String defaultGroup) throws DfException {
        return getTempFile(getUserInfo(userName, userId, defaultGroup));
    }

    private String getUserInfo(String userName, String userId, String defaultGroup) {
        StringBuffer strbuff = new StringBuffer(NotifyDATMethod_AT.OBJECT_TYPE)
                .append(NotifyDATMethod_AT.NAME_VALUE_SEPARATOR).append(NotifyDATMethod_AT.DM_USER);
        addNameValuePair(strbuff, USER_NAME, userName);
        addNameValuePair(strbuff, USER_OS_NAME, userId);
        addNameValuePair(strbuff, USER_OS_DOMAIN, TESTDOMAIN);
        addNameValuePair(strbuff, USER_ADDRESS, userId + TESTEMAILSUFFIX);
        addNameValuePair(strbuff, USER_SOURCE, TESTUSERSOURCE);
        addNameValuePair(strbuff, USER_GROUP_NAME, defaultGroup);
        addNameValuePair(strbuff, ACL_NAME, TESTACLNAME);
        addNameValuePair(strbuff, ACL_DOMAIN, TESTACLDOMAIN);
        addNameValuePair(strbuff, DEFAULT_FOLDER, TESTFOLDER);
        addNameValuePair(strbuff, CLIENT_CAPABILITY, Integer.toString(TESTUSERCLIENTCAPABILITY));
        return strbuff.toString();
    }

    private void addNameValuePair(StringBuffer strbuff, String name, String value) {
        strbuff.append(NotifyDATMethod_AT.ELEMENT_SEPARATOR).append(name)
                .append(NotifyDATMethod_AT.NAME_VALUE_SEPARATOR).append(value);
    }

    private File getTempFile(String userInfo) throws DfException {
        PrintWriter pw = null;
        File file = null;
        try {
            file = File.createTempFile("users", ".txt");
            pw = new PrintWriter(new FileWriter(file, true));
            String [] lines = userInfo.split(";#");
            for (int j = 0; j < lines.length; j++) {
                pw.println(lines[j]);
            }
            pw.println();
            pw.close();
        } catch (IOException ioe) {
            throw new DfException("Couldn't generate user import file", ioe);
        }
        return file;
    }

    private void runMethod(IDfSession session, String methodName, String arguments) throws DfException {
        List argumentValues = Arrays.asList(new String[]{methodName, "TRUE", arguments});
        List argumentNames = Arrays.asList(new String[]{"METHOD", "SAVE_RESULTS", "ARGUMENTS"});
        List argumentTypes = Arrays.asList(new String[]{"S", "B", "S"});
        methodResults = session
                .apply(null, "DO_METHOD", createDfListFromList(argumentNames), createDfListFromList(argumentTypes),
                       createDfListFromList(argumentValues));
    }

    private IDfList createDfListFromList(List list) throws DfException {
        DfClientX client = new DfClientX();
        IDfList dfList = client.getList();
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            dfList.appendString((String) iterator.next());
        }
        return dfList;
    }

    private String createUserInfoObject(IDfSession session, String userName, String userId, String defaultGroup) throws
                                                                                                                 DfException {
        File userFile = getUserFile(userName, userId, defaultGroup);
        IDfSysObject document = (IDfSysObject) session.newObject("dm_document");
        document.setObjectName("New Users");
        document.setContentType("crtext");
        document.setFileEx(userFile.getAbsolutePath(), "crtext", 0, null);
        document.link("/Temp");
        document.save();
        userFile.delete();
        return document.getObjectId().getId();
    }
}