/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.usermtn.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.JavaMail.JavaMailMailDocument;
import com.monsanto.Mail.MailAttachment;
import com.monsanto.Mail.MailAttachmentIterator;
import com.monsanto.Mail.MailDocument;
import com.monsanto.Mail.MessageParseException;
import com.monsanto.Util.FileUtil;
import com.monsanto.XMLUtil.DOMUtil;
import com.monsanto.dctm.test.MockDfQuery;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockPersistentObject;
import com.monsanto.dctm.test.MockSysObject;
import com.monsanto.dctm.usermtn.NotifyDATMethod;
import org.custommonkey.xmlunit.XMLTestCase;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import javax.xml.transform.TransformerException;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: NotifyDATMethod_UT.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: ussing $    	 On:	$Date: 2008-01-25 19:45:26 $
 *
 * @author LAKENCH
 * @version $Revision: 1.6 $
 */
public class NotifyDATMethod_UT extends XMLTestCase {

    private MockNotifyDATMethod mock;
    private ByteArrayOutputStream outputStream;
    private Map testArgs;

    private static final String TESTDOCBASE = "testdocbase";
    private static final String TESTUSERID = "testuserid";
    public static final String TESTRECIPIENT1 = "testrecipient@monsanto.com";
    public static final String TESTRECIPIENT2 = "testrecipient2@monsanto.com";
    public static final List TESTRECIPIENTS  = new ArrayList();
    public static final String TESTSENDER = "testsender@monsanto.com";
    private static final String LINESEPARATOR = System.getProperty("line.separator");

    protected void setUp() throws Exception {
        super.setUp();
        MockDfSessionManager sessionManager = new MockDfSessionManager();
        mock = new MockNotifyDATMethod(sessionManager);
        outputStream = new ByteArrayOutputStream();
        testArgs = new HashMap();
        testArgs.put(NotifyDATMethod.DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
        testArgs.put(NotifyDATMethod.USERID_ARG_NAME, new String[]{TESTUSERID});
        TESTRECIPIENTS.add(TESTRECIPIENT1);
        TESTRECIPIENTS.add(TESTRECIPIENT2);
    }

    public void testCreate() throws Exception {
        NotifyDATMethod method = new NotifyDATMethod();
        assertTrue(method instanceof IDmMethod);
    }

    public void testValidateArguments() throws Exception {
        testArgs.remove(NotifyDATMethod.DOCBASE_ARG_NAME);
        testArgs.remove(NotifyDATMethod.USERID_ARG_NAME);

        mock.execute(testArgs, outputStream);

        assertEquals("Error:" + LINESEPARATOR + "must supply docbase" + LINESEPARATOR + "must supply userid" + LINESEPARATOR,
                     outputStream.toString());

        outputStream.reset();
        testArgs.put(NotifyDATMethod.DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
        mock.execute(testArgs, outputStream);
        assertEquals("Error:" + LINESEPARATOR + "must supply userid" + LINESEPARATOR, outputStream.toString());

        outputStream.reset();
        testArgs.put(NotifyDATMethod.USERID_ARG_NAME, new String[]{TESTUSERID});
        mock.execute(testArgs, outputStream);
        assertEquals("success" + LINESEPARATOR + "" +
                     "SystemID,UserCode,Active" + LINESEPARATOR +
                     "17000,joeminer,1" + LINESEPARATOR +
                     "17000,testuser,1" + LINESEPARATOR +
                     LINESEPARATOR, outputStream.toString());
    }

    public void testGotSession() throws Exception {

        mock.execute(testArgs, outputStream);

        assertEquals("success" + LINESEPARATOR + "" +
                     "SystemID,UserCode,Active" + LINESEPARATOR +
                     "17000,joeminer,1" + LINESEPARATOR +
                     "17000,testuser,1" + LINESEPARATOR +
                     LINESEPARATOR, outputStream.toString());
        IDfSession userSession = mock.sessionManager.getSession(TESTDOCBASE, TESTUSERID);
        assertNotNull(userSession);
        assertEquals(TESTUSERID, userSession.getLoginUserName());
        assertEquals(TESTUSERID, userSession.getLoginInfo().getUser());
        assertEquals("", userSession.getLoginInfo().getPassword());
        assertTrue(((MockSession) userSession).wasReleaseCalled);
    }

    public void testQueryExecuted() throws Exception {
        mock.execute(testArgs, outputStream);

        assertEquals("success" + LINESEPARATOR + "" +
                     "SystemID,UserCode,Active" + LINESEPARATOR +
                     "17000,joeminer,1" + LINESEPARATOR +
                     "17000,testuser,1" + LINESEPARATOR +
                     LINESEPARATOR, outputStream.toString());
        assertTrue(((MockDfQuery) mock.dfQuery).collection.isClosed);
        assertEquals(
                "select r_object_id from dm_document where object_name = 'Result.import_user' and title like '%status code (0)' and FOLDER('/Temp')",
                mock.dfQuery.getDQL());
    }

    public void testAttachmentCreated() throws Exception {
        mock.execute(testArgs, outputStream);

        assertNotNull(mock.tempFile);
        assertTrue(mock.deleteCalled);
        File expectedAttachment = generateExpectedAttachment();
        assertTrue(FileUtil.compareFiles(expectedAttachment.getAbsolutePath(), mock.tempFile.getAbsolutePath()));
    }

    public void testImportResultObjectsDestroyed() throws Exception {
        mock.execute(testArgs, outputStream);

        IDfSession userSession = mock.sessionManager.getSession(TESTDOCBASE, TESTUSERID);
        assertTrue(((MockPersistentObject) userSession.getObject(new DfId("testobject1"))).wasDestroyCalled);
        assertTrue(((MockPersistentObject) userSession.getObject(new DfId("testobject2"))).wasDestroyCalled);
        assertFalse(((MockPersistentObject) userSession.getObject(new DfId("testobject3"))).wasDestroyCalled);
        assertFalse(((MockPersistentObject) userSession.getObject(new DfId("testobject4"))).wasDestroyCalled);
    }

    public void testImportResultObjectsNotDestroyed() throws Exception {
        mock.throwExceptionOnGenerateMailDocument = true;

        try {
            mock.execute(testArgs, outputStream);
        } catch (Exception e) {
            //expected path
            IDfSession userSession = mock.sessionManager.getSession(TESTDOCBASE, TESTUSERID);
            assertFalse(((MockPersistentObject) userSession.getObject(new DfId("testobject1"))).wasDestroyCalled);
            assertFalse(((MockPersistentObject) userSession.getObject(new DfId("testobject2"))).wasDestroyCalled);
            assertFalse(((MockPersistentObject) userSession.getObject(new DfId("testobject3"))).wasDestroyCalled);
            assertFalse(((MockPersistentObject) userSession.getObject(new DfId("testobject4"))).wasDestroyCalled);
        }
    }

    public void testJavaMailDocument() throws Exception {
        mock.execute(testArgs, outputStream);
        for (int i = 0; i < mock.recipients.size(); i++ ){
          assertEquals(NotifyDATMethod.recipients.get(i).toString(),mock.recipients.get(i).toString());
        }
        //assertEquals(NotifyDATMethod.EMAILRECIPIENT, mock.recipients.get(0).toString());
        mock.mailDoc.setAttachmentSavePath(System.getProperty("java.io.tmpdir"));
        DOMUtil.outputXML( mock.mailDoc.toXML());
        verifyMailMessage(mock.mailDoc);
        verifyMailAttachment(mock.mailDoc);
    }

    public void testAlternateRecipient() throws Exception {
       List alternaterecipient = new ArrayList();
        alternaterecipient.add("alternaterecipient");
        testArgs.put(NotifyDATMethod.RECIPIENT_ARG_NAME, alternaterecipient);

        mock.execute(testArgs, outputStream);

        assertEquals("alternaterecipient", mock.recipients.get(0).toString());
    }

    public void testAlternateSender() throws Exception {
      testArgs.put(NotifyDATMethod.SENDER_ARG_NAME, new String[]{"alternatesender"});

        mock.execute(testArgs, outputStream);

        assertEquals("alternatesender", mock.sender);
    }

    private void verifyMailMessage(JavaMailMailDocument actualMailDoc) throws MessageParseException,
        TransformerException {

/*      for (int i = 0, j = 1; i < TESTRECIPIENTS.size(); i++ ){
         assertXpathEvaluatesTo(TESTRECIPIENTS.get(i).toString(), "/REQUEST/HEADER/TO[j]/ADDRESS", actualMailDoc.toXML());
         j++;
       }
*/        assertXpathEvaluatesTo(TESTRECIPIENTS.get(0).toString(), "/REQUEST/HEADER/TO[1]/ADDRESS", actualMailDoc.toXML());
        assertXpathEvaluatesTo(TESTRECIPIENTS.get(1).toString(), "/REQUEST/HEADER/TO[2]/ADDRESS", actualMailDoc.toXML());
        assertEquals(TESTSENDER, actualMailDoc.getFromAddress().toString());
        assertEquals(NotifyDATMethod.EMAILSUBJECT, actualMailDoc.getSubject());
        Document messageBody = actualMailDoc.getMessageBody();
        NodeList nodes = DOMUtil.getNodeListByTagName(messageBody, "LINE");
        assertEquals(1, nodes.getLength());
        String actualBodyText = nodes.item(0).getNodeValue();
        assertEquals(NotifyDATMethod.EMAILBODY, actualBodyText);
    }

    private void verifyMailAttachment(JavaMailMailDocument actualMailDoc) throws IOException {
        assertEquals(1, actualMailDoc.getAttachmentCount());
        MailAttachmentIterator attachmentIterator = actualMailDoc.getAttachmentIterator();
        MailAttachment mailAttachment = attachmentIterator.next();
        String actualAttachmentName = mailAttachment.getAttachmentName();
        assertEquals(mock.tempFile.getName(), actualAttachmentName);
        mailAttachment.save(System.getProperty("java.io.tmpdir"));
        File mailFile = new File(mailAttachment.getAbsolutePath() + "0");
        mailFile.delete();
    }

    private File generateExpectedAttachment() throws IOException {
        File file = File.createTempFile("expected_attachment", ".csv");
        FileUtil.write(file.getAbsolutePath(), "SystemID,UserCode,Active" + LINESEPARATOR + "17000,joeminer,1" + LINESEPARATOR + "17000,testuser,1");
        file.deleteOnExit();
        return file;
    }

    public class MockNotifyDATMethod extends NotifyDATMethod {
        private List mockResults;

        public JavaMailMailDocument mailDoc;
        public IDfQuery dfQuery;
        public File tempFile;
        public MockDfSessionManager sessionManager;
        public boolean deleteCalled;
//        public String recipient ;
        public List recipients = new ArrayList();
        public boolean throwExceptionOnGenerateMailDocument = false;
        public String sender;

        public MockNotifyDATMethod(MockDfSessionManager sessionManager) throws DfException, IOException {
            this.sessionManager = sessionManager;
            mockResults = setupResults();
            addResultObjectsToSession();
        }

        protected MailDocument generateMailDocument(List recipients, String sender, String attachmentFilename) throws
                                                                                                 MessageParseException {
            if (!throwExceptionOnGenerateMailDocument) {
                for (int i = 0; i < recipients.size() ; i++){
                   this.recipients.add(recipients.get(i).toString());
                }
                this.sender = sender;
                mailDoc = (JavaMailMailDocument) super.generateMailDocument(TESTRECIPIENTS, TESTSENDER, attachmentFilename);
                return mailDoc;
            } else {
                throw new MessageParseException("testing error handling");
            }
        }

        /**
         * @noinspection RefusedBequest
         */
        protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws
                                                                                                      DfException {
            IDfLoginInfo loginInfoObj = new DfLoginInfo();
            loginInfoObj.setUser(userid);
            loginInfoObj.setPassword(password);
            loginInfoObj.setDomain(null);
            sessionManager.setIdentity(docbase, loginInfoObj);
            return sessionManager;
        }

        /**
         * @noinspection RefusedBequest
         */
        protected IDfQuery createIDfQuery(String query) {
            dfQuery = new MockDfQuery(true, mockResults);
            dfQuery.setDQL(query);
            return dfQuery;
        }

        protected File getTempFile() throws IOException {
            tempFile = super.getTempFile();
            return tempFile;
        }

        /**
         * @noinspection RefusedBequest
         */
        protected void deleteTempFile(File userFile) {
            deleteCalled = true;
            userFile.deleteOnExit();
        }

        private void addResultObjectsToSession() throws DfException, IOException {
            DfLoginInfo loginInfo = new DfLoginInfo();
            loginInfo.setUser(TESTUSERID);
            sessionManager.setIdentity(TESTDOCBASE, loginInfo);
            MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
            session.setDocbaseName(TESTDOCBASE);
            addTestObjectWithContent(new MockSysObject(), "testobject1", "17000,joeminer,1", session);
            addTestObjectWithContent(new MockSysObject(), "testobject2", "17000,testuser,1", session);
            addTestObjectWithContent(new MockSysObject(), "testobject3", "error", session);
            addTestObjectWithContent(new MockSysObject(), "testobject4", "Error", session);
        }

        private void addTestObjectWithContent(IDfSysObject object, String objectId, String content, MockSession session) throws
                                                                                                                         IOException,
                                                                                                                         DfException {
            File testObject1Content = File.createTempFile("temp", ".txt");
            FileUtil.write(testObject1Content.getAbsolutePath(), content);
            object.setFile(testObject1Content.getAbsolutePath());
            session.addObject(object, objectId);
            testObject1Content.deleteOnExit();
        }

        private List setupResults() {
            Map row1 = new HashMap();
            List objectIds1 = new ArrayList();
            objectIds1.add(0, "testobject1");
            row1.put("r_object_id", objectIds1);
            Map row2 = new HashMap();
            List objectIds2 = new ArrayList();
            objectIds2.add(0, "testobject2");
            row2.put("r_object_id", objectIds2);
            Map row3 = new HashMap();
            List objectIds3 = new ArrayList();
            objectIds3.add(0, "testobject3");
            row3.put("r_object_id", objectIds3);
            Map row4 = new HashMap();
            List objectIds4 = new ArrayList();
            objectIds4.add(0, "testobject4");
            row4.put("r_object_id", objectIds4);
            List results = new ArrayList();
            results.add(row1);
            results.add(row2);
            results.add(row3);
            results.add(row4);
            return results;
        }

    }
}