package com.monsanto.dctm.utils;

import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;

import java.util.Date;

/**
 * This class promotes the previous approved version document to the archive state
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Feb 3, 2009
 * Time: 3:18:51 PM
 * To change this template use File | Settings | File Templates.
 */
public class ArchiveCreation {
    public void processPreviousVersion(IDfSysObject newObj, IDfSession session, String stateName) throws DfException {
        //check if previous version approved version exists and is not current.
        Date dateBeforePreApproved = new Date();
        System.out.println("ArchiveCreation.processPreviousVersion BEFORE finding previous approved version = "  + newObj.getObjectId()+ " time in milli seconds " + dateBeforePreApproved.getTime() + " in format " + dateBeforePreApproved.toString());
        IDfId prevApprovedVersionId = findPrevApprovedVersion(newObj, session,stateName);
        Date dateAfterPreApproved = new Date();
        System.out.println("ArchiveCreation.processPreviousVersion AFTER finding previous approved version = "  + prevApprovedVersionId+ " time in milli seconds " + dateAfterPreApproved.getTime() + " in format " + dateAfterPreApproved.toString());
        if (prevApprovedVersionId != null) {
            //if it exists then promote to archive
            IDfSysObject prevVersionObject = (IDfSysObject) session.getObject(prevApprovedVersionId);
            //make the immutable attribute false
            prevVersionObject.fetch("");
            prevVersionObject.setBoolean("r_immutable_flag", false);
            prevVersionObject.save();
            prevVersionObject.fetch("");
            //promote to archive and save the previous version
            System.out.println("ArchiveCreation.processPreviousVersion");
            Date dateBeforePromote = new Date();
            System.out.println("ArchiveCreation.processPreviousVersion BEFORE Promote= "  + prevVersionObject.getObjectId()+ " time in milli seconds " + dateBeforePromote.getTime() + " in format " + dateBeforePromote.toString());
            prevVersionObject.promote("",false,false);
            Date dateAfterPromote = new Date();
            System.out.println("ArchiveCreation.processPreviousVersion AFTER Promote = "  + prevVersionObject.getObjectId()+ " time in milli seconds " + dateAfterPromote.getTime() + " in format " + dateAfterPromote.toString());
//                //make the immutable attribute true
            prevVersionObject.setBoolean("r_immutable_flag", true);
            Date dateBeforeSave = new Date();
            System.out.println("ArchiveCreation.processPreviousVersion BEFORE Save= "  + prevVersionObject.getObjectId()+ " time in milli seconds " + dateBeforeSave.getTime() + " in format " + dateBeforeSave.toString());
            prevVersionObject.save();
            Date dateAfterSave = new Date();
            System.out.println("ArchiveCreation.processPreviousVersion AFTER save = "  + prevVersionObject.getObjectId()+ " time in milli seconds " + dateAfterSave.getTime() + " in format " + dateAfterSave.toString());
        }
    }
    private IDfId findPrevApprovedVersion(IDfSysObject newObj, IDfSession session, String stateName) throws DfException {
        IDfId  prevApprovedObjId = null;
        IDfId chronicleId = newObj.getChronicleId();
        String qualification = "dm_sysobject(all) where i_chronicle_id = '" + chronicleId +"' and r_immutable_flag = true and i_latest_flag = false and a_status = '" + stateName +"'";
        IDfSysObject prevVersionObject = (IDfSysObject) session.getObjectByQualification(qualification);
        if (prevVersionObject  != null ) {
            prevApprovedObjId =  prevVersionObject.getObjectId();
            System.out.println("prevApprovedObjId =  " + prevApprovedObjId);
        }
        return prevApprovedObjId;
    }

}
