/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils;

import com.documentum.fc.client.DfQuery;
import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.DfException;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: FindVirtualDocumentCycles.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $
 * On:	$Date: 2007-10-23 15:29:22 $
 *
 * @author lakench
 * @version $Revision: 1.2 $
 */
public class FindVirtualDocumentCycles {
  private IDfSession session;

  public FindVirtualDocumentCycles(IDfSession session) {
    this.session = session;
  }

  public List find(String objectType) throws DfException {
    List parentsWithCycles = new ArrayList();
    Iterator parentIds = getParentIds(objectType);
    while (parentIds.hasNext()) {
      String parentId = ((String[]) parentIds.next())[0];
      if (hasCycle(parentId)) parentsWithCycles.add(parentId);
    }
    return parentsWithCycles;
  }

  private boolean hasCycle(String parentId) {
    try {
      QueryUtils.execQuery(session, createCheckForCycleQuery(parentId));
    } catch (DfException e) {
      return true;
    }
    return false;
  }

  private IDfQuery createCheckForCycleQuery(String parentId) {
    return createIDfQuery(generateCheckForCycleQueryString(parentId));
  }

  private String generateCheckForCycleQueryString(String parentId) {
    return "select r_object_id from dm_document in document id('" + parentId + "') descend";
  }

  protected IDfQuery createIDfQuery(String queryString) {
    IDfQuery query = new DfQuery();
    query.setDQL(queryString);
    return query;
  }

  private Iterator getParentIds(String objectType) throws DfException {
    return QueryUtils.execQuery(session, createParentIdsQuery(objectType)).getResultsIterator();
  }

  private IDfQuery createParentIdsQuery(String objectType) {
    return createIDfQuery(generateParentIdsQueryString(objectType));
  }

  private String generateParentIdsQueryString(String objectType) {
    return "select distinct parent_id from dmr_containment where parent_id in (select r_object_id from " + objectType +
        " (all))";
  }
}