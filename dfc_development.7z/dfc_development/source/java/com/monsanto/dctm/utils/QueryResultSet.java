/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils;

import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfAttr;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Filename:    $RCSfile: QueryResultSet.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-10-23 15:29:22 $
 *
 * @author LAKENCH
 * @version $Revision: 1.1 $
 */
public class QueryResultSet {
  private List resultListOfTypedObjects;

  public QueryResultSet(IDfCollection col) throws DfException {
    resultListOfTypedObjects = createListOfTypedObjectsFromCollection(col);
  }

  private List createListOfTypedObjectsFromCollection(IDfCollection col) throws DfException {
    ArrayList list = new ArrayList();
    while (col.next()) {
      list.add(col.getTypedObject());
    }
    return list;
  }

  public Iterator getResultsIterator() throws DfException {
    return createResultsList().iterator();
  }

  private List createResultsList() throws DfException {
    ArrayList list = new ArrayList();
    Iterator typedObjects = resultListOfTypedObjects.iterator();
    while (typedObjects.hasNext()) {
      IDfTypedObject typedObject = (IDfTypedObject) typedObjects.next();
      int attrCount = typedObject.getAttrCount();
      String[] row = new String[attrCount];
      for (int i = 0; i < attrCount; i++) {
        IDfAttr attr = typedObject.getAttr(i);
        String attrName = attr.getName();
        row[i] = typedObject.getString(attrName);
      }
      list.add(row);
    }
    return list;
  }

  public Iterator getResultsAsIteratorOfTypedObjects() {
    return resultListOfTypedObjects.iterator();
  }
}