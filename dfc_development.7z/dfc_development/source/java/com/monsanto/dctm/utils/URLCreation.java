/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils;

import com.documentum.fc.common.DfException;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfCollection;
import com.documentum.fc.client.IDfQuery;
import com.documentum.com.IDfClientX;
import com.documentum.com.DfClientX;

/**
 * Filename:    $RCSfile: URLCreation.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-06-05 01:29:20 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class URLCreation {
  private static final String DEV_HOSTNAME = "stddma00";
  private static final String TEST_HOSTNAME = "sttdma00";
  private static final String PROD_HOSTNAME = "stpdmv00";
  public String processURL(IDfSession session) throws DfException{
    if (session == null)
      throw new DfException("Session is null");
    else {
      String hostName = getHostName(session);
      System.out.println("hostName = " + hostName);
      return getDevURL(hostName);
    }
  }

  private String getDevURL(String hostName) {
    String url = new String();
    String devURL = "http://documentum.dev.monsanto.com/webtop/drl.html?objectId=";
    String testURL = "http://documentum.test.monsanto.com/webtop/drl.html?objectId=";
    String prodURL  = "http://documentum.monsanto.com/webtop/drl.html?objectId=";
    if (hostName.equals(DEV_HOSTNAME))
      url = devURL;
    if (hostName.equals(TEST_HOSTNAME))
      url = testURL;
    if (hostName.equals(PROD_HOSTNAME))
      url = prodURL;
    return url;
  }
  private String getHostName(IDfSession session) throws DfException{
    String hostName = new String();
    String hostNameQuery = "select distinct r_host_name from dm_server_config_s";
    System.out.println("hostNameQuery = " + hostNameQuery);
    IDfCollection hostNameColl = null;
    try {
      hostNameColl = execQuery(hostNameQuery, session);
      while (hostNameColl != null && hostNameColl.next()){
          hostName = hostNameColl.getString("r_host_name");
//        System.out.println("hostName = " + hostName);
      }
    } catch (DfException e) {
      throw e;
    } finally {
          hostNameColl.close();
    }
    return hostName;
  }
    private IDfCollection execQuery(String strQuery, IDfSession session) throws DfException {
        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        q.setDQL(strQuery);
        return q.execute(session, IDfQuery.DF_QUERY);
    }
}