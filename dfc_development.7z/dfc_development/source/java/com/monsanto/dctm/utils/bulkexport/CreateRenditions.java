/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.bulkexport;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

/**
 * Filename:    $RCSfile: CreateRenditions.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddwrig $    	 On:	$Date: 2008-05-09 20:29:50 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class CreateRenditions {
  private IDfSessionManager sessionManager;
  public String docbase;
  public String userName;
  public String objectType;
  private IDfSession session;
  public String password;
  private IDfClient client;
  public String DOCUMENTS_SENT_FOR_RENDITION ;

//  public void execute(Map parameters, OutputStream output) throws DfException {
//    parseJobParameters(parameters);
//    try {
//      createSession();
//      if (session != null) {
//        processDocuments();
//      }
//    }
//    finally {
//      releaseSession();
//    }
//  }

  public void execute() throws DfException, IOException {

    try {
      createSession();
      if (session != null) {
        processDocumentsWithoutRendition();
      }
    }
    finally {
      releaseSession();
    }
  }

  private void parseJobParameters(Map parameters) {
    if (parameters != null) {
      Iterator i = parameters.keySet().iterator();
      while (i.hasNext()) {
        String key = (String) i.next();
        String[] values = (String[]) parameters.get(key);

        if ((key == null) || (key.length() == 0) || (values == null) || (values.length < 1)) {
          continue;
        }
        if (key.equalsIgnoreCase("docbase_name")) {
          docbase = values[0];
        } else if (key.equalsIgnoreCase("user_name")) {
          userName = values[0];
        } else if (key.equalsIgnoreCase("password")) {
          password = values[0];
        }
      }
    }
  }

  private void createSession() throws DfException {
    IDfLoginInfo login = new DfLoginInfo();
    if (userName != null && userName.length() > 0) {
      login.setUser(userName);
    }
    if (password != null && password.length() > 0) {
      login.setPassword(password);
    }
    IDfClient client = DfClient.getLocalClient();
    sessionManager = client.newSessionManager();
    if (docbase != null && docbase.length() > 0) {
      sessionManager.setIdentity(docbase, login);
      session = sessionManager.getSession(docbase);
    }
  }

  private void releaseSession() {
    if (session != null)
      sessionManager.release(session);
  }

  private void processDocumentsWithoutRendition() throws DfException, IOException {
    IDfCollection documentsWithoutRenditioncoll = null;
    IDfSysObject sysObj = null;
    int countNoOfDocumentsProcessed = 0;
    BufferedWriter outputStream =
                new BufferedWriter(new FileWriter(DOCUMENTS_SENT_FOR_RENDITION));
    try {
      documentsWithoutRenditioncoll = execQuery(getDocumentsWithoutRendtionQuery());
      if (documentsWithoutRenditioncoll != null){

        while(documentsWithoutRenditioncoll.next()){
          if (countNoOfDocumentsProcessed == 50) break;
          sysObj = (IDfSysObject) session.getObject(documentsWithoutRenditioncoll.getId("r_object_id"));
          System.out.println("sysObj = " + sysObj.getObjectName());
          System.out.println("countNoOfDocumentsProcessed = " + countNoOfDocumentsProcessed);
//          if (!checkVSD(sysObj.getObjectName())) {
            createRendtion(sysObj, outputStream);
            countNoOfDocumentsProcessed ++;
//          }
          }
      }
    } catch (DfException e) {
      System.out.println(e);
      throw e;
    } finally {
      if (documentsWithoutRenditioncoll!= null)
        documentsWithoutRenditioncoll.close();
      if (outputStream!= null)
        outputStream.close();
    }
  }
  private boolean checkVSD(String objectName){
    boolean isObjectVSD = false;
    String vsdExtn = objectName.substring(objectName.lastIndexOf("."));
    System.out.println("vsdExtn = " + vsdExtn);
    if (vsdExtn.equalsIgnoreCase(".vsd"))
      isObjectVSD = true;
    System.out.println("isObjectVSD = " + isObjectVSD);
    return isObjectVSD;
  }
  private void createRendtion(IDfSysObject sysObj, BufferedWriter outputStream) throws DfException, IOException  {
    try {
      sysObj.queue("dm_autorender_win31", "rendition", 0, false, null, "rendition_req_ps_pdf");
      writeToFileDocumentRendered(sysObj, outputStream);
    }catch (DfException e) {
      //created a file of not rendered documents
      System.out.println("Counld not create rendition e = " + e);
      throw e;
    }

  }

  private String getDocumentsWithoutRendtionQuery() {
    StringBuffer documentsWithoutRenditionQuery = new StringBuffer();
    documentsWithoutRenditionQuery.append("SELECT r_object_id,r_version_label,object_name FROM ");// pmf_doc_luling a");
    documentsWithoutRenditionQuery.append(objectType);
    //documentsWithoutRenditionQuery.append(" a WHERE ANY r_version_label = 'Draft' AND NOT EXISTS");
    documentsWithoutRenditionQuery.append(" a WHERE NOT EXISTS");
    documentsWithoutRenditionQuery.append(" (SELECT parent_id FROM dmr_content WHERE ANY i_rendition !=0");
    documentsWithoutRenditionQuery.append(" AND full_format = 'pdf' AND ANY parent_id = a.r_object_id)");
    documentsWithoutRenditionQuery.append(" and a_content_type <> 'pdf' and a_content_type <> 'jpeg'");
    documentsWithoutRenditionQuery.append(" and NOT a_content_type LIKE 'vsd%'");
    //documentsWithoutRenditionQuery.append(" and a_content_type <> 'pdf'");
    documentsWithoutRenditionQuery.append(" and r_modify_date > date('4/10/2008')");
    return documentsWithoutRenditionQuery.toString();
  }
  private IDfCollection execQuery(String strQuery) throws DfException {
    IDfClientX clientx = new DfClientX();
    IDfQuery query = clientx.getQuery();
    query.setDQL(strQuery);
    return query.execute(session, IDfQuery.DF_QUERY);
  }
  private void writeToFileDocumentRendered(IDfSysObject sysObj,BufferedWriter outputStream)
      throws DfException, IOException {
    String documentName = sysObj.getObjectName();
    String folderPath = getFolderPath(sysObj);
//    String version = sysObj.getVersionLabel(0);
//    String version1 = sysObj.getVersionLabel(1);
//    String version2 = sysObj.getVersionLabel(2);
//    String versionLabel = version + " " + version1 + " " + version2;
//    System.out.println("versionLabel = " + versionLabel);
    if (outputStream != null){
      System.out.println("CreateRenditions.writeToFileDocumentRendered");
      outputStream.write(folderPath);
      outputStream.write(",");
      outputStream.write(documentName);
//      outputStream.write(",");
//      outputStream.write(versionLabel);
      outputStream.newLine();
    } else {
      System.out.println("Error in writing to File");
    }
  }
    private String getFolderPath(IDfSysObject sysObj) throws DfException {
    IDfCollection folderPathcoll = null;
    String folderPath = null;
    try {
      folderPathcoll = execQuery(getFolderPathQuery(sysObj.getObjectId().toString()));
      if (folderPathcoll != null){
        while(folderPathcoll.next()){
          folderPath =  folderPathcoll.getString("r_folder_path");
          System.out.println("folderPath = " + folderPath);
        }
      }
      return folderPath;
    } catch (DfException e) {
      System.out.println(e);
      throw e;
    } finally {
      if (folderPathcoll!= null)
        folderPathcoll.close();
    }
  }
  private String getFolderPathQuery(String objectId) {
    StringBuffer folderPathQuery = new StringBuffer();
    folderPathQuery.append("SELECT r_folder_path, r_object_id  FROM dm_folder");
    folderPathQuery.append(" WHERE r_object_id IN");
    folderPathQuery.append(" (SELECT i_folder_id from dm_document where r_object_id = '");
    folderPathQuery.append(objectId);
    folderPathQuery.append("')");
    System.out.println("folderPathQuery = " + folderPathQuery);
    return folderPathQuery.toString();
  }
}