/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.bulkexport;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.DfClient;
import com.documentum.fc.client.IDfClient;
import com.documentum.fc.client.IDfDocument;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.common.*;
import com.documentum.operations.IDfExportNode;
import com.documentum.operations.IDfExportOperation;
/**
 * Filename:    $RCSfile: ExportPDFDocuments.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddwrig $    	 On:	$Date: 2008-05-09 20:29:50 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class ExportPDFDocuments {

      public void exportPDFDoc() {

         processObjects process = new processObjects("ussing","","stltst03");
      }// main

      static class processObjects {

          String strUser; //User Name
          String strPwd; //Password
          String strDocbase; //Docbase

          processObjects(String strUser, String strPwd, String strDocbase){

              this.strUser = strUser;
              this.strPwd = strPwd;
              this.strDocbase = strDocbase;

              this.exportDoc();

          } // processObjects

          public void exportDoc(){

              try{

                  //Creating Session Starts
                  IDfSession sess = null;
                  IDfClient client = DfClient.getLocalClient();
                  IDfClientX clientx = new DfClientX();

                  // Setup login credentials.
                  IDfLoginInfo li = new DfLoginInfo();
                  li.setUser(this.strUser);
                  li.setPassword(this.strPwd);

                  // Connect.
                  sess = client.newSession(this.strDocbase, li);
                  //Creating Session Ends
                  System.out.println(sess.getSessionId());


                  IDfClientX clientX = new DfClientX();
                  IDfClient localClient = clientX.getLocalClient();

                  IDfExportOperation exportOper = clientX.getExportOperation();
                  exportOper.setDestinationDirectory("C:\\TempProject\\luling"); //hard coded the folder in the local file system

                  IDfId objId = new DfId("09001abe8007723f"); //You can pass the object id which you want to export the rendition
                  String repoName = localClient.getDocbaseNameFromId(objId);

                  IDfDocument doc = (IDfDocument) sess.getObject(objId);

                  IDfExportNode expNode = (IDfExportNode) exportOper.add(doc);
//                setFormat specifies the rendition format to export
//                If this method is not called then the default format is
//                exported.
                  expNode.setFormat("pdf"); //hard coded the format

                  if(exportOper.execute())
                  {
                  String filepath = expNode.getFilePath();
                  System.out.println("Export Operation Successful: " + filepath);
                  }
                  else
                  {
                  System.out.println("Export Operation Failed");
                  IDfList errList = exportOper.getErrors();
                  for(int i=0;i<errList.getCount();i++)
                  {
                  System.out.println(errList.getString(i));
                  }

                  }

                 }
                  catch(Exception ex)
                  {System.out.println(ex);}
              }

     }
  }

