/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.bulkexport;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.operations.IDfExportNode;
import com.documentum.operations.IDfExportOperation;

import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

/**
 * Filename:    $RCSfile: ExportPDFDocumentsToFileShare.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddwrig $    	 On:	$Date: 2008-05-09 20:29:50 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class ExportPDFDocumentsToFileShare {//extends MonMonDocs implements IDmMethod {
  private IDfSessionManager sessionManager;
  public String docbase;
  public String userName;
  private IDfSession session;
  public String password;
  public String objectType;
  private String BASE_PATH =  "\\\\gumbo\\team\\PMF_local_copy\\$team\\View"; //"C:\\TempProject\\luling";
  private IDfClient client;
  public String DOCUMENTS_EXPORTED ;// =  "C:\\TempProject\\luling\\DocumentsExported.csv";

//  public void execute(Map parameters, OutputStream output) throws DfException {
//    parseJobParameters(parameters);
//    try {
//      createSession();
//      if (session != null) {
//        processDocuments();
//      }
//    }
//    finally {
//      releaseSession();
//    }
//  }

  public void execute() throws DfException, IOException {

    try {
      createSession();
      if (session != null) {
        processExportPDFDocuments();
      }
    }
    finally {
      releaseSession();
    }
  }

  private void parseJobParameters(Map parameters) {
    if (parameters != null) {
      Iterator i = parameters.keySet().iterator();
      while (i.hasNext()) {
        String key = (String) i.next();
        String[] values = (String[]) parameters.get(key);

        if ((key == null) || (key.length() == 0) || (values == null) || (values.length < 1)) {
          continue;
        }
        if (key.equalsIgnoreCase("docbase_name")) {
          docbase = values[0];
        } else if (key.equalsIgnoreCase("user_name")) {
          userName = values[0];
        } else if (key.equalsIgnoreCase("password")) {
          password = values[0];
        }
      }
    }
  }

  private void createSession() throws DfException {
    IDfLoginInfo login = new DfLoginInfo();
    if (userName != null && userName.length() > 0) {
      login.setUser(userName);
    }
    if (password != null && password.length() > 0) {
      login.setPassword(password);
    }
    IDfClient client = DfClient.getLocalClient();
    sessionManager = client.newSessionManager();
    if (docbase != null && docbase.length() > 0) {
      sessionManager.setIdentity(docbase, login);
      session = sessionManager.getSession(docbase);
    }
  }

  private void releaseSession() {
    if (session != null)
      sessionManager.release(session);
  }

  private String processFolder(IDfSysObject sysObj) throws DfException  {
    String folderPath = getFolderPath(sysObj);
    //remove object name from folder path
    String onlyFolderPath = removeObjectNameFromFolderPath(folderPath);
    String destFolder = createFoderOnFileShare(BASE_PATH,onlyFolderPath);
    return destFolder;
  }

  private String getFolderPath(IDfSysObject sysObj) throws DfException {
    IDfCollection folderPathcoll = null;
    String folderPath = null;
    try {
      folderPathcoll = execQuery(getFolderPathQuery(sysObj.getObjectId().toString()));
      if (folderPathcoll != null){
        while(folderPathcoll.next()){
          folderPath =  folderPathcoll.getString("r_folder_path");
          System.out.println("folderPath = " + folderPath);
        }
      }
      return folderPath;
    } catch (DfException e) {
      System.out.println(e);
      throw e;
    } finally {
      if (folderPathcoll!= null)
        folderPathcoll.close();
    }
  }
  private String removeObjectNameFromFolderPath(String folderPath)  {
    StringBuffer onlyFolderPath = new StringBuffer();
    String pathSep = "/";
    StringTokenizer initTokens = new StringTokenizer(folderPath, pathSep);
    int numbrOfTokens= initTokens.countTokens();
    for (int i = 0 ; i < (numbrOfTokens) ; i++){
      onlyFolderPath.append(initTokens.nextToken());
      onlyFolderPath.append("\\");
    }
    return onlyFolderPath.toString();
  }
  private String createFoderOnFileShare(String base_path, String folderPath) {
    String destDir = base_path + "\\" + folderPath;
    File f = new File(destDir);
    f.mkdirs();
    return destDir;
  }

  private String getFolderPathQuery(String objectId) {
    StringBuffer folderPathQuery = new StringBuffer();
    folderPathQuery.append("SELECT r_folder_path, r_object_id  FROM dm_folder");
    folderPathQuery.append(" WHERE r_object_id IN");
    folderPathQuery.append(" (SELECT i_folder_id from dm_document where r_object_id = '");
    folderPathQuery.append(objectId);
    folderPathQuery.append("')");
    System.out.println("folderPathQuery = " + folderPathQuery);
    return folderPathQuery.toString();
  }

//  private String getDocumentsWithoutRendtionQuery() {
//    StringBuffer documentsWithoutRenditionQuery = new StringBuffer();
//    documentsWithoutRenditionQuery.append("SELECT r_object_id,r_version_label,object_name FROM pmf_doc_luling a");
//    documentsWithoutRenditionQuery.append(" WHERE ANY r_version_label = 'Draft' AND NOT EXISTS");
//    documentsWithoutRenditionQuery.append(" (SELECT parent_id FROM dmr_content WHERE ANY i_rendition !=0");
//    documentsWithoutRenditionQuery.append(" AND full_format = 'pdf' AND ANY parent_id = a.r_object_id)");
//    documentsWithoutRenditionQuery.append(" and a_content_type <> 'pdf'");
//    return documentsWithoutRenditionQuery.toString();
//  }
  private IDfCollection execQuery(String strQuery) throws DfException {
    IDfClientX clientx = new DfClientX();
    IDfQuery query = clientx.getQuery();
    query.setDQL(strQuery);
    return query.execute(session, IDfQuery.DF_QUERY);
  }
  private void processExportPDFDocuments() throws DfException, IOException {
    //get Documents to be exported
    IDfCollection documentsWithRenditioncoll = null;
    IDfSysObject sysObj = null;
    String destFolder = null;
    BufferedWriter outputStream =
                new BufferedWriter(new FileWriter(DOCUMENTS_EXPORTED));
    int countExportedDocuments = 0;
    try {
      documentsWithRenditioncoll = execQuery(getAllPMFDocumentsQuery());
      if (documentsWithRenditioncoll != null){
        while(documentsWithRenditioncoll.next()){
          if (countExportedDocuments == 50) break;
          sysObj = (IDfSysObject) session.getObject(documentsWithRenditioncoll.getId("r_object_id"));
          System.out.println("sysObj = " + sysObj);
          destFolder = processFolder(sysObj);
          exportPDFDocument(destFolder, sysObj.getObjectId().toString(),outputStream);
          countExportedDocuments++ ;
        }
      }
      System.out.println("countExportedDocuments = " + countExportedDocuments);
    } catch (DfException e) {
      System.out.println(e);
      throw e;
    } finally {
      if (documentsWithRenditioncoll!= null)
        documentsWithRenditioncoll.close();
      if (outputStream!= null)
        outputStream.close();
    }
  }
  private void exportPDFDocument(String destFolder, String objectId,BufferedWriter outputStream)
                                    throws DfException, IOException {
    IDfClientX clientX = new DfClientX();
    System.out.println("destFolder = " + destFolder);
    System.out.println("objectId = " + objectId);
    IDfSysObject sysObj = null;
    try{
      //check if file is already exported
      IDfExportOperation exportOper = clientX.getExportOperation();
      exportOper.setDestinationDirectory(destFolder);
      IDfId objId = new DfId(objectId); //You can pass the object id which you want to export the rendition
      //String repoName = client.getDocbaseNameFromId(objId);
      IDfDocument doc = (IDfDocument) session.getObject(objId);
      IDfExportNode expNode = (IDfExportNode) exportOper.add(doc);
//                setFormat specifies the rendition format to export
//                If this method is not called then the default format is
//                exported.
      expNode.setFormat("pdf"); //hard coded the format
      boolean fileExists = checkFileExists(destFolder,doc.getObjectName());
      System.out.println("fileExists = " + fileExists);
      if (fileExists) {
        System.out.println("File already exists - will not be exported");
      } else {
        if(exportOper.execute())
        {
          String filepath = expNode.getFilePath();
          sysObj = (IDfSysObject) session.getObject(objId);
          System.out.println("sysObj = " + sysObj);
          writeToFileDocumentExported(sysObj, outputStream);
          System.out.println("Export Operation Successful: " + filepath);
        }
        else
        {
          System.out.println("Export Operation Failed");
          IDfList errList = exportOper.getErrors();
          for(int i=0;i<errList.getCount();i++)
          {
            System.out.println(errList.getString(i));
          }

        }
      }

    }
    catch(Exception ex){
      System.out.println(ex);
      throw new DfException(ex);
    }

  }

  private void writeToFileDocumentExported(IDfSysObject sysObj,BufferedWriter outputStream)
                  throws DfException, IOException {
    String documentName = sysObj.getObjectName();
    String folderPath = getFolderPath(sysObj);
    String version = sysObj.getVersionLabel(0);
    String version1 = sysObj.getVersionLabel(1);
//    String version2 = sysObj.getVersionLabel(2);
    String versionLabel = version + " " + version1;// + " " + version2;
    System.out.println("ExportPDFDocumentsToFileShare.writeToFileDocumentExported");
    System.out.println("versionLabel = " + versionLabel);
    if (outputStream != null){
      outputStream.write(folderPath);
      outputStream.write(",");
      outputStream.write(documentName);
      outputStream.write(",");
      outputStream.write(versionLabel);
      outputStream.newLine();
    } else {
      System.out.println("Error in writing to File");
    }
  }

  private boolean checkFileExists(String folderPath, String objectName) {
    objectName = objectName + ".pdf";
    String fileWithPath = folderPath + objectName;
    System.out.println("fileName = " + fileWithPath);
    File f = new File(fileWithPath);
    return f.exists();
  }

  private String getAllPMFDocumentsQuery() {
  StringBuffer documentsWithRenditionQuery = new StringBuffer();
  documentsWithRenditionQuery.append("SELECT r_object_id, object_name FROM ");
  documentsWithRenditionQuery.append(objectType);//"pmf_doc_luling a");
  documentsWithRenditionQuery.append(" WHERE a_content_type = 'pdf'");

  /*documentsWithRenditionQuery.append(" a WHERE EXISTS");
  documentsWithRenditionQuery.append(" (SELECT * FROM dmr_content WHERE ANY i_rendition != 0");
  documentsWithRenditionQuery.append(" AND full_format = 'pdf' AND ANY parent_id = a.r_object_id)");*/
    System.out.println("documentsWithRenditionQuery = " + documentsWithRenditionQuery);
  return documentsWithRenditionQuery.toString();
}
}