/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.bulkexport;

import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: testPDF.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ddwrig $    	 On:	$Date: 2008-05-09 20:29:50 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class testPDF  extends TestCase {

  public void testCreatePMFRendtions() throws Exception {
    CreateRenditions exp = new CreateRenditions();
    exp.docbase = "stlprod2"; //"stltst03";
    exp.userName = "dmadmin";
    exp.password = "NewDctm5";
    exp.objectType = "manu_doc";
    exp.DOCUMENTS_SENT_FOR_RENDITION = "C:\\Documents and Settings\\DDWRIG\\Desktop\\renditions\\render.csv";
    exp.execute();
  }
//  public void testCreateWCMRendtions() throws Exception {
//    CreateRenditions exp = new CreateRenditions();
//    exp.docbase = "stlagp02"; //"stltst03";
//    exp.userName = "dmadmin";
//    exp.password = "NewDctm5";
//    exp.objectType = "wcm_luling";
//    exp.DOCUMENTS_SENT_FOR_RENDITION = "C:\\TempProject\\luling\\WCMDocumentsSentForRendition1.csv";
//    exp.execute();
//  }
  /*public void testPMFExport() throws Exception {
    ExportPDFDocumentsToFileShare exp = new ExportPDFDocumentsToFileShare();
    exp.docbase = "stlagp02";// "stltst03";
    exp.userName = "dmadmin";
    exp.password = "NewDctm5";
    exp.objectType = "pmf_doc_luling";
    exp.DOCUMENTS_EXPORTED = "C:\\TempProject\\luling\\PMFDocumentsExported25.csv";
    exp.execute();
  }*/
  /*public void testWCMExport() throws Exception {
    ExportPDFDocumentsToFileShare exp = new ExportPDFDocumentsToFileShare();
    exp.docbase = "stlprod2";//"mtctst01";
    exp.userName = "dmadmin";
    exp.password = "NewDctm5";
    exp.objectType = "manu_doc";
    exp.DOCUMENTS_EXPORTED = "C:\\Documents and Settings\\DDWRIG\\Desktop\\renditions\\exportedlist.txt";
    exp.execute();
  }*/
//      public void testRemoveAllPMFDocsNotDoc() throws Exception {
//      ExportPDFDocumentsToFileShare exp = new ExportPDFDocumentsToFileShare();
//      exp.docbase = "stltst03";
//      exp.userName = "dmadmin";
//      exp.password = "NewDctm5";
//      exp.removeAllDocumentsNotDoc();
//    }
   public static void main(String[] args)
   {
      testPDF test = new testPDF();
      try
      {
         test.testCreatePMFRendtions();
      }
      catch (Exception e)
      {
         System.err.println("Exception occurred");
         System.err.println(e.getMessage());
         e.printStackTrace();
      }
   }
}