/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.pathgeneration;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.common.DfException;

import java.util.ArrayList;
import java.util.List;

/**
 * Filename:    $RCSfile: DefaultPathGenerator.java,v $
 * Label:       $Name: not supported by cvs2svn $
 * Last Change: $Author: lakench $    	 On:	$Date: 2007-05-14 21:38:20 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class DefaultPathGenerator implements PathGenerator {
    protected List listOfAttrNames = null;
    protected String prefix;

    public DefaultPathGenerator() {
    }

    public DefaultPathGenerator(String prefix, List listOfAttrNames) {
        this.prefix = prefix;
        this.listOfAttrNames = listOfAttrNames;
    }

    public List generatePaths(IDfPersistentObject typedObject) throws
                                                               DfException {
        List alPaths = new ArrayList();
        if (prefix != null && prefix.length() > 0) {
            alPaths.add(prefix);
        }
        if (listOfAttrNames != null) {
            alPaths = generatePaths(typedObject, listOfAttrNames, alPaths);
        }
        alPaths = postProcessPathList(typedObject, alPaths);
        return alPaths;
    }

    protected List postProcessPathList(IDfPersistentObject typedObject, List alPaths) throws DfException {
        return alPaths;
    }

    private List generatePaths(IDfPersistentObject typedObject, List listOfAttributesToAssemble, List runningListOfPaths) throws
                                                                                                                          DfException {
        if (baseCase(listOfAttributesToAssemble)) {
            return runningListOfPaths;
        } else {
            return recurse(listOfAttributesToAssemble, typedObject, runningListOfPaths);
        }
    }

    private List recurse(List listOfAttributesToAssemble, IDfPersistentObject typedObject, List runningListOfPaths) throws
                                                                                                                    DfException {
        List paths = new ArrayList();

        String attrName = (String) listOfAttributesToAssemble.get(0);
        for (int i = 0; i < typedObject.getValueCount(attrName); i++) {
            String attributeValue = typedObject.getRepeatingString(attrName, i);
            addAttributeValueToEachExistingPath(runningListOfPaths, paths, attributeValue);
        }

        return generatePaths(typedObject, oneStepCloserToBaseCase(listOfAttributesToAssemble), paths);
    }

    private boolean baseCase(List listOfAttributesToAssemble) {
        return listOfAttributesToAssemble.size() == 0;
    }

    private void addAttributeValueToEachExistingPath(List listOfExistingPaths, List newPaths, String attributeValue) {
        if (listOfExistingPaths.isEmpty()) {
            newPaths.add(joinPathComponents(attributeValue, null));
        } else {
            for (int j = 0; j < listOfExistingPaths.size(); j++) {
                String existingPath = (String) listOfExistingPaths.get(j);
                newPaths.add(joinPathComponents(existingPath, attributeValue));
            }
        }
    }


    private List oneStepCloserToBaseCase(List listOfAttributesToAssemble) {
        List newListOfAttributesToAssemble = new ArrayList(listOfAttributesToAssemble);
        newListOfAttributesToAssemble.remove(0);
        return newListOfAttributesToAssemble;
    }

    private String joinPathComponents(String firstPathComponent, String secondPathComponent) {
        if (secondPathComponent == null || secondPathComponent.length() == 0) {
            return firstPathComponent;
        } else {
            return firstPathComponent + "/" + secondPathComponent;
        }
    }

}