/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.pathgeneration;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfLogger;
import com.documentum.fc.common.IDfId;
import com.monsanto.dctm.utils.DFCSessionUtils;

import java.io.*;
import java.util.StringTokenizer;

/**
 * Filename:    $RCSfile: RecursiveFolderCreation.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2007-05-22 18:57:46 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */


public class RecursiveFolderCreation
{
  private static final String CLASSNAME = "com.monsanto.dctm.utils.pathgeneration.RecursiveFolderCreation";
  private static PathCreationUtils recursiveFolder = new PathCreationUtils();
  private static IDfSession session;

  //get all the arguments
    public static void main(String[] args) {
        System.out.println("length of argument = "+ args.length);
        if (validateArgs(args)) {
            execute(args);
        } else {
            exitWithUsageMessage();
        }
    }

    //not enough arguments given exit with message
  public static void exitWithUsageMessage() {
    System.err.println("Please enter the arguments.. Docbase Username Password Filename");
    System.exit(1);
  }

  //ensure that there are sufficient arguments
  public static boolean validateArgs(String[] args) {
    return args.length == 4;
  }

  //process arguments and get session
  //The first line of the folder creation file should contain folder acl name and acl domain.
  //read file and separate each line into the folders to be created
  //call folder creation for each line
  public static void execute(String[] args)
  {
         String fileName = args[3]; //"c:\\testfiles\\wcmfolders1.txt";

         IDfSession sess = null;
         //String folderPth = null;
         try
         {
            sess = DFCSessionUtils.login(args[0], args[1], args[2], null);
            String wcmFolders[] = readMyFile(fileName);

             for (int i = 0; i < wcmFolders.length ; i++){
               System.out.println("Created folder: " + wcmFolders[i]);
               IDfId newId = recursiveFolder.createFolder(sess,wcmFolders[i],null,null,null);
                 System.out.println("Created folder: " + newId);
                 IDfSysObject docObj =(IDfSysObject) sess.getObject(newId);
             }

         }catch (Exception e) {
            DfLogger.debug(CLASSNAME, "Error during folder creation " + e.getMessage(), null, null);
           } finally {
            DFCSessionUtils.logout();
        }
    }

   //initialize the acl name, acl domain by reading the first line of the file
   //separately
   public static void initSetup(String recordInit, String pathSep)
   {
        if (pathSep == null || (pathSep.length() == 0))
    {
            pathSep = ":";
     }
        StringTokenizer initTokens = new StringTokenizer(recordInit, pathSep);
        //repoName = initTokens.nextToken();
        String strFolderAcl = initTokens.nextToken();
        String strAclDomain = initTokens.nextToken();
        recursiveFolder.setFolderAcl(strFolderAcl, strAclDomain);
   }

   // reads a file that and gets each line as folder to be created into an array.
   public static String [] readMyFile(String fileName)
   {
       DataInputStream dis = null;
       String record = new String();
       String recordInit = new String();
       int recCount = 0;
       String  folders[] = new String[100];
       try {
         File f = new File(fileName);
         FileReader fr = new FileReader(f);
         BufferedReader br = new BufferedReader(fr);
         recordInit = br.readLine();
          System.out.println(recordInit);
          //process the first line separtely ie get folder acl and acl domain
          initSetup(recordInit, null);
          //get all remaining lines
          while ( (record=br.readLine()) != null ) {
           folders[recCount]= record;
             recCount++;
             System.out.println(recCount + ": " + record);//+ folders[recCount]);
          }

       } catch (IOException e) {
          // catch io errors from FileInputStream or readLine()
          System.out.println("Uh oh, got an IOException error!" + e.getMessage());
          DfLogger.debug(CLASSNAME, "Got an IOException error!" + e.getMessage(), null, null);

       } finally {
          // if the file opened okay, make sure we close it
          if (dis != null) {
          try {
                dis.close();
          } catch (IOException ioe) {
             DfLogger.debug(CLASSNAME, "Error during folder creation " + ioe.getMessage(), null, null);
          }
         }
       }
       return folders;
    }
}
