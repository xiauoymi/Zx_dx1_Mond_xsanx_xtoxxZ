/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.pathgeneration.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.monsanto.dctm.utils.DFCSessionUtils;
import com.monsanto.dctm.utils.pathgeneration.PathCreationUtils;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.util.Map;

/**
 * Filename:    $RCSfile: PathCreationUtils_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2007-05-22 18:59:14 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public class PathCreationUtils_AT extends TestCase {

  private static final String TESTDOCBASE = "mtctst01";
  private static final String TESTUSERID = "devl04";
  private static final String TESTTICKET = "devl04";
  private static final String TESTPATH = "/WCM Materials/testfolder1";

//  private IDfSessionManager sessionManager = null;
  private Map testArgs;
  private ByteArrayOutputStream outputStream;
  private PathCreationUtils pathCreation;
  private IDfSession userSession;
  protected void setUp() throws Exception {
    pathCreation = new PathCreationUtils();
    outputStream = new ByteArrayOutputStream();
  }


  public void testCreateFolder() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, TESTUSERID, TESTTICKET );
    userSession = sessionManager.getSession(TESTDOCBASE);
    assertNotNull(userSession);

    pathCreation.createFolder(userSession, TESTPATH);
  }
}