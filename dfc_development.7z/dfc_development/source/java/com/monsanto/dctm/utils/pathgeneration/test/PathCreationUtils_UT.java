/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.pathgeneration.test;

import com.documentum.fc.client.IDfPersistentObject;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockPersistentObject;
import com.monsanto.dctm.test.MockFolder;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.util.Map;

/**
 * Filename:    $RCSfile: PathCreationUtils_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2007-05-22 18:58:59 $
 *
 * @author ussing
 * @version $Revision: 1.1 $
 */
public class PathCreationUtils_UT extends TestCase {

  private static final String TESTDOCBASE = "testdocbase";
  private static final String TESTUSERID = "testuserid";
  private static final String TESTTICKET = "testticket";

  private static final String DOCBASE_ARG_NAME = "docbase";
  private static final String USERID_ARG_NAME = "userid";
  private static final String TICKET_ARG_NAME = "ticket";

  private static final String TESTPATH = "/WCM Materials/testfolder"; //"/a/b/c/d";
  private static final String QUALIFICATION = "dm_cabinet where object_name='WCM Materials'";
  private static final String FOLDERQUALIFICATION = " dm_sysobject where FOLDER('/WCM Materials')  and object_name='testfolder'";
  private MockPersistentObject object = new MockPersistentObject();
  private MockDfSessionManager sessionManager;
  private Map testArgs;
  private ByteArrayOutputStream outputStream;
  private MockPathCreationUtils mock;
  private MockSession session;
 // private IDfSession userSession;

  protected void setUp() throws Exception {
    sessionManager = new MockDfSessionManager();
    mock = new MockPathCreationUtils(sessionManager);
    outputStream = new ByteArrayOutputStream();

  }
    private void addValidUserToSession() throws DfException {
        DfLoginInfo loginInfo = new DfLoginInfo();
        loginInfo.setUser(TESTUSERID);
        loginInfo.setPassword(TESTTICKET);
        sessionManager.setIdentity(TESTDOCBASE, loginInfo);
        session = (MockSession) sessionManager.getSession(TESTDOCBASE);
        session.setDocbaseName(TESTDOCBASE);
        session.addObject(object);
    }

  public void testGotUserSession() throws Exception {
      addValidUserToSession();
      IDfSession userSession = mock.sessionManager.getSession(TESTDOCBASE, TESTUSERID);
      assertNotNull(userSession);
      assertEquals(TESTUSERID, userSession.getLoginUserName());
      assertEquals(TESTUSERID, userSession.getLoginInfo().getUser());
      assertEquals(TESTTICKET, userSession.getLoginInfo().getPassword());
  }

  public void testCreateFolder() throws Exception {
    addValidUserToSession();
    //add test cabinet
    MockFolder cabinet = new MockFolder("WCM Materials");
    cabinet.setString("r_object_type", "dm_cabinet");
    cabinet.setString("r_object_id","0c001b61800d8429");
    assertNotNull(cabinet);
    session.addObject((IDfPersistentObject)cabinet, QUALIFICATION);
    //add test folder
    MockFolder folder = new MockFolder("testfolder");
    folder.setString("r_object_type", "dm_folder");
    folder.setString("r_object_id","0b001b6180000164");
    assertNotNull(cabinet);
    session.addObject((IDfPersistentObject)folder,FOLDERQUALIFICATION);
    IDfSession userSession = mock.sessionManager.getSession(TESTDOCBASE, TESTUSERID);
    assertNotNull(userSession);

    mock.createFolder(userSession, TESTPATH);
  }

}