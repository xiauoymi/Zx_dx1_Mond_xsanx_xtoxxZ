/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.test;

import com.documentum.fc.client.IDfQuery;
import com.documentum.fc.client.MockSession;
import com.monsanto.dctm.test.MockDfQuery;
import com.monsanto.dctm.utils.FindVirtualDocumentCycles;
import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: FindVirtualDocumentCycles_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-09-28 20:07:14 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class FindVirtualDocumentCycles_UT extends TestCase {
  public void testCreate() throws Exception {
    FindVirtualDocumentCycles findVirtualDocumentCycles = new FindVirtualDocumentCycles(
        new MockSession("testdocbaseowner"));
    assertNotNull(findVirtualDocumentCycles);
  }

  public void testFindNoCycles() throws Exception {
    MockSession mockSession = new MockSession("testdocbaseowner");
    FindVirtualDocumentCycles findVirtualDocumentCycles = new MockFindVirtualDocumentCycles(
        mockSession);
    List listOfCycles = findVirtualDocumentCycles.find("testobjecttypewithnocycles");
    assertTrue(listOfCycles.isEmpty());
  }

  public void testFindCycles() throws Exception {
    MockSession mockSession = new MockSession("testdocbaseowner");

    FindVirtualDocumentCycles findVirtualDocumentCycles = new MockFindVirtualDocumentCycles(mockSession);
    List listOfCycles = findVirtualDocumentCycles.find("testobjecttype");
    assertNotNull(listOfCycles);
    assertTrue(listOfCycles.contains("testdocwithcycle1"));
    assertTrue(listOfCycles.contains("testdocwithcycle2"));
    assertFalse(listOfCycles.contains("testdocwithnocycle"));
  }

  public class MockFindVirtualDocumentCycles extends FindVirtualDocumentCycles {
    Map mockQueryParams = new HashMap();

    public MockFindVirtualDocumentCycles(MockSession mockSession) {
      super(mockSession);
      setupMockQueryParams();
    }

    private void setupMockQueryParams() {
      Map queryParams1 = new HashMap();
      queryParams1.put("shouldReturnResults", Boolean.FALSE);
      queryParams1.put("results", null);
      queryParams1.put("shouldThrowException", Boolean.TRUE);
      mockQueryParams
          .put("select r_object_id from dm_document in document id('testdocwithcycle1') descend", queryParams1);
      Map queryParams2 = new HashMap();
      queryParams2.put("shouldReturnResults", Boolean.FALSE);
      queryParams2.put("results", null);
      queryParams2.put("shouldThrowException", Boolean.TRUE);
      mockQueryParams
          .put("select r_object_id from dm_document in document id('testdocwithcycle2') descend", queryParams2);
      Map queryParams3 = new HashMap();
      queryParams3.put("shouldReturnResults", Boolean.TRUE);
      List mockResults3 = generateNoCycleResults();
      queryParams3.put("results", mockResults3);
      queryParams3.put("shouldThrowException", Boolean.FALSE);
      mockQueryParams
          .put("select r_object_id from dm_document in document id('testdocwithnocycle') descend", queryParams3);
      Map queryParams4 = new HashMap();
      queryParams4.put("shouldReturnResults", Boolean.TRUE);
      List mockResults4 = generateParentIdsResults();
      queryParams4.put("results", mockResults4);
      queryParams4.put("shouldThrowException", Boolean.FALSE);
      mockQueryParams.put(
          "select distinct parent_id from dmr_containment where parent_id in (select r_object_id from testobjecttype (all))",
          queryParams4);
      Map queryParams5 = new HashMap();
      queryParams5.put("shouldReturnResults", Boolean.TRUE);
      List mockResults5 = generateNoCycleParentIdsResults();
      queryParams5.put("results", mockResults5);
      queryParams5.put("shouldThrowException", Boolean.FALSE);
      mockQueryParams.put(
          "select distinct parent_id from dmr_containment where parent_id in (select r_object_id from testobjecttypewithnocycles (all))",
          queryParams5);
    }

    /**
     * @noinspection RefusedBequest
     */
    protected IDfQuery createIDfQuery(String queryString) {
      return new MockDfQuery(
          ((Boolean) ((Map) mockQueryParams.get(queryString)).get("shouldReturnResults")).booleanValue(),
          ((List) ((Map) mockQueryParams.get(queryString)).get("results")),
          ((Boolean) ((Map) mockQueryParams.get(queryString)).get("shouldThrowException")).booleanValue());
    }

    private List generateNoCycleResults() {
      Map row1 = new HashMap();
      List objectIds1 = new ArrayList();
      objectIds1.add(0, "testdocwithnocycle");
      row1.put("r_object_id", objectIds1);
      List results = new ArrayList();
      results.add(row1);
      return results;
    }

    private List generateParentIdsResults() {
      Map row1 = new HashMap();
      List objectIds1 = new ArrayList();
      objectIds1.add(0, "testdocwithcycle1");
      row1.put("parent_id", objectIds1);
      Map row2 = new HashMap();
      List objectIds2 = new ArrayList();
      objectIds2.add(0, "testdocwithcycle2");
      row2.put("parent_id", objectIds2);
      Map row3 = new HashMap();
      List objectIds3 = new ArrayList();
      objectIds3.add(0, "testdocwithnocycle");
      row3.put("parent_id", objectIds3);
      List results = new ArrayList();
      results.add(row1);
      results.add(row2);
      results.add(row3);
      return results;
    }

    private List generateNoCycleParentIdsResults() {
      Map row = new HashMap();
      List objectIds = new ArrayList();
      objectIds.add(0, "testdocwithnocycle");
      row.put("parent_id", objectIds);
      List results = new ArrayList();
      results.add(row);
      return results;
    }
  }
}