/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.test;

import com.documentum.fc.client.IDfTypedObject;
import com.documentum.fc.common.DfException;
import com.monsanto.dctm.test.MockDfCollection;
import com.monsanto.dctm.test.MockTypedObject;
import com.monsanto.dctm.utils.QueryResultSet;
import junit.framework.TestCase;

import java.util.*;

/**
 * Filename:    $RCSfile: QueryResultSet_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: lakench $    	 On:	$Date: 2007-10-23 15:29:22 $
 *
 * @author lakench
 * @version $Revision: 1.1 $
 */
public class QueryResultSet_UT extends TestCase {
  private MockDfCollection collection;
  private List expectedResultsList;
  private List expectedResultsAsTypedObjectsList;

  protected void setUp() throws Exception {
    super.setUp();
    collection = new MockDfCollection(true, generateTestResults());
    expectedResultsList = generateExpectedResultsList();
    expectedResultsAsTypedObjectsList = generateExpectedResultsAsTypeObjectsList();
  }

  public void testCreate() throws Exception {
    QueryResultSet queryResultSet = new QueryResultSet(collection);
    assertNotNull(queryResultSet);
  }

  public void testGetResultsIterator() throws Exception {
    QueryResultSet queryResultSet = new QueryResultSet(collection);
    Iterator resultsIterator = queryResultSet.getResultsIterator();
    int i = 0;
    while (resultsIterator.hasNext()) {
      String[] row = (String[]) resultsIterator.next();
      assertRowsAreEqual((String[]) expectedResultsList.get(i), row);
      i++;
    }
  }

  public void testGetResultsAsIteratorOfTypedObjects() throws Exception {
    QueryResultSet queryResultSet = new QueryResultSet(collection);
    Iterator resultsIterator = queryResultSet.getResultsAsIteratorOfTypedObjects();
    int i = 0;
    while (resultsIterator.hasNext()) {
      IDfTypedObject row = (IDfTypedObject) resultsIterator.next();
      IDfTypedObject expectedRow = (IDfTypedObject) expectedResultsAsTypedObjectsList.get(i);
      assertEquals(expectedRow.getAttrCount(), row.getAttrCount());
      assertEquals(expectedRow.getString("testattr1"), row.getString("testattr1"));
      assertEquals(expectedRow.getString("testattr2"), row.getString("testattr2"));
      i++;
    }
  }

  private void assertRowsAreEqual(String[] expected, String[] actual) {
    for (int i = 0; i < actual.length; i++) {
      assertTrue("row not equal at column " + i, stringContainedInStringArray(expected[i], actual));
    }
  }

  private boolean stringContainedInStringArray(String expected, String[] actual) {
    for (int i = 0; i < actual.length; i++) {
      if (expected.equals(actual[i])) return true;
    }
    return false;
  }

  private List generateExpectedResultsList() {
    String[] row1 = {"testattr1value1", "testattr2value1"};
    String[] row2 = {"testattr1value2", "testattr2value2"};
    String[] row3 = {"testattr1value3", "testattr2value3"};
    List results = new ArrayList();
    results.add(row1);
    results.add(row2);
    results.add(row3);
    return results;
  }

  private List generateExpectedResultsAsTypeObjectsList() throws DfException {
    IDfTypedObject row1 = new MockTypedObject();
    row1.setString("testattr1", "testattr1value1");
    row1.setString("testattr2", "testattr2value1");
    IDfTypedObject row2 = new MockTypedObject();
    row2.setString("testattr1", "testattr1value2");
    row2.setString("testattr2", "testattr2value2");
    IDfTypedObject row3 = new MockTypedObject();
    row3.setString("testattr1", "testattr1value3");
    row3.setString("testattr2", "testattr2value3");
    List results = new ArrayList();
    results.add(row1);
    results.add(row2);
    results.add(row3);
    return results;
  }

  private List generateTestResults() {
    Map row1 = new HashMap();
    List attr1s1 = new ArrayList();
    attr1s1.add("testattr1value1");
    row1.put("testattr1", attr1s1);
    List attr2s1 = new ArrayList();
    attr2s1.add("testattr2value1");
    row1.put("testattr2", attr2s1);
    Map row2 = new HashMap();
    List attr1s2 = new ArrayList();
    attr1s2.add("testattr1value2");
    row2.put("testattr1", attr1s2);
    List attr2s2 = new ArrayList();
    attr2s2.add("testattr2value2");
    row2.put("testattr2", attr2s2);
    Map row3 = new HashMap();
    List attr1s3 = new ArrayList();
    attr1s3.add("testattr1value3");
    row3.put("testattr1", attr1s3);
    List attr2s3 = new ArrayList();
    attr2s3.add("testattr2value3");
    row3.put("testattr2", attr2s3);
    List results = new ArrayList();
    results.add(row1);
    results.add(row2);
    results.add(row3);
    return results;
  }
}