/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.monsanto.dctm.utils.DFCSessionUtils;
import com.monsanto.dctm.utils.URLCreation;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: URLCreation_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-06-05 01:30:09 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class URLCreation_AT extends TestCase {
  public void testDevURL() throws Exception {
    //use dmadmin as it needs superuser session
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stltst03", "devl30", "devl30");
    IDfSession session = sessionManager.getSession("stltst03");

    URLCreation urlObject = new URLCreation();
    String devURL = urlObject.processURL(session);

    assertNotNull(session);
    assertNotNull(urlObject);
    assertEquals(devURL, "http://documentum.dev.monsanto.com/webtop/drl.html?objectId=");
  }
  public void testTestURL() throws Exception {
    //use dmadmin as it needs superuser session and change the dmcl.ini to point to Test
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stlprod", "devl30", "devl30");
    IDfSession session = sessionManager.getSession("stlprod");

    URLCreation urlObject = new URLCreation();
    String TestURL = urlObject.processURL(session);

    assertNotNull(session);
    assertNotNull(urlObject);
    assertEquals(TestURL, "http://documentum.test.monsanto.com/webtop/drl.html?objectId=");
  }
  public void testProdURL() throws Exception {
    //use dmadmin as it needs superuser session
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager("stlprod", "devl30", "devl30");
    IDfSession session = sessionManager.getSession("stlprod");

    URLCreation urlObject = new URLCreation();
    String TestURL = urlObject.processURL(session);

    assertNotNull(session);
    assertNotNull(urlObject);
    assertEquals(TestURL, "http://documentum.monsanto.com/webtop/drl.html?objectId=");
  }
}