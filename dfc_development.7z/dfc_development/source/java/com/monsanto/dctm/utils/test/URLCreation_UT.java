/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.utils.test;

import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockSysObject;
import com.monsanto.dctm.utils.URLCreation;
import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: URLCreation_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2008-06-05 01:29:52 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class URLCreation_UT extends TestCase {
  private static final String TESTDOCBASE = "testdocbase";
  private static final String TESTUSERID = "testuserid";
  private static final String TESTTICKET = "testticket";
  public void testCreate() throws Exception {
    URLCreation urlObject = new URLCreation();
    assertNotNull(urlObject);
  }
  public void testCreateSession() throws Exception {
    MockDfSessionManager sessionManager = new MockDfSessionManager();
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);

    assertNotNull(session);
  }
    public void testprocessURLSessionNullThrowsException() throws Exception {
    MockSession session = null;
    URLCreation urlObject = new URLCreation();
    try{
    String devURL = urlObject.processURL(session);
    } catch (DfException e) {
      return;
    }
    fail("Session is null");
    assertNull(session);
    assertNotNull(urlObject);
 }
  public void testDevURL() throws Exception {
    MockDfSessionManager sessionManager = new MockDfSessionManager();
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","3d_server_config_id");
    sysObject.setString("r_host_name","stddma00");
    session.addObject(sysObject,"query_cmd,s0,F,F,,,,,select distinct r_host_name from dm_server_config_s");

    URLCreation urlObject = new URLCreation();
    String devURL = urlObject.processURL(session);

    assertNotNull(session);
    assertNotNull(urlObject);
    assertEquals(devURL, "http://documentum.dev.monsanto.com/webtop/drl.html?objectId=");
 }
  public void testTestURL() throws Exception {
    MockDfSessionManager sessionManager = new MockDfSessionManager();
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","3d_server_config_id");
    sysObject.setString("r_host_name","sttdma00");
    session.addObject(sysObject,"query_cmd,s0,F,F,,,,,select distinct r_host_name from dm_server_config_s");

    URLCreation urlObject = new URLCreation();
    String testURL = urlObject.processURL(session);

    assertNotNull(session);
    assertNotNull(urlObject);
    assertEquals(testURL, "http://documentum.test.monsanto.com/webtop/drl.html?objectId=");
 }
  public void testProdURL() throws Exception {
    MockDfSessionManager sessionManager = new MockDfSessionManager();
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","3d_server_config_id");
    sysObject.setString("r_host_name","stpdmv00");
    session.addObject(sysObject,"query_cmd,s0,F,F,,,,,select distinct r_host_name from dm_server_config_s");

    URLCreation urlObject = new URLCreation();
    String prodURL = urlObject.processURL(session);

    assertNotNull(session);
    assertNotNull(urlObject);
    assertEquals(prodURL, "http://documentum.monsanto.com/webtop/drl.html?objectId=");
 }
}