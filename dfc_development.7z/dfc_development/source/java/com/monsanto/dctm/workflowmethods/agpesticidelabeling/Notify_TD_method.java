/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.agpesticidelabeling;

/*
 * Created on Jul 22, 2005
 *
 */

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @author kveeram
 *
 */

public class Notify_TD_method implements IDmMethod
{

    protected IDfSessionManager m_sessionMgr = null;
    protected String m_docbase = null;
    protected String m_userName = null;
    protected String m_workitemId = null;
    protected String m_ticket = null;

    private static final String USER_KEY = "user";
    private static final String DOCBASE_KEY = "docbase_name";
    private static final String WORKITEM_KEY_2 = "workitemId";
    private static final String TICKET_KEY = "ticket";
    private static final String WORKITEM_KEY = "packageId";

    private IDfId docIdObj;
    private String lifeCycleState;
    private boolean lifeCycleOverride;
    private boolean lifeCycleTestOnly;


    public void execute(Map params, OutputStream ostream) throws Exception
    {
        initWorkflowParams(params);
        IDfSessionManager sessionManager = login();
        IDfSession session = null;
        IDfWorkflow wrkflObj = null;
        IDfId wrkflId = null;
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            wrkflId = workitem.getWorkflowId();
            wrkflObj = (IDfWorkflow)session.getObject(wrkflId);
            if(workitem.getRuntimeState() == 0){
            workitem.acquire();

            lifeCycleState = null ;
            lifeCycleOverride=false ;
            lifeCycleTestOnly =false ;
            IDfCollection pkgColl = null;
            DfQuery qry_act = new DfQuery();
            IDfSysObject myObj = null;
            IDfTime t = null;
            IDfList performerListDraftEFPEdit = null;
            IDfList performerListDraftEFPReview = null;
            IDfList performerListRegulatoryEFP = null;
            String activityNameDraftEFPEdit = "DraftEFP_Edit";
            String activityDraftEFPEditPerfrm = "";
            String activityNameDraftEFPReview = "DraftEFP_Review";
            String activityDraftEFPReviewPerfrm = "";
            String activityNameRegulatoryEFP = "Regulatory_EFP";
            String activityRegulatoryEFPPerfrm = "";

              pkgColl = workitem.getPackages("");

            if (pkgColl != null)
                 {
                  while (pkgColl.next())
                    {
		       String docId = pkgColl.getString("r_component_id");
                       ostream.write(docId.getBytes());
                       int docCount = pkgColl.getValueCount("r_component_id");
                          for (int i=0; i <=(docCount-1); i++)
                               {
                                 docIdObj = pkgColl.getRepeatingId("r_component_id", i);

                                 if (docIdObj!=null)
                                    {
                                      IDfId sysobjID = new DfId(docId);
                                      IDfSysObject doc = (IDfSysObject)session.getObject(sysobjID);

                                      //getting user from activity DraftEFP
                                       //   performerListDraftEFP = wrkflObj.getPerformers(activityNameDraftEFP);
                                        activityDraftEFPEditPerfrm = wrkflObj.getSupervisorName();
                                        System.out.println("##### String Supervisor Name "+activityDraftEFPEditPerfrm);

                                       //   int percnt = performerListDraftEFP.getCount();
                                       //   for (int a=0; a<percnt; a++)
                                       //   {
                                        //      activityDraftEFPPerfrm = performerListDraftEFP.getString(a);
                                        //   }

                                       //getting user from activity ReviewDraftEFP
                                          performerListDraftEFPReview = wrkflObj.getPerformers(activityNameDraftEFPReview );
                                          int percnt1 = performerListDraftEFPReview.getCount();
                                          for (int a=0; a<percnt1; a++)
                                           {
                                              activityDraftEFPReviewPerfrm = performerListDraftEFPReview.getString(a);
                                           }

                                       //getting user from activity Regulatory_EFP
                                          performerListRegulatoryEFP = wrkflObj.getPerformers(activityNameRegulatoryEFP);
                                          int percnt2 = performerListRegulatoryEFP.getCount();
                                          for (int a=0; a<percnt2; a++)
                                           {
                                             activityRegulatoryEFPPerfrm  = performerListRegulatoryEFP.getString(a);
                                           }

                                          //Notification to Review DraftEFP
                                          if( activityRegulatoryEFPPerfrm.equals( activityDraftEFPEditPerfrm))
                                          {
                                             String mess1 = "The status of the attached document has been changed from 'DraftEFP' to 'Edited for Print' completing the workflow for the child document.";
                                             String mess2 = "Labeling has been notified of this event.";
                                             String mess = mess1+'\n'+mess2;
                                             System.out.println("*** Printlines *** "+ mess );
                                             String eventName="Documentum Workflow Notification";
                                             IDfId inboxId = doc.queue(activityDraftEFPReviewPerfrm,eventName,1,true,t,mess);
                                          }
                                          else   //Notification to DraftEFP
                                          {
                                              String mess1 = "The status of the attached document has been changed from 'DraftEFP' to 'Edited for Print' completing the workflow for the child document.";
                                             String mess2 = "Labeling has been notified of this event.";
                                             String mess = mess1+'\n'+mess2;
                                             System.out.println("*** Printlines *** "+ mess );
                                             String eventName="Documentum Workflow Notification";
                                             IDfId inboxId = doc.queue( activityDraftEFPEditPerfrm,eventName,1,true,t,mess);
                                          }
             }
           }
          }
         }
            }
           workitem.complete();
        }
        catch (DfException e)
        {
                ostream.write(e.getMessage().getBytes());
                e.printStackTrace();    // spit out to stderr as well
                throw e;
        } finally
        {
            if ( session != null )
                sessionManager.release(session);
        }

    }

    protected void initWorkflowParams(Map params)
    {
        // get the 4 WF-related parameters always passed in by Server
       Set keys = params.keySet();
       Iterator iter = keys.iterator();
       while (iter.hasNext())
       {
           String key = (String) iter.next();
           if( (key == null) || (key.length() == 0) )
           {
               continue;
           }
           String []value = (String[])params.get(key);

           if ( key.equalsIgnoreCase(USER_KEY) )
               m_userName = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(DOCBASE_KEY) )
               m_docbase = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(WORKITEM_KEY_2 ) )
               m_workitemId = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(WORKITEM_KEY ) )
               m_workitemId = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(TICKET_KEY) )
               m_ticket = (value.length > 0) ? value[0] : "";
       }
   }

   protected IDfSessionManager login() throws DfException
   {
       if (m_docbase == null || m_userName == null || m_ticket == null )
           return null;

       // now login
       IDfClient dfClient = DfClient.getLocalClient();

       if (dfClient != null)
       {
           IDfLoginInfo li = new DfLoginInfo();
           li.setUser(m_userName);
           li.setPassword(m_ticket);
           li.setDomain(null);

           IDfSessionManager sessionMgr = dfClient.newSessionManager();
           sessionMgr.setIdentity(m_docbase, li);
           return sessionMgr;
       }

       return null;
   }

}
