/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.agpesticidelabeling;

/*
 * Created on Jul 13, 2005
 *
 */

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;

import com.documentum.mthdservlet.IDmMethod;
import com.documentum.fc.common.IDfId;
import java.util.*;
import java.io.OutputStream;

/**
 * @author kveeram
 *
 */

public class SetUsersFromPreviousActivityForREG implements IDmMethod
{

    protected IDfSessionManager m_sessionMgr = null;
    protected String m_docbase = null;
    protected String m_userName = null;
    protected String m_workitemId = null;
    protected String m_ticket = null;

    private static final String USER_KEY = "user";
    private static final String DOCBASE_KEY = "docbase_name";
    private static final String WORKITEM_KEY_2 = "workitemId";
    private static final String TICKET_KEY = "ticket";
    private static final String WORKITEM_KEY = "packageId";

    private IDfId docIdObj;
    private String lifeCycleState;
    private boolean lifeCycleOverride;
    private boolean lifeCycleTestOnly;


    public void execute(Map params, OutputStream ostream) throws Exception
    {
        initWorkflowParams(params);
        IDfSessionManager sessionManager = login();
        IDfSession session = null;
        IDfWorkflow wrkflObj = null;
        IDfId wrkflId = null;
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            wrkflId = workitem.getWorkflowId();
            wrkflObj = (IDfWorkflow)session.getObject(wrkflId);
            if(workitem.getRuntimeState() == 0){
            workitem.acquire();

            lifeCycleState = null ;
            lifeCycleOverride=false ;
            lifeCycleTestOnly =false ;
            IDfList activityPerfmrList = null;
            IDfCollection pkgColl = null;
            IDfSysObject myObj = null;
            IDfACL newACL = null;
            int prfmCount = 0;
            IDfList performerList = null;
            IDfList selectedUsersList = null;
            String activityRegulatorySubmitor = "Regulatory_Submitor";
            String activityNameSubmittedAwaitingApproval = "Submitted_Awaiting_Approval";



            //get activity names whose performers are choosen by some other activities
              performerList = wrkflObj.getPerformers(activityRegulatorySubmitor);
              int percnt = performerList.getCount();
              IDfValue actorfListVal = null;

              for (int a=0; a<percnt; a++)
               {
                  String performerName = performerList.getString(a);
               }
                  wrkflObj.setPerformers(activityNameSubmittedAwaitingApproval , performerList);


            }
            workitem.complete();
        }
        catch (DfException e)
        {
                ostream.write(e.getMessage().getBytes());
                e.printStackTrace();    // spit out to stderr as well
                throw e;
        } finally
        {
            if ( session != null )
                sessionManager.release(session);
        }

    }

    protected void initWorkflowParams(Map params)
    {
        // get the 4 WF-related parameters always passed in by Server
       Set keys = params.keySet();
       Iterator iter = keys.iterator();
       while (iter.hasNext())
       {
           String key = (String) iter.next();
           if( (key == null) || (key.length() == 0) )
           {
               continue;
           }
           String []value = (String[])params.get(key);

           if ( key.equalsIgnoreCase(USER_KEY) )
               m_userName = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(DOCBASE_KEY) )
               m_docbase = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(WORKITEM_KEY_2 ) )
               m_workitemId = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(WORKITEM_KEY ) )
               m_workitemId = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(TICKET_KEY) )
               m_ticket = (value.length > 0) ? value[0] : "";
       }
   }

   protected IDfSessionManager login() throws DfException
   {
       if (m_docbase == null || m_userName == null || m_ticket == null )
           return null;

       // now login
       IDfClient dfClient = DfClient.getLocalClient();

       if (dfClient != null)
       {
           IDfLoginInfo li = new DfLoginInfo();
           li.setUser(m_userName);
           li.setPassword(m_ticket);
           li.setDomain(null);

           IDfSessionManager sessionMgr = dfClient.newSessionManager();
           sessionMgr.setIdentity(m_docbase, li);
           return sessionMgr;
       }

       return null;
   }

}
