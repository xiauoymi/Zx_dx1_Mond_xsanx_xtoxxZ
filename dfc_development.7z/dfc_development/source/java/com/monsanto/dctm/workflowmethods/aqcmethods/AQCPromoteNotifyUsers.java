/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.aqcmethods;

/*
 * AQCPromoteNotifyUsers.java
 *
 * Created By pveerav
 * Created On Apr 28, 2006, 10:00 AM
 *
 * Description: Workflow method to automatically promote the AQC document from
 *              Draft to Active state(..only if it's already in Draft) and
 *              sends a notification to all the members of 'aqc_user' group.
 */


import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class AQCPromoteNotifyUsers
    implements IDmMethod {

  public AQCPromoteNotifyUsers() {
    m_sessionMgr = null;
    m_docbase = null;
    m_userName = null;
    m_workitemId = null;
    m_ticket = null;
  }

  public void execute(Map params, OutputStream ostream)
      throws Exception {
    IDfSessionManager sessionManager;
    IDfSession session;
    Exception exception;
    initWorkflowParams(params);
    sessionManager = login();
    session = null;
    IDfWorkflow wrkflObj = null;
    IDfId wrkflId = null;
    try {
      IDfId workitemID = new DfId(m_workitemId);
      session = sessionManager.getSession(m_docbase);
      IDfWorkitem workitem = (IDfWorkitem) session.getObject(workitemID);
      wrkflId = workitem.getWorkflowId();
      wrkflObj = (IDfWorkflow) session.getObject(wrkflId);
      if (workitem.getRuntimeState() == 0)
        workitem.acquire();
      lifeCycleState = null;
      lifeCycleOverride = false;
      lifeCycleTestOnly = false;
      IDfCollection pkgColl = null;
      ostream.write("Getting packages and promoting document(s)".getBytes());
      pkgColl = workitem.getPackages("");
      if (pkgColl != null) {
        while (pkgColl.next()) {
          String docId = pkgColl.getString("r_component_id");
          ostream.write(docId.getBytes());
          int docCount = pkgColl.getValueCount("r_component_id");
          int i = 0;
          while (i <= docCount - 1) {
            docIdObj = pkgColl.getRepeatingId("r_component_id", i);
            if (docIdObj != null) {
              IDfId sysobjID = new DfId(docId);
              IDfSysObject doc = (IDfSysObject) session.getObject(sysobjID);
              String docState = doc.getCurrentStateName();
              if (docState.equals("Draft")) {
                doc.promote(lifeCycleState, lifeCycleOverride, lifeCycleTestOnly);
              }
              notifyUsers(doc, session);
            }
            i++;
          }
        }
        pkgColl.close();
      }
      workitem.complete();
    }
    catch (DfException e) {
      ostream.write(e.getMessage().getBytes());
      e.printStackTrace();
      throw e;
    }
    finally {
      if (session != null) {
        try {
          sessionManager.release(session);
        }
        catch (Exception e) {
          System.err.println(" error in releasing Session:: " + e);
        }
      }
    }
  }

  protected void initWorkflowParams(Map params) {
    Set keys = params.keySet();
    Iterator iter = keys.iterator();
    do {
      if (!iter.hasNext())
        break;
      String key = (String) iter.next();
      if (key != null && key.length() != 0) {
        String value[] = (String[]) params.get(key);
        if (key.equalsIgnoreCase("user"))
          m_userName = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase("docbase_name"))
          m_docbase = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase("workitemId"))
          m_workitemId = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase("packageId"))
          m_workitemId = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase("ticket"))
          m_ticket = value.length <= 0 ? "" : value[0];
      }
    } while (true);
  }

  protected IDfSessionManager login()
      throws DfException {
    if (m_docbase == null || m_userName == null || m_ticket == null)
      return null;
    IDfClient dfClient = DfClient.getLocalClient();
    if (dfClient != null) {
      IDfLoginInfo li = new DfLoginInfo();
      li.setUser(m_userName);
      li.setPassword(m_ticket);
      li.setDomain(null);
      IDfSessionManager sessionMgr = dfClient.newSessionManager();
      sessionMgr.setIdentity(m_docbase, li);
      return sessionMgr;
    } else {
      return null;
    }
  }

  protected void notifyUsers(IDfSysObject sysObj, IDfSession sess) throws DfException {
    // fix ticket # 0159632
    if (notifyGroup == null) return;
    IDfGroup notify = sess.getGroup(notifyGroup);
    if (notify == null || notify.getAllUsersNamesCount() < 1) {
      System.out.println("@@@@@@<<<<<< Notification group " + notifyGroup + " is either unavailable or empty");
      return;
    }
    System.out.println(
        ">>>>>SENDING " + notify.getAllUsersNamesCount() + " NOTIFICATION(S) FOR DOC: " + sysObj.getObjectName());
    String message = "The attached document has been Reviewed, Approved and stored in 'Active' folder.";
    sysObj.queue(notifyGroup, "Approval Notice", 10, true, null, message);
    // fix ticket # 0159632
    /*
    String eventName = "Documentum Workflow Notification";
    IDfTime t = null;
    String performerName = null;
    String message = "The attached document has been Reviewed, Approved and stored in 'Active' folder.";
    String qryStr = "select i_all_users_names from dm_group where group_name ='aqc_user'";
    //System.out.println("qryStr "+qryStr);
    IDfCollection coll = null; //Collection for the result
    IDfClientX clientx = new DfClientX();
    IDfQuery q = clientx.getQuery(); //Create query object

    q.setDQL(qryStr); //Give it the query
    coll = q.execute(sess, IDfQuery.DF_READ_QUERY);
    if (coll != null) {
      while (coll.next()) {
        performerName = coll.getString("i_all_users_names");
        if (performerName.length() != performerName.trim().length()) {
          System.out.println("Illegal performer name (extra spaces) = " + performerName);
          continue;
        }
        docObj.queue(performerName, eventName, 1, true, t, message);
      }
    }
    if (coll != null)
      coll.close();
    */

  }

  protected IDfSessionManager m_sessionMgr;
  protected String m_docbase;
  protected String m_userName;
  protected String m_workitemId;
  protected String m_ticket;
  private static final String USER_KEY = "user";
  private static final String DOCBASE_KEY = "docbase_name";
  private static final String WORKITEM_KEY_2 = "workitemId";
  private static final String TICKET_KEY = "ticket";
  private static final String WORKITEM_KEY = "packageId";
  // fix ticket # 0159632
  protected String notifyGroup = "aqc_user";
  // fix ticket # 0159632
  private IDfId docIdObj;
  private String lifeCycleState;
  private boolean lifeCycleOverride;
  private boolean lifeCycleTestOnly;
}