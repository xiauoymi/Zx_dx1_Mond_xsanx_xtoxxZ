package com.monsanto.dctm.workflowmethods.biotechmanuscript;

import com.documentum.mthdservlet.IDmMethod;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfList;
import com.documentum.fc.client.*;
import com.monsanto.dctm.utils.DFCSessionUtils;

import java.util.Map;
import java.util.Date;
import java.util.Set;
import java.util.Iterator;
import java.io.OutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Mar 18, 2009
 * Time: 4:31:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class WF_BiotechManuscriptSendNotifications implements
        IDmMethod {

    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    private IDfId docIdObj;
    private IDfSessionManager sessionManager;
    protected String notifyUsersGroup = null;
    protected String notifyAuthorsGroup = null;
    protected String notifyAdminsGroup = null;
    protected String versionComments = null;

    public void execute(Map map, OutputStream outputStream) throws Exception {
        validateArguments(map);
        IDfSession session = null;
        IDfCollection pkgColl = null;
        IDfWorkitem workitem = null;
        try {
            session = getSession(m_docbase,m_userName);
            IDfId workitemID = new DfId(m_workitemId);
            workitem = (IDfWorkitem)session.getObject(workitemID);
            System.out.println("WF_BiotechManuscriptSendNotifications.execute workitem = " + workitem.getObjectId() + " workitem.getRuntimeState() = " + workitem.getRuntimeState());
            Date dateBeforeAcquire = new Date();
            System.out.println("WF_BiotechManuscriptSendNotifications.execute workitem = " + workitem.getObjectId() + " BEFORE ACQUIRE = " + dateBeforeAcquire.getTime() + " in format " + dateBeforeAcquire.toString());
            if ((workitem.getRuntimeState() != workitem.DF_WI_STATE_ACQUIRED))// || (workitem.getRuntimeState() == 0))
            {
                System.out.println("WF_BiotechManuscriptSendNotifications.execute Acquiring workitem " + workitem.getObjectId());
                workitem.acquire();
                Date dateAfterAcquire = new Date();
                System.out.println("WF_BiotechManuscriptSendNotifications.execute workitem = " + workitem.getObjectId() + " AFTER ACQUIRE = " + dateAfterAcquire.getTime() + " in format " + dateAfterAcquire.toString());
            }
            System.out.println("WF_BiotechManuscriptSendNotifications.execute before getting packages workitem.getRuntimeState() = " + workitem.getRuntimeState());
            pkgColl = workitem.getPackages("");
            if(pkgColl != null) {
                while(pkgColl.next()) {
                    String docId = pkgColl.getString("r_component_id");
                    int docCount = pkgColl.getValueCount("r_component_id");
                    for (int i = 0; i < docCount; i++) {
                        docIdObj = pkgColl.getRepeatingId("r_component_id", i);
                        if(docIdObj != null) {
                            System.out.println("WF_BiotechManuscriptSendNotifications.execute Got the component id before Notify: " + "docIdObj = " + docIdObj);
                            notify(docIdObj,session,workitem);
                            System.out.println("WF_BiotechManuscriptSendNotifications.execute After Notify and before workitem complete: " + "docIdObj = " + docIdObj);
                        }
                    }
                }
            }
            finishWorkitem(workitem);
        } catch(DfException e)
        {
            e.printStackTrace();
            throw e;
        } finally {
            pkgColl.close();
            if (session != null) {
                sessionManager.release(session);
            }
        }

    }
    private void finishWorkitem(IDfWorkitem workitem)
            throws Exception {
        try {
            int runTimeState = workitem.getRuntimeState();
            System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem workitem = " + workitem.getObjectId() + " .. runTimeState "+runTimeState);
            //� � � � �DfLogger.debug(this,"<finishWorkitem>runTimeState " + runTimeState, null,null);
            if (runTimeState == 0) {
                workitem.acquire();
                //� � � � � �DfLogger.debug(this, "acquired ",null, null);
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem .. runTimeState acquired ");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
                //� � � � � � � �DfLogger.debug(this, "completed ",null, null);
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem.. runTimeState completed ");
            } else if (runTimeState == 1) {
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem workitem acquired .....");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
            } else if (runTimeState == 3) {
                workitem.resume();
                //� � � � � � �DfLogger.debug(this, "resumed ", null,null);
                workitem.acquire();
                //� � � � � � � �DfLogger.debug(this, "acquired ",null, null);
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem .. runTimeState resumed ");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
                // � � � � � � �DfLogger.debug(this, "completed ",null, null);
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem .. runTimeState completed ");
            } else {
                //� � � � � � � �DfLogger.debug(this, "do nothingworkitem is finished", null, null);
                System.out.println("WF_BiotechManuscriptSendNotifications.finishWorkitem .. do nothingworkitem is finished");
            }
        } catch (Exception ex) {
            //� � � � �DfLogger.error(this, ex.getMessage(),null, ex);
            System.out.println(".. Exception in finshed workitem method "+ex);
            throw ex;
        }
    }
    protected void validateArguments(Map params) {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do
        {
            if(!iter.hasNext())
                break;
            String key = (String)iter.next();
            if(key != null && key.length() != 0)
            {
                String value[] = (String[])params.get(key);
                if(key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("docbase_name"))
                    m_docbase = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("workitemId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("packageId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("ticket"))
                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while(true);
    }
    protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
        return DFCSessionUtils.createSessionManager(docbase, userid, password);
    }
    private IDfSession getSession(String docbase, String userid) throws DfException {
        sessionManager = getSessionManager(docbase, userid, m_ticket);
        return sessionManager.getSession(docbase);
    }
    protected void notify(IDfId sysObjId, IDfSession session, IDfWorkitem workitem) throws DfException {
        IDfWorkflow workflow = (IDfWorkflow)session.getObject(workitem.getWorkflowId());
        IDfList authorsInKickOffTask = workflow.getPerformers("KickOff");
        IDfSysObject sysObj =  (IDfSysObject)session.getObject(sysObjId);
        
        //IDfGroup notify = sysObj.getSession().getGroup(notifyGroup);
        System.out.println("WF_BiotechManuscriptSendNotifications.notify sysObj = " + sysObj.getObjectId());
        String performers;
        System.out.println(
                "WF_BiotechManuscriptSendNotifications.notify Before queue: " + " No of users: " + authorsInKickOffTask.getCount() + " NOTIFICATION(S) FOR DOC: " + sysObj.getObjectName());
        Date dateBeforequeue = new Date();
        System.out.println("BEFORE sending to queue for WF_BiotechManuscriptSendNotifications.notify = "  + sysObj.getObjectId()+ " time in milli seconds " + dateBeforequeue.getTime() + " in format " + dateBeforequeue.toString());

        for (int i = 0; i < authorsInKickOffTask.getCount(); i++)
        {
        //String message = getMessage(sysObj, session);
          performers = authorsInKickOffTask.getString(i);
        sysObj.queue(performers, "Approval Notice", 10, true, null, "");
        }
        Date dateAfterQueue = new Date();
        System.out.println("AFTER sending to queue for WF_BiotechManuscriptSendNotifications.notify = "  + sysObj.getObjectId()+ " time in milli seconds " + dateAfterQueue.getTime() + " in format " + dateAfterQueue.toString());
    }
}
