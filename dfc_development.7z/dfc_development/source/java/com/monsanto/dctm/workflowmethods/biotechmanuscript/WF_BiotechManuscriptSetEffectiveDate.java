/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.biotechmanuscript;

/*
 * WF_BiotechManuscriptPromoteApproved.java
 *
 * Created on June 26, 2006, 10:54 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.utils.DFCSessionUtils;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @author tsvedan
 */
public class WF_BiotechManuscriptSetEffectiveDate
        implements IDmMethod {

    /**
     * Creates a new instance of WF_BiotechManuscriptPromoteApproved
     */
    public WF_BiotechManuscriptSetEffectiveDate() {
        m_sessionMgr = null;
        m_docbase = null;
        m_userName = null;
        m_workitemId = null;
        m_ticket = null;
    }

    public void execute(Map params, OutputStream ostream)
            throws Exception {
//        IDfSessionManager sessionManager;
        IDfSession session;
//        Exception exception;
        initWorkflowParams(params);
        IDfId docId;
//    sessionManager = login();
        session = null;
        IDfCollection pkgColl = null;
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = getSession(m_docbase,m_userName);
            //session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem) session.getObject(workitemID);
            if (workitem.getRuntimeState() == 0)
                workitem.acquire();
            pkgColl = workitem.getPackages("");
            if (pkgColl != null) {
                while (pkgColl.next()) {
                    int docCount = pkgColl.getValueCount("r_component_id");
                    for (int i = 0; i < docCount; i++) {
                        docId = pkgColl.getRepeatingId("r_component_id", i);
                        System.out.println(docId.toString());
                        if (docId != null && !docId.isNull()) {
                            IDfSysObject doc = (IDfSysObject) session.getObject(docId);
                            setEffectiveDate(doc);
                        }
                    }
                }

            }
            workitem.complete();
        } catch (DfException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            if (pkgColl != null)
                pkgColl.close();
            if (session != null)
                sessionManager.release(session);
        }
    }

    protected void initWorkflowParams(Map params) {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do {
            if (!iter.hasNext())
                break;
            String key = (String) iter.next();
            if (key != null && key.length() != 0) {
                String value[] = (String[]) params.get(key);
                if (key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else if (key.equalsIgnoreCase("docbase_name"))
                    m_docbase = value.length <= 0 ? "" : value[0];
                else if (key.equalsIgnoreCase("workitemId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else if (key.equalsIgnoreCase("packageId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else if (key.equalsIgnoreCase("ticket"))
                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while (true);
    }

//  protected IDfSessionManager login()
//      throws DfException {
//    if (m_docbase == null || m_userName == null || m_ticket == null)
//      return null;
//    IDfClient dfClient = DfClient.getLocalClient();
//    if (dfClient != null) {
//      IDfLoginInfo li = new DfLoginInfo();
//      li.setUser(m_userName);
//      li.setPassword(m_ticket);
//      li.setDomain(null);
//      IDfSessionManager sessionMgr = dfClient.newSessionManager();
//      sessionMgr.setIdentity(m_docbase, li);
//      return sessionMgr;
//    } else {
//      return null;
//    }
//  }

    protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
        return DFCSessionUtils.createSessionManager(docbase, userid, password);
    }
    private IDfSession getSession(String docbase, String userid) throws DfException {
        sessionManager = getSessionManager(docbase, userid, m_ticket);
        return sessionManager.getSession(docbase);
    }

    protected void setEffectiveDate(IDfSysObject sysObj) throws DfException {
        IDfClientX clientx = new DfClientX();
        String now = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
        IDfTime time = clientx.getTime(now, IDfTime.DF_TIME_PATTERN44);
        System.out.println("$$$$$$Setting Effective Date to: " + time.getDate());
        sysObj.setTime("effective_date", time);
        sysObj.save();
    } //setEffectiveDate

    protected IDfSessionManager m_sessionMgr;
    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    protected String notifyGroup = null;
//    private static final String USER_KEY = "user";
//    private static final String DOCBASE_KEY = "docbase_name";
//    private static final String WORKITEM_KEY_2 = "workitemId";
//    private static final String TICKET_KEY = "ticket";
//    private static final String WORKITEM_KEY = "packageId";
//    private IDfId docId;
    private IDfSessionManager sessionManager;

}
