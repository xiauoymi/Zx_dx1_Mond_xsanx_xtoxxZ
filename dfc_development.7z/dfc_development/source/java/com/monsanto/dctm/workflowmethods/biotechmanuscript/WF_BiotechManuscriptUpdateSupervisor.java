/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.biotechmanuscript;

/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Filename:    $RCSfile: WF_BiotechManuscriptUpdateSupervisor.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * tsvedan $    	 On:	$Date: 2008-02-04 17:32:30 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */

public class WF_BiotechManuscriptUpdateSupervisor implements IDmMethod {

  /**
   * Creates a new instance of WF_BiotechManuscriptPromoteApproved
   */
  public WF_BiotechManuscriptUpdateSupervisor() {
    m_sessionMgr = null;
    m_docbase = null;
    m_userName = null;
    m_workitemId = null;
    m_ticket = null;
  }

  public void execute(Map params, OutputStream ostream)
      throws Exception {
    IDfSessionManager sessionManager;
    IDfSession session;
    initWorkflowParams(params);
    sessionManager = login();
    session = null;
    try {
      IDfId workitemID = new DfId(m_workitemId);
      session = sessionManager.getSession(m_docbase);
      IDfWorkitem workitem = (IDfWorkitem) session.getObject(workitemID);
      IDfWorkflow workflow = (IDfWorkflow) session.getObject(workitem.getWorkflowId());
      if (workitem.getRuntimeState() == 0)
        workitem.acquire();
      System.out.print("Updating workflow supervisor to... ");
      IDfGroup group = session.getGroup(groupName);
      if (group != null && group.getAllUsersNamesCount() > 0) {
        String supervisor = group.getAllUsersNames(0);
        workflow.updateSupervisorName(supervisor);
        System.out.println(supervisor);
      }
      workitem.complete();
    } catch (Exception e) {
      System.out.println(e.getMessage());
      e.printStackTrace();
      throw e;
    } finally {
      if (session != null)
        sessionManager.release(session);
    }
  }

  protected void initWorkflowParams(Map params) {
    Set keys = params.keySet();
    Iterator iter = keys.iterator();
    do {
      if (!iter.hasNext())
        break;
      String key = (String) iter.next();
      if (key != null && key.length() != 0) {
        String[] value = (String[]) params.get(key);
        if (key.equalsIgnoreCase("user"))
          m_userName = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase("docbase_name"))
          m_docbase = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase("workitemId"))
          m_workitemId = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase("packageId"))
          m_workitemId = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase("ticket"))
          m_ticket = value.length <= 0 ? "" : value[0];
      }
    } while (true);
  }

  protected IDfSessionManager login()
      throws DfException {
    if (m_docbase == null || m_userName == null || m_ticket == null)
      return null;
    IDfClient dfClient = DfClient.getLocalClient();
    if (dfClient != null) {
      IDfLoginInfo li = new DfLoginInfo();
      li.setUser(m_userName);
      li.setPassword(m_ticket);
      li.setDomain(null);
      IDfSessionManager sessionMgr = dfClient.newSessionManager();
      sessionMgr.setIdentity(m_docbase, li);
      return sessionMgr;
    } else {
      return null;
    }
  }

  protected IDfSessionManager m_sessionMgr;
  protected String m_docbase;
  protected String m_userName;
  protected String m_workitemId;
  protected String m_ticket;
  protected String groupName = "biotech_ms_wf_supervisor";

}