/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.breedingdocs;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import org.apache.commons.lang.StringUtils;

/**
 * Filename:    $RCSfile: WF_BreedingPromoteLCAndSendNotification.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * tsvedan $    	 On:	$Date: 2009-06-05 19:03:10 $
 *
 * @author tsvedan
 * @version $Revision: 1.3 $
 */
public class WF_BreedingPromoteLCAndSendNotification
    implements IDmMethod {
  // ENH0180658 fix
  private String lastPerformer=null;
  private static final int PERFORMER_INDEX = 0;
  // ENH0180658 fix
  /**
   * Creates a new instance of com.monsanto.dctm.workflowmethods.breedingdocs.WF_BreedingPromoteLCAndSendNotification
   */
  public WF_BreedingPromoteLCAndSendNotification() {
    m_sessionMgr = null;
    m_docbase = null;
    m_userName = null;
    m_workitemId = null;
    m_ticket = null;
  }

  public void execute(Map params, OutputStream ostream)
      throws Exception {
    IDfSessionManager sessionManager;
    IDfSession session;
    initWorkflowParams(params);
    sessionManager = login();
    session = null;
    try {
      IDfId workitemID = new DfId(m_workitemId);
      session = sessionManager.getSession(m_docbase);
      IDfWorkitem workitem = (IDfWorkitem) session.getObject(workitemID);

      // fix for issue#0159022
      IDfWorkflow workflow = (IDfWorkflow)session.getObject(workitem.getWorkflowId());
      IDfAliasSet AliasSet = (IDfAliasSet)session.getObject(workflow.getAliasSetId());
      notifyGroup = setNotificationGroup(AliasSet);
      // fix for issue#0159022
      //ENH0180658 fix
      lastPerformer=workflow.getLastPerformer(PERFORMER_INDEX);
      // ENH0180658 fix
      if (workitem.getRuntimeState() == 0)
        workitem.acquire();
      IDfCollection pkgColl = null;
      System.out.println("Getting packages and promoting document(s)");
      pkgColl = workitem.getPackages("");
      if (pkgColl != null) {
        while (pkgColl.next()) {
          String docId = pkgColl.getString("r_component_id");
          System.out.println(docId.toString());
          int docCount = pkgColl.getValueCount("r_component_id");
          for (int i = 0; i < docCount; i++) {
            IDfId docIdObj = pkgColl.getRepeatingId("r_component_id", i);
            if (docIdObj != null) {
              IDfId sysobjID = new DfId(docId);
              IDfSysObject doc = (IDfSysObject) session.getObject(sysobjID);
              setEffectiveDate(doc);
              doc.promote(null, false, false);
              sendNotification(doc, session);
            }
          }
        }
        pkgColl.close();
      }
      workitem.complete();
    } catch (DfException e) {
      System.out.println(e.getMessage());
      e.printStackTrace();
      throw e;
    } finally {
      if (session != null)
        sessionManager.release(session);
    }
  }

  protected void initWorkflowParams(Map params) {
    Set keys = params.keySet();
    Iterator iter = keys.iterator();
    do {
      if (!iter.hasNext())
        break;
      String key = (String) iter.next();
      if (key != null && key.length() != 0) {
        String[] value = (String[]) params.get(key);
        if (key.equalsIgnoreCase(USER_KEY))
          m_userName = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase(DOCBASE_KEY))
          m_docbase = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase(WORKITEM_KEY))
          m_workitemId = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase(PACKAGE_KEY))
          m_workitemId = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase(TICKET_KEY))
          m_ticket = value.length <= 0 ? "" : value[0];
      }
    } while (true);
  }

  protected IDfSessionManager login()
      throws DfException {
    if (m_docbase == null || m_userName == null || m_ticket == null)
      return null;
    IDfClient dfClient = DfClient.getLocalClient();
    if (dfClient != null) {
      IDfLoginInfo li = new DfLoginInfo();
      li.setUser(m_userName);
      li.setPassword(m_ticket);
      li.setDomain(null);
      IDfSessionManager sessionMgr = dfClient.newSessionManager();
      sessionMgr.setIdentity(m_docbase, li);
      return sessionMgr;
    } else {
      return null;
    }
  }

  protected void setEffectiveDate(IDfSysObject sysObj) throws DfException {
    IDfClientX clientx = new DfClientX();
    String now = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
    IDfTime time = clientx.getTime(now, IDfTime.DF_TIME_PATTERN44);
    System.out.println("$$$$$$Setting Effective Date to: " + time.getDate());
    sysObj.setTime("effective_date", time);
    sysObj.save();
  } //setEffectiveDate

  protected void sendNotification(IDfSysObject sysObj, IDfSession sess)
      throws DfException {

    if (notifyGroup == null) return;
    IDfGroup notify = sess.getGroup(notifyGroup);
    if (notify == null || notify.getAllUsersNamesCount() < 1) {
      System.out.println("@@@@@@<<<<<< Notification group " + notifyGroup + " is either unavailable or empty");
      return;
    }
    System.out.println(
        ">>>>>SENDING " + notify.getAllUsersNamesCount() + " NOTIFICATION(S) FOR DOC: " + sysObj.getObjectName());
    String message = getMessage(sysObj);
    sysObj.queue(notifyGroup, "Approval Notice", 10, true, null, message);
  } //sendUsersNotification

 /**
    ENH0180658 fix

    Sample notification outlook email.
    The following document has been reviewed and approved. This document is the latest version and supersedes any previous version.
    http://viewdocumentum.monsanto.com/webtop/drl.html?objectId=090012ab80087f3e

    ------------------------------
    LIST OF DOCUMENTS INVOLVED
    ------------------------------
    Document Name...................SB.QP.008 Control of Monitoring & Measuring Devices.doc
    **Version.........................XXX
    **Version Comments����������������Changed section 3 of paragraph A to include��etc.
                                    BLAH BLAH BLAHA03049j1=0345u9 =109jpawejpafjo.///////.

    Created by/Changed by...........Hagar James E
    **Approved by���������������������Matthew Fox
    **Effective Date�����������������.07/07/2008, 10:48AM

    Sample notification DCTM inbox email
    The following document has been reviewed and approved. This document is the latest version and supersedes any previous version.
    Here are the version comments: XXX

    inboxMessage will be ignored when user receives outlook email.
    This is only visible when user see Approval notice email in documentum inbox not in outlook email.
    event sender will skip first token in forming outlook email.
 **/

 protected String getMessage(IDfSysObject sysObj) throws DfException {
    final char DELIMITER='^';
    final char REPLACECHAR='-';
    final int MAX_MSG_SIZE=400;
    final String COMMA=",";
    final String NO_VERSION_COMMENTS="No version comments have been recorded for this document!";
    final String DCTM_INBOX_MSG="The following document has been reviewed and approved. This document is the latest version and supersedes any previous version.\nHere are the version comments: ";
    final String NA="N/A";

    StringBuffer strbuff = new StringBuffer();
    String name=sysObj.getObjectName();
    String version=sysObj.getAllRepeatingStrings("r_version_label",COMMA);
    if (version == null || version.trim().length()<=0)
       version=NA;
    String createdby=sysObj.getOwnerName();
    IDfTime time=sysObj.getTime("effective_date");
    String strEffDate=NA;
    SimpleDateFormat sim = new SimpleDateFormat("MM/dd/yy hh:mm a z");
    if (time!=null)
      strEffDate=sim.format(time.getDate());
    String comments = sysObj.getString("version_comments");
    if (comments != null && comments.trim().length() > 0)
      comments=comments.replace(DELIMITER,REPLACECHAR);
    else
      comments = NO_VERSION_COMMENTS;
   
    if (lastPerformer == null || lastPerformer.trim().length()<=0)
       lastPerformer=NA;

    String inboxMessage = DCTM_INBOX_MSG + comments;
    DfLogger.info(this,"Name: "+name+" "+"inboxMessage= "+inboxMessage ,null,null);
    strbuff.append(StringUtils.rightPad(inboxMessage,MAX_MSG_SIZE)+DELIMITER);
    strbuff.append("Document Name..................."+name+DELIMITER);
    strbuff.append("Version........................."+version+DELIMITER);
    strbuff.append("Version Comments................"+comments+DELIMITER);
    strbuff.append("Created by/Changed by..........."+createdby+DELIMITER);
    strbuff.append("Approved by....................."+lastPerformer+DELIMITER);
    strbuff.append("Effective Date.................."+strEffDate+DELIMITER);
    DfLogger.info(this,"Name: "+name+" "+"Queue Message/Length= "+strbuff.toString()+"/"+strbuff.toString().length() ,null,null);
    return strbuff.toString();

  }

// fix for issue#0159022
  protected String setNotificationGroup(IDfAliasSet AliasSet) throws DfException {

        String str = null;
        int indexofRev = AliasSet.findAliasIndex("NotifyGrp");
        if (indexofRev > -1){
            str = AliasSet.getAliasValue(indexofRev);
        }
        return str;
    } //setNotificationGroup
  // fix for issue#0159022
  protected IDfSessionManager m_sessionMgr;
  protected String m_docbase;
  protected String m_userName;
  protected String m_workitemId;
  protected String m_ticket;
  // fix for issue#0159022
  protected String notifyGroup = null;
  //protected String notifyGroup = "breeding_notify";
  // fix for issue#0159022
  private static final String USER_KEY = "user";
  private static final String DOCBASE_KEY = "docbase_name";
  private static final String WORKITEM_KEY = "workitemId";
  private static final String TICKET_KEY = "ticket";
  private static final String PACKAGE_KEY = "packageId";

}