/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.breedingtechnology;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfTime;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.utils.DFCSessionUtils;

import java.io.IOException;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Filename:    $RCSfile: BreedingTechnologyNotifyUsers.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-02-18 20:05:41 $
 *
 * @author rrkaur
 * @version $Revision: 1.8 $
 */
public class BreedingTechnologyNotifyUsers implements
        IDmMethod {

    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    private IDfId docIdObj;
    private IDfSessionManager sessionManager;
    protected String notifyUsersGroup = null;
    protected String notifyAuthorsGroup = null;
    protected String notifyAdminsGroup = null;
    protected String versionComments = null;

    public void execute(Map map, OutputStream outputStream) throws Exception {
        validateArguments(map);
        IDfSession session = null;
        IDfCollection pkgColl = null;
        IDfWorkitem workitem = null;
        try {
            session = getSession(m_docbase,m_userName);
            workitem = initializeVariables(session);
            System.out.println("BreedingTechnologyNotifyUsers.execute workitem = " + workitem.getObjectId() + " workitem.getRuntimeState() = " + workitem.getRuntimeState());
            Date dateBeforeAcquire = new Date();
            System.out.println("BreedingTechnologyNotifyUsers.execute workitem = " + workitem.getObjectId() + " BEFORE ACQUIRE = " + dateBeforeAcquire.getTime() + " in format " + dateBeforeAcquire.toString());
            if ((workitem.getRuntimeState() != workitem.DF_WI_STATE_ACQUIRED))// || (workitem.getRuntimeState() == 0))
            {
                System.out.println("BreedingTechnologyNotifyUsers.execute Acquiring workitem " + workitem.getObjectId());
                workitem.acquire();
                Date dateAfterAcquire = new Date();
                System.out.println("BreedingTechnologyNotifyUsers.execute workitem = " + workitem.getObjectId() + " AFTER ACQUIRE = " + dateAfterAcquire.getTime() + " in format " + dateAfterAcquire.toString());
            }
            System.out.println("BreedingTechnologyNotifyUsers.execute before getting packages workitem.getRuntimeState() = " + workitem.getRuntimeState());
            pkgColl = workitem.getPackages("");
            if(pkgColl != null) {
                while(pkgColl.next()) {
                    String docId = pkgColl.getString("r_component_id");
                    int docCount = pkgColl.getValueCount("r_component_id");
                    for (int i = 0; i < docCount; i++) {
                        docIdObj = pkgColl.getRepeatingId("r_component_id", i);
                        if(docIdObj != null) {
                            System.out.println("BreedingTechnologyNotifyUsers.execute Got the component id before setDateAndNotify: " + "docIdObj = " + docIdObj);
                            setDatePromoteAndNotify(docId, session);
                            System.out.println("BreedingTechnologyNotifyUsers.execute After setDateAndNotify and before workitem complete: " + "docIdObj = " + docIdObj);
                        }
                    }
                }
            }
            //runtimestate condition
//      workitem.complete();
            finishWorkitem(workitem);
        } catch(DfException e)
        {
//           outputStream.write(e.getMessage().getBytes());
//          writeMessage(outputStream, e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            pkgColl.close();
            if (session != null) {
                sessionManager.release(session);
            }
        }

    }
    private void finishWorkitem(IDfWorkitem workitem)
            throws Exception {
        try {
            int runTimeState = workitem.getRuntimeState();
            System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem workitem = " + workitem.getObjectId() + " .. runTimeState "+runTimeState);
            //� � � � �DfLogger.debug(this,"<finishWorkitem>runTimeState " + runTimeState, null,null);
            if (runTimeState == 0) {
                workitem.acquire();
                //� � � � � �DfLogger.debug(this, "acquired ",null, null);
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem .. runTimeState acquired ");
                Date dateBeforeComplete = new Date();
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
                //� � � � � � � �DfLogger.debug(this, "completed ",null, null);
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem.. runTimeState completed ");
            } else if (runTimeState == 1) {
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem workitem acquired .....");
                Date dateBeforeComplete = new Date();
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
            } else if (runTimeState == 3) {
                workitem.resume();
                //� � � � � � �DfLogger.debug(this, "resumed ", null,null);
                workitem.acquire();
                //� � � � � � � �DfLogger.debug(this, "acquired ",null, null);
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem .. runTimeState resumed ");
                Date dateBeforeComplete = new Date();
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
                // � � � � � � �DfLogger.debug(this, "completed ",null, null);
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem .. runTimeState completed ");
            } else {
                //� � � � � � � �DfLogger.debug(this, "do nothingworkitem is finished", null, null);
                System.out.println("BreedingTechnologyNotifyUsers.finishWorkitem .. do nothingworkitem is finished");
            }
        } catch (Exception ex) {
            //� � � � �DfLogger.error(this, ex.getMessage(),null, ex);
            System.out.println(".. Exception in finshed workitem method "+ex);
            throw ex;
        }
    }

    private void setDatePromoteAndNotify(String docId, IDfSession session) throws DfException {
        IDfId sysobjID = new DfId(docId);
        IDfSysObject doc = (IDfSysObject)session.getObject(sysobjID);
        setEffectiveDate(doc);
        //doc.promote(null, false, false);
        notify(doc,session,notifyUsersGroup);
        notify(doc,session,notifyAuthorsGroup);
        notify(doc,session,notifyAdminsGroup);
    }

    private IDfWorkitem initializeVariables(IDfSession session) throws DfException {
        IDfId workitemID = new DfId(m_workitemId);
        IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
        //System.out.println("workitem.getWorkflowId() = " + workitem.getWorkflowId());
        IDfWorkflow workflow = (IDfWorkflow)session.getObject(workitem.getWorkflowId());
        IDfAliasSet AliasSet = (IDfAliasSet)session.getObject(workflow.getAliasSetId());
        notifyUsersGroup = setNotificationGroup(AliasSet,"bt_users");
        notifyAuthorsGroup = setNotificationGroup(AliasSet, "bt_authors");
        notifyAdminsGroup = setNotificationGroup(AliasSet, "bt_admins");
        return workitem;
    }

    private void writeMessage(OutputStream outputStream, String message) throws IOException {
        outputStream.write((message + "\n").getBytes());
    }
    protected void validateArguments(Map params) {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do
        {
            if(!iter.hasNext())
                break;
            String key = (String)iter.next();
            if(key != null && key.length() != 0)
            {
                String value[] = (String[])params.get(key);
                if(key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("docbase_name"))
                    m_docbase = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("workitemId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("packageId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("ticket"))
                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while(true);

    }

    protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
        return DFCSessionUtils.createSessionManager(docbase, userid, password);
    }
    private IDfSession getSession(String docbase, String userid) throws DfException {
        sessionManager = getSessionManager(docbase, userid, m_ticket);
        return sessionManager.getSession(docbase);
    }
    protected String setNotificationGroup(IDfAliasSet AliasSet, String alias) throws DfException {
        String str = null;
        //System.out.println("alias = " + alias);
        int indexofRev = AliasSet.findAliasIndex(alias);
       // System.out.println("indexofRev = " + indexofRev);
        if (indexofRev > -1){
            str = AliasSet.getAliasValue(indexofRev);
//      System.out.println("str = " + str);
//            str = str.substring(0, str.lastIndexOf("_")+1) + "notify";
        }
        return str;
    }

    protected void notify(IDfSysObject sysObj, IDfSession session, String notifyGroup) throws DfException {
        if (notifyGroup == null) return;
        IDfGroup notify = sysObj.getSession().getGroup(notifyGroup);
        System.out.println("BreedingTechnologyNotifyUsers.notify sysObj = " + sysObj.getObjectId());

        if (notify == null || notify.getAllUsersNamesCount() < 1) {
            System.out.println("@@@@@@<<<<<<BreedingTechnologyNotifyUsers Notification group " + notifyGroup + " is either unavailable or empty");
            return;
        }
        System.out.println(
                "BreedingTechnologyNotifyUsers.notify Before queue: " + "Group " +notifyGroup + " No of users: " + notify.getAllUsersNamesCount() + " NOTIFICATION(S) FOR DOC: " + sysObj.getObjectName());
        Date dateBeforequeue = new Date();
        System.out.println("BEFORE sending to queue for BreedingTechnologyNotifyUsers.notify = "  + sysObj.getObjectId()+ " time in milli seconds " + dateBeforequeue.getTime() + " in format " + dateBeforequeue.toString());
        //String message = getMessage(sysObj, session);
        sysObj.queue(notifyGroup, "Approval Notice", 10, true, null, "");
        Date dateAfterQueue = new Date();
        System.out.println("AFTER sending to queue for BreedingTechnologyNotifyUsers.notify = "  + sysObj.getObjectId()+ " time in milli seconds " + dateAfterQueue.getTime() + " in format " + dateAfterQueue.toString());
    }
    protected void setEffectiveDate(IDfSysObject sysObj) throws DfException {
        IDfClientX clientx = new DfClientX();
        String now = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
        IDfTime time = clientx.getTime(now, IDfTime.DF_TIME_PATTERN44);
        System.out.println("BreedingTechnologyNotifyUsers.setEffectiveDate sysObj.getObjectName() = " + sysObj.getObjectName() + " sysObj.getObjectId() = " + sysObj.getObjectId() + " $$$$$$Setting Effective Date to: " + time.getDate());
        sysObj.setTime("effective_date", time);
        Date dateBeforeSave = new Date();
        System.out.println("BreedingTechnologyNotifyUsers.setEffectiveDate BEFORE save = "  + sysObj.getObjectId()+ " time in milli seconds " + dateBeforeSave.getTime() + " in format " + dateBeforeSave.toString());
        sysObj.save();
        Date dateAfterSave = new Date();
        System.out.println("BreedingTechnologyNotifyUsers.setEffectiveDate AFTER save = "  + sysObj.getObjectId()+ " time in milli seconds " + dateAfterSave.getTime() + " in format " + dateAfterSave.toString());
    } //setEffectiveDate

}