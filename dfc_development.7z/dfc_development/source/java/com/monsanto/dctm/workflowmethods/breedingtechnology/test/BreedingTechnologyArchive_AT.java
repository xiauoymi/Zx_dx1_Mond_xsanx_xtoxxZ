package com.monsanto.dctm.workflowmethods.breedingtechnology.test;

import junit.framework.TestCase;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;
import com.documentum.fc.client.*;
import com.documentum.com.IDfClientX;
import com.documentum.com.DfClientX;
import com.monsanto.dctm.utils.DFCSessionUtils;
import java.util.Date;
import java.text.SimpleDateFormat;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Feb 3, 2009
 * Time: 11:03:17 AM
 * To change this template use File | Settings | File Templates.
 */
public class BreedingTechnologyArchive_AT extends TestCase {
    private static final String TESTDOCBASE = "stltst03";
    private static final String OBJECTNAME = "Test BT_AT Archive Method";
    public void testPreviousPromotedDocumentToArchive() throws Exception {
        //this will require a superuser session as the previous version of the document is getting modified
        IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, "devl29", "devl29");
        IDfSession session = null;
        IDfSysObject sysObject = null;
        IDfSysObject newObject = null;
        Object dummyObj = new Object();
        try {
            session = sessionManager.getSession(BreedingTechnologyArchive_AT.TESTDOCBASE);

            synchronized (dummyObj) {
                sysObject = createSessionAndValidObjectWithAllValues(session);
                assertObjectInfo(session, sysObject);
                //we need this wait for the queque items and workitems to get created
                dummyObj.wait(50000);
                completeApprovalTasks(session);
                dummyObj.notify();
                dummyObj.wait(50000);
            }
            sysObject = (IDfSysObject) session.getObjectByQualification("breed_tech_doc where object_name = '" + OBJECTNAME +"'");
            IDfId prevVersionObj = sysObject.getObjectId();
            assertEquals("Approved", sysObject.getCurrentStateName());
            sysObject.checkout();
            IDfId newObjectId = sysObject.checkin(false,"");
            newObject = (IDfSysObject)session.getObject(newObjectId);
            //complete workflow on NewObject
            synchronized (dummyObj) {
                //sysObject = createSessionAndValidObjectWithAllValues(session);
                assertObjectInfo(session, newObject);
                //we need this wait for the queque items and workitems to get created
                dummyObj.wait(50000);
                completeApprovalTasks(session);
                dummyObj.notify();
                dummyObj.wait(50000);
            }
            //new version should now be Approved but need to get it again in the current session
            newObject = (IDfSysObject)session.getObject(newObjectId);
            assertEquals("Approved", newObject.getCurrentStateName());
            //previous version should now be Archive but need to get it again in the current session
            IDfSysObject prevVersionObject = (IDfSysObject) session.getObject(prevVersionObj);
            assertEquals("Archive", prevVersionObject.getCurrentStateName());
            IDfCollection workflowsOnApprovedDoc = prevVersionObject.getWorkflows("","");
            System.out.println("workflowsOnApprovedDoc.next() = " + workflowsOnApprovedDoc.next());
            assertFalse(workflowsOnApprovedDoc.next());

        } catch (DfServiceException e) {
            e.printStackTrace();
        } finally {
        if (sysObject != null) {
          sysObject.destroy();
        }
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }
    private IDfSysObject createSessionAndValidObjectWithAllValues(IDfSession session) throws Exception {
        IDfSysObject sysObject = null;
        // session = sessionManager.getSession(BreedingTechnologyArchive_AT.TESTDOCBASE);
        sysObject = (IDfSysObject) session.newObject("breed_tech_doc");
        sysObject.setString("object_name",OBJECTNAME);
        sysObject.setRepeatingString("keywords",0,"kk");
        sysObject.setRepeatingString("authors",0,"usha");
        sysObject.setString("bt_level","Corporate");
        sysObject.setString("bt_function","All");
        sysObject.setString("site","All");
        sysObject.setRepeatingString("crop",0,"All");
        sysObject.setContentType( "crtext" );
        sysObject.setString("version_comments","This is a new document");
        sysObject.save();
        return sysObject;
    }
    private void assertObjectInfo(IDfSession session, IDfSysObject sysObject) throws DfException {
        IDfCollection workflows;
        IDfId workflowId;
        IDfWorkflow workflowObject;
        String workflowName = "Breeding Technology Approval Workflow ";
        SimpleDateFormat date = new SimpleDateFormat("yyyy-MM-dd");
        workflowName = workflowName + date.format(new Date());        
        assertNotNull(session);
        assertNotNull(sysObject);
        assertEquals(OBJECTNAME, sysObject.getObjectName());
        assertEquals("Corporate", sysObject.getString("bt_level"));
        assertEquals("All",  sysObject.getString("bt_function"));
        assertEquals("All", sysObject.getString("site"));
        assertEquals("Breeding Technology LC", sysObject.getPolicyName());
//    assertEquals("Draft", sysObject.getCurrentStateName());
        workflows = sysObject.getWorkflows("","");
        if (workflows != null && workflows.next()) {
            workflowId = (IDfId) workflows.getId("r_workflow_id");
            workflowObject = (IDfWorkflow) session.getObject(workflowId);
            assertEquals(workflowName,workflowObject.getObjectName());
        }
    }
    private void completeApprovalTasks(IDfSession session) throws Exception {
        //TODO
        // need to make the test better by getting all the workitems maybe rather than tasks as performers can change
        IDfCollection workflows = null;
        IDfWorkflow workflowObject = null;
        IDfSysObject sysObject = null;
        IDfId workflowId = null;
        sysObject = (IDfSysObject) session.getObjectByQualification("breed_tech_doc where object_name = '" + OBJECTNAME + "'");
        assertObjectInfo(session, sysObject);
        workflows = sysObject.getWorkflows("","");
        if (workflows != null && workflows.next()) {
            workflowId = (IDfId) workflows.getId("r_workflow_id");
            System.out.println("workflowId = " + workflowId);
            workflowObject = (IDfWorkflow) session.getObject(workflowId);
            System.out.println("workflowObject.getNextSeqno() = " + workflowObject.getNextSeqno());
            //process tasks for approvers so that it reaches the PromoteAndNotify task
            //the getPerformers(activityName) does not work so the performer names are hardcoded here
            Object dummyObj = new Object();
            synchronized (dummyObj) {
                String performer = "devl11";
                completeTask(session, performer);
                System.out.println("After completing the first task");
                dummyObj.wait(50000);
                dummyObj.notify();
                performer = "devl12";
                completeTask(session, performer);
                System.out.println("After completing the second task");
            }
        }
    }
    private void completeTask(IDfSession session, String performer) throws DfException {
        IDfPersistentObject pObj;
        IDfWorkitem workItemObject;
        String queueItemQualification =  "dmi_queue_item \n" +
                "where (name = '" + performer + "' and task_name = 'Approval')\n" +
                "and delete_flag=False\n" +
                "order by date_sent";
        IDfQueueItem tasks =  (IDfQueueItem) session.getObjectByQualification(queueItemQualification);
        if (tasks != null) {
            System.out.println("tasks.getId(\"r_object_id\").toString() = " + tasks.getId("r_object_id").toString());
            //get workitem
            pObj = session.getObjectByQualification("dmi_queue_item where r_object_id='" +
                    tasks.getId("r_object_id").toString() + "'");
            System.out.println("pObj.getObjectId() = " + pObj.getObjectId());
            workItemObject = (IDfWorkitem)session.getObject(tasks.getId("item_id"));
            System.out.println("workItemObject.DF_WI_STATE_ACQUIRED = " + workItemObject.DF_WI_STATE_ACQUIRED);
            if (workItemObject.getRuntimeState() != workItemObject.DF_WI_STATE_ACQUIRED)
                workItemObject.acquire();
            IDfClientX clientx = new DfClientX();
            IDfList actList = clientx.getList();
            IDfList forwardList = workItemObject.getForwardActivities();
            if(forwardList.getCount()>0) {
                //  System.out.println("forwarding by default to =" + ((IDfActivity) forwardList.get(0)).getObjectName());
                actList.append(forwardList.get(0));
                workItemObject.setOutputByActivities(actList);
            }else {
                //  System.out.println("There are no more forward activities, using default");
            }
            System.out.println("Before Completing");
            workItemObject.complete();
        }
    }
}
