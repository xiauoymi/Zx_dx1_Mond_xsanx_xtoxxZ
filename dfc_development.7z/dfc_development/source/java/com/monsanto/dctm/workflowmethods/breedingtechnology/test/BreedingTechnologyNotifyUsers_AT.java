/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.breedingtechnology.test;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.IDfList;
import com.monsanto.dctm.utils.DFCSessionUtils;
import com.monsanto.dctm.workflowmethods.breedingtechnology.BreedingTechnologyNotifyUsers;
import junit.framework.TestCase;

import java.util.*;
import java.io.ByteArrayOutputStream;

/**
 * Filename:    $RCSfile: BreedingTechnologyNotifyUsers_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-02-18 20:05:41 $
 *
 * @author rrkaur
 * @version $Revision: 1.7 $
 */
public class BreedingTechnologyNotifyUsers_AT extends TestCase {
  private static final String TESTDOCBASE = "stltst03";
  private IDfCollection methodResults = null;
  private static final String BREEDING_TEGHNOLOGY_METHOD_NAME = "BreedingTechnologyNotifyUsers";
  private static final String DOCBASE_ARG_NAME = "docbase_name";
  private static final String USER_ARG_NAME = "user";
  private static final String TICKET_ARG_NAME = "ticket";
  private static final String WORKITEMID_ARG_NAME = "workitemId";
  private static final String PACKAGEID_ARG_NAME = "packageId";
  private ByteArrayOutputStream outputStream;

  public void testCreateSession() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, "devl11", "devl11");
    IDfSession session = null;
    try {
      session = sessionManager.getSession(BreedingTechnologyNotifyUsers_AT.TESTDOCBASE);
      assertNotNull(session);
    } catch (DfServiceException e) {
      e.printStackTrace();
    } finally {
      sessionManager.release(session);
    }
  }
  public void testCreateSessionAndValidObject() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, "devl11", "devl11");
    IDfSession session = null;
    IDfCollection workflows = null;
    IDfWorkflow workflowObject = null;
    IDfSysObject sysObject = null;

    try {
      session = sessionManager.getSession(BreedingTechnologyNotifyUsers_AT.TESTDOCBASE);
      sysObject = (IDfSysObject) session.newObject("breed_tech_doc");
      sysObject.setString("object_name","Test BT_AT From Method");

      assertNotNull(session);
      assertNotNull(sysObject);
      assertEquals("Test BT_AT From Method", sysObject.getObjectName());
    } catch (DfServiceException e) {
      e.printStackTrace();
    } finally {
      if (sysObject != null) {
        workflows = sysObject.getWorkflows("","");
        if (workflows != null && workflows.next()) {
          workflowObject.abort();
          workflowObject.destroy();
          workflows.close();
        }
        sysObject.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }
  public void testCreateSessionAndValidObjectWithAllValues() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, "devl11", "devl11");
    IDfSession session = null;
    IDfCollection workflows = null;
    IDfWorkflow workflowObject = null;
    IDfSysObject sysObject = null;
    IDfId workflowId = null;
    try {
      session = sessionManager.getSession(BreedingTechnologyNotifyUsers_AT.TESTDOCBASE);
      sysObject = (IDfSysObject) session.newObject("breed_tech_doc");
      sysObject.setString("object_name","Test BT_AT Method");
      sysObject.setRepeatingString("keywords",0,"kk");
      sysObject.setRepeatingString("authors",0,"usha");
      sysObject.setString("bt_level","Corporate");
      sysObject.setString("bt_function","All");
      sysObject.setString("site","All");
      sysObject.setRepeatingString("crop",0,"All");

      sysObject.save();

      assertNotNull(session);
      assertNotNull(sysObject);
      assertEquals("Test BT_AT Method", sysObject.getObjectName());
      assertEquals("Corporate", sysObject.getString("bt_level"));
      assertEquals("All",  sysObject.getString("bt_function"));
      assertEquals("All", sysObject.getString("site"));
      assertEquals("Breeding Technology LC", sysObject.getPolicyName());
      assertEquals("Draft", sysObject.getCurrentStateName());
//      assertEquals("1.0", ((IBreedingTechnology) object).getVersion());
      workflows = sysObject.getWorkflows("","");
      if (workflows != null && workflows.next()) {
        workflowId = (IDfId) workflows.getId("r_workflow_id");
        workflowObject = (IDfWorkflow) session.getObject(workflowId);
        assertEquals("Breeding Technology Approval Workflow 2008-08-26",workflowObject.getObjectName());
      }
    } catch (DfServiceException e) {
      e.printStackTrace();
    } finally {
      if (sysObject != null) {
        workflows = sysObject.getWorkflows("","");
        if (workflows != null && workflows.next()) {
          workflowObject.abort();
          workflowObject.destroy();
          workflows.close();
        }
        sysObject.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }
  public void testWithValidObjectWithAllValuesSetWorkflowTaskToNotify() throws Exception {
    //this test runs with dmadmin as it needs to fetch host from server config and form the url
    //TODO
    //make it work with a devl user
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, "devl29", "devl29");
    IDfSession session = null;
    IDfSysObject sysObject = null;
    IDfCollection workflows = null;
    IDfWorkflow workflowObject = null;
    IDfId workflowId;
    Object dummyObj = new Object();
    try {
      session = sessionManager.getSession(BreedingTechnologyNotifyUsers_AT.TESTDOCBASE);

      synchronized (dummyObj) {
        sysObject = createSessionAndValidObjectWithAllValues(session);
        assertObjectInfo(session, sysObject);
        //we need this wait for the queque items and workitems to get created
        dummyObj.wait(50000);
        completeApprovalTasks(session);
        dummyObj.notify();
        dummyObj.wait(50000);
        promoteAndNotify(session);
        dummyObj.notify();
        dummyObj.wait(50000);
        dummyObj.notify();
        }
      sysObject = (IDfSysObject) session.getObjectByQualification("breed_tech_doc where object_name = 'Test BT_AT Method'");
       assertEquals("Approved", sysObject.getCurrentStateName());
    } catch (DfServiceException e) {
      e.printStackTrace();
    } finally {
      if (sysObject != null) {
//        workflows = sysObject.getWorkflows("","");
//        if (workflows != null && workflows.next()) {
//          workflowId = (IDfId) workflows.getId("r_workflow_id");
//          workflowObject = (IDfWorkflow) session.getObject(workflowId);
//          workflowObject.abort();
//          workflowObject.destroy();
//          workflows.close();
//        }
        sysObject.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }
  private IDfSysObject createSessionAndValidObjectWithAllValues(IDfSession session) throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, "devl11", "devl11");
    IDfSysObject sysObject = null;
    session = sessionManager.getSession(BreedingTechnologyNotifyUsers_AT.TESTDOCBASE);
    sysObject = (IDfSysObject) session.newObject("breed_tech_doc");
    sysObject.setString("object_name","Test BT_AT Method");
    sysObject.setRepeatingString("keywords",0,"kk");
    sysObject.setRepeatingString("authors",0,"usha");
    sysObject.setString("bt_level","Corporate");
    sysObject.setString("bt_function","All");
    sysObject.setString("site","All");
    sysObject.setRepeatingString("crop",0,"All");
    sysObject.setContentType( "crtext" );
    sysObject.setString("version_comments","This is a new document");
    sysObject.save();
    return sysObject;
  }
  private void assertObjectInfo(IDfSession session, IDfSysObject sysObject) throws DfException {
    IDfCollection workflows;
    IDfId workflowId;
    IDfWorkflow workflowObject;
    assertNotNull(session);
    assertNotNull(sysObject);
    assertEquals("Test BT_AT Method", sysObject.getObjectName());
    assertEquals("Corporate", sysObject.getString("bt_level"));
    assertEquals("All",  sysObject.getString("bt_function"));
    assertEquals("All", sysObject.getString("site"));
    assertEquals("Breeding Technology LC", sysObject.getPolicyName());
//    assertEquals("Draft", sysObject.getCurrentStateName());
    workflows = sysObject.getWorkflows("","");
    if (workflows != null && workflows.next()) {
      workflowId = (IDfId) workflows.getId("r_workflow_id");
      workflowObject = (IDfWorkflow) session.getObject(workflowId);
      assertEquals("Breeding Technology Approval Workflow 2008-08-26",workflowObject.getObjectName());
    }
  }
  private void completeApprovalTasks(IDfSession session) throws Exception {
    //TODO
    // need to make the test better by getting all the workitems maybe rather than tasks as performers can change
    IDfCollection workflows = null;
    IDfWorkflow workflowObject = null;
    IDfSysObject sysObject = null;
    IDfId workflowId = null;
    sysObject = (IDfSysObject) session.getObjectByQualification("breed_tech_doc where object_name = 'Test BT_AT Method'");
    assertObjectInfo(session, sysObject);
    workflows = sysObject.getWorkflows("","");
    if (workflows != null && workflows.next()) {
      workflowId = (IDfId) workflows.getId("r_workflow_id");
//        System.out.println("workflowId = " + workflowId);
      workflowObject = (IDfWorkflow) session.getObject(workflowId);
//        System.out.println("workflowObject.getNextSeqno() = " + workflowObject.getNextSeqno());
      //process tasks for approvers so that it reaches the PromoteAndNotify task
      //the getPerformers(activityName) does not work so the performer names are hardcoded here
      Object dummyObj = new Object();
      synchronized (dummyObj) {
      String performer = "devl10";
      completeTask(session, performer);
      System.out.println("After completing the first task");
      dummyObj.wait(25000);
      performer = "Cline Stephanie L";
      completeTask(session, performer);
      System.out.println("After completing the second task");
        dummyObj.notify();
        dummyObj.wait(50000);
      performer = "devl12";
      completeTask(session, performer);
      System.out.println("After completing the third task");
        dummyObj.notify();
        dummyObj.wait(25000);
        dummyObj.notify();
      }
   //   workflowObject.haltAll();
    }
  }
  private void completeTask(IDfSession session, String performer) throws DfException {
    IDfPersistentObject pObj;
    IDfWorkitem workItemObject;
    IDfQueueItem tasks =  (IDfQueueItem) session.getObjectByQualification("dmi_queue_item \n" +
        "where (name = '" + performer + "' and task_name = 'Approval')\n" +
        "and delete_flag=False\n" +
        "order by date_sent");
    if (tasks != null) {
      //System.out.println("tasks.getId(\"r_object_id\").toString() = " + tasks.getId("r_object_id").toString());
      //get workitem
      pObj = session.getObjectByQualification("dmi_queue_item where r_object_id='" +
          tasks.getId("r_object_id").toString() + "'");
      //System.out.println("pObj.getObjectId() = " + pObj.getObjectId());
      workItemObject = (IDfWorkitem)session.getObject(tasks.getId("item_id"));
      if (workItemObject.getRuntimeState() != workItemObject.DF_WI_STATE_ACQUIRED)
        workItemObject.acquire();
      IDfClientX clientx = new DfClientX();
      IDfList actList = clientx.getList();
      IDfList forwardList = workItemObject.getForwardActivities();
      if(forwardList.getCount()>0) {
      //  System.out.println("forwarding by default to =" + ((IDfActivity) forwardList.get(0)).getObjectName());
        actList.append(forwardList.get(0));
        workItemObject.setOutputByActivities(actList);
      }else {
      //  System.out.println("There are no more forward activities, using default");
      }
      workItemObject.complete();
    }
  }
  private void promoteAndNotify(IDfSession session) throws Exception {
    IDfSysObject sysObject;
    IDfCollection workflows;
    IDfId workflowId;
    IDfWorkflow workflowObject;
    IDfPersistentObject pObj;
    IDfWorkitem workItemObject;
    //Create the object in the previous test and don't destroy it
    sysObject = (IDfSysObject) session.getObjectByQualification("breed_tech_doc where object_name = 'Test BT_AT Method'");
    assertNotNull(session);
    assertNotNull(sysObject);
    assertEquals("Test BT_AT Method", sysObject.getObjectName());
    assertEquals("Corporate", sysObject.getString("bt_level"));
    assertEquals("All",  sysObject.getString("bt_function"));
    assertEquals("All", sysObject.getString("site"));
    assertEquals("Breeding Technology LC", sysObject.getPolicyName());
//    assertEquals("Draft", sysObject.getCurrentStateName());
    workflows = sysObject.getWorkflows("","");
    if (workflows != null && workflows.next()) {
      workflowId = (IDfId) workflows.getId("r_workflow_id");
      System.out.println("workflowId = " + workflowId);
      workflowObject = (IDfWorkflow) session.getObject(workflowId);
      assertEquals("Breeding Technology Approval Workflow 2008-08-26",workflowObject.getObjectName());
      System.out.println("workflowObject.getNextSeqno() = " + workflowObject.getNextSeqno());
      pObj = session.getObjectByQualification("dmi_workitem where r_workflow_id = '" + workflowId + "' and r_auto_method_id = '10001abe80176885'");

      System.out.println("pObj.getObjectId() = " + pObj.getObjectId());
      workItemObject = (IDfWorkitem)session.getObject(pObj.getObjectId());
      System.out.println("workItemObject.getObjectId() = " + workItemObject.getObjectId());
      //get package id
      IDfCollection packages = workItemObject.getPackages("");
      String documentId = new String();
      while (packages.next()){
        documentId = packages.getString("r_component_id");
        System.out.println("i am in packages = " );
        System.out.println("Component id = " + packages.getString("r_component_id"));
        System.out.println("package id or object id= " + packages.getString("r_object_id"));
        System.out.println("r_package_name= " + packages.getString("r_package_name"));

      }
      System.out.println("documentId = " + documentId);
      Map testArgs = new HashMap();
      testArgs.put(DOCBASE_ARG_NAME, new String[]{session.getDocbaseName()});
      testArgs.put(TICKET_ARG_NAME, new String[]{session.getLoginTicket()});
      testArgs.put(USER_ARG_NAME, new String[]{session.getLoginUserName()});
      testArgs.put(WORKITEMID_ARG_NAME, new String[]{workItemObject.getObjectId().toString()});
      testArgs.put(PACKAGEID_ARG_NAME, new String[]{sysObject.getObjectId().toString()});
      System.out.println("workItemObject.getRuntimeState() = " + workItemObject.getRuntimeState());
      if (workItemObject.getRuntimeState() != 2){
        //            workItemObject.acquire();
        //            System.out.println("Task Acquired !!!");
        System.out.println("Excuting method = ");
        /*            String arguments = new String();
       arguments =  " docbase_name " + session.getDocbaseName()
           + " user " + session.getLoginUserName()
           + " ticket " + session.getLoginTicket()
           + " workitemId " + pObj.getObjectId()
           +" packageId " + packageId + "'";
       runMethod(session, "BreedingTechnologyNotifyUsers",arguments);*/
        BreedingTechnologyNotifyUsers btNotifyUsers = new BreedingTechnologyNotifyUsers();
//        workflowObject.resumeAll();
        System.out.println("sysObject.getCurrentStateName() = " + sysObject.getCurrentStateName());
//        if (sysObject.getCurrentStateName() == "Approved")
//                 sysObject.demote("Draft", false);
        //btNotifyUsers.execute(testArgs, outputStream);
      }
    }
  }
  private void runMethod(IDfSession session, String methodName, String arguments) throws DfException {
    List argumentValues = Arrays.asList(new String[]{methodName, "TRUE", arguments});
    List argumentNames = Arrays.asList(new String[]{"METHOD", "SAVE_RESULTS", "ARGUMENTS"});
    List argumentTypes = Arrays.asList(new String[]{"S", "B", "S"});
    methodResults = session
        .apply(null, "DO_METHOD", createDfListFromList(argumentNames), createDfListFromList(argumentTypes),
            createDfListFromList(argumentValues));
  }
  private IDfId assertSuccessfulResultsCollection() throws DfException {
    assertNotNull(methodResults);
    assertTrue(methodResults.next());
    assertFalse(methodResults.getBoolean("launch_failed"));
    assertNotNull(methodResults.getId("result"));
    assertEquals(0, methodResults.getInt("method_return_val"));
    assertFalse(methodResults.getBoolean("timed_out"));
    IDfId resultsId = methodResults.getId("result_doc_id");
    assertNotNull(resultsId);
    assertFalse(methodResults.next());
    methodResults.close();
    return resultsId;
  }
  private IDfList createDfListFromList(List list) throws DfException {
    DfClientX client = new DfClientX();
    IDfList dfList = client.getList();
    Iterator iterator = list.iterator();
    while (iterator.hasNext()) {
      dfList.appendString((String) iterator.next());
    }
    return dfList;
  }
  public BreedingTechnologyNotifyUsers_AT(String name) {
    super(name);
  }
}