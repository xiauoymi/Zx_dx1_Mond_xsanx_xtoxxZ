/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.breedingtechnology.test;

import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.test.*;
import com.monsanto.dctm.workflowmethods.breedingtechnology.BreedingTechnologyNotifyUsers;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: BreedingTechnologyNotifyUsers_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-02-18 20:05:41 $
 *
 * @author rrkaur
 * @version $Revision: 1.8 $
 */
public class BreedingTechnologyNotifyUsers_UT extends TestCase {

  private Map testArgs;
  private static final String DOCBASE_ARG_NAME = "docbase_name";
  private static final String USER_ARG_NAME = "user";
  private static final String TICKET_ARG_NAME = "ticket";
  private static final String WORKITEMID_ARG_NAME = "workitemId";
  private static final String PACKAGEID_ARG_NAME = "packageId";
  private static final String TESTDOCBASE = "testdocbase";
  private static final String TESTUSERID = "testuserid";
  private static final String TESTWORKFLOWID = "testworkflowid";
  private static final String TESTTICKET = "testticket";
  private static final String TESTPACKAGEID = "testpackageid";
  private ByteArrayOutputStream outputStream;
  private MockDfSessionManager sessionManager;
  public MockSession session;
  private static final String TESTINSTALLOWNER = "testinstallowner";
  private static final String TESTUSERINFOID = "testuserinfoid";

  protected void setUp(){
    sessionManager = new MockDfSessionManager();
    testArgs = new HashMap();
    testArgs.put(DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
    testArgs.put(TICKET_ARG_NAME, new String[]{TESTTICKET});
    testArgs.put(USER_ARG_NAME, new String[]{TESTUSERID});
    testArgs.put(WORKITEMID_ARG_NAME, new String[]{TESTWORKFLOWID});
    testArgs.put(PACKAGEID_ARG_NAME, new String[]{TESTPACKAGEID});
  }

  public void testCreate() throws Exception {
    BreedingTechnologyNotifyUsers breedingTechnologyNotifyUsers = new BreedingTechnologyNotifyUsers();
    assertNotNull(breedingTechnologyNotifyUsers);
    assertTrue(breedingTechnologyNotifyUsers instanceof IDmMethod);
  }

  public void testGotUserSession() throws Exception {
    MockBreedingTechnologyNotifyUsers mock = new MockBreedingTechnologyNotifyUsers(sessionManager);
    //login details and set up session
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    //sysobject or document object details
    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","09876543");
    sysObject.setString("object_name","Test Doc");
    sysObject.setString("r_current_state","0");
    //workitem details
    MockWorkitem workItemObject = new MockWorkitem();
    workItemObject.setResults(setupResults());
    //workflow details
    MockWorkflow workflowObject = new MockWorkflow();
    workflowObject.setAliasId("aliasId");
    //alias set details
    MockAliasSet aliasSet = new MockAliasSet();
    aliasSet.setAliasValue(0,"bt_corp_user");
    //group setup details
    MockDfGroup group = new MockDfGroup();
    group.setGroupName("bt_corp_user");
    //add all objects to session
    session.setDocbaseName(TESTDOCBASE);
    session.addObject(sysObject,"09876543");
    session.addObject(workItemObject,"testworkflowid");
    session.addObject(workflowObject,"123455");
    session.addObject(aliasSet,"aliasId");
    session.addGroup(group);
   // addOnlyValidObjectToSession(sysObject);

    mock.execute(testArgs, outputStream);

    IDfSession userSession = mock.sessionManager.getSession(TESTDOCBASE, TESTUSERID);
    assertNotNull(userSession);
    assertEquals(TESTUSERID, userSession.getLoginUserName());
    assertEquals(TESTUSERID, userSession.getLoginInfo().getUser());
    assertEquals(TESTTICKET, userSession.getLoginInfo().getPassword());
    assertTrue(((MockSession) userSession).wasReleaseCalled);
  }

  public void testNotificationGroupSetToAdmin() throws Exception {
    MockBreedingTechnologyNotifyUsers mock = new MockBreedingTechnologyNotifyUsers(sessionManager);
    //login details and set up session
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    //sysobject or document object details
    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","09876543");
    sysObject.setString("object_name","Test Doc");
    sysObject.setString("r_current_state","0");
    //workitem details
    MockWorkitem workItemObject = new MockWorkitem();
    workItemObject.setResults(setupResults());
    //workflow details
    MockWorkflow workflowObject = new MockWorkflow();
    workflowObject.setAliasId("aliasId");
    //alias set details
    MockAliasSet aliasSet = new MockAliasSet();
    aliasSet.setAliasValue(0,"bt_corp_admin");
    //group setup details
    MockDfGroup group = new MockDfGroup();
    group.setGroupName("bt_corp_admin");
    //add all objects to session
    session.setDocbaseName(TESTDOCBASE);
    session.addObject(sysObject,"09876543");
    session.addObject(workItemObject,"testworkflowid");
    session.addObject(workflowObject,"123455");
    session.addObject(aliasSet,"aliasId");
    session.addGroup(group);

    mock.execute(testArgs, outputStream);

    assertEquals(mock.notificationGroup,"bt_corp_admin");
  }
  public void testNotificationGroupSetToAuthor() throws Exception {
    MockBreedingTechnologyNotifyUsers mock = new MockBreedingTechnologyNotifyUsers(sessionManager);
    //login details and set up session
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    //sysobject or document object details
    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","09876543");
    sysObject.setString("object_name","Test Doc");
    sysObject.setString("r_current_state","0");
    //workitem details
    MockWorkitem workItemObject = new MockWorkitem();
    workItemObject.setResults(setupResults());
    //workflow details
    MockWorkflow workflowObject = new MockWorkflow();
    workflowObject.setAliasId("aliasId");
    //alias set details
    MockAliasSet aliasSet = new MockAliasSet();
    aliasSet.setAliasValue(0,"bt_corp_author");
    //group setup details
    MockDfGroup group = new MockDfGroup();
    group.setGroupName("bt_corp_author");
    //add all objects to session
    session.setDocbaseName(TESTDOCBASE);
    session.addObject(sysObject,"09876543");
    session.addObject(workItemObject,"testworkflowid");
    session.addObject(workflowObject,"123455");
    session.addObject(aliasSet,"aliasId");
    session.addGroup(group);

    mock.execute(testArgs, outputStream);

    assertEquals(mock.notificationGroup,"bt_corp_author");
  }
  public void testNotificationGroupSetToUser() throws Exception {
    MockBreedingTechnologyNotifyUsers mock = new MockBreedingTechnologyNotifyUsers(sessionManager);
    //login details and set up session
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    //sysobject or document object details
    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","09876543");
    sysObject.setString("object_name","Test Doc");
    sysObject.setString("r_current_state","0");
    //workitem details
    MockWorkitem workItemObject = new MockWorkitem();
    workItemObject.setResults(setupResults());
    //workflow details
    MockWorkflow workflowObject = new MockWorkflow();
    workflowObject.setAliasId("aliasId");
    //alias set details
    MockAliasSet aliasSet = new MockAliasSet();
    aliasSet.setAliasValue(0,"bt_corp_user");
    //group setup details
    MockDfGroup group = new MockDfGroup();
    group.setGroupName("bt_corp_user");
    //add all objects to session
    session.setDocbaseName(TESTDOCBASE);
    session.addObject(sysObject,"09876543");
    session.addObject(workItemObject,"testworkflowid");
    session.addObject(workflowObject,"123455");
    session.addObject(aliasSet,"aliasId");
    session.addGroup(group);

    mock.execute(testArgs, outputStream);

    assertEquals(mock.notificationGroup,"bt_corp_user");
  }
  public void testCreateNotificationGroupAndGroupHasOneUser() throws Exception {
    MockBreedingTechnologyNotifyUsers mock = new MockBreedingTechnologyNotifyUsers(sessionManager);
    //login details and set up session
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    //sysobject or document object details
    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","09876543");
    sysObject.setString("object_name","Test Doc");
    sysObject.setString("r_current_state","0");
    sysObject.setString("i_folder_id","0b001");
    sysObject.setString("object_type","breed_tech_doc");
    sysObject.setString("version_comments","Testing for version comments");
    //workitem details
    MockWorkitem workItemObject = new MockWorkitem();
    workItemObject.setResults(setupResults());
    //workflow details
    MockWorkflow workflowObject = new MockWorkflow();
    workflowObject.setAliasId("aliasId");
    //alias set details
    MockAliasSet aliasSet = new MockAliasSet();
    aliasSet.setAliasValue(0,"bt_corp_user");
    //group setup details
    MockDfGroup group = new MockDfGroup();
    group.setGroupName("bt_corp_user");
    group.addUser("testUser1");
    //config object
    MockSysObject configObject = new MockSysObject();
    configObject.setString("r_object_id","3d_server_config_id");
    configObject.setString("r_host_name","stddma00");
    //add all objects to session
    session.setDocbaseName(TESTDOCBASE);
    session.addObject(sysObject,"09876543");
    session.addObject(workItemObject,"testworkflowid");
    session.addObject(workflowObject,"123455");
    session.addObject(aliasSet,"aliasId");
    session.addGroup(group);
    session.addObject(configObject,"query_cmd,s0,F,F,,,,,select distinct r_host_name from dm_server_config_s");

    mock.execute(testArgs, outputStream);

    assertEquals(mock.notificationGroup,"bt_corp_user");
    assertTrue(sysObject.wasQueueCalled);
  }
  public void testCreateNotificationGroupAndGroupHasMoreUsers() throws Exception {
    MockBreedingTechnologyNotifyUsers mock = new MockBreedingTechnologyNotifyUsers(sessionManager);
    //login details and set up session
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    //sysobject or document object details
    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","09876543");
    sysObject.setString("object_name","Test Doc");
    sysObject.setString("r_current_state","0");
    sysObject.setString("i_folder_id","0b001");
    sysObject.setString("object_type","breed_tech_doc");
    sysObject.setString("version_comments","Testing for version comments");
    //workitem details
    MockWorkitem workItemObject = new MockWorkitem();
    workItemObject.setResults(setupResults());
    //workflow details
    MockWorkflow workflowObject = new MockWorkflow();
    workflowObject.setAliasId("aliasId");
    //alias set details
    MockAliasSet aliasSet = new MockAliasSet();
    aliasSet.setAliasValue(0,"bt_corp_user");
    //group setup details
    MockDfGroup group = new MockDfGroup();
    group.setGroupName("bt_corp_user");
    group.addUser("testUser1");
    group.addUser("testUser2");
    //config object
    MockSysObject configObject = new MockSysObject();
    configObject.setString("r_object_id","3d_server_config_id");
    configObject.setString("r_host_name","stddma00");
    //add all objects to session
    session.setDocbaseName(TESTDOCBASE);
    session.addObject(sysObject,"09876543");
    session.addObject(workItemObject,"testworkflowid");
    session.addObject(workflowObject,"123455");
    session.addObject(aliasSet,"aliasId");
    session.addGroup(group);
    session.addObject(configObject,"query_cmd,s0,F,F,,,,,select distinct r_host_name from dm_server_config_s");

    mock.execute(testArgs, outputStream);

    assertEquals(mock.notificationGroup,"bt_corp_user");
    assertTrue(sysObject.wasQueueCalled);
  }
//  public void testNotificationGroupSetToAdminWithVersionComments() throws Exception {
//    MockBreedingTechnologyNotifyUsers mock = new MockBreedingTechnologyNotifyUsers(sessionManager);
//    //login details and set up session
//    DfLoginInfo loginInfo = new DfLoginInfo();
//    loginInfo.setUser(TESTUSERID);
//    loginInfo.setPassword(TESTTICKET);
//    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
//    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
//    //sysobject or document object details
//    MockSysObject sysObject = new MockSysObject();
//    sysObject.setString("r_object_id","09876543");
//    sysObject.setString("object_name","Test Doc");
//    sysObject.setString("r_current_state","0");
//    sysObject.setString("version_comments","Testing for version comments");
//    //workitem details
//    MockWorkitem workItemObject = new MockWorkitem();
//    workItemObject.setResults(setupResults());
//    //workflow details
//    MockWorkflow workflowObject = new MockWorkflow();
//    workflowObject.setAliasId("aliasId");
//    //alias set details
//    MockAliasSet aliasSet = new MockAliasSet();
//    aliasSet.setAliasValue(0,"bt_corp_admin");
//    //group setup details
//    MockDfGroup group = new MockDfGroup();
//    group.setGroupName("bt_corp_admin");
//    group.addUser("testUser1");
//    //config object
//    MockSysObject configObject = new MockSysObject();
//    configObject.setString("r_object_id","3d_server_config_id");
//    configObject.setString("r_host_name","stddma00");
//    //add all objects to session
//    session.setDocbaseName(TESTDOCBASE);
//    session.addObject(sysObject,"09876543");
//    session.addObject(workItemObject,"testworkflowid");
//    session.addObject(workflowObject,"123455");
//    session.addObject(aliasSet,"aliasId");
//    session.addGroup(group);
//    session.addObject(configObject,"query_cmd,s0,F,F,,,,,select distinct r_host_name from dm_server_config_s");
//
//    mock.execute(testArgs, outputStream);
//
//    assertEquals(mock.notificationGroup,"bt_corp_admin");
//    //assertEquals(mock.versionComments,"Testing for version comments");
//  }
  private List setupResults() {
    Map row1 = new HashMap();
    List objectIds1 = new ArrayList();
    objectIds1.add(0, "09876543");
    row1.put("r_component_id", objectIds1);

    Map row2 = new HashMap();
    List objectIds2 = new ArrayList();
    objectIds2.add(0, "97734535");
    row2.put("r_object_id", objectIds2);

    Map row3 = new HashMap();
    List objectIds3 = new ArrayList();
    objectIds3.add(0, "765654563");
    row3.put("r_component_id", objectIds3);

    Map row4 = new HashMap();
    List objectIds4 = new ArrayList();
    objectIds4.add(0, "674654654");
    row4.put("r_component_id", objectIds4);

    List results = new ArrayList();
    results.add(row1);
    //results.add(row2);
    //results.add(row3);
    //results.add(row4);
    return results;
  }

}