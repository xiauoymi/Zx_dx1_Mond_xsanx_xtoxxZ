/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.itcontroldocs;


import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;
import java.io.OutputStream;
import java.util.*;

public class DmWorkflowPromoteLifecycle
    implements IDmMethod
{

    public DmWorkflowPromoteLifecycle()
    {
        m_sessionMgr = null;
        m_docbase = null;
        m_userName = null;
        m_workitemId = null;
        m_ticket = null;
    }

    public void execute(Map params, OutputStream ostream)
        throws Exception
    {
        IDfSessionManager sessionManager;
        IDfSession session;
        Exception exception;
        initWorkflowParams(params);
        sessionManager = login();
        session = null;
        try
        {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            workitem.acquire();
            lifeCycleState = null;
            lifeCycleOverride = false;
            lifeCycleTestOnly = false;
            IDfCollection pkgColl = null;
            ostream.write("Getting packages and promoting document(s)".getBytes());
            pkgColl = workitem.getPackages("");
            if(pkgColl != null)
            {
                while(pkgColl.next())
                {
                    String docId = pkgColl.getString("r_component_id");
                    ostream.write(docId.getBytes());
                    int docCount = pkgColl.getValueCount("r_component_id");
                    int i = 0;
                    while(i <= docCount - 1)
                    {
                        docIdObj = pkgColl.getRepeatingId("r_component_id", i);
                        if(docIdObj != null)
                        {
                            IDfId sysobjID = new DfId(docId);
                            IDfSysObject doc = (IDfSysObject)session.getObject(sysobjID);
                            doc.promote(lifeCycleState, lifeCycleOverride, lifeCycleTestOnly);
                        }
                        i++;
                    }
                }
                pkgColl.close();
            }
            workitem.complete();
        }
        catch(DfException e)
        {
            ostream.write(e.getMessage().getBytes());
            e.printStackTrace();
            throw e;
        }
         finally
        {
          if(session != null){
              try {
                sessionManager.release(session);
            }
            catch( Exception e ) {
                System.err.println( " error in releasing Session:: "+e );
            }
          }
        }
    }

    protected void initWorkflowParams(Map params)
    {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do
        {
            if(!iter.hasNext())
                break;
            String key = (String)iter.next();
            if(key != null && key.length() != 0)
            {
                String value[] = (String[])params.get(key);
                if(key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("docbase_name"))
                    m_docbase = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("workitemId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("packageId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("ticket"))
                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while(true);
    }

    protected IDfSessionManager login()
        throws DfException
    {
        if(m_docbase == null || m_userName == null || m_ticket == null)
            return null;
        IDfClient dfClient = DfClient.getLocalClient();
        if(dfClient != null)
        {
            IDfLoginInfo li = new DfLoginInfo();
            li.setUser(m_userName);
            li.setPassword(m_ticket);
            li.setDomain(null);
            IDfSessionManager sessionMgr = dfClient.newSessionManager();
            sessionMgr.setIdentity(m_docbase, li);
            return sessionMgr;
        } else
        {
            return null;
        }
    }

    protected IDfSessionManager m_sessionMgr;
    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    private static final String USER_KEY = "user";
    private static final String DOCBASE_KEY = "docbase_name";
    private static final String WORKITEM_KEY_2 = "workitemId";
    private static final String TICKET_KEY = "ticket";
    private static final String WORKITEM_KEY = "packageId";
    private IDfId docIdObj;
    private String lifeCycleState;
    private boolean lifeCycleOverride;
    private boolean lifeCycleTestOnly;
}