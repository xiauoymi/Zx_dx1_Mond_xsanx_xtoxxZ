package com.monsanto.dctm.workflowmethods.manufdocs;

import com.documentum.fc.common.IDfId;
import com.documentum.fc.common.DfException;
import com.documentum.fc.client.IDfAliasSet;
import com.documentum.fc.client.IDfSysObject;

/**
 * Created by IntelliJ IDEA.
 * User: ussing
 * Date: Feb 27, 2009
 * Time: 4:15:03 PM
 * To change this template use File | Settings | File Templates.
 */
public class DocumentPermission {
    public void grantAuthorPermissions(IDfSysObject sysObj, int permission, IDfAliasSet AliasSet) throws DfException {
        String author = new String();
        int indexofAuth = AliasSet.findAliasIndex("Author");
        if (indexofAuth > -1)
            author = AliasSet.getAliasValue(indexofAuth);
        System.out.println("WF_PromoteLifecycleAndGrantPermission.grantPermissions author = " + author);
        if (author != null){
            sysObj.revoke(author,null);
            sysObj.grant(author, permission, null);
            sysObj.save();
        }

    }
}
