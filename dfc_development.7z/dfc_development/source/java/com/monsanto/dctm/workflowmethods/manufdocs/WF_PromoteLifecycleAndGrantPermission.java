/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.manufdocs;
/*
* WF_PromoteLifecycleAndGrantPermission.java
*
* Created on July 29, 2005, 6:44 PM
*/

//package WF_JAVA_Method;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.utils.DFCSessionUtils;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Date;

/**
 * Filename:    $RCSfile: WF_PromoteLifecycleAndGrantPermission.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-04-14 18:12:39 $
 *
 * @author ussing
 * @version $Revision: 1.2 $
 */
public class WF_PromoteLifecycleAndGrantPermission implements IDmMethod {
    private static final int READ_ONLY_PERMISSION = 3;
    private IDfSessionManager sessionManager;

/*
 * WorkflowVersionMajorAndPromoteLifecycle.java
 *
 * Created By TEJA
 * Created On July 28, 2005, 11:00 AM
 *
 * Description: Workflow method to automatically grant the appropriate permissions
 * to subsequent performers in the workflow and promote the lifecycle state
 */



    public WF_PromoteLifecycleAndGrantPermission() {
        m_sessionMgr = null;
        m_docbase = null;
        m_userName = null;
        m_workitemId = null;
        m_ticket = null;
    }

    public void execute(Map params, OutputStream ostream)
            throws Exception {
        IDfSession session = null;
        initWorkflowParams(params);
        //sessionManager = login();
//          session = null;
        IDfCollection pkgColl = null;
        try {
            session = getSession(m_docbase,m_userName);
            IDfId workitemID = new DfId(m_workitemId);
            //session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            IDfWorkflow workflow = (IDfWorkflow)session.getObject(workitem.getWorkflowId());
            IDfAliasSet aliases = (IDfAliasSet)session.getObject(workflow.getAliasSetId());
            Date dateBeforeAcquire = new Date();
            System.out.println("WF_PromoteLifecycleAndGrantPermission.execute workitem = " + workitem.getObjectId() + " BEFORE ACQUIRE = " + dateBeforeAcquire.getTime() + " in format " + dateBeforeAcquire.toString() + " runtime state = "+ workitem.getRuntimeState());
            if ((workitem.getRuntimeState() != workitem.DF_WI_STATE_ACQUIRED))// || (workitem.getRuntimeState() == 0))
            {
                System.out.println("WF_PromoteLifecycleAndGrantPermission.execute Acquiring workitem " + workitem.getObjectId());
                workitem.acquire();
                Date dateAfterAcquire = new Date();
                System.out.println("WF_PromoteLifecycleAndGrantPermission.execute workitem = " + workitem.getObjectId() + " AFTER ACQUIRE = " + dateAfterAcquire.getTime() + " in format " + dateAfterAcquire.toString()+ " runtime state = "+ workitem.getRuntimeState());
            }
            lifeCycleState = null;
            lifeCycleOverride = false;
            lifeCycleTestOnly = false;
            System.out.println("WF_PromoteLifecycleAndGrantPermission: Getting packages and promoting document(s)");
            pkgColl = workitem.getPackages("");
            if(pkgColl != null) {
                while(pkgColl.next()) {
                    String docId = pkgColl.getString("r_component_id");
                    System.out.println("WF_PromoteLifecycleAndGrantPermission document id " + docId.toString());
                    int docCount = pkgColl.getValueCount("r_component_id");
                    int i = 0;
                    while(i <= docCount - 1) {
                        docIdObj = pkgColl.getRepeatingId("r_component_id", i);
                        if(docIdObj != null) {
                            IDfId sysobjID = new DfId(docId);
                            IDfSysObject doc = (IDfSysObject)session.getObject(sysobjID);
                            grantPermissions(doc, aliases);
//                              if (doc.getCurrentStateName().equals("Draft"))
//                                  doc.promote(lifeCycleState, lifeCycleOverride, lifeCycleTestOnly);
                        }
                        i++;
                    }
                }
            }
            finishWorkitem(workitem);
            //workitem.complete();
        } catch(DfException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            if (pkgColl != null)
                pkgColl.close();
            if (session != null) {
                sessionManager.release(session);
            }
        }
    }
    private void finishWorkitem(IDfWorkitem workitem)
            throws Exception {
        try {
            int runTimeState = workitem.getRuntimeState();
            System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem workitem = " + workitem.getObjectId() + " .. runTimeState "+workitem.getRuntimeState());
            //� � � � �DfLogger.debug(this,"<finishWorkitem>runTimeState " + runTimeState, null,null);
            if (runTimeState == 0) {
                workitem.acquire();
                //� � � � � �DfLogger.debug(this, "acquired ",null, null);
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem .. runTimeState acquired ");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString() + " runtime state = "+ workitem.getRuntimeState());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString() + " runtime state = "+ workitem.getRuntimeState());
                //� � � � � � � �DfLogger.debug(this, "completed ",null, null);
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem.. runTimeState completed ");
            } else if (runTimeState == 1) {
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem workitem acquired .....");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString() + " runtime state = "+ workitem.getRuntimeState());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString() + " runtime state = "+ workitem.getRuntimeState());
            } else if (runTimeState == 3) {
                workitem.resume();
                //� � � � � � �DfLogger.debug(this, "resumed ", null,null);
                workitem.acquire();
                //� � � � � � � �DfLogger.debug(this, "acquired ",null, null);
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem .. runTimeState resumed ");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString() + " runtime state = "+ workitem.getRuntimeState());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString() + " runtime state = "+ workitem.getRuntimeState());
                // � � � � � � �DfLogger.debug(this, "completed ",null, null);
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem .. runTimeState completed ");
            } else {
                //� � � � � � � �DfLogger.debug(this, "do nothingworkitem is finished", null, null);
                System.out.println("WF_PromoteLifecycleAndGrantPermission.finishWorkitem .. do nothingworkitem is finished");
            }
        } catch (Exception ex) {
            //� � � � �DfLogger.error(this, ex.getMessage(),null, ex);
            System.out.println(".. Exception in finshed workitem method "+ex);
            throw ex;
        }
    }
    protected void initWorkflowParams(Map params) {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do
        {
            if(!iter.hasNext())
                break;
            String key = (String)iter.next();
            if(key != null && key.length() != 0) {
                String value[] = (String[])params.get(key);
                if(key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("docbase_name"))
                    m_docbase = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("workitemId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("packageId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("ticket"))
                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while(true);
    }

    protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
        return DFCSessionUtils.createSessionManager(docbase, userid, password);
    }
    private IDfSession getSession(String docbase, String userid) throws DfException {
        sessionManager = getSessionManager(docbase, userid, m_ticket);
        return sessionManager.getSession(docbase);
    }
//      protected IDfSessionManager login()
//      throws DfException {
//          if(m_docbase == null || m_userName == null || m_ticket == null)
//              return null;
//          IDfClient dfClient = DfClient.getLocalClient();
//          if(dfClient != null) {
//              IDfLoginInfo li = new DfLoginInfo();
//              li.setUser(m_userName);
//              li.setPassword(m_ticket);
//              li.setDomain(null);
//              IDfSessionManager sessionMgr = dfClient.newSessionManager();
//              sessionMgr.setIdentity(m_docbase, li);
//              return sessionMgr;
//          } else {
//              return null;
//          }
//      }

    protected void grantPermissions(IDfSysObject sysObj, IDfAliasSet AliasSet)
            throws DfException {
        String reviewers = null;
        String approvers = null;
        String author = new String();

        int indexofRev = AliasSet.findAliasIndex("Reviewers");
        if (indexofRev > -1)
            reviewers = AliasSet.getAliasValue(indexofRev);
        int indexofApp = AliasSet.findAliasIndex("Approvers");
        if (indexofApp > -1)
            approvers = AliasSet.getAliasValue(indexofApp);
        //19 feb 2009
        int indexofAuth = AliasSet.findAliasIndex("Author");
        if (indexofAuth > -1)
            author = AliasSet.getAliasValue(indexofAuth);
        System.out.println("WF_PromoteLifecycleAndGrantPermission.grantPermissions author = " + author);
        if (reviewers != null && approvers != null && author != null){
            sysObj.grant(reviewers, READ_ONLY_PERMISSION, null);
            sysObj.grant(approvers, READ_ONLY_PERMISSION, null);
            sysObj.grant(author, READ_ONLY_PERMISSION, null);
            sysObj.save();
        }
    } //grantPermissions


    protected IDfSessionManager m_sessionMgr;
    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    private static final String USER_KEY = "user";
    private static final String DOCBASE_KEY = "docbase_name";
    private static final String WORKITEM_KEY_2 = "workitemId";
    private static final String TICKET_KEY = "ticket";
    private static final String WORKITEM_KEY = "packageId";
    private IDfId docIdObj;
    private String lifeCycleState;
    private boolean lifeCycleOverride;
    private boolean lifeCycleTestOnly;
}
