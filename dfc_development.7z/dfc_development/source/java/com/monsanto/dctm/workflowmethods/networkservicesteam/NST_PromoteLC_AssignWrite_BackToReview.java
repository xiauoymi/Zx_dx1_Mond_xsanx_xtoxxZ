/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.networkservicesteam;

/*
 * NST_PromoteLC_AssignWrite_BackToReview.java
 *
 * Created By: Veeravalli Phani
 *
 * Created On: January 10, 2006, 4:20 PM
 *
 * Application: Network Services Document
 *
 * Notes: This method checks for current lifecycle state of a document before demoting to next state.
 *        If current state is "Under Approval" it demotes the document to "Under Review" state.
 *        Also, assigns write permission to Review activity performer
 */

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;
import java.io.OutputStream;
import java.util.*;

public class NST_PromoteLC_AssignWrite_BackToReview
    implements IDmMethod
{

    public NST_PromoteLC_AssignWrite_BackToReview()
    {
        m_sessionMgr = null;
        m_docbase = null;
        m_userName = null;
        m_workitemId = null;
        m_ticket = null;
    }

    public void execute(Map params, OutputStream ostream)
        throws Exception
    {
        IDfSessionManager sessionManager;
        IDfSession session;
        Exception exception;
        initWorkflowParams(params);
        sessionManager = login();
        session = null;
        try
        {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            workitem.acquire();
            lifeCycleState = null;
            lifeCycleOverride = false;
            lifeCycleTestOnly = false;
            IDfCollection pkgColl = null;
            pkgColl = workitem.getPackages("");
             IDfSysObject doc = null;
            if(pkgColl != null)
            {
                while(pkgColl.next())
                {
                    String docId = pkgColl.getString("r_component_id");
                    ostream.write(docId.getBytes());
                    int docCount = pkgColl.getValueCount("r_component_id");
                    int i = 0;
                    while(i <= docCount - 1)
                    {

                        docIdObj = pkgColl.getRepeatingId("r_component_id", i);
                        if(docIdObj != null)
                        {
                            IDfId sysobjID = new DfId(docId);
                            doc = (IDfSysObject)session.getObject(sysobjID);
                            String docState = doc.getCurrentStateName();
                            if(docState.equals("Under Approval")){
                               String docDemoteState = "Under Review";
                               boolean baseState = false;
                               doc.demote(docDemoteState,baseState);
                            }
                        }
                        i++;
                    }
                     changePermission(workitem,session,doc);
                }
                pkgColl.close();
            }
            workitem.complete();
        }
        catch(DfException e)
        {
            ostream.write(e.getMessage().getBytes());
            e.printStackTrace();
            throw e;
        }
         finally
        {
          if(session != null){
              try {
                sessionManager.release(session);
            }
            catch( Exception e ) {
                System.err.println( " error in releasing Session:: "+e );
            }
          }
        }
    }

    protected void initWorkflowParams(Map params)
    {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do
        {
            if(!iter.hasNext())
                break;
            String key = (String)iter.next();
            if(key != null && key.length() != 0)
            {
                String value[] = (String[])params.get(key);
                if(key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("docbase_name"))
                    m_docbase = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("workitemId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("packageId"))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else
                if(key.equalsIgnoreCase("ticket"))
                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while(true);
    }

    protected IDfSessionManager login()
        throws DfException
    {
        if(m_docbase == null || m_userName == null || m_ticket == null)
            return null;
        IDfClient dfClient = DfClient.getLocalClient();
        if(dfClient != null)
        {
            IDfLoginInfo li = new DfLoginInfo();
            li.setUser(m_userName);
            li.setPassword(m_ticket);
            li.setDomain(null);
            IDfSessionManager sessionMgr = dfClient.newSessionManager();
            sessionMgr.setIdentity(m_docbase, li);
            return sessionMgr;
        } else
        {
            return null;
        }
    }

    //Assign write to review performer.
     protected void changePermission(IDfWorkitem workitem,IDfSession sess,IDfSysObject docObj) throws DfException {
        String performerName = null;
        IDfList perfrmList = getPerformerFromActivity(workitem,sess);
        if(perfrmList!=null){
            int percnt = perfrmList.getCount();
            System.out.println(" PERFORMERS LIST COUNT in review = " + percnt);
            for (int a=0; a<percnt; a++)
               {
                  performerName = perfrmList.getString(a);
                  System.out.println(" PERFOMER NAME in review= " + performerName);
                  //docObj.setOwnerPermit(3);
                  docObj.grant(performerName,6, null);
                  docObj.save();
               }

        }
    }

     //Get performers of "review" activity
     protected IDfList getPerformerFromActivity(IDfWorkitem workitem,IDfSession sess) throws DfException {
        IDfWorkflow wrkflObj = null;
        IDfId wrkflId = null;
        IDfList performerList = null;
        String activityName ="Review";
        String performerName = null;
        wrkflId = workitem.getWorkflowId();
        wrkflObj = (IDfWorkflow)sess.getObject(wrkflId);
        //IDfId processId = wrkflObj.getProcessId();
        //IDfProcess procressObj = (IDfProcess)sess.getObject(processId);
        //int nxtActNum = wrkflObj.getNextSeqno();
        // System.out.println(" Next Activity name = " + procressObj.getActivityName(nxtActNum));
        //int actSeqNum = wrkflObj.getActSeqno(nxtActNum);
        // activityName  = wrkflObj.getActName(actSeqNum);
        // System.out.println(" Next Activity NAME = " + activityName);
        performerList = wrkflObj.getPerformers(activityName);
        return performerList;
     }

    protected IDfSessionManager m_sessionMgr;
    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    private static final String USER_KEY = "user";
    private static final String DOCBASE_KEY = "docbase_name";
    private static final String WORKITEM_KEY_2 = "workitemId";
    private static final String TICKET_KEY = "ticket";
    private static final String WORKITEM_KEY = "packageId";
    private IDfId docIdObj;
    private String lifeCycleState;
    private boolean lifeCycleOverride;
    private boolean lifeCycleTestOnly;
}