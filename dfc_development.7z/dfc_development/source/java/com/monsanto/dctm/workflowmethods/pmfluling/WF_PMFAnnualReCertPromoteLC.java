/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.pmfluling;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
/**
 *
 * @author tsvedan
 */
public class WF_PMFAnnualReCertPromoteLC implements IDmMethod {

    /** Creates a new instance of com.monsanto.dctm.pmfluling.workflowmethods.WF_PMFAnnualReCertPromoteLC */
    public WF_PMFAnnualReCertPromoteLC() {
        m_sessionMgr = null;
        m_docbase = null;
        m_userName = null;
        m_workitemId = null;
        m_ticket = null;
    }

    public void execute(Map params, OutputStream ostream)
    throws DfException {
        IDfSessionManager sessionManager;
        IDfSession session;
        initWorkflowParams(params);
        sessionManager = login();
        IDfCollection pkgColl = null;
        session = null;
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            if(workitem.getRuntimeState() == 0){
                workitem.acquire();
            }
            System.out.println("******Getting packages and promoting document(s)");
            pkgColl = workitem.getPackages("");
            if(pkgColl != null) {
                while(pkgColl.next()) {
                    String strObjId = pkgColl.getString("r_component_id");
                    System.out.println(strObjId.toString());
                    int docCount = pkgColl.getValueCount("r_component_id");
                    for (int i = 0; i < docCount; i++) {
                        objId = pkgColl.getRepeatingId("r_component_id", i);
                        if(objId != null) {
                            IDfSysObject doc = (IDfSysObject)session.getObject(new DfId(strObjId));
                            setReviewDate(doc);
                            doc.promote(null, false, false);
                        }
                    }
                }
            }
            workitem.complete();
        } catch(DfException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            pkgColl.close();
            if(session != null)
                sessionManager.release(session);
        }
    }

    protected void initWorkflowParams(Map params) {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do
        {
            if(!iter.hasNext())
                break;
            String key = (String)iter.next();
            if(key != null && key.length() != 0) {
                String value[] = (String[])params.get(key);
                if(key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else
                    if(key.equalsIgnoreCase("docbase_name"))
                        m_docbase = value.length <= 0 ? "" : value[0];
                    else
                        if(key.equalsIgnoreCase("workitemId"))
                            m_workitemId = value.length <= 0 ? "" : value[0];
                        else
                            if(key.equalsIgnoreCase("packageId"))
                                m_workitemId = value.length <= 0 ? "" : value[0];
                            else
                                if(key.equalsIgnoreCase("ticket"))
                                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while(true);
    }

    protected IDfSessionManager login()
    throws DfException {
        if(m_docbase == null || m_userName == null || m_ticket == null)
            return null;
        IDfClient dfClient = DfClient.getLocalClient();
        if(dfClient != null) {
            IDfLoginInfo li = new DfLoginInfo();
            li.setUser(m_userName);
            li.setPassword(m_ticket);
            li.setDomain(null);
            IDfSessionManager sessionMgr = dfClient.newSessionManager();
            sessionMgr.setIdentity(m_docbase, li);
            return sessionMgr;
        } else {
            return null;
        }
    }

    protected void setReviewDate(IDfSysObject sysObj) throws DfException {

        IDfClientX clientx = new DfClientX();
        Calendar cal = new GregorianCalendar();
        cal.add(Calendar.YEAR, 1);

        String strReviewDate = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(cal.getTime());
        IDfTime time = clientx.getTime(strReviewDate, IDfTime.DF_TIME_PATTERN44);
        System.out.println("$$$$$$Setting Review Date to: " + strReviewDate);
        sysObj.setTime("revision_date", time);
        sysObj.save();

    }

    protected IDfSessionManager m_sessionMgr;
    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    private IDfId objId;

}
