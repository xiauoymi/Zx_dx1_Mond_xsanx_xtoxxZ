/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.pmfluling;

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.util.*;

public class WF_PMFAnnualReCertSetPerformers
        implements IDmMethod {

    public WF_PMFAnnualReCertSetPerformers() {
        m_sessionMgr = null;
        m_docbase = null;
        m_userName = null;
        m_workitemId = null;
        m_ticket = null;
        m_strUnitCode = null;
    }

    public void execute(Map params, OutputStream ostream)
    throws DfException {
        IDfSessionManager sessionManager;
        IDfSession session = null;
        Exception exception;
        initWorkflowParams(params);
        sessionManager = login();
        IDfCollection pkgColl = null;
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            IDfWorkflow workflow = (IDfWorkflow)session.getObject(workitem.getWorkflowId());
            if(workitem.getRuntimeState() == workitem.DF_WI_STATE_DORMANT){
              workitem.acquire();
              System.out.println("Getting packages, setting performers..");
              pkgColl = workitem.getPackages("");
              if(pkgColl != null) {
                  while(pkgColl.next()) {
                      String str_docId = pkgColl.getString("r_component_id");
                      System.out.println(str_docId.toString());
                      int docCount = pkgColl.getValueCount("r_component_id");
                      for (int i = 0; i < docCount; i++) {
                          m_docId = pkgColl.getRepeatingId("r_component_id", i);
                          if(m_docId != null && !m_docId.isNull()) {
                              IDfId sysobjID = new DfId(str_docId);
                              IDfSysObject doc = (IDfSysObject)session.getObject(sysobjID);
                              StringBuffer query = new StringBuffer("select coded_value from dm_dbo.code_lookup");
                              query.append(" where decoded_value='").append(doc.getString("mfg_unit")).append("'");
                              query.append(" and code_type='pmf_luling_unit'");
                              m_strUnitCode = execQuery(query.toString(), session);
  //                            System.out.println("Document belongs to.. " + m_strUnitCode);
                              setPerformers(workflow, session);
                              grantPermissions(doc);
                              abortMOCWorkflow(doc, session);
                          }
                      }
                }
              }
              workitem.complete();
            }

        } catch(DfException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            pkgColl.close();
            if(session != null)
                sessionManager.release(session);
        }
    } //execute

    protected void initWorkflowParams(Map params) {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do
        {
            if(!iter.hasNext())
                break;
            String key = (String)iter.next();
            if(key != null && key.length() != 0) {
                String value[] = (String[])params.get(key);
                if(key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else
                    if(key.equalsIgnoreCase("docbase_name"))
                        m_docbase = value.length <= 0 ? "" : value[0];
                    else
                        if(key.equalsIgnoreCase("workitemId"))
                            m_workitemId = value.length <= 0 ? "" : value[0];
                        else
                            if(key.equalsIgnoreCase("packageId"))
                                m_workitemId = value.length <= 0 ? "" : value[0];
                            else
                                if(key.equalsIgnoreCase("ticket"))
                                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while(true);
    } //initWorkflowParams

    protected IDfSessionManager login()
    throws DfException {
        if(m_docbase == null || m_userName == null || m_ticket == null)
            return null;
        IDfClient dfClient = DfClient.getLocalClient();
        if(dfClient != null) {
            IDfLoginInfo li = new DfLoginInfo();
            li.setUser(m_userName);
            li.setPassword(m_ticket);
            li.setDomain(null);
            IDfSessionManager sessionMgr = dfClient.newSessionManager();
            sessionMgr.setIdentity(m_docbase, li);
            return sessionMgr;
        } else {
            return null;
        }
    } //login

    protected String execQuery(String queryString,
            IDfSession sess) throws DfException{
        IDfCollection coll = null;
        IDfClientX clientx = new DfClientX();
        IDfQuery q = clientx.getQuery();
        String result = null;
        q.setDQL(queryString); //Give it the query
        coll = q.execute(sess, IDfQuery.DF_READ_QUERY);
        if(coll.next()){
            result = coll.getString("coded_value");
            System.out.println("Query executed... Result is " + result);
        }
        if (coll != null)
            coll.close();
        return result;
    } //execQuery

    protected void setPerformers(IDfWorkflow workflow, IDfSession sess) throws DfException {
        String supervisor = null;
        IDfList list = new DfList();
        perfs = new Vector();
        list.appendString(workflow.getCreatorName());
        workflow.setPerformers("Edit", list);
        list = new DfList();
        String str = "lul_" + m_strUnitCode + "_mfg_tct";
        IDfGroup reviewers = sess.getGroup(str);
        perfs.add(str);
        list.appendString(str);
        workflow.setPerformers("TCT Review", list);
        list = new DfList();
        str = "lul_" + m_strUnitCode + "_super";
        perfs.add(str);
        list.appendString(str);
        workflow.setPerformers("Super Review", list);
        list = new DfList();
        str = "lul_" + m_strUnitCode + "_bul";
        perfs.add(str);
        list.appendString(str);
        workflow.setPerformers("BUL Review", list);
        list = new DfList();
        str = "lul_" + m_strUnitCode + "_psm_clerk";
        perfs.add(str);
        list.appendString(str);
        workflow.setPerformers("Approve", list);

        if (reviewers != null && reviewers.getUsersNamesCount() > 0){
            supervisor = reviewers.getAllUsersNames(0);
            workflow.updateSupervisorName(supervisor);
            System.out.println("Changed the supervisor for workflow to: " + supervisor);
        }
    }

    protected void grantPermissions(IDfSysObject sysObj) throws DfException {
        String str = null;
        Enumeration e = perfs.elements();
        while(e.hasMoreElements()){
            str = (String) e.nextElement();
            sysObj.grant(str, 6, null);
        }
        sysObj.save();
    }

    protected void abortMOCWorkflow(IDfSysObject sysObj, IDfSession sess) throws DfException {
        IDfCollection coll = null;
        IDfWorkflow workflow = null;
        try{
          coll = sysObj.getWorkflows("", "");
          if (coll != null){
            while(coll.next()){
              workflow = (IDfWorkflow) sess.getObject(coll.getId("r_workflow_id"));
              if (workflow != null){
                String strWfName = workflow.getObjectName();
                System.out.println("Workflow name = " + strWfName + " terminated = " +workflow.DF_WF_STATE_TERMINATED);
                if (strWfName.startsWith("PMF Luling MOC")){
                  if (workflow.getRuntimeState() != workflow.DF_WF_STATE_TERMINATED ){
                    workflow.abort();
                    break;
                  }
                }
              }
            }
          }
       }finally{
        coll.close();
       }
    }

    protected IDfSessionManager m_sessionMgr;
    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    protected String m_strUnitCode;
    protected IDfId m_docId;
    protected Vector perfs;
}


