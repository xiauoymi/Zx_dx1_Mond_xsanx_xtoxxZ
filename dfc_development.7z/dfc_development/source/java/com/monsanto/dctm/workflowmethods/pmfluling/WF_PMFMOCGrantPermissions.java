/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.pmfluling;

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/*
 * WorkflowVersionMajorAndPromoteLifecycle.java
 *
 * Created By TEJA
 * Created On July 28, 2005, 11:00 AM
 *
 * Description: Workflow method to automatically grant the appropriate permissions
 * to subsequent performers in the workflow and promote the lifecycle state
 */



public class WF_PMFMOCGrantPermissions implements IDmMethod {

    public WF_PMFMOCGrantPermissions() {
        m_sessionMgr = null;
        m_docbase = null;
        m_userName = null;
        m_workitemId = null;
        m_ticket = null;
    }

    public void execute(Map params, OutputStream ostream)
    throws Exception {
        IDfSessionManager sessionManager;
        IDfSession session;
        Exception exception;
        initWorkflowParams(params);
        IDfCollection pkgColl = null;
        sessionManager = login();
        session = null;
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            IDfWorkflow workflow = (IDfWorkflow)session.getObject(workitem.getWorkflowId());
            IDfAliasSet aliases = (IDfAliasSet)session.getObject(workflow.getAliasSetId());
            if(workitem.getRuntimeState() == 0)
              workitem.acquire();

            System.out.println("Getting packages and granting permissions...");
            pkgColl = workitem.getPackages("");
            if(pkgColl != null) {
                while(pkgColl.next()) {
                    String docId = pkgColl.getString("r_component_id");
                    System.out.println(docId.toString());
                    int docCount = pkgColl.getValueCount("r_component_id");
                    int i = 0;
                    while(i <= docCount - 1) {
                        docIdObj = pkgColl.getRepeatingId("r_component_id", i);
                        if(docIdObj != null) {
                            IDfId sysobjID = new DfId(docId);
                            IDfSysObject doc = (IDfSysObject)session.getObject(sysobjID);
                            grantPermissions(doc, aliases);
                        }
                        i++;
                    }
                }
            }
            workitem.complete();
        } catch(DfException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            pkgColl.close();
            if(session != null)
                sessionManager.release(session);
        }
    }

    protected void initWorkflowParams(Map params) {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do
        {
            if(!iter.hasNext())
                break;
            String key = (String)iter.next();
            if(key != null && key.length() != 0) {
                String value[] = (String[])params.get(key);
                if(key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else
                    if(key.equalsIgnoreCase("docbase_name"))
                        m_docbase = value.length <= 0 ? "" : value[0];
                    else
                        if(key.equalsIgnoreCase("workitemId"))
                            m_workitemId = value.length <= 0 ? "" : value[0];
                        else
                            if(key.equalsIgnoreCase("packageId"))
                                m_workitemId = value.length <= 0 ? "" : value[0];
                            else
                                if(key.equalsIgnoreCase("ticket"))
                                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while(true);
    }

    protected IDfSessionManager login()
    throws DfException {
        if(m_docbase == null || m_userName == null || m_ticket == null)
            return null;
        IDfClient dfClient = DfClient.getLocalClient();
        if(dfClient != null) {
            IDfLoginInfo li = new DfLoginInfo();
            li.setUser(m_userName);
            li.setPassword(m_ticket);
            li.setDomain(null);
            IDfSessionManager sessionMgr = dfClient.newSessionManager();
            sessionMgr.setIdentity(m_docbase, li);
            return sessionMgr;
        } else {
            return null;
        }
    }

    protected void grantPermissions(IDfSysObject sysObj, IDfAliasSet AliasSet)
    throws DfException {
        String reviewers = null;
        String approvers = null;

        int indexofRev = AliasSet.findAliasIndex("Mfg TCT");
        if (indexofRev > -1)
            reviewers = AliasSet.getAliasValue(indexofRev);
        int indexofApp = AliasSet.findAliasIndex("PSM Clerk");
        if (indexofApp > -1)
            approvers = AliasSet.getAliasValue(indexofApp);
        if (reviewers != null && approvers != null){
            sysObj.grant(reviewers, 6, null);
            sysObj.grant(approvers, 6, null);
            sysObj.save();
        }
    } //grantPermissions


    protected IDfSessionManager m_sessionMgr;
    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    private IDfId docIdObj;
}

