/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.regaffairslibrary;
/*
 * Created on Sep 22, 2005
 *
 */
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @author kveeram
 *
 */

public class CreateAutomaticRendition implements IDmMethod
{
    protected IDfSessionManager m_sessionMgr = null;
    protected String m_docbase = null;
    protected String m_userName = null;
    protected String m_workitemId = null;
    protected String m_ticket = null;
    private static final String USER_KEY = "user";
    private static final String DOCBASE_KEY = "docbase_name";
    private static final String WORKITEM_KEY_2 = "workitemId";
    private static final String TICKET_KEY = "ticket";
    private static final String WORKITEM_KEY = "packageId";
    private IDfId docIdObj;


    public void execute(Map params, OutputStream ostream) throws Exception
    {
        initWorkflowParams(params);
        IDfSessionManager sessionManager = login();
        IDfSession session = null;
        IDfWorkflow wrkflObj = null;
        IDfId wrkflId = null;
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            wrkflId = workitem.getWorkflowId();
            wrkflObj = (IDfWorkflow)session.getObject(wrkflId);
           // if(workitem.getRuntimeState() == 0)
            workitem.acquire();
            IDfCollection pkgColl = null;
            IDfSysObject myObj = null;
            IDfTime t = null;
            pkgColl = workitem.getPackages("");
            if (pkgColl != null)
                {
                 while (pkgColl.next())
                   {
                      String docId = pkgColl.getString("r_component_id");
                       ostream.write(docId.getBytes());
                      int docCount = pkgColl.getValueCount("r_component_id");
                          for (int i=0; i <=(docCount-1); i++)
                              {
                                 docIdObj = pkgColl.getRepeatingId("r_component_id", i);
                                 if (docIdObj!=null)
                                    {
                                      IDfId sysobjID = new DfId(docId);
                                      IDfSysObject doc = (IDfSysObject)session.getObject(sysobjID);
                                     doc.queue("dm_autorender_win31", "rendition", 0, false, null, "rendition_req_ps_pdf");
                                    doc.save();

                                     //Check every one min for about 10 minutes to see if the rendition has been completed
                                    boolean exFor = false;
                                    IDfCollection renditionsColl = null;
                                    for (int r = 0; r < 20; r++) {
                                       //check for pdf rendition
                                        renditionsColl = doc.getRenditions("full_format");
                                        while (renditionsColl.next())
                                           {
                                           String formatStr = renditionsColl.getString("full_format");
                                           System.out.println("Found rendition FORMAT : " + formatStr);
                                            if(formatStr.equalsIgnoreCase("PDF")){
                                            System.out.println("equals PDF.. will break loop : ");
                                            exFor = true;
                                            break;
                                           }
                                            else{
                                               Thread.sleep(60000);
                                               System.out.println("In sleep : ");
                                           }
                                         } //while
                                        if (exFor == true)
                                           //System.out.println(".. while break loop : ");
                                           break;
                                          System.out.println(".. while break loop : ");


                                   }// for
                                  renditionsColl.close();
                                 }
                                }
                             }
                            }
         // workitem.complete();
          finishWorkitem(workitem);
           System.out.println ("@@@@ After finishWorkitem ");
       }
       catch (DfException e)
       {
           ostream.write(e.getMessage().getBytes());
            e.printStackTrace();    // spit out to stderr as well
           throw e;
       }
       finally
        {
           if ( session != null )
               sessionManager.release(session);
       }
    }

   private void finishWorkitem(IDfWorkitem workitem)
   throws Exception {
        try {
           int runTimeState = workitem.getRuntimeState();
           System.out.println(".. runTimeState "+runTimeState);
           //� � � � �DfLogger.debug(this,"<finishWorkitem>runTimeState " + runTimeState, null,null);
            if (runTimeState == 0) {
               workitem.acquire();
              //� � � � � �DfLogger.debug(this, "acquired ",null, null);
               System.out.println(".. runTimeState acquired ");
                workitem.complete();
               //� � � � � � � �DfLogger.debug(this, "completed ",null, null);
               System.out.println(".. runTimeState completed ");
             } else if (runTimeState == 1) {
                   workitem.complete();
                   } else if (runTimeState == 3) {
                     workitem.resume();
                       //� � � � � � �DfLogger.debug(this, "resumed ", null,null);
                    System.out.println(".. runTimeState resumed ");
                      workitem.acquire();
                        //� � � � � � � �DfLogger.debug(this, "acquired ",null, null);
                       System.out.println(".. runTimeState resumed ");
                        workitem.complete();
                        // � � � � � � �DfLogger.debug(this, "completed ",null, null);
                         System.out.println(".. runTimeState completed ");
                        } else {
                            //� � � � � � � �DfLogger.debug(this, "do nothingworkitem is finished", null, null);
                            System.out.println(".. do nothingworkitem is finished");
                           }
            } catch (Exception ex) {
                 //� � � � �DfLogger.error(this, ex.getMessage(),null, ex);
                 System.out.println(".. Exceprtion in finshed workitem method "+ex);
                throw ex;
                }
       }

    protected void initWorkflowParams(Map params)
    {
        // get the 4 WF-related parameters always passed in by Server
       Set keys = params.keySet();
       Iterator iter = keys.iterator();
       while (iter.hasNext())
       {
         String key = (String) iter.next();
           if( (key == null) || (key.length() == 0) )
           {
               continue;
           }
          String []value = (String[])params.get(key);
           if ( key.equalsIgnoreCase(USER_KEY) )
               m_userName = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(DOCBASE_KEY) )
              m_docbase = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(WORKITEM_KEY_2 ) )
              m_workitemId = (value.length > 0) ? value[0] : "";
          else if ( key.equalsIgnoreCase(WORKITEM_KEY ) )
               m_workitemId = (value.length > 0) ? value[0] : "";
           else if ( key.equalsIgnoreCase(TICKET_KEY) )
               m_ticket = (value.length > 0) ? value[0] : "";
       }
  }

   protected IDfSessionManager login() throws DfException
   {
       if (m_docbase == null || m_userName == null || m_ticket == null )
           return null;
       // now login
       IDfClient dfClient = DfClient.getLocalClient();
       if (dfClient != null)
       {
           IDfLoginInfo li = new DfLoginInfo();
           li.setUser(m_userName);
           li.setPassword(m_ticket);
           li.setDomain(null);
         IDfSessionManager sessionMgr = dfClient.newSessionManager();
          sessionMgr.setIdentity(m_docbase, li);
           return sessionMgr;
       }
       return null;
   }
}
