/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.reglabeling;

/*
 * Created on Jul 18, 2005
 *
 */

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @author kveeram
 *
 */

public class AutoCheckNotifyDraftPrinted implements IDmMethod {
    protected IDfSessionManager m_sessionMgr = null;
    protected String m_docbase = null;
    protected String m_userName = null;
    protected String m_workitemId = null;
    protected String m_ticket = null;

    private static final String USER_KEY = "user";
    private static final String DOCBASE_KEY = "docbase_name";
    private static final String WORKITEM_KEY_2 = "workitemId";
    private static final String TICKET_KEY = "ticket";
    private static final String WORKITEM_KEY = "packageId";

    private IDfId docIdObj;
    private String lifeCycleState;
    private boolean lifeCycleOverride;
    private boolean lifeCycleTestOnly;


    public void execute(Map params, OutputStream ostream) throws Exception {
        initWorkflowParams(params);
        IDfSessionManager sessionManager = login();
        IDfSession session = null;
        IDfWorkflow wrkflObj = null;
        IDfId wrkflId = null;
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            wrkflId = workitem.getWorkflowId();
            wrkflObj = (IDfWorkflow)session.getObject(wrkflId);

            workitem.acquire();

            lifeCycleState = null ;
            lifeCycleOverride=false ;
            lifeCycleTestOnly =false ;
            IDfCollection pkgColl = null;
            DfQuery qry_act = new DfQuery();
            IDfSysObject myObj = null;
            IDfTime t = null;
            IDfList performerList = null;
            String activityNameDraftPrintedCheck = "DraftPrinted_Status_Check";
            String activityNameAutoCheckinLS1 = "Auto_Checkin_LS1";
            String activityNamePrintPlateNumberCheck = "PrintPlateNumber_Check_Error";
            IDfActivity activity = null;
            int actNo=0;
            String attrName = "pesticide_label_status";
            String attrVal = "Draft Printed";
            String attrValFrmQry ="";
            String qryString ="";
            IDfCollection qryColl = null;
            String pesticideType ="ag_pesticide_labels";

            pkgColl = workitem.getPackages("");

            if (pkgColl != null) {
                while (pkgColl.next()) {
                    String docId = pkgColl.getString("r_component_id");
                    ostream.write(docId.getBytes());
                    int docCount = pkgColl.getValueCount("r_component_id");
                    for (int i=0; i <=(docCount-1); i++) {
                        docIdObj = pkgColl.getRepeatingId("r_component_id", i);

                        if (docIdObj!=null) {
                            IDfId sysobjID = new DfId(docId);
                            IDfSysObject doc = (IDfSysObject)session.getObject(sysobjID);
                            String typeName = doc.getTypeName();
                            if(typeName.equals(pesticideType)) {
                                qryString = "select pesticide_label_status from ag_pesticide_labels where r_object_id = '"+docId+"'";
                                try {
                                    DfQuery qry = new DfQuery();
                                    qry.setDQL(qryString);
                                    qryColl = qry.execute(session, IDfQuery.DF_EXECREAD_QUERY);
                                }
                                catch (DfException dfe) {
                                    System.out.println("AutoCheckNotify Draft Printed method - Error in executing DQL query:" + dfe.toString());
                                }

                                while(qryColl.next()) {
                                    attrValFrmQry = qryColl.getString("pesticide_label_status");
                                    System.out.println(" #### ATTR VALUE OF PESTICIDE STATUS "+attrValFrmQry );
                                }
                                if(!attrVal.equals(attrValFrmQry)) {
                                    IDfActivity idfActivity = null;
                                    IDfSysObject actSysObj = null;
                                    IDfList actList = new DfList();
                                    String qualification ="";
                                    qualification = "dm_activity where object_name ='"+activityNameDraftPrintedCheck+"'";
                                    actSysObj = (IDfSysObject)session.getObjectByQualification(qualification);
                                    try{
                                        idfActivity = (IDfActivity)session.getObject(actSysObj.getObjectId());
                                        actList.append(idfActivity);
                                        workitem.setOutputByActivities(actList);

                                    }
                                    catch(DfException dfe){
                                        System.out.println("AutoCheckNotify Draft Printed method");
                                        System.out.println("Error in getting Activity when Status NOT Draft Prined:" + dfe.toString());

                                    }
                                }
                                else{
                                    IDfActivity idfActivity = null;
                                    IDfSysObject actSysObj = null;
                                    IDfList actList = new DfList();
                                    String qualification ="";
                                    qualification = "dm_activity where object_name ='"+activityNameAutoCheckinLS1+"'";
                                    actSysObj = (IDfSysObject)session.getObjectByQualification(qualification);
                                    try{
                                        idfActivity = (IDfActivity)session.getObject(actSysObj.getObjectId());
                                        actList.append(idfActivity);
                                        workitem.setOutputByActivities(actList);
                                    }
                                    catch(DfException dfe){
                                        System.out.println("AutoCheckNotify Draft Printed method");
                                        System.out.println("Error in getting Activity when Status IS Draft Prined:" + dfe.toString());
                                    }
                                }
                            }
                            else{
                                {
                                    if((doc.getString("print_plate_number").length()==0)||(doc.getString("print_plate_number").equals(null))) {
                                        IDfActivity idfActivity = null;
                                        IDfSysObject actSysObj = null;
                                        IDfList actList = new DfList();
                                        String qualification ="";
                                        qualification = "dm_activity where object_name ='"+activityNamePrintPlateNumberCheck+"'";
                                        actSysObj = (IDfSysObject)session.getObjectByQualification(qualification);
                                        try{
                                            idfActivity = (IDfActivity)session.getObject(actSysObj.getObjectId());
                                            actList.append(idfActivity);
                                            workitem.setOutputByActivities(actList);
                                        }
                                        catch(DfException dfe) {
                                            System.out.println("AutoCheckNotify Draft Printed method");
                                            System.out.println("Error in getting Activity when PrintPlateNumber is null:" + dfe.toString());
                                        }
                                    }
                                    else {
                                        IDfActivity idfActivity = null;
                                        IDfSysObject actSysObj = null;
                                        IDfList actList = new DfList();
                                        String qualification ="";
                                        qualification = "dm_activity where object_name ='"+activityNameAutoCheckinLS1+"'";
                                        actSysObj = (IDfSysObject)session.getObjectByQualification(qualification);
                                        try{
                                            idfActivity = (IDfActivity)session.getObject(actSysObj.getObjectId());
                                            actList.append(idfActivity);
                                            workitem.setOutputByActivities(actList);
                                        }
                                        catch(DfException dfe){
                                            System.out.println("AutoCheckNotify Draft Printed method");
                                            System.out.println("Error in getting Activity when PrintPlateNumber is not null:" + dfe.toString());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            workitem.complete();
        }
        catch (DfException e) {
            ostream.write(e.getMessage().getBytes());
            e.printStackTrace();    // spit out to stderr as well
            throw e;
        } finally {
            if ( session != null )
                sessionManager.release(session);
        }

    }

    protected void initWorkflowParams(Map params) {
        // get the 4 WF-related parameters always passed in by Server
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        while (iter.hasNext()) {
            String key = (String) iter.next();
            if( (key == null) || (key.length() == 0) ) {
                continue;
            }
            String []value = (String[])params.get(key);

            if ( key.equalsIgnoreCase(USER_KEY) )
                m_userName = (value.length > 0) ? value[0] : "";
            else if ( key.equalsIgnoreCase(DOCBASE_KEY) )
                m_docbase = (value.length > 0) ? value[0] : "";
            else if ( key.equalsIgnoreCase(WORKITEM_KEY_2 ) )
                m_workitemId = (value.length > 0) ? value[0] : "";
            else if ( key.equalsIgnoreCase(WORKITEM_KEY ) )
                m_workitemId = (value.length > 0) ? value[0] : "";
            else if ( key.equalsIgnoreCase(TICKET_KEY) )
                m_ticket = (value.length > 0) ? value[0] : "";
        }
    }

    protected IDfSessionManager login() throws DfException {
        if (m_docbase == null || m_userName == null || m_ticket == null )
            return null;

        // now login
        IDfClient dfClient = DfClient.getLocalClient();

        if (dfClient != null) {
            IDfLoginInfo li = new DfLoginInfo();
            li.setUser(m_userName);
            li.setPassword(m_ticket);
            li.setDomain(null);

            IDfSessionManager sessionMgr = dfClient.newSessionManager();
            sessionMgr.setIdentity(m_docbase, li);
            return sessionMgr;
        }

        return null;
    }

}
