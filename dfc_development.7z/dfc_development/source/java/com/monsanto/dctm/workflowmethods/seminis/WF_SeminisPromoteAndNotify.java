/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.seminis;

/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.DfTime;
import com.documentum.fc.common.IDfId;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.utils.DFCSessionUtils;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Map;
import java.util.Date;

/**
 * Filename:    $RCSfile: WF_SeminisPromoteAndNotify.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $
 * On:	$Date: 2009-05-12 16:42:45 $
 *
 * @author tsvedan
 * @version $Revision: 1.7 $
 */
public class WF_SeminisPromoteAndNotify implements IDmMethod {
    private String userPassword;
    protected String m_workitemId;
    protected String m_ticket;
    private String docbase = null;
    private String userid = null;
    //private  IDfSession session;
    public static final String DOCBASE_ARG_NAME = "docbase_name";
    public static final String USERID_ARG_NAME = "user";
    private IDfSessionManager sessionManager;
    public static final String WORKITEM_KEY = "workitemId";
    public static final String TICKET_KEY = "ticket";
    public static final String PACKAGE_KEY = "packageId";
    private static String NOTIFY_GROUP ="seminis_generic_promote_notify";
    private String notify_group=null;
    private static final int IN_USE;
    private static final int NOT_IN_USE;
    private static int []arrIsInUseGrp;
    private static final String[] ARR_SUFFIX_GRP;
    private static final int MAX_GRPS=3;


    static {
        IN_USE = 1;
        NOT_IN_USE = 0;
        ARR_SUFFIX_GRP = new String[MAX_GRPS];
        arrIsInUseGrp = new int[MAX_GRPS];
        for (int i=0;i<MAX_GRPS;i++)
        {
            ARR_SUFFIX_GRP[i]="_"+(i+1); // forming grps as seminis_generic_promote_notify_1, seminis_generic_promote_notify_2, seminis_generic_promote_notify_3
            arrIsInUseGrp[i]=0;
        }
    }

    public void execute(Map params, OutputStream ostream)
            throws Exception {
        IDfSession session = null;
        IDfCollection pkgColl = null;
        boolean validArguments = validateArguments(params, ostream);
        if (validArguments) {
            try {
                IDfId workitemID = new DfId(m_workitemId);
                session = getSession(docbase, userid,userPassword);
                IDfWorkitem workitem = (IDfWorkitem) session.getObject(workitemID);
                System.out.println("WF_SeminisPromoteAndNotify.execute workitem = " + workitem.getObjectId() + " workitem.getRuntimeState() = " + workitem.getRuntimeState());
                Date dateBeforeAcquire = new Date();
                System.out.println("WF_SeminisPromoteAndNotify.execute workitem = " + workitem.getObjectId() + " BEFORE ACQUIRE = " + dateBeforeAcquire.getTime() + " in format " + dateBeforeAcquire.toString());
                if (workitem.getRuntimeState() == 0)
                    workitem.acquire();
                Date dateAfterAcquire = new Date();
                System.out.println("WF_SeminisPromoteAndNotify.execute workitem = " + workitem.getObjectId() + " AFTER ACQUIRE = " + dateAfterAcquire.getTime() + " in format " + dateAfterAcquire.toString());
                System.out.println("WF_SeminisPromoteAndNotify.execute Before Getting packages setting acl, effective date and sending notifications");
                pkgColl = workitem.getPackages("");
                if (pkgColl != null) {
                    while (pkgColl.next()) {
                        String docId = pkgColl.getString("r_component_id");
                        System.out.println(docId.toString());
                        int docCount = pkgColl.getValueCount("r_component_id");
                        for (int i = 0; i < docCount; i++) {
                            IDfId docIdObj = pkgColl.getRepeatingId("r_component_id", i);
                            if (docIdObj != null) {
                                IDfId sysobjID = new DfId(docId);
                                IDfSysObject doc = (IDfSysObject) session.getObject(sysobjID);
                                //doc.promote(null, false, false);
                                System.out.println("WF_SeminisPromoteAndNotify.execute Before setACLfromDepartment doc.getObjectId() = " + doc.getObjectId());
                                setACLfromDepartment(doc, session);
                                sendNotification(doc,session);
                                System.out.println("WF_SeminisPromoteAndNotify.execute Before Woritem complete ");
//                doc.save();
                            }
                        }
                    }
                    //pkgColl.close();
                    writeMessage(ostream, "success");
                }
                finishWorkitem(workitem);
            }
            catch(DfException e)
            {
                System.out.println(e.getMessage());
                e.printStackTrace();
                throw e;
            }
            finally
            {
                if(pkgColl != null)
                    pkgColl.close();
                if(session != null)
                    sessionManager.release(session);
            }
        }
    }
    private void writeMessage(OutputStream outputStream, String message) throws IOException {
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
        bufferedWriter.write((message));
        bufferedWriter.newLine();
        bufferedWriter.flush();
    }
    private void finishWorkitem(IDfWorkitem workitem)
            throws Exception {
        try {
            int runTimeState = workitem.getRuntimeState();
            System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " .. runTimeState "+runTimeState);
            if (runTimeState == 0) {
                workitem.acquire();
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem .. runTimeState acquired ");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem .. runTimeState completed ");
            } else if (runTimeState == 1) {
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem workitem acquired .....");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
            } else if (runTimeState == 3) {
                workitem.resume();
                workitem.acquire();
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem.. runTimeState resumed ");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem .. runTimeState completed ");
            } else {
                System.out.println("WF_SeminisPromoteAndNotify.finishWorkitem .. do nothingworkitem is finished");
            }
        } catch (Exception ex) {
            //� � � � �DfLogger.error(this, ex.getMessage(),null, ex);
            System.out.println(".. Exception in finshed workitem method "+ex);
            throw ex;
        }
    }
    protected IDfSessionManager getSessionManager(String docbase, String userid, String password)
            throws DfException
    {
        return DFCSessionUtils.createSessionManager(docbase, userid, password);
    }
    protected IDfSession getSession(String docbase, String userid,String password)
            throws DfException
    {
        sessionManager = getSessionManager(docbase, userid, password);
        return sessionManager.getSession(docbase);
    }
    protected void setACLfromDepartment(IDfSysObject sysObj, IDfSession session)
            throws DfException
    {
        String department = sysObj.getString("operating_unit");
        System.out.println("WF_SeminisPromoteAndNotify.setACLfromDepartment department = " + department);
        String section = sysObj.getString("section");
        if(department.equalsIgnoreCase("Pathology"))
        {
            IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "Seminis Pathology Dept Approved");
            sysObj.setACL(newACL);
        } else
        if(department.equalsIgnoreCase("Seed Technology") && (doesSectionContains(section, "PELLETING") || doesSectionContains(section, "PRIMING")))
        {
            IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "Seminis Seed Tech ACL approved");
            sysObj.setACL(newACL);
        } else
        if(department.equalsIgnoreCase("Genetic Purity") && doesSectionContains(section, "GPG"))
        {
            IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "Seminis GP and GPG ACL approved");
            sysObj.setACL(newACL);
        } else
        if(department.equalsIgnoreCase("Genetic Purity") && doesSectionContains(section, "GPL"))
        {
            IDfACL newACL = session.getACL(session.getDocbaseOwnerName(), "Seminis GP & GPL");
            sysObj.setACL(newACL);
            System.out.println("sysObj.getACLName() = " + sysObj.getACLName());
        }
        //System.out.println("WF_SeminisPromoteAndNotify.setACLfromDepartment Date o: " + new DfTime());
        //sysObj.setTime("effective_date", new DfTime());
        Date dateBeforeSave = new Date();
        System.out.println("WF_SeminisPromoteAndNotify.setACLfromDepartment BEFORE save = "  + sysObj.getObjectId()+ " time in milli seconds " + dateBeforeSave.getTime() + " in format " + dateBeforeSave.toString());
        sysObj.save();
        Date dateAfterSave = new Date();
        System.out.println("WF_SeminisPromoteAndNotify.setACLfromDepartment AFTER save = "  + sysObj.getObjectId()+ " time in milli seconds " + dateAfterSave.getTime() + " in format " + dateAfterSave.toString());

    }
    private boolean doesSectionContains(String section, String subString)
    {
        boolean doesSectionExists = false;
        System.out.println("section = " + section);
        System.out.println("subString = " + subString);
        if(section.toUpperCase().indexOf(subString) > 0 || section.equalsIgnoreCase(subString))
            doesSectionExists = true;
        return doesSectionExists;
    }

    protected boolean validateArguments(Map params, OutputStream outputStream) throws IOException {
        boolean validArguments = true;
        if (params.containsKey(DOCBASE_ARG_NAME)) {
            docbase = ((String[]) params.get(DOCBASE_ARG_NAME))[0];
        }
        if (params.containsKey(USERID_ARG_NAME)) {
            userid = ((String[]) params.get(USERID_ARG_NAME))[0];
        }
        if (params.containsKey(TICKET_KEY )) {
            userPassword = ((String[]) params.get(TICKET_KEY))[0];
        }
//    if (params.containsKey(WORKITEM_KEY)) {
//      m_workitemId = ((String[]) params.get(WORKITEM_KEY))[0];
//      System.out.println("m_workitemId = " + m_workitemId);
//    }
        //the package id here is actually the workitem id
        if (params.containsKey(PACKAGE_KEY)) {
            m_workitemId = ((String[]) params.get(PACKAGE_KEY))[0];
        }
        if (docbase == null || docbase.length() <= 0) {
            writeMessage(outputStream, "Error:");
            writeMessage(outputStream, "must supply docbase");
            validArguments = false;
        }
        if (userid == null || userid.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply userid");
            validArguments = false;
        }
        if (m_workitemId == null || m_workitemId.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply m_workitemId");
            validArguments = false;
        }
        if (userPassword == null || userPassword.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply userPassword");
            validArguments = false;
        }
        return validArguments;
    }
    private int updateFreeGrpNo()
    {
        //default group return is always 1 if all groups are busy
        int returnValue=1;
        for (int i=0;i<MAX_GRPS;i++)
        {
            if (arrIsInUseGrp[i] == NOT_IN_USE)
            {
                returnValue=i+1;
                arrIsInUseGrp[i] = IN_USE;
                break;
            }
        }
        return returnValue;
    }
    private String getFreeGrpName(int freeGrpNo)
    {
        return NOTIFY_GROUP+ARR_SUFFIX_GRP[freeGrpNo-1];
    }
    private void updatetFreeGrpUse(int freeGrpNo,int isUse)
    {
        arrIsInUseGrp[freeGrpNo-1]=isUse;
    }
    protected void sendNotification(IDfSysObject sysObj, IDfSession session)
            throws DfException {
        System.out.println("arrIsInUseGrp = "+arrIsInUseGrp[0]+"/"+arrIsInUseGrp[1]+"/"+arrIsInUseGrp[2]);
        //getting which group is not in use
        int freeGrpNo=updateFreeGrpNo();
        notify_group=getFreeGrpName(freeGrpNo);
        if (notify_group == null) return;
        IDfGroup notify = session.getGroup(notify_group);
        System.out.println("freeGrpNo/notify_group = "+freeGrpNo+"/"+notify_group);
        if (notify == null)
        {
            System.out.println("@@@@@@<<<<<< Notification group " + notify_group + " is not created in the system");
            return;
        }
        if (notify.getUsersNamesCount() > 0){
            System.out.println("@@@@@@<<<<<< Notification group " + notify_group + " is not empty..Deleting members");
            notify.removeAllUsers();
        }
        IDfSysObject docAfterSettingEffectiveDate = (IDfSysObject) session.getObject(sysObj.getObjectId());
        int count = docAfterSettingEffectiveDate.getValueCount("notify_users");
        String message =null;
        if (count > 0) {
            message = getMessage(docAfterSettingEffectiveDate);
            for (int i = 0; i < count; i++) {
                String user = docAfterSettingEffectiveDate.getRepeatingString("notify_users", i);
                if ((user != null) && (user.trim().length() > 0))
                    notify.addUser(user);
                //System.out.println(user + ">>" + notify.getUsersNamesCount() );
            }
        }
        // vvgosw issue # 0162161
        if (notify.getUsersNamesCount()>0)
        {
            Date dateBeforeSave = new Date();

            System.out.println("BEFORE saving notify group WF_SeminisPromoteAndNotify.sendNotification = "  + sysObj.getObjectId()+ " time in milli seconds " + dateBeforeSave.getTime() + " in format " + dateBeforeSave.toString());
            notify.save();
            Date dateAfterSave = new Date();
            System.out.println("AFTER saving notify group WF_SeminisPromoteAndNotify.sendNotification = "  + sysObj.getObjectId()+ " time in milli seconds " + dateAfterSave.getTime() + " in format " + dateAfterSave.toString());
            System.out.println("WF_SeminisPromoteAndNotify.sendNotification Notify Grp "+notify_group+ " Saved. Members and length:"+ notify.getUsersNames(0)+"/"+notify.getUsersNamesCount());
            System.out.println(
                    "WF_SeminisPromoteAndNotify.sendNotification SENDING " + notify.getUsersNamesCount() + " NOTIFICATION(S) FOR DOC: " + sysObj.getObjectName());
            Date dateBeforequeue = new Date();
            System.out.println("BEFORE sending to queue for WF_SeminisPromoteAndNotify.sendNotification = "  + sysObj.getObjectId()+ " time in milli seconds " + dateBeforequeue.getTime() + " in format " + dateBeforequeue.toString());
            sysObj.queue(notify_group, "Approval Notice", 10, true, null, message);
            Date dateAfterQueue = new Date();
            System.out.println("AFTER sending to queue for WF_SeminisPromoteAndNotify.sendNotification = "  + sysObj.getObjectId()+ " time in milli seconds " + dateAfterQueue.getTime() + " in format " + dateAfterQueue.toString());
        }
        else
            System.out.println("WF_SeminisPromoteAndNotify.sendNotification There are no members in notify_users attributes of this document. No notifications sent");
        //set current used group to unused pool
        updatetFreeGrpUse(freeGrpNo,NOT_IN_USE);
    } //sendNotification

    protected String getMessage(IDfSysObject sysObj) throws DfException {
        StringBuffer strbuff = new StringBuffer();
        strbuff.append("The following document has been reviewed and approved. ");
        strbuff.append("This document is the latest version and supersedes any previous version. ");
        String msg = sysObj.getString("notify_message");
        if (msg != null && msg.length() > 0) {
            strbuff.append("Here is the notification message - ");
            strbuff.append(msg);
        } else strbuff.append("No notification message been recorded for this document!");
        return strbuff.toString();
    }
}