/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.seminis;

/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Date;

/**
 * Filename:    $RCSfile: WF_SeminisRejectAndNotify.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $
 * On:	$Date: 2009-02-18 20:11:26 $
 *
 * @author tsvedan
 * @version $Revision: 1.5 $
 */
public class WF_SeminisRejectAndNotify implements IDmMethod {

    public void execute(Map params, OutputStream ostream)
            throws Exception {
        IDfSessionManager sessionManager;
        IDfSession session;
        IDfCollection pkgColl = null;
        initWorkflowParams(params);
        sessionManager = login();
        session = null;
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem) session.getObject(workitemID);
            IDfWorkflow workflow = (IDfWorkflow) session.getObject(workitem.getWorkflowId());
            notifyList = workflow.getPerformers("Approve");
            System.out.println("WF_SeminisRejectAndNotify.execute workitem = " + workitem.getObjectId() + " workitem.getRuntimeState() = " + workitem.getRuntimeState());
            Date dateBeforeAcquire = new Date();
            System.out.println("WF_SeminisRejectAndNotify.execute workitem = " + workitem.getObjectId() + " BEFORE ACQUIRE = " + dateBeforeAcquire.getTime() + " in format " + dateBeforeAcquire.toString());
            if (workitem.getRuntimeState() == 0)
                workitem.acquire();
            Date dateAfterAcquire = new Date();
            System.out.println("WF_SeminisRejectAndNotify.execute workitem = " + workitem.getObjectId() + " AFTER ACQUIRE = " + dateAfterAcquire.getTime() + " in format " + dateAfterAcquire.toString());
            System.out.println("WF_SeminisRejectAndNotify Getting packages and sending notification(s)");
            pkgColl = workitem.getPackages("");
            if (pkgColl != null) {
                while (pkgColl.next()) {
                    String docId = pkgColl.getString("r_component_id");
                    System.out.println(docId.toString());
                    int docCount = pkgColl.getValueCount("r_component_id");
                    for (int i = 0; i < docCount; i++) {
                        IDfId docIdObj = pkgColl.getRepeatingId("r_component_id", i);
                        if (docIdObj != null) {
                            IDfId sysobjID = new DfId(docId);
                            System.out.println("WF_SeminisRejectAndNotify after getting package sysobjID = " + sysobjID);
                            IDfSysObject doc = (IDfSysObject) session.getObject(sysobjID);
                            sendRejectNotice(doc, session);
                        }
                    }
                }
                //pkgColl.close();
            }
            //workitem.complete();
            finishWorkitem(workitem);
        }
        catch (DfException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            throw e;
        }
        finally {
            if(pkgColl != null)
                pkgColl.close();
            if(session != null)
                sessionManager.release(session);
        }
    }

    private void finishWorkitem(IDfWorkitem workitem)
            throws Exception {
        try {
            int runTimeState = workitem.getRuntimeState();
            System.out.println("WF_SeminisRejectAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " .. runTimeState "+runTimeState);
            if (runTimeState == 0) {
                workitem.acquire();
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem .. runTimeState acquired ");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem .. runTimeState completed ");
            } else if (runTimeState == 1) {
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem workitem acquired .....");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
            } else if (runTimeState == 3) {
                workitem.resume();
                workitem.acquire();
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem.. runTimeState resumed ");
                Date dateBeforeComplete = new Date();
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " BEFORE COMPLETE WORKITEM = " + dateBeforeComplete.getTime() + " in format " + dateBeforeComplete.toString());
                workitem.complete();
                Date dateAfterCompleteWorkitem = new Date();
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem workitem = " + workitem.getObjectId() + " AFTER COMPLETE WORKITEM = " + dateAfterCompleteWorkitem.getTime() + " in format " + dateAfterCompleteWorkitem.toString());
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem .. runTimeState completed ");
            } else {
                System.out.println("WF_SeminisRejectAndNotify.finishWorkitem .. do nothingworkitem is finished");
            }
        } catch (Exception ex) {
            //� � � � �DfLogger.error(this, ex.getMessage(),null, ex);
            System.out.println(".. Exception in finshed workitem method "+ex);
            throw ex;
        }
    }
    protected void initWorkflowParams(Map params) {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do {
            if (!iter.hasNext())
                break;
            String key = (String) iter.next();
            if (key != null && key.length() != 0) {
                String[] value = (String[]) params.get(key);
                if (key.equalsIgnoreCase(USER_KEY))
                    m_userName = value.length <= 0 ? "" : value[0];
                else if (key.equalsIgnoreCase(DOCBASE_KEY))
                    m_docbase = value.length <= 0 ? "" : value[0];
                else if (key.equalsIgnoreCase(WORKITEM_KEY))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else if (key.equalsIgnoreCase(PACKAGE_KEY))
                    m_workitemId = value.length <= 0 ? "" : value[0];
                else if (key.equalsIgnoreCase(TICKET_KEY))
                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while (true);
    }

    protected IDfSessionManager login()
            throws DfException {
        if (m_docbase == null || m_userName == null || m_ticket == null)
            return null;
        IDfClient dfClient = DfClient.getLocalClient();
        if (dfClient != null) {
            IDfLoginInfo li = new DfLoginInfo();
            li.setUser(m_userName);
            li.setPassword(m_ticket);
            li.setDomain(null);
            IDfSessionManager sessionMgr = dfClient.newSessionManager();
            sessionMgr.setIdentity(m_docbase, li);
            return sessionMgr;
        } else {
            return null;
        }
    }

    protected void sendRejectNotice(IDfSysObject sysObj, IDfSession sess)
            throws DfException {
        System.out.println("arrIsInUseGrp = "+arrIsInUseGrp[0]+"/"+arrIsInUseGrp[1]+"/"+arrIsInUseGrp[2]);

        //getting which group is not in use
        int freeGrpNo=updateFreeGrpNo();
        rejectNotifyGroup=getFreeGrpName(freeGrpNo);

        if (notifyGroup == null || rejectNotifyGroup ==null) return;
        IDfGroup notify = sess.getGroup(notifyGroup);
        IDfGroup reject_notify = sess.getGroup(rejectNotifyGroup);
        int count = notify.getUsersNamesCount();
        if (notify == null || count < 1) {
            System.out.println("@@@@@@<<<<<< Notification group " + notifyGroup + " is either unavailable or empty");
            return;
        }
        if (reject_notify == null){
            System.out.println("@@@@@@<<<<<< Notification group " + rejectNotifyGroup + " is not created in the system");
            return;
        }
        if (reject_notify.getUsersNamesCount() > 0){
            System.out.println("@@@@@@<<<<<< Notification group " + rejectNotifyGroup + " is not empty..Deleting members" );
            reject_notify.removeAllUsers();
        }
        //logic for not adding performer into reject grp
        for (int i = 0; i < count; i++) {
            String name = notify.getAllUsersNames(i);
            System.out.println(name + ">>");
            if (name != null && name.trim().length() > 0)
                if (!sess.getLoginUserName().equals(name))
                    reject_notify.addUser(name);

        }
        String message = "This document has been sent back for revision.";
        if (reject_notify.getUsersNamesCount()>0)
        {
            Date dateBeforeSave = new Date();
            System.out.println("BEFORE saving notify group WF_SeminisRejectAndNotify.sendRejectNotice = "  + sysObj.getObjectId()+ " time in milli seconds " + dateBeforeSave.getTime() + " in format " + dateBeforeSave.toString());
            reject_notify.save();
            Date dateAfterSave = new Date();
            System.out.println("AFTER saving notify group WF_SeminisRejectAndNotify.sendRejectNotice = "  + sysObj.getObjectId()+ " time in milli seconds " + dateAfterSave.getTime() + " in format " + dateAfterSave.toString());
            System.out.println("WF_SeminisRejectAndNotify.sendRejectNotice Notify Grp "+rejectNotifyGroup+ " Saved. Members and length:"+ reject_notify.getUsersNames(0)+"/"+reject_notify.getUsersNamesCount());
            System.out.println(
                    ">>>>>SENDING " + reject_notify.getUsersNamesCount() + " REJECTION NOTIFICATION(S) FOR DOC: " + sysObj.getObjectName());
            Date dateBeforequeue = new Date();
            System.out.println("BEFORE sending to queue for WF_SeminisRejectAndNotify.sendRejectNotice = "  + sysObj.getObjectId()+ " time in milli seconds " + dateBeforequeue.getTime() + " in format " + dateBeforequeue.toString());
            sysObj.queue(rejectNotifyGroup, "Rejection Notice", 10, true, null, message);
            Date dateAfterQueue = new Date();
            System.out.println("AFTER sending to queue for WF_SeminisRejectAndNotify.sendRejectNotice = "  + sysObj.getObjectId()+ " time in milli seconds " + dateAfterQueue.getTime() + " in format " + dateAfterQueue.toString());

        }
        else
            System.out.println("WF_SeminisRejectAndNotify.sendRejectNotice There are no members added in"+ rejectNotifyGroup + ".No rejection notifications sent");

        //set current used group to unused pool
        updatetFreeGrpUse(freeGrpNo,NOT_IN_USE);

    } //sendRejectNotice
    private int updateFreeGrpNo()
    {
        //default group return is always 1 if all groups are busy
        int returnValue=1;
        for (int i=0;i<MAX_GRPS;i++)
        {
            if (arrIsInUseGrp[i] == NOT_IN_USE)
            {
                returnValue=i+1;
                arrIsInUseGrp[i] = IN_USE;
                break;
            }
        }
        return returnValue;
    }
    private String getFreeGrpName(int freeGrpNo)
    {
        return REJECTNOTIFY_GROUP+ARR_SUFFIX_GRP[freeGrpNo-1];
    }
    private void updatetFreeGrpUse(int freeGrpNo,int isUse)
    {
        arrIsInUseGrp[freeGrpNo-1]=isUse;
    }
    protected IDfSessionManager m_sessionMgr;
    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    protected String rejectedBy;
    protected String notifyGroup = "seminis_workflow_admin";
    protected IDfList notifyList = null;
    private static final String USER_KEY = "user";
    private static final String DOCBASE_KEY = "docbase_name";
    private static final String WORKITEM_KEY = "workitemId";
    private static final String TICKET_KEY = "ticket";
    private static final String PACKAGE_KEY = "packageId";

    private static String REJECTNOTIFY_GROUP ="seminis_generic_reject_notify";
    private String rejectNotifyGroup=null;
    private static final int IN_USE;
    private static final int NOT_IN_USE;
    private static int []arrIsInUseGrp;
    private static final String[] ARR_SUFFIX_GRP;
    private static final int MAX_GRPS=3;


    static {
        IN_USE = 1;
        NOT_IN_USE = 0;
        ARR_SUFFIX_GRP = new String[MAX_GRPS];
        arrIsInUseGrp = new int[MAX_GRPS];
        for (int i=0;i<MAX_GRPS;i++)
        {
            ARR_SUFFIX_GRP[i]="_"+(i+1); // forming grps as seminis_generic_reject_notify_1, seminis_generic_reject_notify_2, seminis_generic_reject_notify_3
            arrIsInUseGrp[i]=0;
        }
    }

}