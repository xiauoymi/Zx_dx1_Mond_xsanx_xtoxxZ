/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.seminis.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.IDfLoginInfo;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.workflowmethods.seminis.WF_SeminisPromoteAndNotify;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

/**
 * Filename:    $RCSfile: MockSeminisPromoteAndNotify.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-05-12 16:42:46 $
 *
 * @author rrkaur
 * @version $Revision: 1.6 $
 */
public class MockSeminisPromoteAndNotify extends WF_SeminisPromoteAndNotify {
  public MockDfSessionManager sessionManager;
  // public MockDfACL iDfACL;
  public MockSession session;
  private static final String TESTDOCBASE = "testdocbase";

  MockSeminisPromoteAndNotify(MockDfSessionManager sessionManager) throws DfServiceException, DfIdentityException,
      DfAuthenticationException {
    this.sessionManager = sessionManager;
    this.session = (MockSession) sessionManager.getSession(TESTDOCBASE);
  }

  /**
   * @noinspection RefusedBequest
   */
  protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws
      DfException {
    IDfLoginInfo loginInfoObj = new DfLoginInfo();
    loginInfoObj.setUser(userid);
    loginInfoObj.setPassword(password);
    loginInfoObj.setDomain(null);
    sessionManager.setIdentity(docbase, loginInfoObj);
    return sessionManager;
  }
  protected void setEffectiveDateAndACLfromDepartment(IDfSysObject sysObj, IDfSession session) throws DfException {
    super.setACLfromDepartment(sysObj,session);
  }
  protected void sendNotification(IDfSysObject sysObj, IDfSession session) throws DfException {
    super.sendNotification(sysObj,session);
  }
  public IDfSession getSession(String docbase, String userid,String password) throws DfException {
    return super.getSession(docbase,userid,password);

  }
  protected boolean validateArguments(Map params, OutputStream outputStream) throws IOException {
    return super.validateArguments(params,outputStream);
  }
}