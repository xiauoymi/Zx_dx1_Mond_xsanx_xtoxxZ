/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.seminis.test;

import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.workflowmethods.seminis.WF_SeminisPromoteAndNotify;
import com.monsanto.dctm.workflowmethods.seminis.WF_SeminisRejectAndNotify;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;
import com.documentum.fc.common.DfLoginInfo;

import java.util.Map;
import java.io.OutputStream;
import java.io.IOException;

/**
 * Filename:    $RCSfile: MockSeminisRejectAndNotify.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-02-18 20:12:04 $
 *
 * @author vvgosw
 * @version $Revision: 1.2 $
 */
public class MockSeminisRejectAndNotify extends WF_SeminisRejectAndNotify {
  public MockDfSessionManager sessionManager;
  // public MockDfACL iDfACL;
  public MockSession session;
  private static final String TESTDOCBASE = "testdocbase";

  MockSeminisRejectAndNotify(MockDfSessionManager sessionManager) throws DfServiceException, DfIdentityException,
      DfAuthenticationException {
    this.sessionManager = sessionManager;
    this.session = (MockSession) sessionManager.getSession(TESTDOCBASE);
  }

  /**
   * @noinspection RefusedBequest
   */
  protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws
      DfException {
    IDfLoginInfo loginInfoObj = new DfLoginInfo();
    loginInfoObj.setUser(userid);
    loginInfoObj.setPassword(password);
    loginInfoObj.setDomain(null);
    sessionManager.setIdentity(docbase, loginInfoObj);
    return sessionManager;
  }

  protected void sendRejectNotice(IDfSysObject sysObj, IDfSession session) throws DfException {
    super.sendRejectNotice(sysObj,session);
  }
}