/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.seminis.test;

import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLoginInfo;
import com.documentum.fc.common.DfTime;
import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockSysObject;
import com.monsanto.dctm.test.MockWorkitem;
import com.monsanto.dctm.test.MockDfGroup;
import com.monsanto.dctm.workflowmethods.seminis.WF_SeminisPromoteAndNotify;
import junit.framework.TestCase;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Filename:    $RCSfile: WF_SeminisPromoteAndNotify_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-05-12 16:42:45 $
 *
 * @author rrkaur
 * @version $Revision: 1.6 $
 */
public class WF_SeminisPromoteAndNotify_UT extends TestCase {

  private MockDfSessionManager sessionManager;
  public MockSession session;
  private static final String TESTDOCBASE = "testdocbase";
  private static final String TESTWORKITEMID = "testworkitemid";
  private static final String TESTUSERID = "testuserid";
  private static final String TESTTICKET = "testticket";
  private Map testArgs;
  private MockSeminisPromoteAndNotify mock;
  private ByteArrayOutputStream outputStream;
  private static final String LINESEPARATOR = System.getProperty("line.separator");
  private static final String TESTPACKAGEKEY = "testpackageid";

  protected void setUp(){
    sessionManager = new MockDfSessionManager();
  }
  public void testCreate() throws Exception
  {
    WF_SeminisPromoteAndNotify notify = new WF_SeminisPromoteAndNotify();
    assertNotNull(notify);

  }
  public void testNotifyEmails() throws Exception
  {
    MockSeminisPromoteAndNotify mock = new MockSeminisPromoteAndNotify(sessionManager);
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = new MockSession("getDocbaseOwnerName");
    IDfGroup grp = new MockDfGroup();
    grp.setGroupName("seminis_generic_promote_notify");
    grp.addUser("User1");
    session.addGroup(grp);
    MockSysObject sysObj = new MockSysObject();


    sysObj.setString("r_object_id", "091234242");
    sysObj.setString("object_name","Seminis Test Doc UT1000");
    sysObj.setString("operating_unit","Genetic Purity");
    sysObj.setString("section","section has gpg");
    sysObj.setString("acl_name","initial ACL name");
    sysObj.setRepeatingString("notify_users",0,"devl01");
    sysObj.setRepeatingString("notify_users",1,"devl02");
    sysObj.setRepeatingString("notify_users",2,"devl03");
    sysObj.setString("notify_message","Notify Message");
    session.addObject(sysObj,"091234242");
    session.addObject(sysObj,"Seminis Test Doc UT1000");

    mock.sendNotification(sysObj,session);
    assertEquals("seminis_generic_promote_notify", sysObj.targetObjName);
    assertEquals(1, MockSysObject.queueCount);

  }

  public void testApplyDefaulyACL() throws Exception {
    MockDfSessionManager mockDfSessionManager = new MockDfSessionManager();
    MockSession mockSession = new MockSession(mockDfSessionManager);
    MockSeminisPromoteAndNotify mock = new MockSeminisPromoteAndNotify(mockDfSessionManager);
    MockSysObject sysObj = new MockSysObject();
    sysObj.setSession(mockSession);
    sysObj.setString("r_object_id", "091234242");
    sysObj.setString("operating_unit","");
    sysObj.setString("section","");
    sysObj.setString("acl_name","initial ACL name");

    mock.setEffectiveDateAndACLfromDepartment(sysObj,mockSession);

    assertEquals("initial ACL name", sysObj.getString("acl_name"));
  }
  public void testDepartmentIsPathology() throws Exception {
    MockSeminisPromoteAndNotify mock = new MockSeminisPromoteAndNotify(sessionManager);
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = new MockSession("getDocbaseOwnerName");
    MockSysObject sysObj = new MockSysObject();
    sysObj.setString("r_object_id", "091234242");
    sysObj.setString("operating_unit","Pathology");
    sysObj.setString("section","hhh");
    sysObj.setString("acl_name","initial ACL name");

    mock.setEffectiveDateAndACLfromDepartment(sysObj,session);

    assertEquals("Pathology",sysObj.getString("operating_unit"));
    assertEquals("Seminis Pathology Dept Approved", sysObj.iDfACL.aclName);


  }
  public void testDepartmentIsSeedTechnologyAndSectionContainsPelleting() throws Exception {
    MockSeminisPromoteAndNotify mock = new MockSeminisPromoteAndNotify(sessionManager);
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = new MockSession("getDocbaseOwnerName");
    MockSysObject sysObj = new MockSysObject();
    sysObj.setString("r_object_id", "091234242");
    sysObj.setString("operating_unit","Seed Technology");
    sysObj.setString("section","seed tech and section is Pelleting");
    sysObj.setString("acl_name","initial ACL name");

    mock.setEffectiveDateAndACLfromDepartment(sysObj,session);

    //assertEquals("Pathology",sysObj.getString("operating_unit"));
    assertEquals("Seminis Seed Tech ACL approved", sysObj.iDfACL.aclName);


  }

  public void testDepartmentIsSeedTechnologyAndSectionContainsPriming() throws Exception {
    MockSeminisPromoteAndNotify mock = new MockSeminisPromoteAndNotify(sessionManager);
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = new MockSession("getDocbaseOwnerName");
    MockSysObject sysObj = new MockSysObject();
    sysObj.setString("r_object_id", "091234242");
    sysObj.setString("operating_unit","Seed Technology");
    sysObj.setString("section","section has priming");
    sysObj.setString("acl_name","initial ACL name");

    mock.setEffectiveDateAndACLfromDepartment(sysObj,session);

    //assertEquals("Pathology",sysObj.getString("operating_unit"));
    assertEquals("Seminis Seed Tech ACL approved", sysObj.iDfACL.aclName);


  }

  public void testDepartmentIsGeneticPurityAndSectionContainsGPG() throws Exception {
    MockSeminisPromoteAndNotify mock = new MockSeminisPromoteAndNotify(sessionManager);
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = new MockSession("getDocbaseOwnerName");
    MockSysObject sysObj = new MockSysObject();
    sysObj.setString("r_object_id", "091234242");
    sysObj.setString("operating_unit","Genetic Purity");
    sysObj.setString("section","section has gpg");
    sysObj.setString("acl_name","initial ACL name");

    mock.setEffectiveDateAndACLfromDepartment(sysObj,session);

    //assertEquals("Pathology",sysObj.getString("operating_unit"));
    assertEquals("Seminis GP and GPG ACL approved", sysObj.iDfACL.aclName);


  }

  public void testDepartmentIsGeneticPurityAndSectionContainsGPL() throws Exception {
    MockSeminisPromoteAndNotify mock = new MockSeminisPromoteAndNotify(sessionManager);
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = new MockSession("getDocbaseOwnerName");
    MockSysObject sysObj = new MockSysObject();
    sysObj.setString("r_object_id", "091234242");
    sysObj.setString("operating_unit","Genetic Purity");
    sysObj.setString("section","section has gpl");
    sysObj.setString("acl_name","initial ACL name");
    //  sysObj.setTime ("effective_date",new DfTime());

    mock.setEffectiveDateAndACLfromDepartment(sysObj,session);

    //assertEquals("Pathology",sysObj.getString("operating_unit"));
    assertEquals("Seminis GP & GPL", sysObj.iDfACL.aclName);
    //assertEquals(new DfTime(),sysObj.getTime("effective_date"));
  }
  public void testValidateArguments() throws Exception {
    testArgs = new HashMap();
    MockDfSessionManager sessionManager = new MockDfSessionManager();
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    mock = new MockSeminisPromoteAndNotify(sessionManager);
    outputStream = new ByteArrayOutputStream();
    testArgs.put(WF_SeminisPromoteAndNotify.DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
    testArgs.put(WF_SeminisPromoteAndNotify.USERID_ARG_NAME, new String[]{TESTUSERID});
    //testArgs.put(WF_SeminisPromoteAndNotify.WORKITEM_KEY, new String[]{TESTWORKITEMID});
    testArgs.put(WF_SeminisPromoteAndNotify.TICKET_KEY, new String[]{TESTTICKET});
    testArgs.put(WF_SeminisPromoteAndNotify.PACKAGE_KEY, new String[]{TESTPACKAGEKEY});

    testArgs.remove(WF_SeminisPromoteAndNotify.DOCBASE_ARG_NAME);
    testArgs.remove(WF_SeminisPromoteAndNotify.USERID_ARG_NAME);
    //testArgs.remove(WF_SeminisPromoteAndNotify.WORKITEM_KEY);
    testArgs.remove(WF_SeminisPromoteAndNotify.TICKET_KEY);
    testArgs.remove(WF_SeminisPromoteAndNotify.PACKAGE_KEY);

    mock.validateArguments(testArgs, outputStream);

    assertEquals("Error:" + LINESEPARATOR + "must supply docbase" +
        LINESEPARATOR + "must supply userid" +
        LINESEPARATOR + "must supply m_workitemId" +
        LINESEPARATOR + "must supply userPassword" +
        LINESEPARATOR,
        outputStream.toString());

    outputStream.reset();
    testArgs.put(WF_SeminisPromoteAndNotify.DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
    mock.validateArguments(testArgs, outputStream);
    assertEquals("Error:" + LINESEPARATOR + "must supply userid" +
        LINESEPARATOR + "must supply m_workitemId" +
        LINESEPARATOR + "must supply userPassword" +
        LINESEPARATOR, outputStream.toString());

    outputStream.reset();
    testArgs.put(WF_SeminisPromoteAndNotify.USERID_ARG_NAME, new String[]{TESTUSERID});
    mock.validateArguments(testArgs, outputStream);
    assertEquals("Error:" + LINESEPARATOR + "must supply m_workitemId" +
        LINESEPARATOR + "must supply userPassword" +
        LINESEPARATOR, outputStream.toString());
    outputStream.reset();
    testArgs.put(WF_SeminisPromoteAndNotify.PACKAGE_KEY, new String[]{TESTPACKAGEKEY});
    mock.validateArguments(testArgs, outputStream);
    assertEquals("Error:" + LINESEPARATOR + "must supply userPassword" +
        LINESEPARATOR, outputStream.toString());
    outputStream.reset();
    testArgs.put(WF_SeminisPromoteAndNotify.TICKET_KEY, new String[]{TESTTICKET});

    assertTrue(mock.validateArguments(testArgs, outputStream));
  }
  public void testGotSession() throws Exception {
    mock = new MockSeminisPromoteAndNotify(sessionManager);
    IDfSession userSession = mock.getSession(TESTDOCBASE, TESTUSERID, TESTTICKET);
    assertNotNull(userSession);
    assertEquals(TESTUSERID, userSession.getLoginUserName());
    assertEquals(TESTUSERID, userSession.getLoginInfo().getUser());
    assertEquals("testticket", userSession.getLoginInfo().getPassword());
  }
  public void testExecuteWithValidArguments() throws Exception {
    testArgs = new HashMap();
    MockDfSessionManager sessionManager = new MockDfSessionManager();
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = (MockSession) sessionManager.getSession(TESTDOCBASE);
    mock = new MockSeminisPromoteAndNotify(sessionManager);
    outputStream = new ByteArrayOutputStream();
    testArgs.put(WF_SeminisPromoteAndNotify.DOCBASE_ARG_NAME, new String[]{TESTDOCBASE});
    testArgs.put(WF_SeminisPromoteAndNotify.USERID_ARG_NAME, new String[]{TESTUSERID});
    testArgs.put(WF_SeminisPromoteAndNotify.PACKAGE_KEY, new String[]{TESTPACKAGEKEY});
    //testArgs.put(WF_SeminisPromoteAndNotify.WORKITEM_KEY, new String[]{TESTWORKITEMID});
    testArgs.put(WF_SeminisPromoteAndNotify.TICKET_KEY, new String[]{TESTTICKET});
    addWorkItemObject(session, TESTDOCBASE);
    addSysObject(session, TESTDOCBASE);

    mock.execute(testArgs, outputStream);

    MockSysObject sysObject = (MockSysObject) session.getObjectByQualification("seminis_doc where r_object_id = '965654563'");
    assertEquals("1", String.valueOf(sysObject.saveCounter));
    assertTrue(sysObject.wasSaveCalled);
    assertTrue(((MockSession) session).wasReleaseCalled);
    assertEquals(new DfTime(),sysObject.getTime("effective_date"));
    assertEquals("success" + LINESEPARATOR + "", outputStream.toString());
  }
  protected void addWorkItemObject(MockSession session, String testdocbase) throws DfServiceException, DfIdentityException,
      DfAuthenticationException {
    MockWorkitem workItemObject = new MockWorkitem();
    workItemObject.setResults(setupResults());
    session.addObject(workItemObject,"testpackageid");
  }
  protected void addSysObject(MockSession session, String testdocbase) throws DfException, DfIdentityException,
      DfAuthenticationException {
    MockSysObject sysObject = new MockSysObject();
    sysObject.setString("r_object_id","965654563");
    sysObject.setString("object_name","Test Doc");
    sysObject.setString("r_current_state","0");
    sysObject.setString("i_folder_id","0b001");
    sysObject.setString("object_type","seminis_doc");
    sysObject.setString("version_comments","Testing for version comments");
    sysObject.setString("operating_unit","Pathology");
    sysObject.setString("section","Test section");
    sysObject.setString("notify_users","Test user");
    sysObject.setString("notify_message","Test message");

    session.addObject(sysObject,"965654563");
    session.addObject(sysObject,"seminis_doc where r_object_id = '965654563'");
  }

  private List setupResults() {
    Map row1 = new HashMap();
    List objectIds1 = new ArrayList();
    objectIds1.add(0, "965654563");
    row1.put("r_component_id", objectIds1);
    List results = new ArrayList();
    results.add(row1);
    return results;
  }

}