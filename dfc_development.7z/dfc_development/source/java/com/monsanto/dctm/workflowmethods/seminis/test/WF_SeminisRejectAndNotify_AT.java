/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.seminis.test;

import com.documentum.fc.common.*;
import com.documentum.fc.client.*;
import com.monsanto.dctm.utils.DFCSessionUtils;
import junit.framework.TestCase;

import java.util.Calendar;

/**
 * Filename:    $RCSfile: WF_SeminisRejectAndNotify_AT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-02-18 20:12:04 $
 *
 * @author vvgosw
 * @version $Revision: 1.2 $
 */
public class WF_SeminisRejectAndNotify_AT extends TestCase {
 private static final String TESTDOCBASE = "stltst03";
  private IDfId m_processId = null;
  private IDfId m_activityId = null;
  private String m_strPortName = null;
  //Change credentials of dmadmin
  private String userID = "devl01";
  private String pass = "devl01";
  private String objectName = "Test Seminis From AT load test";

  public void testCreateSession() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, userID, pass);
    IDfSession session = null;
    try {
      session = sessionManager.getSession(TESTDOCBASE);
      assertNotNull(session);
    } catch (DfServiceException e) {
      e.printStackTrace();
    } finally {
      sessionManager.release(session);
    }
  }
  public void testRejectNotifyEmails() throws Exception {

    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, userID, pass);
    IDfSession session = null;
    /*IDfCollection workflows = null;
    IDfWorkflow workflowObject = null;*/
    IDfSysObject sysObject = null;
    Object dummyObj = new Object();

    objectName ="RUNAT00CDFIX0007Seminis.txt";

    try {
      session = sessionManager.getSession(TESTDOCBASE);
      sysObject = (IDfSysObject) session.newObject("seminis_doc");
      sysObject = setObjectInfo(session);
      sysObject.setRepeatingString("notify_users",0,"Goswami Vishal");
      sysObject.setRepeatingString("notify_users",1,"devl01");
      sysObject.setRepeatingString("notify_users",2,"Kaur Ravneet");

      sysObject.save();

      DfLogger.debug(this,"Object ID " + sysObject.getString("r_object_id"),null,null);
      assertEquals("nulldate",sysObject.getString("effective_date"));

      setProcessId("Seminis Approval Worklfow",session);
      IDfId workflowId = startWorkflow(sysObject,session);
      synchronized (dummyObj) {
        completeApprovalTasks(session,workflowId);
        assertEquals("Draft", sysObject.getRepeatingString("r_version_label",2));
        assertEquals("nulldate",sysObject.getString("effective_date"));
        dummyObj.wait(50000);
        sysObject = (IDfSysObject) session.getObjectByQualification("seminis_doc where object_name = '" + objectName + "'");
        assertEquals("Goswami Vishal",sysObject.getRepeatingString("notify_users",0));
        assertEquals("devl01",sysObject.getRepeatingString("notify_users",1));
        assertEquals("Kaur Ravneet",sysObject.getRepeatingString("notify_users",2));
        assertObjectInfoAfterPromote(session,sysObject);
      }
    } catch (DfServiceException e) {
      e.printStackTrace();
    } finally {
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }
  public void testCreateSessionAndValidObject() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, userID, pass);
    IDfSession session = null;
    IDfCollection workflows = null;
    IDfWorkflow workflowObject = null;
    IDfSysObject sysObject = null;

    try {
      session = sessionManager.getSession(TESTDOCBASE);
      sysObject = (IDfSysObject) session.newObject("seminis_doc");
      sysObject.setString("object_name","Test Seminis From AT");

      assertNotNull(session);
      assertNotNull(sysObject);
      assertEquals("Test Seminis From AT", sysObject.getObjectName());
    } catch (DfServiceException e) {
      e.printStackTrace();
    } finally {
      if (sysObject != null) {
        workflows = sysObject.getWorkflows("","");
        if (workflows != null && workflows.next()) {
          workflowObject.abort();
          workflowObject.destroy();
          workflows.close();
        }
        sysObject.destroy();
      }
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }
  public void testCreateSessionAndValidObjectWithRequiredValues() throws Exception {
    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, userID, pass);
    IDfSession session = null;
    IDfCollection workflows = null;
    IDfWorkflow workflowObject = null;
    IDfSysObject sysObject = null;

    try {
      session = sessionManager.getSession(TESTDOCBASE);
      sysObject = setObjectInfo(session);

      sysObject.save();

      DfLogger.debug(this,"Object ID " + sysObject.getString("r_object_id"),null,null);
      assertNotNull(session);
      assertNotNull(sysObject);
      assertObjectInfo(sysObject);

    } catch (DfServiceException e) {
      e.printStackTrace();
    } finally {
      /*if (sysObject != null) {
        workflows = sysObject.getWorkflows("","");
        if (workflows != null && workflows.next()) {
          workflowObject.abort();
          workflowObject.destroy();
          workflows.close();
        }
        sysObject.destroy();
      }*/
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }
  public void testCreateSessionAndValidObjectWithRequiredValuesWithWorkflow() throws Exception {

    IDfSessionManager sessionManager = DFCSessionUtils.createSessionManager(TESTDOCBASE, userID, pass);
    IDfSession session = null;
    /*IDfCollection workflows = null;
    IDfWorkflow workflowObject = null;*/
    IDfSysObject sysObject = null;
    Object dummyObj = new Object();


    try {
      session = sessionManager.getSession(TESTDOCBASE);
      sysObject = setObjectInfo(session);

      sysObject.save();

      DfLogger.debug(this,"Object ID " + sysObject.getString("r_object_id"),null,null);
      assertEquals("nulldate",sysObject.getString("effective_date"));

      setProcessId("Seminis Approval Worklfow",session);
      IDfId workflowId = startWorkflow(sysObject,session);
      synchronized (dummyObj) {

        completeApprovalTasks(session,workflowId);

        assertEquals("Draft", sysObject.getRepeatingString("r_version_label",2));
        assertEquals("nulldate",sysObject.getString("effective_date"));

        dummyObj.wait(50000);
        dummyObj.wait(50000);

        sysObject = (IDfSysObject) session.getObjectByQualification("seminis_doc where object_name = '" + objectName + "'");

        assertObjectInfoAfterPromote(session,sysObject);
        assertObjectInfo(sysObject);
      }
    } catch (DfServiceException e) {
      e.printStackTrace();
    } finally {
      /*if (sysObject != null) {
        workflows = sysObject.getWorkflows("","");
//Workflow completes so we don't need a destroy
        if (workflows != null && workflows.next()) {
//          workflowObject.abort();
//          workflowObject.destroy();
//          workflows.close();
        }

            //sysObject.destroy();
      }*/
      if (session != null) {
        sessionManager.release(session);
      }
    }
  }


  private void completeTask(IDfSession session, IDfWorkflow workflowObject) throws Exception{
    //System.out.println("SeminisNotification_AT.setPerformerForFirstTask");
//    workflowObject.resumeAll();
    //System.out.println("workflowObject = " + workflowObject.getObjectId().toString());
    IDfWorkitem workItemObject =
        (IDfWorkitem) session.getObjectByQualification("dmi_workitem where r_workflow_id = '" +
            workflowObject.getObjectId().toString() +"' and r_runtime_state != 2 ");

    //System.out.println("workItemObject.getObjectId().toString() = " + workItemObject.getObjectId().toString());
    //System.out.println("workItemObject.getRuntimeState() = " + workItemObject.getRuntimeState());
    if ((workItemObject.getRuntimeState() != 1) && (workItemObject.getRuntimeState() != 2))

      workItemObject.acquire();

    //System.out.println("workItemObject.getPerformerName() = " + workItemObject.getPerformerName());
    IDfList activityList = new DfList();
    IDfActivity activity = workItemObject.getActivity();
    //System.out.println("activity.getObjectName() = " + activity.getObjectName());
    IDfList listObj= workItemObject.getForwardActivities();
    if (activity.getObjectName().equalsIgnoreCase("Approve") || activity.getObjectName().equalsIgnoreCase("Edit") ){
      //System.out.println("setting next activity");
      workItemObject.setOutputByActivities(listObj);
    }
    workItemObject.complete();

  }

  private void rejectTask(IDfSession session, IDfWorkflow workflowObject) throws Exception{
    //System.out.println("SeminisNotification_AT.setPerformerForFirstTask");
//    workflowObject.resumeAll();
    //System.out.println("workflowObject = " + workflowObject.getObjectId().toString());
    IDfWorkitem workItemObject =
        (IDfWorkitem) session.getObjectByQualification("dmi_workitem where r_workflow_id = '" +
            workflowObject.getObjectId().toString() +"' and r_runtime_state != 2 ");

    //System.out.println("workItemObject.getObjectId().toString() = " + workItemObject.getObjectId().toString());
    //System.out.println("workItemObject.getRuntimeState() = " + workItemObject.getRuntimeState());
    if ((workItemObject.getRuntimeState() != 1) && (workItemObject.getRuntimeState() != 2))

      workItemObject.acquire();

    //System.out.println("workItemObject.getPerformerName() = " + workItemObject.getPerformerName());
    IDfList activityList = new DfList();
    IDfActivity activity = workItemObject.getActivity();
    System.out.println("activity.getObjectName() = " + activity.getObjectName());
    IDfList listObj= workItemObject.getRejectActivities();
    if (activity.getObjectName().equalsIgnoreCase("Approve")){
      //System.out.println("setting next activity");
      workItemObject.setOutputByActivities(listObj);
    }
    workItemObject.complete();

  }

  private void completeApprovalTasks(IDfSession session,IDfId workflowID) throws Exception {
    //TODO
    // need to make the test better by getting all the workitems maybe rather than tasks as performers can change
    IDfCollection workflows = null;
    IDfWorkflow workflowObject = null;
    IDfSysObject sysObject = null;
    IDfId workflowId = null;
    Object dummyObj = new Object();
    sysObject = (IDfSysObject) session.getObjectByQualification("seminis_doc where object_name = '" + objectName + "'");
    assertNotNull(sysObject);
    //assertObjectInfo(sysObject);
    if (!workflowID.isNull()) {

      //workflowId = (IDfId) workflows.getId("r_workflow_id");
      System.out.println("workflowId = " + workflowID);
      workflowObject = (IDfWorkflow) session.getObject(workflowID);
      completeTask(session,workflowObject);
      System.out.println("Completed Start task");
      synchronized (dummyObj) {
        rejectTask(session,workflowObject);
        dummyObj.wait(20000);
        System.out.println("Rejected Approve task");
        completeTask(session,workflowObject);
        System.out.println("Completed Edit task");
        completeTask(session,workflowObject);
        System.out.println("Completed Approve task");
        completeTask(session,workflowObject);
        System.out.println("Completed Notify task");
      }
      //workflowObject.haltAll();
    }
  }

  private void assertObjectInfo(IDfSysObject sysObject) throws DfException {
    assertEquals(objectName, sysObject.getObjectName());
    assertEquals("test subject", sysObject.getString("subject"));
    assertEquals("test title", sysObject.getString("title"));
    assertEquals("kk", sysObject.getRepeatingString("keywords",0));
    assertEquals("usha", sysObject.getRepeatingString("authors",0));
    assertEquals("Manual", sysObject.getString("a_document_class"));
    assertEquals("Testdoc123", sysObject.getString("document_number"));
    assertEquals("test revision", sysObject.getString("revision"));
    assertEquals("7/10/2008 00:00:00", sysObject.getString("submitted_date"));
    assertEquals("ASIA", sysObject.getString("region"));
    assertEquals("Thailand", sysObject.getString("country"));
    assertEquals("Adana, Turkey", sysObject.getString("site_or_plant"));

  }
  private void assertObjectInfoAfterPromote(IDfSession session, IDfSysObject sysObject) throws DfException {

    assertEquals("Effective", sysObject.getRepeatingString("r_version_label",2));
    assertEquals("Seminis GP & GPL", sysObject.getACLName());
    //For Dev
    assertEquals("46001abe801c2b77", sysObject.getString("r_policy_id"));
    //Policy Id for Test
    //assertEquals("460012ab800543a1", sysObject.getString("r_policy_id"));
    assertNotNull(sysObject.getString("effective_date"));
   }

  private IDfSysObject setObjectInfo(IDfSession session) throws DfException {
    IDfSysObject sysObject;
    //Changes to have unique object name
    Calendar c1 = Calendar.getInstance();
    objectName = objectName + c1.getTime().toString();
    sysObject = (IDfSysObject) session.newObject("seminis_doc");
    sysObject.setString("object_name",objectName);
    sysObject.setString("subject","test subject");
    sysObject.setString("title","test title");
    sysObject.setRepeatingString("keywords",0,"kk");
    sysObject.setRepeatingString("authors",0,"usha");
    sysObject.setString("a_document_class","Manual");
    sysObject.setString("document_number","Testdoc123");
    sysObject.setString("section","section contains gpl");
    sysObject.setString("revision","test revision");
    sysObject.setString("submitted_date","7/10/2008 00:00:00");
    sysObject.setString("region","ASIA");
    sysObject.setString("country","Thailand");
    sysObject.setString("site_or_plant","Adana, Turkey");
    sysObject.setString("operating_unit","Genetic Purity");
    return sysObject;
  }

  private IDfId startWorkflow(IDfSysObject sysObject, IDfSession session) throws DfException {
    //System.out.println("BreedingTechnology.startWorkflow");
    IDfId documentId = sysObject.getId("r_object_id");
    String activityName = null;
    String packageName = null;
    String portName = null;
    try {
      IDfId processId = getProcessId();
      if (processId == null) {
        DfLogger.warn(this, "No valid processes to start", null, null);
        return null;
      }
      IDfWorkflowBuilder wfBuilder = session.newWorkflowBuilder(processId);
      IDfWorkflow workflow = getWorkflowInfo(wfBuilder);
      setActivityIfNull(wfBuilder);

      IDfActivity activity = (IDfActivity) session.getObject(getActivityId());
      activityName = activity.getString("object_name");

      if (getPortName() == null) //choose first input port by default
      {
        for (int cntrPort = 0; cntrPort < activity.getPortCount(); cntrPort++) {
          if (activity.getPortType(cntrPort).equals("INPUT")) {
            portName = activity.getPortName(cntrPort);
            packageName = activity.getPackageName(cntrPort);
            break;
          }
        }
      } else {
        portName = getPortName();
        for (int i = 0; i < activity.getPortCount(); i++) {
          if (activity.getPortName(i).equals(portName)) {
            packageName = activity.getPackageName(i);
            break;
          }
        }
      }

      String strObjectType = sysObject.getTypeName();
      DfList list = new DfList();
      list.append(documentId);
      workflow.addPackage(
          activityName,
          portName,
          packageName,
          strObjectType,
          "",
          false,
          list);
      System.out.println("workflow.getObjectName() = " + workflow.getObjectName());
      System.out.println("workflow.getObjectId() = " + workflow.getObjectId());
      return workflow.getObjectId();
    } catch (DfException dfe) {
      dfe.printStackTrace();
      throw dfe;
    }
  } //startWorkflow

  protected void setProcessId(String processName, IDfSession session) throws DfException {
    IDfCollection Workflows = null;
    try {
      Workflows = session.getRunnableProcesses("");
      IDfId processID = null;
      while (Workflows.next()) {
        IDfTypedObject Next = Workflows.getTypedObject();
        String workflowName = Next.getString("object_name");
        if (workflowName.equals(processName) || workflowName.trim() == processName.trim()) {
          processID = Next.getId("r_object_id");
          m_processId = processID;
          break;
        }
      }
    } catch (DfException dfe) {
      throw dfe;
    }finally{
      if(Workflows != null){
        Workflows.close();
      }
    }
  }
  private IDfId getProcessId() {
    return m_processId;
  }
  private void setActivityIfNull(IDfWorkflowBuilder wfBuilder) throws DfException {
    if (getActivityId() == null) //choose first start activity by default
    {
      IDfList activityIds = wfBuilder.getStartActivityIds();
      setActivityId((IDfId) activityIds.get(0));
    }
  }
  private IDfWorkflow getWorkflowInfo(IDfWorkflowBuilder wfBuilder) throws DfException {
    wfBuilder.initWorkflow();
    wfBuilder.runWorkflow();
    return wfBuilder.getWorkflow();
  }
  public IDfId getActivityId() {
    return m_activityId;
  }
  public void setActivityId(IDfId activityId) {
    m_activityId = activityId;
  }
  public String getPortName() {
    return m_strPortName;
  }
  public WF_SeminisRejectAndNotify_AT(String name) {
    super(name);
  }
}