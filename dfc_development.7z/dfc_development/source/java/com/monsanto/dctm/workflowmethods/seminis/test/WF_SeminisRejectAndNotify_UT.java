/*
 Copyright:  Copyright � 2008 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/
package com.monsanto.dctm.workflowmethods.seminis.test;

import com.monsanto.dctm.test.MockDfSessionManager;
import com.monsanto.dctm.test.MockDfGroup;
import com.monsanto.dctm.test.MockSysObject;
import com.monsanto.dctm.workflowmethods.seminis.WF_SeminisPromoteAndNotify;
import com.monsanto.dctm.workflowmethods.seminis.WF_SeminisRejectAndNotify;
import com.documentum.fc.client.MockSession;
import com.documentum.fc.client.IDfGroup;
import com.documentum.fc.common.DfLoginInfo;

import java.util.Map;
import java.io.ByteArrayOutputStream;

import junit.framework.TestCase;

/**
 * Filename:    $RCSfile: WF_SeminisRejectAndNotify_UT.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: ussing $    	 On:	$Date: 2009-02-18 20:12:04 $
 *
 * @author vvgosw
 * @version $Revision: 1.2 $
 */
public class WF_SeminisRejectAndNotify_UT extends TestCase {
  private MockDfSessionManager sessionManager;
  public MockSession session;
  private static final String TESTDOCBASE = "testdocbase";
  private static final String TESTWORKITEMID = "testworkitemid";
  private static final String TESTUSERID = "testuserid";
  private static final String TESTTICKET = "testticket";
  private Map testArgs;
  private MockSeminisPromoteAndNotify mock;
  private ByteArrayOutputStream outputStream;
  private static final String LINESEPARATOR = System.getProperty("line.separator");
  private static final String TESTPACKAGEKEY = "testpackageid";

  protected void setUp(){
    sessionManager = new MockDfSessionManager();
  }
  public void testCreate() throws Exception
  {
    WF_SeminisRejectAndNotify notify = new WF_SeminisRejectAndNotify();
    assertNotNull(notify);

  }
  public void testNotifyEmailsWithAdmin() throws Exception
  {
    MockSeminisRejectAndNotify mock = new MockSeminisRejectAndNotify(sessionManager);
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = new MockSession("getDocbaseOwnerName");
    session.setLoginUserName("devl01");
    IDfGroup grpReject = new MockDfGroup();
    IDfGroup grpWfAdmins = new MockDfGroup();
    grpReject.setGroupName("seminis_generic_reject_notify");
    grpWfAdmins.setGroupName("seminis_workflow_admin");
    grpWfAdmins.addUser("devl01");
    grpWfAdmins.addUser("devl02");
    grpWfAdmins.addUser("devl03");
    grpWfAdmins.addUser("devl04");
    grpReject.addUser("RejectUser1");
    session.addGroup(grpReject);
    session.addGroup(grpWfAdmins);
    MockSysObject sysObj = new MockSysObject();
    sysObj.setString("r_object_id", "091234242");
    sysObj.setString("object_name","Seminis Test Doc UT1000");
    sysObj.setString("operating_unit","Genetic Purity");
    sysObj.setString("section","section has gpg");
    sysObj.setString("acl_name","initial ACL name");
    sysObj.setRepeatingString("notify_users",0,"devl01");
    sysObj.setRepeatingString("notify_users",1,"devl02");
    sysObj.setRepeatingString("notify_users",2,"devl03");
    sysObj.setString("notify_message","Notify Message");
    session.addObject(sysObj,"091234243");
    session.addObject(sysObj,"Seminis Test Doc UT1001");

    mock.sendRejectNotice(sysObj,session);
    assertEquals("seminis_generic_reject_notify", sysObj.targetObjName);
    assertEquals(1, MockSysObject.queueCount);
    assertEquals(3, grpReject.getUsersNamesCount());

  }
  public void testNotifyEmailsWithoutAdmin() throws Exception
  {
    MockSeminisRejectAndNotify mock = new MockSeminisRejectAndNotify(sessionManager);
    DfLoginInfo loginInfo = new DfLoginInfo();
    loginInfo.setUser(TESTUSERID);
    loginInfo.setPassword(TESTTICKET);
    sessionManager.setIdentity(TESTDOCBASE, loginInfo);
    MockSession session = new MockSession("getDocbaseOwnerName");
    session.setLoginUserName("AdminUser");
    IDfGroup grpReject = new MockDfGroup();
    IDfGroup grpWfAdmins = new MockDfGroup();
    grpReject.setGroupName("seminis_generic_reject_notify");
    grpWfAdmins.setGroupName("seminis_workflow_admin");
    grpWfAdmins.addUser("devl01");
    grpWfAdmins.addUser("devl02");
    grpWfAdmins.addUser("devl03");
    grpWfAdmins.addUser("devl04");
    grpReject.addUser("RejectUser1");
    session.addGroup(grpReject);
    session.addGroup(grpWfAdmins);
    MockSysObject sysObj = new MockSysObject();
    sysObj.setString("r_object_id", "091234242");
    sysObj.setString("object_name","Seminis Test Doc UT1000");
    sysObj.setString("operating_unit","Genetic Purity");
    sysObj.setString("section","section has gpg");
    sysObj.setString("acl_name","initial ACL name");
    sysObj.setRepeatingString("notify_users",0,"devl01");
    sysObj.setRepeatingString("notify_users",1,"devl02");
    sysObj.setRepeatingString("notify_users",2,"devl03");
    sysObj.setString("notify_message","Notify Message");
    session.addObject(sysObj,"091234243");
    session.addObject(sysObj,"Seminis Test Doc UT1001");

    mock.sendRejectNotice(sysObj,session);
    assertEquals("seminis_generic_reject_notify", sysObj.targetObjName);
    assertEquals(1, MockSysObject.queueCount);
    assertEquals(4, grpReject.getUsersNamesCount());

  }
}