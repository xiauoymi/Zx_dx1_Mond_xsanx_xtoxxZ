package com.monsanto.dctm.workflowmethods.suppliercontracts;
/*
 * WF_SupplierContractsAutoInit.java
 *
 * Created on March 20, 2006, 11:43 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
/**
 *
 * @author tsvedan
 */
public class WF_SupplierContractsAutoInit
        implements IDmMethod {
    
    /** Creates a new instance of WF_SupplierContractsAutoInit */
    public WF_SupplierContractsAutoInit() {
        m_sessionMgr = null;
        m_docbase = null;
        m_userName = null;
        m_workitemId = null;
        m_ticket = null;
    }
    
    public void execute(Map params, OutputStream ostream)
    throws Exception {
        IDfSessionManager sessionManager;
        IDfSession session = null;
        Exception exception;
        initWorkflowParams(params);
        sessionManager = login();
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            IDfWorkflow workflow = (IDfWorkflow)session.getObject(workitem.getWorkflowId());
            if(workitem.getRuntimeState() == 0)
                workitem.acquire();
            IDfCollection pkgColl = null;
            System.out.println("Getting packages, setting performers..");
            pkgColl = workitem.getPackages("");
            if(pkgColl != null) {
                while(pkgColl.next()) {
                    String str_docId = pkgColl.getString("r_component_id");
                    System.out.println(str_docId.toString());
                    int docCount = pkgColl.getValueCount("r_component_id");
                    for (int i = 0; i < docCount; i++) {
                        m_docId = pkgColl.getRepeatingId("r_component_id", i);
                        if(m_docId != null && !m_docId.isNull()) {
                            setPerformers(workflow, session);
                        }
                    }
                }
                pkgColl.close();
            }
            workitem.complete();
        } catch(DfException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            if(session != null)
                sessionManager.release(session);
        }
    } //execute
    
    protected void initWorkflowParams(Map params) {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do
        {
            if(!iter.hasNext())
                break;
            String key = (String)iter.next();
            if(key != null && key.length() != 0) {
                String value[] = (String[])params.get(key);
                if(key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else
                    if(key.equalsIgnoreCase("docbase_name"))
                        m_docbase = value.length <= 0 ? "" : value[0];
                    else
                        if(key.equalsIgnoreCase("workitemId"))
                            m_workitemId = value.length <= 0 ? "" : value[0];
                        else
                            if(key.equalsIgnoreCase("packageId"))
                                m_workitemId = value.length <= 0 ? "" : value[0];
                            else
                                if(key.equalsIgnoreCase("ticket"))
                                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while(true);
    } //initWorkflowParams
    
    protected IDfSessionManager login()
    throws DfException {
        if(m_docbase == null || m_userName == null || m_ticket == null)
            return null;
        IDfClient dfClient = DfClient.getLocalClient();
        if(dfClient != null) {
            IDfLoginInfo li = new DfLoginInfo();
            li.setUser(m_userName);
            li.setPassword(m_ticket);
            li.setDomain(null);
            IDfSessionManager sessionMgr = dfClient.newSessionManager();
            sessionMgr.setIdentity(m_docbase, li);
            return sessionMgr;
        } else {
            return null;
        }
    } //login
    
    protected void setPerformers(IDfWorkflow workflow, IDfSession session) throws DfException {
        IDfList list = new DfList();
        String user = getAcceptActPerformerName(workflow.getObjectId().getId(), session);
        list.appendString(user);
        workflow.setPerformers("Termination Request Review", list);
        workflow.setPerformers("Submit Letter to Vendor", list);
        workflow.setPerformers("File Termination Letter", list);
        workflow.setPerformers("Review (Edited)", list);
        workflow.setPerformers("Review", list);
        workflow.setPerformers("Procurement Final Review", list);
        workflow.setPerformers("Contract Negotiations", list);
        workflow.setPerformers("Obtain Procurement Signatures", list);
//        workflow.setPerformers("Scan Signed Contract", list);
        System.out.println("Procurement user for subsequent activities = " + user);
    }
    
    protected String getAcceptActPerformerName(String wfId, IDfSession session) throws DfException {
        StringBuffer strbuff = new StringBuffer("select r_performer_name from dmi_workitem where r_workflow_id ='");
        strbuff.append(wfId).append("' and r_act_def_id in (select r_object_id from ");
        strbuff.append("dm_activity where object_name='Claim Ownership of Contract')");
        IDfQuery query = new DfQuery();
        query.setDQL(strbuff.toString());
        String user = null;
        IDfCollection coll = query.execute(session, IDfQuery.DF_READ_QUERY);
        if(coll != null){
            if(coll.next())
                user = coll.getString("r_performer_name");
            coll.close();
        }
        return user;
    }
    
    protected IDfSessionManager m_sessionMgr;
    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    protected IDfId m_docId;
    
}
