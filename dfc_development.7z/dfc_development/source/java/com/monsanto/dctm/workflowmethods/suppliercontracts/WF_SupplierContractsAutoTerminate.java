package com.monsanto.dctm.workflowmethods.suppliercontracts;
/*
 * WF_SupplierContractsAutoTerminate.java
 *
 * Created on March 20, 2006, 11:47 AM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
/**
 *
 * @author tsvedan
 */
public class WF_SupplierContractsAutoTerminate
        implements IDmMethod {
    
    /** Creates a new instance of WF_SupplierContractsAutoTerminate */
    public WF_SupplierContractsAutoTerminate() {
        m_sessionMgr = null;
        m_docbase = null;
        m_userName = null;
        m_workitemId = null;
        m_ticket = null;
    }
    
    public void execute(Map params, OutputStream ostream)
    throws Exception {
        IDfSessionManager sessionManager;
        IDfSession session = null;
        Exception exception;
        initWorkflowParams(params);
        sessionManager = login();
        try {
            IDfId workitemID = new DfId(m_workitemId);
            session = sessionManager.getSession(m_docbase);
            IDfWorkitem workitem = (IDfWorkitem)session.getObject(workitemID);
            IDfWorkflow workflow = (IDfWorkflow)session.getObject(workitem.getWorkflowId());
            if(workitem.getRuntimeState() == 0)
                workitem.acquire();
            IDfCollection pkgColl = null;
            System.out.println("Getting packages, sending termination notification..");
            pkgColl = workitem.getPackages("");
            if(pkgColl != null) {
                while(pkgColl.next()) {
                    String str_docId = pkgColl.getString("r_component_id");
                    System.out.println(str_docId.toString());
                    int docCount = pkgColl.getValueCount("r_component_id");
                    for (int i = 0; i < docCount; i++) {
                        m_docId = pkgColl.getRepeatingId("r_component_id", i);
                        if(m_docId != null && !m_docId.isNull()) {
                            IDfId sysobjID = new DfId(str_docId);
                            IDfSysObject doc = (IDfSysObject)session.getObject(sysobjID);
                            sendNotification(doc, workflow.getSupervisorName());
                            doc.setString("contract_status", "Terminated");
                            doc.save();
                        }
                    }
                }
                pkgColl.close();
            }
            workitem.complete();
        } catch(DfException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
            throw e;
        } finally {
            if(session != null)
                sessionManager.release(session);
        }
    } //execute
    
    protected void initWorkflowParams(Map params) {
        Set keys = params.keySet();
        Iterator iter = keys.iterator();
        do
        {
            if(!iter.hasNext())
                break;
            String key = (String)iter.next();
            if(key != null && key.length() != 0) {
                String value[] = (String[])params.get(key);
                if(key.equalsIgnoreCase("user"))
                    m_userName = value.length <= 0 ? "" : value[0];
                else
                    if(key.equalsIgnoreCase("docbase_name"))
                        m_docbase = value.length <= 0 ? "" : value[0];
                    else
                        if(key.equalsIgnoreCase("workitemId"))
                            m_workitemId = value.length <= 0 ? "" : value[0];
                        else
                            if(key.equalsIgnoreCase("packageId"))
                                m_workitemId = value.length <= 0 ? "" : value[0];
                            else
                                if(key.equalsIgnoreCase("ticket"))
                                    m_ticket = value.length <= 0 ? "" : value[0];
            }
        } while(true);
    } //initWorkflowParams
    
    protected IDfSessionManager login()
    throws DfException {
        if(m_docbase == null || m_userName == null || m_ticket == null)
            return null;
        IDfClient dfClient = DfClient.getLocalClient();
        if(dfClient != null) {
            IDfLoginInfo li = new DfLoginInfo();
            li.setUser(m_userName);
            li.setPassword(m_ticket);
            li.setDomain(null);
            IDfSessionManager sessionMgr = dfClient.newSessionManager();
            sessionMgr.setIdentity(m_docbase, li);
            return sessionMgr;
        } else {
            return null;
        }
    } //login
    
    protected void sendNotification(IDfSysObject sysobj, String supervisor) throws DfException {
        sysobj.queue(
                supervisor, 
                "Contract Terminated", 
                10, 
                true, 
                null, 
                "The attached contract has been terminated."
                );
    }
    
    protected IDfSessionManager m_sessionMgr;
    protected String m_docbase;
    protected String m_userName;
    protected String m_workitemId;
    protected String m_ticket;
    protected IDfId m_docId;
    
}
