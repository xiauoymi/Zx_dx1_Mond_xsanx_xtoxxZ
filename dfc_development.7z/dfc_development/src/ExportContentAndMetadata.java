/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfAttr;
import com.documentum.fc.common.IDfLoginInfo;

import java.io.*;

/**
 * Filename:    $RCSfile: ExportContentAndMetadata.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $    	 On:	$Date: 2006-10-14 00:59:30 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class ExportContentAndMetadata {

  private IDfSysObject sysobj = null;
  private IDfClientX clientX = null;
  private IDfSession sess = null;
  private IDfSessionManager sMgr = null;

  private File dir = null;
  private String attrFile = null;
  private String query = null;
  private StringBuffer strbuff = null;


  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    try {
      if (args.length == 6) {
        ExportContentAndMetadata ecm = new ExportContentAndMetadata();
        ecm.login(args[0], args[1], args[2]);
        ecm.init(args[3], args[4], args[5]);
        ecm.export();
      } else {
        System.err.println("Please enter the arguments.. Docbase Username Password Query Directory Filename");
        System.exit(1);
      }
    } catch (Exception e) {
      System.out.println("<<<<<<<<< An error has occurred");
      e.printStackTrace();
    }
  }

  private void export() throws Exception {
    IDfCollection coll = execute(query);
    StringBuffer header = new StringBuffer(2000);
    header.append("file_location").append("\t");
    BufferedWriter out = new BufferedWriter(new FileWriter(attrFile));
    while (coll.next()) {
      strbuff = new StringBuffer(2000);
      sysobj = (IDfSysObject) sess.getObject(coll.getId("r_object_id"));
      System.out.println("Exporting... " + sysobj.getObjectName());
      strbuff.append(getExportedFileName(sysobj)).append("\t");
      for (int i = 0; i < sysobj.getAttrCount(); i++) {
        IDfAttr attr = (IDfAttr) sysobj.getAttr(i);
        if (header != null) header.append(attr.getName());
        if (!attr.isRepeating())
          strbuff.append(sysobj.getValue(attr.getName()).asString());
        else
          appendRepeating(sysobj, attr);
        if (i < sysobj.getAttrCount() - 1) {
          if (header != null) header.append("\t");
          strbuff.append("\t");
        }
      }
      if (header != null) {
        out.write(header.toString());
        out.newLine();
        header = null;
      }
      out.write(strbuff.toString());
      out.newLine();
      out.flush();
    }
    out.close();
  }

  private String getExportedFileName(IDfSysObject sysobj) throws Exception {
    File file = getFile();
    FileOutputStream fos = new FileOutputStream(file);
    ByteArrayInputStream byteArrayInputStream = sysobj.getContent();
    for (int data = byteArrayInputStream.read(); data != -1; data = byteArrayInputStream.read()) {
      char ch = (char) data;
      fos.write(ch);
    }
    fos.flush();
    fos.close();
    return file.getPath();
  }

  private File getFile() throws Exception {
    String objName = sysobj.getObjectName().trim();
    IDfFormat format = (IDfFormat) sess.getObjectByQualification(
        "dm_format where name='" + sysobj.getContentType() + "'");
    String ext = "." + format.getDOSExtension();
    if (objName.endsWith(ext))
      objName = objName.substring(0, objName.lastIndexOf("."));
    File file = new File(dir.getPath() + File.separator + objName + ext);
    for (int i = 1; file.exists(); i++) {
      StringBuffer buffer = new StringBuffer();
      buffer.append(dir.getPath()).append(File.separator);
      buffer.append(objName).append("_").append(i).append(ext);
      file = new File(buffer.toString());
    }
    return file;
  }

  private void appendRepeating(IDfSysObject sysobj, IDfAttr attr) throws DfException {
    for (int i = 0; i < sysobj.getValueCount(attr.getName()); i++) {
      strbuff.append(sysobj.getRepeatingValue(attr.getName(), i).asString());
      if (i < sysobj.getValueCount(attr.getName()) - 1)
        strbuff.append(";#");
    }
  }

  private void init(String query, String dirName, String attrFile) {
    dir = new File(dirName);
    if (!dir.exists()) dir.mkdir();
    this.attrFile = attrFile;
    this.query = query;
  }

  private void login(String strDocbase, String uName, String pWord) throws DfException {
    clientX = new DfClientX();
    sMgr = clientX.getLocalClient().newSessionManager();
    IDfLoginInfo loginInfo = clientX.getLoginInfo();
    loginInfo.setUser(uName);
    loginInfo.setPassword(pWord);
    loginInfo.setDomain("");
    sMgr.setIdentity(strDocbase, loginInfo);
    sess = sMgr.getSession(strDocbase);
    System.out.println(">>>>>>>>> Logged into the docbase " + strDocbase + " as " + uName);
  }

  private IDfCollection execute(String query) throws DfException {
    IDfQuery q = clientX.getQuery();
    q.setDQL(query);
    return q.execute(sess, IDfQuery.DF_QUERY);
  }

}