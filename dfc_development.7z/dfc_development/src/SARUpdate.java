/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.IDfSession;
import com.documentum.fc.client.IDfSessionManager;
import com.documentum.fc.client.IDfSysObject;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfId;
import com.documentum.fc.common.IDfLoginInfo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;

/**
 * Filename:    $RCSfile: SARUpdate.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $    	 On:	$Date: 2007-02-12 22:08:18 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class SARUpdate {


  private static IDfClientX clientX = null;
  private static IDfSession sess = null;
  private static IDfSessionManager sMgr = null;

  private static String attr = null;

  private static PrintWriter log = null;

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    try {
      if (args.length == 5) {
        login(args[0], args[1], args[2]);
        attr = args[3];
      } else {
        System.err.println("Please enter the arguments.. Docbase Username Password Attr Filename");
        System.exit(1);
      }
      BufferedReader br = new BufferedReader(new FileReader(args[4]));
      log = new PrintWriter(new FileWriter("sar_exec_log.txt", true));
      String str = null;
      int i = 1;
      while ((str = br.readLine()) != null) {
        if (str.indexOf(";#") > 0) {
          String [] values = str.split(";#");
          System.out.print(i + ".  Updating -> " + values[0]);
          update(values[0], values[1]);
          i++;
        }
        log.flush();
      }
      br.close();
      log.close();
    } catch (Exception e) {
      System.out.println("<<<<<<<<< An error has occurred");
      e.printStackTrace();
    } finally {
      if (sess != null) {
        sMgr.release(sess);
        System.out.println("<<<<<<<<< Released session");
      }
    }
  }

  private static void update(String id, String value) throws DfException {
    IDfSysObject sysobj = (IDfSysObject) sess.getObject(new DfId(id));
    if (!sysobj.isCheckedOut()) {
      sysobj.setString(attr, value);
      sysobj.save();
      log.println(id + " >> " + value);
      System.out.println("  DONE!");
    } else {
      log.println(id + " << locked by " + sysobj.getLockOwner());
      System.out.println(" >>>> LOCKED");
    }
  }

  private static void login(String strDocbase,
                            String uName, String pWord) throws DfException {
    clientX = new DfClientX();
    sMgr = clientX.getLocalClient().newSessionManager();
    IDfLoginInfo loginInfo = clientX.getLoginInfo();
    loginInfo.setUser(uName);
    loginInfo.setPassword(pWord);
    loginInfo.setDomain("");
    sMgr.setIdentity(strDocbase, loginInfo);
    sess = sMgr.getSession(strDocbase);
    System.out.println(">>>>>>>>> Logged into the docbase " + strDocbase + " as " + uName);
  }
}