/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.IDfLoginInfo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 * Filename:    $RCSfile: UpdateRepeating.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author: tsvedan $
 * On:	$Date: 2007-01-19 22:12:00 $
 *
 * @author tsvedan
 * @version $Revision: 1.2 $
 */
public class UpdateRepeating {

  private static IDfClientX clientX = null;
  private static IDfSession sess = null;
  private static IDfSessionManager sMgr = null;

  private static String type = null;
  private static String attr = null;

  private static PrintWriter log = null;

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    try {
      if (args.length == 6) {
        login(args[0], args[1], args[2]);
        type = args[3];
        attr = args[4];
      } else {
        System.err.println("Please enter the arguments.. Docbase Username Password Type Attr Filename");
        System.exit(1);
      }
      BufferedReader br = new BufferedReader(new FileReader(args[5]));
      log = new PrintWriter(new FileWriter(getLogName(), true));
      String str = null;
      while ((str = br.readLine()) != null) {
        if (str.indexOf(";#") > 0) {
          String [] values = str.split(";#");
          update(values[0], values[1]);
        } else delete(str);
        log.flush();
      }
      br.close();
      log.close();
    } catch (Exception e) {
      System.out.println("<<<<<<<<< An error has occurred");
      e.printStackTrace();
    } finally {
      if (sess != null) {
        sMgr.release(sess);
        System.out.println("<<<<<<<<< Released session");
      }
    }
  }

  private static String getLogName() {
    StringBuffer logFile = new StringBuffer();
    logFile.append(type);
    logFile.append("_");
    logFile.append(attr);
    logFile.append(".log");
    return logFile.toString();
  }

  private static void update(String oldValue, String newValue) throws Exception {
    int count = 0;
    System.out.println("Old value = " + oldValue + "  New value = " + newValue);
    log.print(oldValue + ">>" + newValue);
    IDfCollection coll = execute(getQuery(oldValue));
    while (coll.next()) {
      IDfSysObject sysobj = (IDfSysObject) sess.getObject(coll.getId("r_object_id"));
      for (int i = 0; i < sysobj.getValueCount(attr); i++) {
        if (oldValue.equals(sysobj.getRepeatingString(attr, i)))
          sysobj.setRepeatingString(attr, i, newValue);
      }
      sysobj.save();
      count++;
    }
    coll.close();
    System.out.println("Number of objects updated = " + count);
    log.println(";;" + count);
  }

  private static void delete(String oldValue) throws Exception {
    int count = 0;
    System.out.println("Old value to DELETE = " + oldValue);
    log.print("Old value to DELETE = " + oldValue);
    IDfCollection coll = execute(getQuery(oldValue));
    while (coll.next()) {
      IDfSysObject sysobj = (IDfSysObject) sess.getObject(coll.getId("r_object_id"));
      ArrayList list = new ArrayList();
      for (int i = 0; i < sysobj.getValueCount(attr); i++) {
        String val = sysobj.getRepeatingString(attr, i);
        if (!oldValue.equals(val))
          list.add(val);
      }
      sysobj.truncate(attr, 0);
      for (int i = 0; i < list.size(); i++)
        sysobj.setRepeatingString(attr, i, (String) list.get(i));
      sysobj.save();
      count++;
    }
    coll.close();
    System.out.println("Number of objects updated = " + count);
    log.println(";;" + count);
  }

  private static void login(String strDocbase,
                            String uName, String pWord) throws DfException {
    clientX = new DfClientX();
    sMgr = clientX.getLocalClient().newSessionManager();
    IDfLoginInfo loginInfo = clientX.getLoginInfo();
    loginInfo.setUser(uName);
    loginInfo.setPassword(pWord);
    loginInfo.setDomain("");
    sMgr.setIdentity(strDocbase, loginInfo);
    sess = sMgr.getSession(strDocbase);
    System.out.println(">>>>>>>>> Logged into the docbase " + strDocbase + " as " + uName);
  }

  private static IDfCollection execute(String query) throws DfException {
    IDfQuery q = clientX.getQuery();
    q.setDQL(query);
    return q.execute(sess, IDfQuery.DF_QUERY);
  }

  private static String getQuery(String str) {
    if (str.indexOf("'") >= 0 && str.indexOf("''") < 0)
      str = str.replaceAll("'", "''");
    StringBuffer strbuff = new StringBuffer();
    strbuff.append("SELECT r_object_id FROM ").append(type);
    strbuff.append(" (ALL) WHERE ANY ").append(attr);
    strbuff.append("='").append(str).append("'");
    strbuff.append(" AND r_lock_date IS NULLDATE");
    strbuff.append(" AND r_immutable_flag=0 ");
    return strbuff.toString();
  }

}