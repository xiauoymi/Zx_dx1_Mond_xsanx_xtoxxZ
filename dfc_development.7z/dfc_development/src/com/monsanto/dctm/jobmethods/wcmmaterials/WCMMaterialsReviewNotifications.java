package com.monsanto.dctm.jobmethods.wcmmaterials;/*
 Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.DfException;
import com.documentum.fc.common.DfLogger;
import com.documentum.mthdservlet.IDmMethod;
import com.monsanto.dctm.utils.DFCSessionUtils;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

/**This method runs as job once everyday.
 * Fetches documents that have annually_reviewed attribute set and is one year old from today.
 * Gets the document owner and sends a review notification
 * If document owner is inactive, then send review notification to all active admins in the wcm_materials_admin group
 *
 * 
 */
public class WCMMaterialsReviewNotifications implements IDmMethod {
  private static final String CLASSNAME = "com.monsanto.dctm.jobmethods.wcmmaterials.WCMMaterialsReviewNotifications";
  private IDfSessionManager sessionManager;
  private String docbase;
  private String userName;
  private String password;
  private String reviewMessage = "The following document is due for annual review.";
  //private String strJobID;
  private OutputStream out;
  private IDfSession session;
  //IDfSysObject sysobjDoc;

  /**the entry method for processing documents up for annual review
   *
   * @param parameters
   * @param output
   * @throws DfException
   * @throws IOException
   */
  public void execute(Map parameters, OutputStream output) throws DfException, IOException{
    this.out = output;
    boolean validParameters = validateArguments(parameters, output);
    if (validParameters) {
      try {
        createSession();
        sendReviewNotifications();
      }
      finally {
        releaseSession();
      }
    }
  }

  /** Form the query to get the documents up for annual review.
   *
   * @return String
   */
  private String getQuery() {
    StringBuffer strbuff = new StringBuffer();
    strbuff.append("select r_object_id, object_name, doc_owner from wcm_materials_doc ");
    strbuff.append("where annually_reviewed = 1 and ");
    strbuff.append("(DATEDIFF(year,r_creation_date,date(today)) = 1 )");
    //System.out.println(strbuff);
    return strbuff.toString();
  }

  /**Gets the query for execution
   *
   * @param strQuery
   * @return
   * @throws DfException
   */
  private IDfCollection execQuery(String strQuery) throws DfException {
    IDfClientX clientx = new DfClientX();
    IDfQuery q = clientx.getQuery();
    q.setDQL(strQuery);
    //System.out.println(strQuery);
    return q.execute(session, IDfQuery.DF_QUERY);
  }

  /** Get the documents with document owners for annual review
   * Check if the document owner is active then send the document for review
   * If author is inactive then send notification to all the users in the admin group
   */
  private void sendReviewNotifications() {
    IDfCollection coll = null;
    boolean activeUser = false;
    try {
      coll = execQuery(getQuery());
      String performerName = null;
      if (coll != null) {
        while (coll.next()) {
          IDfSysObject sysobjDoc = (IDfSysObject) session.getObject(coll.getId("r_object_id"));
          performerName= coll.getString("doc_owner");
          //System.out.println("performerName = " + performerName);
          //if user is inactive then send the review mail to all the users in the admin group
          activeUser = processInactiveUsers(performerName, sysobjDoc);
          //System.out.println("activeUser = "+ activeUser);
          if (activeUser) {
            //System.out.println("In active user message = " + reviewMessage);
            sysobjDoc.queue(performerName, "Review Due", 10, true, null, reviewMessage);
          }
        }
        coll.close();
      }else {
        System.out.println("coll = " + coll.toString());
      }

    } catch (DfException de) {
      DfLogger.debug(CLASSNAME, "Error during query execution " + de.getMessage(), null, null);
    }
  }

  /**forms the query to get the user state and returns it
   *
   * @return String
   */
  private String getUserStateQuery(String performerName) {
    StringBuffer strbuff = new StringBuffer();
    strbuff.append("select r_object_id, user_state from dm_user ");
    strbuff.append("where user_name = '");
    strbuff.append(performerName);
    strbuff.append("'");
    //System.out.println(strbuff);
    return strbuff.toString();
  }

  /**forms the query to get the user state and returns it
    *
    * @return String
    */
   private String getAdminUsersQuery() {
     StringBuffer strbuff = new StringBuffer();
     strbuff.append("select r_object_id, user_name from dm_user ");
     strbuff.append("where user_state = 0 and user_name in ");
     strbuff.append("(Select i_all_users_names from dm_group where group_name like 'wcm_materials_admin')");
     //System.out.println(strbuff);
     return strbuff.toString();
   }

  /**Get all the active admin users to send the review message
   * send the message
   * @throws DfException
   */
  private void processAdminReviewNotification(IDfSysObject sysobjDoc) throws DfException{
    IDfCollection coll = null;
    coll = execQuery(getAdminUsersQuery());
    String adminUser = new String();
    if (coll != null) {
      while (coll.next()) {
          //IDfSysObject sysobj = (IDfSysObject) session.getObject(coll.getId("r_object_id"));
          adminUser= coll.getString("user_name");
          //System.out.println("performerName = " + adminUser);
          //System.out.println("message = " + reviewMessage);
          sysobjDoc.queue(adminUser, "Review Due", 10, true, null, reviewMessage);
      }
    }
  }
/**check if the author/performer is inactive
 * if inactive then send the review notification to the users in the admin group
*/
private boolean processInactiveUsers(String performerName, IDfSysObject sysobjDoc) throws DfException {
  boolean active = true;
  //get the user state
  IDfCollection coll = null;
  boolean userState = false;
  coll = execQuery(getUserStateQuery(performerName));
  if (coll != null) {
    userState = coll.getBoolean("user_state");
    //System.out.println("userState = " + userState);
    if (!userState) {
      active = false;
      //get all active admin users and send review notification
      processAdminReviewNotification(sysobjDoc);
    }
  }
  return active;
}

  /**Make sure all the parameters are given to create a session.
   *
   * @param map
   * @param outputStream
   * @return boolean
   * @throws IOException
   */

    private boolean validateArguments(Map map, OutputStream outputStream) throws IOException {
        boolean validArguments = true;

        if (map.containsKey("docbase")) {
            docbase = ((String[]) map.get("docbase"))[0];
        }
        if (map.containsKey("userid")) {
            userName = ((String[]) map.get("userid"))[0];
        }
        if (map.containsKey("ticket")) {
            password = ((String[]) map.get("ticket"))[0];
        }

        if (docbase == null || docbase.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply docbase");
            validArguments = false;
        }
        if (userName == null || userName.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply userid");
            validArguments = false;
        }
        if (password == null || password.length() <= 0) {
            if (validArguments) {
                writeMessage(outputStream, "Error:");
            }
            writeMessage(outputStream, "must supply ticket");
            validArguments = false;
        }
         return validArguments;
    }
  private void createSession() throws DfException {
      sessionManager = getSessionManager(docbase, userName, password);
      session = sessionManager.getSession(docbase);
      //System.out.println("Successfully logged into " + docbase + " as " + userName);
  }

  protected IDfSessionManager getSessionManager(String docbase, String userid, String password) throws DfException {
    return DFCSessionUtils.createSessionManager(docbase, userid, password);
  }
  private void releaseSession() {
    //System.out.println("Releasing session... ");
    if (session != null)
      sessionManager.release(session);
  }
    private void writeMessage(OutputStream outputStream, String message) throws IOException {
        outputStream.write((message + "\n").getBytes());
    }
 }
