package com.monsanto.dctm.workflowmethods.breedingdocs;/*
 Copyright:  Copyright � 2006 Monsanto.  All rights reserved.
 This software was produced using Monsanto resources and is the sole property of Monsanto.
 Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

import com.documentum.com.DfClientX;
import com.documentum.com.IDfClientX;
import com.documentum.fc.client.*;
import com.documentum.fc.common.*;
import com.documentum.mthdservlet.IDmMethod;

import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * Filename:    $RCSfile: WF_BreedingPromoteLCAndSendNotification.java,v $ Label:       $Name: not supported by cvs2svn $ Last Change: $Author:
 * tsvedan $    	 On:	$Date: 2008-01-22 20:22:34 $
 *
 * @author tsvedan
 * @version $Revision: 1.1 $
 */
public class WF_BreedingPromoteLCAndSendNotification
    implements IDmMethod {

  /**
   * Creates a new instance of com.monsanto.dctm.workflowmethods.breedingdocs.WF_BreedingPromoteLCAndSendNotification
   */
  public WF_BreedingPromoteLCAndSendNotification() {
    m_sessionMgr = null;
    m_docbase = null;
    m_userName = null;
    m_workitemId = null;
    m_ticket = null;
  }

  public void execute(Map params, OutputStream ostream)
      throws Exception {
    IDfSessionManager sessionManager;
    IDfSession session;
    initWorkflowParams(params);
    sessionManager = login();
    session = null;
    try {
      IDfId workitemID = new DfId(m_workitemId);
      session = sessionManager.getSession(m_docbase);
      IDfWorkitem workitem = (IDfWorkitem) session.getObject(workitemID);
      if (workitem.getRuntimeState() == 0)
        workitem.acquire();
      IDfCollection pkgColl = null;
      System.out.println("Getting packages and promoting document(s)");
      pkgColl = workitem.getPackages("");
      if (pkgColl != null) {
        while (pkgColl.next()) {
          String docId = pkgColl.getString("r_component_id");
          System.out.println(docId.toString());
          int docCount = pkgColl.getValueCount("r_component_id");
          for (int i = 0; i < docCount; i++) {
            IDfId docIdObj = pkgColl.getRepeatingId("r_component_id", i);
            if (docIdObj != null) {
              IDfId sysobjID = new DfId(docId);
              IDfSysObject doc = (IDfSysObject) session.getObject(sysobjID);
              setEffectiveDate(doc);
              doc.promote(null, false, false);
              sendNotification(doc, session);
            }
          }
        }
        pkgColl.close();
      }
      workitem.complete();
    } catch (DfException e) {
      System.out.println(e.getMessage());
      e.printStackTrace();
      throw e;
    } finally {
      if (session != null)
        sessionManager.release(session);
    }
  }

  protected void initWorkflowParams(Map params) {
    Set keys = params.keySet();
    Iterator iter = keys.iterator();
    do {
      if (!iter.hasNext())
        break;
      String key = (String) iter.next();
      if (key != null && key.length() != 0) {
        String[] value = (String[]) params.get(key);
        if (key.equalsIgnoreCase(USER_KEY))
          m_userName = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase(DOCBASE_KEY))
          m_docbase = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase(WORKITEM_KEY))
          m_workitemId = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase(PACKAGE_KEY))
          m_workitemId = value.length <= 0 ? "" : value[0];
        else if (key.equalsIgnoreCase(TICKET_KEY))
          m_ticket = value.length <= 0 ? "" : value[0];
      }
    } while (true);
  }

  protected IDfSessionManager login()
      throws DfException {
    if (m_docbase == null || m_userName == null || m_ticket == null)
      return null;
    IDfClient dfClient = DfClient.getLocalClient();
    if (dfClient != null) {
      IDfLoginInfo li = new DfLoginInfo();
      li.setUser(m_userName);
      li.setPassword(m_ticket);
      li.setDomain(null);
      IDfSessionManager sessionMgr = dfClient.newSessionManager();
      sessionMgr.setIdentity(m_docbase, li);
      return sessionMgr;
    } else {
      return null;
    }
  }

  protected void setEffectiveDate(IDfSysObject sysObj) throws DfException {
    IDfClientX clientx = new DfClientX();
    String now = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(new Date());
    IDfTime time = clientx.getTime(now, IDfTime.DF_TIME_PATTERN44);
    System.out.println("$$$$$$Setting Effective Date to: " + time.getDate());
    sysObj.setTime("effective_date", time);
    sysObj.save();
  } //setEffectiveDate

  protected void sendNotification(IDfSysObject sysObj, IDfSession sess)
      throws DfException {

    if (notifyGroup == null) return;
    IDfGroup notify = sess.getGroup(notifyGroup);
    if (notify == null || notify.getAllUsersNamesCount() < 1) {
      System.out.println("@@@@@@<<<<<< Notification group " + notifyGroup + " is either unavailable or empty");
      return;
    }
    System.out.println(
        ">>>>>SENDING " + notify.getAllUsersNamesCount() + " NOTIFICATION(S) FOR DOC: " + sysObj.getObjectName());
    String message = getMessage(sysObj);
    sysObj.queue(notifyGroup, "Approval Notice", 10, true, null, message);
  } //sendUsersNotification

  protected String getMessage(IDfSysObject sysObj) throws DfException {
    StringBuffer strbuff = new StringBuffer();
    strbuff.append("The following document has been reviewed and approved. ");
    strbuff.append("This document is the latest version and supersedes any previous version. ");
    String comments = sysObj.getString("version_comments");
    if (comments != null && comments.length() > 0) {
      strbuff.append("Here are the version comments - ");
      strbuff.append(comments);
    } else strbuff.append("No version comments have been recorded for this document!");
    return strbuff.toString();
  }

  protected IDfSessionManager m_sessionMgr;
  protected String m_docbase;
  protected String m_userName;
  protected String m_workitemId;
  protected String m_ticket;
  protected String notifyGroup = "breeding_notify";
  private static final String USER_KEY = "user";
  private static final String DOCBASE_KEY = "docbase_name";
  private static final String WORKITEM_KEY = "workitemId";
  private static final String TICKET_KEY = "ticket";
  private static final String PACKAGE_KEY = "packageId";

}