package com.monsanto.enterprise.iimex;

//this class store every database queries used in the application to load or modify data
public class DataBaseQueries {

	public static final String SELECT_COUNTRY = "SELECT COUNTRY.COUNTRY_CODE, COUNTRY.COUNTRY_NAME, COUNTRY.AREA_CODE, COUNTRY.ACTIVE, COUNTRY.CUSTOM_ZONE, COUNTRY.PUBLISH_OWNER, COUNTRY.PUBLISH_DATE FROM IEVIEW.COUNTRY order by COUNTRY_NAME asc";

	public static final String SELECT_WORLD_AREA = "SELECT WORLD_AREA_CODE, WORLD_AREA_NAME, PUBLISH_OWNER, PUBLISH_DATE FROM IEVIEW.WORLD_AREA";
	
	public static final String SELECT_FROM_CUSTOMS_ZONE = "SELECT CUSTOM_ZONE_CODE, CUSTOM_ZONE_NAME, AREA_CODE, PUBLISH_OWNER, PUBLISH_DATE FROM IEVIEW.CUSTOMS_ZONE";
	
	public static final String SELECT_CUSTOMS_ZONE = "SELECT CUSTOM_ZONE_CODE, CUSTOM_ZONE_NAME, AREA_CODE, PUBLISH_OWNER, PUBLISH_DATE FROM IEVIEW.CUSTOMS_ZONE";
	
	public static final String SELECT_INSTRUCTIONS = "SELECT * FROM IEVIEW.SHIPPING_INSTRUCTIONS";
	
	public static final String ADD_INSTRUCTIONS = "INSERT INTO IEVIEW.SHIPPING_INSTRUCTIONS VALUES (?,?,?,?,?,?,?,?,?)";
	
	public static final String UPDATE_INSTRUCTIONS = "UPDATE IEVIEW.SHIPPING_INSTRUCTIONS SET SHIPPING_INSTRUCTIONS.SEED_SAMPLES = ? , SHIPPING_INSTRUCTIONS.SHIPPING_INSTRUCTIONS = ? , SHIPPING_INSTRUCTIONS.SEED_TREATMENT = ? , SHIPPING_INSTRUCTIONS.MISCALLENOUS = ? , SHIPPING_INSTRUCTIONS.PACKAGING = ? , SHIPPING_INSTRUCTIONS.PUBLISH_OWNER = ? , SHIPPING_INSTRUCTIONS.PUBLISH_DATE	 = ? WHERE SHIPPING_INSTRUCTIONS.DESTINATION_COUNTRY_CODE = ? AND SHIPPING_INSTRUCTIONS.DIVISION =? ";
	
	public static final String REMOVE_INSTRUCTIONS = "DELETE FROM IEVIEW.SHIPPING_INSTRUCTIONS WHERE SHIPPING_INSTRUCTIONS.DESTINATION_COUNTRY_CODE = ? AND SHIPPING_INSTRUCTIONS.DIVISION =? ";
	
	public static final String SELECT_FEES= "SELECT FEES.COUNTRY_CODE, FEES.SHIPPING_DESTINATION, FEES.CERTIFICATE_OF_ORIGIN, FEES.CONSULAR, FEES.FEDERAL_SEED_LAB, FEES.HANDLING, FEES.INSURANCE, FEES.LEGALIZATION, FEES.PHYTOSANITARY_CERTIFICATE, FEES.SEED_ANALYSIS_CERTIFICATE, FEES.INSPECTION, FEES.OTHER, FEES.PUBLISH_OWNER, FEES.PUBLISH_DATE FROM IEVIEW.FEES";
	
	public static final String ADD_FEES= "INSERT INTO IEVIEW.FEES VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String UPDATE_FEES= "UPDATE IEVIEW.FEES SET FEES.CERTIFICATE_OF_ORIGIN = ? , FEES.CONSULAR = ? , FEES.FEDERAL_SEED_LAB = ? , FEES.HANDLING = ? , FEES.INSURANCE = ? , FEES.LEGALIZATION = ? , FEES.PHYTOSANITARY_CERTIFICATE = ? , FEES.SEED_ANALYSIS_CERTIFICATE = ? , FEES.INSPECTION = ? , FEES.OTHER = ? , FEES.PUBLISH_OWNER = ? , FEES.PUBLISH_DATE = ? WHERE  FEES.COUNTRY_CODE = ? AND FEES.SHIPPING_DESTINATION = ? ";
	
	public static final String ADD_COMPANY_DETERMINATION = "INSERT INTO IEVIEW.COMPANY_DETERMINATION VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String SELECT_COMPANY_DETERMINATION = "SELECT COMPANY_DETERMINATION.COUNTRY_CODE, COMPANY_DETERMINATION.DIVISION_CODE, COMPANY_DETERMINATION.PRODUCT_GROUP_CODE, COMPANY_DETERMINATION.SOLDTO_COMPANY_CODE, COMPANY_DETERMINATION.SALES_COMPANY_CODE, COMPANY_DETERMINATION.BILLTO_COMPANY_CODE, COMPANY_DETERMINATION.SHIPTO_COMPANY_CODE, COMPANY_DETERMINATION.CONSIGNTO_COMPANY_CODE, COMPANY_DETERMINATION.SELLLING_COMPANY_CODE, COMPANY_DETERMINATION.SALES_ORGANISATION, COMPANY_DETERMINATION.PUBLISH_OWNER, COMPANY_DETERMINATION.PUBLISH_DATE, COMPANY_DETERMINATION.ACTIVE FROM IEVIEW.COMPANY_DETERMINATION";
	
	public static final String UPDATE_COMPANY_DETERMINATION = "UPDATE IEVIEW.COMPANY_DETERMINATION SET COMPANY_DETERMINATION.SOLDTO_COMPANY_CODE = ? , COMPANY_DETERMINATION.SALES_COMPANY_CODE = ? , COMPANY_DETERMINATION.BILLTO_COMPANY_CODE = ? , COMPANY_DETERMINATION.SHIPTO_COMPANY_CODE = ? , COMPANY_DETERMINATION.CONSIGNTO_COMPANY_CODE = ? , COMPANY_DETERMINATION.SELLLING_COMPANY_CODE = ? , COMPANY_DETERMINATION.SALES_ORGANISATION = ? , COMPANY_DETERMINATION.PUBLISH_OWNER = ? , COMPANY_DETERMINATION.PUBLISH_DATE = ? , COMPANY_DETERMINATION.ACTIVE = ?  WHERE COMPANY_DETERMINATION.COUNTRY_CODE = ? AND COMPANY_DETERMINATION.DIVISION_CODE = ? AND COMPANY_DETERMINATION.PRODUCT_GROUP_CODE = ? ";
	
	public static final String REMOVE_COMPANY_DETERMINATION = "DELETE FROM IEVIEW.COMPANY_DETERMINATION WHERE COMPANY_DETERMINATION.COUNTRY_CODE = ? AND COMPANY_DETERMINATION.DIVISION_CODE = ? AND COMPANY_DETERMINATION.PRODUCT_GROUP_CODE = ? ";
	
	public static final String SELECT_COMPANIES = "SELECT * FROM IEVIEW.COMPANY order by company_code";
	
	public static final String SELECT_VALUE_ADDED_TAX = "SELECT  VALUE_ADDED_TAX.COUNTRY_CODE, VALUE_ADDED_TAX.PRODUCT_GROUP_CODE, VALUE_ADDED_TAX.VALUE_ADDED_TAX, VALUE_ADDED_TAX.PUBLISH_OWNER, VALUE_ADDED_TAX.PUBLISH_DATE FROM IEVIEW.VALUE_ADDED_TAX";
	
	public static final String ADD_VALUE_ADDED_TAX = "INSERT INTO IEVIEW.VALUE_ADDED_TAX VALUES (?,?,?,?,?)";
	
	public static final String UPDATE_VALUE_ADDED_TAX = "UPDATE IEVIEW.VALUE_ADDED_TAX SET VALUE_ADDED_TAX.VALUE_ADDED_TAX = ?, VALUE_ADDED_TAX.PUBLISH_OWNER = ?, VALUE_ADDED_TAX.PUBLISH_DATE = ? WHERE  VALUE_ADDED_TAX.COUNTRY_CODE = ? AND VALUE_ADDED_TAX.PRODUCT_GROUP_CODE = ? ";
	
	public static final String REMOVE_VALUE_ADDED_TAX = "DELETE FROM IEVIEW.VALUE_ADDED_TAX WHERE VALUE_ADDED_TAX.COUNTRY_CODE = ? AND VALUE_ADDED_TAX.PRODUCT_GROUP_CODE = ? ";
	
	public static final String SELECT_CLEARENCE_FEE = "SELECT CUSTOM_CLEARANCE_FEE.COUNTRY_CODE, CUSTOM_CLEARANCE_FEE.TRANPORT_MODE_CODE , CUSTOM_CLEARANCE_FEE.IMPORT_CUSTOM_CLEARANCE_FEE, CUSTOM_CLEARANCE_FEE.EXPORT_CUSTOM_CLEARANCE_FEE,CUSTOM_CLEARANCE_FEE.PUBLISH_OWNER, CUSTOM_CLEARANCE_FEE.PUBLISH_DATE FROM IEVIEW.CUSTOM_CLEARANCE_FEE";
	
	public static final String ADD_CLEARENCE_FEE = "INSERT INTO IEVIEW.CUSTOM_CLEARANCE_FEE VALUES (?,?,?,?,?,?)";
	
	public static final String UPDATE_CLEARENCE_FEE = "UPDATE IEVIEW.CUSTOM_CLEARANCE_FEE SET IMPORT_CUSTOM_CLEARANCE_FEE = ? , EXPORT_CUSTOM_CLEARANCE_FEE = ? , CUSTOM_CLEARANCE_FEE.PUBLISH_OWNER = ? , CUSTOM_CLEARANCE_FEE.PUBLISH_DATE = ? WHERE CUSTOM_CLEARANCE_FEE.COUNTRY_CODE = ? AND CUSTOM_CLEARANCE_FEE.TRANPORT_MODE_CODE = ?";
	
	public static final String SELECT_CLEARENCE_TIME = "SELECT CUSTOM_CLEARANCE_TIME.COUNTRY_CODE, CUSTOM_CLEARANCE_TIME.TRANSPORT_MODE_CODE , CUSTOM_CLEARANCE_TIME.EXPORT_CLEARANCE_TIME, CUSTOM_CLEARANCE_TIME.IMPORT_CLEARANCE_TIME, CUSTOM_CLEARANCE_TIME.PUBLISH_OWNER, CUSTOM_CLEARANCE_TIME.PUBLISH_DATE  FROM IEVIEW.CUSTOM_CLEARANCE_TIME";
	
	public static final String ADD_CLEARENCE_TIME = "INSERT INTO IEVIEW.CUSTOM_CLEARANCE_TIME VALUES (?,?,?,?,?,?)";
	
	public static final String UPDATE_CLEARENCE_TIME = "UPDATE IEVIEW.CUSTOM_CLEARANCE_TIME SET EXPORT_CLEARANCE_TIME = ? , IMPORT_CLEARANCE_TIME = ? , CUSTOM_CLEARANCE_TIME.PUBLISH_OWNER = ? , CUSTOM_CLEARANCE_TIME.PUBLISH_DATE = ? WHERE CUSTOM_CLEARANCE_TIME.COUNTRY_CODE = ? AND CUSTOM_CLEARANCE_TIME.TRANSPORT_MODE_CODE = ?";
	
	public static final String SELECT_TRANSPORTATION_TIME = "SELECT TRANSPORTATION_TIME.TRANSPORT_MODE_CODE, TRANSPORTATION_TIME.FREIGHT_BOOKING, TRANSPORTATION_TIME.TRANSPORTATION_TIME, TRANSPORTATION_TIME.PUBLISH_OWNER, TRANSPORTATION_TIME.PUBLISH_DATE FROM IEVIEW.TRANSPORTATION_TIME WHERE SHIPPING_COUNTRY_CODE = ? AND DESTINATION_COUNTRY_CODE = ?";
	
	public static final String ADD_TRANSPORTATION_TIME = "INSERT INTO IEVIEW.TRANSPORTATION_TIME VALUES(?,?,?,?,?,?,?)";
	
	public static final String UPDATE_TRANSPORTATION_TIME = "UPDATE IEVIEW.TRANSPORTATION_TIME SET FREIGHT_BOOKING = ? , TRANSPORTATION_TIME = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE SHIPPING_COUNTRY_CODE = ? AND DESTINATION_COUNTRY_CODE = ? AND TRANSPORTATION_TIME.TRANSPORT_MODE_CODE = ?";
	
	public static final String REMOVE_TRANSPORTATION_TIME = "DELETE FROM IEVIEW.TRANSPORTATION_TIME WHERE SHIPPING_COUNTRY_CODE = ? AND DESTINATION_COUNTRY_CODE = ? AND TRANSPORTATION_TIME.TRANSPORT_MODE_CODE = ?";
	
	public static final String SELECT_TRANSACTION_TYPE = "SELECT * FROM IEVIEW.TRANSACTION_TYPE";

    public static final String SELECT_SHIPPING_RESTRICTIONS_QUERY ="select c_res.country_of_origin, c_res.destination_country_code, \n" +
            "c_res.comments c_comments, c_res.product_group_code,  \n" +
            "rse_type.shipping_restrict_name, rse_type.shipping_restrict_code, rse_type.comments t_comments, \n" +
            "c_res.publish_owner c_owner, c_res.publish_date c_date, prd_grp.product_group_name pg_name \n" +
            "from ieview.shipping_restrictions c_res \n" +
            "left OUTER join ieview.shipping_restrictions_type rse_type \n" +
            "on c_res.shipping_restrict_code = rse_type.shipping_restrict_code \n" +
            "inner join ieview.product_group prd_grp \n" +
            "on c_res.product_group_code = prd_grp.product_group_code";

    public static final String REMOVE_RESTRICTION =
            "DELETE ieview.shipping_restrictions " +
            " WHERE destination_country_code = ? " +
            " AND country_of_origin = ? " +
            " AND product_group_code = ? ";

    public static final String UPDATE_RESTRICTION =
            "UPDATE ieview.shipping_restrictions " +
            " SET shipping_restrict_code = ?, comments = ?, publish_owner = ?, publish_date = ? " +
            " WHERE destination_country_code = ? " +
            " AND country_of_origin = ? " +
            " AND product_group_code = ? ";

    public static final String ADD_RESTRICTION =
            "INSERT INTO ieview.shipping_restrictions " +
            " (country_of_origin, destination_country_code, product_group_code, shipping_restrict_code, comments, publish_owner, publish_date) " +
            " VALUES( ?, ?, ?, ?, ?, ?, ?)";

    public static final String SELECT_SHIPPING_RESTRICT_TYPE_QUERY =
            " SELECT shipping_restrict_code, shipping_restrict_name, comments, publish_owner, publish_date " +
            " FROM ieview.shipping_restrictions_type " +
            " ORDER BY shipping_restrict_name";

    public static String ADD_SHIPPING_RESTRICTION_TYPE_QUERY =
            "INSERT INTO ieview.shipping_restrictions_type " +
            " (shipping_restrict_code, shipping_restrict_name, comments, publish_owner, publish_date) " +
            " VALUES(ieview.seqIdTable.nextval,?,?,?,?) ";

    public static String REMOVE_SHIPPING_RESTRICT_TYPE_QUERY =
            "DELETE ieview.shipping_restrictions_type WHERE shipping_restrict_code = ?";
    
    public static String UPDATE_SHIPPING_RESTRICT_TYPE_QUERY =
            "UPDATE ieview.shipping_restrictions_type " +
            " SET shipping_restrict_name = ?, comments = ?, publish_owner = ?, publish_date = ? " +
            " WHERE shipping_restrict_code = ?";

    public static final String SELECT_PREFERRED_PORT_OF_ENTRY_QUERY="SELECT shipping_country_code,destination_country_code, PREFERRED_PORT_OF_ENTRY.DIVISION_CODE,\n" +
            "  PREFERRED_PORT_OF_ENTRY.PREFERRED_PORT_OF_ENTRY,\n" +
            "  PUBLISH_OWNER,\n" +
            "  PUBLISH_DATE\n" +
            "FROM IEVIEW.PREFERRED_PORT_OF_ENTRY\n" +
            "order by SHIPPING_COUNTRY_CODE||'_'||DESTINATION_COUNTRY_CODE";

	public static final String SELECT_PREFERRED_SHIPPING_TIME_QUERY="SELECT shipping_country_code,  destination_country_code, TRANSPORTATION_TIME.TRANSPORT_MODE_CODE,\n" +
            "  TRANSPORTATION_TIME.FREIGHT_BOOKING,\n" +
            "  TRANSPORTATION_TIME.TRANSPORTATION_TIME,\n" +
            "  TRANSPORTATION_TIME.PUBLISH_OWNER,\n" +
            "  TRANSPORTATION_TIME.PUBLISH_DATE\n" +
            "FROM IEVIEW.TRANSPORTATION_TIME\n" +
            "ORDER BY SHIPPING_COUNTRY_CODE  ||'_'  ||DESTINATION_COUNTRY_CODE";
    
	public static final String ADD_TRANSACTION_TYPE = "INSERT INTO IEVIEW.TRANSACTION_TYPE VALUES (?,?,?,?,?,?)";
	
	public static final String UPDATE_TRANSACTION_TYPE = "UPDATE IEVIEW.TRANSACTION_TYPE SET PURCHASE_ORDER_TYPE = ?, SALES_ORDER_TYPE = ?, PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE SHIPPING_COMPANY_CODE = ? AND DESTINATION_COMPANY_CODE = ?";
	
	public static final String REMOVE_TRANSACTION_TYPE = "DELETE FROM IEVIEW.TRANSACTION_TYPE WHERE SHIPPING_COMPANY_CODE = ? AND DESTINATION_COMPANY_CODE = ?";
	
	public static final String SELECT_PREFERRED_PORT_OF_ENTRY = "SELECT PREFERRED_PORT_OF_ENTRY.DIVISION_CODE, PREFERRED_PORT_OF_ENTRY.PREFERRED_PORT_OF_ENTRY, PUBLISH_OWNER, PUBLISH_DATE FROM IEVIEW.PREFERRED_PORT_OF_ENTRY WHERE SHIPPING_COUNTRY_CODE = ? AND DESTINATION_COUNTRY_CODE = ?";
	
	public static final String ADD_PREFERRED_PORT_OF_ENTRY = "INSERT INTO IEVIEW.PREFERRED_PORT_OF_ENTRY VALUES (?,?,?,?,?,?)";
	
	public static final String UPDATE_PREFERRED_PORT_OF_ENTRY = "UPDATE IEVIEW.PREFERRED_PORT_OF_ENTRY SET  PREFERRED_PORT_OF_ENTRY = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE SHIPPING_COUNTRY_CODE = ? AND DESTINATION_COUNTRY_CODE = ? AND DIVISION_CODE = ?";
   	
	public static final String REMOVE_PREFERRED_PORT_OF_ENTRY = "DELETE FROM IEVIEW.PREFERRED_PORT_OF_ENTRY WHERE SHIPPING_COUNTRY_CODE = ? AND DESTINATION_COUNTRY_CODE = ? AND PREFERRED_PORT_OF_ENTRY.DIVISION_CODE = ?";

    public static final String SELECT_TRAIT = "SELECT  TRAIT_CODE, TRAIT_NAME, MON_NUM,  PRODUCT_GROUP_CODE, OECD_UNIQUE_IDENTIFIER, LAB_OFFICE_CODE, PUBLISH_DATE, PUBLISH_OWNER FROM IEVIEW.TRAIT";
	
	public static final String SELECT_TRAIT_COUNTRY = "SELECT DESTINATION_COUNTRY_CODE, APPROVED_FOR_PRODUCTION, APPROVED_FOR_IMPORT, APPROVED_FOR_FOOD, PUBLISH_OWNER, PUBLISH_DATE FROM IEVIEW.TRAIT_COUNTRY WHERE TRAIT_CODE = ?";
	
	public static final String SELECT_FROM_DIVISION ="SELECT * FROM IEVIEW.DIVISION";
	
	public static final String INSERT_DIVISION ="INSERT INTO IEVIEW.DIVISION VALUES(?,?,?,?)";
	
	public static final String DELETE_DIVISION ="DELETE FROM IEVIEW.DIVISION WHERE DIVISION_CODE = ?";
	
	public static final String UPDATE_DIVISION ="UPDATE IEVIEW.DIVISION SET DIVISION_NAME = ?, PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE DIVISION_CODE = ?";
	
	public static final String INSERT_PRODUCT ="INSERT INTO IEVIEW.PRODUCT_GROUP VALUES(?,?,?,?,?,?,?)";
	
	public static final String DELETE_PRODUCT ="DELETE FROM IEVIEW.PRODUCT_GROUP WHERE PRODUCT_GROUP_CODE = ?";
	
	public static final String UPDATE_PRODUCT ="UPDATE IEVIEW.PRODUCT_GROUP SET PRODUCT_GROUP_NAME = ?, HTS_CODE = ? , BOTANICAL_NAME = ?, PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE PRODUCT_GROUP_CODE = ?";
	
	public static final String INSERT_TRAIT ="INSERT INTO IEVIEW.TRAIT VALUES(?,?,?,?,?,?,?,?)";
	
	public static final String DELETE_TRAIT ="DELETE FROM IEVIEW.TRAIT WHERE TRAIT_CODE = ?";
	
	public static final String UPDATE_TRAIT ="UPDATE IEVIEW.TRAIT SET TRAIT_NAME = ?, MON_NUM = ?, OECD_UNIQUE_IDENTIFIER = ? , LAB_OFFICE_CODE = ?, PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE TRAIT_CODE = ?";
	
	public static final String INSERT_TRAIT_COUNTRY ="INSERT INTO IEVIEW.TRAIT_COUNTRY VALUES(?,?,?,?,?,?,?)";
	
	public static final String DELETE_TRAIT_COUNTRY ="DELETE FROM IEVIEW.TRAIT_COUNTRY WHERE TRAIT_CODE = ? AND DESTINATION_COUNTRY_CODE = ?";
	
	public static final String UPDATE_TRAIT_COUNTRY ="UPDATE IEVIEW.TRAIT_COUNTRY SET APPROVED_FOR_PRODUCTION = ?, APPROVED_FOR_IMPORT = ? , APPROVED_FOR_FOOD = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE TRAIT_CODE = ? AND DESTINATION_COUNTRY_CODE = ?";
	
	public static final String SELECT_FROM_PRODUCT_GROUP ="SELECT * FROM IEVIEW.PRODUCT_GROUP order by product_group_name asc";
	
	public static final String SELECT_PLANTS= "SELECT unique plants.plant_country_code, plants.plant_company_code, plants.plant_code,\n" +
            "     plants.plant_name, plants.plant_name2, plants.publish_date, plants.publish_owner, plants.active, \n" +
            "     nvl(company.company_name, '') company_name FROM IEVIEW.plants left join\n" +
            "     IEVIEW.COMPANY company\n" +
            "     on ieview.plants.plant_company_code = company.company_code";

	 
	public static final String SELECT_PLANTS_DIVISION ="SELECT plants_division.plant_code, plants_division.division_code, plants_division.comments FROM IEVIEW.plants_division";
	
	public static final String SELECT_CURRENCY = "SELECT  CURRENCY.country_code, CURRENCY.interco_currency, CURRENCY.sales_currency FROM IEVIEW.CURRENCY";
	
	public static final String SELECT_CURRENCY_EXCEPTION = "SELECT CURRENCY_EXCEPTION.shipping_country_code, CURRENCY_EXCEPTION.destination_country_code, CURRENCY_EXCEPTION.interco_currency, CURRENCY_EXCEPTION.sales_currency FROM IEVIEW.CURRENCY_EXCEPTION";
	
	public static final String ADD_CURRENCY = "INSERT INTO IEVIEW.CURRENCY VALUES (?,?,?,?,?,?)";
	
	public static final String UPDATE_CURRENCY = "UPDATE IEVIEW.CURRENCY SET CURRENCY.interco_currency = ? , CURRENCY.sales_currency = ?, CURRENCY.active = ?, CURRENCY.publish_owner = ?, CURRENCY.publish_date = ? WHERE CURRENCY.country_code = ?";
	
	public static final String REMOVE_CURRENCY = "DELETE FROM IEVIEW.CURRENCY WHERE CURRENCY.country_code = ?";
	
	public static final String ADD_CURRENCY_EXCEPTION = "INSERT INTO IEVIEW.CURRENCY_EXCEPTION VALUES (?,?,?,?,?,?)";
	
	public static final String UPDATE_CURRENCY_EXCEPTION = "UPDATE IEVIEW.CURRENCY_EXCEPTION SET CURRENCY_EXCEPTION.interco_currency = ? , CURRENCY_EXCEPTION.sales_currency = ?, CURRENCY_EXCEPTION.publish_owner = ? , CURRENCY_EXCEPTION.publish_date = ? WHERE CURRENCY_EXCEPTION.shipping_country_code = ? AND CURRENCY_EXCEPTION.destination_country_code = ? ";
	
	public static final String REMOVE_CURRENCY_EXCEPTION = "DELETE FROM IEVIEW.CURRENCY_EXCEPTION WHERE CURRENCY_EXCEPTION.shipping_country_code = ? AND CURRENCY_EXCEPTION.destination_country_code = ?";
	
	public static final String SELECT_FROM_CONTACTS = "SELECT CONTACTS.contact_code,"+ 
    "CONTACTS.contact_type_code,"+
    "CONTACTS.contact_name," +
    "CONTACTS.contact_person,"+
    "CONTACTS.street," +
    "CONTACTS.city," +
    "CONTACTS.country_code, "+
    "COUNTRY.country_name,"+ 
    "CONTACTS.contact_tel,"+ 
    "CONTACTS.contact_fax,"+ 
    "CONTACTS.contact_gsm,"+ 
    "CONTACTS.contact_mail,"+ 
    "CONTACTS.comments,"+ 
    "CONTACTS.publish_owner,"+ 
    "CONTACTS.publish_date "+ 
    "FROM IEVIEW.CONTACTS,IEVIEW.COUNTRY "+ 
    "WHERE CONTACTS.country_code = COUNTRY.country_code";
	
	public static final String SELECT_CONTACTS_TYPE = "SELECT CONTACTS_TYPE.CONTACT_TYPE_CODE, CONTACTS_TYPE.CONTACT_TYPE_NAME, CONTACTS_TYPE.PUBLISH_OWNER, CONTACTS_TYPE.PUBLISH_DATE FROM IEVIEW.CONTACTS_TYPE";
	
	public static final String SELECT_CONTACTS_COUNTRY = "SELECT CONTACTS_COUNTRY.CONTACT_CODE, CONTACTS_COUNTRY.COUNTRY_CODE,  CONTACTS_COUNTRY.DIVISION_CODE, CONTACTS_COUNTRY.CONTACT_FROM, CONTACTS_COUNTRY.COMMENTS FROM IEVIEW.CONTACTS_COUNTRY";
	
	public static final String SELECT_INCOTERM_TRANSP = "SELECT inc.INCOTERMS_CODE, inc.INCOTERMS_DESCR,"+ 
    "inc.DUTIES_PAID_BY,"+ 
    "inc.FREIGHT_PAID_BY, "+
    "inc.INSURANCE_PAID_BY, "+
    "inctpmode.transport_mode_code,"+ 
    "tpmode.transport_mode_name, "+
    "inc.publish_owner, "+
    "inc.publish_date "+
    "from IEVIEW.incoterms inc, IEVIEW.transport_mode_incoterm inctpmode, IEVIEW.transport_mode tpmode WHERE  inc.INCOTERMS_CODE =inctpmode.INCOTERM_CODE AND inctpmode.TRANSPORT_MODE_CODE = tpmode.TRANSPORT_MODE_CODE";
	
	public static final String SELECT_IMPORT_DUTIES = "SELECT IMPORT_DUTIES.zone_origin, IMPORT_DUTIES.country_origin, IMPORT_DUTIES.zone_destination, IMPORT_DUTIES.country_destination, IMPORT_DUTIES.HTS_CODE, IMPORT_DUTIES.import_duties, IMPORT_DUTIES.publish_owner, IMPORT_DUTIES.publish_date FROM IEVIEW.IMPORT_DUTIES";
	
	public static final String ADD_IMPORT_DUTIES = "INSERT INTO IEVIEW.IMPORT_DUTIES VALUES (?,?,?,?,?,?,?,?)";
	
	public static final String UPDATE_IMPORT_DUTIES = "UPDATE IEVIEW.IMPORT_DUTIES SET IMPORT_DUTIES.import_duties = ?, IMPORT_DUTIES.publish_owner = ?, IMPORT_DUTIES.publish_date = ? WHERE IMPORT_DUTIES.zone_origin = ? AND IMPORT_DUTIES.country_origin = ? AND IMPORT_DUTIES.zone_destination = ? AND IMPORT_DUTIES.country_destination = ? AND IMPORT_DUTIES.HTS_CODE  = ? ";
	
	public static final String REMOVE_IMPORT_DUTIES = "DELETE FROM IEVIEW.IMPORT_DUTIES WHERE IMPORT_DUTIES.zone_origin = ? AND IMPORT_DUTIES.country_origin = ? AND IMPORT_DUTIES.zone_destination = ? AND IMPORT_DUTIES.country_destination= ? AND IMPORT_DUTIES.HTS_CODE  = ?";
	
	public static final String SELECT_IMPORT_LICENSE_APPROVAL = "SELECT I.DESTINATION_COUNTRY_CODE, I.HTS_CODE, I.IMPORT_LICENSE_APPROVAL, I.PUBLISH_OWNER, I.PUBLISH_DATE FROM IEVIEW.IMPORT_LICENSE_APPROVAL I"; 
	
	public static final String ADD_IMPORT_LICENSE_APPROVAL = "INSERT INTO IEVIEW.IMPORT_LICENSE_APPROVAL VALUES (?,?,?,?,?)";
	
	public static final String UPDATE_IMPORT_LICENSE_APPROVAL = "UPDATE IEVIEW.IMPORT_LICENSE_APPROVAL SET IMPORT_LICENSE_APPROVAL = ? , PUBLISH_OWNER = ? AND PUBLISH_DATE = ? WHERE  DESTINATION_COUNTRY_CODE = ? AND HTS_CODE ?";
	
	public static final String REMOVE_IMPORT_LICENSE_APPROVAL = "DELETE FROM IEVIEW.IMPORT_LICENSE_APPROVAL WHERE DESTINATION_COUNTRY_CODE = ? AND HTS_CODE = ?";
	
	public static final String SELECT_FROM_PHYTO_REQUIREMENT = "SELECT COUNTRY_OF_ORIGIN, DESTINATION_COUNTRY_CODE, PRODUCT_GROUP_CODE, PLANT_ID, MIC_CODE, MIC_DESCRIPTION, PUBLISH_OWNER, PUBLISH_DATE, INFO_FIELD FROM IEVIEW.PHYTOSANITARY_REQUIREMENTS";
	
	public static final String SELECT_VERSION = "SELECT * FROM IEVIEW.VERSION order by release_number asc";

	public static final String OBJECT_VERSIONS_QUERY = "select object_id, version_number from IEVIEW.ie_db_status";

	public static final String SELECT_FROM_DOCUMENTS="SELECT documents.document_code, documents.document_name,documents.document_type," +
	"documents.purpose,documents.active,documents.has_blob,documents.publish_date," +
	"documents.publish_owner, documents_blob.file_name from IEVIEW.documents inner join IEVIEW.documents_blob on " +
	"documents.document_code = documents_blob.document_code" ;
	
    public static final String SELECT_FROM_DOCUMENTS_CONDITION=" SELECT documents.document_code, documents.document_name, " +
       " documents.document_type, " +
    " documents.purpose, documents.has_blob,documents_conditions.special_requirements, "+
    " documents_conditions.responsible,"+
    " documents_conditions.when_to_be_sent,"+
    " documents_conditions.where_to_be_sent,"+
    " documents_conditions.shipping_method,"+
    " documents_conditions.shipping_country_code,"+
    " documents_conditions.shipping_custom_zone,"+
    " documents_conditions.destination_country_code," +
    " documents_conditions.destination_custom_zone," +
    " documents_conditions.country_of_origin,"+
    " documents_conditions.customs_zone_of_origin,"+
    " documents_conditions.transport_mode_code," +
    " documents_conditions.incoterm_code, " +
    " documents_conditions.division_code," +
    " documents_conditions.product_group_code," +
    " documents_conditions.trait_code," +
    " documents_conditions.document_cond_code," +
    " documents_conditions.publish_date," +
    " documents_conditions.publish_owner," +
    " documents_conditions.comments  " +
    " FROM IEVIEW.documents, IEVIEW.documents_conditions " +
    " WHERE ((documents.document_code = documents_conditions.document_code))";


    public static final String UPDATE_DOCUMENT_CONDITIONS =" UPDATE ieview.documents_conditions " +
    " SET "+
    " documents_conditions.special_requirements = ?, " +
    " documents_conditions.responsible = ?, " +
    " documents_conditions.comments = ?, " +
    " documents_conditions.when_to_be_sent = ?, " +
    " documents_conditions.where_to_be_sent = ?, " +
    " documents_conditions.shipping_method = ?, " +
    " documents_conditions.shipping_country_code = ?, " +
    " documents_conditions.shipping_custom_zone = ?, "+
    " documents_conditions.country_of_origin = ?, "+
    " documents_conditions.customs_zone_of_origin = ?, "+
    " documents_conditions.transport_mode_code = ?, " +
    " documents_conditions.incoterm_code = ?, " +
    " documents_conditions.division_code = ?, " +
    " documents_conditions.product_group_code = ?, " +
    " documents_conditions.trait_code = ?, " +
    " documents_conditions.publish_owner = ?, " +
    " documents_conditions.publish_date = ? " +
    " WHERE (documents_conditions.document_cond_code = ?)";

	public static final String INACTIVE_PLANT = "UPDATE IEVIEW.PLANTS SET ACTIVE='N' WHERE PLANT_CODE = ?";
	
	public static final String ACTIVE_PLANT = "UPDATE IEVIEW.PLANTS SET ACTIVE='Y' WHERE PLANT_CODE = ?";
	
	public static final String INSERT_PLANT = "INSERT INTO IEVIEW.PLANTS (PLANT_CODE, PLANT_NAME, PLANT_NAME2, PLANT_COUNTRY_CODE, PLANT_COMPANY_CODE, ACTIVE, PUBLISH_DATE, PUBLISH_OWNER) values (?,?,?,?,?,?,?,?)";
	
	public static final String UPDATE_PLANT = "UPDATE IEVIEW.PLANTS SET PLANT_NAME = ? , PLANT_NAME2 = ? , PLANT_COUNTRY_CODE = ? , PLANT_COMPANY_CODE = ? , ACTIVE = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ?  WHERE PLANT_CODE = ?";
	
	public static final String UPDATE_PLANT_DIVISION = "UPDATE IEVIEW.PLANTS_DIVISION SET  COMMENTS = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE PLANT_CODE = ? AND DIVISION_CODE = ?";
	
	public static final String INSERT_PLANT_DIVISION = "INSERT INTO IEVIEW.PLANTS_DIVISION values (?,?,?,?,?)";
	
	public static final String DELETE_PLANT_DIVISION = "DELETE FROM IEVIEW.PLANTS_DIVISION WHERE PLANT_CODE = ? AND DIVISION_CODE = ?";
	
	public static final String DELETE_CONTACT = " DELETE FROM  IEVIEW.CONTACTS WHERE CONTACT_CODE = ? ";
	
	public static final String DELETE_CONTACTS_COUNTRY = " DELETE FROM  IEVIEW.CONTACTS_COUNTRY WHERE CONTACT_CODE = ? ";
	
	public static final String REMOVE_CONTACTS_COUNTRY = " DELETE FROM  IEVIEW.CONTACTS_COUNTRY WHERE CONTACT_CODE = ? AND COUNTRY_CODE = ? AND DIVISION_CODE = ? and contact_from =?";
	
	public static final String ADD_CONTACTS_COUNTRY = " INSERT INTO IEVIEW.CONTACTS_COUNTRY VALUES (?,?,?,?,?,?,?)";
	
	public static final String UPDATE_CONTACTS_COUNTRY = " UPDATE IEVIEW.CONTACTS_COUNTRY  SET CONTACT_FROM = ?,  COMMENTS = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE CONTACT_CODE = ? AND COUNTRY_CODE = ? AND DIVISION_CODE = ? ";
	
	public static final String UPDATE_CONTACTS = " UPDATE IEVIEW.CONTACTS  SET  COUNTRY_CODE = ? , CONTACT_TYPE_CODE = ? , CONTACT_NAME = ? , CONTACT_PERSON = ? , STREET = ? , CITY = ? , CONTACT_TEL = ? , CONTACT_GSM = ? , CONTACT_FAX = ? , CONTACT_MAIL = ? , COMMENTS = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE CONTACT_CODE = ?";
	
	public static final String INSERT_NEW_CONTACT = " INSERT INTO IEVIEW.CONTACTS " + " VALUES(ieview.seqIdTable.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String SELECT_DB_STATE = "SELECT STATUS FROM IEVIEW.IE_DB_STATUS where object_id = 'user_manager'";
	
	public static final String UPDATE_DB_STATE = "UPDATE IEVIEW.IE_DB_STATUS SET STATUS= ?  where object_id = 'user_manager'";

	public static final String INSERT_IIMEX_MONITORING = "INSERT INTO IEVIEW.IE_MONITORING VALUES (?, sysdate)";
	
	public static final String SELECT_IIMEX_MONITORING ="SELECT * FROM IEVIEW.IE_MONITORING";
	
	public static final String SELECT_USER_MONITORING ="select distinct USER_NAME from IEVIEW.IE_MONITORING";
	
	public static final String SELECT_DATE_MONITORING ="select CONNECTION_DATE from IEVIEW.IE_MONITORING where USER_NAME=?";
	
	public static final String ADD_CUSTOM_ZONE = " INSERT INTO IEVIEW.CUSTOMS_ZONE VALUES (?,?,?,?,?)";

	public static final String UPDATE_CUSTOM_ZONE = " UPDATE IEVIEW.CUSTOMS_ZONE SET CUSTOM_ZONE_NAME = ?, AREA_CODE = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE CUSTOM_ZONE_CODE = ? ";
	
	public static final String REMOVE_CUSTOM_ZONE = " DELETE FROM IEVIEW.CUSTOMS_ZONE WHERE CUSTOM_ZONE_CODE = ? ";
	
	public static final String ADD_WORLD_AREA = " INSERT INTO IEVIEW.WORLD_AREA VALUES (?,?,?,?)";

	public static final String UPDATE_WORLD_AREA = " UPDATE IEVIEW.WORLD_AREA SET WORLD_AREA_NAME = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE WORLD_AREA_CODE = ? ";
	
	public static final String SELECT_NEW_TRANSPORT = "SELECT * FROM IEVIEW.TRANSPORT_MODE WHERE TRANSPORT_MODE.TRANSPORT_MODE_CODE NOT IN ( SELECT TRANSPORT_MODE_CODE FROM IEVIEW.TRANSPORT_MODE_INCOTERM)";
	
	public static final String SELECT_NEW_INCOTERM = "SELECT * FROM IEVIEW.INCOTERMS WHERE INCOTERMS.INCOTERMS_CODE NOT IN ( SELECT INCOTERM_CODE FROM IEVIEW.TRANSPORT_MODE_INCOTERM)";
	
	public static final String REMOVE_WORLD_AREA = " DELETE FROM IEVIEW.WORLD_AREA WHERE WORLD_AREA_CODE = ? ";
	
	public static final String ADD_TRANSPORT_MODE = " INSERT INTO IEVIEW.TRANSPORT_MODE VALUES (?,?,?,?)";

	public static final String REMOVE_TRANSPORT_MODE = " DELETE FROM IEVIEW.TRANSPORT_MODE WHERE TRANSPORT_MODE_CODE = ? ";
	
	public static final String ADD_TRANSPORT_MODE_INCOTERM = " INSERT INTO IEVIEW.TRANSPORT_MODE_INCOTERM VALUES (?,?,?,?)";

	public static final String REMOVE_TRANSPORT_MODE_INCOTERM = " DELETE FROM IEVIEW.TRANSPORT_MODE_INCOTERM WHERE TRANSPORT_MODE_CODE = ? AND INCOTERM_CODE = ?";
	
	public static final String ADD_INCOTERMS = " INSERT INTO IEVIEW.INCOTERMS VALUES (?,?,?,?,?,?,?)";
	
	public static final String UPDATE_INCOTERMS = " UPDATE IEVIEW.INCOTERMS SET INCOTERMS_DESCR = ? , DUTIES_PAID_BY = ? ,  FREIGHT_PAID_BY = ? ,  INSURANCE_PAID_BY = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE INCOTERMS_CODE = ?";

	public static final String REMOVE_INCOTERMS = " DELETE FROM IEVIEW.INCOTERMS WHERE INCOTERMS_CODE = ?";
	
	public static final String ADD_COUNTRY = " INSERT INTO IEVIEW.COUNTRY VALUES (?,?,?,?,?,?,?)";

	public static final String UPDATE_COUNTRY = " UPDATE IEVIEW.COUNTRY SET ACTIVE = ? , CUSTOM_ZONE = ? , AREA_CODE = ? , PUBLISH_OWNER = ? , PUBLISH_DATE = ? WHERE COUNTRY_CODE = ? ";
	
	public static final String REMOVE_COUNTRY = " DELETE FROM IEVIEW.COUNTRY WHERE COUNTRY_CODE = ? ";
	
	public static final String ADD_CONTACT_TYPE = " INSERT INTO IEVIEW.CONTACTS_TYPE VALUES (?,?,?,?)";
	
	public static final String UPDATE_CONTACT_TYPE = " UPDATE IEVIEW.CONTACTS_TYPE set contact_type_name = ? , publish_owner = ? , publish_date = ? WHERE contact_type_code = ?";
	
	public static final String REMOVE_CONTACT_TYPE = " DELETE FROM IEVIEW.CONTACTS_TYPE WHERE CONTACT_TYPE_CODE = ? ";

	public static final String DELETE_DOCUMENT_CONDITION = " DELETE FROM IEVIEW.DOCUMENTS_CONDITIONS WHERE " +
	"	DOCUMENT_COND_CODE = ? ";

	public static final String INSERT_DOCUMENT_CONDITION = " INSERT INTO IEVIEW.DOCUMENTS_CONDITIONS" +
	" VALUES(?,IEVIEW.seqIdTable.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	
	public static final String SELECT_UPDATE_DOC = "SELECT publish_date, publish_owner FROM IEVIEW.DOCUMENTS";
	
	public static final String SELECT_UPDATE_DOCCOND = "SELECT publish_date, publish_owner FROM IEVIEW.DOCUMENTS_CONDITIONS";
	
	public static final String SELECT_UPDATE_LINKDOC = "SELECT publish_date, publish_owner FROM  ]][ ";
	
	public static final String SELECT_UPDATE_LINKURL = "SELECT publish_date, publish_owner FROM IEVIEW.LINK_URL";
	
	public static final String SELECT_FROM_LINKS = "SELECT * FROM IEVIEW.LINK_HEADER";
	
	public static final String SELECT_FROM_URL = "SELECT * FROM IEVIEW.LINK_URL";
	
	public static final String SELECT_FROM_DOC = "SELECT * FROM IEVIEW.LINK_DOC";
	
	public static final String SELECT_DOCUMENT = "SELECT DOC FROM IEVIEW.LINK_DOC WHERE " +
			" DOC_ID = ? AND LINK_ID =? ";
	
	public static final String SELECT_DOCUMENT_REQ = "SELECT DOC FROM IEVIEW.DOCUMENTS_BLOB WHERE " +
	" DOCUMENT_CODE = ? ";

	public static final String UPDATE_URL = "UPDATE IEVIEW.LINK_URL SET URL_TITLE = ? " +
	", URL_DESCRIPTION= ? " +
	", URL= ? " +
	", PUBLISH_DATE= ? " +
	", PUBLISH_OWNER= ? " +
	"WHERE URL_ID= ? ";
	
	public static final String UPDATE_DOC = "UPDATE IEVIEW.LINK_DOC SET DOC_TITLE = ? "+
		", DOC_NAME= ? "+
		", DOC_DESCRIPTION = ? "+
		", DOC = ? "+
		", PUBLISH_DATE = ? " +
		", PUBLISH_OWNER = ? " +
		", LINK_ID = ? " +
		" WHERE DOC_ID = ? ";
	
	public static final String UPDATE_DOC_WITHOUT_BLOB = "UPDATE IEVIEW.LINK_DOC SET DOC_TITLE = ? "+
	", DOC_NAME= ? "+
	", DOC_DESCRIPTION = ? "+
	", PUBLISH_DATE = ? " +
	", PUBLISH_OWNER = ? " +
	", LINK_ID = ? " +
	" WHERE DOC_ID = ? ";
	
	
	public static final String INSERT_URL = "INSERT INTO IEVIEW.LINK_URL VALUES (?,?,?,?,?,?,?)";
	
	public static final String INSERT_DOC = "INSERT INTO IEVIEW.LINK_DOC VALUES (?,?,?,?,?,?,?,?)";
	
	public static final String DELETE_URL = "DELETE FROM IEVIEW.LINK_URL WHERE URL_ID = ?";
	
	
	
	public static final String INACTIVE_LINK = "UPDATE IEVIEW.LINK_HEADER SET LINK_ACTIVE=0 WHERE LINK_ID= ?";
	public static final String REMOVE_LINK_DOC = "DELETE FROM IEVIEW.LINK_DOC WHERE LINK_ID= ? AND DOC_ID= ?";
	
	public static final String UPDATE_LINK = "UPDATE IEVIEW.LINK_HEADER SET LINK_NAME = ? " +
			", LINK_DESCRIPTION=? " +
			"WHERE LINK_ID=?";
	
	public static final String INSERT_LINK = "INSERT INTO IEVIEW.LINK_HEADER VALUES ( ?,?,? ,? )";

	
	public static final String SELECT_CUSTOMS_IMPORT_DUTIES="SELECT * from IEVIEW.CUSTOMS_IMPORT_DUTIES";
	
	public static final String SELECT_PRICING_CURRENCY_EXC="SELECT * from IEVIEW.PRICING_CURRENCY_EXCEPTIONS";

	
	

	
	
		
	public static final String INSERT_NEW_DOC = "INSERT INTO IEVIEW.DOCUMENTS VALUES(?,?,?,?,?,?,?,?)";
	
	public static final String INACTIVE_DOCUMENT = "UPDATE IEVIEW.DOCUMENTS SET ACTIVE='N' WHERE DOCUMENT_CODE= ?";
	
	public static final String SET_HAS_DOC = "UPDATE IEVIEW.DOCUMENTS SET HAS_BLOB='Y' WHERE DOCUMENT_CODE=?";
	
	public static final String UPDATE_DOC_REQ =" UPDATE IEVIEW.DOCUMENTS SET DOCUMENT_NAME = ? "+
												", DOCUMENT_TYPE = ? "+
												", PURPOSE = ? "+
												"WHERE DOCUMENT_CODE=?";
	public static final String UPLOAD_DOC = " UPDATE IEVIEW.DOCUMENTS_BLOB SET DOC = ? "+
											", FILE_NAME = ? "+
											" WHERE DOCUMENT_CODE = ?";
	
	public static final String INSERT_DOC_BLOB = " INSERT INTO IEVIEW.DOCUMENTS_BLOB VALUES (?,?,?)";

    public static String SELECT_SHIPPING_RESTRICTIONS_FOR_REPORT =
            " SELECT c2.country_name dest_name, c2.country_code dest_code, " +
            " c1.country_name origin_name, c1.country_code origin_code, " +
            " division.division_name, pg.product_group_name, restyp.shipping_restrict_name, " +
            " res.comments, res.publish_owner, res.publish_date " +
            " FROM ieview.shipping_restrictions res" +
            " INNER JOIN ieview.shipping_restrictions_type restyp ON res.shipping_restrict_code = restyp.shipping_restrict_code " +
            " INNER JOIN ieview.product_group pg ON res.product_group_code = pg.product_group_code " +
            " INNER JOIN ieview.country c1 ON res.country_of_origin = c1.country_code " +
            " INNER JOIN ieview.country c2 ON res.destination_country_code = c2.country_code " +
            " INNER JOIN ieview.division ON pg.division_code = division.division_code ";

    public static String SELECT_DOC_REQUIREMENTS_FOR_REPORT =
            " select  a.DESTINATION_COUNTRY_CODE, a.DESTINATION_CUSTOM_ZONE, a.SHIPPING_COUNTRY_CODE, a.SHIPPING_CUSTOM_ZONE, a.COUNTRY_OF_ORIGIN, " +
            " c.DIVISION_NAME as Division , d.product_group_name as Product_Group, a.TRAIT_CODE, f.INCOTERMS_DESCR as Incoterms, " +
            " e.TRANSPORT_MODE_NAME as Transport_Mode, b.DOCUMENT_NAME, a.SPECIAL_REQUIREMENTS, a.WHEN_TO_BE_SENT, a.WHERE_TO_BE_SENT, a.RESPONSIBLE, " +
            " a.SHIPPING_METHOD, A.PUBLISH_OWNER, A.PUBLISH_DATE, b.DOCUMENT_CODE, a.DOCUMENT_COND_CODE " +
            " from ieview.DOCUMENTS_CONDITIONS a, ieview.documents b, ieview.division c, ieview.product_group d, ieview.transport_mode e, " +
            " ieview.incoterms f " +
            " where a.DOCUMENT_CODE = b.DOCUMENT_CODE and a.DIVISION_CODE = c.DIVISION_CODE (+) and a.product_group_code = d.product_group_code (+) " +
            " and a.transport_mode_code = e.transport_mode_code (+) and a.INCOTERM_CODE = f.INCOTERMS_CODE (+) " +
            " order by a.destination_country_code, a.DIVISION_CODE, b.DOCUMENT_NAME ";
}
