package com.monsanto.enterprise.iimex;

import java.util.ResourceBundle;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;

public class IIMexException extends Exception{
	private Throwable rootCause;
	
	/**
	 * Create an exception with the given message and cause.
	 * <p>
	 * @param msg description of problem
	 * @param rootCause original exception, if any
	 */
	public IIMexException(ResourceBundle errorBundle,String msg, Throwable rootCause) {
		super(errorBundle.getString(msg));
		this.rootCause = rootCause;
		LoggableError logError = new LoggableError(errorBundle.getString(msg)+ rootCause.toString());
		Logger.log(logError);	
	}
	
	public IIMexException(ResourceBundle errorBundle,String msg){
		super(errorBundle.getString(msg));
		LoggableError logError = new LoggableError(errorBundle.getString(msg));
		Logger.log(logError);
	}
	
	public IIMexException(String msg, Throwable rootCause) {
		this.rootCause = rootCause;
		LoggableError logError = new LoggableError(msg+ rootCause.toString());
		Logger.log(logError);	
	}
	
	public IIMexException(String msg){
		super(msg);
		LoggableError logError = new LoggableError(msg);
		Logger.log(logError);
	}
	

	/**
	 * @return the root cause of this exception (may be null)
	 */
	public Throwable getRootCause() {
		return rootCause;
	}

}
