package com.monsanto.enterprise.iimex;

import com.monsanto.JavaMail.JavaMailMailDocument;
import com.monsanto.Mail.SimpleMailDocument;
import com.monsanto.Mail.SimpleMailDocumentPerson;
import com.monsanto.Mail.SimpleMailDocumentXMLAdapter;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import java.util.Date;
import java.util.List;

/*
 * Utility class. Used to send email to the dev team or to send an exception to them
 */

public class IIMexMailHelper {

	    

	    public static void sendMail(String subject, String msg, List mailAddress)

	    {

	        SimpleMailDocument mail = new SimpleMailDocument();        

	        for (int i = 0; i < mailAddress.size(); i++)

	        {
	            SimpleMailDocumentPerson toPerson = new SimpleMailDocumentPerson();
	            toPerson.setAddress((String)mailAddress.get(i));
	            mail.addToPerson(toPerson);            
	        }

	        SimpleMailDocumentPerson fromPerson = new SimpleMailDocumentPerson();

	        fromPerson.setAddress((IIMexServlet.iimexUsersManager.getErrorBundle()).getString("from"));        

	        mail.setFromPerson(fromPerson);

	        mail.addLineToBody(msg);

	        mail.setSubject(subject);

	        mail.setReceiveDate(new Date());

	        mail.setSubject(IIMexServlet.iimexUsersManager.getErrorBundle().getString("subject"));

	        try

	        {

                JavaMailMailDocument javaMail = new JavaMailMailDocument(SimpleMailDocumentXMLAdapter.getXML(mail));

	            javaMail.send();

	            

	        }

	        catch (Exception exc)

	        {

	            exc.printStackTrace();

	        } 

	    }

	    public static void send(Exception exception, String userName)

	    {

 	        SimpleMailDocument mail = new SimpleMailDocument();

	        SimpleMailDocumentPerson toPerson = new SimpleMailDocumentPerson();

	        toPerson.setAddress(IIMexServlet.iimexUsersManager.getErrorBundle().getString("to"));

	        SimpleMailDocumentPerson ccPerson = new SimpleMailDocumentPerson();

	        ccPerson.setAddress(IIMexServlet.iimexUsersManager.getErrorBundle().getString("cc"));

	        SimpleMailDocumentPerson fromPerson = new SimpleMailDocumentPerson();

	        fromPerson.setAddress(IIMexServlet.iimexUsersManager.getErrorBundle().getString("from"));

	        

	        StackTraceElement[] stackTrace=exception.getStackTrace();

	        

	        mail.addToPerson(toPerson);

	        mail.addCCPerson(ccPerson);

	        mail.setFromPerson(fromPerson);

	        mail.addLineToBody(exception.toString());

	        mail.addLineToBody("User :"+userName);

          if (exception instanceof IIMexException){
            mail.addLineToBody("Root cause : " + ((IIMexException)exception).getRootCause().getMessage());
          }

	        for(int i =0; i<stackTrace.length;i++){

	        	mail.addLineToBody(stackTrace[i].toString());

	        }

	        mail.setReceiveDate(new Date());

	                

	        mail.setSubject(IIMexServlet.iimexUsersManager.getErrorBundle().getString("subject")+exception.toString());

	        try

	        {

                JavaMailMailDocument javaMail = new JavaMailMailDocument(SimpleMailDocumentXMLAdapter.getXML(mail));

	            javaMail.send();   

	        }

	        catch (Exception exc)

	        {

	            exc.printStackTrace();

	        }

	    }

	}






