package com.monsanto.enterprise.iimex;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
@Deprecated
public class IIMexdate{

	protected Date mDate;
	
	public IIMexdate(Date aDate)
	throws IIMexException{
		mDate = aDate;	
	}	

	public void setDate(Date aDate)
	throws IIMexException{
		mDate = aDate;
	}

	public Date getDate()
	throws IIMexException{
		return mDate;	
	}	
	public String getDateString() 
	throws IIMexException{
		String stDate="";
		DateFormat dateFormat =new SimpleDateFormat("dd/MM/yyyy");
		stDate=dateFormat.format(mDate);
		return stDate;
				
	}
}