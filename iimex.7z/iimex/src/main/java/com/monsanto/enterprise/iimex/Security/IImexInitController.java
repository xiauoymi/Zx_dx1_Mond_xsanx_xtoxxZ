package com.monsanto.enterprise.iimex.Security;

import java.io.IOException;
import java.util.Locale;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCManager;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.User;
import com.monsanto.security.SecurityServiceException;
public class IImexInitController implements UseCaseController {
	/**
	 *
	 * <p>Title: IImexInitController</p>
	 * <p>Description: Validates and logs on the current user.</p>
	 * <p>Copyright: Copyright (c) 2003</p>
	 * <p>Company: Monsanto</p>
	 * @author Java Framework Code  Generator 2.3
	 * @version $Id: IImexInitController.java,v 1.6 2007/09/13 08:41:55 mmcort3 Exp $
	 */
	
	public static final String USER_NAME_PARAM = "UserName";
	   public static final String PASSWORD_PARAM =  "Password";

	   /**
	    * Runs the code that implements the logon use case.
	    * @param helper a UCCHelper used to perform common UCC tasks
	    * @throws IOException
	    */
	   public void run (UCCHelper helper) throws IOException
	   {
	      Logger.traceEntry();
	      String login = null;
	      //User iIMexUser = null;
	      try {
	    	  helper.clearSession();

	        	 String lang=helper.getRequestParameterValue("language");
	       	  if ( "en".equals(lang) )
	       	    {
	       	    helper.setSessionParameter("userLocale",Locale.ENGLISH);
	       	    }
	       	  else if ( "en-US".equals(lang) )
	       	    {
	       		  helper.setSessionParameter("userLocale",Locale.US);
	       	    }
	       	  
	            login = helper.getAuthenticatedUserID();
	            if(login!=null){
	            	IIMexServlet.iimexUsersManager.checkDatabaseState(login);

	           //	 helper.setSessionParameter("user", iIMexUser);
	           	 UCCManager.runController("com.monsanto.enterprise.iimex.controller.IIMexGeneralController", helper);
	            Logger.traceExit();
	            }
	         }
	    	  
	    	  
	      catch (SecurityServiceException sse) {      // Some sort of database problem
	         Logger.log(new LoggableError("A error occured while logging on the user. " + "The error was: " + sse.toString()));
	         sse.printStackTrace();	
	 		 IIMexMailHelper.send(sse,helper.getAuthenticatedUserFullName());
	 		 helper.redirect("/inside/ExceptionHandler.jsp");

	      } catch (IIMexException exIIMex) {
			Logger.log(new LoggableError("A error occured while init IIMEX. " + "The error was: " + exIIMex.toString()));
	    	exIIMex.printStackTrace();	
			IIMexMailHelper.send(exIIMex,helper.getAuthenticatedUserFullName());
			helper.redirect("/inside/ExceptionHandler.jsp");	
	      } catch (Exception ex){
	    	 Logger.log(new LoggableError("A error occured while init IIMEX. " + "The error was: " + ex.toString()));
	      	 ex.printStackTrace();	
	      	 IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());
	  		 helper.redirect("/inside/ExceptionHandler.jsp");	
	      }
	   } 
	  
}
