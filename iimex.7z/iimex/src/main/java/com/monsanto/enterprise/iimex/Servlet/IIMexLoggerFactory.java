package com.monsanto.enterprise.iimex.Servlet;

import com.monsanto.AbstractLogging.ITraceLog;
import com.monsanto.AbstractLogging.LogDevice;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.Log4JLogging.Log4JDebugLog;
import com.monsanto.Log4JLogging.Log4JErrorLog;
import com.monsanto.Log4JLogging.Log4JFileLogDevice;
import com.monsanto.Log4JLogging.Log4JInfoLog;
import com.monsanto.Log4JLogging.Log4JMidnightRollingFileLogDevice;
import com.monsanto.Log4JLogging.Log4JTraceLog;
import com.monsanto.Log4JLogging.Log4JWarningLog;
import com.monsanto.XMLUtil.DOMUtil;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * <p>Title: IIMexLoggerFactory</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version $Id: IIMexLoggerFactory.java,v 1.2 2007/07/04 08:12:51 nnlahe Exp $
 */
public class IIMexLoggerFactory
{
   private final String m_cstrAppName = "IIMEX";
   private final String m_cstrTraceLogPath;
   private final String m_cstrPbmLogPath;
   private final String m_cstrRollingLogPath;

   public IIMexLoggerFactory()
   {
      String cstrLogFolderName = System.getProperty("catalina.base") + File.separatorChar + "logs";
      m_cstrTraceLogPath   = cstrLogFolderName + File.separatorChar + m_cstrAppName + "Trace.log";
      m_cstrPbmLogPath = cstrLogFolderName + File.separatorChar + m_cstrAppName + ".log";
      m_cstrRollingLogPath = cstrLogFolderName +File.separatorChar+m_cstrAppName + "RollingLog.log";
   }

   public synchronized void setupLogging () throws IOException,
                                                   LogRegistrationException
   { 
      LogDevice traceAndDebugFile = new Log4JFileLogDevice(m_cstrTraceLogPath);

      Logger.enableLogger(Logger.TRACE_LOG);
      Logger.register(new Log4JInfoLog   (m_cstrAppName, traceAndDebugFile));
      Logger.register(new Log4JTraceLog(m_cstrAppName, traceAndDebugFile)); 
      Logger.register(new Log4JDebugLog (m_cstrAppName, traceAndDebugFile));
      
      LogDevice problemsFile = new Log4JFileLogDevice(m_cstrPbmLogPath); 
      Logger.register(new Log4JErrorLog(m_cstrAppName, problemsFile)); //error & fatal
      Logger.register(new Log4JWarningLog(m_cstrAppName, problemsFile)); 
      
      Logger.traceExit();
   
   }

   public Document toXML()
   {
      Logger.traceEntry();

      Document logDocument = DOMUtil.newDocument();
      Element rootElement = DOMUtil.addChildElement(logDocument, "LOGS");
      insertXML(rootElement);

      return (Document) Logger.traceExit(logDocument);
   }

   public void insertXML(Element parentElement)
   {
      Logger.traceEntry();

      try {
         addLogDeviceToXmlDocument(parentElement, "Rolling Log (Text)", m_cstrRollingLogPath);
         addLogDeviceToXmlDocument(parentElement, "Trace Log", m_cstrTraceLogPath);
      }
      catch (UnsupportedEncodingException uee) {
         Logger.log(new LoggableError(uee));
      }

      Logger.traceExit();
   }

   private void addLogDeviceToXmlDocument(Element parentElement, String deviceName, String filePath)
         throws UnsupportedEncodingException
   {
      Logger.traceEntry();

      if (filePath != null && (!filePath.trim().equals(""))) {
         Element deviceElement = DOMUtil.addChildElement(parentElement, "LOG_DEVICE");
         DOMUtil.addChildElement(deviceElement, "DEVICE_NAME", deviceName);
         DOMUtil.addChildElement(deviceElement, "LOCATION", URLEncoder.encode(filePath, "UTF-8"));
      } else {
         throw new IllegalArgumentException("filePath argument cannot be null, blank, or empty.");
      }

      Logger.traceExit();
   }
}

