package com.monsanto.enterprise.iimex.Servlet;

import com.monsanto.AbstractLogging.LogRegistrationException;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.KerberosServletSecurity.KerberosSecurity;
import com.monsanto.ServletFramework.GatewayServlet;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UCCServletHelper;
import com.monsanto.dataservices.PersistentStore;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.UserManager;
import com.monsanto.Util.Exceptions.WrappingException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;



/**
 * <p>Title: IIMexServlet</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 *
 * @author Java Framework Code  Generator 2.3
 */
public class IIMexServlet extends GatewayServlet

{
    public static final String s_cstrResourceBundle = "com.monsanto.enterprise.iimex.Servlet.IIMex";
    public static UserManager iimexUsersManager;

    public IIMexServlet() throws IOException {
        super();
    }

    /**
     * Init the log configuration.
     * Init the UserManager value. UserManager contains the hashTable with all the DB datas.
     */
    public void init(ServletConfig servletConfig) throws ServletException {
        super.init(servletConfig);

        Logger.traceEntry();

        try {
            if (iimexUsersManager == null) {
                IIMexLoggerFactory loggerFactory = new IIMexLoggerFactory();
                loggerFactory.setupLogging();
                iimexUsersManager = new UserManager();
            }

        }
        catch (LogRegistrationException lre) {
            lre.printStackTrace();
            throw new ServletException(lre.toString());
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
            throw new ServletException(ioe.toString());
        } catch (IIMexException de) {
            de.printStackTrace();
            throw new ServletException(de.toString());
        }

        Logger.traceExit();

    }

    public void destroy() {
        Logger.traceEntry();

        try {
            PersistentStore.registerInstance(null);
        }
        catch (WrappingException e) {
        }

        super.destroy();

        Logger.traceExit();
    }

    /**
     * This static method will create an instance of the desired PersistentStore based on
     * data within a property file.
     *
     * @param request  - The HttpServlet Request from the servlet container
     * @param response - The HttpServletResponse to be sent back to the servlet container.
     * @throws java.io.IOException
     * @throws javax.servlet.ServletException
     */
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {

        Logger.traceEntry();
        KerberosSecurity proxy = new KerberosSecurity();
        proxy.init(request);
        UCCHelper helper = new UCCServletHelper(getServletConfig(), request, response, true, proxy);

        /*  Pass the doGet along.   */
        super.doPost(request, response);


        Logger.traceExit();
    }
}

