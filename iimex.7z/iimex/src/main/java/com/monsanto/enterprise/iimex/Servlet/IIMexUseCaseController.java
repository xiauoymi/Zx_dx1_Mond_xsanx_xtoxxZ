package com.monsanto.enterprise.iimex.Servlet;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.security.SecureUser;

import java.io.IOException;

/**
 * <p>Title: IIMexUseCaseController</p>
 * <p>Description:
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
  */
public abstract class IIMexUseCaseController implements UseCaseController
{
   protected boolean checkForTimeout(UCCHelper helper) throws IOException
   {
      Logger.traceEntry();

      boolean boolRetVal = false;

      SecureUser loggedOnUser = (SecureUser)helper.getSessionParameter(I_SessionParams.sf_cstrCURRENT_USER);
      if (loggedOnUser == null) {
         boolRetVal = true;

         DisplaySessionTimeout.displayTimeoutMessage(helper.getPrintWriter());
      }

      return Logger.traceExit(boolRetVal);
   }
}

