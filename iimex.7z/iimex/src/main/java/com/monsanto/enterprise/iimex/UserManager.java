package com.monsanto.enterprise.iimex;


import java.util.*;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.collections.*;
import com.monsanto.enterprise.iimex.tableloader.TableDBState;
import com.monsanto.enterprise.iimex.elements.IIMEXObjectVersion;


/**
 * UserManager init all the objects and check the db status.
 * <p/>
 * Filename:    $RCSfile: UserManager.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 *
 * @author MMCORT3
 * @version $Revision: 1.28 $
 */
public class UserManager {

    /**
     * Collections objects
     */
    private CustomZoneCollection zonesCollection = null;
    private WorldAreaCollection areasCollection = null;
    private CountryCollection countriesCollection = null;
    private OrderTypeCollection ordersCollection = null;
    private CountryToCountryCollection countriesToCountriesCollection = null;
    private CurrencyCollection currenciesCollection = null;
    private CompaniesCollection companiesCollection = null;
    private contactTypeCollection contactsTypeCollection = null;
    private ContactsCollection contactsCollection = null;
    private PlantsCollection plantsCollection = null;
    private ProductCollection productsCollection = null;
    private TraitCollection traitCollection = null;
    private IncotermsTransportCollection incotermsTransportCollection = null;
    private DocumentCollection documentsCollection = null;
    private LinkCollection linkCollection = null;
    private TableDBState dbState = null;
    private MonitoredUserCollection userColl = null;
    private UpdateCollection updCollection = null;
    private DivisionCollection divisionCollection = null;
    private ImportDutiesCollection dutiesCollection = null;
    private PhytoRequirementCollection phytoCollection = null;
    private ShipRestrictTypeCollection shipRestrictTypeCollection = null;
    protected HashMap<String, IIMEXObjectVersion> objectVersions;

    /**
     * Properties
     */
    private static String bundle = "com.monsanto.enterprise.iimex.Servlet.IIMex";
    private static ResourceBundle errorBundle = null;
    private static ResourceBundle propertiesBundle = null;



    /**
     * Create all the collections and init the objects.
     *
     * @throws IIMexException
     */
    public UserManager() throws IIMexException {

        Logger.traceEntry();

        errorBundle = ResourceBundle.getBundle(bundle);

        propertiesBundle = ResourceBundle.getBundle(bundle);
        dbState = new TableDBState();
        areasCollection = new WorldAreaCollection();
        zonesCollection = new CustomZoneCollection();
        countriesCollection = new CountryCollection();
        companiesCollection = new CompaniesCollection();
        contactsTypeCollection = new contactTypeCollection();
        countriesToCountriesCollection = new CountryToCountryCollection();
        currenciesCollection = new CurrencyCollection();
        divisionCollection = new DivisionCollection();
        productsCollection = new ProductCollection();
        traitCollection = new TraitCollection();
        incotermsTransportCollection = new IncotermsTransportCollection();
        plantsCollection = new PlantsCollection();
        ordersCollection = new OrderTypeCollection();
        contactsCollection = new ContactsCollection();
        dutiesCollection = new ImportDutiesCollection();
        phytoCollection = new PhytoRequirementCollection();
        documentsCollection = new DocumentCollection();
        linkCollection = new LinkCollection();
        shipRestrictTypeCollection = new ShipRestrictTypeCollection();

        init();

        Logger.traceExit();

    }


    /**
     * Pre-fetch all the DB values in differents objects that will be stocked in the collections
     */

    protected void init() throws IIMexException {
        Logger.traceEntry();
        dbState.initDBState();
        zonesCollection.loadTable();
        companiesCollection.loadTable();
        areasCollection.loadTable();
        divisionCollection.loadTable();
        incotermsTransportCollection.loadTable();
        currenciesCollection.loadTable();
        productsCollection.loadTable();
        traitCollection.loadTable();
        countriesCollection.loadTable(companiesCollection, zonesCollection, areasCollection, productsCollection);
        plantsCollection.loadTable(companiesCollection, countriesCollection);
        ordersCollection.loadTable();
        contactsTypeCollection.loadTable();
        contactsCollection.loadTable(countriesCollection, contactsTypeCollection);
        dutiesCollection.loadTable();
        phytoCollection.loadTable();
        documentsCollection.loadTable();
        shipRestrictTypeCollection.loadTable();
        countriesToCountriesCollection.loadTable(countriesCollection, incotermsTransportCollection);
        linkCollection.loadTable();
        refreshDocumentsCollection();
        objectVersions = dbState.loadVersions();
        Logger.traceExit();
    }


    /**
     * Reload data from the DB
     *
     * @throws IIMexException
     */
    private void reload() throws IIMexException {
        Logger.traceEntry();
        refreshCollections();
        Logger.traceExit();
    }


    public ResourceBundle getErrorBundle() {

        return errorBundle;

    }

    private void refreshDocumentsCollection() throws IIMexException {
        documentsCollection.setDocumentRequirementCountryName(countriesCollection, zonesCollection);
        reloadDocumentRequirementProductName();
        documentsCollection.setDocumentRequirementTransport(incotermsTransportCollection);
    }

    private synchronized void refreshCollections() throws IIMexException {
        dbState.loadServerObjectVersions(objectVersions);
        IIMEXObjectVersion objectVersion;
        for (String str : CollectionsChangeMonitor.collectionsUpdateOrder) {
            objectVersion = objectVersions.get(str);
            System.out.println("str = " + str);
            if (objectVersion.hasChanged()) {
                reloadCollection(objectVersion, objectVersions.get("countries_collection"));
                objectVersion.refresh();
            }
        }
    }

    private void reloadCollection(IIMEXObjectVersion iimexObjectVersion,
                                  IIMEXObjectVersion countryCollectionObjectVersion) throws IIMexException {
        if ("zones_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            zonesCollection.reload();
            countryCollectionObjectVersion.forceReload();
        } else if ("companies_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            companiesCollection.reload();
            countryCollectionObjectVersion.forceReload();
        } else if ("areas_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            areasCollection.reloadTable();
            countryCollectionObjectVersion.forceReload();
        } else if ("divisions_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            divisionCollection.reload();
            reloadDocumentRequirementProductName();
        } else if ("incoterms_transport_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            incotermsTransportCollection.reload();
            countriesToCountriesCollection.loadTable(countriesCollection, incotermsTransportCollection);
            documentsCollection.setDocumentRequirementTransport(incotermsTransportCollection);
        } else if ("currencies_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            currenciesCollection.reload();
        } else if ("products_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            productsCollection.reload();
            countryCollectionObjectVersion.forceReload();
        } else if ("traits_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            traitCollection.reload();
            reloadDocumentRequirementProductName();
        } else if ("countries_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            refreshCountriesCollection();
        } else if ("plants_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            plantsCollection.loadTable(companiesCollection, countriesCollection);
        } else if ("orders_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            ordersCollection.reload();
        } else if ("contacts_type_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            contactsTypeCollection.reload();
            contactsCollection.loadTable(countriesCollection, contactsTypeCollection);
        } else if ("contacts_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            contactsCollection.loadTable(countriesCollection, contactsTypeCollection);
        } else if ("duties_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            dutiesCollection.reload();
        } else if ("phyto_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            phytoCollection.reload();
        } else if ("documents_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            documentsCollection.reload();
            refreshDocumentsCollection();
        } else if ("links_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            linkCollection.loadTable();
        } else if ("countries_to_countries_collection".equalsIgnoreCase(iimexObjectVersion.getObjectId())) {
            countriesToCountriesCollection.loadTable(countriesCollection, incotermsTransportCollection);
        } else {
            throw new IIMexException("invalid object configuration!: " + iimexObjectVersion.getObjectId());
        }
    }

    private void reloadDocumentRequirementProductName() throws IIMexException {
        documentsCollection.setDocumentRequirementProductName(productsCollection, divisionCollection, traitCollection);
    }

    private void refreshCountriesCollection() throws IIMexException {
        countriesCollection.reload(companiesCollection, zonesCollection, areasCollection, productsCollection);
        plantsCollection.loadTable(companiesCollection, countriesCollection);
        contactsCollection.loadTable(countriesCollection, contactsTypeCollection);
        countriesToCountriesCollection.loadTable(countriesCollection, incotermsTransportCollection);
        refreshDocumentsCollection();
    }

    public ResourceBundle getPropertiesBundle() {

        return propertiesBundle;

    }


    public void setErrorBundle(ResourceBundle errorBundle) {

        UserManager.errorBundle = errorBundle;

    }


    public ContactsCollection getContactCollection()
            throws IIMexException {
        return contactsCollection;
    }

    public WorldAreaCollection getWorldAreaCollection()
            throws IIMexException {
        return areasCollection;
    }

    public contactTypeCollection getContactTypeCollection()
            throws IIMexException {
        return contactsTypeCollection;
    }

    public ShipRestrictTypeCollection getShipmentRestrictionTypeCollection()
            throws IIMexException {
        return shipRestrictTypeCollection;
    }

    public PhytoRequirementCollection getPhytoRequirementCollection()
            throws IIMexException {
        return phytoCollection;
    }

    public ImportDutiesCollection getImportDutiesCollection() {
        return dutiesCollection;
    }

    public CountryCollection getCountryCollection()
            throws IIMexException {
        return countriesCollection;
    }

    public CompaniesCollection getCompaniesCollection()
            throws IIMexException {
        return companiesCollection;
    }

    public CountryToCountryCollection getCountryToCountryCollection()
            throws IIMexException {
        return countriesToCountriesCollection;
    }

    public OrderTypeCollection getOrderTypeCollection()
            throws IIMexException {
        return ordersCollection;
    }

    public CustomZoneCollection getCustomZonesCollection()
            throws IIMexException {
        return zonesCollection;
    }

    public MonitoredUserCollection getMonitoredUserCollection()
            throws IIMexException {
        userColl.loadTable();
        return userColl;
    }

    public DivisionCollection getDivisionCollection()
            throws IIMexException {
        return divisionCollection;
    }

    public UpdateCollection getUpdateCollection()
            throws IIMexException {
        updCollection.loadTable();
        return updCollection;
    }

    public CurrencyCollection getCurrencyCollection()
            throws IIMexException {
        return currenciesCollection;
    }

    public PlantsCollection getPlantsCollection()
            throws IIMexException {
        return plantsCollection;
    }

    public IncotermsTransportCollection getIncotermsTransportCollection()
            throws IIMexException {
        return incotermsTransportCollection;

    }

    public TraitCollection getTraitCollection()
            throws IIMexException {
        return traitCollection;
    }

    public DocumentCollection getDocuments()
            throws IIMexException {
        return documentsCollection;
    }

    public ProductCollection getProducts()
            throws IIMexException {
        return productsCollection;
    }

    public LinkCollection getLinks()
            throws IIMexException {
        return linkCollection;
    }

    public void checkDatabaseState(String login)
            throws IIMexException {
        reload();
        dbState.updateDBwithUser(login);

    }

    /**
     * Get the version list
     *
     * @return
     * @throws IIMexException
     */
    public HashMap getVersionList()
            throws IIMexException {
        Logger.traceEntry();
        Logger.traceExit();
        return dbState.getHmVersionMng();
    }

    public List getVersionColumName()
            throws IIMexException {
        Logger.traceEntry();
        Logger.traceExit();
        return dbState.getFieldList();
    }

    public void updateDBstatus()
            throws IIMexException {
        Logger.traceEntry();
        reload();
        Logger.traceExit();

    }
}



