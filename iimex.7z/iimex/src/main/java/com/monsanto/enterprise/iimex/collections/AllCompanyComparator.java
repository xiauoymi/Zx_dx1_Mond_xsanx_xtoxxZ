package com.monsanto.enterprise.iimex.collections;



import java.util.Comparator;

import com.monsanto.enterprise.iimex.elements.Company;
import com.monsanto.enterprise.iimex.elements.Country;
//compare two companies usign their code
public class AllCompanyComparator implements Comparator<Company>{

	public int compare(Company a_Object1, Company a_Object2){
	try{
		return a_Object1.getCompanyCode().compareTo(a_Object2.getCompanyCode());
	}catch (Exception ex) {
		return 0;
	}
	
	}	
}