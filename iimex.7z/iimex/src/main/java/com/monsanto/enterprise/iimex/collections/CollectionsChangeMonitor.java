package com.monsanto.enterprise.iimex.collections;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Oct 12, 2009
 * Time: 1:33:19 PM
 * To change this template use File | Settings | File Templates.
 */
public class CollectionsChangeMonitor {
    public static boolean countriesCollectionsChanged;
    public static boolean countryToCountryCollectionChanged;
    public static boolean plantsCollectionChanged;
    public static boolean documentsCollectionChanged;
    public static boolean contactsTypeCollectionChanged;
    public static boolean incotermsTransportCollectionChanged;
    public static boolean divisionCollectionChanged;
    public static boolean traitsCollectionChanged;
    public static boolean contactsCollectionChanged;
    public static boolean zonesCollectionsChanged;

    public static String[] collectionsUpdateOrder = {
            "zones_collection",
            "companies_collection",
            "areas_collection",
            "products_collection",
            "countries_collection",            
            "contacts_collection",
            "contacts_type_collection",
            "documents_collection",
            "plants_collection",
            "divisions_collection",
            "incoterms_transport_collection",
            "currencies_collection",
            "traits_collection",
            "orders_collection",
            "duties_collection",
            "phyto_collection",
            "links_collection"
    };


    /*

      Note public static boolean zonesCollectionsChanged;that the scheduling is not fair. it could lead to starvation but in web application
      environments this is highly unlikely.. just so we are all clear.

     */

    public static AtomicInteger[] userManagerFakeSemaphor = new AtomicInteger[16];


    public static void requestDatabaseAccess(int i){
        while(!userManagerFakeSemaphor[i].compareAndSet(0,1)){
            try {
                userManagerFakeSemaphor[i].wait();
            } catch (InterruptedException e) {
                Logger.log(new LoggableError(e));
            }
        }
    }


    public static void releaseDatabaseAccess(int i){
        userManagerFakeSemaphor[i].set(0);
        userManagerFakeSemaphor[i].notify();
    }

}
