/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.collections;

import java.util.Collections;
import java.util.Iterator;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.Company;
import com.monsanto.enterprise.iimex.tableloader.TableLoadCompanies;
import com.monsanto.enterprise.iimex.tableloader.TableLoader;

/**
 * All companies collection.
 * 
 * Filename:    $RCSfile: CompaniesCollection.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 * @version     $Revision: 1.10 $
 * @author      MMCORT3
 */

public class CompaniesCollection extends TableLoader{

	private Vector<Company> companies=null;

	private TableLoadCompanies companyLoadData = new TableLoadCompanies();

/**Load all the company data (company code, company name) in the Vector companies
 * 
 * @throws IIMexException
 */

public void loadTable()throws IIMexException{
	Logger.traceEntry();
	companies =companyLoadData.loadCompanies();
	Logger.traceExit();
}

/**
 * Reload the company data in the Vector companies
 * @throws IIMexException
 */

public void reload()throws IIMexException{
	Logger.traceEntry();
	loadTable();
	Logger.traceExit();
}

/**
 * Get the company using its code
 * @return a Company
 * @throws IIMexException
 */

public Company getCompanyByCode(String companyCode) throws IIMexException {
	Logger.traceEntry();
	 for(int i=0;i<companies.size();i++){
        if (companyCode.equals(companies.get(i).getCompanyCode())){
            return companies.get(i);
        }
    }
	Logger.traceExit();
	return new Company();
}

/**
 * Get all the company
 * @return a Vector with all the company
 * @throws IIMexException
 */

public Vector<Company> getAllCompany() throws IIMexException {
	Logger.traceEntry();
	return companies;
}
/**
 * Get all the company ordered
 */
public Vector getAllCompanyOrdered() throws IIMexException {
	Logger.traceEntry();
	Vector<Company> result = new Vector<Company>();
	result.addAll(companies);
	return result;
}
/**
 * Get all the company code
 */
public Vector<Company> getAllCompanyCode() throws IIMexException {
	Logger.traceEntry();
	Vector<Company> Result = new  Vector<Company>();
	for(int i=0;i< companies.size();i++){
		Result.add(companies.get(i));
	}
	return Result;
}

/**
 * Get the company name using the company code
 * @return a String
 * @throws IIMexException
 */

public String getCompanyName(String companyCode) throws IIMexException{
	if(companyCode!=null){
    for(int i=0;i<companies.size();i++){
        if (companyCode.equals(companies.get(i).getCompanyCode())){
            return companies.get(i).getCompanyName();
        }
    }
    }
	return "";
}

}

	

