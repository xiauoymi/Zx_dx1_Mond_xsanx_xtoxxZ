/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.collections;

import java.util.HashMap;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.CountryFrom;
import com.monsanto.enterprise.iimex.tableloader.TableLoadContacts;
import com.monsanto.enterprise.iimex.tableloader.TableLoader;

/**
 * Contact object collection.
 * 
 * Filename:    $RCSfile: ContactsCollection.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 * @version     $Revision: 1.10 $
 * @author      MMCORT3
 */

public class ContactsCollection extends TableLoader{

	private Vector<Contacts> contacts=null;

	private TableLoadContacts contactLoadData = new TableLoadContacts();

/**Load all the contact data (contact code, contact type, contact name, address, tel, fax,
 * gsm, mail, division, attached country) in the hashMap contacts (key:country code, value Contact)
 * 
 * @throws IIMexException
 */

public void loadTable(CountryCollection coll,contactTypeCollection coll2)throws IIMexException{
	Logger.traceEntry();
	contacts = contactLoadData.loadContacts(coll,coll2);
	Logger.traceExit();
}

/**
 * Reload the contact data in the hashMap contact
 * @throws IIMexException
 */

public synchronized  void reload(CountryCollection coll,contactTypeCollection coll2)throws IIMexException{
	Logger.traceEntry();	
	loadTable(coll,coll2);
	Logger.traceExit();
}
//retrieve a contact using its code
public Contacts getContactByCode(String Code) throws IIMexException {
	Logger.traceEntry();
	Contacts tmp;
	for(int i=0;i<contacts.size();i++){
		tmp = contacts.get(i);
		if(tmp.getContactCode()==Integer.parseInt(Code))
			return tmp;
	}
	return new Contacts();
}

/**
 * Get a vector with all the contact for a specific country and division
 * @return a Vector
 * @throws IIMexException
 */

public Vector<Contacts> getContactByCountryAndDivision(String CodeCountry, String Division) throws IIMexException {
	Logger.traceEntry();
	Vector<Contacts> result = new Vector<Contacts>();
	Contacts tmp;
	for(int i=0;i<contacts.size();i++){
		tmp = contacts.get(i);
		if(tmp.getCountries().containsKey(CodeCountry))
			if(((HashMap)tmp.getCountries().get(CodeCountry)).containsKey(Division)){
				result.add(tmp);
			}
	}
	return result;
}
/**
 * Get a vector with all the shipping contact for a specific country and division
 * @return a Vector
 * @throws IIMexException
 */

public Vector<Contacts> getContactByCountryAndDivisionAndFrom(String CodeCountry, String Division,String From) throws IIMexException {
	Logger.traceEntry();
	Vector<Contacts> result = new Vector<Contacts>();
	Contacts tmp;
	for(int i=0;i<contacts.size();i++){
		tmp = contacts.get(i);
		if(tmp.getCountries().containsKey(CodeCountry))
			if(((HashMap)tmp.getCountries().get(CodeCountry)).containsKey(Division))
				if(((HashMap)((HashMap)tmp.getCountries().get(CodeCountry)).get(Division)).containsKey(From)){
					result.add(tmp);
			}
	}
	return result;
}
/*
 * manage contacts and their country in the database
 */
public int addContact(Contacts cont) throws IIMexException{
	Logger.traceEntry();
	int addOK = 0;
	addOK = contactLoadData.addContact(cont);
    CollectionsChangeMonitor.contactsCollectionChanged=true;
	Logger.traceExit();
	return addOK;
}

public int removeContact(int contactCode) throws IIMexException{
	Logger.traceEntry();
	int removeOK = 0;
	removeOK = contactLoadData.removeContact(contactCode);
    CollectionsChangeMonitor.contactsCollectionChanged=true;
	Logger.traceExit();
	return removeOK;
}


public int updateContact(Contacts cont) throws IIMexException{
	Logger.traceEntry();
	int updateOK = 0;
	updateOK = contactLoadData.updateContact(cont);
    CollectionsChangeMonitor.contactsCollectionChanged=true;
	Logger.traceExit();
	return updateOK;
}

public int addContactCountry(CountryFrom cf,String contactCode) throws IIMexException{
	Logger.traceEntry();
	int addOK = 0;
	addOK = contactLoadData.addContactCountry(cf, contactCode);
    CollectionsChangeMonitor.contactsCollectionChanged=true;
	Logger.traceExit();
	return addOK;
}

public int updateContactCountry(CountryFrom cf,String contactCode) throws IIMexException{
	Logger.traceEntry();
	int updateOk = 0;
	updateOk = contactLoadData.updateContactCountry(cf, contactCode);
    CollectionsChangeMonitor.contactsCollectionChanged=true;
	Logger.traceExit();
	return updateOk;
}

public int removeContactCountry(String code, String country, String division, String fromCode) throws IIMexException{
	Logger.traceEntry();
	int removeOK = 0;
	removeOK = contactLoadData.removeContactCountry(code,country,division, fromCode);
    CollectionsChangeMonitor.contactsCollectionChanged=true;
	Logger.traceExit();
	return removeOK;
}

/**
 * Get all the contacts
 * @return a Vector
 * @throws IIMexException
 */

public Vector<Contacts> getAllCntacts() throws IIMexException {
	Logger.traceEntry();
	return contacts;
}
//get all contacts for a specific country
public Vector<Contacts> getAllContactsByCountry(String countryCode) throws IIMexException {
	Logger.traceEntry();
	Vector<Contacts> result = new Vector<Contacts>();
	Contacts cont;
	for(int i=0;i<contacts.size();i++){
		cont = contacts.get(i);
		if(cont.getCountryCode().compareTo(countryCode)==0)
			result.add(cont);
	}
		
	return result;
}

}

	

