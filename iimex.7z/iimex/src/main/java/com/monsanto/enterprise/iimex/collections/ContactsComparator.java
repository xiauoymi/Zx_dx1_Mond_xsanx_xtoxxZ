package com.monsanto.enterprise.iimex.collections;

import java.util.Comparator;

import com.monsanto.enterprise.iimex.elements.Contacts;
//compare two contacts using their country code
public class ContactsComparator implements Comparator<Contacts>{

	public int compare(Contacts a_Object1, Contacts a_Object2){
	try{
		return a_Object1.getCountry().compareTo(a_Object2.getCountry());
	}catch (Exception ex) {
		return 0;
	}
	
	}	
}