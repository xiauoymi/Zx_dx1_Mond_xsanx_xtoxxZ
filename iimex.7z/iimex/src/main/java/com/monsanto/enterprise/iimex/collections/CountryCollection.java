/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.collections;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.*;
import com.monsanto.enterprise.iimex.tableloader.TableLoadCountries;
import com.monsanto.enterprise.iimex.tableloader.TableLoader;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

/**
 * All country object collection.
 * 
 * Filename:    $RCSfile: CountryCollection.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 * @version     $Revision: 1.21 $
 * @author      MMCORT3
 */

public class CountryCollection extends TableLoader{

	private HashMap<String, Country> hmCountry=null;

	private TableLoadCountries countryLoadData = new TableLoadCountries();

/**Load all the country data (country name, custom zone code, custom zone name, world area code, world area name, shipping instructions, fees,
 * value added tax, company determination and import license approval) in the hashMap hmCountry (key:country code, value Country)
 * 
 * @throws IIMexException
 */
	
public void loadTable(CompaniesCollection companiesCollection, CustomZoneCollection zoneCollection, WorldAreaCollection areaCollection,ProductCollection pc)throws IIMexException{
	Logger.traceEntry();
	hmCountry = countryLoadData.loadCountries(companiesCollection, zoneCollection,areaCollection,pc);
	Logger.traceExit();
}

/**
 * Reload the country data in the hashMap hmCountry
 * @throws IIMexException
 */

public void reload(CompaniesCollection companiesCollection, CustomZoneCollection zoneCollection, WorldAreaCollection areaCollection,ProductCollection pc)throws IIMexException{
	Logger.traceEntry();
	loadTable(companiesCollection, zoneCollection, areaCollection,pc);
	Logger.traceExit();
}

/**
 * Get a country using its code
 * @return a Country
 * @throws IIMexException
 */

public Country getCountryByCode(String strCodeFromCountry) throws IIMexException {
	Logger.traceEntry();
	Country oCountry = hmCountry.get(strCodeFromCountry);
	Logger.traceExit();
	return oCountry;
}

/**
 * Get all the country
 * @return a List with all the country ordered asc
 * @throws IIMexException
 */

public Vector getAllCountry() throws IIMexException {
	Logger.traceEntry();
	Vector vResult = new Vector();
	Iterator it = hmCountry.values().iterator();
    Country oCountry;
	while (it.hasNext()) {
		oCountry = (Country) it.next();
		vResult.addElement(oCountry);
	}
	AllCountryComparator oCountryComparator = new AllCountryComparator();
	Collections.sort(vResult, oCountryComparator);
	Logger.traceExit();
	return vResult;
	
}

/**
 * Get all the active country
 * @return a List with all the country ordered asc
 * @throws IIMexException
 */

public Vector getAllActiveCountry() throws IIMexException {
	Logger.traceEntry();
	Vector vResult = new Vector();
	Iterator it = hmCountry.values().iterator();
	while (it.hasNext()) {
		Country oCountry = (Country) it.next();
		if(oCountry.getActive())
			vResult.addElement(oCountry);
	}
	AllCountryComparator oCountryComparator = new AllCountryComparator();
	Collections.sort(vResult, oCountryComparator);
	Logger.traceExit();
	return vResult;
}
//manage countries in the base
public int addCountry(Country coun) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = countryLoadData.addCountry(coun);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return addOk;
}

public int updateCountry(Country coun) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = countryLoadData.updateCountry(coun);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return updateOk;
}

public int removeCountry(String countryCode) throws IIMexException{
	Logger.traceEntry();
	int removeOk=-1;
	removeOk = countryLoadData.removeCountry(countryCode);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return removeOk;
}

/**
 * Get the name of a country using its code
 * @return a String
 * @throws IIMexException
 */

public String getCountryName(String countryCode) throws IIMexException{
    Object matchingCountryName = hmCountry.get(countryCode);
    if(matchingCountryName !=null)
		return (hmCountry.get(countryCode)).getCountryName();
	return "false";
}
/*
 * manage the custom clearance fees of a specific country in the base
 */
public int addClearanceFee(ClearanceFee cf, String country)	throws IIMexException{
	Logger.traceEntry();
	int rowUpdate=-1;
	rowUpdate = countryLoadData.addClearanceFee(cf, country);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return rowUpdate;	
}

public int updateClearanceFee(ClearanceFee cf, String country)	throws IIMexException{
	Logger.traceEntry();
	int rowUpdate=-1;
	rowUpdate = countryLoadData.updateClearanceFee(cf, country);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return rowUpdate;	
}
/*
 * manage the taxes information  of a specific country in the base
 */
public int addTax(ValueAddedTax tax, String code) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = countryLoadData.addTax(tax, code);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return addOk;
}

public int updateTax(ValueAddedTax tax, String code) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = countryLoadData.updateTax(tax, code);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return updateOk;
}

public int removeTax(String countryCode, String codePg) throws IIMexException{
	Logger.traceEntry();
	int removeOk=-1;
	removeOk = countryLoadData.removeTax(countryCode, codePg);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return removeOk;
}
/*
 * manage the shipping instructions of a specific country in the base
 */
public int addInstruction(ShippingInstruction ship, String code) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
    if (hasDupInstructionInCache(ship, code)) {
        throw new IIMexEntityCollisionException("Duplicate Destination Country-Division combination already found:"
                + getCountryByCode(code).getCountryName() + "-" + ship.getDivision() + ". Please update existing entry.");
    }
	addOk = countryLoadData.addInstruction(ship, code);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return addOk;
}

private boolean hasDupInstructionInCache(ShippingInstruction newInstruction, String countryCode) {
    Country ctry = hmCountry.get(countryCode);
    if (ctry != null) {
        ShippingInstruction instruction = ctry.getInstruction(newInstruction.getDivision());
        return (instruction != null && instruction.getDivision().equals(newInstruction.getDivision()));
    }
    return false;
}

public int updateInstruction(ShippingInstruction ship, String code) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = countryLoadData.updateInstruction(ship, code);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return updateOk;
}

public int removeInstruction(String country, String division) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = countryLoadData.removeInstruction(country, division);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return updateOk;
}
/*
 * manage the fees of a specific country in the base
 */
public int addFees(Fees fee, String code, String shipping) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = countryLoadData.addFees(fee, code, shipping);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return addOk;
}

public int updateFees(Fees fee, String code, String shipping) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = countryLoadData.updateFees(fee, code, shipping);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return updateOk;
}
/*
 * manage the custom clearance time of a specific country in the base
 */
public int addClearanceTime(ClearanceTime cf, String country)	throws IIMexException{
	Logger.traceEntry();
	int rowUpdate=-1;
	rowUpdate = countryLoadData.addTime(cf, country);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return rowUpdate;	
}

public int updateClearanceTime(ClearanceTime cf, String country)	throws IIMexException{
	Logger.traceEntry();
	int rowUpdate=-1;
	rowUpdate = countryLoadData.updateTime(cf, country);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return rowUpdate;	
}
/*
 * manage the import license approval information of a specific country in the base
 */
public int addLicense(ImportLicenseApproval app, String code,String hts) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = countryLoadData.addLicense(app, code,hts);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return addOk;
}

public int updateLicense(ImportLicenseApproval app, String code,String hts) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = countryLoadData.updateLicense(app, code,hts);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return updateOk;
}

public int removeLicense(String code, String hts) throws IIMexException{
	Logger.traceEntry();
	int removeOk=-1;
	removeOk = countryLoadData.removeLicense(code, hts);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return removeOk;
}
/*
 * manage the companies of a specific country in the base
 */
public int addCompany(CompanyDetermination cd, String code) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = countryLoadData.addCompany(cd, code);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return addOk;
}

public int updateCompany(CompanyDetermination cd, String code) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = countryLoadData.updateCompany(cd, code);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return updateOk;
}

public int removeCompany(CompanyDetermination cd, String code) throws IIMexException{
	Logger.traceEntry();
	int removeOk=-1;
	removeOk = countryLoadData.removeCompany(cd, code);
    CollectionsChangeMonitor.countriesCollectionsChanged=true;
	Logger.traceExit();
	return removeOk;
}

}

	

