package com.monsanto.enterprise.iimex.collections;



import java.util.Comparator;

import com.monsanto.enterprise.iimex.elements.Country;
/*
 * used to compare two countries using their names
 */
public class CountryComparator implements Comparator<Country>{

	public int compare(Country a_Object1, Country a_Object2){
	try{
		return a_Object1.getCountryName().compareTo(a_Object2.getCountryName());
	}catch (Exception ex) {
		return 0;
	}
	
	}	
}
