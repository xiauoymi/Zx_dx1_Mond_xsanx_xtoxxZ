/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.collections;

import java.util.*;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.CountryToCountry;
import com.monsanto.enterprise.iimex.elements.PreferredPort;
import com.monsanto.enterprise.iimex.elements.ShippingRestriction;
import com.monsanto.enterprise.iimex.elements.TransportationTime;
import com.monsanto.enterprise.iimex.tableloader.TableLoadCountryToCountry;
import com.monsanto.enterprise.iimex.tableloader.TableLoader;

/**
 * All country country object collection.
 * 
 * Filename:    $RCSfile: CountryToCountryCollection.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 * @version     $Revision: 1.7 $
 * @author      MMCORT3
 */

public class CountryToCountryCollection extends TableLoader{

	private List<CountryToCountry> countryToCountryList = null;

	private TableLoadCountryToCountry countryToCountryLoadData = new TableLoadCountryToCountry();

    /**
     * Exists only for testing
     */
    protected void setCountryToCountryList(List<CountryToCountry> cToCList) {
        countryToCountryList = cToCList;
    }

    /**Load all the countryToCountry data (shipping code, destination code, preffered port of entry, transportation time and restrictions)
 * in the Vector countryToCountryList
 * @throws IIMexException
 */

public void loadTable(CountryCollection countriesCollection, IncotermsTransportCollection incoTpColl)throws IIMexException{
	Logger.traceEntry();
	countryToCountryList =countryToCountryLoadData.loadCountriesToCountries(countriesCollection, incoTpColl);
	Logger.traceExit();
}

/**
 * Reload the countryToCountry data in the Vector countryToCountryList
 * @throws IIMexException
 */

public void reload(CountryCollection countriesCollection, IncotermsTransportCollection incoTpColl)throws IIMexException{
	Logger.traceEntry();
	loadTable(countriesCollection, incoTpColl);
	Logger.traceExit();
}

/**
 * retrieve a countryToCountry using the shipping code and the destination one 
 * @return a countryToCountry object
 * @throws IIMexException
 */

public CountryToCountry getCountryToCOuntryByCode(String shippingCode, String destinationCode) throws IIMexException {
	Logger.traceEntry();
	CountryToCountry tmp;
	for(int i=0;i< countryToCountryList.size();i++){
		tmp = countryToCountryList.get(i);
		if(tmp.getShippingCode().compareTo(shippingCode)==0)
			if(tmp.getDestinationCode().compareTo(destinationCode)==0)
				return tmp;
	}
	
	return new CountryToCountry();
}

/**
 * Get all the countryToCountry for a fixed shipping country
 * @return a Vector 
 * @throws IIMexException
 */
public Vector<CountryToCountry> getCountryToCOuntry(String shippingCode) throws IIMexException {
	Logger.traceEntry();
	Vector<CountryToCountry> result = new Vector<CountryToCountry>();
	CountryToCountry tmp;
	for(int i=0;i< countryToCountryList.size();i++){
		tmp = countryToCountryList.get(i);
		if(tmp.getShippingCode().compareTo(shippingCode)==0)
			result.add(tmp);
	}
	
	return result;
}

    /**
     * Get all shipping restrictions for destination and origin countries
     */
    public Set<ShippingRestriction> getRestrictions(String destCtryCode, String originCtryCode) {
        Comparator<ShippingRestriction> sort = new Comparator<ShippingRestriction>() {
            public int compare(ShippingRestriction s1, ShippingRestriction s2) {
                return s1.getProductGroupName().compareTo(s2.getProductGroupName());
            }
        };
        Set<ShippingRestriction> restrictions = new TreeSet<ShippingRestriction>(sort);
        for (CountryToCountry c2c : countryToCountryList) {
            if (c2c.getDestinationCode().equals(destCtryCode)) {
                for (ShippingRestriction restriction : c2c.getRestrictions()) {
                    if (restriction.getOrigin().equals(originCtryCode)) {
                        restrictions.add(restriction);
                    }
                }
            }
        }
        return restrictions;
    }

/**
 * Get all the preferred port of entry for a fixed shipping country
 * @return a Vector 
 * @throws IIMexException
 */
public Vector getPortsByCode(String shippingCode) throws IIMexException {
	Logger.traceEntry();
	CountryToCountry tmp;
	Vector<PreferredPort> result = new Vector<PreferredPort>();
	for(int i=0;i< countryToCountryList.size();i++){
		tmp = countryToCountryList.get(i);
        if (tmp.getShippingCode().compareTo(shippingCode)==0){
		Iterator it = tmp.getPreferredPortOfEntry().keySet().iterator();
		while(it.hasNext())
			result.add((PreferredPort)tmp.getPreferredPortOfEntry().get((String)it.next()));
        }
	}
	
	return result;
}
/**
 * Get all the transportations time for a fixed shipping country
 * @return a Vector 
 * @throws IIMexException
 */
public Vector getTranspTimeByCode(String shippingCode) throws IIMexException {
	Logger.traceEntry();
	Iterator ite = countryToCountryList.iterator();
	Vector result = new Vector();
	while(ite.hasNext()){
		CountryToCountry tmp = (CountryToCountry)ite.next();
		if(tmp.getShippingCode().compareTo(shippingCode)==0){
			Iterator it = tmp.getTransportationTime().keySet().iterator();
			while(it.hasNext())
				result.add((TransportationTime)tmp.getTransportationTime().get((String)it.next()));
		}
	}
	
	return result;
}
/**
 * Get all the countryToCountry 
 * @return a Vector 
 * @throws IIMexException
 */
public List getAllCountryToCountry() throws IIMexException {
	return countryToCountryList;
}
/*
 * manage countrytocountry entries and their data in the base 
 */
public int addPort(PreferredPort pp, String code,String div) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = countryToCountryLoadData.addPort(pp, code, div);
    CollectionsChangeMonitor.countryToCountryCollectionChanged=true;
	Logger.traceExit();
	return addOk;
}

public int updatePort(PreferredPort pp, String code,String div) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = countryToCountryLoadData.updatePort(pp, code, div);
    CollectionsChangeMonitor.countryToCountryCollectionChanged=true;
	Logger.traceExit();
	return updateOk;
}

public int removePort(String ship, String dest,String div) throws IIMexException{
	Logger.traceEntry();
	int removeOk=-1;
	removeOk = countryToCountryLoadData.removePort(ship, dest, div);
    CollectionsChangeMonitor.countryToCountryCollectionChanged=true;
	Logger.traceExit();
	return removeOk;
}

public int addTransportationTime(TransportationTime tp, String code) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = countryToCountryLoadData.addTransportationTime(tp, code);
    CollectionsChangeMonitor.countryToCountryCollectionChanged=true;
	Logger.traceExit();
	return addOk;
}


public int updateTransportationTime(TransportationTime tp, String code) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = countryToCountryLoadData.updateTransportationTime(tp, code);
  CollectionsChangeMonitor.countryToCountryCollectionChanged=true;
	Logger.traceExit();
	return addOk;
}

public int removeTransportationTime(TransportationTime tp, String code) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = countryToCountryLoadData.removeTransportationTime(tp, code);
    CollectionsChangeMonitor.countryToCountryCollectionChanged=true;
  Logger.traceExit();
	return addOk;
}

    public int removeRestriction(String destCode, String originCode, String productGroupCode) throws IIMexException {
        Logger.traceEntry();
        int removeOk = countryToCountryLoadData.removeRestriction(destCode, originCode, productGroupCode);
        CollectionsChangeMonitor.countryToCountryCollectionChanged=true;
        Logger.traceExit();
        return removeOk;
    }

    public int updateRestriction(ShippingRestriction shippingRestriction) throws IIMexException {
        Logger.traceEntry();
        int updateOk = countryToCountryLoadData.updateRestriction(shippingRestriction);
        CollectionsChangeMonitor.countryToCountryCollectionChanged=true;
        Logger.traceExit();
        return updateOk;
    }

    public int addRestriction(ShippingRestriction shippingRestriction) throws IIMexException {
        Logger.traceEntry();
        int addOk = countryToCountryLoadData.addRestriction(shippingRestriction);
        CollectionsChangeMonitor.countryToCountryCollectionChanged=true;
        Logger.traceExit();
        return addOk;
    }
}

	

