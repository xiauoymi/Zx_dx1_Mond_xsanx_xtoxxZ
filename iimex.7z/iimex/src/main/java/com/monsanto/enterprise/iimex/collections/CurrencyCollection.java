/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.collections;



import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;



import com.monsanto.AbstractLogging.Logger;

import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.PricingCurrency;

import com.monsanto.enterprise.iimex.tableloader.TableLoadCurrency;



/**

 * CurrencyCollection contains all the currency in a hashTable and manage all the 

 * currency operations

 * 

 * Filename:    $RCSfile: CurrencyCollection.java,v $

 * Label:       $Name:  $

 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $

 * @version     $Revision: 1.11 $

 * @author      MMCORT3

 */

public class CurrencyCollection {



		private HashMap<String, HashMap<String, PricingCurrency>> hmCurrency=null;

		private TableLoadCurrency currencyLoadData = new TableLoadCurrency();

/**

 * Load all the currency data in a hashMap key toCountry,

 * value hashMap  fromCountryPricingCurrency where the key is fromCountry and the value is is the PricingCurrency.

 * when there is not exception fromCountry is not in the hashMap fromCountryPricingCurrency and we will find the 

 * pricingCurrency with the key= ALL

 * @throws IIMexException

 */

public void loadTable()

		throws IIMexException{



			Logger.traceEntry();

			hmCurrency = currencyLoadData.loadCurrencyRows();

			Logger.traceExit();



		}

/**

 * Reload the data

 * @throws IIMexException

 */

public void reload()throws IIMexException{

	Logger.traceEntry();

	loadTable();

	Logger.traceExit();

}



/**

 * Get the currency that is used for the import/export.

 * @param fromCountry 

 * @param toCountry

 * @return PricingCurrency object

 * @throws IIMexException

 */

public PricingCurrency getPricingCurrency(String fromCountry, String toCountry)

throws IIMexException{

	Logger.traceEntry();

	PricingCurrency oCurrency = new PricingCurrency();

	if(hmCurrency.containsKey(toCountry)){

		HashMap<String, PricingCurrency> hmFromToCurrency = hmCurrency.get(toCountry);

		if(hmFromToCurrency.containsKey(fromCountry)){

			oCurrency = hmFromToCurrency.get(fromCountry);

		}else if(hmFromToCurrency.containsKey("*")){

			oCurrency = hmFromToCurrency.get("*");

		}
	}

	Logger.traceExit();

	return oCurrency;

}
/*
 * get all currencies for a shipping country
 * 
 */
public Vector<PricingCurrency> getAllCurrency(String fromCountry){
	
	Logger.traceEntry();
	
	Vector<PricingCurrency> result = new Vector<PricingCurrency>();
	
	if(hmCurrency.containsKey(fromCountry)){
		
		HashMap<String, PricingCurrency> hmFromToCurrency = hmCurrency.get(fromCountry);
		
		Iterator ite = hmFromToCurrency.keySet().iterator();
		
		while(ite.hasNext()){
			
			String next = (String)ite.next();
			
			if(next.compareTo("*")!=0)
				
				result.add(hmFromToCurrency.get(next));
			
		}
	}
	
	Logger.traceExit();
	
	return result;
}
/*
 * get all currencies for a destination country
 * 
 */
public Vector<PricingCurrency> getAllToCurrency(String toCountry){
	
	Logger.traceEntry();
	
	Vector<PricingCurrency> result = new Vector<PricingCurrency>();
	
	if(hmCurrency.containsKey(toCountry)){
		
		HashMap<String, PricingCurrency> hmToCurrency = hmCurrency.get(toCountry);
		
		Iterator ite = hmToCurrency.keySet().iterator();
		
		while(ite.hasNext()){
			
			String next = (String)ite.next();
			
			if(next.compareTo("*")!=0){
				
				result.add(hmToCurrency.get(next));
				
			}
		}
	}

	
	Logger.traceExit();
	
	return result;
}
/*
 * manage currencies and their exceptions in the base
 */
public int addCurrency(PricingCurrency pc, String owner) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = currencyLoadData.addCurrency(pc,owner);
    reload();
	Logger.traceExit();
    reload();
	return addOk;
}

public int updateCurrency(PricingCurrency pc, String owner) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = currencyLoadData.updateCurrency(pc,owner);
    reload();
	Logger.traceExit();
	return updateOk;
}

public int removeCurrency(PricingCurrency pc) throws IIMexException{
	Logger.traceEntry();
	int removeOk=-1;
	removeOk = currencyLoadData.removeCurrency(pc);
    reload();
	Logger.traceExit();
	return removeOk;
}

public int addCurrencyException(PricingCurrency pc, String owner) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = currencyLoadData.addCurrencyException(pc,owner);
    reload();
	Logger.traceExit();
	return addOk;
}

public int updateCurrencyException(PricingCurrency pc, String owner) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = currencyLoadData.updateCurrencyException(pc,owner);
    reload();
	Logger.traceExit();
	return updateOk;
}

public int removeCurrencyException(PricingCurrency pc) throws IIMexException{
	Logger.traceEntry();
	int removeOk=-1;
	removeOk = currencyLoadData.removeCurrencyException(pc);
    reload();
	Logger.traceExit();
	return removeOk;
}

}

