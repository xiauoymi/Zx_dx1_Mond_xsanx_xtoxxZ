package com.monsanto.enterprise.iimex.collections;

import java.util.Iterator;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.WorldArea;
import com.monsanto.enterprise.iimex.elements.customZone;
import com.monsanto.enterprise.iimex.tableloader.TableLoadCustomZone;
import com.monsanto.enterprise.iimex.tableloader.TableLoader;

/**
 * All custom zone collection.
 * 
 * Filename:    $RCSfile: CustomZoneCollection.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 * @version     $Revision: 1.7 $
 * @author      MMCORT3
 */

public class CustomZoneCollection extends TableLoader{

	private Vector<customZone> zones=null;

	private TableLoadCustomZone customLoadData = new TableLoadCustomZone();

/**Load all the zones
 * 
 * @throws IIMexException
 */
	
public void loadTable()throws IIMexException{
	Logger.traceEntry();
	zones = customLoadData.loadCustomZone();
	Logger.traceExit();
}

/**
 * Reload the data in the hashMap
 * @throws IIMexException
 */

public void reload()throws IIMexException{
	Logger.traceEntry();
	loadTable();
    CollectionsChangeMonitor.zonesCollectionsChanged=true;
	Logger.traceExit();
}

/**
 * Get a zone using its code
 * @throws IIMexException
 */

public customZone getZoneByCode(String code) throws IIMexException {
	Logger.traceEntry();
	Iterator ite = zones.iterator();
	customZone tmp;
	while(ite.hasNext()){
		tmp = (customZone)ite.next();
		if(tmp.getCustomZoneCode().compareTo(code)==0)
			return tmp;
	}
	tmp = new customZone();
	Logger.traceExit();
	return tmp;
}

/**
 * Get all the zones
 * @throws IIMexException
 */

public Vector<customZone> getAllCZones() throws IIMexException {
	Logger.traceEntry();
	return zones;
}
/*
 * manage zones in the database
 */
public int addCustomZone(customZone zone)	throws IIMexException{
	Logger.traceEntry();
	int rowUpdate=-1;
	rowUpdate = customLoadData.addCustomZone(zone);
    reload();
	Logger.traceExit();
	return rowUpdate;	
}

public int updateCustomZone(customZone zone)	throws IIMexException{
	Logger.traceEntry();
	int rowUpdate=-1;
	rowUpdate = customLoadData.updateCustomZone(zone);
    reload();
	Logger.traceExit();
	return rowUpdate;	
}

public int removeCustomZone(String zone)	throws IIMexException{
	Logger.traceEntry();
	int rowUpdate=-1;
	rowUpdate = customLoadData.removeCustomZone(zone);
    reload();
	Logger.traceExit();
	return rowUpdate;
}

}

	

