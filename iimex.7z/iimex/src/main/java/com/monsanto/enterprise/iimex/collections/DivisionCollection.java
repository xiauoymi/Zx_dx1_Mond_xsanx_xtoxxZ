package com.monsanto.enterprise.iimex.collections;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dbdataservices.PersistentStoreDBPreparedStatement;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.tableloader.TableLoadDivision;

public class DivisionCollection {

	private List<Division> divisions=null;

	private TableLoadDivision divisionLoadData = new TableLoadDivision();

	/**Load all the division data (division name, division code) in the Collection divisions
	 * 
	 * @throws IIMexException
	 */
	public void loadTable()throws IIMexException{
		Logger.traceEntry();
		divisions=divisionLoadData.loadDivisions();
		Logger.traceExit();
	}
	/**
	 * Reload the division data in the Collection divisions
	 * @throws IIMexException
	 */

	public void reload()throws IIMexException{
		Logger.traceEntry();
		loadTable();
        CollectionsChangeMonitor.divisionCollectionChanged=true;

		Logger.traceExit();
	}
	/**
	 * Get all the divisions
	 * @return a collection
	 */
	public List<Division> getAllDivision(){
		return divisions;
	}
	/**
	 * Get a division name using its code
	 * @return
	 */
	public String getDivisionName(String code){
		String name=" ";
        Division div;
		for(int i=0;i<divisions.size();i++){
			div = divisions.get(i);
			if(code.compareTo(div.getDivisionCode())==0)
				name=div.getDivisionName();
		}
		return name;
	}
	/**
	 * Get a division using its code
	 * @return
	 */
	public Division getDivision(String code){
		Division div;
		for(int i=0;i<divisions.size();i++){
			div = divisions.get(i);
			if(code.compareTo(div.getDivisionCode())==0)
				return div;
		}
		return new Division();
	}
	/**
	 * 
	 * manage divisions in the base
	 */
	public int addDivision(Division div)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = divisionLoadData.addDivision(div);
        reload();
		Logger.traceExit();
		return rowUpdate;	
	}
	
	public int updateDivision(Division div)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = divisionLoadData.updateDivision(div);
        reload();
		Logger.traceExit();
		return rowUpdate;	
	}
	
	public int removeDivision(String div)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = divisionLoadData.removeDivision(div);
        reload();
		Logger.traceExit();
		return rowUpdate;
	}
}