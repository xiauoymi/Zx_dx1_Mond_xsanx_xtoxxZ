/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/


package com.monsanto.enterprise.iimex.collections;


import java.util.*;


import com.monsanto.AbstractLogging.Logger;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.DocumentConditions;

import com.monsanto.enterprise.iimex.elements.Documents;

import com.monsanto.enterprise.iimex.tableloader.TableLoadDocument;

/**
 * DocumentCollection contains a TreeMap with all document ordered by documentCode and manages all the documents <p/>
 * operations <p/> <p/> <p/> Filename:    $RCSfile: DocumentCollection.java,v $ <p/> Label:       $Name:  $ <p/> Last
 * Change: $Author: tadial $    	 On:	$Date: 2009/10/13 19:23:36 $
 *
 * @author MMCORT3
 * @version $Revision: 1.10 $
 */

public class DocumentCollection {


  private TreeMap<Integer, Documents> smDocuments = null;

  private TableLoadDocument documentLoadData = new TableLoadDocument();

  private List<String> fieldListDocuments = null;

  /** Setter created for unit testing purposes */
  protected void setSmDocuments(TreeMap<Integer, Documents> smDocuments) {
      this.smDocuments = smDocuments;
  }

  /**
   * Load the data to the TreeMap, key documentCode, value DocumenstObject
   *
   * @exception IIMexException
   */

  public void loadTable()

      throws IIMexException {

    Logger.traceEntry();

    smDocuments = documentLoadData.loadDocumentsRows();

    fieldListDocuments = documentLoadData.loadDocumentsColumName();

    Logger.traceExit();

  }


  /**
   * Reload all the data to the treeMap
   *
   * @exception IIMexException
   */

  public void reload()

      throws IIMexException {

    Logger.traceEntry();

    loadTable();

    Logger.traceExit();

  }


  /**
   * Get all the documents requiered to import/export <p/> to fromCountryCode, toCountryCode, prodOriginCode,
   * prodGroup, <p/> fromCustomsZones, toCustomsZone and with the same tranpMode
   *
   * @param strFromCountryCode
   * @param strToCountryCode
   * @param strProdGroup
   * @param strFromCustomsZone
   * @param strToCustomsZone
   * @param transpMode
   *
   * @return DocumentsConditions vector
   *
   * @exception IIMexException
   */

  public Vector getDocumentsByFilter(String strFromCountryCode, String strToCountryCode, String strOriginCountryCode,
                                     String strProdGroup, String strTrait, String strDivision,
                                     String strFromCustomsZone, String strToCustomsZone, String strOriginCustomsZone,
                                     String transpMode, String incoterm)

      throws IIMexException {


    Logger.traceEntry();


    Vector<DocumentConditions> result = new Vector<DocumentConditions>();
    boolean nonNullProductGroupFound = false;


    Iterator it = smDocuments.values().iterator();
    Vector<DocumentConditions> res = new Vector<DocumentConditions>(41);
    HashMap<String, Boolean> uniqueDocumentCodes = new HashMap<String, Boolean>();

    while (it.hasNext()) {

      Documents docReq = (Documents) it.next();

      if (docReq.isReq() && docReq.isActive()) {

        HashMap<Integer, DocumentConditions> hmdocumentsConditions = docReq.getDocumentConditionHM();

        Iterator itDocConditions = hmdocumentsConditions.values().iterator();
        res.clear();
        nonNullProductGroupFound = false;
        while (itDocConditions.hasNext()) {
          DocumentConditions oDocCondition = (DocumentConditions) itDocConditions.next();
          if (StringUtils.isNullOrEmpty(oDocCondition.getToCountry()) ||
              StringUtils.areEqual(oDocCondition.getToCountry(), strToCountryCode)) {

            if (StringUtils.isNullOrEmpty(oDocCondition.getFromcountry()) ||
                StringUtils.areEqual(oDocCondition.getFromcountry(), strFromCountryCode)) {

              if (StringUtils.isNullOrEmpty(oDocCondition.getOriginCountry()) ||
                  StringUtils.areEqual(oDocCondition.getOriginCountry(), strOriginCountryCode)) {

                if (StringUtils.isNullOrEmpty(oDocCondition.getFromcustomsZone()) ||
                    StringUtils.areEqual(oDocCondition.getFromcustomsZone(), strFromCustomsZone)) {

                  if (StringUtils.isNullOrEmpty(oDocCondition.getToCustZone()) ||
                      StringUtils.areEqual(oDocCondition.getToCustZone(), strToCustomsZone)) {

                    if (StringUtils.isNullOrEmpty(oDocCondition.getZoneOrigin()) ||
                        StringUtils.areEqual(oDocCondition.getZoneOrigin(), strOriginCustomsZone)) {

                      if (StringUtils.isNullOrEmpty(oDocCondition.getTranspMode()) ||
                          StringUtils.areEqual(oDocCondition.getTranspMode(), transpMode)) {

                        if (StringUtils.isNullOrEmpty(oDocCondition.getIncoterms()) ||
                            StringUtils.areEqual(oDocCondition.getIncoterms(), incoterm)) {

                          if (StringUtils.isNullOrEmpty(oDocCondition.getProductGroup()) ||
                              StringUtils.areEqual(oDocCondition.getProductGroup(), strProdGroup)) {

                            if (StringUtils.areEqual(oDocCondition.getProductGroup(), strProdGroup)) {
                              nonNullProductGroupFound = true;
                            }
                            if (StringUtils.isNullOrEmpty(oDocCondition.getDivision()) ||
                                StringUtils.areEqual(oDocCondition.getDivision(), strDivision)) {

                              if (StringUtils.isNullOrEmpty(oDocCondition.getTrait()) ||
                                  StringUtils.areEqual(oDocCondition.getTrait(), strTrait)) {

                                res.add(oDocCondition);

                              }
                            }
                          }
                        }

                      }

                    }

                  }

                }

              }

            }

          }


        }
        if (nonNullProductGroupFound) {
          for (int i = 0; i < res.size(); i++) {
            if (!StringUtils.isNullOrEmpty(res.get(i).getProductGroup())) {
              result.add(res.get(i));
            }
          }
        } else {
          result.addAll(res);
        }
      }


    }

    Logger.traceExit();


    return result;


  }


  /**
   * Get the document table column name for the report
   *
   * @return
   *
   * @exception IIMexException
   */

  public List getDocumentField()

      throws IIMexException {

    return fieldListDocuments;

  }


  /**
   * Get all the Documents object
   *
   * @return a Collection containing all the documents object ordered by document SDocName asc.
   *
   * @exception IIMexException
   */

  public Vector<Documents> getAllDocuments()
      throws IIMexException {

    Logger.traceEntry();

    Comparator<Documents> sortByName = new Comparator<Documents>() {
        public int compare(Documents d1, Documents d2) {
            return d1.getSDocName().compareTo(d2.getSDocName());
        }
    };
    List<Documents> docsList = new ArrayList<Documents>();

    for (Documents docReq : smDocuments.values()) {
        if (docReq.isActive()) {
            docsList.add(docReq);
        }
    }
    Collections.sort(docsList, sortByName);
    Vector<Documents> docCollection = new Vector<Documents>(docsList);

    Logger.traceExit();

    return docCollection;
  }


  public Documents getDocumentRequirements(Integer iDoc)

      throws IIMexException {

    Logger.traceEntry();

    Documents documentReq = (Documents) smDocuments.get(iDoc);

    Logger.traceExit();

    return documentReq;

  }


  public int deleteDocuments(int docId)

      throws IIMexException {

    Logger.traceEntry();

    int rowDelete = 0;

    rowDelete = documentLoadData.inactiveDocument(docId);


    reload();
    Logger.traceExit();

    return rowDelete;

  }


  public int updateDocuments(int docId, String docName, String typeReq,

                             String purpose, String filePath)

      throws IIMexException {

    Logger.traceEntry();

    int rowUpdate = 0;

    rowUpdate = documentLoadData.updateDocuments(docId, docName, typeReq, purpose, filePath);
    reload();
    return rowUpdate;

  }

  public Vector getDocumentByDestination(Country coun) {
    Comparator<DocumentConditions> sortByName = new Comparator<DocumentConditions>() {
      public int compare(DocumentConditions d1, DocumentConditions d2) {
          return d1.getDocName().compareTo(d2.getDocName());
      }
    };
    List<DocumentConditions> docCondList = new ArrayList<DocumentConditions>();
    for (Integer docCode : smDocuments.keySet()) {
      Documents tmp = smDocuments.get(docCode);
      if (tmp.getDocumentConditions() != null) {
          Collection<DocumentConditions> cond = tmp.getDocumentConditions();
          for (DocumentConditions docCond : cond) {
              if (docCond != null) {
                  if (coun != null) {
                      if (!StringUtils.isNullOrEmpty(coun.getCountryCode())) {
                          System.out.println("Country Code is ::::: = " + coun.getCountryCode());
                      } else {
                          coun.setCountryCode("");
                      }
                      if (!StringUtils.isNullOrEmpty(coun.getCustomsZoneCode())) {
                          System.out.println("Zone Code is ::::: = " + coun.getCustomsZoneCode());
                      } else {
                          coun.setCustomsZoneCode("");
                      }
                      if ((!StringUtils.isNullOrEmpty(docCond.getToCountry()) &&
                              docCond.getToCountry().equalsIgnoreCase(coun.getCountryCode()))
                              || (!StringUtils.isNullOrEmpty(docCond.getToCustZone()) &&
                              docCond.getToCustZone().equalsIgnoreCase(coun.getCustomsZoneCode()))) {
                          docCondList.add(docCond);
                      }
                  }
              }
          }
      }
    }
    Collections.sort(docCondList, sortByName);
    return new Vector(docCondList);
  }

  public int addDocuments(int docId, String docName, String typeReq,

                          String purpose, String filePath, String owner) throws IIMexException {

    Logger.traceEntry();

    int rowUpdate = 0;

    rowUpdate = documentLoadData.addDocument(docId, docName, typeReq, purpose, filePath, owner);
    reload();
    Logger.traceExit();

    return rowUpdate;

  }


  public int getDocCounter()

      throws IIMexException {

    Logger.traceEntry();

    Logger.traceExit();

    return documentLoadData.getDocConter();

  }


  public void setDocumentRequirementCountryName(CountryCollection countryCol, CustomZoneCollection custCol)

      throws IIMexException {

    Iterator it = smDocuments.values().iterator();

    while (it.hasNext()) {

      Documents docReq = (Documents) it.next();

      if (docReq.isReq() && docReq.isActive()) {

        HashMap<Integer, DocumentConditions> hmdocumentsConditions = docReq.getDocumentConditionHM();

        Iterator itDocConditions = hmdocumentsConditions.values().iterator();

        while (itDocConditions.hasNext()) {

          DocumentConditions oDocCondition = (DocumentConditions) itDocConditions.next();

          String fromCountryCode = oDocCondition.getFromcountry();

          String toCountryCode = oDocCondition.getToCountry();

          String originCountryCode = oDocCondition.getOriginCountry();

          String fromCustZone = oDocCondition.getFromcustomsZone();

          String toCustZone = oDocCondition.getToCustZone();

          String originCustZone = oDocCondition.getZoneOrigin();

          if (!StringUtils.isNullOrEmpty(fromCountryCode)) {
            Country shipping = countryCol.getCountryByCode(fromCountryCode);
            oDocCondition.setFromCountryNameLong(shipping.getCountryName());
          }

          if (!StringUtils.isNullOrEmpty(toCountryCode)) {
            Country destination = countryCol.getCountryByCode(toCountryCode);
            oDocCondition.setToCountryNameLong(destination.getCountryName());
          }
          if (!StringUtils.isNullOrEmpty(originCountryCode)) {
            Country origin = countryCol.getCountryByCode(originCountryCode);
            oDocCondition.setCountryOriginLong(origin.getCountryName());
          }
          if (!StringUtils.isNullOrEmpty(fromCustZone)) {
            oDocCondition.setFromCustomZoneLong(custCol.getZoneByCode(fromCustZone).getCustomZoneName());
          }
          if (!StringUtils.isNullOrEmpty(toCustZone)) {
            oDocCondition.setToCustomZoneLong(custCol.getZoneByCode(toCustZone).getCustomZoneName());
          }
          if (!StringUtils.isNullOrEmpty(originCustZone)) {
            oDocCondition.setZoneOriginLong(custCol.getZoneByCode(originCustZone).getCustomZoneName());
          }
        }

      }

    }

  }


  public void setDocumentRequirementProductName(ProductCollection productsCollection,
                                                DivisionCollection divisionCollection,
                                                TraitCollection traitCollection) throws IIMexException {

    Iterator it = smDocuments.values().iterator();

    while (it.hasNext()) {

      Documents docReq = (Documents) it.next();

      if (docReq.isReq() && docReq.isActive()) {

        HashMap<Integer, DocumentConditions> hmdocumentsConditions = docReq.getDocumentConditionHM();

        Iterator itDocConditions = hmdocumentsConditions.values().iterator();

        while (itDocConditions.hasNext()) {

          DocumentConditions oDocCondition = (DocumentConditions) itDocConditions.next();

          String productCode = oDocCondition.getProductGroup();

          String divisionCode = oDocCondition.getDivision();

          String trait = oDocCondition.getTrait();

          if (!StringUtils.isNullOrEmpty(productCode)) {

            oDocCondition.setProductGroupLong(productsCollection.getProductName(productCode));

          }
          if (!StringUtils.isNullOrEmpty(divisionCode)) {

            oDocCondition.setDivisionLong(divisionCollection.getDivisionName(divisionCode));

          }
          if (!StringUtils.isNullOrEmpty(trait)) {

            oDocCondition.setTraitLong(traitCollection.getTraitName(trait));

          }
        }

      }

    }


  }


  public int deleteDocumentCondition(String docCondId)

      throws IIMexException {

    Logger.traceEntry();

    int rowDelete = 0;

    rowDelete = documentLoadData.deleteDocumentCondition(Integer.parseInt(docCondId));


    reload();
    Logger.traceExit();

    return rowDelete;

  }

    public int updateDocCondition(DocumentConditions docCond) throws IIMexException {
      Logger.traceEntry();

      int rowUpdated = documentLoadData.updateDocumentCondition(docCond);
      reload();

      Logger.traceExit();
      return rowUpdated;
    }

    public DocumentConditions getDocumentConditionsById(String docCondId) {
        int docCondInt = Integer.parseInt(docCondId);
        DocumentConditions docCond = null;
        for (Documents documents : smDocuments.values()) {
            HashMap<Integer, DocumentConditions> hm = documents.getDocumentConditionHM();
            if (hm != null && hm.keySet().contains(docCondInt)) {
                docCond = hm.get(docCondInt);
                break;
            }
        }
        return docCond;
    }

  public boolean checkDocumentCondition(DocumentConditions docCond)

      throws IIMexException {

    Logger.traceEntry();

    boolean newDocCond = true;

    Documents doc = smDocuments.get(Integer.parseInt(docCond.getDocumentCode()));

    if (doc.isReq()) {

      HashMap<Integer, DocumentConditions> hmdocumentsConditions = doc.getDocumentConditionHM();

      Iterator itDocConditions = hmdocumentsConditions.values().iterator();

      while (itDocConditions.hasNext()) {

        DocumentConditions oDocCondition = (DocumentConditions) itDocConditions.next();

        if ((docCond.getFromcountry().equalsIgnoreCase(oDocCondition.getFromcountry())) &&

            (docCond.getFromcustomsZone().equalsIgnoreCase(oDocCondition.getFromcustomsZone())) &&

            (docCond.getOriginCountry().equalsIgnoreCase(oDocCondition.getOriginCountry())) &&

            (docCond.getZoneOrigin().equalsIgnoreCase(oDocCondition.getZoneOrigin())) &&

            (docCond.getToCountry().equalsIgnoreCase(oDocCondition.getToCountry())) &&

            (docCond.getToCustZone().equalsIgnoreCase(oDocCondition.getToCustZone())) &&

            (docCond.getDivision().equalsIgnoreCase(oDocCondition.getDivision())) &&

            (docCond.getProductGroup().equalsIgnoreCase(oDocCondition.getProductGroup())) &&

            (docCond.getTrait().equalsIgnoreCase(oDocCondition.getTrait())) &&

            (docCond.getIncoterms()).equalsIgnoreCase(oDocCondition.getIncoterms()) &&

            (docCond.getTranspMode().equalsIgnoreCase(oDocCondition.getTranspMode()))

            ) {

          newDocCond = false;

        }

      }


    }

    Logger.traceExit();

    return newDocCond;

  }


    public int addDocCondition(DocumentConditions docCond) throws IIMexException {

      int i = documentLoadData.addDocumentCondition(docCond);
      reload();
      return i;

    }



  public void setDocumentRequirementTransport(

      IncotermsTransportCollection incotermsTransportCollection) throws IIMexException {

    Iterator it = smDocuments.values().iterator();

    while (it.hasNext()) {

      Documents docReq = (Documents) it.next();

      if (docReq.isReq() && docReq.isActive()) {

        HashMap<Integer, DocumentConditions> hmdocumentsConditions = docReq.getDocumentConditionHM();

        Iterator itDocConditions = hmdocumentsConditions.values().iterator();

        while (itDocConditions.hasNext()) {

          DocumentConditions oDocCondition = (DocumentConditions) itDocConditions.next();

          String transport = oDocCondition.getTranspMode();

          String incoterms = oDocCondition.getIncoterms();

          if (!(StringUtils.isNullOrEmpty(transport) || StringUtils.isNullOrEmpty(incoterms))) {

            String transpIncoter = transport + " - " + incoterms;

            oDocCondition.setTransportLong(
                incotermsTransportCollection.getIncotermTrasportInfobyCode(transpIncoter).getIncotermTransportName());

          }

        }

      }


    }


  }

}

