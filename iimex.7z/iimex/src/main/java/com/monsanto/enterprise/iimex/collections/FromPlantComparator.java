/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.collections;



import java.util.Comparator;



import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;



public class FromPlantComparator implements Comparator<PlantsFromCountry> {



	public int compare(PlantsFromCountry a_Object1, PlantsFromCountry a_Object2){

	try{

		int compareCountryCd=0;

		int compareCompanyCd=0;

		int compare=0;

		compareCountryCd= a_Object1.getCodeFromCountry().compareTo(a_Object2.getCodeFromCountry());

		if(compareCountryCd==0){

			compareCompanyCd = a_Object1.getM_strPlantCompanyCode().compareTo(a_Object2.getM_strPlantCompanyCode());

			if(compareCompanyCd==0){

				compare=a_Object1.getCodePlant().compareTo(a_Object2.getCodePlant());

			}else{

				compare=compareCompanyCd;

			}

		}else{

			compare=compareCountryCd;

		}

		 

		 

		 return compare;

	}catch (Exception ex) {

		return 0;

	}

	

	}	

}

