package com.monsanto.enterprise.iimex.collections;

import com.monsanto.enterprise.iimex.IIMexException;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 31, 2010
 * Time: 10:31:44 AM
 */
public class IIMexEntityCollisionException extends IIMexException {
    public IIMexEntityCollisionException(String msg) {
        super(msg);
    }
}
