/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.ImportDuties;
import com.monsanto.enterprise.iimex.elements.ValueAddedTax;
import com.monsanto.enterprise.iimex.tableloader.TableLoadDuties;
import com.monsanto.enterprise.iimex.tableloader.TableLoader;

/**
 * All import duties object collection.
 * 
 * Filename:    $RCSfile: ImportDutiesCollection.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 * @version     $Revision: 1.9 $
 * @author      MMCORT3
 */

public class ImportDutiesCollection extends TableLoader{

	private HashMap<String, Vector<ImportDuties>> duties=null;

	private TableLoadDuties companyLoadData = new TableLoadDuties();

/**Load all the import duties
 * 
 * @throws IIMexException
 */

public void loadTable()throws IIMexException{
	Logger.traceEntry();
	duties =companyLoadData.loadDuties();
	Logger.traceExit();
}

/**
 * Reload the import duties data in the hashMap
 * @throws IIMexException
 */

public void reload()throws IIMexException{
	Logger.traceEntry();	
	loadTable();
	Logger.traceExit();
}

/**
 * get a specific duty using the htscode of a product group and the shipping and destination country
 */

public ImportDuties getDuty(String HTSCode, Country shipping, Country destination) throws IIMexException {
	Logger.traceEntry();
	Vector<ImportDuties> tmp;
	ImportDuties res = new ImportDuties();
	if(duties.containsKey(HTSCode)){
		tmp = duties.get(HTSCode);
		ImportDuties dut;
		for(int i=0;i<tmp.size();i++){
			dut = tmp.get(i);
			if(shipping.getCustomsZoneCode()!=null && dut.getZoneOrigin().compareTo(shipping.getCustomsZoneCode())==0){
				if(destination.getCustomsZoneCode()!=null && dut.getZoneDestination().compareTo(destination.getCustomsZoneCode())==0)
					return dut;
				else if(dut.getCountryDestination().compareTo(destination.getCountryCode())==0)
					return dut;
			}else if(dut.getCountryOrigin().compareTo(shipping.getCountryCode())==0){
				if(destination.getCustomsZoneCode()!=null && dut.getZoneDestination().compareTo(destination.getCustomsZoneCode())==0)
					return dut;
				else if(dut.getCountryDestination().compareTo(destination.getCountryCode())==0)
					return dut;
			}else if(dut.getZoneOrigin().compareTo("*")==0 && dut.getCountryOrigin().compareTo("*")==0 && dut.getCountryDestination().compareTo(destination.getCountryCode())==0){
				res =dut;
			}
		}
	}
	
	if(duties.containsKey("*")){ 
		tmp = duties.get("*");
		ImportDuties dut;
		for(int i=0;i<tmp.size();i++){
			dut = tmp.get(i);
			if(dut.getZoneOrigin().compareTo(shipping.getCustomsZoneCode())==0){
				if(dut.getZoneDestination().compareTo(destination.getCustomsZoneCode())==0)
					return dut;
				else if(dut.getCountryDestination().compareTo(destination.getCountryCode())==0)
					return dut;
			}else if(dut.getCountryOrigin().compareTo(shipping.getCountryCode())==0){
				if(dut.getZoneDestination().compareTo(destination.getCustomsZoneCode())==0)
					return dut;
				else if(dut.getCountryDestination().compareTo(destination.getCountryCode())==0)
					return dut;
			}else if(dut.getZoneOrigin().compareTo("*")==0 && dut.getCountryOrigin().compareTo("*")==0 && dut.getCountryDestination().compareTo(destination.getCountryCode())==0)
				res =dut;
		}
		
	}
	
	return res;
}
/*
 * get all duties for a destination country
 */
public Vector<ImportDuties> getCountryDuty(Country destination) throws IIMexException {
	Logger.traceEntry();
	Vector<ImportDuties> result = new Vector<ImportDuties>();
	Vector<ImportDuties> tmp;
	Iterator ite = duties.values().iterator();
	while(ite.hasNext()){
		tmp = (Vector<ImportDuties>)ite.next();
        ImportDuties dut;
		for(int i=0;i<tmp.size();i++){
			dut = tmp.get(i);
			if(dut.getCountryDestination().compareTo(destination.getCountryCode())==0)
				result.add(dut);
			else if(dut.getCountryDestination().compareTo("*")==0)
				if(dut.getZoneDestination().compareTo(destination.getCustomsZoneCode())==0)
					result.add(dut);
		}
	}
	
	return result;
}

/**
 * Get all the duties
 */

public Vector<ImportDuties> getAllDuties() throws IIMexException {
	Logger.traceEntry();
	Vector<ImportDuties> AllDuties = new Vector<ImportDuties>();
    Vector<ImportDuties> tmp;
	Logger.traceExit();
	Iterator ite = duties.values().iterator();
	while(ite.hasNext()){
		tmp = (Vector<ImportDuties>)ite.next();
		for(int i=0;i<tmp.size();i++){AllDuties.add(tmp.get(i));}
	}
	return AllDuties;
}
/*
 * manage inputs in the database
 */
public int addDuty(ImportDuties dut) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = companyLoadData.addDuty(dut);
    reload();
	Logger.traceExit();
	return addOk;
}

public int updateDuty(ImportDuties dut) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = companyLoadData.updateDuty(dut);
    reload();
	Logger.traceExit();
	return updateOk;
}

public int removeDuty(ImportDuties dut) throws IIMexException{
	Logger.traceEntry();
	int removeOk=-1;
	removeOk = companyLoadData.removeDuty(dut);
    reload();
	Logger.traceExit();
	return removeOk;
}

}

	

