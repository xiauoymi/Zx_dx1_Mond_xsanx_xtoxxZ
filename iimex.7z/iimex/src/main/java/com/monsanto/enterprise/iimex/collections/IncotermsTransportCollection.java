/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.collections;



import java.util.Collection;
import java.util.Collections;

import java.util.HashMap;

import java.util.Iterator;

import java.util.List;

import java.util.Vector;



import com.monsanto.AbstractLogging.Logger;

import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.IncotermTransportInfo;
import com.monsanto.enterprise.iimex.elements.Transport;

import com.monsanto.enterprise.iimex.tableloader.TableLoadIncotermsTp;

/**
 * IncotermsTransportCollection contains a hashMap with all the incoterms and transport info and manage all
 * all the operation related with the incoterms and transport.
 * 
 * Filename:    $RCSfile: IncotermsTransportCollection.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 * @version     $Revision: 1.12 $
 * @author      MMCORT3
 */

public class IncotermsTransportCollection {

	/**hashMap where the key is the incoterm code and

	 * the value is another hashMap where the key is the transport mode and the value is an IncotermTransportInfo

	 * object containing all the datas concerning the incoterms and the transport mode.

	 */

	HashMap<String, HashMap<String,IncotermTransportInfo>> hmIncotermsTransport=null;
	
	Vector<IncotermTransportInfo> newTransport = null;
	
	Vector<IncotermTransportInfo> newIncoterm = null;

	TableLoadIncotermsTp incotermsTransportLoadData = new TableLoadIncotermsTp();

	

	/**

	 * Load the values from the DB to a hashMap where the key is incotermCode info and the value is

	 * a hashMap with where the key is the transporCode and the object is an IncotermTransporInfo object

	 * @throws IIMexException

	 */

	public void loadTable()

	throws IIMexException{



		Logger.traceEntry();

        reloadTransportMode();

        reloadIncoterm();

        reloadTransportModeIncoTerm();


        Logger.traceExit();

	}

	/**

	 * reload the values from the DB to the hashMap

	 * @throws IIMexException

	 */

	public void reload()throws IIMexException{

		Logger.traceEntry();

		loadTable();
        
        CollectionsChangeMonitor.incotermsTransportCollectionChanged=true;

		Logger.traceExit();

	}

/*
 * get only the different transport mode from the collection
 */
	public Vector<IncotermTransportInfo> getTransportList()

	throws IIMexException{

		Vector<IncotermTransportInfo> transportList = new Vector<IncotermTransportInfo>();
		Iterator it = hmIncotermsTransport.values().iterator();
        HashMap<String, HashMap<String, Vector<IncotermTransportInfo>>> mhIncotermsTp;

		while(it.hasNext()){

			mhIncotermsTp = (HashMap<String, HashMap<String, Vector<IncotermTransportInfo>>>)it.next();
			
			Iterator ite = mhIncotermsTp.values().iterator();
			
			boolean exist;
			
			while(ite.hasNext()){
				
				IncotermTransportInfo ico = (IncotermTransportInfo)ite.next();
				String code = ico.getTransportCode();
				exist=false;
				for(int i=0;i<transportList.size();i++)
					if(code.compareTo((transportList.get(i)).getTransportCode())==0)
						exist=true;
				if(!exist){
					transportList.add(ico);
				}
			}
			
		}
		
		return transportList;
	}
	/*
	 * get the transport modes that are not associated with incoterms
	 */
	public List getNewTransportList()

		throws IIMexException{

		return newTransport;

	}
	
	
	

	/**

	 * @return a Vector to all the IncotermTransportInfo objects ordered by transport mode and incoterm

	 * @throws IIMexException

	 */

	public Vector<IncotermTransportInfo> getIncotermTransportList()

	throws IIMexException{

		Vector<IncotermTransportInfo> incotermTptList = new Vector<IncotermTransportInfo>();

		Iterator it = hmIncotermsTransport.values().iterator();

		while(it.hasNext()){

			HashMap mhIncotermsTp = (HashMap)it.next();

			incotermTptList.addAll(mhIncotermsTp.values());

		}

		TranspModeComparator oTptModeComparator = new TranspModeComparator();

		Collections.sort(incotermTptList,oTptModeComparator);

		Logger.traceExit();

		return incotermTptList;

	}
	/*
	 * get every different incoterm
	 */
	public Vector<IncotermTransportInfo> getAllDifferentIncoterm()	throws IIMexException{

		Vector<IncotermTransportInfo> incotermList = new Vector<IncotermTransportInfo>();

		Iterator it = hmIncotermsTransport.values().iterator();

		while(it.hasNext()){

			HashMap mhIncotermsTp = (HashMap)it.next();

			Iterator ite = mhIncotermsTp.values().iterator();
			
			while(ite.hasNext()){
				IncotermTransportInfo inco = (IncotermTransportInfo)ite.next();  
				boolean isIn = false;
				Iterator iter = incotermList.iterator();
				while(iter.hasNext()){
					if(((IncotermTransportInfo)iter.next()).getIncotermsCode().compareTo(inco.getIncotermsCode())==0){
						isIn = true;
					}
				}
				if(!isIn)
					incotermList.add(inco);
				
			}
		}

		TranspModeComparator oTptModeComparator = new TranspModeComparator();

		Collections.sort(incotermList,oTptModeComparator);

		Logger.traceExit();

		return incotermList;

	}
	/*
	 * get all transport mode incoterms object for a transport mode code
	 */
	public Vector<IncotermTransportInfo> getTransportModeIncoterm(String tp)	throws IIMexException{

		Vector<IncotermTransportInfo> result = new Vector<IncotermTransportInfo>();

		Iterator it = hmIncotermsTransport.values().iterator();

		while(it.hasNext()){

			HashMap mhIncotermsTp = (HashMap)it.next();

			if(mhIncotermsTp.containsKey(tp)){
				IncotermTransportInfo inco = (IncotermTransportInfo)mhIncotermsTp.get(tp);
				result.add(inco);
			}
			
		}

		TranspModeComparator oTptModeComparator = new TranspModeComparator();

		Collections.sort(result,oTptModeComparator);

		Logger.traceExit();

		return result;

	}
	
	public Vector<IncotermTransportInfo> getNewIncoterm(String tp)	throws IIMexException{

		Vector<IncotermTransportInfo> result = new Vector<IncotermTransportInfo>();

		Iterator it = hmIncotermsTransport.values().iterator();

		while(it.hasNext()){

			HashMap mhIncotermsTp = (HashMap)it.next();

			if(!mhIncotermsTp.containsKey(tp))
				if(mhIncotermsTp.size()>0){
					IncotermTransportInfo inco = (IncotermTransportInfo)mhIncotermsTp.values().iterator().next();
					result.add(inco);
				}
		}

		result.addAll(newIncoterm);
		
		TranspModeComparator oTptModeComparator = new TranspModeComparator();

		Collections.sort(result,oTptModeComparator);

		Logger.traceExit();

		return result;

	}
	/* 
	 *retrieve a transport mode using its code 
	 */
	public IncotermTransportInfo getTransport(String code){
		
		Logger.traceEntry();
		
		Iterator it = hmIncotermsTransport.values().iterator();
		
		while(it.hasNext()){

			HashMap mhIncotermsTp = (HashMap)it.next();

			if(mhIncotermsTp.containsKey(code))
				if(mhIncotermsTp.size()>0){
					return (IncotermTransportInfo)mhIncotermsTp.get(code);
				}
		}
		
		it = newTransport.iterator();
		
		while(it.hasNext()){
			IncotermTransportInfo tmp = (IncotermTransportInfo) it.next();
			if(!StringUtils.isNullOrEmpty(tmp.getTransportCode()))
				if(tmp.getTransportCode().compareTo(code)==0)
					return tmp;
		}
		
		return new IncotermTransportInfo();		
	}
	/*
	 * get the incoterms that are not associated with a transport mode
	 */
	public List getNewIncoterm()	throws IIMexException{

		Logger.traceEntry();

		return newIncoterm;

	}
	
	/**

	 * Get the incotermTransportInfo with all the information related to the incotermCode

	 * @param strIncoInfo

	 * @return

	 * @throws IIMexException

	 */

	public IncotermTransportInfo getIncotermInfoByCode(String strIncoInfo) throws IIMexException {



	Logger.traceEntry();



	HashMap mhTransportMode = (HashMap)hmIncotermsTransport.get(strIncoInfo);

	IncotermTransportInfo incotermInfo = (IncotermTransportInfo)mhTransportMode.values().toArray()[0];

	Logger.traceExit();

	return incotermInfo;

}

	/**

	 * Get the IncotermTransportInfo object that has transport and Incoterm code contain in codes

	 * @param codes contains the transport and the incoterms code codes = TransportCode - IncotermCode

	 * @return

	 * @throws IIMexException

	 */

	public IncotermTransportInfo getIncotermTrasportInfobyCode(String codes)

	throws IIMexException{

		Logger.traceEntry();

		String transportCode = codes.substring(0,1);

		String incotermCode = codes.substring(4,codes.length());

		IncotermTransportInfo incotermTptInfo;
		
		if(hmIncotermsTransport.containsKey(incotermCode)){

			HashMap mhTransportMode = hmIncotermsTransport.get(incotermCode);

			if(mhTransportMode.containsKey(transportCode)){

				incotermTptInfo = (IncotermTransportInfo)mhTransportMode.get(transportCode);

			}else{

				throw (new IIMexException("Error transport mode: "+transportCode +" impossible  for the incoterms: "+incotermCode));

			}

		}else{

			throw (new IIMexException("The incortem: "+incotermCode+ " does not exist"));

		}

		Logger.traceExit();

		return incotermTptInfo;

	}
/*
 * get a transport incoterm object using their code
 */
	public IncotermTransportInfo getIncotermTrasportInfobyCodeAndName(String codes)

	throws IIMexException{

		Logger.traceEntry();

		int pos = codes.indexOf("-");
		
		String transportName = codes.substring(0,pos-1);
		
		String incotermCode = codes.substring(pos+2);

		IncotermTransportInfo incotermTptInfo=null;

		if(hmIncotermsTransport.containsKey(incotermCode)){

			HashMap mhTransportMode = hmIncotermsTransport.get(incotermCode);

			Collection allIncoTp = mhTransportMode.values();
			
			Iterator ite = allIncoTp.iterator();
			IncotermTransportInfo tmp;
			while(ite.hasNext()){
				tmp = ((IncotermTransportInfo)ite.next());
				if(tmp.getTransportName().compareTo(transportName)==0){
					incotermTptInfo = tmp;
				}
			}
			if(incotermTptInfo==null){
				throw (new IIMexException("Error transport mode: "+transportName +" impossible  for the incoterm: "+incotermCode));
			}
		}else{

			throw (new IIMexException("The incortem: "+incotermCode+ " does not exist"));

		}

		Logger.traceExit();

		return incotermTptInfo;

	}
	/*
	 * manage the entries in the database
	 */
	public int addTransportMode(IncotermTransportInfo inco)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = incotermsTransportLoadData.addTransportMode(inco);
        reloadTransportMode();
        Logger.traceExit();
		return rowUpdate;	
	}

    private void reloadTransportMode() throws IIMexException {
        newTransport = incotermsTransportLoadData.loadNewTransport();
    }

    public int removeTransportMode(String inco)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = incotermsTransportLoadData.removeTransportMode(inco);
        reloadTransportMode();
		Logger.traceExit();
		return rowUpdate;
	}
	
	public int addTransportModeIncoterm(IncotermTransportInfo inco)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = incotermsTransportLoadData.addTransportModeIncoterm(inco);
        reloadTransportModeIncoTerm();
		Logger.traceExit();
		return rowUpdate;	
	}
	
	public int removeTransportModeIncoterm(IncotermTransportInfo inco)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = incotermsTransportLoadData.removeTransportModeIncoterm(inco);
        reloadTransportModeIncoTerm();
        Logger.traceExit();
		return rowUpdate;
	}

    private void reloadTransportModeIncoTerm() throws IIMexException {
        hmIncotermsTransport = incotermsTransportLoadData.loadIncotermsTpRows();
    }

    public int addIncoterm(IncotermTransportInfo inco)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = incotermsTransportLoadData.addIncoterm(inco);
        reloadIncoterm();
        Logger.traceExit();
		return rowUpdate;	
	}

    private void reloadIncoterm() throws IIMexException {
        newIncoterm = incotermsTransportLoadData.loadNewIncoterm();
    }

    public int updateIncoterm(IncotermTransportInfo inco)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = incotermsTransportLoadData.updateIncoterm(inco);
        reloadIncoterm();
		Logger.traceExit();
		return rowUpdate;	
	}
	
	public int removeIncoterm(String inco) throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = incotermsTransportLoadData.removeIncoterm(inco);
        reloadIncoterm();
		Logger.traceExit();
		return rowUpdate;
	}

}

