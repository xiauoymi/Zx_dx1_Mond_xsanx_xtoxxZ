/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.collections;



import java.util.Collection;

import java.util.Date;

import java.util.TreeMap;



import com.monsanto.AbstractLogging.Logger;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.elements.LinkAndDocument;

import com.monsanto.enterprise.iimex.elements.Url;

import com.monsanto.enterprise.iimex.tableloader.TableLoadLinks;





public class LinkCollection {

	 private TreeMap<Integer, LinkAndDocument> tmLinks = null;

	 private TableLoadLinks linkLoadData= new TableLoadLinks();



	/**

	 * Load the links and documentation data from the DB 

	 * @throws IIMexException

	 */

	public void loadTable()

	throws IIMexException{

		Logger.traceExit();

		  tmLinks = linkLoadData.loadLinksRows();

		Logger.traceExit();

	}

	

	public void reload()

	throws IIMexException{

		Logger.traceEntry();	

		loadTable();

		Logger.traceExit();

	}

	

	 TreeMap getLinks()

	 throws IIMexException{

		 return tmLinks;

	 }

	 

	 public Collection getAllLinks()

	 throws IIMexException{

		 return tmLinks.values();

	 }

	 

	 public LinkAndDocument getLinkAndDocument(String linkId)

	 throws IIMexException{

		 LinkAndDocument linkAndDocument = tmLinks.get(new Integer(linkId));

		 return linkAndDocument;

		 

	 }

	 /**

	  * Inactive the link in the object and in the database

	  * @param linkId

	  * @return the number of row updated in the database

	  * @throws IIMexException

	  */

	 public boolean setInactiveLink(String linkId)

	 throws IIMexException{

		 Logger.traceEntry();

		 int rowUpdate=0;

		 boolean succesful=false;

		 

		 rowUpdate=linkLoadData.updateLinkInactive(linkId);

		 if(rowUpdate>0){

			 succesful=true;

		 }
         reload();
		 Logger.traceExit();

		 return succesful;

		 

	 }
	 
	 public boolean removeDoc(String linkId, String docId)

	 throws IIMexException{

		 Logger.traceEntry();

		 int rowUpdate=0;

		 boolean succesful=false;

		 

		 rowUpdate=linkLoadData.removeDoc(linkId, docId);

		 if(rowUpdate>0){

			 succesful=true;

		 }
          reload();
		 Logger.traceExit();

		 return succesful;	 

	 }

	 /**

	  * Update a link in the object and in the database with the following datas

	  * @param linkId

	  * @param linkGroupName

	  * @param linkGroupDesc

	  */

	public boolean updateLink(String linkId, String linkGroupName, String linkGroupDesc)

	throws IIMexException{

		Logger.traceEntry();

		int rowUpdate=0;

		boolean succesful=false;

		rowUpdate=linkLoadData.updateLink(linkId,linkGroupName, linkGroupDesc);

		if(rowUpdate>0){

			 succesful=true;

		 }
        reload();
		Logger.traceExit();

		 return succesful;

	

	}

	/**

	 * Add a new group link to the collection and add the link to the database

	 * @param linkGroupName

	 * @param linkGroupDesc

	 * @return

	 * @throws IIMexException

	 */

	public boolean insertLink(String linkGroupName, String linkGroupDesc)

	throws IIMexException{

		Logger.traceEntry();

		boolean succesful = false;

		int insertRow =0;

		int linkId = tmLinks.size()+1;

		insertRow = linkLoadData.insertLink(linkId, linkGroupName, linkGroupDesc);

		if (insertRow>0){

			succesful = true;

		}
        reload();
		Logger.traceExit();

		return succesful;

	}



	public boolean updateUrl(String linkId, String urlId, String linkOrDocGroupName, String linkorDocGroupDesc, String urlPath,String userId) 

	throws IIMexException{

		Logger.traceEntry();

		boolean succesful= false;

		int updateRow =0;

		updateRow=linkLoadData.updateUrl(linkId,urlId, linkOrDocGroupName, linkorDocGroupDesc, urlPath,userId);

		

		if(updateRow>0){

			succesful=true;

			LinkAndDocument linkAndDocument = tmLinks.get(new Integer(linkId));

			Url url =linkAndDocument.getUrl(urlId);

			url.setUrlTitle(linkOrDocGroupName);

			url.setUrlDescription(linkorDocGroupDesc);

			url.setUrl(urlPath);

			url.setPublishDate(new Date());

			url.setPublishOwner(userId);

		}

		
         reload();
		Logger.traceExit();

		return succesful;

	}



	public boolean createNewUrl(String linkId, String linkOrDocGroupName,

			String linkorDocGroupDesc, String urlPath, String userId)

	throws IIMexException {

		Logger.traceEntry();

		boolean succesful = false;

		int rowInsert =0;

		LinkAndDocument linkAndDoc =tmLinks.get(new Integer(linkId));

				Date publishDate = new Date();

		rowInsert = linkLoadData.addUrl(linkId,linkOrDocGroupName, linkorDocGroupDesc,urlPath,userId,publishDate);

		

		

		if(rowInsert >0){

			succesful=true;

			int urlId=linkLoadData.getUrlCounter();

			Url url = new Url();

			url.setUrlId(urlId);

			url.setLinkId(Integer.parseInt(linkId));

			url.setPublishDate(publishDate);

			url.setPublishOwner(userId);

			url.setUrl(urlPath);

			url.setUrlDescription(linkorDocGroupDesc);

			url.setUrlTitle(linkOrDocGroupName);

			linkAndDoc.addUrl(urlId, url);

			linkAndDoc.setHasUrl(true);

			

		}

		Logger.traceExit();
        reload();
		return succesful;

	}



	public boolean deleteUrl(String linkId, String urlId)

	throws IIMexException {

		Logger.traceEntry();

		int rowDelete=0;

		boolean deleteOk = false;

		LinkAndDocument linkAndDocument = tmLinks.get(new Integer(linkId));

		rowDelete = linkLoadData.deleteUrl(urlId);

		if(rowDelete>0){

		 deleteOk=true;

		}
        reload();
		Logger.traceExit();

		return deleteOk;

	}



	public boolean createNewDoc(String linkId, String linkOrDocGroupName,

			String linkorDocGroupDesc, String filePath, String userId) throws IIMexException {

		Logger.traceEntry();

		boolean succesful = false;

		int rowInsert =0;

	//	LinkAndDocument linkAndDoc =tmLinks.get(new Integer(linkId));

				Date publishDate = new Date();

		rowInsert = linkLoadData.addDoc(linkId,linkOrDocGroupName, linkorDocGroupDesc,filePath,userId,publishDate);

		

		

		if(rowInsert >0){

			succesful=true;

		}

        reload();
		Logger.traceExit();

		return succesful;

		}



	public boolean updateDoc(String linkId, String docId,

			String linkOrDocGroupName, String linkorDocGroupDesc,

			String filePath, String userId) throws IIMexException{

		Logger.traceEntry();

		boolean succesful=false;

		int rowInsert = 0;

		

		rowInsert = linkLoadData.updateDoc(linkId, docId,linkOrDocGroupName, linkorDocGroupDesc,filePath, userId);

		if(rowInsert > 0){

			succesful = true;

		}
        reload();
		return succesful;

	}

}

