package com.monsanto.enterprise.iimex.collections;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.MonitoredUser;
import com.monsanto.enterprise.iimex.tableloader.TableLoadMonitoredUser;

public class MonitoredUserCollection{
	
	private Vector<MonitoredUser> userList=null;
	private TableLoadMonitoredUser tlm = new TableLoadMonitoredUser();
	
	public MonitoredUserCollection() {
	}
	
	public void setList(Vector uL){
		userList=uL;
	}
	
	public Date getMin(){
		if(userList!=null)
			return userList.get(0).getMin();
		else return(new Date(0));
	}
	
	public MonitoredUser getFirst(){
		if(userList!=null)
			return userList.get(0);
		else return(new MonitoredUser());
	}
	
	public int getNbMonth(){
		if(userList!=null)
			return userList.get(0).getNbMonth();
		else return 0;
	}
	
	public void add(MonitoredUser mu){
		if(userList==null)
			userList = new Vector<MonitoredUser> ();
		userList.add(mu);
	}
	
	public List getList(){
		return userList;
	}
	
	public void loadTable() throws IIMexException{
		userList = tlm.loadMonitoredUser();
	}
	
}