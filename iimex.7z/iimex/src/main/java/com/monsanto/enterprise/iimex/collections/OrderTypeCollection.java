/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.CompanyDetermination;
import com.monsanto.enterprise.iimex.elements.orderType;
import com.monsanto.enterprise.iimex.tableloader.TableLoadOrderType;
import com.monsanto.enterprise.iimex.tableloader.TableLoader;

/**
 * All order type object collection.
 * 
 * Filename:    $RCSfile: OrderTypeCollection.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 * @version     $Revision: 1.8 $
 * @author      MMCORT3
 */

public class OrderTypeCollection extends TableLoader{

	private HashMap<String, HashMap<String, orderType>>  orderTypes=null;

	private TableLoadOrderType orderTypeLoadData = new TableLoadOrderType();

/**Load all the order type data (purchase order type, sales order type) in the hashMap contained in orderTypes (key:selling company code, value hashMap (key:sold to company code, value order type))
 * 
 * @throws IIMexException
 */

public void loadTable()throws IIMexException{
	Logger.traceEntry();
	orderTypes = orderTypeLoadData.loadOrderType();
	Logger.traceExit();
}

/**
 * Reload the order type data in the hashMap orderTypes
 * @throws IIMexException
 */

public void reload()throws IIMexException{
	Logger.traceEntry();
	loadTable();
	Logger.traceExit();
}

/**
 * Retrieve the order type using the selling company code and the sold to company code
 * @return order type
 * @throws IIMexException
 * @param sellingCompanySoldToCode
 * @param destinationCompanySoldToCode
 * @param destinationSellingCode
 */

public orderType getOrderType(String sellingCompanySoldToCode, String destinationCompanySoldToCode,
                              String destinationSellingCode) throws IIMexException {
	if(orderTypes.get(sellingCompanySoldToCode)!=null){
		if(((HashMap)orderTypes.get(sellingCompanySoldToCode)).get(destinationCompanySoldToCode)!=null){
      orderType orderForSalesOrder = (orderType) ((HashMap)orderTypes.get(sellingCompanySoldToCode)).get(
          destinationSellingCode);
      orderType type = (orderType) ((HashMap) orderTypes.get(sellingCompanySoldToCode)).get(destinationCompanySoldToCode);
      type.setSalesOrderType(orderForSalesOrder.getSalesOrderType());
      return type;
		}else if(((HashMap)orderTypes.get(sellingCompanySoldToCode)).get("*")!=null){
			return (orderType)((HashMap)orderTypes.get(sellingCompanySoldToCode)).get("*");
		}
	}else if(orderTypes.get("*")!=null)
		if(((HashMap)orderTypes.get("*")).get(destinationCompanySoldToCode)!=null)
			return (orderType)((HashMap)orderTypes.get("*")).get(destinationCompanySoldToCode);
		
	return new orderType();
}
/*
 * retrieve all order types for a vector of companies
 */
public Vector<orderType> getOrderTypeVector(Vector companies) throws IIMexException {
	Vector<orderType> result = new Vector<orderType>();
	Iterator ite;
	Iterator it = companies.iterator();
	Vector<orderType> already = new Vector<orderType>();
	while(it.hasNext()){
		CompanyDetermination cd = (CompanyDetermination)it.next();
		String sellingCode = cd.getSellingCompanyCode();
		String soldToCode = cd.getSoldToCompanyCode();
		if(orderTypes.get(sellingCode)!=null){
			ite = ((HashMap)orderTypes.get(sellingCode)).keySet().iterator();
			while(ite.hasNext()){
					orderType ot = (orderType)((HashMap)orderTypes.get(sellingCode)).get((String)ite.next());
					if(!already.contains(ot)){
					result.add(ot);
					already.add(ot);
				}
			}
		}
	
		ite = orderTypes.keySet().iterator();
		while(ite.hasNext()){
			String tmp = (String)ite.next();
			if(((HashMap)orderTypes.get(tmp)).get(soldToCode)!=null){
				orderType ot = (orderType)(((HashMap)orderTypes.get(tmp)).get(soldToCode));
				if(!already.contains(ot)){
					result.add(ot);
					already.add(ot);
				}	
			}
		}
	}

	return result;
}

/**
 * Get all order type
 * @return a List with all the country ordered asc
 * @throws IIMexException
 */

public HashMap getAllOrder() throws IIMexException {
	Logger.traceEntry();
	return orderTypes;
}

public int addOrder(orderType order, String code) throws IIMexException{
	Logger.traceEntry();
	int addOk=-1;
	addOk = orderTypeLoadData.addOrder(order, code);
    reload();
	Logger.traceExit();
	return addOk;
}

public int updateOrder(orderType order, String code) throws IIMexException{
	Logger.traceEntry();
	int updateOk=-1;
	updateOk = orderTypeLoadData.updateOrder(order, code);
    reload();
	Logger.traceExit();
	return updateOk;
}

public int removeOrder(orderType order, String code) throws IIMexException{
	Logger.traceEntry();
	int removeOk=-1;
	removeOk = orderTypeLoadData.removeOrder(order, code);
    reload();
	Logger.traceExit();
	return removeOk;
}


}

	

