/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.PhytoRequirement;
import com.monsanto.enterprise.iimex.tableloader.TableLoadRequirements;
import com.monsanto.enterprise.iimex.tableloader.TableLoader;

/**
 * All PhytoRequirement object collection.
 * <p/>
 * Filename:    $RCSfile: PhytoRequirementCollection.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 *
 * @author MMCORT3
 * @version $Revision: 1.5 $
 */

public class PhytoRequirementCollection extends TableLoader {

    private HashMap<String, HashMap<String, HashMap<String, Vector<PhytoRequirement>>>> requirement = null;

    private TableLoadRequirements requirementLoadData = new TableLoadRequirements();

    /**
     * Load all the PhytoRequirement data in the hashMap requirement (key: phyto code, value requirement)
     *
     * @throws IIMexException
     */

    public void loadTable() throws IIMexException {
        Logger.traceEntry();
        requirement = requirementLoadData.loadRequirements();
        Logger.traceExit();
    }

    /**
     * Reload the pyto data
     *
     * @throws IIMexException
     */

    public void reload() throws IIMexException {
        Logger.traceEntry();        
        loadTable();
        Logger.traceExit();
    }

    /**
     * get all the requirement for a shipment (shipping country, destination one and product group)
     */

    public Vector<PhytoRequirement> getRequirementsByCode(String countryOfOrigin, String destination, String productGroup) throws IIMexException {
        Logger.traceEntry();
        HashMap<String, HashMap<String, Vector<PhytoRequirement>>> map1 = requirement.get(countryOfOrigin);
        if (map1 != null) {
            HashMap<String, Vector<PhytoRequirement>> map2 = map1.get(destination);
            if (map2 != null) {
                Vector<PhytoRequirement> phytoRequirementVector = map2.get(productGroup);
                if (phytoRequirementVector!=null){
                    return phytoRequirementVector;
                }
            }
        }
        return new Vector<PhytoRequirement>();
    }

    /**
     * Get all the requirements
     */

    public Vector getAllRequirement() throws IIMexException {
        Logger.traceEntry();
        Vector<PhytoRequirement> requirements = new Vector<PhytoRequirement>();
        Iterator it = requirement.keySet().iterator();
        Iterator it2;
        Iterator it3;
        Iterator it4;
        while (it.hasNext()) {
            it2 = ((HashMap) requirement.get((String) it.next())).keySet().iterator();
            while (it2.hasNext()) {
                it3 = ((HashMap) ((HashMap) requirement.get((String) it.next())).get((String) it2.next())).keySet().iterator();
                while (it3.hasNext()) {
                    it4 = ((Vector) ((HashMap) ((HashMap) requirement.get((String) it.next())).get((String) it2.next())).get((String) it3.next())).iterator();
                    while (it4.hasNext()) {
                        requirements.add((PhytoRequirement)it4.next());
                    }
                }
            }
        }
        return requirements;
    }

}

	

