/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.collections;



import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;
import com.monsanto.enterprise.iimex.tableloader.TableLoadPlants;



/**

 * In the plantCollection object are stocked in a hashMap all the plants, the key are the country and by country

 *  we can find a hashMap where the key is the product group. All the plants data manipulations are made in this object

 * 

 * Filename:    $RCSfile: PlantsCollection.java,v $

 * Label:       $Name:  $

 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $

 * @version     $Revision: 1.15 $

 * @author      MMCORT3

 */

public class PlantsCollection {



		private HashMap<String, HashMap<String, PlantsFromCountry>> mhPlants = null;

		private TableLoadPlants plantsLoadData = new TableLoadPlants();

		

		/**

		 * Load all the data to the hashMap

		 * @throws IIMexException

		 */

		public void loadTable(CompaniesCollection companiesCollection,CountryCollection countryColl)

		throws IIMexException{



			Logger.traceEntry();

			mhPlants =plantsLoadData.loadPlantsRows(companiesCollection,countryColl);

			Logger.traceExit();



		}

		/**

		 * Reload data

		 * @throws IIMexException

		 */

		public void reload(CompaniesCollection companiesCollection,CountryCollection countryColl)throws IIMexException{

			Logger.traceEntry();

			loadTable(companiesCollection,countryColl);

			Logger.traceExit();

		}
		//retrieve every plants in a country for a specific division
		public List getFromPlantsByCode(String fromCountry, String division)

		throws IIMexException{

			Logger.traceEntry();

			List plantsListDivision=new ArrayList();

			if(mhPlants.containsKey(fromCountry)){

				HashMap plantListCountry = (HashMap)mhPlants.get(fromCountry);

				Iterator ite = plantListCountry.keySet().iterator();
				
				while(ite.hasNext()){
					PlantsFromCountry plant = (PlantsFromCountry)plantListCountry.get(ite.next());
					if(plant.getDivision().containsKey(division))
						
					plantsListDivision.add(plant);

				}

			}

			PlantsComparator oPlantsComparator = new PlantsComparator();

			Collections.sort(plantsListDivision, oPlantsComparator);


			Logger.traceExit();

			return plantsListDivision;

		}

/**

 * Get all the plants information including the product group in a Vector ordered by plant code and by company code

 * @return

 * @throws IIMexException

 */	

public List getAllPlantsDivision()

throws IIMexException{

			 Vector plantsElements= new Vector();

			 Iterator it1 = mhPlants.values().iterator();

			 while(it1.hasNext()){

				 HashMap plantsCountryList = (HashMap)it1.next();

				 Iterator it2 =plantsCountryList.values().iterator();

				 while(it2.hasNext()){

					 List plantsDivisionList =(List	)it2.next();

					 plantsElements.addAll(plantsDivisionList);

				 }

			 }

			 FromPlantComparator oPlantsComparator = new FromPlantComparator();

			 Collections.sort(plantsElements,oPlantsComparator); 

			 

			 return plantsElements;

		}



/**

 * Get all the plants information in a Vector ordered by plant code and by company code

 * @return

 * @throws IIMexException

 */	

public List<PlantsFromCountry> getAllPlants()

throws IIMexException{
			List<PlantsFromCountry> result = new ArrayList<PlantsFromCountry>();
			Iterator it1 = mhPlants.values().iterator();
			 while(it1.hasNext()){
				 HashMap plantsCountryList = (HashMap)it1.next();
				 Iterator it2 =plantsCountryList.values().iterator();
				 while (it2.hasNext()){
					result.add((PlantsFromCountry)it2.next());
				 }
			 }
			 FromPlantComparator oPlantsComparator = new FromPlantComparator();
			 Collections.sort(result,oPlantsComparator);		 
			 return result;
}
/**
 * 
 * @param countryCode
 * @return a list of all plants in a specific country
 */
public List<PlantsFromCountry> getAllPlantsByCountry(String countryCode)

throws IIMexException{
			List<PlantsFromCountry> result = new ArrayList<PlantsFromCountry>();
			Iterator it1 = mhPlants.values().iterator();
			 while(it1.hasNext()){
				 HashMap plantsCountryList = (HashMap)it1.next();
				 Iterator it2 =plantsCountryList.values().iterator();
				 while (it2.hasNext()){
					 PlantsFromCountry pfc = (PlantsFromCountry)it2.next();
					 if(pfc.getCodeFromCountry().compareTo(countryCode)==0)
						 result.add(pfc);
				 }
			 }
			 FromPlantComparator oPlantsComparator = new FromPlantComparator();
			 Collections.sort(result,oPlantsComparator);		 
			 return result;
}
//retrieve a specific plant using its code
public PlantsFromCountry getPlantByCode(String code) throws IIMexException{

	List result = new ArrayList();
	Iterator it1 = mhPlants.values().iterator();
	 while(it1.hasNext()){
		 HashMap plantsCountryList = (HashMap)it1.next();
		 Iterator it2 =plantsCountryList.values().iterator();
		 while (it2.hasNext()){
			 PlantsFromCountry plant = (PlantsFromCountry)it2.next();
			 if(plant.getCodePlant().compareTo(code)==0)
			 return plant;
		 }
	 }
	 return new PlantsFromCountry();
}


//add a plant in the collection
public int addPlant(PlantsFromCountry plant) throws IIMexException{
	Logger.traceEntry();
	int rowUpdate = 0;
	rowUpdate = plantsLoadData.addPlant(plant);
	Logger.traceExit();
	return rowUpdate;

}
//update an existing plant
public int updatePlant(PlantsFromCountry plant) throws IIMexException{
	Logger.traceEntry();
	int rowUpdate = 0;
	rowUpdate = plantsLoadData.updatePlant(plant);
    CollectionsChangeMonitor.plantsCollectionChanged=true;
	Logger.traceExit();
	return rowUpdate;
}
// remove a plant from the collection 
public int inactivePlant(String code) throws IIMexException{
	Logger.traceEntry();
	int rowUpdate = 0;
	rowUpdate = plantsLoadData.inactivePlant(code);
    CollectionsChangeMonitor.plantsCollectionChanged=true;
	Logger.traceExit();
	return rowUpdate;

}
//activate an existing plant
public int activePlant(String code) throws IIMexException{
	Logger.traceEntry();
	int rowUpdate = 0;
	rowUpdate = plantsLoadData.activePlant(code);
    CollectionsChangeMonitor.plantsCollectionChanged=true;
	Logger.traceExit();
	return rowUpdate;

}
//insert a division to a plant
public int addPlantDivision(String codePlant, String codeDivision, String Comment,String User) throws IIMexException{
	Logger.traceEntry();
	int rowUpdate = 0;
	rowUpdate = plantsLoadData.addPlantDivision(codePlant,codeDivision,Comment,User);
    CollectionsChangeMonitor.plantsCollectionChanged=true;
	Logger.traceExit();
	return rowUpdate;
}
//delete a division from a plant 
public int deletePlantDivision(String codePlant, String codeDivision) throws IIMexException{
	Logger.traceEntry();
	int rowUpdate = 0;
	rowUpdate = plantsLoadData.deletePlantDivision(codePlant,codeDivision);
    CollectionsChangeMonitor.plantsCollectionChanged=true;
	Logger.traceExit();
	return rowUpdate;
}
//update a division's information from a plant
public int updatePlantDivision(String codePlant, String codeDivision, String Comment,String User) throws IIMexException{
	Logger.traceEntry();
	int rowUpdate = 0;
	rowUpdate = plantsLoadData.updatePlantDivision(codePlant,codeDivision,Comment,User);
    CollectionsChangeMonitor.plantsCollectionChanged=true;
	Logger.traceExit();
	return rowUpdate;
}
}

