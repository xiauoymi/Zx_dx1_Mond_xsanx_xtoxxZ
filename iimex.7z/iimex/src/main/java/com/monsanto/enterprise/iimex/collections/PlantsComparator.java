package com.monsanto.enterprise.iimex.collections;

import java.util.Comparator;

import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;
/*
 * use to compare two plants using their code
 */
public class PlantsComparator implements Comparator<PlantsFromCountry>{

	public int compare(PlantsFromCountry a_Object1, PlantsFromCountry a_Object2){
	try{		
		return a_Object1.getCodePlant().compareTo(a_Object2.getCodePlant());
	}catch (Exception ex) {
		return 0;
	}
	
	}	
}