/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.collections;



import java.util.Collection;

import java.util.Collections;

import java.util.HashMap;

import java.util.Iterator;

import java.util.List;

import java.util.TreeMap;

import java.util.Vector;



import com.monsanto.AbstractLogging.Logger;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.ProductGroup;

import com.monsanto.enterprise.iimex.elements.ProductOrigin;

import com.monsanto.enterprise.iimex.tableloader.TableLoadProducts;

/**

 * ProductCollection contains all the productOrigin and all the productGroup and manage the methode related

 * with the productOrigin and with the productGroup

 * 

 * Filename:    $RCSfile: ProductCollection.java,v $

 * Label:       $Name:  $

 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $

 * @version     $Revision: 1.12 $

 * @author      MMCORT3

 */

public class ProductCollection {

	private TreeMap<String, ProductOrigin> tmProdOrigin=null;

	private HashMap<String, ProductGroup> hmProdGroup = null;

	private TableLoadProducts productsLoadData = new TableLoadProducts();

	private List<String> fieldPRoductGroup = null;

	

	/**

	 * Load the data in the hashMaps

	 * Load the productGroup in a hashMap where the key is the productGroupCode and the value is a ProductGroup

	 * Load the productOrigin in a hashMap where the key is the productOriginCode and the value is a ProductOrigin

	 * @throws IIMexException

	 */

	public void loadTable()

	throws IIMexException{

		Logger.traceEntry();

		tmProdOrigin=productsLoadData.loadProductOrigin();

		hmProdGroup = productsLoadData.loadProductGroup();

		fieldPRoductGroup= productsLoadData.loadProductGroupColumName();

		Logger.traceExit();

	}

	/**

	 * Reload the data

	 * @throws IIMexException

	 */

	public void reload()throws IIMexException{

		Logger.traceEntry();

		loadTable();

        CollectionsChangeMonitor.countriesCollectionsChanged=true;

		Logger.traceExit();

	}

	/**

	 * Get a Vector with all the productGroup

	 * @return

	 * @throws IIMexException

	 */

	public Vector getAllProductGroup()

	throws IIMexException{

		Logger.traceEntry();

		Vector vAllProductGroup = new Vector();

		Iterator itProductGroup = hmProdGroup.values().iterator();

		while(itProductGroup.hasNext()){

			vAllProductGroup.add(itProductGroup.next());

		}

		ProductGroupComparator oProdGroupComparator = new ProductGroupComparator();

		Collections.sort(vAllProductGroup, oProdGroupComparator);

		Logger.traceExit();

		return vAllProductGroup;

	}
	/*
	 * retrieve all the products group that are in a specified division
	 */
	public Vector<ProductGroup> getAllProductGroupByDivision(String code)

	throws IIMexException{

		Logger.traceEntry();

		Vector<ProductGroup> vAllProductGroup = new Vector<ProductGroup>();

		Iterator itProductGroup = hmProdGroup.values().iterator();

		while(itProductGroup.hasNext()){
			ProductGroup pg = (ProductGroup)itProductGroup.next();
			if(pg.getDivisionCode().compareTo(code)==0)
				vAllProductGroup.add(pg);

		}

		ProductGroupComparator oProdGroupComparator = new ProductGroupComparator();

		Collections.sort(vAllProductGroup, oProdGroupComparator);

		Logger.traceExit();

		return vAllProductGroup;

	}

	/**

	 * Get a vector with all the productOrigin  

	 * @return 

	 * @throws IIMexException

	 */

	public Collection getAllProductOrigin()

	throws IIMexException{

		Logger.traceEntry();

		Collection v =tmProdOrigin.values();

		Logger.traceExit();

		return v;

	}

	

	/**

	 * Get the productGroup with the prodCode

	 * @param prodCode

	 * @return

	 * @throws IIMexException

	 */

	public ProductGroup getProductGroup(String prodCode)throws IIMexException{

		ProductGroup oProdGroup = hmProdGroup.get(prodCode);

		

		return oProdGroup;

	}

	



	/**

	 * Get teh productOrigin with the prodOrigin code

	 */

	public ProductOrigin getProductOrigin(String prodCode)throws IIMexException{

		ProductOrigin oProdOrigin = tmProdOrigin.get(prodCode);

		

		return oProdOrigin;

	}

	public List getProductGroupField()

	throws IIMexException{

		return fieldPRoductGroup;

	}

	public String getProductName(String productCode) throws IIMexException{

		ProductGroup product = hmProdGroup.get(productCode);

		

		return product.getProductGroupName();

	}
	//add  a product to  the collection
	public int addProduct(ProductGroup prod)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = productsLoadData.addProduct(prod);
        reload();
		Logger.traceExit();
		return rowUpdate;	
	}
	//update an existing product
	public int updateProduct(ProductGroup prod)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = productsLoadData.updateProduct(prod);
        reload();
		Logger.traceExit();
		return rowUpdate;	
	}
	//remove a product from the collection
	public int removeProduct(String prod)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = productsLoadData.removeProduct(prod);
        reload();
		Logger.traceExit();
		return rowUpdate;
	}



}

