package com.monsanto.enterprise.iimex.collections;
import java.util.Comparator;

import com.monsanto.enterprise.iimex.elements.ProductGroup;
/*
 * Utility class used to sort the product groups
 * the sort is made using the name of the groups
 */
public class ProductGroupComparator implements Comparator<ProductGroup>{

	public int compare(ProductGroup a_Object1, ProductGroup a_Object2){
	try{
   	return a_Object1.getProductGroupName().compareTo(a_Object2.getProductGroupName());
	}catch (Exception ex) {
		return 0;
	}
	
	}	
}
