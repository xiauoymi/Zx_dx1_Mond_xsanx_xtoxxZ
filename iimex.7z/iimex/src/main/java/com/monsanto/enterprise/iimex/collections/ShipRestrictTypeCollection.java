package com.monsanto.enterprise.iimex.collections;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.ShippingRestrictionType;
import com.monsanto.enterprise.iimex.tableloader.TableLoaderShippingRestrictType;

import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 16, 2010
 * Time: 3:19:48 PM
 */
public class ShipRestrictTypeCollection {

    private Vector<ShippingRestrictionType> types=null;
    private TableLoaderShippingRestrictType typesLoadData = new TableLoaderShippingRestrictType();

    /**
     * This method was created for testing only
     */
    protected void setTypesCache(Vector<ShippingRestrictionType> types) {
        this.types = types;
    }
    /**
     * This method was created for testing only
     */
    protected void setLoader(TableLoaderShippingRestrictType loader) {
        typesLoadData = loader;
    }

    public void loadTable()throws IIMexException {
        Logger.traceEntry();
        types = typesLoadData.loadShippingRestrictType();
        Logger.traceExit();
    }

    public void reload()throws IIMexException{
        Logger.traceEntry();
        loadTable();
        Logger.traceExit();
    }

    public Vector<ShippingRestrictionType> getAllTypes() {
        Logger.traceEntry();
        return types;
    }

    public int updateType(ShippingRestrictionType type) throws IIMexException {
        Logger.traceEntry();
        if (hasDupInCacheUpdate(type)) {
            throw new IIMexEntityCollisionException("Duplicate Shipping Restriction Type name already found: " + type.getName());
        }
        int updOK = typesLoadData.updateShipRestrictType(type);
        reload();
        Logger.traceExit();
        return updOK;
    }

    public int addType(ShippingRestrictionType type) throws IIMexException {
        Logger.traceEntry();
        if (hasDupInCache(type)) {
            throw new IIMexEntityCollisionException("Duplicate Shipping Restriction Type name already found: " + type.getName());
        }
        int addOK = typesLoadData.addShipRestrictType(type);
        reload();
        Logger.traceExit();
        return addOK;
    }

    private boolean hasDupInCache(ShippingRestrictionType newType) {
        for (ShippingRestrictionType cachedType : types) {
            if (cachedType.getName().equals(newType.getName())) {
                return true;
            }
        }
        return false;  //To change body of created methods use File | Settings | File Templates.
    }

    private boolean hasDupInCacheUpdate(ShippingRestrictionType newType) {
        for (ShippingRestrictionType cachedType : types) {
            if (cachedType.getName().equals(newType.getName())) {
                return !cachedType.getCode().equals(newType.getCode());
            }
        }
        return false;  //To change body of created methods use File | Settings | File Templates.
    }

    public int removeType(String typeCode) throws IIMexException {
        Logger.traceEntry();
        int deleteOK = typesLoadData.removeShipRestrictType(typeCode);
        reload();
        Logger.traceExit();
        return  deleteOK;
    }
}
