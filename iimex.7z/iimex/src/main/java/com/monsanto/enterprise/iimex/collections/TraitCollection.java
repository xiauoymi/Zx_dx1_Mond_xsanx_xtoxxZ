package com.monsanto.enterprise.iimex.collections;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.ProductGroup;
import com.monsanto.enterprise.iimex.elements.Trait;
import com.monsanto.enterprise.iimex.tableloader.TableLoadTrait;
/**
 * All trait object collection.
 * 
 **/
public class TraitCollection {

	private Vector<Trait> Trait=null;

	private TableLoadTrait traitLoadData = new TableLoadTrait();

	/**Load all the trait data (trait name, trait name, product group code, OECD identifier, lab office code, approved)
	 * Vector Trait
	 * 
	 * @throws IIMexException
	 */
	public void loadTable()throws IIMexException{
		Logger.traceEntry();
		Trait=traitLoadData.loadTraits();
		Logger.traceExit();
	}
	/**
	 * Reload the trait data in the Vector Trait
	 * @throws IIMexException
	 */

	public void reload()throws IIMexException{
		Logger.traceEntry();
		Trait=traitLoadData.loadTraits();
		Logger.traceExit();
	}
	/**
	 * return all trait in a vector
	 **/
	public Vector getAllTrait(){
		if(Trait!=null)
			return Trait;
		else return new Vector();
	}
	
	public Vector getAllTraitByGroup(String group){
		Vector result = new Vector();
		Iterator ite = Trait.iterator();
		while(ite.hasNext()){
			Trait tr = (Trait)ite.next();
			if(tr.getProductGroupCode().compareTo(group)==0)
				result.add(tr);
		}
		return result;
	}
	
	/**
	 * 
	 * @return a trait name using its code to retrieve it
	 */
	public String getTraitName(String code){
		Iterator ite = Trait.iterator();
		String name=" ";
		while(ite.hasNext()){
			Trait div = (Trait)ite.next();
			if(code.compareTo(div.getTraitCode())==0)
				name=div.getTraitName();
		}
		return name;
	}
	/**
	 * 
	 * @return a trait using its code to retrieve it
	 */
	public Trait getTrait(String code){
		Iterator ite = Trait.iterator();
		Trait good = new Trait();
		Trait tmp;
		while(ite.hasNext()){
			tmp=(Trait)ite.next();
			if(tmp.getTraitCode().compareTo(code)==0)
				good=tmp;
		}
		return good;
	}
	/*
	 * add a trait to the collection
	 */
	public int addTrait(Trait tr)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = traitLoadData.addTrait(tr);
        reload();
		Logger.traceExit();
		return rowUpdate;	
	}
	/*
	 * update a trait in the collection
	 */
	public int updateTrait(Trait tr)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = traitLoadData.updateTrait(tr);
        reload();
		Logger.traceExit();
		return rowUpdate;	
	}
	/*
	 * remove a trait from the collection
	 */
	public int removeTrait(String tr)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = traitLoadData.removeTrait(tr);
        reload();
		Logger.traceExit();
		return rowUpdate;
	}
	/*
	 * add some trait-country information in the collection
	 */
	public int addTraitCountry(String code, String destination, String production,String impor, String food, String owner)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = traitLoadData.addTraitCountry(code, destination, production, impor, food, owner);
        reload();
		Logger.traceExit();
		return rowUpdate;	
	}
	/*
	 * update some trait-country information in the collection
	 */
	public int updateTraitCountry(String code, String destination, String production,String impor, String food, String owner)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = traitLoadData.updateTraitCountry(code, destination, production, impor, food, owner);
        reload();
		Logger.traceExit();
		return rowUpdate;	
	}
	/*
	 * remove some trait-country information from the collection
	 */
	public int removeTraitCountry(String code, String destination)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = traitLoadData.removeTraitCountry(code, destination);
        reload();
		Logger.traceExit();
		return rowUpdate;
	}
	
}