package com.monsanto.enterprise.iimex.collections;

import java.util.Comparator;

import com.monsanto.enterprise.iimex.elements.IncotermTransportInfo;

/*
 * class used to compare two transport mode
 * if the name are the same then the incoterm code 
 * is used to compare them
 * otherwise it is just a comparison on the name
 */

public class TranspModeComparator implements Comparator<IncotermTransportInfo>{

	public int compare(IncotermTransportInfo a_Object1, IncotermTransportInfo a_Object2){
	try{

		int compareTransp=0;
		int compareIncoterm=0;
		int compare=0;
		
		compareTransp= a_Object1.getTransportName().compareTo(a_Object2.getTransportName());
		if(compareTransp==0){
			compareIncoterm = a_Object1.getIncotermsCode().compareTo(a_Object2.getIncotermsCode());
			compare=compareIncoterm;
		}else{
			compare=compareTransp;
		} 
		 return compare;
	}catch (Exception ex) {
		return 0;
	}
	
	}	
}
