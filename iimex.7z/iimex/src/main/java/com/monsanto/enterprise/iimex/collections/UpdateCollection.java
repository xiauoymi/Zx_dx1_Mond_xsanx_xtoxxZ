package com.monsanto.enterprise.iimex.collections;

import java.sql.Date;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.Update;
import com.monsanto.enterprise.iimex.tableloader.TableLoadMonitoredUser;
import com.monsanto.enterprise.iimex.tableloader.UpdateTableLoader;
/*
 * collection that manages the update information
 */
public class UpdateCollection{
	private Update[] last=null;
	private UpdateTableLoader utl= new UpdateTableLoader();
	
	public UpdateCollection(){
		last= new Update[10];
		for(int i = 0 ; i< 10 ; i++){
			last[i]=new Update();
			last[i].setDate(new Date(0));
		}
	}
	
	public void set(int index, Update u){last[index]=u;}
	public Update get(int index){return last[index];}
	
	public Update[] getLast(){return last;}
	public void setLast(Update[] l){last=l;}
	
	public void loadTable() throws IIMexException{
		for(int i = 0 ; i< 10 ; i++){
			last[i]=new Update();
			last[i].setDate(new Date(0));
		}
		last=utl.loadLastUpdate();
	}
	
}