package com.monsanto.enterprise.iimex.collections;

import java.util.Comparator;

import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.User;

public class UserComparator implements Comparator<User>{

	public int compare(User a_Object1, User a_Object2){
	try{
		return a_Object1.getNom().compareTo(a_Object2.getNom());
	}catch(IIMexException IIMexEx){
		return 0;
	}
	
	}	
}