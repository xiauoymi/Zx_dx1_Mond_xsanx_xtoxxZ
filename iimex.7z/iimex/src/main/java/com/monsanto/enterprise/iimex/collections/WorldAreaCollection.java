package com.monsanto.enterprise.iimex.collections;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.WorldArea;
import com.monsanto.enterprise.iimex.elements.customZone;
import com.monsanto.enterprise.iimex.tableloader.TableLoadWorldArea;
/*
 * This class manage the collection of all world areas
 */
public class WorldAreaCollection{
	private Vector<WorldArea> worldAreas=null;
	private TableLoadWorldArea tlw = new TableLoadWorldArea();
	
	public WorldAreaCollection(){}
	public void setAreas(Vector<WorldArea> w){worldAreas=w;}
	public Vector getAllAreas(){return worldAreas;}
	/*
	 * call the class loader to feed the collection
	 */
	public void loadTable() throws IIMexException{
		Logger.traceEntry();
		worldAreas =tlw.loadAreas();
		Logger.traceExit();
	}
	/*
	 * call the class loader to feed again the collection
	 * used when something an input has been changed during the session
	 */
	public void reloadTable() throws IIMexException{ 
		Logger.traceEntry();
		loadTable();
        CollectionsChangeMonitor.countriesCollectionsChanged=true;
		Logger.traceExit();
	}
	
	/**
	 * Get a country using its code
	 * @return a Country
	 * @throws IIMexException
	 */

	public WorldArea getAreaByCode(String code) throws IIMexException {
		Logger.traceEntry();
		Iterator ite = worldAreas.iterator();
		WorldArea tmp;
		while(ite.hasNext()){
			tmp = (WorldArea)ite.next();
			if(tmp.getAreaCode().compareTo(code)==0)
				return tmp;
		}
		tmp = new WorldArea();
		Logger.traceExit();
		return tmp;
	}
	/*
	 * retrieve the are name using its code
	 */
	public String getAreaName(String code) throws IIMexException {
		Logger.traceEntry();
		Iterator ite = worldAreas.iterator();
		WorldArea tmp;
		if(!StringUtils.isNullOrEmpty(code)){
			while(ite.hasNext()){
				tmp = (WorldArea)ite.next();
				if(tmp.getAreaCode().compareTo(code)==0)
					return tmp.getAreaName();
			}
		}	
		Logger.traceExit();
		return "";
	}
	/*
	 * add an area to the collection
	 */
	public int addArea(WorldArea wa)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = tlw.addArea(wa);
        reloadTable();
		Logger.traceExit();
		return rowUpdate;	
	}
	/*
	 * update an area in the collection
	 */
	public int updateArea(WorldArea wa)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = tlw.updateArea(wa);
        reloadTable();
		Logger.traceExit();
		return rowUpdate;	
	}
	/*
	 * remove an area from the collection
	 */
	public int removeArea(String wa)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=-1;
		rowUpdate = tlw.removeArea(wa);
        reloadTable();
		Logger.traceExit();
		return rowUpdate;
	}
}
