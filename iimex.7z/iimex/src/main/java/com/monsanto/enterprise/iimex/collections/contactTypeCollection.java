/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.collections;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.contactType;
import com.monsanto.enterprise.iimex.tableloader.TableLoadContactType;
import com.monsanto.enterprise.iimex.tableloader.TableLoadContacts;
import com.monsanto.enterprise.iimex.tableloader.TableLoadCountries;
import com.monsanto.enterprise.iimex.tableloader.TableLoader;

/**
 * Contact type object collection.
 * 
 * Filename:    $RCSfile: contactTypeCollection.java,v $
 * Label:       $Name:  $
 * Last Change: $Author: tadial $    	 On:	$Date: 2009/10/15 20:30:01 $
 * @version     $Revision: 1.7 $
 * @author      MMCORT3
 */

public class contactTypeCollection extends TableLoader{

	private Vector<contactType> types=null;

	private TableLoadContactType typesLoadData = new TableLoadContactType();

/**Load all the contact type data
 * 
 * @throws IIMexException
 */

public void loadTable()throws IIMexException{
	Logger.traceEntry();
	types = typesLoadData.loadContactsType();
	Logger.traceExit();
}

/**
 * Reload the contact type data 
 * @throws IIMexException
 */

public void reload()throws IIMexException{
	Logger.traceEntry();
	loadTable();
    CollectionsChangeMonitor.contactsTypeCollectionChanged=true;
	Logger.traceExit();
}

/**
 * Get all the contact types
 * @return a Vector
 * @throws IIMexException
 */

public Vector getAllTypes() throws IIMexException {
	Logger.traceEntry();
	return types;
}

/**
 * Get a type using its code
 */

public contactType getType(String code) throws IIMexException {
	Logger.traceEntry();
	contactType type;
	for(int i=0;i<types.size();i++) {
		type = types.get(i);
		if(type.getTypeCode().compareTo(code)==0)
			return type;
	}
	Logger.traceExit();
	return new contactType();
}
/**
 * Get a type name using its code
 */
public String getTypeName(String code) throws IIMexException {
	Logger.traceEntry();
	contactType type;
	for(int i=0;i<types.size();i++) {
		type = types.get(i);
		if(type.getTypeCode().compareTo(code)==0)
			return type.getName();
	}
	Logger.traceExit();
	return "";
}
//manage types in the database

public int addType(contactType ct) throws IIMexException {
	Logger.traceEntry();
	int addOK = 0;
	addOK = typesLoadData.addContactType(ct);
    reload();
	Logger.traceExit();
	return addOK;
}

public int updateType(contactType ct) throws IIMexException {
	Logger.traceEntry();
	int addOK = 0;
	addOK = typesLoadData.updateContactType(ct);
    reload();
	Logger.traceExit();
	return addOK;
}

public int removeType(String ct) throws IIMexException {
	Logger.traceEntry();
	int addOK = 0;
	addOK = typesLoadData.removeContactType(ct);
    reload();
	Logger.traceExit();
	return addOK;
}

}

	

