package com.monsanto.enterprise.iimex.collections;

import java.util.List;

import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.tableloader.TableLoadCustoms;

public class customsCollection{
	private List<String> customs=null;
	private TableLoadCustoms tlc = new TableLoadCustoms();
	
	public customsCollection(){;}
	public void setCustoms(List c){customs=c;}
	public List getCustoms(){return customs;}
	public void loadTable() throws IIMexException{ customs =tlc.loadCustoms();}
	public void reloadTable() throws IIMexException{
		customs =tlc.loadCustoms();
	}
	
}