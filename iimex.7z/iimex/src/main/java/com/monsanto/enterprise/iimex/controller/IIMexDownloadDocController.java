/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller;



import java.io.BufferedInputStream;

import java.io.BufferedOutputStream;

import java.io.FileInputStream;

import java.io.FileOutputStream;

import java.io.IOException;

import java.io.InputStream;

import java.io.OutputStream;

import java.io.Writer;

import java.util.Collection;



import oracle.jdbc.driver.OracleBlobInputStream;

import oracle.jdbc.driver.OracleInputStream;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.FormattedWriter;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.FileUtil;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.controller.utils.IIMexDocWriter;

import com.monsanto.enterprise.iimex.elements.DocLink;

import com.monsanto.enterprise.iimex.elements.Documents;

import com.monsanto.enterprise.iimex.elements.LinkAndDocument;

import com.monsanto.enterprise.iimex.tableloader.TableGetDocument;

/**

 * Download the document.

 * Get the the document from the linkCollection with the linkId and docId and send the document to the client pc.

 * 

 * Filename:    $RCSfile: IIMexDownloadDocController.java,v $

 * Label:       $Name:  $

 * Last Change: $Author: mmcort3 $    	 On:	$Date: 2008/07/11 09:23:56 $

 * @version     $Revision: 1.3 $

 * @author      MMCORT3

 */



public class IIMexDownloadDocController implements UseCaseController{

	

	public void run (UCCHelper helper) throws IOException

	{

		try{

			String docId=helper.getRequestParameterValue("docId");

			String linkId=helper.getRequestParameterValue("linkId");

			if(!StringUtils.isNullOrEmpty(linkId)){

				LinkAndDocument linkAndDocument = IIMexServlet.iimexUsersManager.getLinks().getLinkAndDocument(linkId);

				DocLink docLink = linkAndDocument.getDocLink(docId);

				BufferedInputStream docInput = new BufferedInputStream(docLink.getDocument());

			 	IIMexDocWriter iimexDoc = new IIMexDocWriter(docLink.getDocName(),helper,docInput);

			 	helper.writeToFormattedWriter(iimexDoc);

			}else{

				Documents docReq =IIMexServlet.iimexUsersManager.getDocuments().getDocumentRequirements(Integer.parseInt(docId));

				BufferedInputStream docInput =new BufferedInputStream(docReq.getDocument());

				IIMexDocWriter iimexDoc = new IIMexDocWriter(docReq.getFileName(),helper,docInput);

			 	helper.writeToFormattedWriter(iimexDoc);

			}

			

		}catch (IIMexException ex){

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}catch (Exception ex2){

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex2.toString()));

		  	ex2.printStackTrace();

		  	IIMexMailHelper.send(ex2,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

		

	}

}