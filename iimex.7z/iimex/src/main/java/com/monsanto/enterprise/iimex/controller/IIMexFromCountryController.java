package com.monsanto.enterprise.iimex.controller;


import java.io.IOException;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.elements.userselection.Result;
import com.monsanto.enterprise.iimex.elements.userselection.Selection;

/**
*
* <p>Title: IIMExFromCountryController</p>
* <p>Description:Gets all the data that are showed in the selection_tool screen</p>
* <p>Copyright: Copyright (c) 2003</p>
* <p>Company: Monsanto</p>
* @author Java Framework Code  Generator 2.3
* @version 
*/

public class IIMexFromCountryController  implements UseCaseController
{
  
  /**
   * Runs the code that implements the general use case.
   * @param helper a UCCHelper used to perform common UCC tasks
   * @throws IOException
   */
  public void run (UCCHelper helper) throws IOException
  {
	  // GET THE REQUEST SELECT VALUE
	  Selection select = new Selection();
	  select.setShipping(helper.getRequestParameterValue("lstCountryFrom"));
	  
	  select.setDestination(helper.getRequestParameterValue("lstCountryTo"));
	  select.setOrigin(helper.getRequestParameterValue("lstCountryOr"));
	  
	  select.setIncoterm(helper.getRequestParameterValue("lstTranspMode"));
	  select.setTransport(helper.getRequestParameterValue("lstTransp"));
	  
	  select.setDivision(helper.getRequestParameterValue("lstDivision"));
	  String tmp=helper.getRequestParameterValue("lstProdGroup");
	  int index = tmp.indexOf("-");
	  select.setProductGroup(tmp.substring(index+2));
	  tmp=helper.getRequestParameterValue("lstTrait");
	  index = tmp.indexOf("-");
	  select.setTrait(tmp.substring(index+2));
	  
	  Result res = new Result();
	  
	  try {
		res.setSelection(select);
		helper.setSessionParameter("shipCountrySelect", IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(select.getShipping()));
	
	  helper.setSessionParameter("destCountrySelect", IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(select.getDestination()));
	  helper.setSessionParameter("prodOriginSelect", IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(select.getOrigin()));
	  
	  helper.setSessionParameter("transportSelected", select.getTransport());
	  
	  tmp=select.getIncoterm();
	  index = tmp.indexOf ("-");
	  
	  helper.setSessionParameter("transpModeSelect", tmp.substring(index+2));
	  
	  helper.setSessionParameter("divisionSelect", select.getDivision());
	  helper.setSessionParameter("prodGroupSelect", IIMexServlet.iimexUsersManager.getProducts().getProductGroup(select.getProductGroup()) );
	  helper.setSessionParameter("traitSelect", IIMexServlet.iimexUsersManager.getTraitCollection().getTrait(select.getTrait()));
	  
	  helper.setSessionParameter("result", res);
	  helper.setSessionParameter("isSearched", "y");
	  
	  } catch (IIMexException e) {
		  Logger.log(new LoggableError("A error occured " + "The error was: " + e.toString()));
		  	e.printStackTrace();
		  	IIMexMailHelper.send(e,helper.getAuthenticatedUserFullName());
	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");
		}
	  
      helper.redirect(helper.getContextPath()+"/inside/IIMEX_selectiontool.jsp");
	  
  }
  
}

