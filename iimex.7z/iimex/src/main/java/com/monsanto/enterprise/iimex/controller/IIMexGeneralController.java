package com.monsanto.enterprise.iimex.controller;

import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.ProductGroup;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.security.SecurityServiceException;


/**
*
* <p>Title: IMEXGeneralController</p>
* <p>Copyright: Copyright (c) 2003</p>
* <p>Company: Monsanto</p>
* @author Java Framework Code  Generator 2.3
* @version 
*/


public class IIMexGeneralController implements UseCaseController
{
  
  /**
   * Runs the code that implements the general use case.
   * @param helper a UCCHelper used to perform common UCC tasks
   * Check the user option
   *  [1] Country to Country Selection Tool
   *  [2] Reports
   *  [3] Links to other website
   *  [4] Maintenance
   * @throws IOException
   * 
   * 
   */

public void run (UCCHelper helper) throws IOException
  {
	  helper.setSessionParameter("isSearched", "n");
	  if((String)helper.getSessionParameter("user")==null)
	      helper.setSessionParameter("user",helper.getAuthenticatedUserFullName());
	  try{
		  String n_menu=helper.getRequestParameterValue("FromMenu");
		  // Get the FromCountryLis,  it is showed in From Country drop down list
		  	Vector vCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry();
			helper.setSessionParameter("outPutListC", vCountry);
			
			Vector vCustomZone = IIMexServlet.iimexUsersManager.getCustomZonesCollection().getAllCZones();
			helper.setSessionParameter("outPutListCZ", vCustomZone);
			
		 	Vector vCountryToCountry = (Vector) IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getAllCountryToCountry();
			helper.setSessionParameter("outPutListCTC", vCountryToCountry);
			
			Collection vDivision = IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision();
			helper.setSessionParameter("outPutListDI", vDivision);
			
			Iterator ite = vDivision.iterator();
			helper.setSessionParameter("initDivision", ((Division)ite.next()).getDivisionCode());
			
			// Get the ProductGroup list, it is showed in the Product Group drop down list	   
			Vector vAllProductGroup = IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup();
			helper.setSessionParameter("outPutListPG", vAllProductGroup);
			
			helper.setSessionParameter("initProduct", ((ProductGroup)vAllProductGroup.firstElement()).getProductGroupCode());
		
			// Get the trait list, it is showed in the trait drop down list	   
			Vector vAllTrait = IIMexServlet.iimexUsersManager.getTraitCollection().getAllTrait();
			helper.setSessionParameter("outPutListT", vAllTrait);
		
			
			// Get the Transport list, it is showed in the Transport Mode drop down list
			Vector vTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList();
			helper.setSessionParameter("outPutListM", vTransport);
		
			// Get the IncotermsTransport list, it is showed in the Transport Mode - Incoterm drop down list
			Vector vIncotermsTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getIncotermTransportList();
			helper.setSessionParameter("outPutListTM", vIncotermsTransport);
		/*		   
			// Get the ToCountry list, it is showed in To Country drop down list
			Vector vToCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllToCountry();
			helper.setSessionParameter("outPutListTC", vToCountry);
		
			// Get the ProductOrigin list, it is showed in Zone of product origin drop down list
			Collection cProductOrigin = IIMexServlet.iimexUsersManager.getProducts().getAllProductOrigin();
			helper.setSessionParameter("outPutListPO", cProductOrigin);
		
			// Get the ProductGroup list, it is showed in the Product Group drop down list	   
			Vector vAllProductGroup = IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup();
			helper.setSessionParameter("outPutListPG", vAllProductGroup);
			
			// Get the Transport list, it is showed in the Transport Mode drop down list
			Vector vTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList();
			helper.setSessionParameter("outPutListM", vTransport);
			
			Collection vDivision = IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision();
			helper.setSessionParameter("outPutListDI", vDivision);
			
			// Get the IncotermsTransport list, it is showed in the Transport Mode - Incoterm drop down list
			Vector vIncotermsTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getIncotermTransportList();
			helper.setSessionParameter("outPutListTM", vIncotermsTransport);
		    */ if ( "1".equals(n_menu) ){
		    helper.redirect(helper.getContextPath()+"/inside/IIMEX_selectiontool.jsp");
	  }
		     else if("2".equals(n_menu)){
		     helper.redirect(helper.getContextPath()+"/servlet/IIMexReportsController");
		     }
		     else if("3".equals(n_menu)){
		    helper.redirect(helper.getContextPath()+"/servlet/IIMexLinksAndDocController");
		     }else {
		    helper.redirect(helper.getContextPath()+"/inside/IIMEX_maintenance_index.jsp");
		     }
		    	 
		
	 }catch (SecurityServiceException sse) {      // Some sort of database problem
	        Logger.log(new LoggableError("A error occured  " + "The error was: " + sse.toString()));
	        sse.printStackTrace();
	        IIMexMailHelper.send(sse,helper.getAuthenticatedUserFullName());
			helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");	
	  }
	  catch (Exception ex){
		  	Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));
		  	ex.printStackTrace();
		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());
	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");
  
  }   
}
}

