/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller;



import java.io.IOException;

import java.util.Collection;

import java.util.Vector;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;



/**

 * A session paramater will be passe for the link and documentation

 * Filename:    $RCSfile: IIMexLinksAndDocController.java,v $

 * Label:       $Name:  $

 * Last Change: $Author: mmcort3 $    	 On:	$Date: 2008/02/01 14:30:17 $

 * @version     $Revision: 1.1 $

 * @author      MMCORT3

*/

public class IIMexLinksAndDocController implements UseCaseController{

	/**

	 * Get a linkCollection with all the link and documentation information and pass it 

	 * like session parameters

	 * @param helper

	 * @throws IOException

	 */

	public void run (UCCHelper helper) throws IOException

	{

		try{

			Collection vAllLink;

			vAllLink =IIMexServlet.iimexUsersManager.getLinks().getAllLinks();

			 helper.setSessionParameter("linkVector",vAllLink);

			 helper.redirect(helper.getContextPath()+"/inside/linkDocumentation.jsp");

		}catch (IIMexException ex){

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}catch (Exception ex2){

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex2.toString()));

		  	ex2.printStackTrace();

		  	IIMexMailHelper.send(ex2,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

		

	}

}

