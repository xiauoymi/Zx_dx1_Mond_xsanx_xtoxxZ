package com.monsanto.enterprise.iimex.controller;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.tableloader.TableLoadDocumentRequirementsReport;
import com.monsanto.enterprise.iimex.tableloader.TableLoadShippingRestrictionReport;

import java.io.IOException;
import java.util.Collection;


/**
 *
 * <p>Title: IIMexReportsController</p>
 * <p>Description:Genere the list to display in the report jsp.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Monsanto</p>
 * @author Java Framework Code  Generator 2.3
 * @version
 */

/**
 * For each report a list is passed as session parameter. The list will be display with the displaytag decorator
 */
public class IIMexReportsController implements UseCaseController {

    /**
     * Runs the code that implements the general use case.
     *
     * @param helper a UCCHelper used to perform common UCC tasks
     * @throws IOException
     */
    public void run(UCCHelper helper) throws IOException {
        /*
         * Check the kind of report that the user has choose
         * The data values are stocked in the outPutListReportValue
         * The colum name are stocked in the outputListEntete
        */
        try {
            Collection listReport = null;

            String n_report = helper.getRequestParameterValue("num_report");
            String tableName = "";
            String jspPath = "";
            if (StringUtils.isNullOrEmpty(n_report)) {
                n_report = "0";
            }
            if (n_report.equalsIgnoreCase("0")) {
                helper.redirect(helper.getContextPath() + "/inside/Reports.jsp");
            } else {
                if ("1".equals(n_report)) {
                    tableName = "List of Active Countries";
                    listReport = IIMexServlet.iimexUsersManager.getCountryCollection().getAllCountry();
                    jspPath = "/inside/countryReport.jsp";
                } else if ("2".equals(n_report)) {
                    tableName = "List of Active Plants";
                    listReport = IIMexServlet.iimexUsersManager.getPlantsCollection().getAllPlants();
                    jspPath = "/inside/plantReport.jsp";
                } else if ("3".equals(n_report)) {
                    tableName = "List of Active Plants with Division";
                    listReport = IIMexServlet.iimexUsersManager.getPlantsCollection().getAllPlantsDivision();
                    jspPath = "/inside/plantProdGroupReport.jsp";
                } else if ("4".equals(n_report)) {
                    tableName = "List of Contacts";
                    listReport = IIMexServlet.iimexUsersManager.getContactCollection().getAllCntacts();
                    jspPath = "/inside/contactsReport.jsp";
                } else if ("5".equals(n_report)) {
                    tableName = "List of Documents";
                    listReport = IIMexServlet.iimexUsersManager.getDocuments().getAllDocuments();
                    jspPath = "/inside/documentReport.jsp";
                } else if ("6".equals(n_report)) {
                    tableName = "List of Product groups";
                    listReport = IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup();
                    jspPath = "/inside/productGroupReport.jsp";
                } else if ("7".equals(n_report)) {
                    tableName = "List of Shipping Restrictions";
                    TableLoadShippingRestrictionReport reportLoader = new TableLoadShippingRestrictionReport();
                    listReport = reportLoader.loadAllShippingRestrictionForReport();
                    jspPath = "/inside/shipRestrictReport.jsp";
                } else if ("8".equals(n_report)) {
                    tableName = "List of Document Requirements";
                    TableLoadDocumentRequirementsReport reportLoader = new TableLoadDocumentRequirementsReport();
                    listReport = reportLoader.loadDocumentRequirementsForReport();
                    jspPath = "/inside/docRequirementsReport.jsp";
                }
                helper.setSessionParameter("tableName", tableName);
                helper.setSessionParameter("allValue", listReport);
                helper.redirect(helper.getContextPath() + jspPath);
            }

        } catch (IIMexException ex) {
            Logger.log(new LoggableError("A error occurred " + "The error was: " + ex.toString()));
            ex.printStackTrace();
            IIMexMailHelper.send(ex, helper.getAuthenticatedUserFullName());
            helper.redirect(helper.getContextPath() + "/inside/ExceptionHandler.jsp");
        }


    }

}


