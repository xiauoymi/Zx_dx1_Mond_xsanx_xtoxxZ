/*

	Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller;



import java.io.IOException;

import java.util.ArrayList;

import java.util.Collection;

import java.util.HashMap;

import java.util.Iterator;

import java.util.List;

import java.util.Vector;



import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.Contacts;







public class IIMexVersionController  implements UseCaseController

{

  

  /**

   * Runs the code that implements the general use case.

   * @param helper a UCCHelper used to perform common UCC tasks

   * @throws IOException

   */

  public void run (UCCHelper helper) throws IOException

  {

	  /*

	   * Check the kind of report that the user has choose

	   * The data values are stocked in the outPutListReportValue

	   * The colum name are stocked in the outputListEntete

	  */

	  try {

		  ArrayList vEntete;  

	  vEntete =(ArrayList) IIMexServlet.iimexUsersManager.getVersionColumName();

		 // HashMap versionList = IIMexServlet.iimexUsersManager.getVersionList();

		 Collection versionList =  (Collection)IIMexServlet.iimexUsersManager.getVersionList().values();

			helper.setSessionParameter("versionHeader", vEntete);

		    helper.setSessionParameter("versionList", versionList);

			helper.redirect(helper.getContextPath()+"/inside/version.jsp");

		

			

	}catch (Exception ex) {

		Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

	  	ex.printStackTrace();

	  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

	}

     

	  

  }

  

}











