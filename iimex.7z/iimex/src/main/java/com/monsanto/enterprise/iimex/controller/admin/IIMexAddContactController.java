/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;

import java.util.Collection;

import java.util.List;

import java.util.Vector;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.Documents;



public class IIMexAddContactController implements UseCaseController{

//allow the user to add a new contact

	public void run(UCCHelper helper) throws IOException {

		  try {
			  String countryCode = helper.getRequestParameterValue("countryCode");
			  helper.setSessionParameter("countryName", IIMexServlet.iimexUsersManager.getCountryCollection().getCountryName(countryCode));
			  helper.setSessionParameter("countryCode", countryCode);	
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  if((action.compareTo("add")==0)){
					  	Contacts cont = new Contacts();
					  	cont.setContactName(helper.getRequestParameterValue("name"));
					  	cont.setContactPerson(helper.getRequestParameterValue("person"));
					  	cont.setContactType(helper.getRequestParameterValue("type"));
					  	cont.setStreet(helper.getRequestParameterValue("street"));
					  	cont.setCity(helper.getRequestParameterValue("city"));
					  	cont.setCountry(countryCode);
					  	cont.setTel(helper.getRequestParameterValue("tel"));
					  	cont.setFax(helper.getRequestParameterValue("fax"));
					  	cont.setMobile(helper.getRequestParameterValue("mobile"));
					  	cont.setMail(helper.getRequestParameterValue("mail"));
					  	cont.setContactComments(helper.getRequestParameterValue("comments"));
					  	String owner = helper.getAuthenticatedUserID();
						TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
						Locale loc = Locale.FRANCE;
						Calendar cal = Calendar.getInstance(tz,loc);
						Date date = cal.getTime();
					  	cont.setPublishOwner(owner);
					  	cont.setPublishDate(date);
					  	
					  	int addOk=IIMexServlet.iimexUsersManager.getContactCollection().addContact(cont);
					  	if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							helper.setSessionParameter("allValue", IIMexServlet.iimexUsersManager.getContactCollection().getAllCntacts());
							
						  }
					  	helper.redirect(helper.getContextPath()+"/admin/contactadmin.jsp");
					  }
			  }else{
				  helper.setSessionParameter("countryCode", countryCode);
				  helper.setSessionParameter("allType", IIMexServlet.iimexUsersManager.getContactTypeCollection().getAllTypes());
				  helper.redirect(helper.getContextPath()+"/admin/addContact.jsp");
			 }
		}  catch (IIMexException ex) {

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

	}


}



