/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Collection;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;



public class IIMexChooseShippingCountry implements UseCaseController{

//	Allow the user to choose for which country he wants to manage some shipping instruction

	public void run(UCCHelper helper) throws IOException {

		  try {

			  Collection  listCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry();
			  helper.setSessionParameter("allCountry", listCountry);
			   helper.redirect(helper.getContextPath()+"/admin/chooseShippingCountry.jsp");

		}  catch (IIMexException ex) {

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

	}


}



