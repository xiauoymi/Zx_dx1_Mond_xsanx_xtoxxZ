/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;

import java.util.Collection;

import java.util.List;

import java.util.Vector;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.ClearanceFee;
import com.monsanto.enterprise.iimex.elements.ClearanceTime;
import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.Documents;
import com.monsanto.enterprise.iimex.elements.IncotermTransportInfo;



public class IIMexClearanceTimeAdminController implements UseCaseController{

//manage the clearance times in a country

	public void run(UCCHelper helper) throws IOException {

		  try {
			  String countryCode = helper.getRequestParameterValue("countryCode");
			  HashMap  ClearanceTime = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode).getClearanceTime();
			  Vector allTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList();
			  allTransport.addAll(IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewTransportList());
			  
			  Iterator ite = allTransport.iterator();
			  Vector allTimes = new Vector();
			  while(ite.hasNext()){
				  IncotermTransportInfo inco = (IncotermTransportInfo)ite.next();
				  if(ClearanceTime.containsKey(inco.getTransportCode())){
					  ClearanceTime cf = (ClearanceTime)ClearanceTime.get(inco.getTransportCode());
					  cf.setTransportModeName(inco.getTransportName());
					  cf.setTransportModeCode(inco.getTransportCode());
					  allTimes.add(cf);
				  } else{
					  ClearanceTime cf = new ClearanceTime();
					cf.setTransportModeCode(inco.getTransportCode());
					cf.setTransportModeName(inco.getTransportName());
					allTimes.add(cf);
				  }
			  }
			  
			  
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("codeTp", helper.getRequestParameterValue("codeTp"));
					  helper.setSessionParameter("action", "");
				  }
				  //update the clearance time if it exists, save it otherwise
				  else if((action.compareTo("save")==0)){
					  String codeTp = helper.getRequestParameterValue("codeTp");
					  String importClearance = helper.getRequestParameterValue("importClearance");
					  String exportClearance = helper.getRequestParameterValue("exportClearance");
					  String owner = helper.getAuthenticatedUserID();
					  
					  ClearanceTime tmp = new ClearanceTime();
					  
					  tmp.setExportClearanceTime(exportClearance);
					  tmp.setImportClearanceTime(importClearance);
					  
					  tmp.setTransportModeCode(codeTp);
					  tmp.setPublishOwner(owner);
					  
					  int addOk=-1;
					  if(ClearanceTime.containsKey(codeTp))
						  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().updateClearanceTime(tmp, countryCode);
					  else
						  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().addClearanceTime(tmp, countryCode);
					  if(addOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
						  ClearanceTime = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode).getClearanceTime();
						  allTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList();
						  allTransport.addAll(IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewTransportList());
						  
						  ite = allTransport.iterator();
						  allTimes = new Vector();
						  while(ite.hasNext()){
							  IncotermTransportInfo inco = (IncotermTransportInfo)ite.next();
							  if(ClearanceTime.containsKey(inco.getTransportCode())){
								  ClearanceTime cf = (ClearanceTime)ClearanceTime.get(inco.getTransportCode());
								  cf.setTransportModeName(inco.getTransportName());
								  cf.setTransportModeCode(inco.getTransportCode());
								  allTimes.add(cf);
							  } else{
								  ClearanceTime cf = new ClearanceTime();
								cf.setTransportModeCode(inco.getTransportCode());
								cf.setTransportModeName(inco.getTransportName());
								allTimes.add(cf);
							  }
						  }
					}
					  helper.setSessionParameter("action", "");
					  helper.setSessionParameter("codeTp", "");
				  }
			  }
			  helper.setSessionParameter("name", IIMexServlet.iimexUsersManager.getCountryCollection().getCountryName(countryCode));
			  helper.setSessionParameter("countryCode", countryCode);
			  helper.setSessionParameter("allTimes", allTimes);
			  helper.redirect(helper.getContextPath()+"/admin/timeAdmin.jsp");

		}  catch (IIMexException ex) {

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

	}


}



