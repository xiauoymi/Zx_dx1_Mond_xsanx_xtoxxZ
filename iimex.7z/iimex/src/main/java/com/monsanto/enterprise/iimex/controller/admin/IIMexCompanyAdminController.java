

package com.monsanto.enterprise.iimex.controller.admin;


import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexConstants;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.CompanyDetermination;
import com.monsanto.enterprise.iimex.elements.Country;

import java.io.IOException;
import java.util.Vector;



public class IIMexCompanyAdminController implements UseCaseController{

//manage the companies in a country

	public void run(UCCHelper helper) throws IOException {

		  try {

			  String countryCode = helper.getRequestParameterValue("countryCode");
			  Country country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
			  Vector allCompanies = country.getCompanyDeterminationVector();
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  int addOk=-1;
				  					//delete an input  
				  if((action.compareTo("delete")==0)){
					  String division = helper.getRequestParameterValue("division");
					  String group = helper.getRequestParameterValue("group");
					  CompanyDetermination cd = new CompanyDetermination();
					  cd.setDivision(division);
					  cd.setGroup(group);
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().removeCompany(cd, countryCode);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
							allCompanies = country.getCompanyDeterminationVector();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("division","");
					  helper.setSessionParameter("group","");
				  }else if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("division",helper.getRequestParameterValue("division"));
					  helper.setSessionParameter("group",helper.getRequestParameterValue("group"));
					  helper.setSessionParameter("allDiv",IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision());
					  helper.setSessionParameter("allGroup",IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup());
					  helper.setSessionParameter("allComp",IIMexServlet.iimexUsersManager.getCompaniesCollection().getAllCompanyOrdered());
					  helper.setSessionParameter("action","edit");
					  //edit one
				  }else if((action.compareTo("register")==0)){
					  String division = helper.getRequestParameterValue("division");
					  String group = helper.getRequestParameterValue("group");
					  CompanyDetermination cd = new CompanyDetermination();
					  cd.setSoldToCompanyCode(helper.getRequestParameterValue("soldTo"));
					  cd.setSalesCompanyName(helper.getRequestParameterValue("sales"));
					  cd.setBillToCompanyCode(helper.getRequestParameterValue("billTo"));
					  cd.setShipToCompanyName(helper.getRequestParameterValue("shipTo"));
					  cd.setConsignToCompanyName(helper.getRequestParameterValue("consignTo"));
					  cd.setSellingCompanyCode(helper.getRequestParameterValue("selling"));
					  cd.setSalesOrganisation(helper.getRequestParameterValue("salesOrg"));
					  cd.setActive(helper.getRequestParameterValue("active"));
					  cd.setDivision(division);
					  cd.setGroup(group);
					  cd.setPublishOwner( helper.getAuthenticatedUserID());
					  
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().updateCompany(cd, countryCode);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
						allCompanies = country.getCompanyDeterminationVector();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("division","");
					  helper.setSessionParameter("group","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("division","");
					  helper.setSessionParameter("group","");
					  helper.setSessionParameter("allDiv",IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision());
					  helper.setSessionParameter("allGroup",IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup());
					  helper.setSessionParameter("allComp",IIMexServlet.iimexUsersManager.getCompaniesCollection().getAllCompany());
					  helper.setSessionParameter("action","new");
					  //save a new one
				  }else if((action.compareTo("save")==0)){
					  String division = helper.getRequestParameterValue("division");
					  String group = helper.getRequestParameterValue("group");
					  CompanyDetermination cd = new CompanyDetermination();
					  cd.setSoldToCompanyCode(helper.getRequestParameterValue("soldTo"));
					  cd.setSalesCompanyName(helper.getRequestParameterValue("sales"));
					  cd.setBillToCompanyCode(helper.getRequestParameterValue("billTo"));
					  cd.setShipToCompanyName(helper.getRequestParameterValue("shipTo"));
					  cd.setConsignToCompanyName(helper.getRequestParameterValue("consignTo"));
					  cd.setSellingCompanyCode(helper.getRequestParameterValue("selling"));
            String salesOrg = helper.getRequestParameterValue("salesOrg");
            if (IIMexConstants.NO_DATA.equalsIgnoreCase(salesOrg)){
              salesOrg = "";
            }
            cd.setSalesOrganisation(salesOrg);
					  cd.setActive(helper.getRequestParameterValue("active"));
					  cd.setDivision(division);
					  cd.setGroup(group);
					  cd.setPublishOwner( helper.getAuthenticatedUserID());
					  
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().addCompany(cd, countryCode);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
						allCompanies = country.getCompanyDeterminationVector();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("division","");
					  helper.setSessionParameter("group","");
				  }
				  
			  }
			  helper.setSessionParameter("countryCode", countryCode);
			  helper.setSessionParameter("allCompanies", allCompanies);
			  helper.redirect(helper.getContextPath()+"/admin/companyAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  