/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import java.util.ArrayList;
import java.util.Iterator;

import java.util.Collection;

import java.util.List;

import java.util.Vector;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.Documents;



public class IIMexContactAdminController implements UseCaseController{

//draw the contact list in a country. the user can delete one from this page

	public void run(UCCHelper helper) throws IOException {

		  try {
			  String countryCode = helper.getRequestParameterValue("countryCode");
			  Collection  listReport = IIMexServlet.iimexUsersManager.getContactCollection().getAllContactsByCountry(countryCode);
			  
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  if((action.compareTo("remove")==0)){
					  int  contactCode = Integer.parseInt(helper.getRequestParameterValue("contactCode"));
					  int removeOk=-1;
					  removeOk=IIMexServlet.iimexUsersManager.getContactCollection().removeContact(contactCode);
					  if(removeOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
						  listReport = IIMexServlet.iimexUsersManager.getContactCollection().getAllContactsByCountry(countryCode);
					  }
				  }
			 }
			
			  Collection listCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllCountry();
			  helper.setSessionParameter("action", "");
			  helper.setSessionParameter("allValue", listReport);
			  helper.setSessionParameter("countryCode", countryCode);
			  	
			   helper.redirect(helper.getContextPath()+"/admin/contactadmin.jsp");

		}  catch (IIMexException ex) {

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

	}


}



