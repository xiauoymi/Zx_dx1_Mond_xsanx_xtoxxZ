/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;

import java.util.Collection;

import java.util.List;

import java.util.Vector;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.Documents;



public class IIMexCountryAdminController implements UseCaseController{

//manage countries

	public void run(UCCHelper helper) throws IOException {

		  try {

			  Collection  listCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllCountry();
			  helper.setSessionParameter("allCountry", listCountry);
			  helper.setSessionParameter("countryCode", helper.getRequestParameterValue("countryCode"));
			  String msg="";
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  if((action.compareTo("add")==0)){
					  helper.setSessionParameter("action", action);
					  helper.setSessionParameter("allCustoms", IIMexServlet.iimexUsersManager.getCustomZonesCollection().getAllCZones());
					  helper.setSessionParameter("allArea", IIMexServlet.iimexUsersManager.getWorldAreaCollection().getAllAreas());
				  }
				  //add a new one
				  else if((action.compareTo("save")==0)){
					  String  countryCode = helper.getRequestParameterValue("code");
					  String  countryName = helper.getRequestParameterValue("name");
					  String  active = helper.getRequestParameterValue("active");
					  String  customZoneCode = helper.getRequestParameterValue("customZoneCode");
					  String  worldAreaCode = helper.getRequestParameterValue("worldAreaCode");
					  
					  Country coun = new Country();
					  coun.setCountryCode(countryCode);
					  coun.setActive((active.compareTo("true")==0));
					  coun.setCustomsZoneCode(customZoneCode);
					  coun.setCountryName(countryName);
					  coun.setWorldAreaCode(worldAreaCode);
					  
					  String owner = helper.getAuthenticatedUserID();
					  TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
					  Locale loc = Locale.FRANCE;
					  Calendar cal = Calendar.getInstance(tz,loc);
					  Date date = cal.getTime();
					  coun.setPublishOwner(owner);
					  coun.setPublishDate(date);
					  int addOk=-1;
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().addCountry(coun);
					  if(addOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
					      listCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllCountry();
					      helper.setSessionParameter("allCountry", listCountry);
					}
					  helper.setSessionParameter("action", "");
				  }
				  else if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("countryCode", helper.getRequestParameterValue("countryCode"));
					  helper.setSessionParameter("allCustoms", IIMexServlet.iimexUsersManager.getCustomZonesCollection().getAllCZones());
					  helper.setSessionParameter("allArea", IIMexServlet.iimexUsersManager.getWorldAreaCollection().getAllAreas());
				  }
				  //update one
				  else if((action.compareTo("register")==0)){
					  String  countryCode = helper.getRequestParameterValue("countryCode");
					  String  active = helper.getRequestParameterValue("active");
					  String  customZoneCode = helper.getRequestParameterValue("customZoneCode");
					  String  worldAreaCode = helper.getRequestParameterValue("worldAreaCode");
					  
					  Country coun = new Country();
					  coun.setWorldAreaCode(worldAreaCode);
					  coun.setCountryCode(countryCode);
					  coun.setActive((active.compareTo("true")==0));
					  coun.setCustomsZoneCode(customZoneCode);
					  
					  String owner = helper.getAuthenticatedUserID();
					  TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
					  Locale loc = Locale.FRANCE;
					  Calendar cal = Calendar.getInstance(tz,loc);
					  Date date = cal.getTime();
					  coun.setPublishOwner(owner);
					  coun.setPublishDate(date);
					  
					  int addOk=-1;
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().updateCountry(coun);
					  if(addOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
					      listCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllCountry();
					      helper.setSessionParameter("allCountry", listCountry);
					}
					  helper.setSessionParameter("action", "");
					  helper.setSessionParameter("countryCode","");
				  }//delete one
				  else if((action.compareTo("delete")==0)){
					  String  countryCode = helper.getRequestParameterValue("countryCode");
					  int addOk=-1;
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().removeCountry(countryCode);
					  if(addOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
					      listCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllCountry();
					      helper.setSessionParameter("allCountry", listCountry);
					}
					  helper.setSessionParameter("action", "");
					  helper.setSessionParameter("countryCode","");
				  }
			  }
			  helper.redirect(helper.getContextPath()+"/admin/countryAdmin.jsp");

		}  catch (IIMexException ex) {

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

	}


}



