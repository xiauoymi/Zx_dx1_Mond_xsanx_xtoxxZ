

package com.monsanto.enterprise.iimex.controller.admin;



import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.PricingCurrency;

import java.io.IOException;
import java.util.Vector;



public class IIMexCurrencyAdminController implements UseCaseController{

//manage the currencies for a country

	public void run(UCCHelper helper) throws IOException {

		  try {

			  String dest = helper.getRequestParameterValue("countryCode");
			  PricingCurrency mainCur = IIMexServlet.iimexUsersManager.getCurrencyCollection().getPricingCurrency("*", dest);
			  Vector allCur = IIMexServlet.iimexUsersManager.getCurrencyCollection().getAllToCurrency(dest);
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  int addOk=-1;
				  //delete an exception
				  if((action.compareTo("delete")==0)){
					  String ship = helper.getRequestParameterValue("ship");
					  PricingCurrency pc = new PricingCurrency();
					  pc.setSFromCountry(ship);
					  pc.setSToCountry(dest);
					  addOk=IIMexServlet.iimexUsersManager.getCurrencyCollection().removeCurrencyException(pc);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							mainCur = IIMexServlet.iimexUsersManager.getCurrencyCollection().getPricingCurrency("*", dest);
							allCur = IIMexServlet.iimexUsersManager.getCurrencyCollection().getAllCurrency(dest);
					  }
					  helper.setSessionParameter("ship","");
					  helper.setSessionParameter("action","");
				  }else if((action.compareTo("editMain")==0)){
					 helper.setSessionParameter("action","editMain");
					 //save or update the currency of the country depending of its existence
				  }else if((action.compareTo("registerMain")==0)){
					  String interco = helper.getRequestParameterValue("interco");
					  String sales = helper.getRequestParameterValue("sales");
					  PricingCurrency pc = new PricingCurrency();
					  
					  pc.setSIntercoCurrency(interco);
					  pc.setSSalesCurrency(sales);
					  pc.setSToCountry(dest);
					  String owner = helper.getAuthenticatedUserID();
					  if(mainCur.getIntercoCurrency().compareTo("contact trade and compliance")!=0 || mainCur.getSalesCurrency().compareTo("contact trade and compliance")!=0)
						  addOk = IIMexServlet.iimexUsersManager.getCurrencyCollection().updateCurrency(pc,owner);
					  else addOk = IIMexServlet.iimexUsersManager.getCurrencyCollection().addCurrency(pc,owner);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						mainCur = IIMexServlet.iimexUsersManager.getCurrencyCollection().getPricingCurrency("*", dest);
						allCur = IIMexServlet.iimexUsersManager.getCurrencyCollection().getAllCurrency(dest);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("ship","");
				  }else if((action.compareTo("edit")==0)){
					 helper.setSessionParameter("action","edit");
					 helper.setSessionParameter("ship",helper.getRequestParameterValue("ship"));
					 //save modifications on an exception
				  }else if((action.compareTo("register")==0)){
					  String interco = helper.getRequestParameterValue("interco");
					  String sales = helper.getRequestParameterValue("sales");
					  String ship = helper.getRequestParameterValue("ship");
					  PricingCurrency pc = new PricingCurrency();
					  
					  pc.setSIntercoCurrency(interco);
					  pc.setSSalesCurrency(sales);
					  pc.setSFromCountry(ship);
					  pc.setSToCountry(dest);
					  String owner = helper.getAuthenticatedUserID();
					  
					  addOk = IIMexServlet.iimexUsersManager.getCurrencyCollection().updateCurrencyException(pc, owner);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						mainCur = IIMexServlet.iimexUsersManager.getCurrencyCollection().getPricingCurrency("*", dest);
						allCur = IIMexServlet.iimexUsersManager.getCurrencyCollection().getAllCurrency(dest);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("ship","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("ship","");
					  helper.setSessionParameter("action","new");
					  helper.setSessionParameter("allCountry", IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry());
					  //add an exception
				  }else if((action.compareTo("save")==0)){
					  String interco = helper.getRequestParameterValue("interco");
					  String sales = helper.getRequestParameterValue("sales");
					  String ship = helper.getRequestParameterValue("ship");
					  PricingCurrency pc = new PricingCurrency();
					  
					  pc.setSIntercoCurrency(interco);
					  pc.setSSalesCurrency(sales);
					  pc.setSFromCountry(ship);
					  pc.setSToCountry(dest);
					  String owner = helper.getAuthenticatedUserID();
					  
					  
					  addOk = IIMexServlet.iimexUsersManager.getCurrencyCollection().addCurrencyException(pc, owner);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						mainCur = IIMexServlet.iimexUsersManager.getCurrencyCollection().getPricingCurrency("*", dest);
						allCur = IIMexServlet.iimexUsersManager.getCurrencyCollection().getAllCurrency(dest);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("ship","");
				  }
				  
			  }
			  
			  helper.setSessionParameter("allCur", allCur);
			  helper.setSessionParameter("mainCur", mainCur);
			  helper.setSessionParameter("countryCode", dest);
			  helper.redirect(helper.getContextPath()+"/admin/currencyAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  