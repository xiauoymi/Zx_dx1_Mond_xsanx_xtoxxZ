/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;

import java.util.Collection;

import java.util.List;

import java.util.Vector;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.ClearanceFee;
import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.Documents;
import com.monsanto.enterprise.iimex.elements.IncotermTransportInfo;



public class IIMexCustomClearanceAdminController implements UseCaseController{

//manage the custom clearance fees of a specific country

	public void run(UCCHelper helper) throws IOException {

		  try {
			  String code = helper.getRequestParameterValue("code");
			  HashMap  fees = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(code).getClearanceFee();
			  Vector allTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList();
			  allTransport.addAll(IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewTransportList());
			  
			  Iterator ite = allTransport.iterator();
			  Vector allFees = new Vector();
			  while(ite.hasNext()){
				  IncotermTransportInfo inco = (IncotermTransportInfo)ite.next();
				  if(fees.containsKey(inco.getTransportCode())){
					  ClearanceFee cf = (ClearanceFee)fees.get(inco.getTransportCode());
					  cf.setTransportModeName(inco.getTransportName());
					  cf.setTransportModeCode(inco.getTransportCode());
					  allFees.add(cf);
				  } else{
					ClearanceFee cf = new ClearanceFee();
					cf.setTransportModeCode(inco.getTransportCode());
					cf.setTransportModeName(inco.getTransportName());
					 allFees.add(cf);
				  }
			  }
			  
			  
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("codeTp", helper.getRequestParameterValue("codeTp"));
					  helper.setSessionParameter("action", "");
				  }
				  //update the fee if it already exists, save a new one otherwise
				  else if((action.compareTo("save")==0)){
					  String codeTp = helper.getRequestParameterValue("codeTp");
					  String importClearance = helper.getRequestParameterValue("importClearance");
					  String exportClearance = helper.getRequestParameterValue("exportClearance");
					  String owner = helper.getAuthenticatedUserID();
					  
					  ClearanceFee tmp = new ClearanceFee();
					  
					  tmp.setTransportModeCode(codeTp);
					  tmp.setImportClearanceFee(importClearance);
					  tmp.setExportClearanceFee(exportClearance);
					  tmp.setPublishOwner(owner);
					  
					  int addOk=-1;
					  if(fees.containsKey(codeTp))
						  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().updateClearanceFee(tmp, code);
					  else
						  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().addClearanceFee(tmp, code);
					  if(addOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
						  fees = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(code).getClearanceFee();
						  allTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList();
						  ite = allTransport.iterator();
						  allFees = new Vector();
						  while(ite.hasNext()){
							  IncotermTransportInfo inco = (IncotermTransportInfo)ite.next();
							  if(fees.containsKey(inco.getTransportCode())){
								  ClearanceFee cf = (ClearanceFee)fees.get(inco.getTransportCode());
								  cf.setTransportModeName(inco.getTransportName());
								  cf.setTransportModeCode(inco.getTransportCode());
								  allFees.add(cf);
							  }
							  else{
								ClearanceFee cf = new ClearanceFee();
								cf.setTransportModeCode(inco.getTransportCode());
								cf.setTransportModeName(inco.getTransportName());
								allFees.add(cf);
							  }
						  }
					}
					  helper.setSessionParameter("action", "");
					  helper.setSessionParameter("codeTp", "");
				  }
			  }
			  helper.setSessionParameter("name", helper.getRequestParameterValue("name"));
			  helper.setSessionParameter("code", code);
			  helper.setSessionParameter("allFees", allFees);
			  helper.redirect(helper.getContextPath()+"/admin/customClearanceAdmin.jsp");

		}  catch (IIMexException ex) {

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

	}


}



