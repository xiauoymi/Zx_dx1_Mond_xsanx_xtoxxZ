

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.collections.WorldAreaCollection;
import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;
import com.monsanto.enterprise.iimex.elements.WorldArea;
import com.monsanto.enterprise.iimex.elements.customZone;



public class IIMexCustomZoneAdminController implements UseCaseController{

//manage the custom zone

	public void run(UCCHelper helper) throws IOException {

		  try {

			  Collection listCustomZones = IIMexServlet.iimexUsersManager.getCustomZonesCollection().getAllCZones();
			  WorldAreaCollection areaCollection = IIMexServlet.iimexUsersManager.getWorldAreaCollection();
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  String code = helper.getRequestParameterValue("code");
				  int addOk=-1;		
				  //delete one
				  if((action.compareTo("delete")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getCustomZonesCollection().removeCustomZone(code);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							listCustomZones = IIMexServlet.iimexUsersManager.getCustomZonesCollection().getAllCZones();
					  }
					  helper.setSessionParameter("code","");
					  helper.setSessionParameter("action","");
				  }else if((action.compareTo("edit")==0)){
					 helper.setSessionParameter("code",code);
					 helper.setSessionParameter("action","edit");
					 helper.setSessionParameter("allArea",areaCollection.getAllAreas());
					 //add a new one
				  }else if((action.compareTo("register")==0)){
					  code = helper.getRequestParameterValue("code");
					  String name = helper.getRequestParameterValue("name");
					  String owner = helper.getAuthenticatedUserID();
					  String areaCode = helper.getRequestParameterValue("areaCode"); 
					  
					  customZone cz = new customZone();
					  cz.setCustomZoneCode(code);
					  cz.setCustomZoneName(name);
					  cz.setAreaCode(areaCode);
					  cz.setPublisOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getCustomZonesCollection().addCustomZone(cz);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						listCustomZones = IIMexServlet.iimexUsersManager.getCustomZonesCollection().getAllCZones();
						areaCollection = IIMexServlet.iimexUsersManager.getWorldAreaCollection();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("code","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("code","");
					  helper.setSessionParameter("action","new");
					  helper.setSessionParameter("allArea",areaCollection.getAllAreas());
					  //update one
				  }else if((action.compareTo("save")==0)){
					  code = helper.getRequestParameterValue("code");
					  String name = helper.getRequestParameterValue("name");
					  String owner = helper.getAuthenticatedUserID();
					  String areaCode = helper.getRequestParameterValue("areaCode"); 
					  
					  customZone cz = new customZone();
					  cz.setCustomZoneCode(code);	
					  cz.setCustomZoneName(name);
					  cz.setAreaCode(areaCode);
					  cz.setPublisOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getCustomZonesCollection().updateCustomZone(cz);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						listCustomZones = IIMexServlet.iimexUsersManager.getCustomZonesCollection().getAllCZones();
						areaCollection = IIMexServlet.iimexUsersManager.getWorldAreaCollection();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("code","");
				  }
				  
			  }
			  
			  helper.setSessionParameter("allZones", listCustomZones);
			  helper.setSessionParameter("areaCollection", areaCollection);
			  helper.redirect(helper.getContextPath()+"/admin/customZoneAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  
