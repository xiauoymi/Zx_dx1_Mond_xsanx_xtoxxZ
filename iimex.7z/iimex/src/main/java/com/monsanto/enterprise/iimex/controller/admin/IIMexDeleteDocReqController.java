package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;



public class IIMexDeleteDocReqController implements UseCaseController {

	

	public void run(UCCHelper helper) throws IOException {

	

		String docId=helper.getRequestParameterValue("docId");

		String docCondId=helper.getRequestParameterValue("docCondId");

		String msg="";

		int rowDelete=0;

		

		try{

			

			rowDelete=IIMexServlet.iimexUsersManager.getDocuments().deleteDocumentCondition(docCondId);

			if(rowDelete>0){

				IIMexServlet.iimexUsersManager.updateDBstatus();

				

				msg="The document requirement is deleted from the document and requirement list";

			}else{

				msg="An error occured when delete the document ";

			}

		}catch(IIMexException e){

			Logger.log(new LoggableError("An error occured when delete the document condition " + e.toString()));

	        e.printStackTrace();

	        IIMexMailHelper.send(e,helper.getAuthenticatedUserFullName());

			helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

		

		helper.setSessionParameter("msg",msg);

		helper.redirect(helper.getContextPath()+"/inside/IIMEX_maintenance_index.jsp");

	}

}

