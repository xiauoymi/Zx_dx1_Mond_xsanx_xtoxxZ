/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;



public class IIMexDeleteLinkController implements UseCaseController{



	public void run(UCCHelper helper) throws IOException {



		  String linkId= helper.getRequestParameterValue("linkId").toString();

		  String msg="";

		  boolean updateOk = false;

		  String linkName="";

		  try {

			  linkName=IIMexServlet.iimexUsersManager.getLinks().getLinkAndDocument(linkId).getLinkName();

			updateOk = IIMexServlet.iimexUsersManager.getLinks().setInactiveLink(linkId);

			if (updateOk){

				msg="Link "+linkName+" has been deleted";

				IIMexServlet.iimexUsersManager.updateDBstatus();

				

			}else{

				msg="Link "+linkName+" has not been deleted please try again or contact the support";

			}

		} catch (IIMexException e) {

			Logger.log(new LoggableError("A error occured  delete link " + e.toString()));

	        e.printStackTrace();

	        IIMexMailHelper.send(e,helper.getAuthenticatedUserFullName());

			helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

		

		helper.setSessionParameter("msg", msg);

		helper.redirect(helper.getContextPath()+"/inside/IIMEX_maintenance_index.jsp");

	}

		



}

