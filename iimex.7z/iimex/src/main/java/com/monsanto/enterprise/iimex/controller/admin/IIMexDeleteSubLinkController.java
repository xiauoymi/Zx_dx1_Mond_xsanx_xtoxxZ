/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.LinkAndDocument;



public class IIMexDeleteSubLinkController implements UseCaseController{



	public void run(UCCHelper helper) throws IOException {

		// TODO Auto-generated method stub

		String linkId=helper.getRequestParameterValue("linkId");

		String urlId="0";

		String docId="0";

		boolean deleteOk=false;

		String msg="";

		if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("urlId"))){

			urlId=helper.getRequestParameterValue("urlId");

		}

		if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("docId"))){

			docId=helper.getRequestParameterValue("docId");

		}

		try{		

		if(!urlId.equalsIgnoreCase("0") || !docId.equalsIgnoreCase("0")){

			String urlName;
			
			if(!urlId.equalsIgnoreCase("0")){
			
				urlName = IIMexServlet.iimexUsersManager.getLinks().getLinkAndDocument(linkId).getUrl(urlId).getUrl();
				deleteOk=IIMexServlet.iimexUsersManager.getLinks().deleteUrl(linkId,urlId);

			}else{
				urlName = IIMexServlet.iimexUsersManager.getLinks().getLinkAndDocument(linkId).getDocLink(docId).getDocName();
				deleteOk=IIMexServlet.iimexUsersManager.getLinks().removeDoc(linkId, docId);
			}
			
			

			if(deleteOk){

				msg="The url "+urlName +" has been removed";

				IIMexServlet.iimexUsersManager.updateDBstatus();

			}else{

			  msg=" The url " +urlName+" has not been removed please try again or contact the support";

			}

		}

		}catch (IIMexException e) {

			Logger.log(new LoggableError("A error occured  " + "The error was: " + e.toString()));

	        e.printStackTrace();

	        IIMexMailHelper.send(e,helper.getAuthenticatedUserFullName());

			helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");	

		}

		helper.setSessionParameter("msg", msg);

		helper.redirect(helper.getContextPath()+"/inside/IIMEX_maintenance_index.jsp");

	}



}

