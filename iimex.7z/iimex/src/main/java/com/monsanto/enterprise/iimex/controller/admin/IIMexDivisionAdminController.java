

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;



public class IIMexDivisionAdminController implements UseCaseController{

//interface to mange the divisions

	public void run(UCCHelper helper) throws IOException {

		  try {

			  Collection ListDivision = IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision();
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  String codeDivision = helper.getRequestParameterValue("codeDivision");
				  int addOk=-1;
				  //delete an existing one
				  if((action.compareTo("delete")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getDivisionCollection().removeDivision(codeDivision);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							ListDivision = IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision();
					  }
					  helper.setSessionParameter("codeDivision","");
					  helper.setSessionParameter("action","");
				  }else if((action.compareTo("edit")==0)){
					 helper.setSessionParameter("codeDivision",codeDivision);
					 helper.setSessionParameter("action","edit");
					 //save a new one
				  }else if((action.compareTo("register")==0)){
					  String code = helper.getRequestParameterValue("codeDivision");
					  String name = helper.getRequestParameterValue("divisionName");
					  String owner = helper.getAuthenticatedUserID();
					  
					  Division div = new Division();
					  div.setDivisionCode(code);
					  div.setDivisionName(name);
					  div.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getDivisionCollection().addDivision(div);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						ListDivision = IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("codeDivision","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("codeDivision","");
					  helper.setSessionParameter("action","new");
					  //update one
				  }else if((action.compareTo("save")==0)){
					  String code = helper.getRequestParameterValue("codeDivision");
					  String name = helper.getRequestParameterValue("divisionName");
					  String owner = helper.getAuthenticatedUserID();
					  
					  Division div = new Division();
					  div.setDivisionCode(code);
					  div.setDivisionName(name);
					  div.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getDivisionCollection().updateDivision(div);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						ListDivision = IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("codeDivision","");
				  }
				  
			  }
			  
			  helper.setSessionParameter("allDivision", ListDivision);
			  helper.redirect(helper.getContextPath()+"/admin/divisionAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  