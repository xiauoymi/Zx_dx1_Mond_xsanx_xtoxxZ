package com.monsanto.enterprise.iimex.controller.admin;


import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.DocumentConditions;

import java.io.IOException;
import java.util.Date;
import java.util.Vector;



public class IIMexDocRequirementAdminController implements UseCaseController {

//interface where the user can add a edit requirements for a specific document

	public void run(UCCHelper helper) throws IOException {
		try{
			String countryCode = helper.getRequestParameterValue("countryCode");
			Country country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
			String countryName = country.getCountryName();
			
			Vector allDoc = IIMexServlet.iimexUsersManager.getDocuments().getDocumentByDestination(country);

			boolean isNew = false;
            boolean isEdit = false;
			
			if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
			
				String action = helper.getRequestParameterValue("action");
				String docCondId = helper.getRequestParameterValue("docCondId");
				
				if((action.compareTo("delete")==0)){
					 int deleteOk=IIMexServlet.iimexUsersManager.getDocuments().deleteDocumentCondition(docCondId);
					 if(deleteOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allDoc = IIMexServlet.iimexUsersManager.getDocuments().getDocumentByDestination(country);
					  }
					  helper.setSessionParameter("docCondId","");
					  helper.setSessionParameter("action","");
				}else if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("docCondId",docCondId);
					  helper.setSessionParameter("action","edit");
                      setCollectionsInSession(helper);
                      helper.setSessionParameter("countryCode", countryCode);
                      helper.setSessionParameter("name", countryName);
                      DocumentConditions docCond = IIMexServlet.iimexUsersManager.getDocuments().getDocumentConditionsById(docCondId);
                      setDocumentConditionsParams(helper, docCond);
                      isEdit = true;
				}/*else if((action.compareTo("register")==0)){
						  String name = helper.getRequestParameterValue("divisionName");
						  String owner = helper.getAuthenticatedUserID();
						  
						  Division div = new Division();
						  div.setDivisionCode(code);
						  div.setDivisionName(name);
						  div.setPublishOwner(owner);
						  
						  addOk=IIMexServlet.iimexUsersManager.getDivisionCollection().addDivision(div);
						  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							ListDivision = IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision();
						  }
						  helper.setSessionParameter("action","");
						  helper.setSessionParameter("codeDivision","");
				}*/else if((action.compareTo("new")==0)){
                      helper.setSessionParameter("docCondId","");
                      helper.setSessionParameter("action","new");
                      setCollectionsInSession(helper);
                      helper.setSessionParameter("countryCode", countryCode);
                      helper.setSessionParameter("name", countryName);
                      isNew = true;
				}else if((action.compareTo("save")==0)){
                    DocumentConditions docCond = buildConditions(helper, countryCode, country);
					boolean newDocCond=IIMexServlet.iimexUsersManager.getDocuments().checkDocumentCondition(docCond);
					if(newDocCond){
						int addOk=IIMexServlet.iimexUsersManager.getDocuments().addDocCondition(docCond);
						if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							allDoc = IIMexServlet.iimexUsersManager.getDocuments().getDocumentByDestination(country);
						}
						helper.setSessionParameter("docCondId","");
						helper.setSessionParameter("action","");
					}
				} else if (action.compareTo("update")==0) {
                    DocumentConditions docCond = buildConditions(helper, countryCode, country);
                    docCondId = (String)helper.getSessionParameter("docCondId");
                    docCond.setDocConditionCode(Integer.parseInt(docCondId));
                    int updateOk=IIMexServlet.iimexUsersManager.getDocuments().updateDocCondition(docCond);

                    if(updateOk>0){
                        IIMexServlet.iimexUsersManager.updateDBstatus();
                        allDoc = IIMexServlet.iimexUsersManager.getDocuments().getDocumentByDestination(country);
                    }
                    helper.setSessionParameter("docCondId","");
                    helper.setSessionParameter("action","");
                }
			}
			helper.setSessionParameter("countryCode", countryCode);
            helper.setSessionParameter("name", countryName);
            helper.setSessionParameter("allDoc", allDoc);
            if(isNew) {
                helper.redirect(helper.getContextPath()+"/admin/newDocumentRequirement.jsp");
            } else if (isEdit) {
                helper.redirect(helper.getContextPath()+"/admin/updateDocumentRequirement.jsp");
            } else {
                helper.redirect(helper.getContextPath()+"/admin/documentSpecimentAdmin.jsp");
            }

		}  catch (IIMexException ex) {
			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));
		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");
		}
	}

    protected void setDocumentConditionsParams(UCCHelper helper, DocumentConditions docCond) {
        helper.setSessionParameter("document", docCond.getDocName());
        helper.setSessionParameter("specialReq", docCond.getSpecialReq());
        helper.setSessionParameter("buyerSeller", docCond.getBuyerSeller());
        helper.setSessionParameter("comment", docCond.getComments());
        helper.setSessionParameter("whenSent", docCond.getWhenSent());
        helper.setSessionParameter("whereSent", docCond.getWhereSent());
        helper.setSessionParameter("shippingMethod", docCond.getShippingMethod());
        helper.setSessionParameter("fromCountry", docCond.getFromcountry());
        helper.setSessionParameter("fromCustomZone", docCond.getFromcustomsZone());
        helper.setSessionParameter("countryOrigin", docCond.getOriginCountry());
        helper.setSessionParameter("zoneOrigin", docCond.getZoneOrigin());
        helper.setSessionParameter("transportMode", docCond.getTranspMode());
        helper.setSessionParameter("incoterm", docCond.getIncoterms());
        helper.setSessionParameter("division", docCond.getDivision());
        helper.setSessionParameter("prodGroup", docCond.getProductGroup());
        helper.setSessionParameter("trait", docCond.getTrait());
    }

    private void setCollectionsInSession(UCCHelper helper) throws IIMexException {
        helper.setSessionParameter("allCountry", IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry());
        helper.setSessionParameter("allCustom",IIMexServlet.iimexUsersManager.getCustomZonesCollection().getAllCZones());
        helper.setSessionParameter("allDiv",IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision());
        helper.setSessionParameter("allProd",IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup());
        helper.setSessionParameter("allTrait",IIMexServlet.iimexUsersManager.getTraitCollection().getAllTrait());
        helper.setSessionParameter("allInco",IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getAllDifferentIncoterm());
        helper.setSessionParameter("allTransp",IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList());
        helper.setSessionParameter("allDocuments",IIMexServlet.iimexUsersManager.getDocuments().getAllDocuments());
    }

    protected DocumentConditions buildConditions(UCCHelper helper, String countryCode, Country country) throws IOException, IIMexException {
        String document=helper.getRequestParameterValue("document");
        String specialReq=helper.getRequestParameterValue("specialReq");
        String buyerSeller = helper.getRequestParameterValue("buyerSeller");
        String comments = helper.getRequestParameterValue("comment");
        String whenSent= helper.getRequestParameterValue("whenSent");
        String whereSent= helper.getRequestParameterValue("whereSent");
        String shippingMethod= helper.getRequestParameterValue("shippingMethod");
        String fromCountry=helper.getRequestParameterValue("fromCountry");
        String fromCustomZone=helper.getRequestParameterValue("fromCustomZone");
        String countryOrigin=helper.getRequestParameterValue("countryOrigin");
        String zoneOrigin=helper.getRequestParameterValue("zoneOrigin");
        String transportMode= helper.getRequestParameterValue("transportMode");
        String incoterm= helper.getRequestParameterValue("incoterm");
        String division=helper.getRequestParameterValue("division");
        String prodGroup=helper.getRequestParameterValue("prodGroup");
        String trait=helper.getRequestParameterValue("trait");
        String owner = helper.getAuthenticatedUserID();

        DocumentConditions docCond= new DocumentConditions();

        docCond.setDocumentCode(document);
        docCond.setSpecialReq(specialReq);
        docCond.setBuyerSeller(buyerSeller);
        docCond.setComments(comments);
        docCond.setWhenSent(whenSent);
        docCond.setWhereSent(whereSent);
        docCond.setShippingMethod(shippingMethod);
        docCond.setFromcountry(fromCountry);
        docCond.setFromcustomsZone(fromCustomZone);
        docCond.setToCountry(countryCode);
        docCond.setToCustZone(country.getCustomsZoneCode());
        docCond.setOriginCountry(countryOrigin);
        docCond.setZoneOrigin(zoneOrigin);
        docCond.setIncoterms(incoterm);
        docCond.setTranspMode(transportMode);
        docCond.setDivision(division);
        docCond.setProductGroup(prodGroup);
        docCond.setTrait(trait);
        docCond.setPublishDate(new Date());
        docCond.setPublishOwner(owner);
        return docCond;
    }


}