/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import java.util.ArrayList;

import java.util.Collection;

import java.util.List;

import java.util.Vector;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.Documents;



public class IIMexDocSpecimenAdminController implements UseCaseController{

//the user choose the document he wants to manage and the controller send him to the good page

	public void run(UCCHelper helper) throws IOException {

		  try {

		

			 Collection<Documents> listReport;

				listReport = IIMexServlet.iimexUsersManager.getDocuments().getAllDocuments();

				 helper.setSessionParameter("allValue", listReport);

				helper.redirect(helper.getContextPath()+"/admin/documentSpeciment.jsp");

		}  catch (IIMexException ex) {

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

	}



}

