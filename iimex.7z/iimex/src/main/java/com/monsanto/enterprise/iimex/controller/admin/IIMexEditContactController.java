/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;


import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.CountryFrom;



public class IIMexEditContactController implements UseCaseController{

//edit an existing contac

	public void run(UCCHelper helper) throws IOException {

		  try {			  
			  String contactCode = helper.getRequestParameterValue("code");
			  Contacts cont = IIMexServlet.iimexUsersManager.getContactCollection().getContactByCode(contactCode);
              helper.setSessionParameter("contact",cont);
			  helper.setSessionParameter("allCountry",IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry());
			  helper.setSessionParameter("size",cont.getCountriesVector().size());
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("size",cont.getCountriesVector().size());
                      helper.setSessionParameter("allCountries",cont.getCountriesVector());
					  helper.setSessionParameter("allType", IIMexServlet.iimexUsersManager.getContactTypeCollection().getAllTypes());
					  helper.setSessionParameter("action","edit");
				  }
				  else if((action.compareTo("save")==0)){
					  CountryFrom cf = new CountryFrom();
					  cf.setFrom(helper.getRequestParameterValue("from"));
					  cf.setCountry(helper.getRequestParameterValue("country"));
					  cf.setDivision(helper.getRequestParameterValue("division"));
					  cf.setComment(helper.getRequestParameterValue("comment"));
					  String owner = helper.getAuthenticatedUserID();
				      TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
					  Locale loc = Locale.FRANCE;
					  Calendar cal = Calendar.getInstance(tz,loc);
					  Date date = cal.getTime();
					  cf.setPublishOwner(owner);
					  cf.setPublishDate(date);
					  int updateOk =  IIMexServlet.iimexUsersManager.getContactCollection().updateContactCountry(cf,contactCode);
					  if(updateOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
						  cont = IIMexServlet.iimexUsersManager.getContactCollection().getContactByCode(contactCode);
						  helper.setSessionParameter("contact",cont);
						  helper.setSessionParameter("allCountries",cont.getCountriesVector());
						  helper.setSessionParameter("size",cont.getCountriesVector().size());
					  }
					  helper.setSessionParameter("action","");
				  }	//save modifications on a contact information
				  else if((action.compareTo("update")==0)){
					  Contacts tmp = new Contacts();
					  tmp.setContactCode(Integer.parseInt(contactCode));
					  tmp.setCountry(helper.getRequestParameterValue("country"));
					  tmp.setContactType(helper.getRequestParameterValue("type"));
					  tmp.setContactName(helper.getRequestParameterValue("name"));
					  tmp.setContactPerson(helper.getRequestParameterValue("person"));
					  tmp.setStreet(helper.getRequestParameterValue("street"));
					  tmp.setCity(helper.getRequestParameterValue("city"));
					  tmp.setTel(helper.getRequestParameterValue("tel"));
					  tmp.setMobile(helper.getRequestParameterValue("mobile"));
					  tmp.setFax(helper.getRequestParameterValue("fax"));
					  tmp.setMail(helper.getRequestParameterValue("mail"));
					  tmp.setContactComments(helper.getRequestParameterValue("comments"));
					  String owner = helper.getAuthenticatedUserID();
				      TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
					  Locale loc = Locale.FRANCE;
					  Calendar cal = Calendar.getInstance(tz,loc);
					  Date date = cal.getTime();
					  tmp.setPublishOwner(owner);
					  tmp.setPublishDate(date);
					  int updateOk =  IIMexServlet.iimexUsersManager.getContactCollection().updateContact(tmp);
					  if(updateOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
						  cont = IIMexServlet.iimexUsersManager.getContactCollection().getContactByCode(contactCode);
						  helper.setSessionParameter("contact",cont);
						  helper.setSessionParameter("allCountries",cont.getCountriesVector());
						  helper.setSessionParameter("size",cont.getCountriesVector().size());
					  }
					  helper.setSessionParameter("action","");
				  }
				  else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("allCountry", IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry());
					  helper.setSessionParameter("allDivision", IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision());
					  helper.setSessionParameter("action","new");
					  helper.setSessionParameter("size",cont.getCountriesVector().size());
				  }//save a new contact country
				  else if((action.compareTo("add")==0)){
					  CountryFrom cf = new CountryFrom();
					  cf.setFrom(helper.getRequestParameterValue("from"));
					  cf.setCountry(helper.getRequestParameterValue("country"));
					  cf.setDivision(helper.getRequestParameterValue("division"));
					  cf.setComment(helper.getRequestParameterValue("comment"));
					  String owner = helper.getAuthenticatedUserID();
				      TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
					  Locale loc = Locale.FRANCE;
					  Calendar cal = Calendar.getInstance(tz,loc);
					  Date date = cal.getTime();
					  cf.setPublishOwner(owner);
					  cf.setPublishDate(date);
					  int addOk =  IIMexServlet.iimexUsersManager.getContactCollection().addContactCountry(cf,contactCode);
					  if(addOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
						  cont = IIMexServlet.iimexUsersManager.getContactCollection().getContactByCode(contactCode);
						  helper.setSessionParameter("contact",cont);
						  helper.setSessionParameter("allCountries",cont.getCountriesVector());
						  helper.setSessionParameter("size",cont.getCountriesVector().size());
					  }
					  helper.setSessionParameter("action","");
				  }//delete a contact country object
				  else if((action.compareTo("delete")==0)){
					  String country = helper.getRequestParameterValue("country");
					  String division = helper.getRequestParameterValue("division");
					  String fromCode = helper.getRequestParameterValue("fromCode");
					  int removeOk =  IIMexServlet.iimexUsersManager.getContactCollection().removeContactCountry(contactCode,country,division, fromCode);
					  if(removeOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
						  cont = IIMexServlet.iimexUsersManager.getContactCollection().getContactByCode(contactCode);
						  helper.setSessionParameter("contact",cont);
						  helper.setSessionParameter("allCountries",cont.getCountriesVector());
						  helper.setSessionParameter("size",cont.getCountriesVector().size());
					  }
					  helper.setSessionParameter("action","");
				  }
			  }
			  helper.redirect(helper.getContextPath()+"/admin/editContact.jsp");
		}  catch (Exception ex) {

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

	}


}



