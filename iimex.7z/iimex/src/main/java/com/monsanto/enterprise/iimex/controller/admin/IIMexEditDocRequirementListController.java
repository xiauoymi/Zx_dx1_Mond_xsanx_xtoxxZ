package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.Documents;



public class IIMexEditDocRequirementListController implements UseCaseController {


//edit an existing doc requirement
	public void run(UCCHelper helper) throws IOException {

		

		try{

			

			String  docId="0";

			String msg="";

			if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("docId"))){

				docId=helper.getRequestParameterValue("docId");

			}

			if(!docId.equalsIgnoreCase("0")){

			Documents docReq=	IIMexServlet.iimexUsersManager.getDocuments().getDocumentRequirements(new Integer(docId));

			helper.setSessionParameter("DocReq",docReq);

			helper.setSessionParameter("msg", msg);

			helper.redirect(helper.getContextPath()+"/admin/documentRequirementDetails.jsp");

			}else{

				Documents docReq = new Documents();

				int docIdInt = IIMexServlet.iimexUsersManager.getDocuments().getDocCounter()+5;

				docReq.setIDocCode(docIdInt);

				helper.setSessionParameter("msg", msg);

				helper.setSessionParameter("DocReq",docReq);

				helper.redirect(helper.getContextPath()+"/admin/documentRequirementDetails.jsp");

			}

			

		}catch(IIMexException e){

			Logger.log(new LoggableError("A error occured when loading the documents conditions " + e.toString()));

	        e.printStackTrace();

	        IIMexMailHelper.send(e,helper.getAuthenticatedUserFullName());

			helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

		

		

	}



}