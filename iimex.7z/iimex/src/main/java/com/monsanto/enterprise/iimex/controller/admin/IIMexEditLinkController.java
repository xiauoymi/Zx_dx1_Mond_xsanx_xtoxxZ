/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.LinkAndDocument;



public class IIMexEditLinkController implements UseCaseController{



	public void run(UCCHelper helper) throws IOException {



		

		String linkId=(helper.getRequestParameterValue("linkId")).toString();

		boolean newLinkGroup = false;

		String linkGroupName ="";

		String linkGroupDesc="";

		// Change link Description

		if(!linkId.equalsIgnoreCase("0")){

		try {

			LinkAndDocument linkDoc=IIMexServlet.iimexUsersManager.getLinks().getLinkAndDocument(linkId);

			linkGroupName = linkDoc.getLinkName();

			linkGroupDesc = linkDoc.getLinkDescription();		    

		} catch (IIMexException e) {

			Logger.log(new LoggableError("A error occured  " + "The error was: " + e.toString()));

	        e.printStackTrace();

	        IIMexMailHelper.send(e,helper.getAuthenticatedUserFullName());

			helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");	

		}

		

		}else{

			//New link

			newLinkGroup=true;

		}

		

		helper.setSessionParameter("editLinkId", linkId);

		helper.setSessionParameter("newLinkGroup", newLinkGroup);

		helper.setSessionParameter("linkGroupName", linkGroupName);

		helper.setSessionParameter("linkGroupDesc",linkGroupDesc);

		helper.redirect(helper.getContextPath()+"/admin/editLinkAdmin.jsp");

	}



}

