

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;
//interface to edit an existing plant
public class IIMexEditPlantController implements UseCaseController{

	public void run(UCCHelper helper) throws IOException {

		  try {

			  PlantsFromCountry plant = IIMexServlet.iimexUsersManager.getPlantsCollection().getPlantByCode(helper.getRequestParameterValue("codePlant"));
			  
			  Vector divisions = new Vector();
			  
			  HashMap div = plant.getDivision();
			  
			  Iterator ite = div.keySet().iterator();
			  
			  while(ite.hasNext()){
				  divisions.add((String)ite.next());
			  }
			  
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  helper.setSessionParameter("action", action);
				  int addOk=-1;
				  if((action.compareTo("UpdatePlant")==0)){
					  helper.setSessionParameter("allCountry",IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry());
					  helper.setSessionParameter("allCompany",IIMexServlet.iimexUsersManager.getCompaniesCollection().getAllCompanyCode());
				  }
				  //register modification on it
				  if((action.compareTo("registerPlant")==0)){
					  String code = helper.getRequestParameterValue("codePlant");
					  String plantName = helper.getRequestParameterValue("plantName");
					  String plantName2 = helper.getRequestParameterValue("plantName2");
					  String companyCode = helper.getRequestParameterValue("companyCode");
					  String active = helper.getRequestParameterValue("active");
					  String codeCountry = helper.getRequestParameterValue("codeCountry");
					  String owner = helper.getAuthenticatedUserID();
					  TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
					  Locale loc = Locale.FRANCE;
					  Calendar cal = Calendar.getInstance(tz,loc);
					  Date date = cal.getTime();
					  
					  PlantsFromCountry tmp = new PlantsFromCountry();
					  tmp.setPlantName(plantName);
					  tmp.setM_strPlantName2(plantName2);
					  tmp.setPublishOwner(owner);
					  tmp.setPublishDate(date);
					  tmp.setCodePlant(code);
					  tmp.setCodeFromCountry(codeCountry);
					  if(active.compareTo("true")==0)
						  tmp.setActive(true);
					  tmp.setM_strPlantCompanyCode(companyCode);
					  
					  addOk=IIMexServlet.iimexUsersManager.getPlantsCollection().updatePlant(tmp);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						plant = IIMexServlet.iimexUsersManager.getPlantsCollection().getPlantByCode(helper.getRequestParameterValue("codePlant"));
						 divisions = new Vector();
						 div = plant.getDivision();
						 ite = div.keySet().iterator();
						  while(ite.hasNext()){
							  divisions.add((String)ite.next());
						  }
					  }
					  helper.setSessionParameter("action", " ");
				  }//update a plant division
 				  if((action.compareTo("registerDivision")==0)){
 					 addOk=IIMexServlet.iimexUsersManager.getPlantsCollection().updatePlantDivision(plant.getCodePlant(), helper.getRequestParameterValue("codeDivision"),helper.getRequestParameterValue("comment"),helper.getAuthenticatedUserID());
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						plant = IIMexServlet.iimexUsersManager.getPlantsCollection().getPlantByCode(helper.getRequestParameterValue("codePlant"));
						 divisions = new Vector();
						 div = plant.getDivision();
						 ite = div.keySet().iterator();
						  while(ite.hasNext()){
							  divisions.add((String)ite.next());
						  }
					  }
					  helper.setSessionParameter("action", " ");
					  helper.setSessionParameter("divi"," ");
				  }
				  if((action.compareTo("editDivision")==0)){
					  helper.setSessionParameter("divi",helper.getRequestParameterValue("codeDivision"));
					  Collection allDiv = IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision();
					  Iterator it = allDiv.iterator();
					  Vector allDivision = new Vector();
					  while(it.hasNext()){
						  Division tmp = (Division)it.next();
						  if(!divisions.contains(tmp.getDivisionCode()))
							  allDivision.add(tmp);
					  }
					  helper.setSessionParameter("allDivision",allDivision);
				  }//delete it
				  if((action.compareTo("deleteDivision")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getPlantsCollection().deletePlantDivision(plant.getCodePlant(), helper.getRequestParameterValue("codeDivision"));
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						plant = IIMexServlet.iimexUsersManager.getPlantsCollection().getPlantByCode(helper.getRequestParameterValue("codePlant"));
						 divisions = new Vector();
						 div = plant.getDivision();
						 ite = div.keySet().iterator();
						  while(ite.hasNext()){
							  divisions.add((String)ite.next());
						  }
					  }
					  helper.setSessionParameter("action", " ");
				  }
				  if((action.compareTo("addDivision")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getPlantsCollection().addPlantDivision(plant.getCodePlant(), helper.getRequestParameterValue("codeDivision"),helper.getRequestParameterValue("comment"),helper.getAuthenticatedUserID());
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						plant = IIMexServlet.iimexUsersManager.getPlantsCollection().getPlantByCode(helper.getRequestParameterValue("codePlant"));
						 divisions = new Vector();
						 div = plant.getDivision();
						 ite = div.keySet().iterator();
						  while(ite.hasNext()){
							  divisions.add((String)ite.next());
						  }
					  }
					  helper.setSessionParameter("action", " ");
				}//add a new one
				  if((action.compareTo("add")==0)){
					  Collection allDiv = IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision();
					  Iterator it = allDiv.iterator();
					  Vector allDivision = new Vector();
					  while(it.hasNext()){
						  Division tmp = (Division)it.next();
						  if(!divisions.contains(tmp.getDivisionCode()))
							  allDivision.add(tmp);
					  }
					  helper.setSessionParameter("allDivision",allDivision);
				  }
			  }
			  helper.setSessionParameter("plant", plant);
			  helper.setSessionParameter("divisions", divisions);
			  helper.redirect(helper.getContextPath()+"/admin/editPlant.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  