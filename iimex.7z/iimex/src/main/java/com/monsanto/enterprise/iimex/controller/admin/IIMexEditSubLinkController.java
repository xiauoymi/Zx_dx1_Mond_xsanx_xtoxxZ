/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.DocLink;

import com.monsanto.enterprise.iimex.elements.LinkAndDocument;

import com.monsanto.enterprise.iimex.elements.Url;



public class IIMexEditSubLinkController implements UseCaseController{



	public void run(UCCHelper helper) throws IOException {

		String linkName ="";

		String linkDesc="";

		String urlPath="";

		String date="";

		String owner ="";

		String docName="";

		String urlId ="0";

		String docId="0";

		boolean isUrl= true;

		boolean newLink = false;

		String linkId=helper.getRequestParameterValue("linkId");

		if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("urlId"))){

			urlId=helper.getRequestParameterValue("urlId");

		}

		if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("docId"))){

			docId=helper.getRequestParameterValue("docId");

		}

		

		if(!(urlId.equalsIgnoreCase("0")&&(docId.equalsIgnoreCase("0")))){	

			try {

				LinkAndDocument linkDoc=IIMexServlet.iimexUsersManager.getLinks().getLinkAndDocument(linkId);

				if(!urlId.equalsIgnoreCase("0")){

				Url url = linkDoc.getUrl(urlId);

				linkName = url.getUrlTitle();

				urlPath = url.getUrl();

				linkDesc = url.getUrlDescription();

				owner=url.getPublishOwner();

				date =url.getPublishDate();

				}else{

					DocLink doc = linkDoc.getDocLink(docId);

					linkName=doc.getDocTitle();

					urlPath =doc.getDocName();

					linkDesc = doc.getdocDescription();

					owner=doc.getPublishOwner();

					date = doc.getPublishDate();

					docName =doc.getDocName();

					isUrl = false;

				}

			} catch (IIMexException e) {

				Logger.log(new LoggableError("A error occured  " + "The error was: " + e.toString()));

		        e.printStackTrace();

		        IIMexMailHelper.send(e,helper.getAuthenticatedUserFullName());

				helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");	

			}

			}else{

				newLink=true;

			}

	

		helper.setSessionParameter("newLink", newLink);

		helper.setSessionParameter("linkName", linkName);

		helper.setSessionParameter("linkDesc",linkDesc);

		helper.setSessionParameter("isUrl",isUrl);

		helper.setSessionParameter("linkId",linkId);

		helper.setSessionParameter("urlPath",urlPath);

		helper.setSessionParameter("urlId", urlId);

		helper.setSessionParameter("docId", docId);

		helper.setSessionParameter("publishOwner",owner);

		helper.setSessionParameter("publishDate", date);

		helper.setSessionParameter("docName", docName);

		

		

		helper.redirect(helper.getContextPath()+"/admin/editLinkDocAdmin.jsp");

	}



}

