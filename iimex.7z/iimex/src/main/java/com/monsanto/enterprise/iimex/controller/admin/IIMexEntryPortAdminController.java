

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Vector;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.PreferredPort;



public class IIMexEntryPortAdminController implements UseCaseController{

//manage the preferred ports of entry in a country

	public void run(UCCHelper helper) throws IOException {

		  try {

			  String countryCode = helper.getRequestParameterValue("countryCode");
			  String name = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryName(countryCode);
			  Vector allPorts = IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getPortsByCode(countryCode);
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  int addOk=-1;
				  		//delete one			  
				  if((action.compareTo("delete")==0)){
					  String division = helper.getRequestParameterValue("division");
					  String countryCode2 = helper.getRequestParameterValue("countryCode2");
					  addOk=IIMexServlet.iimexUsersManager.getCountryToCountryCollection().removePort(countryCode,countryCode2,division);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							allPorts = IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getPortsByCode(countryCode);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("countryCode2","");
					  helper.setSessionParameter("division","");
				  }else if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("countryCode2",helper.getRequestParameterValue("countryCode2"));
					  helper.setSessionParameter("division",helper.getRequestParameterValue("division"));
					  helper.setSessionParameter("action","edit");
					  //update one
				  }else if((action.compareTo("register")==0)){
					  String division = helper.getRequestParameterValue("division");
					  String countryCode2 = helper.getRequestParameterValue("countryCode2");
					  PreferredPort pp = new PreferredPort();
					  pp.setDestCountryCode(countryCode2);
					  pp.setDivision(division);
					  pp.setPort(helper.getRequestParameterValue("port"));
					  pp.setOwner( helper.getAuthenticatedUserID());
					  
					  addOk=IIMexServlet.iimexUsersManager.getCountryToCountryCollection().updatePort(pp,countryCode,division);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allPorts = IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getPortsByCode(countryCode);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("countryCode2","");
					  helper.setSessionParameter("division","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("countryCode2","");
					  helper.setSessionParameter("division","");
					  helper.setSessionParameter("action","new");
					  helper.setSessionParameter("allDiv",IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision());
					  helper.setSessionParameter("allDest",IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry());
					  //save a new one
				  }else if((action.compareTo("save")==0)){
					  String division = helper.getRequestParameterValue("division");
					  String countryCode2 = helper.getRequestParameterValue("countryCode2");
					  PreferredPort pp = new PreferredPort();
					  pp.setDestCountryCode(countryCode2);
					  pp.setDivision(division);
					  pp.setPort(helper.getRequestParameterValue("port"));
					  pp.setOwner( helper.getAuthenticatedUserID());
					  
					  addOk=IIMexServlet.iimexUsersManager.getCountryToCountryCollection().addPort(pp,countryCode,division);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allPorts = IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getPortsByCode(countryCode);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("countryCode2","");
					  helper.setSessionParameter("division","");
				  }
				  
			  }
			  helper.setSessionParameter("countryCode", countryCode);
			  helper.setSessionParameter("name", name);
			  helper.setSessionParameter("allPorts", allPorts);
			  helper.redirect(helper.getContextPath()+"/admin/portAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  