

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.Fees;

//manage the fees in shipping or destination country

public class IIMexFeesAdminController implements UseCaseController{



	public void run(UCCHelper helper) throws IOException {

		  try {
			  String countryCode = helper.getRequestParameterValue("countryCode");
			  String shipping = helper.getRequestParameterValue("shipping");
			  Fees fee = null;
			  if(shipping.compareTo("S")==0)
				  fee = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode).getShipping();
			  else fee = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode).getDestination();
			  String action ="";
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  action = helper.getRequestParameterValue("action");
				  int addOk=-1;
				  //update a fee if it already exists save a new one otherwise 
				  if((action.compareTo("save")==0)){
					  Fees tmp = new Fees();
					  tmp.setCertificateOfOrigin(helper.getRequestParameterValue("certificateOfOrigin"));
					  tmp.setConsular(helper.getRequestParameterValue("consular"));
					  tmp.setFederalSeedLab(helper.getRequestParameterValue("federalSeedLab"));
					  tmp.setHandling(helper.getRequestParameterValue("handling"));
					  tmp.setInspection(helper.getRequestParameterValue("inspection"));
					  tmp.setInsurance(helper.getRequestParameterValue("insurance"));
					  tmp.setLegalization(helper.getRequestParameterValue("legalization"));
					  tmp.setOther(helper.getRequestParameterValue("other"));
					  tmp.setPhytosanitaryCertificate(helper.getRequestParameterValue("phytosanitaryCertificate"));
					  tmp.setSeedAnalysisCertificate(helper.getRequestParameterValue("seedAnalysisCertificate"));
					  tmp.setPublishOwner(helper.getAuthenticatedUserID());
					  if(fee.getExist())
						  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().updateFees(tmp, countryCode, shipping);
					  else addOk=IIMexServlet.iimexUsersManager.getCountryCollection().addFees(tmp, countryCode, shipping);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							if(shipping.compareTo("S")==0)
								  fee = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode).getShipping();
							  else fee = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode).getDestination();
							action="";
					  }
				  }
			  }
			  helper.setSessionParameter("countryCode", countryCode);
			  helper.setSessionParameter("fee", fee);
			  helper.setSessionParameter("name", IIMexServlet.iimexUsersManager.getCountryCollection().getCountryName(countryCode));
			  helper.setSessionParameter("shipping", shipping);
			  helper.setSessionParameter("action", action);
			  helper.redirect(helper.getContextPath()+"/admin/feeAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  