

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.ImportDuties;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;



public class IIMexImportDutiesAdminController implements UseCaseController{

//administratio interface for the import duties

	public void run(UCCHelper helper) throws IOException {

		  try {

			  String code = helper.getRequestParameterValue("code");
			  Country country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(code);
			  Vector allDuties = IIMexServlet.iimexUsersManager.getImportDutiesCollection().getCountryDuty(country);
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  int addOk=-1;
				  				//delete one	  
				  if((action.compareTo("delete")==0)){
					  String shipZone = helper.getRequestParameterValue("shipZone");
					  String shipCountry = helper.getRequestParameterValue("shipCountry");
					  String hts = helper.getRequestParameterValue("hts");
					  String destZone = helper.getRequestParameterValue("destZone");
					  String destCountry = helper.getRequestParameterValue("destCountry");
					  
					 ImportDuties dut = new ImportDuties();
					 dut.setZoneOrigin(shipZone);
					 dut.setZoneDestination(destZone);
					 dut.setCountryOrigin(shipCountry);
					 dut.setCountryDestination(destCountry);
					 dut.setHtsCode(hts);
					 
					  addOk=IIMexServlet.iimexUsersManager.getImportDutiesCollection().removeDuty(dut);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							allDuties = IIMexServlet.iimexUsersManager.getImportDutiesCollection().getCountryDuty(IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(code));
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("shipZone","");
					  helper.setSessionParameter("shipCountry","");
					  helper.setSessionParameter("hts","");
					  helper.setSessionParameter("destZone","");
					  helper.setSessionParameter("destCountry","");
				  }else if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("shipZone",helper.getRequestParameterValue("shipZone"));
					  helper.setSessionParameter("shipCountry",helper.getRequestParameterValue("shipCountry"));
					  helper.setSessionParameter("hts",helper.getRequestParameterValue("hts"));
					  helper.setSessionParameter("destZone",helper.getRequestParameterValue("destZone"));
					  helper.setSessionParameter("destCountry",helper.getRequestParameterValue("destCountry"));
					  helper.setSessionParameter("action","edit");
					  //update one
				  }else if((action.compareTo("register")==0)){
					  String shipZone = helper.getRequestParameterValue("shipZone");
					  String shipCountry = helper.getRequestParameterValue("shipCountry");
					  String hts = helper.getRequestParameterValue("hts");
					  String destZone = helper.getRequestParameterValue("destZone");
					  String destCountry = helper.getRequestParameterValue("destCountry");
					  String duty = helper.getRequestParameterValue("duty");
					  String owner = helper.getAuthenticatedUserID();
					  
					 ImportDuties dut = new ImportDuties();
					 dut.setZoneOrigin(shipZone);
					 dut.setZoneDestination(destZone);
					 dut.setCountryOrigin(shipCountry);
					 dut.setCountryDestination(destCountry);
					 dut.setHtsCode(hts);
					 dut.setImportDuties(duty);
					 dut.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getImportDutiesCollection().updateDuty(dut);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allDuties = IIMexServlet.iimexUsersManager.getImportDutiesCollection().getCountryDuty(IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(code));
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("shipZone","");
					  helper.setSessionParameter("shipCountry","");
					  helper.setSessionParameter("hts","");
					  helper.setSessionParameter("destZone","");
					  helper.setSessionParameter("destCountry","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("shipZone","");
					  helper.setSessionParameter("shipCountry","");
					  helper.setSessionParameter("hts","");
					  helper.setSessionParameter("destZone","");
					  helper.setSessionParameter("destCountry","");
					  helper.setSessionParameter("action","new");
					  helper.setSessionParameter("country",country);
					  helper.setSessionParameter("allZone",IIMexServlet.iimexUsersManager.getCustomZonesCollection().getAllCZones());
					  helper.setSessionParameter("allCountry",IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry());
					  helper.setSessionParameter("allProd",IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup());
					  //save a new one
				  }else if((action.compareTo("save")==0)){
					  String shipZone = helper.getRequestParameterValue("shipZone");
					  String shipCountry = helper.getRequestParameterValue("shipCountry");
					  String hts = helper.getRequestParameterValue("hts");
					  String destZone = helper.getRequestParameterValue("destZone");
					  String destCountry = helper.getRequestParameterValue("destCountry");
					  String duty = helper.getRequestParameterValue("duty");
					  String owner = helper.getAuthenticatedUserID();
					  
					 ImportDuties dut = new ImportDuties();
					 dut.setZoneOrigin(shipZone);
					 dut.setZoneDestination(destZone);
					 dut.setCountryOrigin(shipCountry);
					 dut.setCountryDestination(destCountry);
					 dut.setHtsCode(hts);
					 dut.setImportDuties(duty);
					 dut.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getImportDutiesCollection().addDuty(dut);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allDuties = IIMexServlet.iimexUsersManager.getImportDutiesCollection().getCountryDuty(IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(code));
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("shipZone","");
					  helper.setSessionParameter("shipCountry","");
					  helper.setSessionParameter("hts","");
					  helper.setSessionParameter("destZone","");
					  helper.setSessionParameter("destCountry","");
				  }
				  
			  }
			  helper.setSessionParameter("code", code);
			  helper.setSessionParameter("allDuties", allDuties);
			  helper.redirect(helper.getContextPath()+"/admin/importDutiesAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  