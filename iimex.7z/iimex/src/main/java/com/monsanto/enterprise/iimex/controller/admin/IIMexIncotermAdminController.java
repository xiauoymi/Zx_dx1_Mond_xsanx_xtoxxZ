

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.collections.WorldAreaCollection;
import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.IncotermTransportInfo;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;
import com.monsanto.enterprise.iimex.elements.WorldArea;
import com.monsanto.enterprise.iimex.elements.customZone;

//class that mangaes the incoterms

public class IIMexIncotermAdminController implements UseCaseController{

	public void run(UCCHelper helper) throws IOException {

		  try {

			  Vector allIncoterms = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getAllDifferentIncoterm();
			  allIncoterms.addAll(IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewIncoterm());
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  String code = helper.getRequestParameterValue("code");
				  int addOk=-1;		
				  //delete one
				  if((action.compareTo("delete")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().removeIncoterm(code);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							allIncoterms = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getAllDifferentIncoterm();
							allIncoterms.addAll(IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewIncoterm());
					  }
					  helper.setSessionParameter("code","");
					  helper.setSessionParameter("action","");
				  }else if((action.compareTo("edit")==0)){
					 helper.setSessionParameter("code",code);
					 helper.setSessionParameter("action","edit");
					 //save a new one
				  }else if((action.compareTo("register")==0)){
					  code = helper.getRequestParameterValue("code");
					  String description = helper.getRequestParameterValue("description");
					  String duty = helper.getRequestParameterValue("duty");
					  String freight = helper.getRequestParameterValue("freight");
					  String insurance = helper.getRequestParameterValue("insurance");
					  String owner = helper.getAuthenticatedUserID();
					  
					  IncotermTransportInfo inco = new IncotermTransportInfo(); 
					  inco.setSIncotermsCode(code);
					  inco.setSIncotermDescr(description);
					  inco.setSDuties(duty);
					  inco.setSFreight(freight);
					  inco.setSInsurance(insurance);
					  inco.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().addIncoterm(inco);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allIncoterms = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getAllDifferentIncoterm();
						allIncoterms.addAll(IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewIncoterm());
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("code","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("code","");
					  helper.setSessionParameter("action","new");
					  //save modifications on an existing one 
				  }else if((action.compareTo("save")==0)){
					  code = helper.getRequestParameterValue("code");
					  String description = helper.getRequestParameterValue("description");
					  String duty = helper.getRequestParameterValue("duty");
					  String freight = helper.getRequestParameterValue("freight");
					  String insurance = helper.getRequestParameterValue("insurance");
					  String owner = helper.getAuthenticatedUserID();
					  
					  IncotermTransportInfo inco = new IncotermTransportInfo(); 
					  inco.setSIncotermsCode(code);
					  inco.setSIncotermDescr(description);
					  inco.setSDuties(duty);
					  inco.setSFreight(freight);
					  inco.setSInsurance(insurance);
					  inco.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().updateIncoterm(inco);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allIncoterms = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getAllDifferentIncoterm();
						allIncoterms.addAll(IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewIncoterm());
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("code","");
				  }
				  
			  }
			  
			  helper.setSessionParameter("allIncoterms", allIncoterms);
			  helper.redirect(helper.getContextPath()+"/admin/incotermAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  
