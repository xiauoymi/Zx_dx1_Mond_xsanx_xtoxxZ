

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Vector;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.ImportLicenseApproval;



public class IIMexLicenseAdminController implements UseCaseController{

//manage the import license approval in a country

	public void run(UCCHelper helper) throws IOException {

		  try {

			  String countryCode = helper.getRequestParameterValue("countryCode");
			  Country country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
			  Vector allLicenses = country.getImportLicenseApprovalVector();
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  int addOk=-1;
				  			//delete one 		  
				  if((action.compareTo("delete")==0)){
					  String hts = helper.getRequestParameterValue("hts");
					  
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().removeLicense(countryCode,hts);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
							allLicenses = country.getImportLicenseApprovalVector();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("hts","");
				  }else if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("hts",helper.getRequestParameterValue("hts"));
					  helper.setSessionParameter("action","edit");
					  //save modifications on one
				  }else if((action.compareTo("register")==0)){
					  String hts = helper.getRequestParameterValue("hts");
					  
					  ImportLicenseApproval license = new ImportLicenseApproval();
					  license.setImportLicenseApproval(helper.getRequestParameterValue("license"));
					  license.setPublishOwner( helper.getAuthenticatedUserID());
					  
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().updateLicense(license,countryCode,hts);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
						allLicenses = country.getImportLicenseApprovalVector();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("hts","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("hts","");
					  helper.setSessionParameter("action","new");
					  helper.setSessionParameter("allProd",IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup());
					  //add a new one
				  }else if((action.compareTo("save")==0)){
					  String hts = helper.getRequestParameterValue("hts");
					  
					  ImportLicenseApproval license = new ImportLicenseApproval();
					  license.setImportLicenseApproval(helper.getRequestParameterValue("license"));
					  license.setPublishOwner( helper.getAuthenticatedUserID());
					  
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().addLicense(license,countryCode,hts);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
						allLicenses = country.getImportLicenseApprovalVector();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("hts","");
				  }
				  
			  }
			  helper.setSessionParameter("countryCode", countryCode);
			  helper.setSessionParameter("allLicenses", allLicenses);
			  helper.redirect(helper.getContextPath()+"/admin/licenseAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  