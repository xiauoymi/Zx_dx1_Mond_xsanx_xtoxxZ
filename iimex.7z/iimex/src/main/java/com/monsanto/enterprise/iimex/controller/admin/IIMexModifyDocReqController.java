package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import java.util.ArrayList;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.Documents;



public class IIMexModifyDocReqController implements UseCaseController {

//	controller used to modify a document requirement

	public void run(UCCHelper helper) throws IOException{

		int rowUpdate=0;

		String msg="";

		String userID=helper.getAuthenticatedUserID();

		String docName=((Documents)helper.getSessionParameter("DocReq")).getSDocName();

		int docId= ((Documents)helper.getSessionParameter("DocReq")).getIDocCode();

		String typeReq=((Documents)helper.getSessionParameter("DocReq")).getSTypeRequirement();

		String purpose=((Documents)helper.getSessionParameter("DocReq")).getPurpose();

		String filePath="";

		ArrayList uploadedFiles =helper.getClientFiles();

		
	
		
		

		if(!StringUtils.isNullOrEmpty((helper.getRequestParameterValue("docName")).toString())){

			docName= (helper.getRequestParameterValue("docName")).toString();

		}

		if(!StringUtils.isNullOrEmpty((helper.getRequestParameterValue("typeReq")).toString())){

			typeReq= (helper.getRequestParameterValue("typeReq")).toString();

		}

		if(!StringUtils.isNullOrEmpty((helper.getRequestParameterValue("purpose")).toString())){

			purpose= (helper.getRequestParameterValue("purpose")).toString();

		}

		//filePath=helper.getRequestParameterValue("filePath").toString();

		Documents docReq= null;

		try{

			if(uploadedFiles.size()>0)
				filePath=(String)uploadedFiles.get(0);
			
			if(!((Documents)helper.getSessionParameter("DocReq")).isNotNewDoc()){

				rowUpdate=IIMexServlet.iimexUsersManager.getDocuments().addDocuments(docId,docName,typeReq,purpose,filePath,userID);

				if(rowUpdate>0){

					IIMexServlet.iimexUsersManager.updateDBstatus();

					docReq = IIMexServlet.iimexUsersManager.getDocuments().getDocumentRequirements(new Integer(docId));

					msg= docName + " has been created, you can add the documents requirements";

				}else{

					msg= docName + " has not been created, you can add the documents requirements";

				}

			}else{

	

				rowUpdate=IIMexServlet.iimexUsersManager.getDocuments().updateDocuments(docId,docName,typeReq,purpose,filePath);

				if(rowUpdate>0){

					IIMexServlet.iimexUsersManager.updateDBstatus();

					docReq =IIMexServlet.iimexUsersManager.getDocuments().getDocumentRequirements(new Integer(docId));

					msg=docName + " document has been updated correctly";

			}else{

				msg= docName + " has not been updated, please try again";

			}

			}

			helper.setSessionParameter("msg", msg);

			helper.setSessionParameter("DocReq", docReq);

			helper.redirect(helper.getContextPath()+"/admin/documentRequirementDetails.jsp");

		}catch(IIMexException exc){

			Logger.log(new LoggableError("A error occured  update link " + exc.toString()));

	        exc.printStackTrace();

	        IIMexMailHelper.send(exc,helper.getAuthenticatedUserFullName());

			helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}finally{

			   helper.deleteScratchFolder();

		  }

		

	}



}

