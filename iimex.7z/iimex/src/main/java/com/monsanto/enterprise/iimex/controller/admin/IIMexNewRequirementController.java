package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.DocumentConditions;

import com.monsanto.enterprise.iimex.elements.Documents;

import com.monsanto.enterprise.iimex.elements.IncotermTransportInfo;



public class IIMexNewRequirementController implements UseCaseController{

//controller used to save a new document requirement

	public void run(UCCHelper helper) throws IOException {

		String specialReq=helper.getRequestParameterValue("specialReq");

		String buyerSeller = helper.getRequestParameterValue("buyerSeller");

        String comments = helper.getRequestParameterValue("comment");

		String whenSent= helper.getRequestParameterValue("whenSent");
		
		String whereSent= helper.getRequestParameterValue("whereSent");
		
		String shippingMethod= helper.getRequestParameterValue("shippingMethod");

		String fromCountry=helper.getRequestParameterValue("fromCountry");

		String fromCustomZone=helper.getRequestParameterValue("fromCustomZone");
		
		String toCountry=helper.getRequestParameterValue("toCountry");

		String toCustomZone=helper.getRequestParameterValue("toCustomZone");

		String countryOrigin=helper.getRequestParameterValue("countryOrigin");
		
		String zoneOrigin=helper.getRequestParameterValue("zoneOrigin");

		String transportMode= helper.getRequestParameterValue("transportMode");
		
		String incoterm= helper.getRequestParameterValue("incoterm");

		String division=helper.getRequestParameterValue("division");
		
		String prodGroup=helper.getRequestParameterValue("prodGroup");

		String trait=helper.getRequestParameterValue("trait");

		String owner = helper.getAuthenticatedUserID();

		int updateOk=0;

		String msg="";

		Documents doc = (Documents)helper.getSessionParameter("DocReq");

		

	try{

		DocumentConditions docCond= new DocumentConditions();

		docCond.setDocumentCode(String.valueOf(doc.getIDocCode()));

		docCond.setSpecialReq(specialReq);

		docCond.setBuyerSeller(buyerSeller);

        docCond.setComments(comments);
		
		docCond.setWhenSent(whenSent);

		docCond.setWhereSent(whereSent);
		
		docCond.setShippingMethod(shippingMethod);
		
		docCond.setFromcountry(fromCountry);
		
		docCond.setFromcustomsZone(fromCustomZone);
		
		docCond.setToCountry(toCountry);
		
		docCond.setToCustZone(toCustomZone);
		
		docCond.setOriginCountry(countryOrigin);
		
		docCond.setZoneOrigin(zoneOrigin);
		
		docCond.setIncoterms(incoterm);
		
		docCond.setTranspMode(transportMode);
		
		docCond.setDivision(division);
		
		docCond.setProductGroup(prodGroup);
		
		docCond.setTrait(trait);
		
		docCond.setPublishDate(new Date());
		
		docCond.setPublishOwner(owner);

		boolean newDocCond=IIMexServlet.iimexUsersManager.getDocuments().checkDocumentCondition(docCond);

		if(newDocCond){

			updateOk=IIMexServlet.iimexUsersManager.getDocuments().addDocCondition(docCond);

			if(updateOk>0){

				IIMexServlet.iimexUsersManager.updateDBstatus();

				msg="Document condition updated correctly";

			}else{

				msg="Error updating document condition, please try again";

			}

		}else{

			msg="Document condition already existent please try again";

		}

		

	}catch(IIMexException e) {

		  Logger.log(new LoggableError("A error occured " + "The error was: " + e.toString()));

		  e.printStackTrace();

		  IIMexMailHelper.send(e,helper.getAuthenticatedUserFullName());

	       helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

	}

	helper.setSessionParameter("msg", msg);

	helper.redirect(helper.getContextPath()+"/inside/IIMEX_maintenance_index.jsp");	

	}



}

