

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;



public class IIMexPlantAdminController implements UseCaseController{

//manage the plants in a country

	public void run(UCCHelper helper) throws IOException {

		  try {
			  String countryCode = helper.getRequestParameterValue("countryCode");
			  Collection ListPlant = IIMexServlet.iimexUsersManager.getPlantsCollection().getAllPlantsByCountry(countryCode);
			  
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  String codePlant = helper.getRequestParameterValue("codePlant");
				  int addOk=-1;
				  //delete one
				  if((action.compareTo("delete")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getPlantsCollection().inactivePlant(codePlant);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							ListPlant = IIMexServlet.iimexUsersManager.getPlantsCollection().getAllPlantsByCountry(countryCode);
					  }
					  //activate an existing one
				  }else if((action.compareTo("activate")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getPlantsCollection().activePlant(codePlant);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							ListPlant = IIMexServlet.iimexUsersManager.getPlantsCollection().getAllPlantsByCountry(countryCode);
					  }
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("allCountry", IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry());
					  helper.setSessionParameter("allCompany", IIMexServlet.iimexUsersManager.getCompaniesCollection().getAllCompanyCode());
					  helper.setSessionParameter("action","new");
					  //add a new one
				  }else if((action.compareTo("register")==0)){
					  String code = helper.getRequestParameterValue("codePlant");
					  String plantName = helper.getRequestParameterValue("plantName");
					  String plantName2 = helper.getRequestParameterValue("plantName2");
					  String companyCode = helper.getRequestParameterValue("companyCode");
					  String active = helper.getRequestParameterValue("active");
					  String codeCountry = helper.getRequestParameterValue("codeCountry");
					  String owner = helper.getAuthenticatedUserID();
					  TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
					  Locale loc = Locale.FRANCE;
					  Calendar cal = Calendar.getInstance(tz,loc);
					  Date date = cal.getTime();
					  
					  PlantsFromCountry plant = new PlantsFromCountry();
					  plant.setPlantName(plantName);
					  plant.setM_strPlantName2(plantName2);
					  plant.setPublishOwner(owner);
					  plant.setPublishDate(date);
					  plant.setCodePlant(code);
					  plant.setCodeFromCountry(codeCountry);
					  plant.setM_strPlantCompanyCode(companyCode);
					  
					  addOk=IIMexServlet.iimexUsersManager.getPlantsCollection().addPlant(plant);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						ListPlant = IIMexServlet.iimexUsersManager.getPlantsCollection().getAllPlantsByCountry(countryCode);
					  }
					  helper.setSessionParameter("action","");
				  }
				  
			  }
              else{
                helper.setSessionParameter("action","");   
              }
			  helper.setSessionParameter("countryCode", countryCode);
			  helper.setSessionParameter("allPlant", ListPlant);
			  helper.redirect(helper.getContextPath()+"/admin/plantAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  