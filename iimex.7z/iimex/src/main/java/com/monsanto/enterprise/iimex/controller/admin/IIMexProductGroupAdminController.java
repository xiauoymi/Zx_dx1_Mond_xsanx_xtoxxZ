

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.elements.ProductGroup;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;



public class IIMexProductGroupAdminController implements UseCaseController{

//manage the product groups inside a division

	public void run(UCCHelper helper) throws IOException {

		  try {

			  String division = helper.getRequestParameterValue("codeDivision");
			  Collection ListProductGroup = IIMexServlet.iimexUsersManager.getProducts().getAllProductGroupByDivision(division);
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  String codeProduct = helper.getRequestParameterValue("codeProduct");
				  int addOk=-1;
				  //delete one
				  if((action.compareTo("delete")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getProducts().removeProduct(codeProduct);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							ListProductGroup = IIMexServlet.iimexUsersManager.getProducts().getAllProductGroupByDivision(division);
					  }
					  helper.setSessionParameter("codeProduct","");
					  helper.setSessionParameter("action","");
				  }else if((action.compareTo("edit")==0)){
					 helper.setSessionParameter("codeProduct",codeProduct);
					 helper.setSessionParameter("action","edit");
					 //add a new one
				  }else if((action.compareTo("register")==0)){
					  String code = helper.getRequestParameterValue("codeProduct");
					  String name = helper.getRequestParameterValue("ProductName");
					  String divisionCode = helper.getRequestParameterValue("codeDivision");
					  String htsCode = helper.getRequestParameterValue("htsCode");
					  String botanical = helper.getRequestParameterValue("botanical");
					  String owner = helper.getAuthenticatedUserID();
					  
					  ProductGroup prod = new ProductGroup();
					  prod.setProductGroupCode(code);
					  prod.setProductGroupName(name);
					  prod.setDivisionCode(divisionCode);
					  prod.setHTSCode(htsCode);
					  prod.setBotanicalName(botanical);
					  prod.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getProducts().addProduct(prod);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						ListProductGroup = IIMexServlet.iimexUsersManager.getProducts().getAllProductGroupByDivision(division);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("codeProduct","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("codeProduct","");
					  helper.setSessionParameter("action","new");
					  //save an edited one
				  }else if((action.compareTo("save")==0)){
					  String code = helper.getRequestParameterValue("codeProduct");
					  String name = helper.getRequestParameterValue("productGroupName");
					  String divisionCode = helper.getRequestParameterValue("codeDivision");
					  String htsCode = helper.getRequestParameterValue("htsCode");
					  String botanical = helper.getRequestParameterValue("botanical");
					  String owner = helper.getAuthenticatedUserID();
					  
					  ProductGroup prod = new ProductGroup();
					  prod.setProductGroupCode(code);
					  prod.setProductGroupName(name);
					  prod.setDivisionCode(divisionCode);
					  prod.setHTSCode(htsCode);
					  prod.setBotanicalName(botanical);
					  prod.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getProducts().updateProduct(prod);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						ListProductGroup = IIMexServlet.iimexUsersManager.getProducts().getAllProductGroupByDivision(division);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("codeProduct","");
				  }
				  
			  }
			  
			  helper.setSessionParameter("codeDivision", division);
			  helper.setSessionParameter("allProduct", ListProductGroup);
			  helper.redirect(helper.getContextPath()+"/admin/productGroupAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  