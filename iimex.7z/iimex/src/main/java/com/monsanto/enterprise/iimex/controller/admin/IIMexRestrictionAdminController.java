package com.monsanto.enterprise.iimex.controller.admin;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.collections.CountryCollection;
import com.monsanto.enterprise.iimex.collections.CountryToCountryCollection;
import com.monsanto.enterprise.iimex.elements.ProductGroup;
import com.monsanto.enterprise.iimex.elements.ShippingRestriction;
import com.monsanto.enterprise.iimex.elements.ShippingRestrictionType;

import java.io.IOException;
import java.util.Collection;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 16, 2010
 * Time: 9:08:45 AM
 */
public class IIMexRestrictionAdminController implements UseCaseController {
    static final String ACTION_PARM = "action";
    static final String PRODUCT_CODE_PARM = "productCode";

    public void run(UCCHelper helper) throws IOException {
        // clear residual session parms that may be residual, which drive decisions below
        helper.setSessionParameter(ACTION_PARM, "");
        helper.setSessionParameter(PRODUCT_CODE_PARM, "");

        try {
            CountryToCountryCollection countryToCountryColl = IIMexServlet.iimexUsersManager.getCountryToCountryCollection();
            CountryCollection countryColl = IIMexServlet.iimexUsersManager.getCountryCollection();
            String destCode = helper.getRequestParameterValue("destCountry");
            String originCode = helper.getRequestParameterValue("originCountry");
            String productCode = helper.getRequestParameterValue(PRODUCT_CODE_PARM);
            String originName = countryColl.getCountryName(originCode);
            String destName = countryColl.getCountryName(destCode);
            Collection<ShippingRestriction> allRestr = countryToCountryColl.getRestrictions(destCode, originCode);
            if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue(ACTION_PARM))){
                String action = helper.getRequestParameterValue(ACTION_PARM);
                if (action.equalsIgnoreCase("delete")) {
                    int deleteOk=countryToCountryColl.removeRestriction(destCode, originCode, productCode);
                    if (deleteOk>0) {
                        IIMexServlet.iimexUsersManager.updateDBstatus();
                        allRestr = countryToCountryColl.getRestrictions(destCode, originCode);
                    }

                } else if (action.equalsIgnoreCase("edit")) {
                    Vector<ShippingRestrictionType> restricTypes = IIMexServlet.iimexUsersManager.getShipmentRestrictionTypeCollection().getAllTypes();
                    helper.setSessionParameter("allTypes", restricTypes);
                    helper.setSessionParameter(ACTION_PARM, "edit");
                    helper.setSessionParameter(PRODUCT_CODE_PARM, productCode);

                } else if (action.equalsIgnoreCase("new")) {
                    Vector<ShippingRestrictionType> restricTypes = IIMexServlet.iimexUsersManager.getShipmentRestrictionTypeCollection().getAllTypes();
                    helper.setSessionParameter("allTypes", restricTypes);
                    Vector<ProductGroup> prodTypes = IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup();
                    helper.setSessionParameter("allProd", prodTypes);
                    helper.setSessionParameter(ACTION_PARM, "new");

                } else if (action.equalsIgnoreCase("save")) { // saving an update
                    ShippingRestriction srt = buildRestrictionFromRequest(helper);
					int updOk = countryToCountryColl.updateRestriction(srt);
					if(updOk > 0){
					    IIMexServlet.iimexUsersManager.updateDBstatus();
						allRestr = countryToCountryColl.getRestrictions(destCode, originCode);
					}

				}  else if (action.equalsIgnoreCase("register")) { // registering a new added restriction
                    ShippingRestriction srt = buildRestrictionFromRequest(helper);
					int addOk = countryToCountryColl.addRestriction(srt);
					if(addOk > 0){
					    IIMexServlet.iimexUsersManager.updateDBstatus();
						allRestr = countryToCountryColl.getRestrictions(destCode, originCode);
					}
				}
            }
            helper.setSessionParameter("allRestr", allRestr);
            helper.setSessionParameter("originCountry", originCode);
            helper.setSessionParameter("destCountry", destCode);
            helper.setSessionParameter("originName", originName);
            helper.setSessionParameter("destName", destName);
            helper.redirect(helper.getContextPath()+"/admin/restrictionAdmin.jsp");
        } catch (IIMexException ex) {
            Logger.log(new LoggableError("A error occurred " + "The error was: " + ex.toString()));
            ex.printStackTrace();
            IIMexMailHelper.send(ex, helper.getAuthenticatedUserFullName());
            helper.redirect(helper.getContextPath() + "/inside/ExceptionHandler.jsp");
        }
    }

    private ShippingRestriction buildRestrictionFromRequest(UCCHelper helper) throws IOException {
        ShippingRestriction restriction = new ShippingRestriction();
        restriction.setDestination(helper.getRequestParameterValue("destCountry"));
        restriction.setOrigin(helper.getRequestParameterValue("originCountry"));
        restriction.setProductCode(helper.getRequestParameterValue(PRODUCT_CODE_PARM));
        restriction.setRestrictionTypeCode(helper.getRequestParameterValue("restrCode"));
        restriction.setComments(helper.getRequestParameterValue("comments"));
        restriction.setPublishOwnerId(helper.getAuthenticatedUserID());
        // date will be set in the insert/update
        return restriction;
    }

}
