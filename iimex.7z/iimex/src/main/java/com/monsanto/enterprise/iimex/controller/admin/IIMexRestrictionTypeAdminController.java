package com.monsanto.enterprise.iimex.controller.admin;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.collections.IIMexEntityCollisionException;
import com.monsanto.enterprise.iimex.elements.ShippingRestrictionType;

import java.io.IOException;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 16, 2010
 * Time: 9:06:42 AM
 */
public class IIMexRestrictionTypeAdminController implements UseCaseController {
    
    public void run(UCCHelper helper) throws IOException {
        try {
            // TODO: have not written UT code for the following 5 lines of clearing session params
            helper.setSessionParameter("errorMsg", null);
            helper.setSessionParameter("action", "");
            helper.setSessionParameter("code", "");
            helper.setSessionParameter("name", null);
            helper.setSessionParameter("comments", null);
            Vector<ShippingRestrictionType> allTypes = IIMexServlet.iimexUsersManager.getShipmentRestrictionTypeCollection().getAllTypes();
            if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
                String action = helper.getRequestParameterValue("action");
                String code = helper.getRequestParameterValue("code");

				//delete one
				if (action.equalsIgnoreCase("delete")) {
					int deleteOk=IIMexServlet.iimexUsersManager.getShipmentRestrictionTypeCollection().removeType(code);
					if (deleteOk>0) {
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allTypes = IIMexServlet.iimexUsersManager.getShipmentRestrictionTypeCollection().getAllTypes();
					}
					helper.setSessionParameter("code","");
					helper.setSessionParameter("action","");
					//add a new one
				} else if(action.equalsIgnoreCase("register")) {
                    ShippingRestrictionType srt = buildTypeFromRequest(helper);
                    try {
    					int addOk = IIMexServlet.iimexUsersManager.getShipmentRestrictionTypeCollection().addType(srt);
                        if(addOk > 0){
                            IIMexServlet.iimexUsersManager.updateDBstatus();
                            allTypes = IIMexServlet.iimexUsersManager.getShipmentRestrictionTypeCollection().getAllTypes();
                        }
                        helper.setSessionParameter("action","");
                        helper.setSessionParameter("code","");
                    } catch (IIMexEntityCollisionException cex) {
                        helper.setSessionParameter("action", "new");
                        helper.setSessionParameter("name", srt.getName());
                        helper.setSessionParameter("comments", srt.getComments());
                        helper.setSessionParameter("errorMsg", cex.getMessage());
                    }
                }
                else if (action.equalsIgnoreCase("new")) {
                    helper.setSessionParameter("code","");
					helper.setSessionParameter("action","new");
				} else if (action.equalsIgnoreCase("edit")) {
					helper.setSessionParameter("code", code);
					helper.setSessionParameter("action","edit");
                    // TODO: have not written UT for the following 2 lines
                    helper.setSessionParameter("name", helper.getRequestParameterValue("name"));
                    helper.setSessionParameter("comments", helper.getRequestParameterValue("comments"));
                } else if (action.equalsIgnoreCase("save")) {
                    ShippingRestrictionType srt = buildTypeFromRequest(helper);
                    try {
                        int updOk=IIMexServlet.iimexUsersManager.getShipmentRestrictionTypeCollection().updateType(srt);
                        if(updOk > 0){
                            IIMexServlet.iimexUsersManager.updateDBstatus();
                            allTypes = IIMexServlet.iimexUsersManager.getShipmentRestrictionTypeCollection().getAllTypes();
                        }
                        helper.setSessionParameter("action","");
                        helper.setSessionParameter("code","");
                    } catch (IIMexEntityCollisionException cex) {
                        helper.setSessionParameter("action", "edit");
                        helper.setSessionParameter("code", srt.getCode());
                        helper.setSessionParameter("name", srt.getName());
                        helper.setSessionParameter("comments", srt.getComments());
                        helper.setSessionParameter("errorMsg", cex.getMessage());
                    }
				}
            }

            helper.setSessionParameter("allTypes", allTypes);
            helper.redirect(helper.getContextPath() + "/admin/restrictionTypeAdmin.jsp");

        } catch (IIMexException ex) {
			Logger.log(new LoggableError("A error occurred " + "The error was: " + ex.toString()));
			ex.printStackTrace();
			IIMexMailHelper.send(ex, helper.getAuthenticatedUserFullName());
		    helper.redirect(helper.getContextPath() + "/inside/ExceptionHandler.jsp");
		}
    }

    private ShippingRestrictionType buildTypeFromRequest(UCCHelper helper) throws IOException {
        ShippingRestrictionType srt = new ShippingRestrictionType();
        srt.setCode(helper.getRequestParameterValue("code"));
        srt.setName(helper.getRequestParameterValue("name"));
        srt.setComments(helper.getRequestParameterValue("comments"));
        srt.setPublishOwnerId(helper.getAuthenticatedUserID());
        // date will be set in the insert/update
        return srt;
    }

}
