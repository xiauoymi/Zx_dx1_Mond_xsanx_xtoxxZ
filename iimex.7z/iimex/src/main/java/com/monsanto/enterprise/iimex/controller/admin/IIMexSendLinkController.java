/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;



public class IIMexSendLinkController implements UseCaseController{



	public void run(UCCHelper helper) throws IOException {

		String linkId= (helper.getSessionParameter("editLinkId")).toString();

		String linkGroupName=helper.getRequestParameterValue("link_name");

		String linkGroupDesc=helper.getRequestParameterValue("link_desc");

		String msg="";

		boolean updateOk=false;

		try{

		if(linkId.equalsIgnoreCase("0")){

				updateOk= IIMexServlet.iimexUsersManager.getLinks().insertLink(linkGroupName, linkGroupDesc);

				if(updateOk){

					msg="The new link group "+linkGroupName+" has been created";

					IIMexServlet.iimexUsersManager.updateDBstatus();

				}else{

				 msg=" Link "+linkGroupName+" has not been created please try again or contact the support";

				}

				msg="The new link group "+linkGroupName+" has been created";

		}else{

			

				updateOk=IIMexServlet.iimexUsersManager.getLinks().updateLink(linkId, linkGroupName, linkGroupDesc);

				if(updateOk){

				msg="The link group "+linkGroupName+ " has been updated";

				IIMexServlet.iimexUsersManager.updateDBstatus();

			}else{

			 msg=" Link "+linkGroupName+" has not been updated please try again or contact the support";

			}

		}

		}catch (IIMexException ex){

			Logger.log(new LoggableError("A error occured  update link " + ex.toString()));

	        ex.printStackTrace();

	        IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

			helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

		helper.setSessionParameter("msg", msg);

		helper.redirect(helper.getContextPath()+"/inside/IIMEX_maintenance_index.jsp");

	}



}

