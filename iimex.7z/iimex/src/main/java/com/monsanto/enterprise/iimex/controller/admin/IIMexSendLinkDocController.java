/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import java.util.ArrayList;



import com.ctc.wstx.util.StringUtil;

import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;



public class IIMexSendLinkDocController implements UseCaseController{



	public void run(UCCHelper helper) throws IOException {

		String linkId = (helper.getSessionParameter("linkId")).toString();

		String urlId ="0";

		String docId="0";

		//if(!StringUtils.isNullOrEmpty((helper.getSessionParameter("urlId")).toString())){

			urlId = (helper.getSessionParameter("urlId")).toString();

		//}

		//if(!StringUtils.isNullOrEmpty((helper.getSessionParameter("docId")).toString())){

			docId= (helper.getSessionParameter("docId")).toString();

		//}

		String linkOrDocGroupName=helper.getRequestParameterValue("link_name");

		String linkorDocGroupDesc=helper.getRequestParameterValue("link_desc");

		String urlPath = helper.getRequestParameterValue("link_url");

		String urlDoc =helper.getRequestParameterValue("urlDoc");
		
		String isUrl = helper.getRequestParameterValue("isUrl");
		
		String newLink = helper.getRequestParameterValue("newLink");

		//String filePath =helper.getRequestParameterValue("filePath");

		String msg="";

		String userId = helper.getAuthenticatedUserID();

		ArrayList uploadedFiles =helper.getClientFiles();
		
		boolean ok=false;
		
		if(newLink!=null){
			if(StringUtils.isNullOrEmpty(urlDoc)){
			msg="you have to select a radio boutton link or document";
			} else if(uploadedFiles.size()>0 || urlDoc.compareTo("Link")==0){
			ok=true;
			}
		}else ok=true;
		 
		if(ok){
		boolean updateOk=false;

		try{

			if(!(urlId.equalsIgnoreCase("0")&&docId.equalsIgnoreCase("0"))){

				if(!urlId.equalsIgnoreCase("0")){

					// Update link

					updateOk= IIMexServlet.iimexUsersManager.getLinks().updateUrl(linkId,urlId,linkOrDocGroupName, linkorDocGroupDesc,urlPath,userId);

					if(updateOk){

						msg="The new link group "+linkOrDocGroupName+" has been updated";

						IIMexServlet.iimexUsersManager.updateDBstatus();

					}else{

					 msg=" Link "+linkOrDocGroupName+" has not been updated please try again or contact the support";

					}

				}else{


					String filePath=(String)uploadedFiles.get(0);

					// Update doc

					updateOk = IIMexServlet.iimexUsersManager.getLinks().updateDoc(linkId,docId,linkOrDocGroupName,linkorDocGroupDesc,filePath,userId);

					if(updateOk){

						msg="The new doc "+linkOrDocGroupName+" has been updated";

						IIMexServlet.iimexUsersManager.updateDBstatus();

					}else{

					 msg=" Link "+linkOrDocGroupName+" has not been updated please try again or contact the support";

					}

				}

				

			}else{

		

				//String urlDoc =helper.getRequestParameterValue("urlDoc");

				

				if(urlDoc.equalsIgnoreCase("Link")){

					if(StringUtils.isNullOrEmpty(urlPath)){

						msg="To create a new link the url has to be filled";		

					} if(StringUtils.isNullOrEmpty(linkorDocGroupDesc)){
						msg="To create a new link the description has to be filled";
					}else{
					

						// New link

							updateOk =IIMexServlet.iimexUsersManager.getLinks().createNewUrl(linkId, linkOrDocGroupName, linkorDocGroupDesc,urlPath,userId);

							if(updateOk){

								msg="The new link "+linkOrDocGroupName+" has been created";

								IIMexServlet.iimexUsersManager.updateDBstatus();

							}else{

								msg=" Link "+linkOrDocGroupName+" has not been created please try again or contact the support";

							}

					

					}

						

				}else{

					// new doc

					

					String filePath=(String)uploadedFiles.get(0);

					if(!StringUtils.isNullOrEmpty(filePath)){

						updateOk =IIMexServlet.iimexUsersManager.getLinks().createNewDoc(linkId, linkOrDocGroupName, linkorDocGroupDesc,filePath,userId);

						if(updateOk){

							msg="The new Document "+linkOrDocGroupName+" has been created";

							IIMexServlet.iimexUsersManager.updateDBstatus();

						}else{

							msg=" Link "+linkOrDocGroupName+" has not been created please try again or contact the support";

						}


					}

				

				}

			}

		

			}catch (IIMexException ex){

				Logger.log(new LoggableError("A error occured  update link " + ex.toString()));

		        ex.printStackTrace();

		        IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

				helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			  

			

	}

			finally{

				   helper.deleteScratchFolder();

			  }
		}else{
			msg=" You have to specify the path of the document "+linkOrDocGroupName;
		}
			helper.setSessionParameter("msg", msg);

			helper.redirect(helper.getContextPath()+"/inside/IIMEX_maintenance_index.jsp");

	

	}



	}

