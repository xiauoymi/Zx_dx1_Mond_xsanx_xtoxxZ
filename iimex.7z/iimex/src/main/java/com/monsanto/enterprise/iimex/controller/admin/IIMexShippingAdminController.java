

package com.monsanto.enterprise.iimex.controller.admin;



import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.collections.IIMexEntityCollisionException;
import com.monsanto.enterprise.iimex.elements.ShippingInstruction;

import java.io.IOException;
import java.util.Vector;



public class IIMexShippingAdminController implements UseCaseController{

//interface to manage the shipping instructions

	public void run(UCCHelper helper) throws IOException {

		  try {
              helper.setSessionParameter("errorMsg", null);
			  String countryCode = helper.getRequestParameterValue("countryCode");
			  Vector Instructions = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode).getInstructions();
			  String action ="";
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  action = helper.getRequestParameterValue("action");
				  int addOk=-1;
				  //delete an existing one 
				  if((action.compareTo("delete")==0)){
					  String division = helper.getRequestParameterValue("division");
                      helper.setSessionParameter("action", "");
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().removeInstruction(countryCode,division);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							Instructions = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode).getInstructions();
					  }
				  }else if((action.compareTo("new")==0)){
                      helper.setSessionParameter("action", "new");
					  helper.setSessionParameter("allDiv", IIMexServlet.iimexUsersManager.getDivisionCollection().getAllDivision());
					  //add a new one
				  }else if((action.compareTo("save")==0)){
                      helper.setSessionParameter("action", "");
					  helper.setSessionParameter("division", "");
                      ShippingInstruction instruction = buildInstructionFromRequest(helper);
                      try {
                          addOk=IIMexServlet.iimexUsersManager.getCountryCollection().addInstruction(instruction,countryCode);
                          if(addOk>0){
                                IIMexServlet.iimexUsersManager.updateDBstatus();
                                Instructions = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode).getInstructions();
                          }
                      } catch (IIMexEntityCollisionException cex) {
                          helper.setSessionParameter("action", "new");
                          helper.setSessionParameter("division", helper.getRequestParameterValue("division"));
                          helper.setSessionParameter("seedSamples", instruction.getSeedSamples());
                          helper.setSessionParameter("seedTreatment", instruction.getSeedTreatment());
                          helper.setSessionParameter("shippingInstructions", instruction.getShippingInstructions());
                          helper.setSessionParameter("miscallenous", instruction.getMiscallenous());
                          helper.setSessionParameter("packaging", instruction.getPackaging());
                          helper.setSessionParameter("errorMsg", cex.getMessage());
                      }

				  }else if((action.compareTo("edit")==0)){
                      helper.setSessionParameter("action", "edit");
					  helper.setSessionParameter("division", helper.getRequestParameterValue("division"));
					  //save an edited one
				  }else if((action.compareTo("register")==0)){
                      helper.setSessionParameter("action", "");
					  helper.setSessionParameter("division", "");
                      ShippingInstruction instruction = buildInstructionFromRequest(helper);
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().updateInstruction(instruction,countryCode);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							Instructions = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode).getInstructions();
					  }
					  
				  }
			  }
			  helper.setSessionParameter("countryCode", countryCode);
			  helper.setSessionParameter("name", IIMexServlet.iimexUsersManager.getCountryCollection().getCountryName(countryCode));
			  helper.setSessionParameter("instructions", Instructions);
			 
			  helper.redirect(helper.getContextPath()+"/admin/shippingAdmin.jsp");

			}  catch (IIMexException ex) {
				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));
			  	ex.printStackTrace();
			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());
		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");
			}

	}

    private ShippingInstruction buildInstructionFromRequest(UCCHelper helper) throws IOException {
        ShippingInstruction instruction = new ShippingInstruction();
        instruction.setDivision(helper.getRequestParameterValue("division"));
        instruction.setSeedSamples(helper.getRequestParameterValue("seedSamples"));
        instruction.setSeedTreatment(helper.getRequestParameterValue("seedTreatment"));
        instruction.setShippingInstructions(helper.getRequestParameterValue("shippingInstructions"));
        instruction.setMiscallenous(helper.getRequestParameterValue("miscallenous"));
        instruction.setPackaging(helper.getRequestParameterValue("packaging"));
        instruction.setOwner(helper.getAuthenticatedUserID());
        return instruction;
    }
}
			  