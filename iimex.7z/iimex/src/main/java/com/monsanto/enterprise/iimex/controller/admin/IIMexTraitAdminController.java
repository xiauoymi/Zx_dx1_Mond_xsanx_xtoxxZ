

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Collection;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.Trait;



public class IIMexTraitAdminController implements UseCaseController{

//manage traits

	public void run(UCCHelper helper) throws IOException {

		  try {
			  String group = helper.getRequestParameterValue("codeProduct");
			  Collection ListTrait = IIMexServlet.iimexUsersManager.getTraitCollection().getAllTraitByGroup(group);
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  String codeTrait = helper.getRequestParameterValue("codeTrait");
				  int addOk=-1;				  
				  //delete a trait
				  if((action.compareTo("delete")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getTraitCollection().removeTrait(codeTrait);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							ListTrait = IIMexServlet.iimexUsersManager.getTraitCollection().getAllTraitByGroup(group);
					  }
					  helper.setSessionParameter("codeTrait","");
					  helper.setSessionParameter("action","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("codeTrait","");
					  helper.setSessionParameter("action","new");
					  helper.setSessionParameter("allProductGroup",IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup());
					  //add a new trait to the table
				  }else if((action.compareTo("save")==0)){
					  String code = helper.getRequestParameterValue("codeTrait");
					  String name = helper.getRequestParameterValue("traitName");
					  String monNumber = helper.getRequestParameterValue("monNumber");
					  String productCode = helper.getRequestParameterValue("codeProductGroup");
					  String oecd = helper.getRequestParameterValue("oecd");
					  String office = helper.getRequestParameterValue("office");
					  String owner = helper.getAuthenticatedUserID();
					  
					  Trait tr = new Trait();
					  tr.setTraitCode(code);
					  tr.setTraitName(name);
					  tr.setMonNumber(monNumber);
					  tr.setProductGroupCode(productCode);
					  tr.setOECDIdentifier(oecd);
					  tr.setLabOfficeCode(office);
					  tr.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getTraitCollection().addTrait(tr);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						ListTrait = IIMexServlet.iimexUsersManager.getTraitCollection().getAllTraitByGroup(group);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("codeTrait","");
				  }
				  
			  }
			  
			  helper.setSessionParameter("codeProduct", group);
			  helper.setSessionParameter("allTrait", ListTrait);
			  helper.redirect(helper.getContextPath()+"/admin/traitAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  