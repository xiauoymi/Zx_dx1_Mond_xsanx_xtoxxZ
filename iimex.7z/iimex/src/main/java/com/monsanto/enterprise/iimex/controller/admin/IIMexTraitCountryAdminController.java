

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Collection;
import java.util.Vector;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.Trait;



public class IIMexTraitCountryAdminController implements UseCaseController{

//interface for trait country

	public void run(UCCHelper helper) throws IOException {

		  try {
			  ;
			  Trait tr = IIMexServlet.iimexUsersManager.getTraitCollection().getTrait(helper.getRequestParameterValue("codeTrait"));
			  Vector allApproved = tr.getApprovedVector();
			  Vector allCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry();
			  
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  int addOk=-1;			
				  //delete one
				  if((action.compareTo("delete")==0)){
					  String destination = helper.getRequestParameterValue("destination");
					  addOk=IIMexServlet.iimexUsersManager.getTraitCollection().removeTraitCountry(tr.getTraitCode(), destination);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							tr = IIMexServlet.iimexUsersManager.getTraitCollection().getTrait(helper.getRequestParameterValue("codeTrait"));
							allApproved = tr.getApprovedVector();
							allCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry();
					  }
					  helper.setSessionParameter("destination","");
					  helper.setSessionParameter("action","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("action","new");
					  //save a new one
				  }else if((action.compareTo("save")==0)){
					  String code = helper.getRequestParameterValue("codeTrait");
					  String destination = helper.getRequestParameterValue("destination");
					  String prod = helper.getRequestParameterValue("prod");
					  String imp = helper.getRequestParameterValue("imp");
					  String food = helper.getRequestParameterValue("food");
					  String owner = helper.getAuthenticatedUserID();
					  
					  addOk=IIMexServlet.iimexUsersManager.getTraitCollection().addTraitCountry(code, destination, prod, imp,food, owner);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						tr = IIMexServlet.iimexUsersManager.getTraitCollection().getTrait(helper.getRequestParameterValue("codeTrait"));
						allApproved = tr.getApprovedVector();
						allCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry();
					  }
					  helper.setSessionParameter("destination","");
					  helper.setSessionParameter("action","");
				  }else if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("destination",helper.getRequestParameterValue("destination"));
					  //save mondificatio on an exiting one
				  }else if((action.compareTo("register")==0)){
					  String code = helper.getRequestParameterValue("codeTrait");
					  String destination = helper.getRequestParameterValue("destination");
					  String prod = helper.getRequestParameterValue("prod");
					  String imp = helper.getRequestParameterValue("imp");
					  String food = helper.getRequestParameterValue("food");
					  String owner = helper.getAuthenticatedUserID();
					  
					  addOk=IIMexServlet.iimexUsersManager.getTraitCollection().updateTraitCountry(code, destination, prod, imp, food, owner);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						tr = IIMexServlet.iimexUsersManager.getTraitCollection().getTrait(helper.getRequestParameterValue("codeTrait"));
						allApproved = tr.getApprovedVector();
						allCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry();
					  }
					  helper.setSessionParameter("destination","");
					  helper.setSessionParameter("action","");
				  }else if((action.compareTo("update")==0)){
					  String code = helper.getRequestParameterValue("codeTrait");
					  String name = helper.getRequestParameterValue("name");
					  String monNumber = helper.getRequestParameterValue("monNumber");
					  String oecd = helper.getRequestParameterValue("oecd");
					  String office = helper.getRequestParameterValue("office");
					  String owner = helper.getAuthenticatedUserID();
					  
					  Trait trait = new Trait();
					  trait.setTraitCode(code);
					  trait.setTraitName(name);
					  trait.setMonNumber(monNumber);
					  trait.setOECDIdentifier(oecd);
					  trait.setLabOfficeCode(office);
					  trait.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getTraitCollection().updateTrait(trait);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						tr = IIMexServlet.iimexUsersManager.getTraitCollection().getTrait(helper.getRequestParameterValue("codeTrait"));
						allApproved = tr.getApprovedVector();
						allCountry = IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry();
					  }
					  helper.setSessionParameter("destination","");
					  helper.setSessionParameter("action","");
				  }else if((action.compareTo("change")==0)){
					  helper.setSessionParameter("action","change");
					  helper.setSessionParameter("destination","");
				  }
				  
			  }
			  
			  helper.setSessionParameter("trait", tr);
			  helper.setSessionParameter("allApproved", allApproved);
			  helper.setSessionParameter("allCountry", allCountry);
			  helper.setSessionParameter("colCountry", IIMexServlet.iimexUsersManager.getCountryCollection());
			  helper.redirect(helper.getContextPath()+"/admin/traitCountryAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  