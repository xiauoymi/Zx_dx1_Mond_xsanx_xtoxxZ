

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Vector;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.CompanyDetermination;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.ImportLicenseApproval;
import com.monsanto.enterprise.iimex.elements.orderType;



public class IIMexTransactionAdminController implements UseCaseController{

//interface for transaction type

	public void run(UCCHelper helper) throws IOException {

		  try {

			  String countryCode = helper.getRequestParameterValue("countryCode");
			  Country country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
			  Vector allTransaction = IIMexServlet.iimexUsersManager.getOrderTypeCollection().getOrderTypeVector(country.getCompanyDeterminationVector());
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  int addOk=-1;
				  //delete an input	  
				  if((action.compareTo("delete")==0)){
					  String destination = helper.getRequestParameterValue("destination");
					  String shipping = helper.getRequestParameterValue("shipping");
					  orderType ot = new orderType();
					  ot.setDestination(destination);
					  addOk=IIMexServlet.iimexUsersManager.getOrderTypeCollection().removeOrder(ot, shipping);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
							allTransaction = IIMexServlet.iimexUsersManager.getOrderTypeCollection().getOrderTypeVector(country.getCompanyDeterminationVector());
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("destination","");
					  helper.setSessionParameter("shipping","");
				  }else if((action.compareTo("edit")==0)){
					  String destination = helper.getRequestParameterValue("destination");
					  String shipping = helper.getRequestParameterValue("shipping");
					  helper.setSessionParameter("destination",destination);
					  helper.setSessionParameter("shipping",shipping);
					  helper.setSessionParameter("action","edit");
					  //save an edited one
				  }else if((action.compareTo("register")==0)){
					  String destination = helper.getRequestParameterValue("destination");
					  String shipping = helper.getRequestParameterValue("shipping");
					  String purchase = helper.getRequestParameterValue("purchase");
					  String sales = helper.getRequestParameterValue("sales");	
					  orderType ot = new orderType();
					  ot.setDestination(destination);
					  ot.setPurchaseOrderType(purchase);
					  ot.setSalesOrderType(sales);
					  ot.setPublishOwner( helper.getAuthenticatedUserID());
					  
					  addOk=IIMexServlet.iimexUsersManager.getOrderTypeCollection().updateOrder(ot, shipping);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
						allTransaction = IIMexServlet.iimexUsersManager.getOrderTypeCollection().getOrderTypeVector(country.getCompanyDeterminationVector());
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("destination","");
					  helper.setSessionParameter("shipping","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("destination","");
					  helper.setSessionParameter("shipping","");
					  helper.setSessionParameter("type",helper.getRequestParameterValue("type"));
					  helper.setSessionParameter("countryComp",country.getCompanyDeterminationVector());
					  helper.setSessionParameter("allComp",IIMexServlet.iimexUsersManager.getCompaniesCollection().getAllCompanyOrdered());
					  helper.setSessionParameter("action","new");
					  //save a new one
				  }else if((action.compareTo("save")==0)){
					  String destination = helper.getRequestParameterValue("destination");
					  String shipping = helper.getRequestParameterValue("shipping");
					  String purchase = helper.getRequestParameterValue("purchase");
					  String sales = helper.getRequestParameterValue("sales");	
					  orderType ot = new orderType();
					  ot.setDestination(destination);
					  ot.setPurchaseOrderType(purchase);
					  ot.setSalesOrderType(sales);
					  ot.setPublishOwner( helper.getAuthenticatedUserID());
					  addOk=IIMexServlet.iimexUsersManager.getOrderTypeCollection().addOrder(ot, shipping);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						country = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(countryCode);
						allTransaction = IIMexServlet.iimexUsersManager.getOrderTypeCollection().getOrderTypeVector(country.getCompanyDeterminationVector());
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("destination","");
					  helper.setSessionParameter("shipping","");
				  }
				  
			  }
			  helper.setSessionParameter("countryCode", countryCode);
			  helper.setSessionParameter("allTransaction", allTransaction);
			  helper.redirect(helper.getContextPath()+"/admin/transactionAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  