

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Vector;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.IncotermTransportInfo;



public class IIMexTransportModeAdminController implements UseCaseController{
//admin interface for transport modes
	public void run(UCCHelper helper) throws IOException {

		  try {

			  Vector allTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList();
			  allTransport.addAll(IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewTransportList());
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  String code = helper.getRequestParameterValue("code");
				  int addOk=-1;				  
				  //delete one
				  if((action.compareTo("delete")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().removeTransportMode(code);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							allTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList();
							allTransport.addAll(IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewTransportList());
					  }
					  helper.setSessionParameter("code","");
					  helper.setSessionParameter("action","");
					  //save a new one
				  }else if((action.compareTo("register")==0)){
					  code = helper.getRequestParameterValue("code");
					  String name = helper.getRequestParameterValue("name");
					  String owner = helper.getAuthenticatedUserID();
					  
					  IncotermTransportInfo inco = new IncotermTransportInfo(); 
					  inco.setTransportCode(code);
					  inco.setTransportName(name);
					  inco.setPublishOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().addTransportMode(inco);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList();
						allTransport.addAll(IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewTransportList());
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("code","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("code","");
					  helper.setSessionParameter("action","new");
				  }
				  
			  }
			  
			  helper.setSessionParameter("allTransport", allTransport);
			  helper.redirect(helper.getContextPath()+"/admin/transportModeAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  
