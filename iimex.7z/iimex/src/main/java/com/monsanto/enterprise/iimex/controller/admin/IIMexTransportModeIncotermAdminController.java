

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.collections.WorldAreaCollection;
import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.IncotermTransportInfo;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;
import com.monsanto.enterprise.iimex.elements.WorldArea;
import com.monsanto.enterprise.iimex.elements.customZone;



public class IIMexTransportModeIncotermAdminController implements UseCaseController{
//admin interface for the transport mode incoterm data
	public void run(UCCHelper helper) throws IOException {

		  try {

			  String codeTp = helper.getRequestParameterValue("codeTp");
			  IncotermTransportInfo transport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransport(codeTp);
			  Vector allIncotermTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportModeIncoterm(codeTp);
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  
				  int addOk=-1;				
				  //remove one
				  if((action.compareTo("delete")==0)){
					  String codeInc = helper.getRequestParameterValue("codeInc");
					  IncotermTransportInfo inco = new IncotermTransportInfo(); 
					  inco.setTransportCode(codeTp);
					  inco.setSIncotermsCode(codeInc);
					  addOk=IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().removeTransportModeIncoterm(inco);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							allIncotermTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportModeIncoterm(codeTp);
					  }
					  helper.setSessionParameter("codeTp","");
					  helper.setSessionParameter("codeInc","");
					  helper.setSessionParameter("action","");
					  //register a new one
				  }else if((action.compareTo("register")==0)){
					  String codeInc = helper.getRequestParameterValue("codeInc");
					  IncotermTransportInfo inco = new IncotermTransportInfo(); 
					  inco.setTransportCode(codeTp);
					  inco.setSIncotermsCode(codeInc);
					  inco.setPublishOwner(helper.getAuthenticatedUserID());
					  
					  addOk=IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().addTransportModeIncoterm(inco);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allIncotermTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportModeIncoterm(codeTp);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("codeTp","");
					  helper.setSessionParameter("codeInc","");
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("codeTp","");
					  helper.setSessionParameter("codeInc","");
					  helper.setSessionParameter("action","new");
					  helper.setSessionParameter("newIncoterm",IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getNewIncoterm(codeTp));
				  }
				  
			  }
			  
			  helper.setSessionParameter("transport", transport);
			  helper.setSessionParameter("allIncotermTransport", allIncotermTransport);
			  helper.setSessionParameter("size",allIncotermTransport.size());
			  helper.redirect(helper.getContextPath()+"/admin/transportModeIncotermAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  
