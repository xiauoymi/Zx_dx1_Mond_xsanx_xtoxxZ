

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Vector;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.TransportationTime;



public class IIMexTransportationTimeAdminController implements UseCaseController{


//admin interface for transportation time
	public void run(UCCHelper helper) throws IOException {

		  try {

			  String countryCode = helper.getRequestParameterValue("countryCode");
			  String name = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryName(countryCode);
			  Vector allTranspTime = IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getTranspTimeByCode(countryCode);
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  int addOk=-1;
				  					  //remove one
				  if((action.compareTo("delete")==0)){
					  String tpMode = helper.getRequestParameterValue("tpMode");
					  String countryCode2 = helper.getRequestParameterValue("countryCode2");
					  TransportationTime tmp = new TransportationTime();
					  tmp.setDestCountryCode(countryCode2);
					  tmp.setTpModeCode(tpMode);
					  addOk=IIMexServlet.iimexUsersManager.getCountryToCountryCollection().removeTransportationTime(tmp, countryCode);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							allTranspTime = IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getTranspTimeByCode(countryCode);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("countryCode2","");
					  helper.setSessionParameter("tpMode","");
				  }else if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("countryCode2",helper.getRequestParameterValue("countryCode2"));
					  helper.setSessionParameter("tpMode",helper.getRequestParameterValue("tpMode"));
					  helper.setSessionParameter("action","edit");
					  //save an edited one
				  }else if((action.compareTo("register")==0)){
					  String tpMode = helper.getRequestParameterValue("tpMode");
					  String countryCode2 = helper.getRequestParameterValue("countryCode2");
					  TransportationTime tp = new TransportationTime();
					  tp.setDestCountryCode(countryCode2);
					  tp.setTpModeCode(tpMode);
					  tp.setFreightBooking(helper.getRequestParameterValue("freight"));
					  tp.setTransportationTime(helper.getRequestParameterValue("tpTime"));
					  tp.setPublishOwner( helper.getAuthenticatedUserID());
					  
					  addOk=IIMexServlet.iimexUsersManager.getCountryToCountryCollection().updateTransportationTime(tp, countryCode);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();

						allTranspTime = IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getTranspTimeByCode(countryCode);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("countryCode2","");
					  helper.setSessionParameter("tpMode","");;
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("countryCode2","");
					  helper.setSessionParameter("tpMode","");
					  helper.setSessionParameter("action","new");
					  helper.setSessionParameter("allTpMode",IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getTransportList());
					  helper.setSessionParameter("allDest",IIMexServlet.iimexUsersManager.getCountryCollection().getAllActiveCountry());
					  //save a new one
				  }else if((action.compareTo("save")==0)){
					  String tpMode = helper.getRequestParameterValue("tpMode");
					  String countryCode2 = helper.getRequestParameterValue("countryCode2");
					  TransportationTime tp = new TransportationTime();
					  tp.setDestCountryCode(countryCode2);
					  tp.setTpModeCode(tpMode);
					  tp.setFreightBooking(helper.getRequestParameterValue("freight"));
					  tp.setTransportationTime(helper.getRequestParameterValue("tpTime"));
					  tp.setPublishOwner( helper.getAuthenticatedUserID());
					  
					  addOk=IIMexServlet.iimexUsersManager.getCountryToCountryCollection().addTransportationTime(tp, countryCode);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						allTranspTime = IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getTranspTimeByCode(countryCode);
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("countryCode2","");
					  helper.setSessionParameter("division","");
				  }
				  
			  }
			  helper.setSessionParameter("countryCode", countryCode);
			  helper.setSessionParameter("name", IIMexServlet.iimexUsersManager.getCountryCollection().getCountryName(countryCode));
			  helper.setSessionParameter("name", name);
			  helper.setSessionParameter("allTranspTime", allTranspTime);
			  helper.redirect(helper.getContextPath()+"/admin/tpTimeAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  