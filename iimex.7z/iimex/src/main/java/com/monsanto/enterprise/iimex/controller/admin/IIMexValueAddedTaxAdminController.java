/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;

import java.util.Collection;

import java.util.List;

import java.util.Vector;



import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.AbstractLogging.Logger;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.ServletFramework.UseCaseController;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.IIMexMailHelper;

import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;

import com.monsanto.enterprise.iimex.elements.ClearanceFee;
import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.Documents;
import com.monsanto.enterprise.iimex.elements.IncotermTransportInfo;
import com.monsanto.enterprise.iimex.elements.ValueAddedTax;



public class IIMexValueAddedTaxAdminController implements UseCaseController{

//Administrators use this page to manage the taxes

	public void run(UCCHelper helper) throws IOException {

		  try {

			  String code = helper.getRequestParameterValue("code");
			  Collection allvalues = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(code).getValueAddedTaxVector();
			  
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  if((action.compareTo("edit")==0)){
					  helper.setSessionParameter("codePg", helper.getRequestParameterValue("codePg"));
					  helper.setSessionParameter("action", "");
					  //save an edited tax
				  }else if((action.compareTo("save")==0)){
					  String codePg = helper.getRequestParameterValue("codePg");
					  String value = helper.getRequestParameterValue("value");
					  String owner = helper.getAuthenticatedUserID();
					  
					  ValueAddedTax tmp = new ValueAddedTax();
					  
					  tmp.setGroup(codePg);
					  tmp.setValue(value);
					  tmp.setOwner(owner);
					  
					  int addOk=-1;
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().updateTax(tmp, code);
					  if(addOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
						  allvalues = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(code).getValueAddedTaxVector();
					}
					  helper.setSessionParameter("action", "");
					  helper.setSessionParameter("codePg", "");
				  } else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("allGroup", IIMexServlet.iimexUsersManager.getProducts().getAllProductGroup());
					  helper.setSessionParameter("action", "new");
					  //register a new tax
				  } else if((action.compareTo("register")==0)){
					  String codePg = helper.getRequestParameterValue("codePg");
					  String value = helper.getRequestParameterValue("value");
					  String owner = helper.getAuthenticatedUserID();
					  
					  ValueAddedTax tmp = new ValueAddedTax();
					  
					  tmp.setGroup(codePg);
					  tmp.setValue(value);
					  tmp.setOwner(owner);
					  
					  int addOk=-1;
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().addTax(tmp, code);
					  if(addOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
						  allvalues = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(code).getValueAddedTaxVector();
					}
					  helper.setSessionParameter("action", "");
					  helper.setSessionParameter("codePg", "");
					  //delete a tax
				  } else if((action.compareTo("delete")==0)){
					  String codePg = helper.getRequestParameterValue("codePg");
					  
					  int addOk=-1;
					  addOk=IIMexServlet.iimexUsersManager.getCountryCollection().removeTax(code,codePg);
					  if(addOk>0){
						  IIMexServlet.iimexUsersManager.updateDBstatus();
						  allvalues = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(code).getValueAddedTaxVector();
					}
					  helper.setSessionParameter("action", "");
					  helper.setSessionParameter("codePg", "");
				  }
			  }
			  helper.setSessionParameter("name", helper.getRequestParameterValue("name"));
			  helper.setSessionParameter("code", code);
			  helper.setSessionParameter("allvalues", allvalues);
			  helper.redirect(helper.getContextPath()+"/admin/valueAddedTaxAdmin.jsp");

		}  catch (IIMexException ex) {

			Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

		  	ex.printStackTrace();

		  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}

	}


}



