

package com.monsanto.enterprise.iimex.controller.admin;



import java.io.IOException;
import java.util.Collection;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.WorldArea;



public class IIMexWorldAreaAdminController implements UseCaseController{

//this controller manage the page where administrators manage the world area

	public void run(UCCHelper helper) throws IOException {

		  try {
			  //load the data
			  Collection ListWorldArea = IIMexServlet.iimexUsersManager.getWorldAreaCollection().getAllAreas();
			  if(!StringUtils.isNullOrEmpty(helper.getRequestParameterValue("action"))){
				  String action = helper.getRequestParameterValue("action");
				  String code = helper.getRequestParameterValue("code");
				  int addOk=-1;
				  					  
				  if((action.compareTo("delete")==0)){
					  addOk=IIMexServlet.iimexUsersManager.getWorldAreaCollection().removeArea(code);
					  if(addOk>0){
							IIMexServlet.iimexUsersManager.updateDBstatus();
							ListWorldArea = IIMexServlet.iimexUsersManager.getWorldAreaCollection().getAllAreas();
					  }
					  helper.setSessionParameter("code","");
					  helper.setSessionParameter("action","");
					  //the user wants to edit an existing world area
				  }else if((action.compareTo("edit")==0)){
					 helper.setSessionParameter("code",code);
					 helper.setSessionParameter("action","edit");
					 //the user wants to register a new area
				  }else if((action.compareTo("register")==0)){
					  code = helper.getRequestParameterValue("code");
					  String name = helper.getRequestParameterValue("name");
					  String owner = helper.getAuthenticatedUserID();
					  
					  WorldArea wa = new WorldArea();
					  wa.setAreaCode(code);
					  wa.setAreaName(name);
					  wa.setPublisOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getWorldAreaCollection().addArea(wa);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						ListWorldArea = IIMexServlet.iimexUsersManager.getWorldAreaCollection().getAllAreas();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("code","");
					  //the user wants to add a world area
				  }else if((action.compareTo("new")==0)){
					  helper.setSessionParameter("code","");
					  helper.setSessionParameter("action","new");
					  //the user wants to save some modifications on a world area
				  }else if((action.compareTo("save")==0)){
					  code = helper.getRequestParameterValue("code");
					  String name = helper.getRequestParameterValue("name");
					  String owner = helper.getAuthenticatedUserID();
					  
					  WorldArea wa = new WorldArea();
					  wa.setAreaCode(code);
					  wa.setAreaName(name);
					  wa.setPublisOwner(owner);
					  
					  addOk=IIMexServlet.iimexUsersManager.getWorldAreaCollection().updateArea(wa);
					  if(addOk>0){
						IIMexServlet.iimexUsersManager.updateDBstatus();
						ListWorldArea = IIMexServlet.iimexUsersManager.getWorldAreaCollection().getAllAreas();
					  }
					  helper.setSessionParameter("action","");
					  helper.setSessionParameter("code","");
				  }
				  
			  }
			  
			  helper.setSessionParameter("allArea", ListWorldArea);
			  helper.redirect(helper.getContextPath()+"/admin/worldAreaAdmin.jsp");

			}  catch (IIMexException ex) {

				Logger.log(new LoggableError("A error occured " + "The error was: " + ex.toString()));

			  	ex.printStackTrace();

			  	IIMexMailHelper.send(ex,helper.getAuthenticatedUserFullName());

		        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

			}

	}
}
			  