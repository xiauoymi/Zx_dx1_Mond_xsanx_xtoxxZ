package com.monsanto.enterprise.iimex.controller.utils;

import java.io.IOException;
import java.util.ArrayList;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.enterprise.iimex.IIMexMailHelper;

public class IIMexContactController implements UseCaseController{
 
	
	public void run (UCCHelper helper) throws IOException{
		try{
			String msg = (String)helper.getRequestParameterValue("message");
			if(msg!=null){
				ArrayList l = new ArrayList();
				l.add("support.manufacturing@monsanto.com");
				IIMexMailHelper.sendMail("", msg, l);
			}
			
		}catch (Exception ex2){
			Logger.log(new LoggableError("A error occured " + "The error was: " + ex2.toString()));
		  	ex2.printStackTrace();
		  	IIMexMailHelper.send(ex2,helper.getAuthenticatedUserFullName());
	        helper.redirect(helper.getContextPath()+"/inside/ExceptionHandler.jsp");

		}
		helper.redirect(helper.getContextPath());
	}
 
}