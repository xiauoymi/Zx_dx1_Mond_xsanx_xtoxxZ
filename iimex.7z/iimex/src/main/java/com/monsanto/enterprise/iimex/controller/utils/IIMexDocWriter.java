/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.controller.utils;



import java.io.BufferedInputStream;

import java.io.FileInputStream;

import java.io.InputStream;

import java.io.OutputStream;

import java.util.ResourceBundle;



import com.monsanto.ServletFramework.FormattedWriter;

import com.monsanto.ServletFramework.UCCHelper;

import com.monsanto.Util.FileUtil;

import com.monsanto.enterprise.iimex.elements.DocLink;





public class IIMexDocWriter implements FormattedWriter 

{

    

    

    private BufferedInputStream docInput;

    private UCCHelper helper;

    private String fileName;

    

    

    public IIMexDocWriter(String fileName,UCCHelper helper,BufferedInputStream docInput)

    {

        this.helper 	= helper;

        this.fileName  =fileName;

        this.docInput =docInput;

    }

    /**

     * Copy the inputFile in the outputStream. The content type is get from the

     * MymeType properties file.

     */

    public void write(OutputStream outputStream)

    {

    	 try {

         	ResourceBundle types = ResourceBundle.getBundle("com.monsanto.enterprise.iimex.Servlet.MimeTypes");

         	int index = fileName.lastIndexOf(".");

         	String ext="txt";

         	if(index>=0){

         		ext=fileName.substring(index+1);

         	}

         	

         

         	helper.setContentType(types.getString(ext));

             helper.setHeader("Content-Disposition","attachment; filename=" + fileName);

            FileUtil.copyFile(docInput, outputStream);

             docInput.close();

           

         }catch(Exception e)

        {

            e.printStackTrace();

        }      

        



    }



}



