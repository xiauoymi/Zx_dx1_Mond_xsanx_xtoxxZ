package com.monsanto.enterprise.iimex.controller.utils;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.ServletFramework.UseCaseController;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexMailHelper;
import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.DocumentConditions;
import com.monsanto.enterprise.iimex.elements.PhytoRequirement;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;
import com.monsanto.enterprise.iimex.elements.userselection.Result;
import com.monsanto.pdf.PDFFormattedWriter;

public class IIMexPdfWriterController implements UseCaseController {

    /**
     * This method is used to store the result of the user's search in a string in a xml format
     * so that it can be provided to a PDF printer. the xml value are used in a xsl sytle sheet
     * to construct the tables and to set the pdf style
     */
    public void run(UCCHelper helper) throws IOException {
        try {
            String page = "";

            Result res = (Result) helper.getSessionParameter("result");

            String tmp = " ";
            page += "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?> \n <!DOCTYPE page [ <!ELEMENT page (title|subtitle|line|table|prefix|data|header)*>" +
                    "<!ELEMENT title    (#PCDATA)>" +
                    "<!ELEMENT subtitle (#PCDATA)>" +
                    "<!ELEMENT line    (#PCDATA|prefix)*>" +
                    "<!ELEMENT header    (user|date)*>" +
                    "<!ELEMENT user 	(#PCDATA)>" +
                    "<!ELEMENT date 	(#PCDATA)>" +
                    "<!ELEMENT prefix 	(#PCDATA)>" +
                    "<!ELEMENT data 	(#PCDATA)>" +
                    "<!ELEMENT table    (colName|row|cell)*>" +
                    "<!ELEMENT colName  (#PCDATA)>" +
                    "<!ELEMENT row    	(#PCDATA)>" +
                    "<!ELEMENT cell    	(#PCDATA)>" +

                    "]> \n <page>";
            page += "<header><user>" + helper.getAuthenticatedUserFullName() + "</user>";
            TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
            Locale loc = Locale.FRANCE;
            Calendar cal = Calendar.getInstance(tz, loc);
            page += "<date>" + cal.getTime().toString() + "</date></header>";
            page += "<superTitle> IIMEX Import Export Database </superTitle>";
            page += "<line><prefix>Shipping Country:</prefix>";
            if (!StringUtils.isNullOrEmpty(res.getShipping().getCountryName()))
                tmp = res.getShipping().getCountryName();
            page += tmp;
            tmp = " ";
            page += "<prefix2> Destination Country: </prefix2>";
            if (!StringUtils.isNullOrEmpty(res.getDestination().getCountryName()))
                tmp = res.getDestination().getCountryName();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix>Country of product origin: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getOrigin().getCountryName()))
                tmp = res.getOrigin().getCountryName();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix>Transport Mode: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getIncotermInfo().getTransportName()))
                tmp = res.getIncotermInfo().getTransportName();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix>Incoterm: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getIncotermInfo().getSIncotermDescr()))
                tmp = res.getIncotermInfo().getSIncotermDescr();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix>Product Line: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getDivision().getDivisionName()))
                tmp = res.getDivision().getDivisionName();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix>Product Group: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getProductGroup().getProductGroupName()))
                tmp = res.getProductGroup().getProductGroupName();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix>Trait: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getTrait().getMonNumber()))
                tmp = res.getTrait().getMonNumber();
            page += tmp + "</line>";
            tmp = " ";

            page += "<title>Restrictions</title>";
            page += "<line><prefix>This shipment is: </prefix>";
            page += res.getShippingRestriction().getRestrictionName() + "</line>";
            page += "<line><prefix>Restriction Type Definition: </prefix>";
            tmp = res.getAllowed();
            page += res.getShippingRestriction().getRestrictionComments() + "</line>";
            if (!StringUtils.isNullOrEmpty(res.getShippingRestriction().getComments())) {
                page += "<line><prefix>Shipment restriction comment: </prefix>";
                tmp = res.getAllowed();
                page += res.getShippingRestriction().getComments() + "</line>";
            }

          page += "<title>MATERIAL DATA</title>";
            page += "<table5><head><colName>" + res.getTrait().getTraitName() + "</colName><colName>Last updated:" + res.getTrait().getPublishOwner() + res.getTrait().getPublishDate() + "</colName></head><body>";
            page += "<row>";
            page += "<cell>Description</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getTrait().getTraitName()))
                page += res.getTrait().getTraitName();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>OECD unique identifier</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getTrait().getOECDIdentifier()))
                page += res.getTrait().getOECDIdentifier();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Approved for Production</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getApproved().getProduction()))
                page += res.getApproved().getProduction();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Approved for Import</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getApproved().getImportation()))
                page += res.getApproved().getImportation();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Approved for Food, Feed or Environment</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getApproved().getFood()))
                page += res.getApproved().getFood();
            page += "</cell></row>";
            page += "</body></table5>";
          
            tmp = " ";

            page += "<title>Transactional data</title>";
            page += "<subtitle>Organisational data</subtitle>";
            page += "<line><prefix>World area (ship cntry)</prefix>";
            page += res.getShipping().getWorldAreaName();
            page += "<prefix2>World area (dest cntry)</prefix2>";
            page += res.getDestination().getWorldAreaName() + "</line>";
            page += "<line><prefix>Customs zone (ship cntry)</prefix>";
            page += res.getShipping().getCustomsZoneName();
            page += "<prefix2>Customs zone (dest cntry)</prefix2>";
            page += res.getDestination().getCustomsZoneName() + "</line>";
            page += "<line><prefix>Customs zone (prod origin)</prefix>";
            page += res.getOrigin().getCustomsZoneName() + "</line>";

            page += "<subtitle>Intercompany transactions</subtitle>";
            page += "<line><prefix>Shipping Company: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getShippingCompanies().getSellingCompanyCode()))
                tmp += res.getShippingCompanies().getSellingCompanyCode();
            tmp += " - ";
            if (!StringUtils.isNullOrEmpty(res.getShippingCompanies().getSellingCompanyName()))
                tmp += res.getShippingCompanies().getSellingCompanyName();
            page += tmp;
            tmp = " ";
            page += "<prefix2>Sold To Company: </prefix2>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getSoldToCompanyCode()))
                tmp += res.getDestinationCompanies().getSoldToCompanyCode();
            tmp += " - ";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getSoldToCompanyName()))
                tmp += res.getDestinationCompanies().getSoldToCompanyName();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix>Purchase Order Type: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getOrderTypes().getPurchaseOrderType()))
                tmp = res.getOrderTypes().getPurchaseOrderType();
            page += tmp;
            tmp = " ";

            page += "<prefix2>Bill To company: </prefix2>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getBillToCompanyCode()))
                tmp += res.getDestinationCompanies().getBillToCompanyCode();
            tmp += " - ";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getBillToCompanyName()))
                tmp += res.getDestinationCompanies().getBillToCompanyName();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix>Currency: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getCurrency().getIntercoCurrency()))
                tmp = res.getCurrency().getIntercoCurrency();
            page += tmp;
            tmp = " ";

            page += "<prefix2>Ship To company: </prefix2>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getShipToCompanyCode()))
                tmp += res.getDestinationCompanies().getShipToCompanyCode();
            tmp += " - ";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getShipToCompanyName()))
                tmp += res.getDestinationCompanies().getShipToCompanyName();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix></prefix>";
            page += tmp;

            page += "<prefix2>Consign To company: </prefix2>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getConsignToCompanyCode()))
                tmp += res.getDestinationCompanies().getConsignToCompanyCode();
            tmp += " - ";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getConsignToCompanyName()))
                tmp += res.getDestinationCompanies().getConsignToCompanyName();
            page += tmp + "</line>";
            tmp = " ";

            page += "<subtitle>Customer Sales Transactions</subtitle>";

            page += "<line><prefix>Shipping Company: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getShippingCompanies().getSellingCompanyCode()))
                tmp += res.getShippingCompanies().getSellingCompanyCode();
            tmp = " - ";
            if (!StringUtils.isNullOrEmpty(res.getShippingCompanies().getSellingCompanyName()))
                tmp += res.getShippingCompanies().getSellingCompanyName();
            page += tmp;
            tmp = " ";
            page += "<prefix2> Selling Company: </prefix2>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getSellingCompanyCode()))
                tmp = res.getDestinationCompanies().getSellingCompanyCode();
            tmp = " - ";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getSellingCompanyName()))
                tmp = res.getDestinationCompanies().getSellingCompanyName();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix>Sales order Type: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getOrderTypes().getSalesOrderType()))
                tmp = res.getOrderTypes().getSalesOrderType();
            page += tmp;
            tmp = " ";

            page += "<prefix2> Sales Organisation: </prefix2>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationCompanies().getSalesOrganisation()))
                tmp = res.getDestinationCompanies().getSalesOrganisation();
            page += tmp + "</line>";
            tmp = " ";

            page += "<line><prefix>Currency: </prefix>";
            if (!StringUtils.isNullOrEmpty(res.getCurrency().getSalesCurrency()))
                tmp = res.getCurrency().getSalesCurrency();
            page += tmp + "</line>";
            tmp = " ";

            page += "<title>PLANTS in shipping country</title>";
            page += "<table1> <head><colName>Plant ID </colName><colName>Plant Name </colName> <colName>Plant Name 2 </colName><colName>Country </colName><colName>Company </colName><colName>Comment </colName><colName>Last Updated </colName></head><body>";
            List fromP;
            fromP = res.getPlants();
            if (fromP == null || fromP.size() == 0) {
                page += "</body></table1>";
                page += "<data>no plants applicable for this product group</data>";
            } else {
                for (int i = 0; i < fromP.size(); i++) {

                    page += "<row>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PlantsFromCountry) fromP.get(i)).getCodePlant()))
                        page += ((PlantsFromCountry) fromP.get(i)).getCodePlant();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PlantsFromCountry) fromP.get(i)).getPlantName()))
                        page += ((PlantsFromCountry) fromP.get(i)).getPlantName();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PlantsFromCountry) fromP.get(i)).getM_strPlantName2()))
                        page += ((PlantsFromCountry) fromP.get(i)).getM_strPlantName2();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PlantsFromCountry) fromP.get(i)).getCodeFromCountry()))
                        page += ((PlantsFromCountry) fromP.get(i)).getCodeFromCountry();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PlantsFromCountry) fromP.get(i)).getM_strPlantCompanyCode()) && !StringUtils.isNullOrEmpty(((PlantsFromCountry) fromP.get(i)).getM_strPlantCompanyName()))
                        page += ((PlantsFromCountry) fromP.get(i)).getM_strPlantCompanyCode() + " - " + ((PlantsFromCountry) fromP.get(i)).getM_strPlantCompanyName();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PlantsFromCountry) fromP.get(i)).getComments(res.getDivision().getDivisionCode())))
                        page += ((PlantsFromCountry) fromP.get(i)).getComments(res.getDivision().getDivisionCode());
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PlantsFromCountry) fromP.get(i)).getPublishOwner()))
                        page += ((PlantsFromCountry) fromP.get(i)).getPublishOwner();
                    if (((PlantsFromCountry) fromP.get(i)).getPublishDate() != null)
                        page += ((PlantsFromCountry) fromP.get(i)).getPublishDate();
                    page += "</cell>";
                    page += "</row>";
                }
                page += "</body></table1>";
            }

            page += "<title>CONTACTS</title>";

            Vector v = res.getShippingContacts();
            int number = 1;
            boolean hasContact = false;
            if (v == null || v.size() == 0) {
                page += "<line>no contacts defined in shipping country</line>";
            } else {
                for (int i = 0; i < v.size(); i++) {
                    Contacts cont = (Contacts) v.get(i);
                    page += "<table2><head><colName>Contact " + number + " in shipping country </colName><colName>Last updated: " + cont.getPublishOwner() + " </colName></head><body>";
                    page += "<row>";
                    page += "<cell>Contact type</cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getContactType()))
                        page += cont.getContactType();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Contact Name</cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getContactName()))
                        page += cont.getContactName();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Contact person </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getContactPerson()))
                        page += cont.getContactPerson();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Street </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getStreet()))
                        page += cont.getStreet();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>City </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getCity()))
                        page += cont.getCity();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Country </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getCountry()))
                        page += cont.getCountry();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Telephone </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getTel()))
                        page += cont.getTel();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Fax </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getFax()))
                        page += cont.getFax();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Mobile </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getMobile()))
                        page += cont.getMobile();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Mail </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getMail()))
                        page += cont.getMail();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Comments </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getContactComments()))
                        page += cont.getContactComments();
                    if (!StringUtils.isNullOrEmpty(cont.getComment(res.getShipping().getCountryCode(), res.getDivision().getDivisionCode(), "F")))
                        page += cont.getComment(res.getShipping().getCountryCode(), res.getDivision().getDivisionCode(), "F");
                    page += "</cell></row>";
                    page += "</body></table2>";
                    number++;
                    page += "<line></line>";
                }
            }

            v = res.getDestinationContacts();
            number = 1;
            if (v == null || v.size() == 0) {
                page += "<line>no contacts defined in destination country</line>";
            } else {
                for (int i = 0; i < v.size(); i++) {
                    Contacts cont = (Contacts) v.get(i);
                    page += "<table2><head><colName>Contact " + number + " in destination country </colName><colName>Last updated: " + cont.getPublishOwner() + " </colName></head><body>";
                    page += "<row>";
                    page += "<cell>Contact type</cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getContactType()))
                        page += cont.getContactType();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Contact Name</cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getContactName()))
                        page += cont.getContactName();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Contact person </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getContactPerson()))
                        page += cont.getContactPerson();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Street </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getStreet()))
                        page += cont.getStreet();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>City </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getCity()))
                        page += cont.getCity();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Country </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getCountry()))
                        page += cont.getCountry();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Telephone </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getTel()))
                        page += cont.getTel();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Fax </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getFax()))
                        page += cont.getFax();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Mobile </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getMobile()))
                        page += cont.getMobile();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Mail </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getMail()))
                        page += cont.getMail();
                    page += "</cell></row>";
                    page += "<row>";
                    page += "<cell>Comments </cell><cell>";
                    if (!StringUtils.isNullOrEmpty(cont.getContactComments()))
                        page += cont.getContactComments();
                    if (!StringUtils.isNullOrEmpty(cont.getComment(res.getShipping().getCountryCode(), res.getDivision().getDivisionCode(), "T")))
                        page += cont.getComment(res.getShipping().getCountryCode(), res.getDivision().getDivisionCode(), "T");
                    page += "</cell></row>";
                    page += "</body></table2>";
                    number++;
                    page += "<line></line>";
                }
            }

            page += "<title>Incoterm info </title>";
            page += "<table4><head> <colName>Incoterms:" + res.getIncotermInfo().getSIncotermDescr() + "</colName> <colName>Last updated:" + res.getIncotermInfo().getPublishOwner() + res.getIncotermInfo().getPublishDate() + "</colName></head><body>";
            page += "<row>";
            page += "<cell>Duties paid by</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getIncotermInfo().getSDuties()))
                page += res.getIncotermInfo().getSDuties();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Freight paid by</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getIncotermInfo().getSFreight()))
                page += res.getIncotermInfo().getSFreight();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Insurance paid by</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getIncotermInfo().getSInsurance()))
                page += res.getIncotermInfo().getSInsurance();
            page += "</cell></row>";
            page += "</body></table4>";

            page += "<title>Customs info</title>";
            page += "<table5><head><colName></colName><colName>Produc group: " + res.getProductGroup().getProductGroupName() + " </colName><colName>Last updated</colName></head><body>";
            page += "<row>";
            page += "<cell>HTS Code</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getProductGroup().getHTSCode()))
                page += res.getProductGroup().getHTSCode();
            page += "</cell><cell>" + res.getProductGroup().getPublishOwner() + res.getProductGroup().getPublishDate() + "</cell></row>";
            page += "<row>";
            page += "<cell>Botanical name</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getProductGroup().getBotanicalName()))
                page += res.getProductGroup().getBotanicalName();
            page += "</cell><cell>" + res.getProductGroup().getPublishOwner() + res.getProductGroup().getPublishDate() + "</cell></row>";
            page += "<row>";
            page += "<cell>Export Customs clearance fee</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getExportClearanceFee().getExportClearanceFee()))
                page += res.getExportClearanceFee().getExportClearanceFee();
            page += "</cell><cell>" + res.getExportClearanceFee().getPublishOwner() + res.getExportClearanceFee().getPublishDate() + "</cell></row>";
            page += "<row>";
            page += "<cell>Import Customs Clearance Fee</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getImportClearanceFee().getImportClearanceFee()))
                page += res.getImportClearanceFee().getImportClearanceFee();
            page += "</cell><cell>" + res.getImportClearanceFee().getPublishOwner() + res.getImportClearanceFee().getPublishDate() + "</cell></row>";
            page += "<row>";
            page += "<cell>Value Added Tax</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getValueAddedTax().getValue()))
                page += res.getValueAddedTax().getValue();
            page += "</cell><cell>" + res.getValueAddedTax().getOwner() + res.getValueAddedTax().getDate() + "</cell></row>";
            page += "<row>";
            page += "<cell>Import Duties</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getImportDuties().getImportDuties()))
                page += res.getImportDuties().getImportDuties();
            page += "</cell><cell>" + res.getImportDuties().getPublishOwner() + res.getImportDuties().getPublishDate() + "</cell></row>";
            page += "</body></table5>";

            page += "<title>FEES</title>";
            page += "<table4><head><colName>Fees in shipping country</colName><colName>Last updated:" + res.getShipping().getPublishOwner() + res.getShipping().getPublishDate() + "</colName></head><body>";
            page += "<row>";
            page += "<cell>Certificate of origin</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingFees().getCertificateOfOrigin()))
                page += res.getShippingFees().getCertificateOfOrigin();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Consular</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingFees().getConsular()))
                page += res.getShippingFees().getConsular();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Federal seed lab</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingFees().getFederalSeedLab()))
                page += res.getShippingFees().getFederalSeedLab();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Handling</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingFees().getHandling()))
                page += res.getShippingFees().getHandling();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Insurance</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingFees().getInsurance()))
                page += res.getShippingFees().getInsurance();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Legalization</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingFees().getLegalization()))
                page += res.getShippingFees().getLegalization();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Phytosanitary certificate</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingFees().getPhytosanitaryCertificate()))
                page += res.getShippingFees().getPhytosanitaryCertificate();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Seed Analysis Certificate</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingFees().getSeedAnalysisCertificate()))
                page += res.getShippingFees().getSeedAnalysisCertificate();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Inspection</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingFees().getInspection()))
                page += res.getShippingFees().getInspection();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Other</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingFees().getOther()))
                page += res.getShippingFees().getOther();
            page += "</cell></row>";
            page += "</body></table4>";
            page += "<line></line	>";
            page += "<table4><head><colName>Fees in destination country</colName><colName>Last updated:" + res.getDestination().getPublishOwner() + res.getDestination().getPublishDate() + "</colName></head><body>";
            page += "<row>";
            page += "<cell>Certificate of origin</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationFees().getCertificateOfOrigin()))
                page += res.getDestinationFees().getCertificateOfOrigin();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Consular</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationFees().getConsular()))
                page += res.getDestinationFees().getConsular();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Federal seed lab</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationFees().getFederalSeedLab()))
                page += res.getDestinationFees().getFederalSeedLab();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Handling</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationFees().getHandling()))
                page += res.getDestinationFees().getHandling();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Insurance</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationFees().getInsurance()))
                page += res.getDestinationFees().getInsurance();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Legalization</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationFees().getLegalization()))
                page += res.getDestinationFees().getLegalization();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Phytosanitary certificate</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationFees().getPhytosanitaryCertificate()))
                page += res.getDestinationFees().getPhytosanitaryCertificate();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Seed Analysis Certificate</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationFees().getSeedAnalysisCertificate()))
                page += res.getDestinationFees().getSeedAnalysisCertificate();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Inspection</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationFees().getInspection()))
                page += res.getDestinationFees().getInspection();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Other</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationFees().getOther()))
                page += res.getDestinationFees().getOther();
            page += "</cell></row>";
            page += "</body></table4>";

            page += "<title>LEAD TIMES</title>";
            page += "<table5><head><colName></colName><colName></colName><colName>Last updated</colName></head><body>";
            page += "<row>";
            page += "<cell>Import License Approval</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getImportLicenseApproval().getImportLicenseApproval()))
                page += res.getImportLicenseApproval().getImportLicenseApproval();
            page += "</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getImportLicenseApproval().getPublishOwner()))
                page += res.getImportLicenseApproval().getPublishOwner() + res.getImportLicenseApproval().getPublishDate();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Export clearance time</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingClearance().getExportClearanceTime()))
                page += res.getShippingClearance().getExportClearanceTime();
            page += "</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getShippingClearance().getPublishOwner()))
                page += res.getShippingClearance().getPublishOwner() + res.getShippingClearance().getPublishDate();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Freight booking</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getTransportationTime().getFreightBooking()))
                page += res.getTransportationTime().getFreightBooking();
            page += "</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getTransportationTime().getPublishOwner()))
                page += res.getTransportationTime().getPublishOwner() + res.getTransportationTime().getPublishDate();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Transportation time</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getTransportationTime().getTransportationTime()))
                page += res.getTransportationTime().getTransportationTime();
            page += "</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getTransportationTime().getPublishOwner()))
                page += res.getTransportationTime().getPublishOwner() + res.getTransportationTime().getPublishDate();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Import clearance time</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationClearance().getImportClearanceTime()))
                page += res.getDestinationClearance().getImportClearanceTime();
            page += "</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getDestinationClearance().getPublishOwner()))
                page += res.getDestinationClearance().getPublishOwner() + res.getDestinationClearance().getPublishDate();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Port of entry</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getPreferredPortOfEntry().getPort()))
                page += res.getPreferredPortOfEntry().getPort();
            page += "</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getPreferredPortOfEntry().getOwner()))
                page += res.getPreferredPortOfEntry().getOwner() + res.getPreferredPortOfEntry().getDate();
            page += "</cell></row>";
            page += "</body></table5>";

            page += "<title>SHIPPING INSTRUCTIONS</title>";
            page += "<table4><head><colName></colName><colName>Last updated:" + res.getInstruction().getOwner() + res.getInstruction().getDate() + "</colName></head><body>";
            page += "<row>";
            page += "<cell>Seed samples</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getInstruction().getSeedSamples()))
                page += res.getInstruction().getSeedSamples();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Shipping instructions</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getInstruction().getShippingInstructions()))
                page += res.getInstruction().getShippingInstructions();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Required seed treatment</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getInstruction().getSeedTreatment()))
                page += res.getInstruction().getSeedTreatment();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Miscellaneous</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getInstruction().getMiscallenous()))
                page += res.getInstruction().getMiscallenous();
            page += "</cell></row>";
            page += "<row>";
            page += "<cell>Packaging</cell><cell>";
            if (!StringUtils.isNullOrEmpty(res.getInstruction().getPackaging()))
                page += res.getInstruction().getPackaging();
            page += "</cell></row>";
            page += "</body></table4>";

//            page += "<title>MATERIAL DATA</title>";
//            page += "<table5><head><colName>" + res.getTrait().getTraitName() + "</colName><colName>Last updated:" + res.getTrait().getPublishOwner() + res.getTrait().getPublishDate() + "</colName></head><body>";
//            page += "<row>";
//            page += "<cell>Description</cell><cell>";
//            if (!StringUtils.isNullOrEmpty(res.getTrait().getTraitName()))
//                page += res.getTrait().getTraitName();
//            page += "</cell></row>";
//            page += "<row>";
//            page += "<cell>OECD unique identifier</cell><cell>";
//            if (!StringUtils.isNullOrEmpty(res.getTrait().getOECDIdentifier()))
//                page += res.getTrait().getOECDIdentifier();
//            page += "</cell></row>";
//            page += "<row>";
//            page += "<cell>Approved for Production</cell><cell>";
//            if (!StringUtils.isNullOrEmpty(res.getApproved().getProduction()))
//                page += res.getApproved().getProduction();
//            page += "</cell></row>";
//            page += "<row>";
//            page += "<cell>Approved for Import</cell><cell>";
//            if (!StringUtils.isNullOrEmpty(res.getApproved().getImportation()))
//                page += res.getApproved().getImportation();
//            page += "</cell></row>";
//            page += "<row>";
//            page += "<cell>Approved for Food, Feed or Environment</cell><cell>";
//            if (!StringUtils.isNullOrEmpty(res.getApproved().getFood()))
//                page += res.getApproved().getFood();
//            page += "</cell></row>";
//            page += "</body></table5>";

            page += "<title>Documents </title>";
            page += "<table6><head> <colName>Document</colName> <colName>Document Name</colName> <colName>Special Requirements</colName> <colName>Responsible </colName><colName> Shipping method </colName><colName>Where to be sent</colName><colName>Where to be sent</colName><colName>Comments </colName></head><body>";
            v = res.getDocuments();
            if (v == null || v.size() == 0) {
                page += "</body></table6>";
                page += "<data>no documents for this selection</data>";
            } else {
                for (int i = 0; i < v.size(); i++) {
                    page += "<row>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((DocumentConditions) v.get(i)).getTypeRequirement()))
                        page += ((DocumentConditions) v.get(i)).getTypeRequirement();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((DocumentConditions) v.get(i)).getDocName()))
                        page += ((DocumentConditions) v.get(i)).getDocName();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((DocumentConditions) v.get(i)).getSpecialReq()))
                        page += ((DocumentConditions) v.get(i)).getSpecialReq();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((DocumentConditions) v.get(i)).getBuyerSeller()))
                        page += ((DocumentConditions) v.get(i)).getBuyerSeller() + " ";
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((DocumentConditions) v.get(i)).getShippingMethod()))
                        page += ((DocumentConditions) v.get(i)).getShippingMethod() + " ";
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((DocumentConditions) v.get(i)).getWhereSent()))
                        page += ((DocumentConditions) v.get(i)).getWhereSent() + " ";
                    page += "</cell>";
                    page += "<cell>";
                    if (((DocumentConditions) v.get(i)).getWhenSent() != null)
                        page += ((DocumentConditions) v.get(i)).getWhenSent() + " ";
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((DocumentConditions) v.get(i)).getComments()))
                        page += ((DocumentConditions) v.get(i)).getComments() + " ";
                    page += "</cell>";
                    page += "</row>";
                }
                page += "</body></table6>";
            }


            page += "<title>Vegetable Phytosanitary requirements</title>";
            page += "<table3><head> <colName>Plant ID</colName> <colName>MIC code</colName> <colName>MIC description</colName> <colName>Info Field</colName> <colName>Last Updated</colName> </head><body>";
            v = res.getPhytosanitaryRequirements();
            if (v == null || v.size() == 0) {
                page += "</body></table3>";
                page += "<data> no additional declarations on the phytosanitary certificate for this selection</data>";
            } else {
                for (int i = 0; i < v.size(); i++) {
                    page += "<row>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PhytoRequirement) v.get(i)).getPlantID()))
                        page += ((PhytoRequirement) v.get(i)).getPlantID();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PhytoRequirement) v.get(i)).getMicCode()))
                        page += ((PhytoRequirement) v.get(i)).getMicCode();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PhytoRequirement) v.get(i)).getMicDescription()))
                        page += ((PhytoRequirement) v.get(i)).getMicDescription();
                    page += "</cell>";
                     //new field requirement info field.
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PhytoRequirement) v.get(i)).getInfoField()))
                        page += ((PhytoRequirement) v.get(i)).getInfoField();
                    page += "</cell>";
                    page += "<cell>";
                    if (!StringUtils.isNullOrEmpty(((PhytoRequirement) v.get(i)).getPublishOwner()))
                        page += ((PhytoRequirement) v.get(i)).getPublishOwner() + " ";
                    if (((PhytoRequirement) v.get(i)).getPublishDate() != null)
                        page += ((PhytoRequirement) v.get(i)).getPublishDate() + " ";
                    page += "</cell>";
                    page += "</row>";
                }
                page += "</body></table3>";
            }

            page += "</page>";
            /*
                * convert the String into a document
                */
            Logger.log(new LoggableInfo(page));
            StringReader sr = new StringReader(page);
            InputSource is = new InputSource(sr);
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(true);

            factory.setNamespaceAware(true);
            DocumentBuilder builder = null;
            try {
                builder = factory.newDocumentBuilder();
                DefaultHandler handler = new DefaultHandler();
                builder.setErrorHandler(handler);
                Document document = builder.parse(is);
                /*
                     * the document and the stylesheet are used to feed the printer and the pdf is printed
                     */
                PDFFormattedWriter pdfWriter = new PDFFormattedWriter(document, "/Stylesheet/page.xsl", helper);
                helper.writeToFormattedWriter(pdfWriter);
            } catch (ParserConfigurationException e1) {
                e1.printStackTrace();
            } catch (SAXException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        } catch (Exception ex2) {
            Logger.log(new LoggableError("A error occured " + "The error was: " + ex2.toString()));
            ex2.printStackTrace();
            IIMexMailHelper.send(ex2, helper.getAuthenticatedUserFullName());
            helper.redirect(helper.getContextPath() + "/inside/ExceptionHandler.jsp");

		}
	}
 
}