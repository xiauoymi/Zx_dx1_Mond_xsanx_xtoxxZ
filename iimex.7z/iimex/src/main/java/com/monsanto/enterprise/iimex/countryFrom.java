package com.monsanto.enterprise.iimex;

import java.util.Date;
/*
 * This class is used to list each country where a specific contact works
 */
@Deprecated
public class countryFrom{
	protected String From;
	protected String comment=" ";
	protected String country;
	protected String division;
	protected String publishOwner;
	protected Date publishDate;
	
	public String getFrom(){
		return From;
	}
	public void setFrom(String f){
		From = f;
	}
	public String getCountry(){
		return country;
	}
	public void setCountry(String c){
		country = c;
	}
	public String getDivision(){
		return division;
	}
	public void setDivision(String d){
		division = d;
	}
	public String getComment(){
		return comment;
	}
	public void setComment(String c){
		comment = c;
	}
	public void setPublishOwner(String publishOwner){
		this.publishOwner=publishOwner;
	}
	public void setPublishDate(Date publishDate){
		this.publishDate=publishDate;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
}