package com.monsanto.enterprise.iimex.elements;

import java.util.Date;

/**
 * This object contains all information about the relation between the trait and the country
 */
public class Approved{
	
	/**
	 * Is the trait approved for production in the destination country
	 */
	protected String production = "contact trade and compliance";
	/**
	 * Is the trait approved for importation in the destination country
	 */
	protected String importation = "contact trade and compliance";
	
	protected String food = "contact trade and compliance";
	/**
	 * Who has published those information
	 */
	
	protected String country = "";
	
	protected String publishOwner;
	/**
	 * When were published those information
	 */
	protected Date publishDate;
	
	public String getProduction(){
		return production;
	}
	public String getImportation(){
		return importation;
	}
	public String getFood(){
		return food;
	}
	public String getCountry(){
		return country;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
	
	public void setProduction(String production){
		this.production = production;
	}
	public void setImportation(String importation){
		this.importation = importation;
	}
	public void setFood(String food){
		this.food = food;
	}
	public void setCountry(String c){
		this.country = c;
	}
	public void setPublishOwner(String owner){
		publishOwner = owner;
	}
	public void setPublishDate(Date date){
		publishDate = date;
	}
}