package com.monsanto.enterprise.iimex.elements;

import java.util.Date;

/**
* store the clearance fee information
**/

public class ClearanceFee {
	protected String importClearanceFee="contact trade and compliance";
	protected String exportClearanceFee="contact trade and compliance";
	protected String transportModeCode;
	protected String transportModeName;
	protected String publishOwner = "";
	protected Date publishDate = new Date();
	
	public void setImportClearanceFee(String importClearanceFee){
		this.importClearanceFee = importClearanceFee;
	}
	public void setExportClearanceFee(String exportClearanceFee){
		this.exportClearanceFee = exportClearanceFee;
	}
	public void setPublishOwner(String publishOwner){
		this.publishOwner = publishOwner;
	}
	public void setPublishDate(Date publishDate){
		this.publishDate = publishDate;
	}
	
	public String getImportClearanceFee(){
		return importClearanceFee;
	}
	public String getExportClearanceFee(){
		return exportClearanceFee;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
	
	public void setTransportModeCode(String tp){
		transportModeCode = tp;
	}
	public void setTransportModeName(String tp){
		transportModeName = tp;
	}
	public String getTransportModeCode(){
		return transportModeCode;
	}
	public String getTransportModeName(){
		return transportModeName;
	}
	
}


