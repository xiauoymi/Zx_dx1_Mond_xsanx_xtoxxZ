package com.monsanto.enterprise.iimex.elements;

import java.util.Date;
/**
* store the clearance time information
**/
public class ClearanceTime {
	protected String importClearanceTime = "contact trade and compliance";
	protected String exportClearanceTime = "contact trade and compliance";
	protected String transportModeCode;
	protected String transportModeName;
	protected String publishOwner;
	protected Date publishDate;
	
	public void setImportClearanceTime(String importClearanceTime){
		this.importClearanceTime = importClearanceTime;
	}
	public void setExportClearanceTime(String exportClearanceTime){
		this.exportClearanceTime = exportClearanceTime;
	}
	public void setPublishOwner(String publishOwner){
		this.publishOwner = publishOwner;
	}
	public void setPublishDate(Date publishDate){
		this.publishDate = publishDate;
	}
	
	public String getImportClearanceTime(){
		return importClearanceTime;
	}
	public String getExportClearanceTime(){
		return exportClearanceTime;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
	public void setTransportModeCode(String tp){
		transportModeCode = tp;
	}
	public void setTransportModeName(String tp){
		transportModeName = tp;
	}
	public String getTransportModeCode(){
		return transportModeCode;
	}
	public String getTransportModeName(){
		return transportModeName;
	}
}


