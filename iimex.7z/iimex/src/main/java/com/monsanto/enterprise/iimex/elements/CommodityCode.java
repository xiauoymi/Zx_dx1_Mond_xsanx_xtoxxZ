package com.monsanto.enterprise.iimex.elements;

public class CommodityCode {

	protected String sProdgroup;
	protected String sCountryCode;
	protected String sCommodityCode;
	protected String sBotanicalName;
	protected String sClearance;
	protected Double iTax;
	
	
	public Double getITax() {
		return iTax;
	}
	public void setITax(Double tax) {
		iTax = tax;
	}
	public String getSClearance() {
		return sClearance;
	}
	public void setSClearance(String clearance) {
		sClearance = clearance;
	}
	public String getSCommodityCode() {
		return sCommodityCode;
	}
	public void setSCommodityCode(String commodityCode) {
		sCommodityCode = commodityCode;
	}
	public String getSCountryCode() {
		return sCountryCode;
	}
	public void setSCountryCode(String countryCode) {
		sCountryCode = countryCode;
	}

	public String getSProdgroup() {
		return sProdgroup;
	}
	public void setSProdgroup(String prodgroup) {
		sProdgroup = prodgroup;
	}
	
	public void setBotanicalName(String botanicalName){
		sBotanicalName =botanicalName;
	}
	
	public String getBotanicalName(){
		return sBotanicalName;
	}

}
