package com.monsanto.enterprise.iimex.elements;

import java.util.Date;

/**
* Store the company name for every company code
**/

public class Company{

	
	protected String companyCode;
	protected String companyName;
	
	protected String publishOwner;
	protected Date publishDate;
	
	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public void setPublishOwner(String publishOwner) {
		this.publishOwner = publishOwner;
	}
	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}
	
	public String getCompanyCode() {
		return companyCode;
	}
	public String getCompanyName() {
		return companyName;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
}
