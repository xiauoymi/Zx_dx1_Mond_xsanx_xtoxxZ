package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;

/**
* This object store all information about companies in a country
**/
public class CompanyDetermination {

	
	protected String group=" ";
	protected String division=" ";
	protected String soldToCompanyCode=" ";
	protected String salesCompanyCode=" ";
	protected String billToCompanyCode=" ";
	protected String shipToCompanyCode=" ";
	protected String consignToCompanyCode=" ";
	protected String sellingCompanyCode=" ";
	protected String soldToCompanyName = IIMexConstants.NO_DATA;
	protected String salesCompanyName=" ";
	protected String billToCompanyName=" ";
	protected String shipToCompanyName=" ";
	protected String consignToCompanyName=" ";
	protected String sellingCompanyName =  IIMexConstants.NO_DATA;
	protected String salesOrganisation = "";
	protected String publishOwner;
	protected Date publishDate;
	protected String active=" ";
	
	public void setActive(String active) {
		this.active = active;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public void setSoldToCompanyCode(String soldToCompanyCode) {
		this.soldToCompanyCode = soldToCompanyCode;
	}
	public void setSalesCompanyCode(String salesCompanyCode) {
		this.salesCompanyCode = salesCompanyCode;
	}
	public void setBillToCompanyCode(String billToCompanyCode) {
		this.billToCompanyCode = billToCompanyCode;
	}
	public void setShipToCompanyCode(String shipToCompanyCode) {
		this.shipToCompanyCode = shipToCompanyCode;
	}
	public void setConsignToCompanyCode(String consignToCompanyCode) {
		this.consignToCompanyCode = consignToCompanyCode;
	}
	public void setSellingCompanyCode(String sellingCompanyCode) {
		this.sellingCompanyCode = sellingCompanyCode;
	}
	public void setSoldToCompanyName(String soldToCompanyName) {
		this.soldToCompanyName = soldToCompanyName;
	}
	public void setSalesCompanyName(String salesCompanyName) {
		this.salesCompanyName = salesCompanyName;
	}
	public void setBillToCompanyName(String billToCompanyName) {
		this.billToCompanyName = billToCompanyName;
	}
	public void setShipToCompanyName(String shipToCompanyName) {
		this.shipToCompanyName = shipToCompanyName;
	}
	public void setConsignToCompanyName(String consignToCompanyName) {
		this.consignToCompanyName = consignToCompanyName;
	}
	public void setSellingCompanyName(String sellingCompanyName) {
		this.sellingCompanyName = sellingCompanyName;
	}
	public void setSalesOrganisation(String salesOrganisation) {
		this.salesOrganisation = salesOrganisation;
	}
	public void setPublishOwner(String publishOwner) {
		this.publishOwner = publishOwner;
	}
	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}
	
	public String getActive() {
		return active;
	}
	public String getDivision() {
		return division;
	}
	public String getGroup() {
		return group;
	}
	public String getSoldToCompanyCode() {
		return soldToCompanyCode;
	}
	public String getSalesCompanyCode() {
		return salesCompanyCode;
	}
	public String getBillToCompanyCode() {
		return billToCompanyCode;
	}
	public String getShipToCompanyCode() {
		return shipToCompanyCode;
	}
	public String getConsignToCompanyCode() {
		return consignToCompanyCode;
	}
	public String getSellingCompanyCode() {
		return sellingCompanyCode;
	}
	public String getSoldToCompanyName() {
		return soldToCompanyName;
	}
	public String getSalesCompanyName() {
		return salesCompanyName;
	}
	public String getBillToCompanyName() {
		return billToCompanyName;
	}
	public String getShipToCompanyName() {
		return shipToCompanyName;
	}
	public String getConsignToCompanyName() {
		return consignToCompanyName;
	}
	public String getSellingCompanyName() {
		return sellingCompanyName;
	}
	public String getSalesOrganisation() {
		return salesOrganisation;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
}
