package com.monsanto.enterprise.iimex.elements;

import java.util.Date;
import java.util.HashMap;
import java.util.Vector;

import java.util.Iterator;


/**
 * This object contains all information about the contact
 */

public class Contacts {

	protected int m_strContactCode;
	protected String m_strContactType;
	protected String m_strContactName;
	protected String m_strContactPerson;
	protected String m_strStreet;
	protected String m_strCity;
	protected String m_strCountry;
	protected String m_strCountryCode;
	protected String m_strTel;
	protected String m_strFax;
	protected String m_strMobile;
	protected String m_strMail;
	protected String m_strContactComments = "";
	protected String m_strPublishOwner;
	protected Date m_strPublishDate;
	protected HashMap countries = new HashMap();
	
	public int getContactCode() {
		return m_strContactCode;
	}
	public void setContactCode(int code) {
		m_strContactCode = code;
	}
	public String getContactType() {
		return m_strContactType;
	}
	public void setContactType(String type) {
		m_strContactType = type;
	}
	public String getContactName() {
		return m_strContactName;
	}
	public void setContactName(String contactName) {
		m_strContactName = contactName;
	}
	public String getContactPerson() {
		return m_strContactPerson;
	}
	public void setContactPerson(String contactPerson) {
		m_strContactPerson = contactPerson;
	}
	public String getStreet() {
		return m_strStreet;
	}
	public void setStreet(String street) {
		m_strStreet = street;
	}
	public String getCity() {
		return m_strCity;
	}
	public void setCity(String city) {
		m_strCity = city;
	}
	public String getCountry() {
		return m_strCountry;
	}
	public String getCountryCode() {
		return m_strCountryCode;
	}
	public void setCountry(String country) {
		m_strCountry = country;
	}
	public void setCountryCode(String countryCode) {
		m_strCountryCode = countryCode;
	}
	public HashMap getCountries() {
		return countries;
	}
	public Vector getCountriesVector() {
		Vector count = new Vector();
		Iterator ite = countries.keySet().iterator();
		while(ite.hasNext()){
			HashMap tmp = (HashMap)countries.get((String)ite.next());
			Iterator it = tmp.keySet().iterator();
			while(it.hasNext()){
				HashMap from = (HashMap)tmp.get((String)it.next());
				Iterator iter = from.keySet().iterator();
				while(iter.hasNext()){
					CountryFrom cf = (CountryFrom)from.get((String)iter.next());
					count.add(cf);
				}
			}
		}
		return count;
	}
	public void setCountries(HashMap country) {
		countries = country;
	}
	public String getTel() {
		return m_strTel;
	}
	public void setTel(String tel) {
		m_strTel = tel;
	}
	public String getFax() {
		return m_strFax;
	}
	public void setFax(String fax) {
		m_strFax = fax;
	}
	public String getMobile() {
		return m_strMobile;
	}
	public void setMobile(String mobile) {
		m_strMobile = mobile;
	}
	public String getMail() {
		return m_strMail;
	}
	public void setMail(String mail) {
		m_strMail = mail;
	}
	public String getContactComments() {
		return m_strContactComments;
	}
	
	public String getComment(String countryCode,String divisionCode,String From) {

        HashMap countryMap = (HashMap) countries.get(countryCode);
        if (countryMap==null){return "";}
        HashMap divisionsMaps = (HashMap) (countryMap.get(divisionCode));
        if (divisionsMaps==null){return "";}
        CountryFrom countryFrom = (CountryFrom) divisionsMaps.get(From);
        if (countryFrom==null){return "";}
        return countryFrom.getComment();
	}
	
	public void setContactComments(String contactComments) {
		m_strContactComments = contactComments;
	}
	public void setPublishOwner(String publishOwner) {
		m_strPublishOwner = publishOwner;
	}
	public String getPublishOwner() {
		return m_strPublishOwner;
	}
	public void setPublishDate(Date publishDate) {
		m_strPublishDate = publishDate;
	}
	public Date getPublishDate() {
		return m_strPublishDate;
	}
}
