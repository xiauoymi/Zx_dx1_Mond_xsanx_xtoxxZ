package com.monsanto.enterprise.iimex.elements;

import java.util.Date;



public class ContactsFromCountry {

	protected int m_strContactCode;
	protected String m_strContactType;
	protected String m_strContactName;
	protected String m_strContactPerson;
	protected String m_strStreet;
	protected String m_strCity;
	protected String m_strCountry;
	protected String m_strTel;
	protected String m_strFax;
	protected String m_strMobile;
	protected String m_strMail;
	protected String m_strContactComments;
	protected String m_strPublishOwner;
	protected Date m_strPublishDate;
	protected String m_strContactDivision;
	protected String m_strAttachedCountry;
	protected String m_strFrom;
	
	public int getContactCode() {
		return m_strContactCode;
	}
	public void setContactCode(int code) {
		m_strContactCode = code;
	}
	public String getContactType() {
		return m_strContactType;
	}
	public void setContactType(String type) {
		m_strContactType = type;
	}
	public String getContactName() {
		return m_strContactName;
	}
	public void setContactName(String contactName) {
		m_strContactName = contactName;
	}
	public String getContactPerson() {
		return m_strContactPerson;
	}
	public void setContactPerson(String contactPerson) {
		m_strContactPerson = contactPerson;
	}
	public String getStreet() {
		return m_strStreet;
	}
	public void setStreet(String street) {
		m_strStreet = street;
	}
	public String getCity() {
		return m_strCity;
	}
	public void setCity(String city) {
		m_strCity = city;
	}
	public String getCountry() {
		return m_strCountry;
	}
	public void setCountry(String country) {
		m_strCountry = country;
	}
	public String getAttachedCountry() {
		return m_strAttachedCountry;
	}
	public void setAttachedCountry(String country) {
		m_strAttachedCountry = country;
	}
	public String getTel() {
		return m_strTel;
	}
	public void setTel(String tel) {
		m_strTel = tel;
	}
	public String getFax() {
		return m_strFax;
	}
	public void setFax(String fax) {
		m_strFax = fax;
	}
	public String getMobile() {
		return m_strMobile;
	}
	public void setMobile(String mobile) {
		m_strMobile = mobile;
	}
	public String getMail() {
		return m_strMail;
	}
	public void setMail(String mail) {
		m_strMail = mail;
	}
	public String getContactComments() {
		return m_strContactComments;
	}
	public void setContactComments(String contactComments) {
		m_strContactComments = contactComments;
	}
	public void setPublishOwner(String publishOwner) {
		m_strPublishOwner = publishOwner;
	}
	public String getPublishOwner() {
		return m_strPublishOwner;
	}
	public void setPublishDate(Date publishDate) {
		m_strPublishDate = publishDate;
	}
	public Date getPublishDate() {
		return m_strPublishDate;
	}
	public void setContactDivision(String contactDivision) {
		m_strContactDivision = contactDivision;
	}
	public String getContactDivision() {
		return m_strContactDivision;
	}
	public String getFrom() {
		return m_strFrom;
	}
	public void setFrom(String from) {
		m_strFrom = from;
	}
}
