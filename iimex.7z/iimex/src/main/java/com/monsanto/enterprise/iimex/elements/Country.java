package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
/**
 * Store all information about a country
 * 
 *
 */
public class Country {

	
	protected String countryCode;
	protected String countryName;
	protected String customsZoneCode = IIMexConstants.NO_DATA;
	protected String customsZoneName = IIMexConstants.NO_DATA;
	protected String worldAreaCode = IIMexConstants.NO_DATA;
	protected String worldAreaName = IIMexConstants.NO_DATA;
	protected boolean active = false;
	
	/**
	 * Shipping Instructions
	 */
	protected Vector instructions;
	protected boolean instructionExist = false;
	
	/**
	 * Fees when country is used as shipping or destination 
	 */
	protected Fees shipping;
	protected Fees destination;
	
	/**
	 * information that depends of the country and product (VAT and companies)
	 */
	protected  HashMap valueAddedTax;
	protected  HashMap companyDetermination;
	protected  HashMap ImportLicenseApproval;
	
	/**
	 * information that depends of the country and transport mode (clearance fee and custom clearance time)
	 */
	protected  HashMap clearanceTime;
	protected  HashMap clearanceFee;
	
	protected HashMap orderTypes;
	
	protected String publishOwner;
	protected Date publishDate;
	
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public void setCustomsZoneCode(String customsZoneCode) {
		this.customsZoneCode = customsZoneCode;
	}
	public void setCustomsZoneName(String customsZoneName) {
		this.customsZoneName = customsZoneName;
	}
	public void setWorldAreaCode(String worldAreaCode) {
		this.worldAreaCode = worldAreaCode;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public void setImportLicenseApproval(HashMap license){
		ImportLicenseApproval = license;
	}
	public void setWorldAreaName(String worldAreaName) {
		this.worldAreaName = worldAreaName;
	}
	public void setShipping(Fees shipping) {
		this.shipping = shipping;
	}
	public void setDestination(Fees destination) {
		this.destination = destination;
	}
	public void setValueAddedTax(HashMap valueAddedTax) {
		this.valueAddedTax = valueAddedTax;
	}
	public void setInstruction(Vector instructions){
		this.instructions = instructions;
	}
	public void setCompanyDetermination(HashMap companyDetermination) {
		this.companyDetermination = companyDetermination;
	}
	public void setClearanceFee(HashMap clearanceFee) {
		this.clearanceFee = clearanceFee;
	}
	public void setClearanceTime(HashMap clearanceTime) {
		this.clearanceTime = clearanceTime;
	}
	public void setOrderTypes(HashMap orderTypes){
		this.orderTypes=orderTypes;
	}
	public void setInstructionExist(boolean instructionExist){
		this.instructionExist = instructionExist;
	}
	
	public void setPublishOwner(String publishOwner){
		this.publishOwner=publishOwner;
	}
	public void setPublishDate(Date publishDate){
		this.publishDate=publishDate;
	}
	
	public String getCountryCode() {
		return countryCode;
	}
	public String getCountryName() {
		return countryName;
	}
	public String getCustomsZoneCode() {
		return customsZoneCode;
	}
	public String getCustomsZoneName() {
		return customsZoneName;
	}
	public String getWorldAreaCode() {
		return worldAreaCode;
	}
	public String getWorldAreaName() {
		return worldAreaName;
	}
	public boolean getActive() {
		return active;
	}
	public Fees getShipping() {
		if(shipping!=null)
			return shipping;
		return new Fees();
	}
	public Fees getDestination() {
		if(destination!=null)
			return destination;
		return new Fees();
	}
	public HashMap getValueAddedTax() {
		if(valueAddedTax!=null)
			return valueAddedTax;
		return new HashMap();
	}
	public Vector getInstructions(){
		if(instructions!=null)
			return instructions;
		return new Vector();
	}
	public ShippingInstruction getInstruction(String division){
		if(instructions!=null){
			Iterator ite = instructions.iterator();
			while(ite.hasNext()){
				ShippingInstruction tmp = (ShippingInstruction)ite.next();
				if(tmp.getDivision().compareTo(division)==0)
					return tmp;
			}
		}
		return new ShippingInstruction();
	}
	public Vector getValueAddedTaxVector() {
		Vector result = new Vector();
		if(valueAddedTax!=null && !valueAddedTax.isEmpty()){
			Iterator ite = valueAddedTax.keySet().iterator();
			while(ite.hasNext())
				result.add((ValueAddedTax)valueAddedTax.get(ite.next()));
		}
		return result;
	}
	
	public HashMap getCompanyDetermination() {
		if(companyDetermination!=null)
			return companyDetermination;
		return new HashMap();
	}
	
	public CompanyDetermination getDetermination(String div,String prod) {
		if(companyDetermination==null || !companyDetermination.containsKey(div))
			return new CompanyDetermination();
		Iterator ite = ((Vector)companyDetermination.get(div)).iterator();
		CompanyDetermination cmp = new CompanyDetermination();
		while(ite.hasNext()){
			CompanyDetermination tmp = (CompanyDetermination)ite.next();
			if(tmp.getGroup().compareTo(prod)==0)
				return tmp;
			if(tmp.getGroup().compareTo("*")==0)
				cmp=tmp;
		}
		return cmp;
	}
	
	public Vector getCompanyDeterminationVector() {
		Vector result = new Vector();
		Iterator ite = companyDetermination != null ? companyDetermination.keySet().iterator() : null;
		while(ite != null && ite.hasNext()){
			Vector tmp = (Vector)companyDetermination.get((String)ite.next());
			Iterator it = tmp.iterator();
			while(it.hasNext())
			result.add(it.next());
		}
		return result;
	}
	
	public HashMap getClearanceFee() {
		if(clearanceFee!=null)
			return clearanceFee;
		return new HashMap();
	}
	public HashMap getImportLicenseApproval(){
		if(ImportLicenseApproval!=null)
			return ImportLicenseApproval;
		return new HashMap();
	}
	public Vector getImportLicenseApprovalVector(){
		Vector result = new Vector();
		if(ImportLicenseApproval!=null){
			Iterator ite = ImportLicenseApproval.keySet().iterator();
			while(ite.hasNext()){
				String code = (String)ite.next();
				ImportLicenseApproval tmp = (ImportLicenseApproval)ImportLicenseApproval.get(code);
				tmp.setHTS(code);
				result.add(tmp);
			}
		}
		return result;
	}
	public HashMap getClearanceTime() {
		if(clearanceTime!=null)
			return clearanceTime;
		return new HashMap();
	}
	public HashMap getOrderTypes() {
		return orderTypes;
	}
	public boolean getInstructionExist(){
		return instructionExist;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
}
