package com.monsanto.enterprise.iimex.elements;

import java.util.HashMap;
import java.util.Vector;

/**
* This object contains all the information that depend of the shipping and destination country
**/
public class CountryToCountry {

	
	protected String shippingCode;
	protected String destinationCode;
	
	/**
	 * information that depends of the countryToCountry and division (preferred port of entry)
	 */
	protected  HashMap preferredPortOfEntry;
	
	/**
	 * information that depends of the countryToCountry and transport mode (transportation time)
	 */
	protected  HashMap transportationTime;
	
	/**
	 * list of product restricted between the shipping country and the destination one
	 */
	protected Vector<ShippingRestriction> restrictions;
	
	public void setShippingCode(String shippingCode) {
		this.shippingCode = shippingCode;
	}
	public void setDestinationCode(String destinationCode) {
		this.destinationCode = destinationCode;
	}
	public void setPreferredPortOfEntry(HashMap preferredPortOfEntry) {
		this.preferredPortOfEntry = preferredPortOfEntry;
	}
	public void setTransportationTime(HashMap transportationTime) {
		this.transportationTime = transportationTime;
	}
	public void setRestrictions(Vector<ShippingRestriction> restrictions){
		this.restrictions=restrictions;
	}
	
	public String getShippingCode() {
		return shippingCode;
	}
	public String getDestinationCode() {
		return destinationCode;
	}
	public HashMap getPreferredPortOfEntry() {
		return preferredPortOfEntry;
	}
	public HashMap getTransportationTime() {
		return transportationTime;
	}
	public Vector<ShippingRestriction> getRestrictions(){
		return restrictions;
	}
}
