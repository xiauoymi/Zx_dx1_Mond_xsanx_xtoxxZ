package com.monsanto.enterprise.iimex.elements;

public class CustomAgents {

	protected String sCountryCode;
	protected String sCustomAgentCode;
	protected String sTransportModeCode;
	protected String sTransportModeName;
	protected String sKey;
	protected String sCustomAgentName;
	protected String sAddress1;
	protected String sAddress2;
	protected String sTel;
	protected String sFax;
	protected String sContact;
	
	
	
	public String getSContact() {
		return sContact;
	}
	public void setSContact(String contact) {
		sContact = contact;
	}
	public String getSAddress1() {
		return sAddress1;
	}
	public void setSAddress1(String address1) {
		sAddress1 = address1;
	}
	public String getSAddress2() {
		return sAddress2;
	}
	public void setSAddress2(String address2) {
		sAddress2 = address2;
	}
	public String getSCountryCode() {
		return sCountryCode;
	}
	public void setSCountryCode(String countryCode) {
		sCountryCode = countryCode;
	}
	public String getSCustomAgentCode() {
		return sCustomAgentCode;
	}
	public void setSCustomAgentCode(String customAgentCode) {
		sCustomAgentCode = customAgentCode;
	}
	public String getSCustomAgentName() {
		return sCustomAgentName;
	}
	public void setSCustomAgentName(String customAgentName) {
		sCustomAgentName = customAgentName;
	}
	public String getSFax() {
		return sFax;
	}
	public void setSFax(String fax) {
		sFax = fax;
	}
	public String getSKey() {
		return sKey;
	}
	public void setSKey(String key) {
		sKey = key;
	}
	public String getSTel() {
		return sTel;
	}
	public void setSTel(String tel) {
		sTel = tel;
	}
	public String getSTransportModeCode() {
		return sTransportModeCode;
	}
	public void setSTransportModeCode(String transportMode) {
		sTransportModeCode = transportMode;
	}
	public String getSTransportModeName() {
		return sTransportModeName;
	}
	public void setSTransportModeName(String transportMode) {
		sTransportModeName = transportMode;
	}
	
}
