package com.monsanto.enterprise.iimex.elements;
//defined for a shipping country, a destination one and a product group
public class CustomsImportDuties {

		protected String sFromCountry;
		protected String sToCountry;
		protected String sProductGroup;
		protected Double dImportDuties;
		
		public Double getDImportDuties() {
			return dImportDuties;
		}
		public void setDImportDuties(Double importDuties) {
			dImportDuties = importDuties;
		}
		public String getSFromCountry() {
			return sFromCountry;
		}
		public void setSFromCountry(String fromCountry) {
			sFromCountry = fromCountry;
		}
		public String getSProductGroup() {
			return sProductGroup;
		}
		public void setSProductGroup(String productGroup) {
			sProductGroup = productGroup;
		}
		public String getSToCountry() {
			return sToCountry;
		}
		public void setSToCountry(String toCountry) {
			sToCountry = toCountry;
		}
		
		

}
