package com.monsanto.enterprise.iimex.elements;

import java.util.Date;
//division of the products
public class Division{
	protected String m_strDivisionCode;
	protected String m_strDivisionName;
	protected String publishOwner;
	protected Date publishDate;
	
	public String getDivisionCode() {
		return m_strDivisionCode;
	}
	public void setDivisionCode(String divisionCode) {
		m_strDivisionCode = divisionCode;
	}
	public String getDivisionName() {
		return m_strDivisionName;
	}
	public void setDivisionName(String divisionName) {
		m_strDivisionName = divisionName;
	}
	public void setPublishOwner(String publishOwner){
		this.publishOwner=publishOwner;
	}
	public void setPublishDate(Date publishDate){
		this.publishDate=publishDate;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
}