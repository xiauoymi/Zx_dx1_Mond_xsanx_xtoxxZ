/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.elements;



import java.io.BufferedInputStream;

import java.io.BufferedOutputStream;

import java.io.File;

import java.io.FileInputStream;

import java.io.FileNotFoundException;

import java.io.FileOutputStream;

import java.io.IOException;

import java.io.InputStream;

import java.io.OutputStream;

import java.sql.Blob;

import java.sql.SQLException;

import java.text.DateFormat;

import java.text.SimpleDateFormat;

import java.util.Date;



import com.monsanto.Util.FileUtil;

import com.monsanto.Util.StringUtils;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.tableloader.TableGetDocument;

import com.sun.corba.se.impl.javax.rmi.CORBA.Util;



/**

 * Information about the documents that are published in the interface link and documentation

 * Filename:    $RCSfile: DocLink.java,v $

 * Label:       $Name:  $

 * Last Change: $Author: mmcort3 $    	 On:	$Date: 2008/06/27 13:38:54 $

 * @version     $Revision: 1.4 $

 * @author      MMCORT3

*/

public class DocLink  {

	

	/**

	 * DocId it is the same that we find in the DB

	 */

	protected int docId;

	/**

	 * Parent link Id

	 */

	protected int linkId;

	/**

	 * Doc title show in the web interface

	 */

	protected String m_strDocTitle;

	/**

	 * Doc name

	 */

	protected String m_StrDocName;

	/**

	 * Doc description

	 */

	protected String m_strDocDescription;

	/**

	 * Date when the document has been published

	 */

	protected String publishDate;

	/**

	 * Person who request to publish the document

	 */

	protected String publishOwner;

	/**

	 * Document path

	 */

	protected InputStream document;

	//protected InputStream document;

	protected byte[] byteFile;

	

	

	public String getDocId() {

		return Integer.toString(docId);

	}

	public void setDocId(int docId) {

		this.docId = docId;

	}

	public String getLinkId() {

		return Integer.toString(linkId);

	}

	public void setLinkId(int linkId) {

		this.linkId = linkId;

	}

	public String getdocDescription() {

		return m_strDocDescription;

	}

	public void setdescription(String docDescription) {

		m_strDocDescription = docDescription;

	}

	public String getDocTitle() {

		return m_strDocTitle;

	}

	public void setDocTitle(String docTitle) {

		m_strDocTitle = docTitle;

	}

	public InputStream getDocument() 

	throws IIMexException{

		TableGetDocument documentGetter = new TableGetDocument();

			return documentGetter.getDocument(this.docId, this.linkId);

	}

	/**

	 * Copy the file in a byte vector called byteFile

	 * @param stream

	 * @throws IIMexException

	 */

	public void setDocument(InputStream inputStream) 

	throws IIMexException{

		this.document = inputStream;

		

	

		

	}

	public String getPublishDate() {

		return publishDate;

	}

	public void setPublishDate(Date publishDate) {

		String strDate="";

		DateFormat dateFormat =new SimpleDateFormat("MM/dd/yyyy");

		if(!(publishDate==null)){

			strDate=dateFormat.format(publishDate);

		}

		this.publishDate = strDate;

	}

	public String getPublishOwner() {

		return publishOwner;

	}

	public void setPublishOwner(String publishOwner) {

		this.publishOwner = publishOwner;

		

	}

	public String getDocName() {

		return m_StrDocName;

	}

	public void setDocName(String strDocName) {

		m_StrDocName = strDocName;

	}

	

}

