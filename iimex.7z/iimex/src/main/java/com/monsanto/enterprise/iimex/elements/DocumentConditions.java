/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.elements;



import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DocumentConditions {

	protected boolean hasBlob;

	protected String documentCode;

	protected String docName;

	protected String typeRequirement;

	protected String specialReq;

	protected String buyerSeller;

	protected String fromcountry="";

	protected String toCountry="";

	protected String origincountry="";

	protected String fromcustomsZone="";
	
	protected String zoneOrigin="";

	protected String toCustZone="";

	protected String productGroup="";
	
	protected String division="";
	
	protected String trait="";
	
	protected String comments="";
	
	protected String whenSent;
	
	protected String whereSent="";
	
	protected String shippingMethod="";

	protected String transpMode="";

	protected String incoterms="";

	protected int docConditionCode;

	protected String fromCountryLong="";

	protected String toCountryLong="";

	protected String fromCustomZoneLong="";

	protected String countryOriginLong="";
	
	protected String zoneOriginLong="";

	protected String toCustomZoneLong="";

	protected String divisionLong="";
	
	protected String productLong="";
	
	protected String traitLong="";

	protected String transportLong="";

	protected String publishOwner="";

	protected String publishDate="";

    protected String incotermsDescr;

	

	public String getBuyerSeller() {

		return buyerSeller;

	}

	public void setBuyerSeller(String buyerSeller) {

			this.buyerSeller = buyerSeller;	

	}

	public String getToCustZone() {

		return toCustZone;

	}

	public void setCocustZone(String cocustZone) {

		if(!StringUtils.isNullOrEmpty(cocustZone)){

			this.toCustZone = cocustZone;

		}

	

	}

	public String getDocumentCode() {

		return documentCode;

	}

	public void setDocumentCode(String documentCode) {

		this.documentCode = documentCode;

	}

	public String getFromcountry() {

		

		return fromcountry;

	}

	public void setFromcountry(String fromcountry) {

		if(!StringUtils.isNullOrEmpty(fromcountry)){

			this.fromcountry = fromcountry;

		}

		

	}

	public String getFromcustomsZone() {

		return fromcustomsZone;

	}

	public void setFromcustomsZone(String fromcustomsZone) {

		if(!StringUtils.isNullOrEmpty(fromcustomsZone)){

			this.fromcustomsZone = fromcustomsZone;

		}

	

	}

	public String getIncoterms() {

		return incoterms;

	}

	public void setIncoterms(String incoterms) {

		if(!StringUtils.isNullOrEmpty(incoterms)){

			this.incoterms = incoterms;

		}

		

	}

	public String getProductGroup() {

		return productGroup;

	}

	public void setProductGroup(String productGroup) {

		if(!StringUtils.isNullOrEmpty(productGroup)){

			this.productGroup = productGroup;

		}

		

	}

	public String getSpecialReq() {

		return specialReq;

	}

	public void setSpecialReq(String specialReq) {

		this.specialReq = specialReq;

	}

	public String getToCountry() {

		return toCountry;

	}

	public void setToCountry(String toCountry) {

		if(!StringUtils.isNullOrEmpty(toCountry)){

			this.toCountry = toCountry;

		}

	}

	public String getTranspMode() {

		return transpMode;

	}

	public void setTranspMode(String transpMode) {

		if(!StringUtils.isNullOrEmpty(transpMode)){

			this.transpMode = transpMode;

		}

		

	}

	public String getZoneOrigin() {

		

		return zoneOrigin;

	}

	public void setZoneOrigin(String zoneOrigin) {

		if(!StringUtils.isNullOrEmpty(zoneOrigin)){

			this.zoneOrigin = zoneOrigin;

		}

		

	}

	public String getDocName() {

		return docName;

	}

	public void setDocName(String docName) {

		this.docName = docName;

	}

	public void setToCustZone(String toCustZone) {

		if(!StringUtils.isNullOrEmpty(toCustZone)){

			this.toCustZone = toCustZone;

		}

	

	}

	public String getTypeRequirement() {

		return typeRequirement;

	}

	public void setTypeRequirement(String typeRequirement) {

		this.typeRequirement = typeRequirement;

	}

	public void setHasBlob(String blob){

		if(blob.equalsIgnoreCase("Y")){

			this.hasBlob=true;

		}

	}

	

	public boolean isBlob(){

		return hasBlob;

	}

	public void setDocConditionCode(int documentConditionCode) {

		this.docConditionCode =documentConditionCode;

		

	}

	

	public int getDocConditionCode(){

		return this.docConditionCode;

	}

	public void setFromCountryNameLong(String countryName) {

		this.fromCountryLong = countryName;

		

	}

	

	public String getFromCountryLong(){

		return fromCountryLong;

	}

	public void setToCountryNameLong(String countryName) {

		this.toCountryLong = countryName;

		

	}

	public String getToCountryLong(){

		return toCountryLong;

	}

	public void setProductGroupLong(String productName) {

		this.productLong=productName;

		

	}

	public String getProductNameLong(){

		return productLong;

	}
	
	public void setCountryOriginLong(String countryName) {
		this.countryOriginLong=countryName;		
	}
	public String getCountryOriginLong(){
		return countryOriginLong;
	}
	
	public void setDivisionLong(String division) {
		this.divisionLong=division;
	}
	public String getDivisionLong(){
		return divisionLong;
	}
	
	public void setTraitLong(String traitName) {
		this.traitLong=traitName;
	}
	public String getTraitLong(){
		return traitLong;
	}

	public void setFromCustomZoneLong(String fromCustomZone){

		this.fromCustomZoneLong=fromCustomZone;

	}

	

	public String getFromCustomZoneLong(){

		return this.fromCustomZoneLong;

	}



	public void setToCustomZoneLong(String toCustomZone){

		this.toCustomZoneLong=toCustomZone;

	}

	

	public String getToCustomZoneLong(){

		return this.toCustomZoneLong;

	}

	

	public void setZoneOriginLong(String zoneOrigin){

		this.zoneOriginLong=zoneOrigin;

	}

	public String getZoneOriginLong(){

		return this.zoneOriginLong;

	}

	

	public void setTransportLong(String transportIncoterm){

		this.transportLong=transportIncoterm;

	}

	

	public String getTransportLong(){

		return this.transportLong;

	}

	

	public void setPublishOwner(String string) {

		this.publishOwner=string;

		

	}

	public String getPublishOwner(){

		return this.publishOwner;

	}

	

	public String getPublishDate() {	

		return publishDate;

	}

	public void setPublishDate(Date publishDate) throws IIMexException{

		String strDate="";

		DateFormat dateFormat =new SimpleDateFormat("MM/dd/yyyy");
if (publishDate != null){
    try {
      strDate=dateFormat.format(publishDate);
    } catch (Exception e) {
      e.printStackTrace();
      throw new IIMexException("Error in parsing publishDate for Document Conditions", e);
    }

    this.publishDate = strDate;
  }else this.publishDate = "";

	}
	
	public String getWhenSent() {	
		return whenSent;
	}
	public void setWhenSent(String when) {
		whenSent = when;
	}
	
	public void setComments(String comm) {
		comments=comm;
	}
	public String getComments(){
		return comments;
	}
	
	public void setWhereSent(String where) {
		whereSent=where;
	}

	public String getWhereSent(){
		return whereSent;
	}
	
	public void setShippingMethod(String meth) {
		shippingMethod=meth;
	}
	public String getShippingMethod(){
		return shippingMethod;
	}
	
	public void setOriginCountry(String country) {
		origincountry=country;
	}
	public String getOriginCountry(){
		return origincountry;
	}
	
	public void setDivision(String div) {
		division=div;
	}
	public String getDivision(){
		return division;
	}
	
	public void setTrait(String tr) {
		trait=tr;
	}
	public String getTrait(){
		return trait;
	}

    public String getIncotermsDescr() {
        return incotermsDescr;
    }
    public void setIncotermsDescr(String incotermsDescr) {
        this.incotermsDescr = incotermsDescr;
    }

}

