package com.monsanto.enterprise.iimex.elements;

import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;

import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.tableloader.TableGetDocument;

public class Documents {

	protected int iDocCode;
	protected String sDocName;
	protected String sTypeRequirement;
	protected String purpose;
	protected boolean active=false;
	protected boolean hasBlob =false;
	protected boolean hasReq=false;
	protected boolean notNewDoc=false;
	protected String publishOwner;
	protected String publishDate;
	protected String fileName;
	
	/**
	 * HashMap with all the documents conditions for this kind of document. Key int that i
	 */
	//protected Vector documentConditions; 
	protected HashMap<Integer,DocumentConditions> hmDocumentConditions;
	
	public int getIDocCode() {
		return iDocCode;
	}
	public String getDocCode() {
		return String.valueOf(iDocCode);
	}
	public void setIDocCode(int docCode) {
		iDocCode = docCode;
	}
	
	public String getSDocName() {
		return sDocName;
	}
	public void setSDocName(String docName) {
		sDocName = docName;
	}
	
	
	public String getSTypeRequirement() {
		return sTypeRequirement;
	}
	public void setSTypeRequirement(String typeRequirement) {
		sTypeRequirement = typeRequirement;
	}
	public Collection<DocumentConditions> getDocumentConditions() {
		if(hmDocumentConditions!=null)
			return hmDocumentConditions.values();
		return null;
	}
	public HashMap<Integer,DocumentConditions> getDocumentConditionHM(){
		return hmDocumentConditions;
	}
	
	public void setDocumentConditionsHM(HashMap<Integer,DocumentConditions> docConditionsHM){
		this.hmDocumentConditions = docConditionsHM;
	}
	
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	 public void setFlag(String flag) {
		if(flag.equalsIgnoreCase("Y")){
			this.active=true;
		}
	}
	public boolean isActive(){
		return active;
	}
	
	public void setHasBlob(String blob){
		if(blob.equalsIgnoreCase("Y")){
			this.hasBlob=true;
		}
	}
	
	public boolean isBlob(){
		return hasBlob;
	}
	public void setHasReq(boolean req ){
		this.hasReq =req;
	}
	public boolean isReq(){
		return this.hasReq;
	}
	public boolean isNotNewDoc(){
		return this.notNewDoc;
	}
	
	public void setNotNewDoc(boolean notNewDoc){
		this.notNewDoc=notNewDoc;
	}
	public void setPublishOwner(String string) {
		this.publishOwner=string;
		
	}
	public String getPublishOwner(){
		return this.publishOwner;
	}
	
	public String getPublishDate() {	
		return publishDate;
	}
	public void setPublishDate(Date publishDate) {
		String strDate="";
		DateFormat dateFormat =new SimpleDateFormat("MM/dd/yyyy");
		strDate=dateFormat.format(publishDate);
		this.publishDate = strDate;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	public String getFileName(){	
		return fileName;
	}
	public InputStream getDocument() 
	throws IIMexException{
		TableGetDocument documentGetter = new TableGetDocument();
		return documentGetter.getDocumentReq(this.iDocCode);
	}
	public DocumentConditions getDocumentConditionHM(String docCondId) 
	throws IIMexException{
		
		return hmDocumentConditions.get(Integer.parseInt(docCondId));
	}
}
