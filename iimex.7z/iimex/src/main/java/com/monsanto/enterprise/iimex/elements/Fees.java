package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
//defined for a shipping country
public class Fees {

  protected String certificateOfOrigin = IIMexConstants.NO_DATA;
	protected String consular = IIMexConstants.NO_DATA;
	protected String federalSeedLab = IIMexConstants.NO_DATA;
	protected String handling = IIMexConstants.NO_DATA;
	protected String insurance = IIMexConstants.NO_DATA;
	protected String legalization = IIMexConstants.NO_DATA;
	protected String phytosanitaryCertificate = IIMexConstants.NO_DATA;
	protected String seedAnalysisCertificate = IIMexConstants.NO_DATA;
	protected String inspection = IIMexConstants.NO_DATA;
	protected String other = IIMexConstants.NO_DATA;
	protected boolean exist = false;
	protected String publishOwner;
	protected Date publishDate;

	public void setCertificateOfOrigin(String certificateOfOrigin){
		this.certificateOfOrigin=certificateOfOrigin;
	}
	public void setConsular(String consular){
		this.consular=consular;
	}
	public void setFederalSeedLab(String federalSeedLab){
		this.federalSeedLab=federalSeedLab;
	}
	public void setHandling(String handling){
		this.handling=handling;
	}
	public void setInsurance(String insurance){
		this.insurance=insurance;
	}
	public void setLegalization(String legalization){
		this.legalization=legalization;
	}
	public void setPhytosanitaryCertificate(String phytosanitaryCertificate){
		this.phytosanitaryCertificate=phytosanitaryCertificate;
	}
	public void setSeedAnalysisCertificate(String seedAnalysisCertificate){
		this.seedAnalysisCertificate=seedAnalysisCertificate;
	}
	public void setInspection(String inspection){
		this.inspection=inspection;
	}
	public void setOther(String other){
		this.other=other;
	}
	public void setExist(boolean exist){
		this.exist=exist;
	}
	public void setPublishOwner(String publishOwner){
		this.publishOwner=publishOwner;
	}
	public void setPublishDate(Date publishDate){
		this.publishDate=publishDate;
	}
	
	public String getCertificateOfOrigin(){
		return certificateOfOrigin;
	}
	public String getConsular(){
		return consular;
	}
	public String getFederalSeedLab(){
		return federalSeedLab;
	}
	public String getHandling(){
		return handling;
	}
	public String getInsurance(){
		return insurance;
	}
	public String getLegalization(){
		return legalization;
	}
	public String getPhytosanitaryCertificate(){
		return phytosanitaryCertificate;
	}
	public String getSeedAnalysisCertificate(){
		return seedAnalysisCertificate;
	}
	public String getInspection(){
		return inspection;
	}
	public String getOther(){
		return other;
	}
	public boolean getExist(){
		return exist;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
}
