package com.monsanto.enterprise.iimex.elements;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Oct 13, 2009
 * Time: 10:52:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class IIMEXObjectVersion implements Comparable<IIMEXObjectVersion>{
    private int updateOrderIndex=100;
    private String objectId;

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public int getUpdateOrderIndex() {
        return updateOrderIndex;
    }

    public void setUpdateOrderIndex(int updateOrderIndex) {
        this.updateOrderIndex = updateOrderIndex;
    }

    public long getLocalVersionNumber() {
        return localVersionNumber;
    }

    public void setLocalVersionNumber(long localVersionNumber) {
        this.localVersionNumber = localVersionNumber;
    }

    public long getServerVersionNumber() {
        return serverVersionNumber;
    }

    public void setServerVersionNumber(long serverVersionNumber) {
        this.serverVersionNumber = serverVersionNumber;
    }

    private long localVersionNumber;
    private long serverVersionNumber;

    public boolean hasChanged(){
        return serverVersionNumber > localVersionNumber;
    }

    public int compareTo(IIMEXObjectVersion o) {
       return updateOrderIndex - o.getUpdateOrderIndex();
    }

    public void refresh() {
       localVersionNumber = serverVersionNumber;        
    }

    public void forceReload() {
      localVersionNumber = serverVersionNumber-1;         
    }
}
