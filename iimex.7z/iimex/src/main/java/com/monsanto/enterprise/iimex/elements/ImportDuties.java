package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;

/*
 * defined for a product group, a zone of origin and a zone of destination
 * or a product group, a country of origin and a zone of destination
 * or a product group, a zone of origin and a country of destination
 * or a product group, a country of origin and a country of destination
 */
public class ImportDuties{
	protected String zoneOrigin;
	protected String countryOrigin;
	protected String zoneDestination;
	protected String countryDestination;
	protected String htsCode;
	protected String importDuties = IIMexConstants.NO_DATA;
	protected String publishOwner = "";
	protected Date publishDate = new Date();
	
	public String getZoneOrigin(){
		return zoneOrigin;
	}
	public String getCountryOrigin(){
		return countryOrigin;
	}
	public String getZoneDestination(){
		return zoneDestination;
	}
	public String getCountryDestination(){
		return countryDestination;
	}
	public String getImportDuties(){
		return importDuties;
	}
	public String gethtsCode(){
		return htsCode;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
	
	public void setZoneOrigin(String origin){
		zoneOrigin = origin;
	}
	public void setCountryOrigin(String origin){
		countryOrigin = origin;
	}
	public void setZoneDestination(String destination){
		zoneDestination = destination;
	}
	public void setCountryDestination(String destination){
		countryDestination = destination;
	}
	public void setImportDuties(String importDuties){
		this.importDuties = importDuties;
	}
	public void setHtsCode(String htsCode){
		this.htsCode = htsCode;
	}
	public void setPublishOwner(String owner){
		publishOwner = owner;
	}
	public void setPublishDate(Date date){
		publishDate = date;
	}
}