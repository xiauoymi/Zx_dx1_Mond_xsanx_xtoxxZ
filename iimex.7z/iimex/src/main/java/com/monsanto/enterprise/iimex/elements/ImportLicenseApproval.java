package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
//defined for a product group and a destination country
public class ImportLicenseApproval{

	
	protected String importLicenseApproval = IIMexConstants.NO_DATA;
	protected String hts;
	protected String publishOwner;
	protected Date publishDate;
	
	public void setImportLicenseApproval(String importLicense) {
		this.importLicenseApproval = importLicense;
	}
	public void setPublishOwner(String publishOwner) {
		this.publishOwner = publishOwner;
	}
	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}
	
	public String getHTS(){
		return hts;
	}
	public void setHTS(String h){
		hts=h;
	}
	public String getImportLicenseApproval() {
		return importLicenseApproval;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
}
