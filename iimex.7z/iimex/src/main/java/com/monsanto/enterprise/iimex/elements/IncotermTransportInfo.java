package com.monsanto.enterprise.iimex.elements;

import java.util.Date;

/*
 * Incoterm and transport mode info
 */
public class IncotermTransportInfo {

	protected String sIncotermsCode;
	protected String sIncotermDescr;
	protected String sDuties;
	protected String sFreight;
	protected String sInsurance;
	protected String transportCode;
	protected String transportName;
	protected String publishOwner;
	protected Date publishDate;
	
	
	public String getTransportCode() {
		return transportCode;
	}
	public void setTransportCode(String transportCode) {
		this.transportCode = transportCode;
	}
	public String getTransportName() {
		return transportName;
	}
	public void setTransportName(String transportName) {
		this.transportName = transportName;
	}
	public String getSDuties() {
		return sDuties;
	}
	public void setSDuties(String duties) {
		sDuties = duties;
	}
	public String getSInsurance() {
		return sInsurance;
	}
	public void setSInsurance(String insurance) {
		sInsurance = insurance;
	}
	public String getSFreight() {
		return sFreight;
	}
	public void setSFreight(String freight) {
		sFreight = freight;
	}
	public String getSIncotermDescr() {
		return sIncotermDescr;
	}
	public void setSIncotermDescr(String incotermDescr) {
		sIncotermDescr = incotermDescr;
	}
	public String getIncotermsCode() {
		return sIncotermsCode;
	}
	public void setSIncotermsCode(String incotermsCode) {
		sIncotermsCode = incotermsCode;
	}
	public String getIncotermTransportName(){
		return this.transportName+" - "+this.sIncotermDescr;
		
	}
	public void setPublishOwner(String publish) {
		publishOwner = publish;
	}
	public String getPublishOwner(){
		return publishOwner;
		
	}
	public void setPublishDate(Date publish) {
		publishDate = publish;
	}
	public Date getPublishDate(){
		return publishDate;
		
	}
	public String getIncotermTransportInfo(){
		return this.transportCode+" - "+this.sIncotermsCode;
	}
}
