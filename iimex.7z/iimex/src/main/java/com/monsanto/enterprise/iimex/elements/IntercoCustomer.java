/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.elements;



public class IntercoCustomer {

 

	protected String strCustomerCode;

	protected String strCustomerName;

	protected String strCountryCode;

	protected String strCompanyCode;

	protected String strSalesOrgCode;

	protected String strDistChannelCode;

	protected String strDivisionCode;

	protected String strAccountAssignGroup;

	protected String strCurrencyCode;

	

	public String getAccountAssignGroup() {

		return strAccountAssignGroup;

	}

	

	public void setAccountAssignGroup(String accountAssignGroup) {

		this.strAccountAssignGroup = accountAssignGroup;

	}

	

	public String getCurrencyCode() {

		return strCurrencyCode;

	}

	

	public void setCurrencyCode(String currencyCode) {

		this.strCurrencyCode = currencyCode;

	}

	

	public String getDivisionCode() {

		return strDivisionCode;

	}

	

	public void setDivisionCode(String divisionCode) {

		this.strDivisionCode = divisionCode;

	}

	

	public String getCompanyCode() {

		return strCompanyCode;

	}

	

	public void setCompanyCode(String strCompanyCode) {

		this.strCompanyCode = strCompanyCode;

	}

	

	public String getCountryCode() {

		return strCountryCode;

	}

	

	public void setCountryCode(String strCountryCode) {

		this.strCountryCode = strCountryCode;

	}

	

	public String getCustomerCode() {

		return strCustomerCode;

	}

	

	public void setCustomerCode(String strCustomerCode) {

		this.strCustomerCode = strCustomerCode;

	}

	

	public String getCustomerName() {

		return strCustomerName;

	}

	

	public void setCustomerName(String strCustomerName) {

		this.strCustomerName = strCustomerName;

	}

	

	public String getDistChannelCode() {

		return strDistChannelCode;

	}

	

	public void setDistChannelCode(String strDistChannelCode) {

		this.strDistChannelCode = strDistChannelCode;

	}

	

	public String getSalesOrgCode() {

		return strSalesOrgCode;

	}

	

	public void setSalesOrgCode(String strSalesOrgCode) {

		this.strSalesOrgCode = strSalesOrgCode;

	}

	

	

}

