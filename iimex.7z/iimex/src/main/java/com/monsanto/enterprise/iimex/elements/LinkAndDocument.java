/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.elements;



import java.util.Collection;

import java.util.HashMap;

import java.util.Vector;



import com.monsanto.enterprise.iimex.IIMexException;



public class LinkAndDocument {

	/**

	 * hmUrl contains all the Url for this link

	 */

	protected HashMap <Integer,Url> hmUrl;

	/**

	 * hmDoc contains all the Doc for this link

	 */

	protected HashMap <Integer,DocLink> hmDoc;

	/**

	 * True if this link has at least one URL

	 */

	protected boolean hasUrl = false;

	/**

	 * True if this link has at least one doc

	 */

	protected boolean hasDoc = false;

	/**

	 * True if the link is active

	 */

	protected boolean active = true;

	/**

	 * Link Id in the db

	 */

	protected int linkId;

	/**

	 * Link name

	 */

	protected String linkName;

	/**

	 * Link description

	 */

	protected String linkDescription;

	

	public void LinkAndDocument(){

		HashMap<Integer,Url> hmUrl = new HashMap<Integer,Url>();

		HashMap<Integer,DocLink> hmDoc= new HashMap<Integer,DocLink>();

	}

	

	public boolean getHasDoc() {

		return hasDoc;

	}

	public void setHasDoc(boolean hasDoc) {

		this.hasDoc = hasDoc;

	}

	public boolean getHasUrl() {

		return hasUrl;

	}

	public void setHasUrl(boolean hasUrl) {

		this.hasUrl = hasUrl;

	}

	public Collection getDocCollection() {

		return hmDoc.values();

	}

	public void setDocCollection(HashMap hmDoc) {

		this.hmDoc = hmDoc;

	}

	public Collection getUrlCollection() {

		return hmUrl.values();

	}

	public void setUrlCollection(HashMap hmUrl) {

		this.hmUrl = hmUrl;

	}

	public String getLinkDescription() {

		return linkDescription;

	}

	public void setLinkDescription(String linkDescription) {

		this.linkDescription = linkDescription;

	}

	public int getLinkId() {

		return linkId;

	}

	public void setLinkId(int linkId) {

		this.linkId = linkId;

	}

	public String getLinkName() {

		return linkName;

	}

	public void setLinkName(String linkName) {

		this.linkName = linkName;

	}



	public void addUrl(int urlId, Url linkUrl) {

		if(hmUrl==null){

			 hmUrl = new HashMap<Integer,Url>();

		}

		hmUrl.put(new Integer(urlId), linkUrl);



	}



	public void addDoc(int docId, DocLink linkDoc) {

		if(hmDoc==null){

			hmDoc = new HashMap<Integer, DocLink>();

		}

		hmDoc.put(new Integer(docId), linkDoc);

	}

	

	public DocLink getDocLink(String docId)

	throws IIMexException{

		DocLink docLink = hmDoc.get(new Integer(docId));

		return docLink;

	}



	public boolean isActive() {

		return active;

	}



	public void setActive(boolean active) {

		this.active = active;

	}



	public Url getUrl(String urlId)

	throws IIMexException {

		Url url = hmUrl.get(new Integer(urlId));

		return url;

	}



	public void removeUrl(String urlId) 

	throws IIMexException {

		Object obj = hmUrl.remove(Integer.parseInt(urlId));	

	}



	

	

}

