package com.monsanto.enterprise.iimex.elements;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;

public class MonitoredUser{
	private String name;
	private Vector connections = null;
	private Date[] last = null;
	private Date min;
	int nbMonth;
	Calendar minCal;
	public MonitoredUser(){
		;
	}
	
	public void setName(String n){name=n;}
	public String getName(){return name;}
	
	public void setMin(Date d){
		min=d;
		TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
		Locale loc = Locale.FRANCE;
		Calendar nowCal = Calendar.getInstance(tz,loc);
		
		minCal = Calendar.getInstance();
		minCal.setTime(min);
		
		nowCal.getTime().toString();
		minCal.getTime().toString();
		nbMonth = ((nowCal.get(Calendar.YEAR) - minCal.get(Calendar.YEAR))*12) + (nowCal.get(Calendar.MONTH) - minCal.get(Calendar.MONTH));
	}
	public Date getMin(){return min;}
	
	public void setConnections(Vector c){connections=c;}
	public Vector getConnections(){return connections;}
	public void addConnection(Date d){
		if(connections==null)
			connections = new Vector(); 
		connections.add(d);
	}
	
	public void setLasts(Date[] l){
		last=l;
	}
	
	public Date getLast1(){
		return last[0];
	}
	
	public int getNbMonth(){return nbMonth;}
	
	public Date getLast2(){
		return last[1];
	}
	
	public Date getLast3(){
		return last[2];
	}
	
	public int[] getStat(){		
		
		int[] stat= new int[nbMonth+1];
		
		for(int i = 0 ; i <= nbMonth ; i++)
			stat[i]=0;
		
		Iterator ite = connections.iterator();
		Calendar tmp = Calendar.getInstance();
		while(ite.hasNext()) {
			tmp.setTime((Date)ite.next());
			stat[((tmp.get(Calendar.YEAR) - minCal.get(Calendar.YEAR))*12) + (tmp.get(Calendar.MONTH) - minCal.get(Calendar.MONTH))]++;
		}
		
		return stat;
	}
	
}