package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
//defined for a shpping country, a destunation one and a product group
public class PhytoRequirement{
	
	protected String plantID;
	protected String micCode;
	protected String micDescription = IIMexConstants.NO_DATA;
	protected String publishOwner;
	protected Date publishDate;
    protected String infoField;
	
	public void setPlantID(String plant){
		plantID = plant;
	}
	public void setMicCode(String code){
		micCode = code;
	}
	public void setMicDescription(String description){
		micDescription = description;
	}
	public void setPublishOwner(String owner){
		publishOwner = owner;
	}
	public void setPublishDate(Date date){
		publishDate = date;
	}

    public void setInfoField(String info){
		infoField = info;
	}

	public String getPlantID(){return plantID;}
	public String getMicCode(){return micCode;}
	public String getMicDescription(){return micDescription;}
	public String getPublishOwner(){return publishOwner;}
	public Date getPublishDate(){return publishDate;}
    public String getInfoField(){return infoField;}
	
}