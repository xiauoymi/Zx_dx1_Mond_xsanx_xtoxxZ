package com.monsanto.enterprise.iimex.elements;

import java.util.Date;
import java.util.HashMap;
//defined for a division and a country
public class PlantsFromCountry {

	protected String m_strCodeFromCountry;
	protected String m_strNameFromCountry;
	protected String m_strCodePlant;
	protected String m_strPlantName;
	protected String m_strDivision;
	protected String m_strPlantName2;
	protected String m_strPlantCompanyCode;
	protected String m_strPlantCompanyName;
	protected String m_strComments;
	protected String m_strPublishOwner;
	protected Date m_strPublishDate;
	protected HashMap division;
	protected boolean active;
	
	
	public boolean isActive() {
		return active;
	}
	public boolean getActive() {
		return active;
	}
	public void setActive(boolean active) {
		this.active = active;
	}
	public String getM_strPlantCompanyCode() {
		return m_strPlantCompanyCode;
	}
	
	public void setM_strPlantCompanyCode(String plantCompany) {
		m_strPlantCompanyCode = plantCompany;
	}
	public String getM_strPlantCompanyName() {
		return m_strPlantCompanyName;
	}
	
	public void setM_strPlantCompanyName(String plantCompany) {
		m_strPlantCompanyName = plantCompany;
	}
	public String getM_strPlantName2() {
		return m_strPlantName2;
	}
	public void setM_strPlantName2(String plantName2) {
		m_strPlantName2 = plantName2;
	}
	public String getCodeFromCountry() {
		return m_strCodeFromCountry;
	}
	public void setCodeFromCountry(String codeFromCountry) {
		m_strCodeFromCountry = codeFromCountry;
	}
	public String getNameFromCountry() {
		return m_strNameFromCountry;
	}
	public void setNameFromCountry(String nameFromCountry) {
		m_strNameFromCountry = nameFromCountry;
	}
	public String getCodePlant() {
		return m_strCodePlant;
	}
	
	public String getPlantCompanyCode() {
		return m_strPlantCompanyCode;
	}
	public String getPlantCompanyName() {
		return m_strPlantCompanyName;
	}
	public void setCodePlant(String codePlant) {
		m_strCodePlant = codePlant;
	}
	public String getPlantName() {
		return m_strPlantName;
	}
	public void setPlantName(String plantName) {
		m_strPlantName = plantName;
	}

	public HashMap getDivision() {
		if(division!=null)
			return division;
		return new HashMap();
	}
	public void setDivision(HashMap division) {
		this.division = division;
	}
	
	public String getComments(String div) {
		return (String)division.get(div);
	}
	
	public void setComments(String div, String comments) {
		division.put(div,comments);
	}
	
	public String getPublishOwner() {
		return m_strPublishOwner;
	}
	
	public Date getPublishDate() {
		return m_strPublishDate;
	}
	
	public void setPublishOwner(String owner) {
		m_strPublishOwner = owner;
	}
	
	public void setPublishDate(Date date) {
		m_strPublishDate = date;
	}
}
