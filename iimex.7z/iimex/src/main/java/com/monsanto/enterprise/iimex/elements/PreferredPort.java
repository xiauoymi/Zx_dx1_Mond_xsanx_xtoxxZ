package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
//defined for a shipping country, a destination one and a division
public class PreferredPort{
	private String destCountryCode;
	private String destCountryName;
	private String division;
	private String port = IIMexConstants.NO_DATA;
	private String owner;
	private Date date;
	
	public void setDestCountryCode(String code){destCountryCode = code;}
	public void setDestCountryName(String name){destCountryName = name;}
	public void setDivision(String div){division = div;}
	public void setPort(String por){port = por;}
	public void setOwner(String o){owner = o;}
	public void setDate(Date d){date = d;}
	
	public String getDestCountryCode(){return destCountryCode;}
	public String getDestCountryName(){return destCountryName;}
	public String getDivision(){return division;}
	public String getPort(){return port;}
	public String getOwner(){return owner;}
	public Date getDate(){return date;}
	
}