package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

public class PricingCurrency {
	//a currency is defined for a destination country and an exception is also defined for a shipping one
	protected String sFromCountry;
	protected String sToCountry;
	protected String sIntercoCurrency = IIMexConstants.NO_DATA;
	protected String sSalesCurrency = IIMexConstants.NO_DATA;
	
	public String getFromCountry() {
		return sFromCountry;
	}
	public void setSFromCountry(String fromCountry) {
		sFromCountry = fromCountry;
	}
	public String getSalesCurrency() {
		return sSalesCurrency;
	}
	public void setSSalesCurrency(String salesCurrency) {
		sSalesCurrency = salesCurrency;
	}
	public String getIntercoCurrency() {
		return sIntercoCurrency;
	}
	public void setSIntercoCurrency(String currency) {
		sIntercoCurrency = currency;
	}
	public String getToCountry() {
		return sToCountry;
	}
	public void setSToCountry(String toCountry) {
		sToCountry = toCountry;
	}
	
	

}
