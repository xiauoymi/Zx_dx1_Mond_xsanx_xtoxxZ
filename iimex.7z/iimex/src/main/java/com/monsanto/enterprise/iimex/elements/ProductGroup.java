package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
//a product group is part of a division
public class ProductGroup {

	
	protected String m_strProductGroupCode;
	protected String m_strProductGroupName;
	protected String m_strDivisionCode;
	protected String m_strHTSCode = IIMexConstants.NO_DATA;
	protected String m_strBotanicalName = IIMexConstants.NO_DATA;
	protected String m_strPublishOwner;
	protected Date m_strPublishDate;
	
	
	
	public String getProductGroupCode() {
		return m_strProductGroupCode;
	}
	public void setProductGroupCode(String productGroupCode) {
		m_strProductGroupCode = productGroupCode;
	}
	public String getProductGroupName() {
		return m_strProductGroupName;
	}
	public void setProductGroupName(String productGroupName) {
		m_strProductGroupName = productGroupName;
	}
	public String getDivisionCode() {
		return m_strDivisionCode;
	}
	public void setDivisionCode(String divisionCode) {
		m_strDivisionCode = divisionCode;
	}
	
	public String getHTSCode() {
		return m_strHTSCode;
	}
	public void setHTSCode(String HTSCode) {
		m_strHTSCode = HTSCode;
	}
	
	public String getBotanicalName() {
		return m_strBotanicalName;
	}
	public void setBotanicalName(String botanicalName) {
		m_strBotanicalName = botanicalName;
	}
	
	public String getPublishOwner() {
		return m_strPublishOwner;
	}
	public void setPublishOwner(String publishOwner) {
		m_strPublishOwner = publishOwner;
	}
	
	public Date getPublishDate() {
		return m_strPublishDate;
	}
	public void setPublishDate(Date publishDate) {
		m_strPublishDate = publishDate;
	}
	
}
