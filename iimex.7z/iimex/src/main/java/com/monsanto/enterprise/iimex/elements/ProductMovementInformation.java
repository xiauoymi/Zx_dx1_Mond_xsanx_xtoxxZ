package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.collections.IncotermsTransportCollection;

import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Oct 1, 2009
 * Time: 9:38:53 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductMovementInformation {

    private HashMap<String, List<ShippingRestriction>> countryRestrictions = new HashMap<String, List<ShippingRestriction>>(INITIAL_LIST_SIZE);
    private HashMap<String, List<PreferredPort>> preferredPorts = new HashMap<String, List<PreferredPort>>(INITIAL_LIST_SIZE);
    private HashMap<String, List<TransportationTime>> preferredTransportTimes = new HashMap<String, List<TransportationTime>>(INITIAL_LIST_SIZE);
    private static final int INITIAL_LIST_SIZE = 113;

    public HashMap<String, List<ShippingRestriction>> getCountryRestrictions() {
        return countryRestrictions;
    }

    public void addCountryRestriction(String fromCountryCode, String toCountryCode, ShippingRestriction restrictionCode){
    String keyCode = fromCountryCode+"_"+toCountryCode;
    List<ShippingRestriction> restrictions = countryRestrictions.get(keyCode);
    if (restrictions==null){
        restrictions=new ArrayList<ShippingRestriction>();
        countryRestrictions.put(keyCode, restrictions);
    }
    restrictions.add(restrictionCode);
    }

    public void addPreferredPortForShipping(String fromCountryCode, String toCountryCode, PreferredPort preferredPort){

    String keyCode = fromCountryCode+"_"+toCountryCode;
    List<PreferredPort> restrictions = preferredPorts.get(keyCode);
    if (restrictions==null){
        restrictions=new ArrayList<PreferredPort>();
        preferredPorts.put(keyCode, restrictions);
    }
    restrictions.add(preferredPort);
    }

    public void addPreferredTransportTimesForShipping(String fromCountryCode, String toCountryCode, TransportationTime transportationTime){

    String keyCode = fromCountryCode+"_"+toCountryCode;
    List<TransportationTime> restrictions = preferredTransportTimes.get(keyCode);
    if (restrictions==null){
        restrictions=new ArrayList<TransportationTime>();
        preferredTransportTimes.put(keyCode, restrictions);
    }
    restrictions.add(transportationTime);
    }

    public HashMap<String, List<PreferredPort>> getPreferredPorts() {
        return preferredPorts;
    }

    public HashMap<String, List<TransportationTime>> getPreferredTransportTimes() {
        return preferredTransportTimes;
    }


    public Vector<ShippingRestriction> getRestrictionsBetweenCountries(String shippingCode, String destinationCode) {
        Vector<ShippingRestriction> v = new Vector<ShippingRestriction>();
        List<ShippingRestriction> rs = countryRestrictions.get(shippingCode+"_"+destinationCode);
        if (rs!=null){
            for(ShippingRestriction s:rs){
                v.add(s);
            }
        }
        return v;
    }

    public HashMap getPreferredPortsBetweenCountries(String shippingCode, String destinationCode, String destinationCountryName) {
       HashMap m = new HashMap();
        List<PreferredPort> ps = preferredPorts.get(shippingCode + "_" + destinationCode);
        if (ps!=null){
            for(PreferredPort p:ps){
                p.setDestCountryCode(destinationCode);
                p.setDestCountryName(destinationCountryName);
                m.put(p.getDivision(),p);
            }
        }
        return m;
    }

    public HashMap getPreferredTransportTimesBetweenCountries(String shippingCode, String destinationCode, String destinationCountryName,
                                                              IncotermsTransportCollection transportModeNames) {
       HashMap m = new HashMap();
        List<TransportationTime> ps = preferredTransportTimes.get(shippingCode + "_" + destinationCode);
        if (ps!=null){
            for(TransportationTime p:ps){
                p.setDestCountryCode(destinationCode);
                p.setDestCountryName(destinationCountryName);
                p.setTpModeName(transportModeNames.getTransport(p.getTpModeCode()).getTransportName());
                m.put(p.getTpModeCode(),p);
            }
        }
        return m;
    }
}
