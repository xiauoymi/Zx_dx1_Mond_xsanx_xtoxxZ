package com.monsanto.enterprise.iimex.elements;

import java.util.Date;
//product origin of a product group 
public class ProductOrigin {
	
	protected String m_strProductOriginCode;
	protected String m_strProductOriginName;
	
	
	public String getProductOriginCode() {
		return m_strProductOriginCode;
	}
	public void setProductOriginCode(String productOriginCode) {
		m_strProductOriginCode = productOriginCode;
	}
	public String getProductOriginName() {
		return m_strProductOriginName;
	}
	public void setProductOriginName(String productOriginName) {
		m_strProductOriginName = productOriginName;
	}
	
}
