package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
//shiiping instructions defined for a specific destination country
public class ShippingInstruction{
	
	protected String seedSamples = IIMexConstants.NO_DATA;
	protected String shippingInstructions = IIMexConstants.NO_DATA;
	protected String seedTreatment = IIMexConstants.NO_DATA;
	protected String miscallenous = IIMexConstants.NO_DATA;
	protected String packaging = IIMexConstants.NO_DATA;
	protected String division ="";
	protected String owner="";
	protected Date date=new Date();
	
	public void setSeedSamples(String seedSamples) {
		this.seedSamples = seedSamples;
	}
	public void setShippingInstructions(String shippingInstructions) {
		this.shippingInstructions = shippingInstructions;
	}
	public void setSeedTreatment(String seedTreatment) {
		this.seedTreatment = seedTreatment;
	}
	public void setMiscallenous(String miscallenous) {
		this.miscallenous = miscallenous;
	}
	public void setPackaging(String packaging) {
		this.packaging = packaging;
	}
	public void setDivision(String division) {
		this.division = division;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	public String getSeedSamples() {
		return seedSamples;
	}
	public String getShippingInstructions() {
		return shippingInstructions;
	}
	public String getSeedTreatment() {
		return seedTreatment;
	}
	public String getMiscallenous() {
		return miscallenous;
	}
	public String getPackaging() {
		return packaging;
	}
	public String getDivision() {
		return division;
	}
	public String getOwner() {
		return owner;
	}
	public Date getDate() {
		return date;
	}
	
}