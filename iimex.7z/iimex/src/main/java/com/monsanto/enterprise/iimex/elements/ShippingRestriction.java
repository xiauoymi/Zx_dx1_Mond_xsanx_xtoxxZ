package com.monsanto.enterprise.iimex.elements;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Oct 21, 2009
 * Time: 11:39:04 AM
 */
public class ShippingRestriction {
    private String comments; // restriction comments
    private String restrictionName;  // restrictionType name
    private String restrictionTypeCode;
    private String restrictionComments; // restrictionType comments
    private String origin;
    private String destination;
    private String productGroupCode;
    private String productGroupName;
    private String publishOwnerId;
    private Date publishDate;

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getRestrictionName() {
        return restrictionName;
    }

    public void setRestrictionName(String restrictionName) {
        this.restrictionName = restrictionName;
    }

    public String getRestrictionTypeCode() {
        return restrictionTypeCode;
    }

    public void setRestrictionTypeCode(String restrictionTypeCode) {
        this.restrictionTypeCode = restrictionTypeCode;
    }

    public String getRestrictionComments() {
        return restrictionComments;
    }

    public void setRestrictionComments(String restrictionComments) {
        this.restrictionComments = restrictionComments;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getProductCode() {
        return productGroupCode;
    }

    public void setProductCode(String productGroupCode) {
        this.productGroupCode = productGroupCode;
    }

    public String getProductGroupName() {
        return productGroupName;
    }

    public void setProductGroupName(String productGroupName) {
        this.productGroupName = productGroupName;
    }

    public String getPublishOwnerId() {
        return publishOwnerId;
    }

    public void setPublishOwnerId(String publishOwnerId) {
        this.publishOwnerId = publishOwnerId;
    }

    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }
}
