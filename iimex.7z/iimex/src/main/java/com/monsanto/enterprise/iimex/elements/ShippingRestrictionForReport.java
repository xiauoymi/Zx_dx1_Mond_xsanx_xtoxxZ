package com.monsanto.enterprise.iimex.elements;

/**
 * For reporting purposes, we want to get additional information that is not in the current restrictions query, because
 * that data gets cached into the country-to-country collection for 12000 or more records.
 * User: KBWELK
 * Date: Aug 30, 2010
 * Time: 2:52:38 PM
 */
public class ShippingRestrictionForReport extends ShippingRestriction {
    private String originCountryName;
    private String destinationCountryName;
    private String divisionName;

    public String getOriginCountryName() {
        return originCountryName;
    }

    public void setOriginCountryName(String orginCountryName) {
        this.originCountryName = orginCountryName;
    }

    public String getDestinationCountryName() {
        return destinationCountryName;
    }

    public void setDestinationCountryName(String destinationCountryName) {
        this.destinationCountryName = destinationCountryName;
    }

    public String getDivisionName() {
        return divisionName;
    }

    public void setDivisionName(String divisionName) {
        this.divisionName = divisionName;
    }
}
