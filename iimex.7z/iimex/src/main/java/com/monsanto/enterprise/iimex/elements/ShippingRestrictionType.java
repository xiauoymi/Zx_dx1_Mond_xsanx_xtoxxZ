package com.monsanto.enterprise.iimex.elements;

import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 16, 2010
 * Time: 3:57:13 PM
 */
public class ShippingRestrictionType {
    private String code;
    private String name;
    private String comments;
    private String publishOwnerId;
    private Date publishDate;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
    
    public String getPublishOwnerId() {
        return publishOwnerId;
    }

    public void setPublishOwnerId(String publishOwnerId) {
        this.publishOwnerId = publishOwnerId;
    }

    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }
}
