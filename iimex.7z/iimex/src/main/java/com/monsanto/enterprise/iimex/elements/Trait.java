package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
//a Trait is a part of a product group
public class Trait{
	protected String traitCode;
	protected String traitName = IIMexConstants.NO_DATA;
	protected String monNumber = IIMexConstants.NO_DATA;
	protected String productGroupCode;
	protected String OECDIdentifier = IIMexConstants.NO_DATA;
	protected String labOfficeCode;
	protected String publishOwner = "";
	protected Date publishDate = new Date();
	protected HashMap approved;
	
	public String getTraitCode(){
		return traitCode;
	}
	public String getTraitName(){
		return traitName;
	}
	public String getMonNumber(){
		return monNumber;
	}
	public String getProductGroupCode(){
		return productGroupCode;
	}
	public String getOECDIdentifier(){
		return OECDIdentifier;
	}
	public String getLabOfficeCode(){
		return labOfficeCode;
	}
	public HashMap getApproved(){
		if(approved!=null)
			return approved;
		return new HashMap();
	}
	public Vector getApprovedVector(){
		Iterator it = approved.keySet().iterator();
		Vector result = new Vector();
		while(it.hasNext()){
		 result.add((Approved)approved.get((String)it.next()));	
		}
		return result;
	}
	public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
	
	public void setTraitCode(String code){
		traitCode = code;
	}
	public void setMonNumber(String number){
		monNumber = number;
	}
	public void setTraitName(String name){
		traitName = name;
	}
	public void setProductGroupCode(String code){
		productGroupCode = code;
	}
	public void setOECDIdentifier(String identifier){
		OECDIdentifier = identifier;
	}
	public void setLabOfficeCode(String code){
		labOfficeCode = code;
	}
	public void setApproved(HashMap approved){
		this.approved = approved;
	}
	public void setPublishOwner(String owner){
		publishOwner = owner;
	}
	public void setPublishDate(Date date){
		publishDate = date;
	}
}