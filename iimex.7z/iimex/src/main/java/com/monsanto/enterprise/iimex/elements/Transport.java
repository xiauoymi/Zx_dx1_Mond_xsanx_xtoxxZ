package com.monsanto.enterprise.iimex.elements;
/*
 * Used to store transport name and code
 */
public class Transport{
	private String code;
	private String name;
	
	public void setCode(String c){code=c;}
	public String getCode(){return code;}
	public void setName(String n){name=n;}
	public String getName(){return name;}
}