package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
//Shipping instructions of a shipment, defined for shipping country, a destination one and a transport mode
public class TransportationTime{
	protected String destCountryCode;
	protected String destCountryName;
	protected String tpModeCode;
	protected String tpModeName;
	protected String freightBooking = IIMexConstants.NO_DATA;
	protected String transportationTime = IIMexConstants.NO_DATA;
	protected String publisOwner;
	protected Date publishDate;
	
	public void setFreightBooking(String freightBooking){
		this.freightBooking = freightBooking;
	}
	public void setTransportationTime(String transportationTime){
		this.transportationTime = transportationTime;
	}
	public void setPublishOwner(String publisOwner){
		this.publisOwner = publisOwner;
	}
	public void setPublishDate(Date publishDate){
		this.publishDate = publishDate;
	}
	public void setDestCountryCode(String code){
		this.destCountryCode = code;
	}
	public void setDestCountryName(String name){
		this.destCountryName = name;
	}
	public void setTpModeCode(String code){
		this.tpModeCode = code;
	}
	public void setTpModeName(String name){
		this.tpModeName = name;
	}
	
	public String getFreightBooking(){
		return freightBooking;
	}
	public String getTransportationTime(){
		return transportationTime;
	}
	public String getDestCountryCode(){
		return destCountryCode;
	}
	public String getDestCountryName(){
		return destCountryName;
	}
	public String getTpModeCode(){
		return tpModeCode;
	}
	public String getTpModeName(){
		return tpModeName;
	}
	public String getPublishOwner(){
		return publisOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
}


