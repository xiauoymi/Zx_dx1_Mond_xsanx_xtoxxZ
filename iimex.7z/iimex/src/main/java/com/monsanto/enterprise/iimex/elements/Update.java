package com.monsanto.enterprise.iimex.elements;

import java.sql.Date;

public class Update{
	private String owner=null;
	private String type=null;
	private Date date;
	
	public Update(){;}
	
	public String getOwner(){return owner;}
	public void setOwner(String o){owner=o;}
	
	public String getType(){return type;}
	public void setType(String t){type=t;}
	
	public Date getDate(){return date;}
	public void setDate(Date d){date=d;}
}