/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.elements;



import java.text.DateFormat;

import java.text.SimpleDateFormat;

import java.util.Calendar;

import java.util.Date;



/**

 * This object contains all the information about the url

 * 

 * Filename:    $RCSfile: Url.java,v $

 * Label:       $Name:  $

 * Last Change: $Author: mmcort3 $    	 On:	$Date: 2008/02/01 14:30:57 $

 * @version     $Revision: 1.1 $

 * @author      MMCORT3

 */

public class Url {



	/**

	 * UrlId in the database

	 */

	protected int urlId;

	/**

	 * UrlTitle to be show in the interface

	 */

	protected String m_strUrlTitle;

	/**

	 * Parent linkId in the database

	 */

	protected int linkId;

	/**

	 * Url description

	 */

	protected String m_strUrlDescription;

	/**

	 * Url address

	 */

	protected String m_strUrl;

	/**

	 * When the Url has been published

	 */

	protected String publishDate;

	/**

	 * Who is the person who has asked to publish the link

	 */

	protected String publishOwner;

	

	public String getUrl() {

		return m_strUrl;

	}

	public void setUrl(String url) {

		m_strUrl = url;

	}

	public String getUrlDescription() {

		return m_strUrlDescription;

	}

	public void setUrlDescription(String urlDescription) {

		m_strUrlDescription = urlDescription;

	}

	public int getUrlId() {

		return urlId;

	}

	public void setUrlId(int urlId) {

		this.urlId = urlId;

	}

	public String getUrlTitle() {

		return m_strUrlTitle;

	}

	public void setUrlTitle(String urlTitle) {

		m_strUrlTitle = urlTitle;

	}

	public int getLinkId() {

		return linkId;

	}

	public void setLinkId(int linkId) {

		this.linkId = linkId;

	}

	public String getPublishDate() {	

		return publishDate;

	}

	public void setPublishDate(Date publishDate) {

		String strDate="";

		DateFormat dateFormat =new SimpleDateFormat("MM/dd/yyyy");

		strDate=dateFormat.format(publishDate);

		this.publishDate = strDate;

	}

	public String getPublishOwner() {

		return publishOwner;

	}

	public void setPublishOwner(String publishOwner) {

		this.publishOwner = publishOwner;

	}

	

}

