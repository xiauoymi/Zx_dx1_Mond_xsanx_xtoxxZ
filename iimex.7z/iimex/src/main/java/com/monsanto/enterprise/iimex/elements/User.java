package com.monsanto.enterprise.iimex.elements;

import java.util.Collection;

import java.util.Collections;

import java.util.Enumeration;

import java.util.Hashtable;

import java.util.Vector;

import com.monsanto.enterprise.iimex.IIMexException;




public class User{

	

	protected String m_nCodeId;



	protected String m_strNom;

	protected String m_strAdministrateur;

	
	protected boolean m_bInitialize = false;

	protected Hashtable m_vSoldTo;

	//protected Vector m_vCr;

	

//---------------------------------------------------------------------------------------------		

	public User() 

	throws IIMexException{

		m_vSoldTo = new Hashtable();

		//m_vCr = new Vector();

		

	}

	

//---------------------------------------------------------------------------------------------		

	public void setCodeId(String a_nCodeId)

	throws IIMexException{

		m_nCodeId = a_nCodeId;		

	}

	

//---------------------------------------------------------------------------------------------		

	public String getCodeId()

	throws IIMexException{

		return m_nCodeId;

	}

		
	

//---------------------------------------------------------------------------------------------		

	public void setNom(String a_strParam)

	throws IIMexException{

		m_strNom = a_strParam;	

	}


//---------------------------------------------------------------------------------------------		

	public void setAdministrateur(String a_strParam)

	throws IIMexException{

		m_strAdministrateur = a_strParam;	

	}

	

//---------------------------------------------------------------------------------------------		

	public String getNom()

	throws IIMexException{

		return m_strNom;	

	}


//	---------------------------------------------------------------------------------------------		

	public String getAdministrateur()

	throws IIMexException{

		return m_strAdministrateur;	

	}



//---------------------------------------------------------------------------------------------	

	public boolean isAdministrateur()

	throws IIMexException{

		if(m_strAdministrateur.equalsIgnoreCase("y")) return true;

		else return false;	

	}



//---------------------------------------------------------------------------------------------

	public void setInitialize(boolean a_bParam)

	throws IIMexException{

		m_bInitialize = a_bParam;	

	}	

	

//---------------------------------------------------------------------------------------------

	public boolean getInitialize()

	throws IIMexException{

		return m_bInitialize;	

	}

	



}
