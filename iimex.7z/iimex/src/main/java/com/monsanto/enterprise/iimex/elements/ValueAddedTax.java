package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
//classe that store the value of a tax its product group for a specific country
public class ValueAddedTax{
	protected String group;
	protected String groupName;
	protected String value = IIMexConstants.NO_DATA;
	protected String owner;
	protected Date date;
	
	public void setGroup(String g){
		group = g;
	}
	public void setGroupName(String gn){
		groupName = gn;
	}
	public void setValue(String v){
		value = v;
	}
	public void setOwner(String o){
		owner = o;
	}
	public void setDate(Date d){
		date = d;
	}
	
	public String getGroup(){ return group;}
	public String getGroupName(){ return groupName;}
	public String getValue(){ return value;}
	public String getOwner(){ return owner;}
	public Date getDate(){ return date;}
}