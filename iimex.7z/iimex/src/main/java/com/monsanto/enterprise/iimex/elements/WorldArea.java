package com.monsanto.enterprise.iimex.elements;

import java.util.Date;
//class that store world area code and name
public class WorldArea{
	
	protected String areaCode;
	protected String areaName;
	protected String publishOwner;
	protected Date publishDate;
	
	public void setAreaName(String name){
		areaName = name;
	}
	public void setAreaCode(String code){
		areaCode = code;
	}
	public void setPublisOwner(String owner){
		publishOwner = owner;
	}
	public void setPublisDate(Date date){
		publishDate = date;
	}
	
	public String getAreaName(){
		return areaName;
	}
	public String getAreaCode(){
		return areaCode;
	}
	public String getPublisOwner(){
		return publishOwner;
	}
	public Date getPublisDate(){
		return publishDate;
	}
}