package com.monsanto.enterprise.iimex.elements;

import java.util.Date;
//contact type code and name
public class contactType{
	private String typeCode;
	private String typeName;
	protected String publishOwner;
	protected Date publishDate;
	
	public void setTypeCode(String typeCode) {
		this.typeCode = typeCode;
	}
	public String getTypeCode() {
		return typeCode;
	}
	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}
	public String getName() {
		return typeName;
	}
	public void setPublishOwner(String publishOwner) {
		this.publishOwner = publishOwner;
	}
	public String getPublishOwner() {
		return publishOwner;
	}
	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}
	public Date getPublishDate() {
		return publishDate;
	}
	
}