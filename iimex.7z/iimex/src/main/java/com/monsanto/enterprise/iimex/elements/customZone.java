package com.monsanto.enterprise.iimex.elements;

import java.util.Date;
//custome zone name and code (part of an area most of the time)
public class customZone{
	
	protected String zoneCode;
	protected String zoneName;
	protected String areaCode = " ";
	protected String publishOwner;
	protected Date publishDate;
	
	public void setCustomZoneCode(String code){
		zoneCode = code;
	}
	public void setCustomZoneName(String name){
		zoneName = name;
	}
	public void setAreaCode(String code){
		areaCode = code;
	}
	public void setPublisOwner(String owner){
		publishOwner = owner;
	}
	public void setPublisDate(Date date){
		publishDate = date;
	}
	
	public String getCustomZoneCode(){
		return zoneCode;
	}
	public String getCustomZoneName(){
		return zoneName;
	}
	public String getAreaCode(){
		return areaCode;
	}
	public String getPublisOwner(){
		return publishOwner;
	}
	public Date getPublisDate(){
		return publishDate;
	}
}