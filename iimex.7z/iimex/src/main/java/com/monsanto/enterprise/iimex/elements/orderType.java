package com.monsanto.enterprise.iimex.elements;

import com.monsanto.enterprise.iimex.IIMexConstants;

import java.util.Date;
//defined for a shipping company and a destination one
public class orderType {

	
	protected String purchaseOrderType = IIMexConstants.NO_DATA;
	protected String salesOrderType = IIMexConstants.NO_DATA;
	protected String destination;
	protected String shipping;
	protected String publishOwner;
	protected Date publishDate;
	
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public void setShipping(String shipping) {
		this.shipping = shipping;
	}
	public void setPurchaseOrderType(String purchaseOrderType) {
		this.purchaseOrderType = purchaseOrderType;
	}
	public void setSalesOrderType(String salesOrderType) {
		this.salesOrderType = salesOrderType;
	}
	public void setPublishOwner(String publishOwner) {
		this.publishOwner = publishOwner;
	}
	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}
	
	public String getShipping() {
		return shipping;
	}
	public String getDestination() {
		return destination;
	}
	public String getPurchaseOrderType() {
		return purchaseOrderType;
	}
	public String getSalesOrderType() {
		return salesOrderType;
	}
		public String getPublishOwner(){
		return publishOwner;
	}
	public Date getPublishDate(){
		return publishDate;
	}
}
