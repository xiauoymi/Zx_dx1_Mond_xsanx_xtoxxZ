package com.monsanto.enterprise.iimex.elements.userselection;

import java.util.List;
import java.util.Vector;

import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.elements.*;

/**
 * this object is used to calculate the different results using the selection made by the user
 *
 * @author AGARGAN
 */
/*
 * Once the selection is made in the selection tool, this class is used to store the 
 * result of the search in order to display it in the application or in a pdf file
 */
public class Result {

    protected Selection select;
    protected Country shipping;
    protected Country destination;
    protected Country origin;
    protected CountryToCountry Trip;
    protected CountryToCountry Trip2;
    protected Division div;
    protected ProductGroup prod;
    protected Trait trait;
    protected CompanyDetermination shippingComp;
    protected CompanyDetermination destinationComp;
    protected IncotermTransportInfo incotermTransport;
    protected String allowed;
    protected ShippingRestriction shippingRestriction;
    protected orderType order;
    protected List plants;
    protected PricingCurrency oCurrency;
    protected Vector shippingContacts;
    protected Vector destinationContacts;
    protected ValueAddedTax valueAddedTax;
    protected ClearanceFee shippingClearanceFee;
    protected ClearanceFee destinationClearanceFee;
    protected ImportDuties duties;
    protected ImportLicenseApproval license;
    protected ClearanceTime shippingClearance;
    protected ClearanceTime destinationClearance;
    protected TransportationTime transpTime;
    protected PreferredPort prefferedPort;
    protected Approved appr;
    protected Fees ShippingFees;
    protected Fees DestinationFees;
    protected Vector requirements;
    protected Vector documents;
    protected ShippingInstruction instruction;

    public void setSelection(Selection sel) throws IIMexException {
        select = sel;
        init();
    }

    /**
     * initialize all the attributes by retrieving their correct value in the collections using the selection
     *
     * @throws IIMexException
     */
    /*
      * the result is concatened from the selection and the collections of data
      */
    protected void init() throws IIMexException {
        shipping = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(select.getShipping());
        destination = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(select.getDestination());
        origin = IIMexServlet.iimexUsersManager.getCountryCollection().getCountryByCode(select.getOrigin());
        Trip = IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getCountryToCOuntryByCode(select.getShipping(), select.getDestination());
        Trip2 = IIMexServlet.iimexUsersManager.getCountryToCountryCollection().getCountryToCOuntryByCode(select.getOrigin(), select.getDestination());
        trait = IIMexServlet.iimexUsersManager.getTraitCollection().getTrait(select.getTrait());
        div = IIMexServlet.iimexUsersManager.getDivisionCollection().getDivision(select.getDivision());
        prod = IIMexServlet.iimexUsersManager.getProducts().getProductGroup(select.getProductGroup());
        requirements = IIMexServlet.iimexUsersManager.getPhytoRequirementCollection().getRequirementsByCode(origin.getCountryCode(), destination.getCountryCode(), prod.getProductGroupCode());
        incotermTransport = IIMexServlet.iimexUsersManager.getIncotermsTransportCollection().getIncotermTrasportInfobyCode(select.getIncoterm());
        documents = IIMexServlet.iimexUsersManager.getDocuments().getDocumentsByFilter(shipping.getCountryCode(), destination.getCountryCode(),
                origin.getCountryCode(), prod.getProductGroupCode(), trait.getTraitCode(), div.getDivisionCode(), shipping.getCustomsZoneCode(),
                destination.getCustomsZoneCode(), origin.getCustomsZoneCode(), incotermTransport.getTransportCode(), incotermTransport.getIncotermsCode());
        shippingComp = shipping.getDetermination(select.getDivision(), select.getProductGroup());
        destinationComp = destination.getDetermination(select.getDivision(), select.getProductGroup());

        determineRestrictions();
        if (shippingComp.getSoldToCompanyCode() != null && destinationComp.getSoldToCompanyCode() != null){
            order = IIMexServlet.iimexUsersManager.getOrderTypeCollection().getOrderType(shippingComp.getSoldToCompanyCode(), destinationComp.getSoldToCompanyCode(),
                destinationComp.getSellingCompanyCode());
        }
        else{
            order = new orderType();
          }
        plants = IIMexServlet.iimexUsersManager.getPlantsCollection().getFromPlantsByCode(select.getShipping(), select.getDivision());
        oCurrency = IIMexServlet.iimexUsersManager.getCurrencyCollection().getPricingCurrency(shipping.getCountryCode(), destination.getCountryCode());
        shippingContacts = IIMexServlet.iimexUsersManager.getContactCollection().getContactByCountryAndDivisionAndFrom(shipping.getCountryCode(), div.getDivisionCode(), "F");
        destinationContacts = IIMexServlet.iimexUsersManager.getContactCollection().getContactByCountryAndDivisionAndFrom(destination.getCountryCode(), div.getDivisionCode(), "T");
        ;

        if (shipping.getClearanceFee().get(select.getTransport()) != null)
            shippingClearanceFee = (ClearanceFee) shipping.getClearanceFee().get(select.getTransport());
        else shippingClearanceFee = new ClearanceFee();

        if (destination.getClearanceFee().get(select.getTransport()) != null)
            destinationClearanceFee = (ClearanceFee) destination.getClearanceFee().get(select.getTransport());
        else destinationClearanceFee = new ClearanceFee();

        if (destination.getValueAddedTax().get(select.getProductGroup()) != null)
            valueAddedTax = (ValueAddedTax) destination.getValueAddedTax().get(select.getProductGroup());
        else valueAddedTax = new ValueAddedTax();
        duties = IIMexServlet.iimexUsersManager.getImportDutiesCollection().getDuty(prod.getHTSCode(), origin, destination);

        if (destination.getImportLicenseApproval().containsKey(prod.getHTSCode()))
            license = (ImportLicenseApproval) destination.getImportLicenseApproval().get(prod.getHTSCode());
        else license = new ImportLicenseApproval();
        if (shipping.getClearanceTime().containsKey(incotermTransport.getTransportCode()))
            shippingClearance = (ClearanceTime) shipping.getClearanceTime().get(incotermTransport.getTransportCode());
        else shippingClearance = new ClearanceTime();
        if (destination.getClearanceTime().containsKey(incotermTransport.getTransportCode()))
            destinationClearance = (ClearanceTime) destination.getClearanceTime().get(incotermTransport.getTransportCode());
        else destinationClearance = new ClearanceTime();
        if (Trip.getTransportationTime().containsKey(incotermTransport.getTransportCode()))
            transpTime = (TransportationTime) Trip.getTransportationTime().get(incotermTransport.getTransportCode());
        else transpTime = new TransportationTime();
        if (Trip.getPreferredPortOfEntry().containsKey(select.getDivision()))
            prefferedPort = (PreferredPort) Trip.getPreferredPortOfEntry().get(select.getDivision());
        else prefferedPort = new PreferredPort();
        if (trait.getApproved().containsKey(destination.getCountryCode()))
            appr = (Approved) trait.getApproved().get(destination.getCountryCode());
        else appr = new Approved();
        if (shipping.getShipping() != null)
            ShippingFees = shipping.getShipping();
        else ShippingFees = new Fees();
        if (destination.getDestination() != null)
            DestinationFees = destination.getDestination();
        else DestinationFees = new Fees();
        instruction = destination.getInstruction(div.getDivisionCode());
    }

  private void determineRestrictions() {
        allowed = "allowed";
        shippingRestriction = null;
        Vector<ShippingRestriction> restriction = Trip2.getRestrictions();
        if (restriction != null) {
            for (ShippingRestriction rs : restriction) {
                if (select.getProductGroup().equalsIgnoreCase(rs.getProductCode())) {
                    allowed = "not allowed";
                    shippingRestriction = rs;
                    break;
                }
            }
        }
        if (shippingRestriction==null){
            shippingRestriction = new ShippingRestriction();
            shippingRestriction.setProductCode(select.getProductGroup());
            if ("17".equalsIgnoreCase(select.getDivision())) {
                shippingRestriction.setRestrictionName("not assessed");
                shippingRestriction.setRestrictionComments("not assessed");
            } else {
                shippingRestriction.setRestrictionName("allowed");
                shippingRestriction.setRestrictionComments("allowed");
            }
        }


    }

    public Country getOrigin() {
        return origin;
    }

    public Division getDivision() {
        return div;
    }

    public ProductGroup getProductGroup() {
        return prod;
    }

    public Trait getTrait() {
        return trait;
    }

    public Country getShipping() {
        return shipping;
    }

    public Country getDestination() {
        return destination;
    }

    public CountryToCountry getTrip() {
        return Trip;
    }

    public String getAllowed() {
        return allowed;
    }

    public CompanyDetermination getShippingCompanies() {
        return shippingComp;

    }

    public CompanyDetermination getDestinationCompanies() {
        return destinationComp;

    }

    public orderType getOrderTypes() {
        return order;
    }

    public PricingCurrency getCurrency() {
        return oCurrency;
    }

    public List getPlants() {
        return plants;
    }

    public Vector getShippingContacts() {
        return shippingContacts;
    }

    public Vector getDestinationContacts() {
        return destinationContacts;
    }

    public IncotermTransportInfo getIncotermInfo() {
        return incotermTransport;
    }

    public ValueAddedTax getValueAddedTax() {
        return valueAddedTax;
    }

    public ClearanceFee getImportClearanceFee() {
        return destinationClearanceFee;
    }

    public ClearanceFee getExportClearanceFee() {
        return shippingClearanceFee;
    }

    public ImportDuties getImportDuties() {
        return duties;
    }

    public Fees getShippingFees() {
        return ShippingFees;
    }

    public Fees getDestinationFees() {
        return DestinationFees;
    }

    public ImportLicenseApproval getImportLicenseApproval() {
        return license;
    }

    public ClearanceTime getShippingClearance() {
        return shippingClearance;
    }

    public ClearanceTime getDestinationClearance() {
        return destinationClearance;
    }

    public TransportationTime getTransportationTime() {
        return transpTime;
    }

    public PreferredPort getPreferredPortOfEntry() {
        return prefferedPort;
    }

    public Approved getApproved() {
        return appr;
    }

    public Vector getDocuments() {
        return documents;
    }

    public Vector getPhytosanitaryRequirements() {
        return requirements;
    }

    public ShippingInstruction getInstruction() {
        return instruction;
    }

    public ShippingRestriction getShippingRestriction() {
        return shippingRestriction;
    }

}