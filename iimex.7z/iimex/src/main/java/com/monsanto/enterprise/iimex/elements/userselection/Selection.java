package com.monsanto.enterprise.iimex.elements.userselection;
/**
 * 
 * This object is used to store all the value selected by the user
 * @author AGARGAN
 *
 */
/*
 * Utility class used to store the selection made by the user in the main tool.
 */
public class Selection{
	protected String shipping;
	protected String destination;
	protected String origin;
	protected String incoterm;
	protected String transport;
	protected String division;
	protected String productGroup;
	protected String trait;

    public void setShipping(String ship){
		shipping = ship;
	}
	public void setDestination(String dest){
		destination = dest;
	}
	public void setOrigin(String orig){
		origin = orig;
	}
	public void setIncoterm(String inco){
		incoterm = inco;
	}
	public void setTransport(String trans){
		transport = trans;
	}
	public void setDivision(String div){
		division = div;
	}
	public void setProductGroup(String prod){
		productGroup = prod;
	}
	public void setTrait(String tr){
		trait = tr;
	}
	
	public String getShipping(){
		return shipping;
	}
	public String getDestination(){
		return destination;
	}
	public String getOrigin(){
		return origin;
	}
	public String getIncoterm(){
		return incoterm;
	}
	public String getTransport(){
		return transport;
	}
	public String getDivision(){
		return division;
	}
	public String getProductGroup(){
		return productGroup;
	}
	public String getTrait(){
		return trait;
	}
}