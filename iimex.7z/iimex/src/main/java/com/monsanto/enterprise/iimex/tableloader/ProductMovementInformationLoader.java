package com.monsanto.enterprise.iimex.tableloader;

import com.monsanto.enterprise.iimex.elements.ProductMovementInformation;
import com.monsanto.enterprise.iimex.elements.PreferredPort;
import com.monsanto.enterprise.iimex.elements.TransportationTime;
import com.monsanto.enterprise.iimex.elements.ShippingRestriction;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.DataBaseQueries;

import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Oct 1, 2009
 * Time: 9:37:08 PM
 */
public class ProductMovementInformationLoader extends TableLoader{

    public ProductMovementInformation getProductInformation() throws IIMexException {
        ProductMovementInformation productMovementInformation = new ProductMovementInformation();
        Connection conn=null;
        ResultSet it=null;
        try {
            conn = getConnection();
            it = conn.prepareStatement(DataBaseQueries.SELECT_SHIPPING_RESTRICTIONS_QUERY).executeQuery();

            while (it.next()){                
                productMovementInformation.addCountryRestriction(it.getString("country_of_origin"),it.getString("destination_country_code"), getShippingRestrictionFrom(it));
            }
            it.close();

            it = conn.prepareStatement(DataBaseQueries.SELECT_PREFERRED_PORT_OF_ENTRY_QUERY).executeQuery();
            while (it.next()){
                productMovementInformation.addPreferredPortForShipping(it.getString("shipping_country_code"),it.getString("destination_country_code"),
                        getPreferredPortOfEntryFromIterator(it));
            }
            it.close();

            it = conn.prepareStatement(DataBaseQueries.SELECT_PREFERRED_SHIPPING_TIME_QUERY).executeQuery();
            while (it.next()){
                productMovementInformation.addPreferredTransportTimesForShipping(it.getString("shipping_country_code"),it.getString("destination_country_code"),
                        getPreferredTransportTimesFromIterator(it));
            }
            it.close();
        }
        catch (SQLException e) {
			throw (new IIMexException("Error adding port ", e));
		} finally {
			closeConnection(conn);
		}

        return productMovementInformation;
    }

    private TransportationTime getPreferredTransportTimesFromIterator(ResultSet it) throws SQLException {
        TransportationTime trs = new TransportationTime();

                trs.setDestCountryCode(it.getString("DESTINATION_COUNTRY_CODE"));
								trs.setFreightBooking(it.getString("FREIGHT_BOOKING"));

								trs.setTransportationTime(it.getString("TRANSPORTATION_TIME"));

								trs.setPublishOwner(it.getString("PUBLISH_OWNER"));

								trs.setPublishDate(it.getDate("PUBLISH_DATE"));
							trs.setTpModeCode(it.getString("TRANSPORT_MODE_CODE"));
        return trs;

    }

    private ShippingRestriction getShippingRestrictionFrom(ResultSet it) throws SQLException {
        ShippingRestriction shippingRestriction = new ShippingRestriction();
        shippingRestriction.setComments(it.getString("c_comments"));
        shippingRestriction.setOrigin(it.getString("country_of_origin"));
        shippingRestriction.setDestination(it.getString("destination_country_code"));
        shippingRestriction.setProductCode(it.getString("product_group_code"));
        shippingRestriction.setRestrictionComments(it.getString("t_comments"));
        shippingRestriction.setRestrictionName(it.getString("shipping_restrict_name"));
        shippingRestriction.setRestrictionTypeCode(it.getString("shipping_restrict_code"));
        shippingRestriction.setPublishDate(it.getDate("c_date"));
        shippingRestriction.setPublishOwnerId(it.getString("c_owner"));
        shippingRestriction.setProductGroupName(it.getString("pg_name"));
        return shippingRestriction;
    }

    private PreferredPort getPreferredPortOfEntryFromIterator(ResultSet it) throws SQLException {
        PreferredPort pp = new PreferredPort();
								pp.setDestCountryCode(it.getString("destination_country_code"));
								pp.setDivision(it.getString("DIVISION_CODE"));
								pp.setPort(it.getString("PREFERRED_PORT_OF_ENTRY"));
                                pp.setOwner(it.getString("PUBLISH_OWNER"));
                                pp.setDate(it.getDate("PUBLISH_DATE"));
        return pp;
    }
}
