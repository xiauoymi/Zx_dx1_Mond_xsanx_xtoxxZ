/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/


package com.monsanto.enterprise.iimex.tableloader;


import java.util.ArrayList;

import java.util.Date;

import java.util.HashMap;

import java.util.List;
import java.sql.*;


import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.DataBaseQueries;

import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.IIMEXObjectVersion;


/**
 * Filename: $RCSfile: TableDBState.java,v $ Label: $Name:  $ Last Change: $Author: tadial $ On: $Date: 2009/10/15 20:30:01 $
 *
 * @author MMCORT3
 * @version $Revision: 1.10 $
 */


public class TableDBState extends TableLoader {


    private static final int NUMBER_OBJECTS_BEING_TRACKED = 29;

    protected HashMap hmVersionMng = null;

    protected List fieldList;

    private static final String OBJECT_ID_COLUMN_NAME = "object_id";
    private static final String VERSION_NUMBER_COLUMN_NAME = "version_number";
    private static final String ERROR_LOADING_OBJECT_VERSIONS = "Error loading object versions";


    public void initDBState() throws IIMexException {

        Logger.traceEntry();
        Connection con = null;
        PreparedStatement pstm = null;
        try {
            con = getConnection();

            pstm = con.prepareStatement(DataBaseQueries.UPDATE_DB_STATE);

            pstm.setString(1, "n");

            pstm.executeUpdate();

            pstm.close();

            fieldList = getColumnNames(DataBaseQueries.SELECT_VERSION, con);

            loadIIMexVersionRows(con);


        } catch (SQLException _ex) {
            _ex.printStackTrace();
            throw (new IIMexException("Error updating DB status", _ex));

        } finally {

            if (con != null) {
                try {
                    con.close();
                } catch (SQLException e) {
                    throw (new IIMexException("Error updating DB status", e));
                }
            }

        }


    }


    public HashMap<String, IIMEXObjectVersion> loadVersions() throws IIMexException {
        Connection con=null;
        con = getConnection();
        IIMEXObjectVersion objectVersion;
        HashMap<String, IIMEXObjectVersion> objectVersions =
            new HashMap<String, IIMEXObjectVersion>(NUMBER_OBJECTS_BEING_TRACKED);
        try {
            ResultSet rs = con.prepareStatement(DataBaseQueries.OBJECT_VERSIONS_QUERY).executeQuery();
            while (rs.next()){
                objectVersion = new IIMEXObjectVersion();
                objectVersion.setLocalVersionNumber(rs.getLong(VERSION_NUMBER_COLUMN_NAME));
                objectVersion.setServerVersionNumber(rs.getLong(VERSION_NUMBER_COLUMN_NAME));
                objectVersion.setObjectId(rs.getString(OBJECT_ID_COLUMN_NAME));
                System.out.println("objectVersion.getObjectId() = " + objectVersion.getObjectId());
                objectVersions.put(objectVersion.getObjectId(), objectVersion);
            }
        } catch (SQLException e) {
            throw new IIMexException(ERROR_LOADING_OBJECT_VERSIONS, e);
        }
        finally{
            closeConnection(con);
        }
        return objectVersions;
    }


   public void loadServerObjectVersions(HashMap<String, IIMEXObjectVersion> objectVersions) throws IIMexException {
        Connection con=null;
        con = getConnection();
        IIMEXObjectVersion objectVersion;
        try {
            ResultSet rs = con.prepareStatement(DataBaseQueries.OBJECT_VERSIONS_QUERY).executeQuery();
            while (rs.next()){
                objectVersion = objectVersions.get(rs.getString(OBJECT_ID_COLUMN_NAME));
                objectVersion.setServerVersionNumber(rs.getLong(VERSION_NUMBER_COLUMN_NAME));
            }
        } catch (SQLException e) {
            throw new IIMexException(ERROR_LOADING_OBJECT_VERSIONS, e);
        }
        finally{
            closeConnection(con);
        }
    }




    /**
     * Check if the DB has been updated Return true if the DB has been updated and set the status as n.
     *
     * @return
     * @throws IIMexException
     */

    public boolean checkDatabaseState() throws IIMexException {

        Logger.traceEntry();
        Logger.traceExit();
        return true;
    }


    /**
     * Update the database with the user login and when the
     * <p/>
     * user has connected. Those data will be avalaible for monitoring or for statistiques
     *
     * @param login
     * @throws IIMexException
     */

    public void updateDBwithUser(String login)

            throws IIMexException {

        Logger.traceEntry();

        Connection connection = null;

        PreparedStatement pstm = null;

        // Demande de connexion

        try {

            connection = getConnection();
            pstm = connection.prepareStatement(DataBaseQueries.INSERT_IIMEX_MONITORING);

            pstm.setString(1, login);

            pstm.executeUpdate();


        } catch (SQLException wEx) {

            throw (new IIMexException("Error update DB", wEx));

        } finally {

            closeConnection(connection);

        }


    }

    private void loadIIMexVersionRows(Connection con)

            throws IIMexException {

        Logger.traceEntry();

        hmVersionMng = new HashMap();

        int i = 0;
        try {

            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_VERSION).executeQuery();
            while (it.next()) {

                String version = it.getString(1);

                Date date = it.getDate(2);

                String comment = it.getString(3);

                List versionList = new ArrayList();

                versionList.add(0, version);

                versionList.add(1, date);

                versionList.add(2, comment);

                hmVersionMng.put(i, versionList);
                i++;

            }
            it.close();

        } catch (SQLException e) {

            throw (new IIMexException("Error in the DB row", e));

        }

        Logger.traceExit();


    }


    public List getFieldList() {

        return fieldList;

    }


    public HashMap getHmVersionMng() {

        return hmVersionMng;

    }


    /**
     * set the database Updated field as Y
     *
     * @return
     * @throws IIMexException
     */

    public int setDBUpdated()

            throws IIMexException {

        Logger.traceEntry();

        int rowUpdate = 0;

        Connection connection = null;

        PreparedStatement pstm = null;

        synchronized (this) {

                    //2217724736443
                try {
                    connection = getConnection();
                    pstm = connection.prepareStatement(DataBaseQueries.UPDATE_DB_STATE);

                    pstm.setString(1, "y");

                    rowUpdate = pstm.executeUpdate();

                } catch (SQLException _ex) {

                    throw (new IIMexException("Error updating DB status", _ex));

                } finally {

                    try {

                        pstm.close();

                    } catch (SQLException _ex) {

                        throw (new IIMexException("Error updating DB status",

                                _ex));

                    }

                    closeConnection(connection);

                }

            }



        Logger.traceExit();

        return rowUpdate;

    }


}

