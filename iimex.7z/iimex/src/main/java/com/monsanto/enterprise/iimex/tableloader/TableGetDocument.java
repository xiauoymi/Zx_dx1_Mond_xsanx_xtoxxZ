/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.tableloader;



import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.monsanto.AbstractLogging.Logger;

import com.monsanto.enterprise.iimex.DataBaseQueries;

import com.monsanto.enterprise.iimex.IIMexException;


public class TableGetDocument extends TableLoader{

	/**

	 * Get a document from the database

	 */

	public InputStream getDocument(int docId, int linkId)

	throws IIMexException{

		Logger.traceEntry();

        Connection connection =null;

        PreparedStatement pstm;

        InputStream fileInput = null;

        ResultSet result;

        try{
            connection = getConnection();

				pstm = connection.prepareStatement(DataBaseQueries.SELECT_DOCUMENT);

				pstm.setInt(1, docId);

				pstm.setInt(2, linkId);

				result = pstm.executeQuery();

				if (result.next()){
				fileInput = result.getBlob(1).getBinaryStream();
                }

			}catch (SQLException wEx) {

				throw (new IIMexException("Error update DB", wEx));

			}  finally {



			closeConnection(connection);

			}


		return fileInput;

		

	}



	public InputStream getDocumentReq(int docId)

	throws IIMexException{

		Logger.traceEntry();

		 Connection con =null;

        PreparedStatement pstm;

        InputStream fileInput = null;

        ResultSet result;

		try{

                con = getConnection();
				pstm =con.prepareStatement(DataBaseQueries.SELECT_DOCUMENT_REQ);

				pstm.setInt(1, docId);

				result =pstm.executeQuery();

				if (result.next()) {
				fileInput = result.getBlob(1).getBinaryStream();
                }

			

			}catch (SQLException wEx) {

				throw (new IIMexException("Error update DB", wEx));

			}  finally {

				closeConnection(con);
			}
    	return fileInput;
	}

}

