package com.monsanto.enterprise.iimex.tableloader;

import java.util.Vector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.Company;

public class TableLoadCompanies extends TableLoader {
	//load the companies in the application
	public Vector<Company> loadCompanies()	throws IIMexException{

		Logger.traceEntry();

		Vector<Company> companies = new Vector<Company>();		

        Connection con = null;

        try{

            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_COMPANIES).executeQuery();
            while (it.next()) {

				Company comp = new Company();

				comp.setCompanyCode(it.getString(1));
				
				comp.setCompanyName(it.getString(2));
				
				comp.setPublishOwner(it.getString(3));
				
				comp.setPublishDate(it.getDate(4));
				
				companies.add(comp);
			}
            it.close();

		} catch (SQLException _ex) {

			throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));

		} finally {

			closeConnection(con);

		}

		Logger.traceExit();

		return companies;

	}
	
}