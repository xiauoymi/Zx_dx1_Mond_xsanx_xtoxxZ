package com.monsanto.enterprise.iimex.tableloader;

import java.util.Vector;
import java.util.Date;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.contactType;

public class TableLoadContactType extends TableLoader {
	//load the contact from the base
	public Vector<contactType> loadContactsType() throws IIMexException{

		Logger.traceEntry();

        Connection con=null;

        Vector<contactType> types = new Vector<contactType>();

        try {

            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_CONTACTS_TYPE).executeQuery();
            while (it.next()) {
				contactType type = new contactType();
				type.setTypeCode(it.getString(1));
				type.setTypeName(it.getString(2));
				type.setPublishOwner(it.getString(3));
				type.setPublishDate(it.getDate(4));
				types.add(type);
			}
		} catch (SQLException e) {

			throw (new IIMexException("Error in the DB row", e));

		}finally{

closeConnection(con);

		}

		Logger.traceExit();	
		return types;
	}
	//add a new one
	public int addContactType(contactType ct) throws IIMexException{

		Logger.traceEntry();
		
		PreparedStatement pstm=null;
        Connection con=null;
		int addOk =0;
		
		try{
      con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_CONTACT_TYPE);
			pstm.setInt(1, Integer.valueOf(ct.getTypeCode()));
			pstm.setString(2, ct.getName());
			pstm.setString(3, ct.getPublishOwner());
			pstm.setDate(4, new java.sql.Date(new Date().getTime()));
		
			addOk=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive contact type "+ct.getName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
	//update an existing one
	public int updateContactType(contactType ct) throws IIMexException{

		Logger.traceEntry();
		
		PreparedStatement pstm=null;
        Connection con = null;
		int addOk =0;
		
		try{
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_CONTACT_TYPE);
			pstm.setInt(4, Integer.valueOf(ct.getTypeCode()));
			pstm.setString(1, ct.getName());
			pstm.setString(2, ct.getPublishOwner());
			pstm.setDate(3, new java.sql.Date(new Date().getTime()));
		
			addOk=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive contact type "+ct.getName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
	// remove it
	public int removeContactType(String ct) throws IIMexException{

		Logger.traceEntry();
		
		PreparedStatement pstm=null;
        Connection con=null;
		int addOk =0;
		
		try{
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_CONTACT_TYPE);
			pstm.setString(1, ct);
		
			addOk=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive contact type "+ct, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
		}
	
}