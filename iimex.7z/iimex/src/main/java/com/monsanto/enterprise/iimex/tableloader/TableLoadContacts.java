package com.monsanto.enterprise.iimex.tableloader;

import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;


import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.collections.CountryCollection;
import com.monsanto.enterprise.iimex.collections.contactTypeCollection;
import com.monsanto.enterprise.iimex.elements.Contacts;
import com.monsanto.enterprise.iimex.elements.CountryFrom;

public class TableLoadContacts extends TableLoader {
	//load all contacts in the application
	public Vector loadContacts(CountryCollection coll,contactTypeCollection coll2) throws IIMexException{

		Logger.traceEntry();
        Connection con=null;

        Vector Contacts = new Vector();

        try {
            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_FROM_CONTACTS).executeQuery();

			while (it.next()) {
				
				String country=it.getString(7);

				Contacts contact = new Contacts();

				contact.setContactCode(it.getInt(1));
				
				contact.setContactType(coll2.getTypeName(it.getString(2)));
				
				contact.setContactName(it.getString(3));
				
				contact.setContactPerson(it.getString(4));
				
				contact.setStreet(it.getString(5));
				
				contact.setCity(it.getString(6));
				
				contact.setCountryCode(it.getString(7));
				
				contact.setCountry(it.getString(8));
				
				contact.setTel(it.getString(9));
				
				contact.setFax(it.getString(10));
				
				contact.setMobile(it.getString(11));
				
				contact.setMail(it.getString(12));
				
				contact.setContactComments(it.getString(13));

				contact.setPublishOwner(it.getString(14));
				
				contact.setPublishDate((Date)it.getDate(15));
				
				Contacts.add(contact);



			}
            it.close();
			loadContactsCountry(Contacts, con);
		} catch (SQLException e) {

			throw (new IIMexException("Error in the DB row", e));

		}finally{

			closeConnection(con);

		}
		
		Logger.traceExit();	
		return Contacts;
	}
	//load their countries
	void loadContactsCountry(Vector Contacts, Connection con)throws IIMexException{
		
		Logger.traceEntry();


        try {
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_CONTACTS_COUNTRY).executeQuery();
            while (it.next()) {
				java.util.Iterator ite = Contacts.iterator();
				while(ite.hasNext()){
					Contacts tmp = (Contacts)ite.next(); 
					if(tmp.getContactCode() == it.getInt(1)){
						HashMap countries = tmp.getCountries();
						CountryFrom cf = new CountryFrom();
						cf.setFrom(it.getString(4));
						if(it.getString(5)!=null)
							cf.setComment(it.getString(5));
						cf.setCountry(it.getString(2));
						cf.setDivision(it.getString(3));
						if(countries.containsKey(it.getString(2))){
							HashMap div = (HashMap)countries.get(it.getString(2));
							HashMap from;
							if(div.containsKey(it.getString(3)))
								from = (HashMap)div.get(it.getString(3));
							else from = new HashMap();
							from.put(it.getString(4), cf);
							div.put(it.getString(3), from);
							countries.put(it.getString(2), div);
						}else{
							HashMap div = new HashMap();
							HashMap from;
							if(div.containsKey(it.getString(3)))
								from = (HashMap)div.get(it.getString(3));
							else from = new HashMap();
							from.put(it.getString(4), cf);
							div.put(it.getString(3), from);
							countries.put(it.getString(2), div);
						}
						tmp.setCountries(countries);
					}
				}
			}
            it.close();
			
		} catch (SQLException e) {

			throw (new IIMexException("Error in the DB row", e));

		}
		Logger.traceExit();	
		
	}
	//delete a contact
	public int removeContact(int contactCode) throws IIMexException{
		Logger.traceEntry();
		int removeOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.DELETE_CONTACTS_COUNTRY);
			pstm.setInt(1,contactCode);
			removeOK=pstm.executeUpdate();
			pstm.close();
			if(removeOK>=0){
					pstm = con.prepareStatement(DataBaseQueries.DELETE_CONTACT);
					pstm.setInt(1,contactCode);
					removeOK=pstm.executeUpdate();
					pstm.close();
			}
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive contact "+contactCode, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return removeOK;
	}
	//add one
	public int addContact(Contacts cont) throws IIMexException{
		Logger.traceEntry();
		int addOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INSERT_NEW_CONTACT);
			pstm.setString(1,cont.getContactType());
			pstm.setString(2,cont.getContactName());
			pstm.setString(3,cont.getContactPerson());
			pstm.setString(4,cont.getStreet());
			pstm.setString(5,cont.getCity());
			pstm.setString(6,cont.getCountry());
			pstm.setString(7,cont.getTel());
			pstm.setString(8,cont.getFax());
			pstm.setString(9,cont.getMobile());
			pstm.setString(10,cont.getMail());
			pstm.setString(11,cont.getContactComments());
			pstm.setString(12,cont.getPublishOwner());
			pstm.setDate(13,new java.sql.Date(cont.getPublishDate().getTime()));
			addOK=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error adding contact "+cont.getContactName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOK;
	}
	//update one
	public int updateContact(Contacts cont) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_CONTACTS);
			pstm.setString(2,cont.getContactType());
			pstm.setString(3,cont.getContactName());
			pstm.setString(4,cont.getContactPerson());
			pstm.setString(5,cont.getStreet());
			pstm.setString(6,cont.getCity());
			pstm.setString(7,cont.getTel());
			pstm.setString(8,cont.getMobile());
			pstm.setString(9,cont.getFax());
			pstm.setString(10,cont.getMail());
			pstm.setString(11,cont.getContactComments());
			pstm.setString(1,cont.getCountry());
			pstm.setString(12,cont.getPublishOwner());
			pstm.setDate(13,new java.sql.Date(cont.getPublishDate().getTime()));
			pstm.setInt(14,cont.getContactCode());
			updateOK=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
            e.printStackTrace();
			throw (new IIMexException("Error updating contact "+cont.getContactName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
	//add a new contact country
	public int addContactCountry(CountryFrom cf,String contactCode) throws IIMexException{
		Logger.traceEntry();
		int addOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_CONTACTS_COUNTRY);
			pstm.setInt(1,Integer.parseInt(contactCode));
			pstm.setString(2,cf.getCountry());
			pstm.setString(3,cf.getDivision());
			pstm.setString(4,cf.getFrom());
			pstm.setString(5,cf.getComment());
			pstm.setString(6,cf.getPublishOwner());
			pstm.setDate(7,new java.sql.Date(cf.getPublishDate().getTime()));
			addOK=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating contact "+contactCode, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOK;
	}
	//update it
	public int updateContactCountry(CountryFrom cf,String contactCode) throws IIMexException{
		Logger.traceEntry();
		int updateOk = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_CONTACTS_COUNTRY);
			
			pstm.setString(1,cf.getFrom());
			pstm.setString(2,cf.getComment());
			pstm.setString(3,cf.getPublishOwner());
			pstm.setDate(4, new java.sql.Date(cf.getPublishDate().getTime()));
			
			pstm.setInt(5,Integer.parseInt(contactCode));
			pstm.setString(6,cf.getCountry());
			pstm.setString(7,cf.getDivision());
			
			updateOk=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating contact "+contactCode, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOk;
	}
//delte it
	public int removeContactCountry(String code, String country, String division, String fromCode) throws IIMexException{
		Logger.traceEntry();
		int removeOK = 0;
		PreparedStatement pstm=null;
    Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_CONTACTS_COUNTRY);
			pstm.setString(1,code);
			pstm.setString(2,country);
			pstm.setString(3,division);
			pstm.setString(4, fromCode);
			removeOK=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating contact "+code, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return removeOK;
	}
	
}