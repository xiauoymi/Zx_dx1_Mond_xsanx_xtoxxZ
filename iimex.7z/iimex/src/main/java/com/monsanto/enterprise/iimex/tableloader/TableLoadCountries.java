/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.tableloader;

import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.Util.StringUtils;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.collections.CompaniesCollection;
import com.monsanto.enterprise.iimex.collections.CustomZoneCollection;
import com.monsanto.enterprise.iimex.collections.ProductCollection;
import com.monsanto.enterprise.iimex.collections.WorldAreaCollection;
import com.monsanto.enterprise.iimex.elements.ClearanceFee;
import com.monsanto.enterprise.iimex.elements.ClearanceTime;
import com.monsanto.enterprise.iimex.elements.CompanyDetermination;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.Fees;
import com.monsanto.enterprise.iimex.elements.ImportLicenseApproval;
import com.monsanto.enterprise.iimex.elements.ShippingInstruction;
import com.monsanto.enterprise.iimex.elements.ValueAddedTax;

public class TableLoadCountries extends TableLoader{

	/**
	 * Load the data of all countries from the database to a HashTable
	 * @return
	 * @throws IIMexException
	 */

	public HashMap<String, Country> loadCountries(CompaniesCollection companiesCollection, CustomZoneCollection zoneCollection, WorldAreaCollection areaCollection,ProductCollection pc) throws IIMexException{
		Logger.traceEntry();
		HashMap<String, Country> mhCountry =new HashMap<String, Country>();
		Connection con = null;
		try {
		
			Logger.log(new LoggableInfo("SELECT_COUNTRY"));
            con = getConnection();
			ResultSet ite = con.prepareStatement(DataBaseQueries.SELECT_COUNTRY).executeQuery();
			while (ite.next()) {
				Country oCountry = new Country();
				oCountry.setCountryCode(ite.getString(1));
				oCountry.setCountryName(ite.getString(2));
				oCountry.setWorldAreaCode(ite.getString(3));
				if(!StringUtils.isNullOrEmpty(oCountry.getWorldAreaCode()))
					oCountry.setWorldAreaName(areaCollection.getAreaByCode(oCountry.getWorldAreaCode()).getAreaName());
				if(!StringUtils.isNullOrEmpty(ite.getString(4)))
					if(ite.getString(4).compareTo("y")==0)
						oCountry.setActive(true);
				oCountry.setCustomsZoneCode(ite.getString(5));
				oCountry.setPublishOwner(ite.getString(6));
				oCountry.setPublishDate((Date)ite.getDate(7));
				if(!StringUtils.isNullOrEmpty(ite.getString(5))){					
					oCountry.setCustomsZoneName(zoneCollection.getZoneByCode(oCountry.getCustomsZoneCode()).getCustomZoneName());
			}					
			mhCountry.put(oCountry.getCountryCode(), oCountry);
			}

			loadInstructions(mhCountry, con);
			loadFees(mhCountry,con);
			loadValueAddedTax(mhCountry,pc,con);
			loadCompanyDetermination(mhCountry, companiesCollection,con);
			loadClearanceFee(mhCountry,con);
			loadImportLicenseApproval(mhCountry,con);
			loadClearanceTime(mhCountry,con);
		
		} catch (Exception e) {
            e.printStackTrace();
            Logger.log(new LoggableError(e));
			throw (new IIMexException("Error in the DB row", e));
		}finally{
			if (con!=null){
                try {
                    con.close();
                } catch (SQLException e) {
                   Logger.log(new LoggableError(e));
                }
            }
		}
	
		Logger.traceExit();
		return mhCountry;
	}
	//load the shipping instructions for a specific country
	private void loadInstructions(HashMap<String, Country> mhCountry,Connection con) throws IIMexException{
		Logger.traceEntry();
		Logger.log(new LoggableInfo("SELECT_INSTRUCTIONS"));
        Country oCountry;
		try{
            ResultSet ite = con.prepareStatement(DataBaseQueries.SELECT_INSTRUCTIONS).executeQuery();
            while (ite.next()) {
				oCountry = mhCountry.get(ite.getString(1));
				ShippingInstruction tmp = new ShippingInstruction();
				tmp.setDivision(ite.getString(9));
				tmp.setSeedSamples(ite.getString(2));
				tmp.setShippingInstructions(ite.getString(3));
				tmp.setSeedTreatment(ite.getString(4));
				tmp.setMiscallenous(ite.getString(5));
				tmp.setPackaging(ite.getString(6));
				tmp.setOwner(ite.getString(7));
				tmp.setDate(ite.getDate(8));
				Vector tor = oCountry.getInstructions();
				tor.add(tmp);
				oCountry.setInstruction(tor);
			}
		} catch (Exception e) {
			throw (new IIMexException("Error in the DB row", e));
		}
		Logger.traceExit();
	}
	//load the fees for a specific country
	private void loadFees(HashMap<String, Country> mhCountry,Connection con) throws IIMexException{
		Logger.traceEntry();	
		Logger.log(new LoggableInfo("SELECT_FEES"));
        Country oCountry;
		try{
            ResultSet ite = con.prepareStatement(DataBaseQueries.SELECT_FEES).executeQuery();
            while (ite.next()) {
				oCountry = mhCountry.get(ite.getString(1));
				Fees fee = new Fees();
				
				fee.setCertificateOfOrigin(ite.getString(3));
				fee.setConsular(ite.getString(4));
				fee.setFederalSeedLab(ite.getString(5));
				fee.setHandling(ite.getString(6));
				fee.setInsurance(ite.getString(7));
				fee.setLegalization(ite.getString(8));
				fee.setPhytosanitaryCertificate(ite.getString(9));
				fee.setSeedAnalysisCertificate(ite.getString(10));
				fee.setInspection(ite.getString(11));
				fee.setOther(ite.getString(12));
				fee.setPublishOwner(ite.getString(13));
				fee.setPublishDate((Date)ite.getDate(14));
				fee.setExist(true);
				
				if(ite.getString(2).compareTo("S")==0)
					oCountry.setShipping(fee);
				else oCountry.setDestination(fee);
			}
		}catch (Exception e) {
			throw (new IIMexException("Error in the DB row", e));
		}
		Logger.traceExit();
	}
	//load the taxes for a specific country
	private void loadValueAddedTax(HashMap<String, Country> mhCountry,ProductCollection pc,Connection con)throws IIMexException{
		Logger.traceEntry();	
		Logger.log(new LoggableInfo("SELECT_VALUE_ADDED_TAX"));
        Country oCountry;
		try{
            ResultSet ite = con.prepareStatement(DataBaseQueries.SELECT_VALUE_ADDED_TAX).executeQuery();
            while (ite.next()) {
				oCountry = mhCountry.get(ite.getString(1));
				ValueAddedTax vat = new ValueAddedTax();
				vat.setGroup(ite.getString(2));
				vat.setGroupName(pc.getProductName(ite.getString(2)));
				vat.setValue(ite.getString(3));
				vat.setOwner(ite.getString(4));
				vat.setDate(ite.getDate(5));
				HashMap valueAddedTax = oCountry.getValueAddedTax();
				valueAddedTax.put(ite.getString(2), vat);
				oCountry.setValueAddedTax(valueAddedTax);
			}
		}catch (Exception e) {
				throw (new IIMexException("Error in the DB row", e));
			}
			Logger.traceExit();
	}
	//load the companies for a specific country
	private void loadCompanyDetermination(HashMap<String, Country> mhCountry, CompaniesCollection companiesCollection,Connection con)throws IIMexException{
		Logger.traceEntry();	
		Logger.log(new LoggableInfo("SELECT_COMPANY_DETERMINATION"));
        Country oCountry;
		try{
            ResultSet ite = con.prepareStatement(DataBaseQueries.SELECT_COMPANY_DETERMINATION).executeQuery();
            while (ite.next()) {
				oCountry = mhCountry.get(ite.getString(1));
				HashMap companyDetermination = oCountry.getCompanyDetermination();				
				CompanyDetermination comp = new CompanyDetermination();
				
				if(ite.getString(4)!=null){
					comp.setSoldToCompanyCode(ite.getString(4));
					comp.setSoldToCompanyName(companiesCollection.getCompanyName(comp.getSoldToCompanyCode()));
				}
				if(ite.getString(5)!=null)
					comp.setSalesCompanyName(ite.getString(5));
				if(ite.getString(6)!=null){
					comp.setBillToCompanyCode(ite.getString(6));
					comp.setBillToCompanyName(companiesCollection.getCompanyName(comp.getBillToCompanyCode()));
				}
//        else if(ite.getString(4)!=null && ite.getString(4).compareTo("3868")==0){
//					comp.setBillToCompanyCode("3868");
//					comp.setBillToCompanyName(comp.getSoldToCompanyName());
//				}
        else{
					comp.setBillToCompanyCode("");
					comp.setBillToCompanyName("Contact I/E");
				}
				if(ite.getString(7)!=null)
					comp.setShipToCompanyName(ite.getString(7));
				if(ite.getString(8)!=null)
					comp.setConsignToCompanyName(ite.getString(8));
				if(ite.getString(9)!=null){
					comp.setSellingCompanyCode(ite.getString(9));
					comp.setSellingCompanyName(companiesCollection.getCompanyName(comp.getSellingCompanyCode()));
				}
//        else if(ite.getString(4)!=null && ite.getString(4).compareTo("3868")==0){
//					comp.setSellingCompanyCode("3868");
//					comp.setSellingCompanyName(comp.getSoldToCompanyName());
//				}
        else{
					comp.setSellingCompanyCode("");
					comp.setSellingCompanyName("Contact I/E");
				}
				if(ite.getString(10)!=null)
					comp.setSalesOrganisation(ite.getString(10));
				if(ite.getString(11)!=null)
					comp.setPublishOwner(ite.getString(11));
				if(ite.getDate(12)!=null)
					comp.setPublishDate((Date)ite.getDate(12));
				if(ite.getString(13)!=null)
					comp.setActive(ite.getString(13));
				comp.setDivision(ite.getString(2));
				comp.setGroup(ite.getString(3));
				
				if(companyDetermination.containsKey(ite.getString(2))){
					Vector cmp = (Vector)companyDetermination.get(ite.getString(2));
					cmp.add(comp);
					companyDetermination.put(ite.getString(2), cmp);
				}else{
					Vector cmp = new Vector();
					cmp.add(comp);
					companyDetermination.put(ite.getString(2), cmp);
				}
				oCountry.setCompanyDetermination(companyDetermination);
			}
		}catch (Exception e) {
			throw (new IIMexException("Error in the DB row", e));
		}
        Logger.traceExit();
	}
	//load the clearance fees for a specific country
	private void loadClearanceFee(HashMap<String, Country> mhCountry,Connection con)throws IIMexException{
		Logger.traceEntry();	
		Logger.log(new LoggableInfo("SELECT_CLEARENCE_FEE"));
        Country oCountry;
		try{
            ResultSet ite = con.prepareStatement(DataBaseQueries.SELECT_CLEARENCE_FEE).executeQuery();
            while (ite.next()) {
				oCountry = mhCountry.get(ite.getString(1));
				HashMap clearanceFee =oCountry.getClearanceFee();
				ClearanceFee clea = new ClearanceFee();
			
				if(ite.getString(3)!=null)
					clea.setImportClearanceFee(ite.getString(3));
				if(ite.getString(4)!=null)
					clea.setExportClearanceFee(ite.getString(4));
				if(ite.getString(5)!=null)
					clea.setPublishOwner(ite.getString(5));
				if(ite.getString(6)!=null)
					clea.setPublishDate((Date)ite.getDate(6));
			
				clearanceFee.put(ite.getString(2), clea);
				oCountry.setClearanceFee(clearanceFee);
			}	
		}catch (Exception e) {
			throw (new IIMexException("Error in the DB row", e));
		}
		Logger.traceExit();
	}
	//add a new clearance fee
	public int addClearanceFee(ClearanceFee cf, String country)throws IIMexException{
		Logger.traceEntry();	
		int rowUpdate=0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_CLEARENCE_FEE);
			pstm.setString(1,country);
			pstm.setString(2,cf.getTransportModeCode());
			pstm.setString(4,cf.getExportClearanceFee());
			pstm.setString(3,cf.getImportClearanceFee());
			pstm.setString(5,cf.getPublishOwner());
			pstm.setDate(6,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error addind clearance fee", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//update it
	public int updateClearanceFee(ClearanceFee cf, String country)throws IIMexException{
		Logger.traceEntry();	
		int rowUpdate=0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_CLEARENCE_FEE);
			pstm.setString(5,country);
			pstm.setString(6,cf.getTransportModeCode());
			pstm.setString(2,cf.getExportClearanceFee());
			pstm.setString(1,cf.getImportClearanceFee());
			pstm.setString(3,cf.getPublishOwner());
			pstm.setDate(4,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating clearance fee", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//load the import license approval of a country
	private void loadImportLicenseApproval(HashMap<String, Country> mhCountry,Connection con)throws IIMexException{
		Logger.traceEntry();	
		Logger.log(new LoggableInfo("SELECT_IMPORT_LICENSE_APPROVAL"));
        Country oCountry;
		try{
            ResultSet ite = con.prepareStatement(DataBaseQueries.SELECT_IMPORT_LICENSE_APPROVAL).executeQuery();
            while (ite.next()) {
				oCountry = mhCountry.get(ite.getString(1));
				HashMap importLicense = oCountry.getImportLicenseApproval();
				ImportLicenseApproval lic = new ImportLicenseApproval();
				
				lic.setImportLicenseApproval(ite.getString(3));
				lic.setPublishOwner(ite.getString(4));
				lic.setPublishDate(ite.getDate(5));
				
				importLicense.put(ite.getString(2), lic);
				oCountry.setImportLicenseApproval(importLicense);
			}	
		}catch (Exception e) {
			throw (new IIMexException("Error in the DB row", e));
		}
		Logger.traceExit();
	}
	//load the clearance time
	private void loadClearanceTime(HashMap<String, Country> mhCountry, Connection con)throws IIMexException{
		Logger.traceEntry();	
		Logger.log(new LoggableInfo("SELECT_CLEARENCE_TIME"));
        Country oCountry;
		try{
            ResultSet ite = con.prepareStatement(DataBaseQueries.SELECT_CLEARENCE_TIME).executeQuery();
            while (ite.next()) {
				oCountry = mhCountry.get(ite.getString(1));
				HashMap clearanceTime =oCountry.getClearanceTime();	
				ClearanceTime clea = new ClearanceTime();		
				
				if(ite.getString(3)!=null)
					clea.setExportClearanceTime(ite.getString(3));					
				if(ite.getString(4)!=null)
					clea.setImportClearanceTime(ite.getString(4));				
				if(ite.getString(5)!=null)
					clea.setPublishOwner(ite.getString(5));					
				if(ite.getString(6)!=null)
					clea.setPublishDate(ite.getDate(6));
				
				clearanceTime.put(ite.getString(2), clea);
				oCountry.setClearanceTime(clearanceTime);
			}	
		}catch (Exception e) {
			throw (new IIMexException("Error in the DB row", e));
		}
		Logger.traceExit();
	}
	// add a new country
	public int addCountry(Country coun) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_COUNTRY);
			pstm.setString(1,coun.getCountryCode());
			pstm.setString(2,coun.getCountryName());
			if(coun.getActive())
				pstm.setString(3,"y");
			else pstm.setString(3,"n");
			pstm.setString(4,coun.getWorldAreaCode());
			pstm.setString(5,coun.getCustomsZoneCode());
			pstm.setString(6,coun.getPublishOwner());
			pstm.setDate(7,new java.sql.Date(coun.getPublishDate().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive country "+coun.getCountryName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
	//update it
	public int updateCountry(Country coun) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_COUNTRY);
			if(coun.getActive())
				pstm.setString(1,"y");
			else pstm.setString(1,"n");
			pstm.setString(2,coun.getCustomsZoneCode());
			pstm.setString(3,coun.getWorldAreaCode());
			pstm.setString(4,coun.getPublishOwner());
			pstm.setDate(5,new java.sql.Date(coun.getPublishDate().getTime()));
			pstm.setString(6,coun.getCountryCode());
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive country "+coun.getCountryName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
	//remove it
	public int removeCountry(String countryCode) throws IIMexException{
		Logger.traceEntry();
		int removeOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_COUNTRY);
			pstm.setString(1,countryCode);
			removeOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive country "+countryCode, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return removeOK;
	}
	//add a new tax
	public int addTax(ValueAddedTax tax, String code) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_VALUE_ADDED_TAX);
			pstm.setString(1,code);
			pstm.setString(2,tax.getGroup());
			pstm.setString(3,tax.getValue());
			pstm.setString(4,tax.getOwner());
			pstm.setDate(5,new java.sql.Date(new Date().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error adding tax ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
	//update it
	public int updateTax(ValueAddedTax tax, String code) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_VALUE_ADDED_TAX);
			pstm.setString(1,tax.getValue());
			pstm.setString(2,tax.getOwner());
			pstm.setDate(3,new java.sql.Date(new Date().getTime()));
			pstm.setString(4,code);
			pstm.setString(5,tax.getGroup());
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error updating tax " , e));
		} finally {
closeConnection(con);
        }
		Logger.traceExit();
		return updateOK;
	}
	//remove it
	public int removeTax(String countryCode, String codePg) throws IIMexException{
		Logger.traceEntry();
		int removeOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_VALUE_ADDED_TAX);
			pstm.setString(1,countryCode);
			pstm.setString(2,codePg);
			removeOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error removing tax ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return removeOK;
	}
	//add shipping isntructions for a country
	public int addInstruction(ShippingInstruction ship, String code) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_INSTRUCTIONS);
			pstm.setString(1,code);
			pstm.setString(9,ship.getDivision());
			pstm.setString(2,ship.getSeedSamples());
			pstm.setString(3,ship.getShippingInstructions());
			pstm.setString(4,ship.getSeedTreatment());
			pstm.setString(5,ship.getMiscallenous());
			pstm.setString(6,ship.getPackaging());
			pstm.setString(7,ship.getOwner());
			pstm.setDate(8,new java.sql.Date(new Date().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error adding instructions ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
	//update it
	public int updateInstruction(ShippingInstruction ship, String code) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_INSTRUCTIONS);
			pstm.setString(8,code);
			pstm.setString(9,ship.getDivision());
			pstm.setString(1,ship.getSeedSamples());
			pstm.setString(2,ship.getShippingInstructions());
			pstm.setString(3,ship.getSeedTreatment());
			pstm.setString(4,ship.getMiscallenous());
			pstm.setString(5,ship.getPackaging());
			pstm.setString(6,ship.getOwner());
			pstm.setDate(7,new java.sql.Date(new Date().getTime()));
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error updating tax " , e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
	//remove it
	public int removeInstruction(String country, String division) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_INSTRUCTIONS);
			pstm.setString(1,country);
			pstm.setString(2,division);
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error removing tax " , e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
	//add Fees
	public int addFees(Fees fee, String code, String shipping) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_FEES);
			pstm.setString(1,code);
			pstm.setString(2,shipping);
			pstm.setString(3,fee.getCertificateOfOrigin());
			pstm.setString(4,fee.getConsular());
			pstm.setString(5,fee.getFederalSeedLab());
			pstm.setString(6,fee.getHandling());
			pstm.setString(7,fee.getInsurance());
			pstm.setString(8,fee.getLegalization());
			pstm.setString(9,fee.getPhytosanitaryCertificate());
			pstm.setString(10,fee.getSeedAnalysisCertificate());
			pstm.setString(11,fee.getInspection());
			pstm.setString(12,fee.getOther());
			pstm.setString(13,fee.getPublishOwner());
			pstm.setDate(14,new java.sql.Date(new Date().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error adding instructions ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
//update it
	public int updateFees(Fees fee, String code, String shipping) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_FEES);
			pstm.setString(13,code);
			pstm.setString(14,shipping);
			pstm.setString(1,fee.getCertificateOfOrigin());
			pstm.setString(2,fee.getConsular());
			pstm.setString(3,fee.getFederalSeedLab());
			pstm.setString(4,fee.getHandling());
			pstm.setString(5,fee.getInsurance());
			pstm.setString(6,fee.getLegalization());
			pstm.setString(7,fee.getPhytosanitaryCertificate());
			pstm.setString(8,fee.getSeedAnalysisCertificate());
			pstm.setString(9,fee.getInspection());
			pstm.setString(10,fee.getOther());
			pstm.setString(11,fee.getPublishOwner());
			pstm.setDate(12,new java.sql.Date(new Date().getTime()));
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error updating tax " , e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
	//add clearance time for a country
	public int addTime(ClearanceTime clea,String code) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_CLEARENCE_TIME);
			pstm.setString(1,code);
			pstm.setString(2,clea.getTransportModeCode());
			pstm.setString(3,clea.getExportClearanceTime());
			pstm.setString(4,clea.getImportClearanceTime());
			pstm.setString(5,clea.getPublishOwner());
			pstm.setDate(6,new java.sql.Date(new Date().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error adding custom clearance time ", e));
		} finally {
		closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
	//update it
	public int updateTime(ClearanceTime clea,String code) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_CLEARENCE_TIME);
			pstm.setString(5,code);
			pstm.setString(6,clea.getTransportModeCode());
			pstm.setString(1,clea.getExportClearanceTime());
			pstm.setString(2,clea.getImportClearanceTime());
			pstm.setString(3,clea.getPublishOwner());
			pstm.setDate(4,new java.sql.Date(new Date().getTime()));
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error updating  custom clearance time " , e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
	//add an import license time for a country
	public int addLicense(ImportLicenseApproval app, String code,String hts) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_IMPORT_LICENSE_APPROVAL);
			pstm.setString(1,code);
			pstm.setString(2,hts);
			pstm.setString(3,app.getImportLicenseApproval());
			pstm.setString(4,app.getPublishOwner());
			pstm.setDate(5,new java.sql.Date(new Date().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error adding license ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
	//update it
	public int updateLicense(ImportLicenseApproval app, String code,String hts) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_IMPORT_LICENSE_APPROVAL);
			pstm.setString(4,code);
			pstm.setString(5,hts);
			pstm.setString(1,app.getImportLicenseApproval());
			pstm.setString(2,app.getPublishOwner());
			pstm.setDate(3,new java.sql.Date(new Date().getTime()));
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error updating license " , e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
	// remove it
	public int removeLicense(String code,String hts) throws IIMexException{
		Logger.traceEntry();
		int removeOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_IMPORT_LICENSE_APPROVAL);
			pstm.setString(1,code);
			pstm.setString(2,hts);
			removeOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error removing license ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return removeOK;
	}
	//add a new company determiantion for a country
	public int addCompany(CompanyDetermination cd, String code) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_COMPANY_DETERMINATION);
			pstm.setString(1,code);
			pstm.setString(2,cd.getDivision());
			pstm.setString(3,cd.getGroup());
			pstm.setString(4,cd.getActive());
			pstm.setString(5,cd.getSoldToCompanyCode());
			pstm.setString(6,cd.getSalesCompanyName());
			pstm.setString(7,cd.getBillToCompanyCode());
			pstm.setString(8,cd.getShipToCompanyName());
			pstm.setString(9,cd.getConsignToCompanyName());
			pstm.setString(10,cd.getSellingCompanyCode());
			pstm.setString(11,cd.getSalesOrganisation());
			pstm.setString(12,cd.getPublishOwner());
			pstm.setDate(13,new java.sql.Date(new Date().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error adding company determination ", e));
		} finally {
		closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
	//update it 
	public int updateCompany(CompanyDetermination cd, String code) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_COMPANY_DETERMINATION);
			pstm.setString(11,code);
			pstm.setString(12,cd.getDivision());
			pstm.setString(13,cd.getGroup());
			pstm.setString(10,cd.getActive());
			pstm.setString(1,cd.getSoldToCompanyCode());
			pstm.setString(2,cd.getSalesCompanyName());
			pstm.setString(3,cd.getBillToCompanyCode());
			pstm.setString(4,cd.getShipToCompanyName());
			pstm.setString(5,cd.getConsignToCompanyName());
			pstm.setString(6,cd.getSellingCompanyCode());
			pstm.setString(7,cd.getSalesOrganisation());
			pstm.setString(8,cd.getPublishOwner());
			pstm.setDate(9,new java.sql.Date(new Date().getTime()));
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error updating company determination " , e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
    //remove it
	public int removeCompany(CompanyDetermination cd, String code) throws IIMexException{
		Logger.traceEntry();
		int removeOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_COMPANY_DETERMINATION);
			pstm.setString(1,code);
			pstm.setString(2,cd.getDivision());
			pstm.setString(3,cd.getGroup());
			removeOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error removing company determination ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return removeOK;
	}
	
}