/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.tableloader;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.collections.CountryCollection;
import com.monsanto.enterprise.iimex.collections.IncotermsTransportCollection;
import com.monsanto.enterprise.iimex.elements.*;

public class TableLoadCountryToCountry extends TableLoader {

    /**
     * Load the data from the database to a HashTable
     * Those are all about a shipment (depending of a shipping and a destination country)
     *
     * @return
     * @throws IIMexException
     */

    public Vector<CountryToCountry> loadCountriesToCountries(CountryCollection countriesCollection, IncotermsTransportCollection incoTpColl) throws IIMexException {
        Logger.traceEntry();

        Vector<CountryToCountry> mhCountryToCountry = new Vector<CountryToCountry>();

        List shipping = countriesCollection.getAllActiveCountry();

        List destination = countriesCollection.getAllActiveCountry();

        Iterator shipIt = shipping.iterator();

        Iterator destIt;

        ProductMovementInformationLoader productMovementInformationLoader = new ProductMovementInformationLoader();
        ProductMovementInformation productInformation = productMovementInformationLoader.getProductInformation();
        while (shipIt.hasNext()) {
            Country ship = (Country) shipIt.next();
            destIt = destination.iterator();
            while (destIt.hasNext()) {
                Country dest = (Country) destIt.next();
                CountryToCountry cToC = new CountryToCountry();
                cToC.setShippingCode(ship.getCountryCode());
                cToC.setDestinationCode(dest.getCountryCode());
                cToC.setRestrictions(productInformation.getRestrictionsBetweenCountries(cToC.getShippingCode(), cToC.getDestinationCode()));
                cToC.setPreferredPortOfEntry(
                        productInformation.getPreferredPortsBetweenCountries(cToC.getShippingCode(),
                                cToC.getDestinationCode(),
                                countriesCollection.getCountryName(cToC.getDestinationCode())));
                cToC.setTransportationTime(productInformation.getPreferredTransportTimesBetweenCountries(cToC.getShippingCode(),
                        cToC.getDestinationCode(),
                        countriesCollection.getCountryName(cToC.getDestinationCode()), incoTpColl));
                mhCountryToCountry.add(cToC);
            }
        }

        Logger.traceExit();
        return mhCountryToCountry;
    }

    //add a new preferred port
    public int addPort(PreferredPort pp, String code, String div) throws IIMexException {
        Logger.traceEntry();
        int addOk = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.ADD_PREFERRED_PORT_OF_ENTRY);
            pstm.setString(1, code);
            pstm.setString(2, pp.getDestCountryCode());
            pstm.setString(3, div);
            pstm.setString(4, pp.getPort());
            pstm.setString(5, pp.getOwner());
            pstm.setDate(6, new java.sql.Date(new Date().getTime()));
            addOk = pstm.executeUpdate();
            pstm.close();

        } catch (SQLException e) {
            throw (new IIMexException("Error adding port ", e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return addOk;
    }

    //update a preferred port
    public int updatePort(PreferredPort pp, String code, String div) throws IIMexException {
        Logger.traceEntry();
        int updateOK = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.UPDATE_PREFERRED_PORT_OF_ENTRY);
            pstm.setString(4, code);
            pstm.setString(5, pp.getDestCountryCode());
            pstm.setString(6, div);
            pstm.setString(1, pp.getPort());
            pstm.setString(2, pp.getOwner());
            pstm.setDate(3, new java.sql.Date(new Date().getTime()));
            updateOK = pstm.executeUpdate();
            pstm.close();

        } catch (SQLException e) {
            throw (new IIMexException("Error updating port ", e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return updateOK;
    }

    //remove a preferred port
    public int removePort(String ship, String dest, String div) throws IIMexException {
        Logger.traceEntry();
        int removeOK = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.REMOVE_PREFERRED_PORT_OF_ENTRY);
            pstm.setString(1, ship);
            pstm.setString(2, dest);
            pstm.setString(3, div);
            removeOK = pstm.executeUpdate();
            pstm.close();

        } catch (SQLException e) {
            throw (new IIMexException("Error removing port ", e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return removeOK;
    }

    //add a new transportation time
    public int addTransportationTime(TransportationTime tp, String code) throws IIMexException {
        Logger.traceEntry();
        int addOk = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.ADD_TRANSPORTATION_TIME);
            pstm.setString(1, code);
            pstm.setString(2, tp.getDestCountryCode());
            pstm.setString(3, tp.getTpModeCode());
            pstm.setString(4, tp.getFreightBooking());
            pstm.setString(5, tp.getTransportationTime());
            pstm.setString(6, tp.getPublishOwner());
            pstm.setDate(7, new java.sql.Date(new Date().getTime()));
            addOk = pstm.executeUpdate();
            pstm.close();

        } catch (SQLException e) {
            throw (new IIMexException("Error adding transportation time ", e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return addOk;
    }

    //update one
    public int updateTransportationTime(TransportationTime tp, String code) throws IIMexException {
        Logger.traceEntry();
        int updateOK = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.UPDATE_TRANSPORTATION_TIME);
            pstm.setString(5, code);
            pstm.setString(6, tp.getDestCountryCode());
            pstm.setString(7, tp.getTpModeCode());
            pstm.setString(1, tp.getFreightBooking());
            pstm.setString(2, tp.getTransportationTime());
            pstm.setString(3, tp.getPublishOwner());
            pstm.setDate(4, new java.sql.Date(new Date().getTime()));
            updateOK = pstm.executeUpdate();
            pstm.close();

        } catch (SQLException e) {
            throw (new IIMexException("Error updating transportation time ", e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return updateOK;
    }

    //remove one
    public int removeTransportationTime(TransportationTime tp, String code) throws IIMexException {
        Logger.traceEntry();
        int removeOK = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();

            pstm = con.prepareStatement(DataBaseQueries.REMOVE_TRANSPORTATION_TIME);
            pstm.setString(1, code);
            pstm.setString(2, tp.getDestCountryCode());
            pstm.setString(3, tp.getTpModeCode());
            removeOK = pstm.executeUpdate();
            pstm.close();

        } catch (SQLException e) {
            throw (new IIMexException("Error removing transportation time ", e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return removeOK;
	}

    public int removeRestriction(String destCode, String originCode, String productGroupCode) throws IIMexException {
        Logger.traceEntry();
        int removeOK = 0;
        Connection con = null;
        try {
            con = getConnection();

            PreparedStatement pstm = con.prepareStatement(DataBaseQueries.REMOVE_RESTRICTION);
            pstm.setString(1, destCode);
            pstm.setString(2, originCode);
            pstm.setString(3, productGroupCode);
            removeOK = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error removing shipping restriction", e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return removeOK;
    }

    public int updateRestriction(ShippingRestriction shippingRestriction) throws IIMexException {
        Logger.traceEntry();
        int updateOK = 0;
        Connection con = null;
        try {
            con = getConnection();

            PreparedStatement pstm = con.prepareStatement(DataBaseQueries.UPDATE_RESTRICTION);
            pstm.setInt(1, Integer.valueOf(shippingRestriction.getRestrictionTypeCode()));
            pstm.setString(2, shippingRestriction.getComments());
            pstm.setString(3, shippingRestriction.getPublishOwnerId());
            pstm.setDate(4, new java.sql.Date(System.currentTimeMillis()));
            // for where clause
            pstm.setString(5, shippingRestriction.getDestination());
            pstm.setString(6, shippingRestriction.getOrigin());
            pstm.setString(7, shippingRestriction.getProductCode());
            updateOK = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error updating shipping restriction", e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return updateOK;
    }

    public int addRestriction(ShippingRestriction shippingRestriction) throws IIMexException {
        Logger.traceEntry();
        int addOK = 0;
        Connection con = null;
        try {
            con = getConnection();

            PreparedStatement pstm = con.prepareStatement(DataBaseQueries.ADD_RESTRICTION);
            pstm.setString(1, shippingRestriction.getOrigin());
            pstm.setString(2, shippingRestriction.getDestination());
            pstm.setString(3, shippingRestriction.getProductCode());
            pstm.setString(4, shippingRestriction.getRestrictionTypeCode());
            pstm.setString(5, shippingRestriction.getComments());
            pstm.setString(6, shippingRestriction.getPublishOwnerId());
            pstm.setDate(7, new java.sql.Date(System.currentTimeMillis()));
            addOK = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error adding shipping restriction", e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return addOK;
    }
}