/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.tableloader;



import java.util.Date;
import java.util.HashMap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.PricingCurrency;



public class TableLoadCurrency extends TableLoader{

	/**

	 * Load the row from the table IE_PRICING and PRICING_EXCEPTIONS and set them in a hashTable

	 * @return

	 * @throws IIMexException

	 */

	public HashMap<String, HashMap<String, PricingCurrency>> loadCurrencyRows()

	throws IIMexException{

		Logger.traceEntry();

		HashMap<String, HashMap<String, PricingCurrency>> mhCurrency = new HashMap<String, HashMap<String, PricingCurrency>>();
        Connection con=null;

        try{
            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_CURRENCY).executeQuery();

			while (it.next()) {

				String toCountry= it.getString(1);

				String stoCurrency;

				String salesCurrency;

				stoCurrency = it.getString(2);

				salesCurrency = it.getString(3);

				PricingCurrency oCurrency= new PricingCurrency();

				oCurrency.setSToCountry(toCountry);
				
				oCurrency.setSFromCountry("*");

				oCurrency.setSSalesCurrency(salesCurrency);

				oCurrency.setSIntercoCurrency(stoCurrency);
					
				HashMap<String, PricingCurrency> mhFromToCurrency;
				
				if(!mhCurrency.containsKey(toCountry))

					mhFromToCurrency = new HashMap<String, PricingCurrency>();

				else
					
					mhFromToCurrency = mhCurrency.get(toCountry);
						
				mhFromToCurrency.put(oCurrency.getFromCountry(), oCurrency);

				mhCurrency.put(toCountry, mhFromToCurrency);

			}
           it.close();

		  it = con.prepareStatement(DataBaseQueries.SELECT_CURRENCY_EXCEPTION).executeQuery();
			
			while(it.next()){
				
				String toCountry= it.getString(2);

				String stoCurrency;

				String salesCurrency;

				String fromCountry = it.getString(1);

				stoCurrency = it.getString(3);

				salesCurrency = it.getString(4);

				PricingCurrency oCurrency= new PricingCurrency();

				oCurrency.setSToCountry(toCountry);
				
				oCurrency.setSFromCountry(fromCountry);

				oCurrency.setSSalesCurrency(salesCurrency);

				oCurrency.setSIntercoCurrency(stoCurrency);
					
				HashMap<String, PricingCurrency> mhFromToCurrency;
				
				if(!mhCurrency.containsKey(toCountry))

					mhFromToCurrency = new HashMap<String, PricingCurrency>();

				else
					
					mhFromToCurrency = mhCurrency.get(toCountry);
						
				mhFromToCurrency.put(oCurrency.getFromCountry(), oCurrency);

				mhCurrency.put(toCountry, mhFromToCurrency);
				
			}
            it.close();

		} catch (SQLException _ex) {

		

			throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));

		

		} finally {



			closeConnection(con);

		}

		Logger.traceExit();

		return mhCurrency;

	}
//add a currency to the database
	public int addCurrency(PricingCurrency pc,String owner) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_CURRENCY);
			pstm.setString(1,pc.getToCountry());
			pstm.setString(2,pc.getIntercoCurrency());
			pstm.setString(3,pc.getSalesCurrency());
			pstm.setString(4,"Y");
			pstm.setString(5,owner);
			pstm.setDate(6,new java.sql.Date(new Date().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error adding currency ", e));
		} finally {
		closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
//update a currency in the database
	public int updateCurrency(PricingCurrency pc, String owner) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_CURRENCY);
			pstm.setString(6,pc.getToCountry());
			pstm.setString(1,pc.getIntercoCurrency());
			pstm.setString(2,pc.getSalesCurrency());
			pstm.setString(3,"Y");
			pstm.setString(4,owner);
			pstm.setDate(5,new java.sql.Date(new Date().getTime()));
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error updating currency " , e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
//	remove a currency from the database
	public int removeCurrency(PricingCurrency pc) throws IIMexException{
		Logger.traceEntry();
		int removeOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_CURRENCY);
			pstm.setString(1,pc.getToCountry());removeOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error removing currency ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return removeOK;
	}
//add an exception
	public int addCurrencyException(PricingCurrency pc, String owner) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_CURRENCY_EXCEPTION);
			pstm.setString(1,pc.getFromCountry());
			pstm.setString(2,pc.getToCountry());
			pstm.setString(3,pc.getIntercoCurrency());
			pstm.setString(4,pc.getSalesCurrency());
			pstm.setString(5,owner);
			pstm.setDate(6,new java.sql.Date(new Date().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error adding currency ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
//update it 
	public int updateCurrencyException(PricingCurrency pc, String owner) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_CURRENCY_EXCEPTION);
			pstm.setString(5,pc.getFromCountry());
			pstm.setString(6,pc.getToCountry());
			pstm.setString(1,pc.getIntercoCurrency());
			pstm.setString(2,pc.getSalesCurrency());
			pstm.setString(3,owner);
			pstm.setDate(4,new java.sql.Date(new Date().getTime()));
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error updating currency " , e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
// remove it
	public int removeCurrencyException(PricingCurrency pc) throws IIMexException{
		Logger.traceEntry();
		int removeOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_CURRENCY_EXCEPTION);
			pstm.setString(1,pc.getFromCountry());
			pstm.setString(2,pc.getToCountry());
			removeOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error removing currency ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return removeOK;
	}

}

