package com.monsanto.enterprise.iimex.tableloader;



import java.util.Date;
import java.util.Vector;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.WorldArea;
import com.monsanto.enterprise.iimex.elements.customZone;



public class TableLoadCustomZone extends TableLoader{

//load the custom zones
	public Vector<customZone> loadCustomZone()

	throws IIMexException{

		Logger.traceEntry();

		Vector<customZone> zones = new Vector<customZone>();
        Connection con=null;

    try{
        con = getConnection();
        ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_CUSTOMS_ZONE).executeQuery();

			while (it.next()) {
			
				customZone zone = new customZone();
			
				zone.setCustomZoneCode(it.getString(1));
			
				zone.setCustomZoneName(it.getString(2));
			
				zone.setAreaCode(it.getString(3));
			
				zone.setPublisOwner(it.getString(4));
			
				zone.setPublisDate((Date)it.getDate(5));
			
				zones.add(zone);			
				
			}

		} catch (Exception _ex) {

				throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));

		} finally {

		 closeConnection(con);

		}

		Logger.traceExit();

		return zones;

	}
	//add one
	public int addCustomZone(customZone zone)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_CUSTOM_ZONE);
			pstm.setString(1,zone.getCustomZoneCode());
			pstm.setString(2,zone.getCustomZoneName());
			pstm.setString(3,zone.getAreaCode());
			pstm.setString(4,zone.getPublisOwner());
			pstm.setDate(5,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error addind custom zone"+zone.getCustomZoneName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//update it
	public int updateCustomZone(customZone zone)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_CUSTOM_ZONE);
			pstm.setString(5,zone.getCustomZoneCode());
			pstm.setString(1,zone.getCustomZoneName());
			pstm.setString(2,zone.getAreaCode());
			pstm.setString(3,zone.getPublisOwner());
			pstm.setDate(4,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating custom zone"+zone.getCustomZoneName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//remove it
	public int removeCustomZone(String zone)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_CUSTOM_ZONE);
			pstm.setString(1,zone);
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating custom zone"+zone, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
}