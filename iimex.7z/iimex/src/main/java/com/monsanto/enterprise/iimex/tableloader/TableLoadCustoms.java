package com.monsanto.enterprise.iimex.tableloader;

import java.sql.Date;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreObjectResultSetForwardIterator;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dbdataservices.PersistentStoreDBPreparedStatement;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.MonitoredUser;

public class TableLoadCustoms extends TableLoader{
	
	public List<String> loadCustoms()throws IIMexException{
		Logger.traceEntry();
		
		List customs = new ArrayList();		
		Connection con=null;
		try {
            con = getConnection();

			ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_FROM_CUSTOMS_ZONE).executeQuery();
			while(it.next()){
				customs.add(it.getString(1));
			}
			
			
		} catch (SQLException e) {

			throw (new IIMexException("Error in the DB row", e));

		}finally{

			closeConnection(con);

		}
		
		Logger.traceExit();
		return customs;
	}
	
}