package com.monsanto.enterprise.iimex.tableloader;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dbdataservices.PersistentStoreDBPreparedStatement;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.Division;

public class TableLoadDivision extends TableLoader {
	//load all divisions in the application
	public List<Division> loadDivisions()	throws IIMexException{

		Logger.traceEntry();

		List<Division> divisions = new ArrayList<Division>();
		
        Connection con = null;

        try{

            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_FROM_DIVISION).executeQuery();
            while (it.next()) {

				Division div = new Division();

				String divisionCode = it.getString(1);

				div.setDivisionCode(divisionCode);
				
				String divisionName = it.getString(2);
				
				div.setDivisionName(divisionName);
				
				div.setPublishOwner(it.getString(3));
				
				div.setPublishDate(it.getDate(4));
				
				divisions.add(div);
			}
            it.close();

    } catch (SQLException _ex) {

			throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));

		} finally {

			closeConnection(con);

		}

		Logger.traceExit();

		return divisions;

	}
	// add a new one in the database
	public int addDivision(Division div)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INSERT_DIVISION);
			pstm.setString(1,div.getDivisionCode());
			pstm.setString(2,div.getDivisionName());
			pstm.setString(3,div.getPublishOwner());
			pstm.setDate(4,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error addind division"+div.getDivisionName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	// update one
	public int updateDivision(Division div)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_DIVISION);
			pstm.setString(4,div.getDivisionCode());
			pstm.setString(1,div.getDivisionName());
			pstm.setString(2,div.getPublishOwner());
			pstm.setDate(3,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating division"+div.getDivisionName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//remove one
	public int removeDivision(String div)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.DELETE_DIVISION);
			pstm.setString(1,div);
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating division"+div, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	
	
}