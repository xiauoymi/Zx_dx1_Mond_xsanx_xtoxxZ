/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.tableloader;



import java.io.File;

import java.io.FileInputStream;

import java.io.FileNotFoundException;

import java.io.InputStream;

import java.util.ArrayList;

import java.util.Date;

import java.util.HashMap;

import java.util.List;

import java.util.TreeMap;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;




import com.monsanto.AbstractLogging.Logger;


import com.monsanto.Util.StringUtils;


import com.monsanto.enterprise.iimex.DataBaseQueries;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.elements.DocumentConditions;

import com.monsanto.enterprise.iimex.elements.Documents;







public class TableLoadDocument extends TableLoader	{

	/**Load the documents information from the DB and put the data concerning the 

	 * documents in a Documents object and in a DocumentConditions object.

	 * Set the DocumentsConditions in the corresponding Documents (Documents contains the list 

	 * of the DocumentConditions with the same documentCode.

	 * Stock the Documents in a HashMap

	 * where the key is the document code and the value is the Documents objects.

	 */

	

	protected int docCounter=0;

	

	public TreeMap<Integer, Documents> loadDocumentsRows()

	throws IIMexException{

		Logger.traceEntry();

		TreeMap<Integer, Documents> mhDocuments = new TreeMap<Integer, Documents>();

        Connection con = null;

        try {

            con = getConnection();
            ResultSet it =con.prepareStatement(DataBaseQueries.SELECT_FROM_DOCUMENTS).executeQuery();

			while (it.next()) {

				docCounter=docCounter+1;

				Documents oDocuments = new Documents();

				

				int documentCode =it.getInt(1);

				oDocuments.setIDocCode(documentCode);

				oDocuments.setSDocName(it.getString(2));

				oDocuments.setSTypeRequirement(it.getString(3));

				oDocuments.setPurpose(it.getString(4));

				oDocuments.setFlag(it.getString(5));

				oDocuments.setHasBlob(it.getString(6));

				oDocuments.setPublishDate(it.getDate(7));

				oDocuments.setPublishOwner(it.getString(8));

				oDocuments.setFileName(it.getString(9));

				Integer iDocumentCode = new Integer(documentCode);

				oDocuments.setNotNewDoc(true);

				mhDocuments.put(iDocumentCode, oDocuments);
			}

            it.close();
			

			ResultSet itDocCod =con.prepareStatement(DataBaseQueries.SELECT_FROM_DOCUMENTS_CONDITION).executeQuery();

			while(itDocCod.next()){	

				int documentCode =itDocCod.getInt(1);
				
				DocumentConditions docConditions = new DocumentConditions();

				docConditions.setDocName(itDocCod.getString(2));

				docConditions.setDocumentCode(Integer.toString(documentCode));

				docConditions.setTypeRequirement(itDocCod.getString(3));

				docConditions.setHasBlob(itDocCod.getString(5));

				docConditions.setSpecialReq(itDocCod.getString(6));

				docConditions.setBuyerSeller(itDocCod.getString(7));

				docConditions.setWhenSent(itDocCod.getString(8));

				docConditions.setWhereSent(itDocCod.getString(9));
				
				docConditions.setShippingMethod(itDocCod.getString(10));
				
				docConditions.setFromcountry(itDocCod.getString(11));

				docConditions.setFromcustomsZone(itDocCod.getString(12));

				docConditions.setToCountry(itDocCod.getString(13));

				docConditions.setCocustZone(itDocCod.getString(14));
				
				docConditions.setOriginCountry(itDocCod.getString(15));
				
				docConditions.setZoneOrigin(itDocCod.getString(16));
				
				docConditions.setTranspMode(itDocCod.getString(17));

				docConditions.setIncoterms(itDocCod.getString(18));

				docConditions.setDivision(itDocCod.getString(19));
				
				docConditions.setProductGroup(itDocCod.getString(20));

				docConditions.setTrait(itDocCod.getString(21));

				docConditions.setDocConditionCode(itDocCod.getInt(22));

				docConditions.setPublishDate(itDocCod.getDate(23));

				docConditions.setPublishOwner(itDocCod.getString(24));
			
                docConditions.setComments(itDocCod.getString(25));

				if(mhDocuments.containsKey(documentCode)){

					Documents oDoc = mhDocuments.get(documentCode);

					if(oDoc.isReq()){

						HashMap<Integer,DocumentConditions> docConditionsHM = oDoc.getDocumentConditionHM();

						docConditionsHM.put(docConditions.getDocConditionCode(),docConditions);

					}else{

						HashMap <Integer,DocumentConditions>hmdocConditions = new HashMap<Integer,DocumentConditions>();

						hmdocConditions.put(docConditions.getDocConditionCode(),docConditions);

						oDoc.setDocumentConditionsHM(hmdocConditions);

						oDoc.setHasReq(true);

					}

					}

				}
            itDocCod.close();

		} catch (SQLException e) {

			throw (new IIMexException("Error loading the link and documentation information", e));

		}finally{

            closeConnection(con);

        }

		

		Logger.traceExit();

		

		return mhDocuments;

	}

    public List<String> loadDocumentsColumName()

	throws IIMexException{

		Logger.traceEntry();

		List<String> fieldList= new ArrayList<String>();
        Connection con = null;
	try{

        con = getConnection();
        try {
            fieldList = getColumnNames(DataBaseQueries.SELECT_FROM_DOCUMENTS, con);
        } catch (SQLException e) {
            throw new IIMexException("",e);
        }

    }finally{

		closeConnection(con);	}Logger.traceExit();

		return fieldList;

	}

	public int inactiveDocument(int docId) 

	throws IIMexException{

		Logger.traceEntry();

		int rowDelete=0;

		Logger.traceEntry();

		PreparedStatement pstm =null;

		Connection con=null;
		try {
            con = getConnection();

			pstm = con.prepareStatement(DataBaseQueries.INACTIVE_DOCUMENT);

			pstm.setInt(1,docId);

			rowDelete=pstm.executeUpdate();

		}catch (SQLException e){

			throw (new IIMexException("Error deleting document ", e));

		}finally {

			closeConnection(con);
		}

		Logger.traceExit();

		return rowDelete;

	}

	public int updateDocuments(int docId, String docName, String typeReq,

			String purpose, String filePath) throws IIMexException{



		InputStream is = null;

		Logger.traceEntry();

		int rowUpdate=0;

		String fileName = "";

		

		PreparedStatement pstm=null;

		Connection con=null;
		try {
            con = getConnection();

			pstm = con.prepareStatement(DataBaseQueries.UPDATE_DOC_REQ);

			pstm.setString(1,docName);

			pstm.setString(2,typeReq);

			pstm.setString(3,purpose);

			pstm.setInt(4,docId);

			rowUpdate=pstm.executeUpdate();
            pstm.close();
		

			if(rowUpdate>0){

				if(!StringUtils.isNullOrEmpty(filePath)){

						String[] tokenPath = StringUtils.tokenize(filePath,"\\", false);

						File file = null;

						fileName=tokenPath[tokenPath.length-1];

						file = new File(filePath);

						is = new FileInputStream(filePath);

					 rowUpdate=0;

						pstm= con.prepareStatement(DataBaseQueries.UPLOAD_DOC);

						pstm.setBinaryStream(1,is, (int)file.length());

						pstm.setString(2,fileName);

						pstm.setInt(3,docId);

						rowUpdate=pstm.executeUpdate();
                        pstm.close();
						if(rowUpdate>0){

							pstm = con.prepareStatement(DataBaseQueries.SET_HAS_DOC);

							pstm.setInt(1, docId);

							rowUpdate=pstm.executeUpdate();

                            pstm.close();

						}

					}
			}
		} catch (SQLException e) {

			throw (new IIMexException("Error updating document "+docName, e));

		} catch (FileNotFoundException fex) {

			throw (new IIMexException("Error updating document "+docName +", file not found  ", fex));

			

		} finally {

			closeConnection(con);

		}

		Logger.traceExit();

	return rowUpdate;	

	

	}

	public int addDocument(int docId, String docName, String typeReq,

			String purpose, String filePath, String owner) throws IIMexException {

		Logger.traceEntry();

		int rowInsert = 0;

		PreparedStatement pstm =null;
        Connection con=null;
		try{
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INSERT_NEW_DOC);

			pstm.setInt(1,docId);

			pstm.setString(2,docName);

			pstm.setString(3,typeReq );

			pstm.setString(4,purpose);

			pstm.setString(5,"Y");

			if(!StringUtils.isNullOrEmpty(filePath))
			
				pstm.setString(6,"Y");

			else pstm.setString(6,"N");
			
			pstm.setDate(8,new java.sql.Date(new Date().getTime()));

			pstm.setString(7,owner);

			rowInsert=pstm.executeUpdate();

			pstm.close();
			
			if(!StringUtils.isNullOrEmpty(filePath)){
			
					String[] tokenPath = StringUtils.tokenize(filePath,"\\", false);

					File file = null;

					String fileName=tokenPath[tokenPath.length-1];

					file = new File(filePath);

					FileInputStream is = new FileInputStream(filePath);

					rowInsert=0;

					pstm = con.prepareStatement(DataBaseQueries.INSERT_DOC_BLOB);

					pstm.setBinaryStream(2,is, (int)file.length());

					pstm.setString(3,fileName);

					pstm.setInt(1,docId);

					rowInsert=pstm.executeUpdate();

                    pstm.close();
					
				}


		}catch (SQLException e){

			throw (new IIMexException("Error addind document "+docName, e));

		} catch (FileNotFoundException e) {
			throw (new IIMexException("Error addind document "+docName, e));
		}finally {

			closeConnection(con);
		}

		Logger.traceExit();

		return rowInsert;

	}

	public int getDocConter(){

		return docCounter;

	}

	public int deleteDocumentCondition(int docCondCode) throws IIMexException{

		

		Logger.traceEntry();

		int rowDelete=0;

		PreparedStatement pstm =null;
        Connection con=null;
		try{
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.DELETE_DOCUMENT_CONDITION);

			pstm.setInt(1,docCondCode);

			

			rowDelete=pstm.executeUpdate();

		}catch (SQLException e){

			throw (new IIMexException("Error deleting document condition ", e));

		}finally {

			closeConnection(con);
		}

		Logger.traceExit();

		return rowDelete;

	}

	public int addDocumentCondition(DocumentConditions docCond) throws IIMexException{

		Logger.traceEntry();

		int rowInsert=0;

		PreparedStatement pstm =null;
        Connection con=null;
		try{
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INSERT_DOCUMENT_CONDITION);

			pstm.setString(1,docCond.getDocumentCode());

			pstm.setString(2,docCond.getSpecialReq());

			pstm.setString(3,docCond.getBuyerSeller());

            pstm.setString(4,docCond.getComments());
			
			pstm.setString(5,docCond.getWhenSent());
			
			pstm.setString(6,docCond.getWhereSent());

			pstm.setString(7, docCond.getShippingMethod());
			
			pstm.setString(8, docCond.getFromcountry());

			pstm.setString(9, docCond.getFromcustomsZone());

			pstm.setString(10, docCond.getToCountry());

			pstm.setString(11,docCond.getToCustZone());

			pstm.setString(12, docCond.getOriginCountry());
			
			pstm.setString(13, docCond.getZoneOrigin());

			pstm.setString(14,docCond.getTranspMode());

			pstm.setString(15,docCond.getIncoterms());

			pstm.setString(16, docCond.getDivision());
			
			pstm.setString(17, docCond.getProductGroup());
			
			pstm.setString(18, docCond.getTrait());

			pstm.setString(19,docCond.getPublishOwner());

			pstm.setDate(20,new java.sql.Date(new Date().getTime()));

			rowInsert=pstm.executeUpdate();

		}catch (SQLException e){

			throw (new IIMexException("Error adding document condition ", e));

		}finally {

			closeConnection(con);
		}

		Logger.traceExit();

		return rowInsert;

		

	}

    public int updateDocumentCondition(DocumentConditions docCond) throws IIMexException{
        Logger.traceEntry();

        int rowUpdate=0;

        PreparedStatement pstm = null;
        Connection con=null;
        try{
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.UPDATE_DOCUMENT_CONDITIONS);

            //select clause bindings
            pstm.setString(1, docCond.getSpecialReq());
            pstm.setString(2, docCond.getBuyerSeller());
            pstm.setString(3, docCond.getComments());
            pstm.setString(4, docCond.getWhenSent());
            pstm.setString(5, docCond.getWhereSent());
            pstm.setString(6, docCond.getShippingMethod());
            pstm.setString(7, docCond.getFromcountry());
            pstm.setString(8, docCond.getFromcustomsZone());
            pstm.setString(9, docCond.getOriginCountry());
            pstm.setString(10, docCond.getZoneOrigin());
            pstm.setString(11, docCond.getTranspMode());
            pstm.setString(12, docCond.getIncoterms());
            pstm.setString(13, docCond.getDivision());
            pstm.setString(14, docCond.getProductGroup());
            pstm.setString(15, docCond.getTrait());
            pstm.setString(16, docCond.getPublishOwner());
            pstm.setDate(17, new java.sql.Date(new Date().getTime()));

            //where clause bindings
            pstm.setInt(18, docCond.getDocConditionCode());

            rowUpdate=pstm.executeUpdate();

        }catch (SQLException e){
            throw (new IIMexException("Error updating document condition ", e));
        }finally {
            closeConnection(con);
        }

        Logger.traceExit();
        return rowUpdate;
    }
}

