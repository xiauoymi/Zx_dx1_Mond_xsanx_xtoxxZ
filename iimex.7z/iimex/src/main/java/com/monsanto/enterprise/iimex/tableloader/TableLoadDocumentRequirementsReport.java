package com.monsanto.enterprise.iimex.tableloader;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.DocumentConditions;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Dec 13, 2010
 * Time: 9:54:13 AM
 * To change this template use File | Settings | File Templates.
 */
public class TableLoadDocumentRequirementsReport extends TableLoader {

    public List<DocumentConditions> loadDocumentRequirementsForReport() throws IIMexException {
        Logger.traceEntry();

        List<DocumentConditions> requirements = new ArrayList<DocumentConditions>();
        Connection con = null;

        try {
            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_DOC_REQUIREMENTS_FOR_REPORT).executeQuery();
            while (it.next()) {

                DocumentConditions documentConditions = new DocumentConditions();

                documentConditions.setToCountry(it.getString("DESTINATION_COUNTRY_CODE"));
                documentConditions.setToCustZone(it.getString("DESTINATION_CUSTOM_ZONE"));
                documentConditions.setFromcountry(it.getString("SHIPPING_COUNTRY_CODE"));
                documentConditions.setFromcustomsZone(it.getString("SHIPPING_CUSTOM_ZONE"));
                documentConditions.setOriginCountry(it.getString("COUNTRY_OF_ORIGIN"));
                documentConditions.setDivisionLong(it.getString("DIVISION"));
                documentConditions.setProductGroupLong(it.getString("PRODUCT_GROUP"));
                documentConditions.setTrait(it.getString("TRAIT_CODE"));
                documentConditions.setIncotermsDescr(it.getString("INCOTERMS"));
                documentConditions.setTransportLong(it.getString("TRANSPORT_MODE"));
                documentConditions.setDocName(it.getString("DOCUMENT_NAME"));
                documentConditions.setSpecialReq(it.getString("SPECIAL_REQUIREMENTS"));
                documentConditions.setWhenSent(it.getString("WHEN_TO_BE_SENT"));
                documentConditions.setWhereSent(it.getString("WHERE_TO_BE_SENT"));
                documentConditions.setBuyerSeller(it.getString("RESPONSIBLE"));
                documentConditions.setShippingMethod(it.getString("SHIPPING_METHOD"));
                documentConditions.setPublishOwner(it.getString("PUBLISH_OWNER"));
                documentConditions.setPublishDate(it.getDate("PUBLISH_DATE"));
                documentConditions.setDocumentCode(it.getString("DOCUMENT_CODE"));
                documentConditions.setDocConditionCode(it.getInt("DOCUMENT_COND_CODE"));

                requirements.add(documentConditions);
            }
            it.close();

        } catch (SQLException _ex) {
            throw (new IIMexException("Error connection to the DB please contact your IT support contact", _ex));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();

        return requirements;
    }
}
