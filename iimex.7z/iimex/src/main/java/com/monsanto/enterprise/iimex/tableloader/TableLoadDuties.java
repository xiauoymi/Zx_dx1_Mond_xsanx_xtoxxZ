/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.tableloader;



import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.ImportDuties;
import com.monsanto.enterprise.iimex.elements.ValueAddedTax;



public class TableLoadDuties extends TableLoader{

	//load the import duties information in the application

	public HashMap<String, Vector<ImportDuties>> loadDuties()

	throws IIMexException{

		Logger.traceEntry();

		HashMap<String, Vector<ImportDuties>> Duties = new HashMap<String, Vector<ImportDuties>>();
        Connection con =null;


        try{

            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_IMPORT_DUTIES).executeQuery();


			while (it.next()) {
				
				ImportDuties dut = new ImportDuties();
				
				dut.setZoneOrigin(it.getString(1));
				
				dut.setCountryOrigin(it.getString(2));
				
				dut.setZoneDestination(it.getString(3));
				
				dut.setCountryDestination(it.getString(4));
				
				String HTSCode = it.getString(5);
				
				dut.setHtsCode(HTSCode);
				
				dut.setImportDuties(it.getString(6));
				
				dut.setPublishOwner(it.getString(7));
				
				dut.setPublishDate(it.getDate(8));		

				if(Duties.containsKey(HTSCode))	
					Duties.get(HTSCode).add(dut);
				else{

					Vector<ImportDuties> HTS = new Vector<ImportDuties>();
					
					HTS.add(dut);
					
					Duties.put(HTSCode, HTS);
				}

		

			}
            it.close();
		} catch (SQLException _ex) {
			throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));	
		} finally {
			closeConnection(con);
		}

		Logger.traceExit();

		return Duties;

	}
//add a new one
	public int addDuty(ImportDuties dut) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_IMPORT_DUTIES);
			pstm.setString(1,dut.getZoneOrigin());
			pstm.setString(2,dut.getCountryOrigin());
			pstm.setString(3,dut.getZoneDestination());
			pstm.setString(4,dut.getCountryDestination());
			pstm.setString(5,dut.gethtsCode());
			pstm.setString(6,dut.getImportDuties());
			pstm.setString(7,dut.getPublishOwner());
			pstm.setDate(8,new java.sql.Date(new Date().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error adding duty ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
//update one
	public int updateDuty(ImportDuties dut) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_IMPORT_DUTIES);
			pstm.setString(4,dut.getZoneOrigin());
			pstm.setString(5,dut.getCountryOrigin());
			pstm.setString(6,dut.getZoneDestination());
			pstm.setString(7,dut.getCountryDestination());
			pstm.setString(8,dut.gethtsCode());
			pstm.setString(1,dut.getImportDuties());
			pstm.setString(2,dut.getPublishOwner());
			pstm.setDate(3,new java.sql.Date(new Date().getTime()));
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error updating duty " , e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
//remove it
	public int removeDuty(ImportDuties dut) throws IIMexException{
		Logger.traceEntry();
		int removeOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_IMPORT_DUTIES);
			pstm.setString(1,dut.getZoneOrigin());
			pstm.setString(2,dut.getCountryOrigin());
			pstm.setString(3,dut.getZoneDestination());
			pstm.setString(4,dut.getCountryDestination());
			pstm.setString(5,dut.gethtsCode());
			removeOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error removing duty ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return removeOK;
	}


}

