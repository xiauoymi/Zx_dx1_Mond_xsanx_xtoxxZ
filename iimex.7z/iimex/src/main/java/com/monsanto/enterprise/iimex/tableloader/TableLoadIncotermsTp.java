/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/


package com.monsanto.enterprise.iimex.tableloader;


import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Vector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;


import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.IncotermTransportInfo;


public class TableLoadIncotermsTp extends TableLoader {

    /**
     * Load the incoterms and the incoterms transport mode in a hashMap where the key is the incoterm code and
     * <p/>
     * the value is another hashMap where the key is the transport mode and the value is an IncotermTransportInfo
     * <p/>
     * object containing all the datas concerning the incoterms and the transport mode.
     *
     * @return
     * @throws IIMexException
     */

    public HashMap<String, HashMap<String,IncotermTransportInfo>> loadIncotermsTpRows()

            throws IIMexException {

        Logger.traceEntry();

        HashMap<String, HashMap<String,IncotermTransportInfo>> mhIncotermsTp =
                new HashMap<String, HashMap<String,IncotermTransportInfo>>();

        Connection con = null;

        try {

            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_INCOTERM_TRANSP).executeQuery();
            while (it.next()) {


                IncotermTransportInfo oIncotermsTp = new IncotermTransportInfo();


                String incotermsCode = it.getString(1);

                String transportCode = it.getString(6);

                oIncotermsTp.setSIncotermsCode(incotermsCode);

                oIncotermsTp.setSIncotermDescr(it.getString(2));

                oIncotermsTp.setSDuties(it.getString(3));

                oIncotermsTp.setSFreight(it.getString(4));

                oIncotermsTp.setSInsurance(it.getString(5));

                oIncotermsTp.setTransportCode(it.getString(6));

                oIncotermsTp.setTransportName(it.getString(7));

                oIncotermsTp.setPublishOwner(it.getString(8));

                oIncotermsTp.setPublishDate((Date) it.getDate(9));

                if (mhIncotermsTp.containsKey(incotermsCode)) {

                   HashMap<String,IncotermTransportInfo> mhTransport = mhIncotermsTp.get(incotermsCode);

                    mhTransport.put(transportCode, oIncotermsTp);

                } else {

                     HashMap<String,IncotermTransportInfo> mhTransport = new  HashMap<String,IncotermTransportInfo>();

                    mhTransport.put(transportCode, oIncotermsTp);

                    mhIncotermsTp.put(incotermsCode, mhTransport);

                }


            }
            it.close();
        } catch (SQLException e) {

            throw (new IIMexException("Error in the DB row", e));

        } finally {

            closeConnection(con);

        }

        Logger.traceExit();

        return mhIncotermsTp;

    }

    //load incoterms that are not associated to a transport mode
    public Vector<IncotermTransportInfo> loadNewIncoterm() throws IIMexException {

        Logger.traceEntry();

        Vector<IncotermTransportInfo> result = new Vector<IncotermTransportInfo>();
        Connection con = null;

        try {
            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_NEW_INCOTERM).executeQuery();

            while (it.next()) {

                IncotermTransportInfo oIncotermsTp = new IncotermTransportInfo();

                oIncotermsTp.setSIncotermsCode(it.getString(1));

                oIncotermsTp.setSIncotermDescr(it.getString(2));

                oIncotermsTp.setSDuties(it.getString(3));

                oIncotermsTp.setSFreight(it.getString(4));

                oIncotermsTp.setSInsurance(it.getString(5));

                oIncotermsTp.setPublishOwner(it.getString(6));

                oIncotermsTp.setPublishDate((Date) it.getDate(7));

                result.add(oIncotermsTp);

            }
            it.close();

        } catch (SQLException e) {

            throw (new IIMexException("Error in the DB row", e));

        } finally {

            closeConnection(con);

        }

        Logger.traceExit();

        return result;

    }

    //load the transport mode that are not associtaed to an incoterm
    public Vector<IncotermTransportInfo> loadNewTransport() throws IIMexException {

        Logger.traceEntry();

        Vector<IncotermTransportInfo> result = new Vector<IncotermTransportInfo>();
        Connection con = null;

        try {

            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_NEW_TRANSPORT).executeQuery();
            while (it.next()) {


                IncotermTransportInfo oIncotermsTp = new IncotermTransportInfo();

                oIncotermsTp.setTransportCode(it.getString(1));

                oIncotermsTp.setTransportName(it.getString(2));

                oIncotermsTp.setPublishOwner(it.getString(3));

                oIncotermsTp.setPublishDate((Date) it.getDate(4));

                result.add(oIncotermsTp);

            }

            it.close();
        } catch (SQLException e) {

            throw (new IIMexException("Error in the DB row", e));

        } finally {

            closeConnection(con);

        }

        Logger.traceExit();

        return result;

    }

    //add a new transport mode
    public int addTransportMode(IncotermTransportInfo inco) throws IIMexException {
        Logger.traceEntry();
        int rowUpdate = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.ADD_TRANSPORT_MODE);
            pstm.setString(1, inco.getTransportCode());
            pstm.setString(2, inco.getTransportName());
            pstm.setString(3, inco.getPublishOwner());
            pstm.setDate(4, new java.sql.Date(new Date().getTime()));
            rowUpdate = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error addind transport mode " + inco.getTransportName(), e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return rowUpdate;
    }

    //remove it
    public int removeTransportMode(String tpm) throws IIMexException {
        Logger.traceEntry();
        int rowUpdate = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.REMOVE_TRANSPORT_MODE);
            pstm.setString(1, tpm);
            rowUpdate = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error deleting transport mode " + tpm, e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return rowUpdate;
    }

    //add a transport mode - incoterm
    public int addTransportModeIncoterm(IncotermTransportInfo inco) throws IIMexException {
        Logger.traceEntry();
        int rowUpdate = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.ADD_TRANSPORT_MODE_INCOTERM);
            pstm.setString(1, inco.getTransportCode());
            pstm.setString(2, inco.getIncotermsCode());
            pstm.setString(3, inco.getPublishOwner());
            pstm.setDate(4, new java.sql.Date(new Date().getTime()));
            rowUpdate = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error addind transport mode incoterm" + inco.getTransportName() + inco.getSIncotermDescr(), e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return rowUpdate;
    }

    //remove it
    public int removeTransportModeIncoterm(IncotermTransportInfo inco) throws IIMexException {
        Logger.traceEntry();
        int rowUpdate = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.REMOVE_TRANSPORT_MODE_INCOTERM);
            pstm.setString(1, inco.getTransportCode());
            pstm.setString(2, inco.getIncotermsCode());
            rowUpdate = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error removing transport mode incoterm" + inco.getTransportName() + inco.getSIncotermDescr(), e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return rowUpdate;
    }

    //add a new incoterm
    public int addIncoterm(IncotermTransportInfo inco) throws IIMexException {
        Logger.traceEntry();
        int rowUpdate = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.ADD_INCOTERMS);
            pstm.setString(1, inco.getIncotermsCode());
            pstm.setString(2, inco.getSIncotermDescr());
            pstm.setString(3, inco.getSDuties());
            pstm.setString(4, inco.getSFreight());
            pstm.setString(5, inco.getSInsurance());
            pstm.setString(6, inco.getPublishOwner());
            pstm.setDate(7, new java.sql.Date(new Date().getTime()));
            rowUpdate = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error addind incoterm" + inco.getSIncotermDescr(), e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return rowUpdate;
    }

    //update it
    public int updateIncoterm(IncotermTransportInfo inco) throws IIMexException {
        Logger.traceEntry();
        int rowUpdate = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.UPDATE_INCOTERMS);
            pstm.setString(7, inco.getIncotermsCode());
            pstm.setString(1, inco.getSIncotermDescr());
            pstm.setString(2, inco.getSDuties());
            pstm.setString(3, inco.getSFreight());
            pstm.setString(4, inco.getSInsurance());
            pstm.setString(5, inco.getPublishOwner());
            pstm.setDate(6, new java.sql.Date(new Date().getTime()));
            rowUpdate = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error updating incoterm" + inco.getSIncotermDescr(), e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return rowUpdate;
    }

    //remove it
    public int removeIncoterm(String inco) throws IIMexException {
        Logger.traceEntry();
        int rowUpdate = 0;
        PreparedStatement pstm = null;
        Connection con = null;
        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.REMOVE_INCOTERMS);
            pstm.setString(1, inco);
            rowUpdate = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error updating incoterm" + inco, e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return rowUpdate;
	}

}

