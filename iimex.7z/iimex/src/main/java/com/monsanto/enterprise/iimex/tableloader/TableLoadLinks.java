/*

Copyright:  Copyright � 2008 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.tableloader;



import java.io.File;

import java.io.FileInputStream;

import java.io.FileNotFoundException;

import java.io.InputStream;

import java.sql.*;

import java.util.Date;

import java.util.HashMap;

import java.util.TreeMap;



import com.monsanto.AbstractLogging.Logger;

import com.monsanto.Util.StringUtils;

import com.monsanto.Util.Exceptions.WrappingException;

import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;

import com.monsanto.dataservices.PersistentStoreStatement;

import com.monsanto.enterprise.iimex.DataBaseQueries;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.elements.DocLink;

import com.monsanto.enterprise.iimex.elements.LinkAndDocument;

import com.monsanto.enterprise.iimex.elements.Url;



public class TableLoadLinks extends TableLoader {

/**

 * Load the data from the link_Header table and stock it in a TreeMap where the key is 

 * the linkId

 * @return

 * @throws IIMexException

 */

	int docCounter=0;

	int urlCounter =0;

	public TreeMap<Integer, LinkAndDocument> loadLinksRows()

	throws IIMexException{

		Logger.traceEntry();

		TreeMap<Integer, LinkAndDocument> tmLinks = new TreeMap<Integer,LinkAndDocument>();
        Connection con=null;

        try {
            con = getConnection();
            ResultSet it=con.prepareStatement(DataBaseQueries.SELECT_FROM_LINKS).executeQuery();
			while (it.next()) {

				LinkAndDocument linkAndDoc = new LinkAndDocument();

				int linkId = it.getInt(1);

				linkAndDoc.setLinkId(linkId);

				linkAndDoc.setLinkName(it.getString(2));

				linkAndDoc.setLinkDescription(it.getString(3));

				if(it.getInt(4)==0){

					linkAndDoc.setActive(false);

				}else{

					linkAndDoc.setActive(true);

				}

				tmLinks.put(new Integer(linkId),linkAndDoc);

		}
        it.close();

        ResultSet itUrl=con.prepareStatement(DataBaseQueries.SELECT_FROM_URL).executeQuery();

		

			while (itUrl.next()) {

				Url linkUrl = new Url();

				int linkId = itUrl.getInt(2);

				int urlId = itUrl.getInt(1);

				linkUrl.setLinkId(linkId);

				linkUrl.setUrlId(urlId);

				linkUrl.setUrlTitle(itUrl.getString(3));

				linkUrl.setUrlDescription(itUrl.getString(4));

				linkUrl.setUrl(itUrl.getString(5));

				linkUrl.setPublishDate(itUrl.getDate(6));

				linkUrl.setPublishOwner(itUrl.getString(7));

				LinkAndDocument linkAndDoc = tmLinks.get(new Integer(linkId));	

				linkAndDoc.setHasUrl(true);

				linkAndDoc.addUrl(urlId, linkUrl);

				urlCounter=urlCounter+1;

				

		}
        itUrl.close();

        ResultSet itDoc=con.prepareStatement(DataBaseQueries.SELECT_FROM_DOC).executeQuery();

			

			while (itDoc.next()) {

				DocLink linkDoc = new DocLink();

				int linkId = itDoc.getInt(2);

				int docId = itDoc.getInt(1);

				linkDoc.setDocId(docId);

				linkDoc.setLinkId(linkId);

				linkDoc.setDocTitle(itDoc.getString(3));

				linkDoc.setDocName(itDoc.getString(4));

				linkDoc.setdescription(itDoc.getString(5));

				linkDoc.setPublishDate(itDoc.getDate(7));

				linkDoc.setPublishOwner(itDoc.getString(8));

				LinkAndDocument linkAndDoc = tmLinks.get(new Integer(linkId));	

				linkAndDoc.setHasDoc(true);

				linkAndDoc.addDoc(docId, linkDoc);

				docCounter=docCounter+1;

		}
        itDoc.close();
		}catch (SQLException e) {

			throw (new IIMexException("Error loading the documents ", e));

		}finally{

			closeConnection(con);

		}

		Logger.traceExit();

		return tmLinks;

	}

	/**

	 * Inactive document in the database

	 * @param linkId

	 * @throws IIMexException

	 */

	

	public int updateLinkInactive(String linkId) 

	throws IIMexException{

		Logger.traceEntry();

		int rowUpdate=0;

		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INACTIVE_LINK);

			pstm.setInt(1,Integer.parseInt(linkId));

			rowUpdate=pstm.executeUpdate();

			pstm.close();

		} catch (SQLException e) {

			throw (new IIMexException("Error inactive link "+linkId, e));

		} finally {

			closeConnection(con);
		}

		Logger.traceExit();

	return rowUpdate;	

	}

	public int updateLink(String linkId, String linkGroupName, String linkGroupDesc) 

	throws IIMexException{

		Logger.traceEntry();

		int rowUpdate=0;

		PreparedStatement pstm=null;

		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_LINK);

			pstm.setInt(3,Integer.parseInt(linkId));

			pstm.setString(1,linkGroupName);

			pstm.setString(2,linkGroupDesc);

			rowUpdate=pstm.executeUpdate();

			pstm.close();

		} catch (SQLException e) {

			throw (new IIMexException("Error inactive link "+linkId, e));

		} finally {

			closeConnection(con);
		}

		Logger.traceExit();

	return rowUpdate;	

	}

	public int insertLink(int linkId, String linkGroupName, String linkGroupDesc)

	throws IIMexException{

		Logger.traceEntry();

		int rowInsert=0;

		PreparedStatement pstm=null;

		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INSERT_LINK);

			pstm.setInt(1,linkId);

			pstm.setString(2,linkGroupName);

			pstm.setString(3,linkGroupDesc);

			pstm.setInt(4,1);

			rowInsert=pstm.executeUpdate();

			pstm.close();

		} catch (SQLException e) {

			throw (new IIMexException("Error adding a link to the db "+linkId, e));

		} finally {

			closeConnection(con);
		}
		Logger.traceExit();

		return rowInsert;

	}

	public int updateUrl(String linkId, String urlId, String linkOrDocGroupName, String linkorDocGroupDesc, String urlPath, String userId)

	throws IIMexException{

		Logger.traceEntry();

		int rowUpdate=0;

		PreparedStatement pstm=null;

		Connection con=null;
		try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.UPDATE_URL);

			pstm.setInt(6,Integer.parseInt(urlId));

			pstm.setString(1,linkOrDocGroupName);

			pstm.setString(2,linkorDocGroupDesc);

			pstm.setString(3,urlPath);

			pstm.setDate(4,new java.sql.Date(new Date().getTime()));

			pstm.setString(5,userId);

			rowUpdate=pstm.executeUpdate();

			pstm.close();

		} catch (SQLException e) {

			throw (new IIMexException("Error updating link "+linkOrDocGroupName, e));

		} finally {

			closeConnection(con);
		}

		Logger.traceExit();

	return rowUpdate;	

	}

	public int addUrl(String linkId, String linkOrDocGroupName,

			String linkorDocGroupDesc, String urlPath, String userId, Date publishDate)

	throws IIMexException{

		Logger.traceEntry();

		int rowInsert = 0;

		PreparedStatement pstm =null;

		Connection con=null;
		try {
            con = getConnection();

			urlCounter=urlCounter+1;

			pstm = con.prepareStatement(DataBaseQueries.INSERT_URL);

			pstm.setInt(1,urlCounter);

			pstm.setInt(2,Integer.parseInt(linkId));

			pstm.setString(3, linkOrDocGroupName);

			pstm.setString(4, linkorDocGroupDesc);

			pstm.setString(5, urlPath);

			pstm.setDate(6,new java.sql.Date(publishDate.getTime()));

			pstm.setString(7, userId);

			rowInsert =pstm.executeUpdate();

			pstm.close();

		}catch (SQLException e){

			throw (new IIMexException("Error updating url "+linkOrDocGroupName, e));

		}finally {

			closeConnection(con);
		}

		Logger.traceExit();

		return rowInsert;

	}

	public int deleteUrl(String urlId) 

	throws IIMexException {

		

		Logger.traceEntry();

		int rowDelete=0;

		PreparedStatement pstm =null;

		Connection con=null;
		try {
            con = getConnection();

			pstm = con.prepareStatement(DataBaseQueries.DELETE_URL);

			pstm.setInt(1,Integer.parseInt(urlId));

			rowDelete=pstm.executeUpdate();

		}catch (SQLException e){

			throw (new IIMexException("Error deleting url ", e));

		}finally {

			closeConnection(con);
		}

		Logger.traceExit();

		return rowDelete;

		

	}

	public int getUrlCounter() 

	throws IIMexException{

		return urlCounter;

	}

	public int getDocCounter() 

	throws IIMexException {

		return docCounter;

	}

	public int addDoc(String linkId, String linkOrDocGroupName,

			String linkorDocGroupDesc, String filePath, String userId,

			Date publishDate) throws IIMexException{

		Logger.traceEntry();

		// InputStream is = null;

		int rowInsert = 0;
        Connection con=null;
        PreparedStatement pstm=null;
		try{

            con = getConnection();

			docCounter=docCounter+1;

			int docId = docCounter;

		    StringBuffer strSQL = new StringBuffer("INSERT INTO IEVIEW.LINK_DOC(DOC_ID,DOC) VALUES (");

			strSQL.append(docId).append(",").append("EMPTY_BLOB())").toString();

			con.prepareStatement(strSQL.toString()).executeUpdate();

			rowInsert=updateDoc(linkId,new Integer(docId).toString(),linkOrDocGroupName,linkorDocGroupDesc,filePath,userId);

		

		}catch (SQLException e){

			throw (new IIMexException("Error adding the new document "+linkOrDocGroupName, e));

		} finally {

			closeConnection(con);
		}

		Logger.traceExit();

		return rowInsert;

	}

	public int updateDoc(String linkId, String docId, String linkOrDocGroupName, String linkorDocGroupDesc, String docPath, String userId)

	throws IIMexException{

		InputStream is = null;

		Logger.traceEntry();

		int rowUpdate=0;

		String fileName = "";

		String[] tokenPath = StringUtils.tokenize(docPath,"\\", false);

		fileName=tokenPath[tokenPath.length-1];

		PreparedStatement pstm=null;
        Connection con=null;
		

		try {
            con = getConnection();
			if(!StringUtils.isNullOrEmpty(docPath)){

				File file = new File(docPath);

				is = new FileInputStream(docPath);

				pstm = con.prepareStatement(DataBaseQueries.UPDATE_DOC);

				pstm.setInt(8,Integer.parseInt(docId));

				pstm.setString(1,linkOrDocGroupName);

				pstm.setString(2,fileName);

				pstm.setString(3,linkorDocGroupDesc);

				pstm.setBinaryStream(4,is, (int)file.length());

				pstm.setDate(5,new java.sql.Date(new Date().getTime()));

				pstm.setString(6,userId);

				pstm.setInt(7,new Integer(linkId));

				rowUpdate=pstm.executeUpdate();

				pstm.close();

			}else{

				pstm = con.prepareStatement(DataBaseQueries.UPDATE_DOC_WITHOUT_BLOB);

				pstm.setInt(7,Integer.parseInt(docId));

				pstm.setString(1,linkOrDocGroupName);

				pstm.setString(2,fileName);

				pstm.setString(3,linkorDocGroupDesc);

				pstm.setDate(4,new java.sql.Date(new Date().getTime()));

				pstm.setString(5,userId);

				pstm.setInt(6,new Integer(linkId));

				rowUpdate=pstm.executeUpdate();

				pstm.close();

			}

			

		} catch (SQLException e) {

			throw (new IIMexException("Error updating link "+linkOrDocGroupName, e));

		} catch (FileNotFoundException fex) {

			throw (new IIMexException("Error updating link "+linkOrDocGroupName +", file not found  ", fex));

			

		} finally {

			closeConnection(con);
		}

		Logger.traceExit();

	return rowUpdate;	

	}
	
	public int removeDoc(String linkId, String docId)

	throws IIMexException{

		Logger.traceEntry();

		int rowUpdate=0;

		PreparedStatement pstm=null;
        Connection con=null;

		try {
                 con = getConnection();
				pstm = con.prepareStatement(DataBaseQueries.REMOVE_LINK_DOC);


				pstm.setString(1,linkId);

				pstm.setString(2,docId);

				rowUpdate=pstm.executeUpdate();

				pstm.close();

		} catch (SQLException e) {

			throw (new IIMexException("Error removing link "+docId, e));

		} finally {

			closeConnection(con);
		}

		Logger.traceExit();

	return rowUpdate;	

	}

}

