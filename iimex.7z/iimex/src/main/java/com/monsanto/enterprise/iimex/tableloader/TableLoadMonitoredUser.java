package com.monsanto.enterprise.iimex.tableloader;

import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreObjectResultSetForwardIterator;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dbdataservices.PersistentStoreDBPreparedStatement;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.MonitoredUser;

public class TableLoadMonitoredUser extends TableLoader{
	
	public Vector<MonitoredUser> loadMonitoredUser()throws IIMexException{
		Logger.traceEntry();
		
		Vector<MonitoredUser> users = new Vector<MonitoredUser>();
		
        Connection con=null;
        PreparedStatement pstm=null;
		try{

             con =getConnection();
			ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_USER_MONITORING).executeQuery();

			Date min = new Date(3900,7,7);
			Date[] last = null;
			Date tmp;
			while(it.next()){
				last = new Date[3];
				for(int i=0;i<3;i++){
					last[i]=new Date(0);
				}
				String name = it.getString(1);
				MonitoredUser mu = new MonitoredUser();
				mu.setName(name);
				pstm = con.prepareStatement(DataBaseQueries.SELECT_DATE_MONITORING);
				pstm.setString(1, name);
				ResultSet psr = pstm.executeQuery();
                java.sql.Date dt=null;
				while(psr.next()){
                    dt = psr.getDate(1);
					if(min.compareTo(dt)>0)
						min=dt;
					mu.addConnection(dt);
					tmp=dt;
					if(last[0].compareTo(tmp)<0){
						last[2]=last[1];
						last[1]=last[0];
						last[0]=tmp;
					}else if(last[1].compareTo(tmp)<0){
						last[2]=last[1];
						last[1]=tmp;
					}else if(last[2].compareTo(tmp)<0){
						last[2]=tmp;
					}
				}
				mu.setLasts(last);
				users.add(mu);
			}
			
			Iterator ite = users.iterator();
			while(ite.hasNext()){
				((MonitoredUser)ite.next()).setMin(min); 
			}
			
		} catch (SQLException e) {

			throw (new IIMexException("Error in the DB row", e));

		}finally{

			closeConnection(con);

		}
		
		Logger.traceExit();
		return users;
	}
	
}