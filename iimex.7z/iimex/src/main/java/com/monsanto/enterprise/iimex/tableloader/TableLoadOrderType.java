package com.monsanto.enterprise.iimex.tableloader;

import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.orderType;

public class TableLoadOrderType extends TableLoader {
	//load order types from the base
	public HashMap<String, HashMap<String, orderType>> loadOrderType()throws IIMexException{

		Logger.traceEntry();
		HashMap<String, HashMap<String, orderType>> orderTypes = new HashMap<String, HashMap<String, orderType>>();
		

        Connection con=null;

        try{

            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_TRANSACTION_TYPE).executeQuery();
            while (it.next()) {
				orderType order = new orderType();
				if(orderTypes.containsKey(it.getString(1))){
					HashMap<String, orderType> selling = orderTypes.get(it.getString(1));
					order.setPurchaseOrderType(it.getString(3));
					order.setSalesOrderType(it.getString(4));
					order.setPublishOwner(it.getString(5));
					order.setPublishDate((Date)it.getDate(6));
					order.setDestination(it.getString(2));
					order.setShipping(it.getString(1));
					selling.put(it.getString(2),order);
				}else{
					HashMap<String, orderType> selling = new HashMap<String, orderType>();
					order.setPurchaseOrderType(it.getString(3));
					order.setSalesOrderType(it.getString(4));
					order.setPublishOwner(it.getString(5));
					order.setPublishDate((Date)it.getDate(6));
					order.setDestination(it.getString(2));
					order.setShipping(it.getString(1));
					selling.put(it.getString(2),order);
					orderTypes.put(it.getString(1), selling);
				}
			}

		} catch (SQLException _ex) {

			throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));

		} finally {

			closeConnection(con);

		}

		Logger.traceExit();

		return orderTypes;

	}
	//add a new one
	public int addOrder(orderType order, String code) throws IIMexException{
		Logger.traceEntry();
		int addOk = 0;
		PreparedStatement pstm=null;
        Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_TRANSACTION_TYPE);
			pstm.setString(1,code);
			pstm.setString(2,order.getDestination());
			pstm.setString(3,order.getPurchaseOrderType());
			pstm.setString(4,order.getSalesOrderType());
			pstm.setString(5,order.getPublishOwner());
			pstm.setDate(6,new java.sql.Date(new Date().getTime()));
			addOk=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error adding transaction type ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return addOk;
	}
//update it
	public int updateOrder(orderType order, String code) throws IIMexException{
		Logger.traceEntry();
		int updateOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_TRANSACTION_TYPE);
			pstm.setString(5,code);
			pstm.setString(6,order.getDestination());
			pstm.setString(1,order.getPurchaseOrderType());
			pstm.setString(2,order.getSalesOrderType());
			pstm.setString(3,order.getPublishOwner());
			pstm.setDate(4,new java.sql.Date(new Date().getTime()));
			updateOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error updating adding transaction type " , e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return updateOK;
	}
//delete one
	public int removeOrder(orderType order, String code) throws IIMexException{
		Logger.traceEntry();
		int removeOK = 0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_TRANSACTION_TYPE);
			pstm.setString(1,code);
			pstm.setString(2,order.getDestination());
			removeOK=pstm.executeUpdate();
			pstm.close();
			
		} catch (SQLException e) {
			throw (new IIMexException("Error removing adding transaction type ", e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return removeOK;
	}
	
}