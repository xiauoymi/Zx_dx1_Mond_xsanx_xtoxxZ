/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.tableloader;



import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.TimeZone;
import java.util.Vector;

import java.util.HashMap;

import java.util.List;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;


import com.monsanto.AbstractLogging.LoggableInfo;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;

import com.monsanto.Util.StringUtils;

import com.monsanto.Util.Exceptions.WrappingException;

import com.monsanto.enterprise.iimex.DataBaseQueries;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.collections.CompaniesCollection;
import com.monsanto.enterprise.iimex.collections.CountryCollection;
import com.monsanto.enterprise.iimex.elements.PlantsFromCountry;



public class TableLoadPlants extends TableLoader{

	

	/**

	 * Take the data in the DB and stock it in a hashMap where the key are the country and by county

	 *  we can find a hashMap where the key are the productGroup and the values are PlantsFromCountry objects

	 * @return

	 * @throws IIMexException

	 */

	public HashMap<String, HashMap<String, PlantsFromCountry>> loadPlantsRows(CompaniesCollection companiesCollection,CountryCollection countryColl)

	throws IIMexException{

		Logger.traceEntry();

		HashMap<String, HashMap<String, PlantsFromCountry>> mhPlants = new HashMap<String, HashMap<String, PlantsFromCountry>>();
        Connection con = null;


        try{
        con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_PLANTS).executeQuery();

		while (it.next()) {
			
			String fromCountry= it.getString(1);
			 
			String plantCompanyCode=it.getString(2);

			String plantCode =it.getString(3);

			String plantName=it.getString(4);
			
			String plantName2=it.getString(5);
			
			Date publish_date=it.getDate(6);
			
			String publish_owner=it.getString(7);

			String active=it.getString(8);
			
			PlantsFromCountry plant = new PlantsFromCountry();

			plant.setCodeFromCountry(fromCountry);
			
			plant.setNameFromCountry(countryColl.getCountryName(fromCountry));

			plant.setCodePlant(plantCode);

			plant.setPlantName(plantName);
			
			plant.setM_strPlantName2(plantName2);
			
			if(plantCompanyCode!=null){
				plant.setM_strPlantCompanyCode(plantCompanyCode);
				plant.setM_strPlantCompanyName(it.getString("company_name"));//companiesCollection.getCompanyName(plantCompanyCode));
			}
			
			plant.setPublishDate(publish_date);
			
			plant.setPublishOwner(publish_owner);

			if(active.compareTo("Y")==0){
				plant.setActive(true);
			}else{
				plant.setActive(false);
			}
			if(mhPlants.containsKey(fromCountry)){
				HashMap<String, PlantsFromCountry> plantListCountry=mhPlants.get(fromCountry);
				plantListCountry.put(plant.getCodePlant(), plant);
			}else{
				HashMap<String, PlantsFromCountry> plantListCountry = new HashMap<String, PlantsFromCountry>();
				plantListCountry.put(plant.getCodePlant(), plant);
				mhPlants.put(fromCountry, plantListCountry);
			}
		}
		loadPlantDivision(mhPlants, con);
	} catch (SQLException _ex) {
		throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));
	} finally {
		if (con!=null){
            try {
                con.close();
            } catch (SQLException e) {
                Logger.log(new LoggableError(e));
            }
        }
	}
		Logger.traceExit();
		return mhPlants;

	}

	//load the plant division information
	private void loadPlantDivision(HashMap<String, HashMap<String, PlantsFromCountry>> plants, Connection con)throws IIMexException{
		Logger.traceEntry();	
		try{
            HashMap<String, PlantsFromCountry> plantListCountry;
            PlantsFromCountry plant;
            ResultSet ite = con.prepareStatement(DataBaseQueries.SELECT_PLANTS_DIVISION).executeQuery();
            while (ite.next()) {
                Iterator it = plants.keySet().iterator();
				while(it.hasNext()){
					plantListCountry = plants.get((it.next()));
					if(plantListCountry.containsKey(ite.getString(1))){
						plant = plantListCountry.get(ite.getString(1));
						HashMap tmp = plant.getDivision();
						if(ite.getString(3)!=null)
							tmp.put(ite.getString(2),ite.getString(3));
						else tmp.put(ite.getString(2),"");
						plant.setDivision(tmp);
					}
				}
					
			}
		}catch (SQLException e) {
			throw (new IIMexException("Error in the DB row", e));
		}
		Logger.traceExit();
	}
	// add a new plant in the base
	public int addPlant(PlantsFromCountry plant) throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INSERT_PLANT);
			pstm.setString(1,plant.getCodePlant());
			pstm.setString(2,plant.getPlantName());
			pstm.setString(3,plant.getM_strPlantName2());
			pstm.setString(4,plant.getCodeFromCountry());
			pstm.setString(5,plant.getPlantCompanyCode());
			pstm.setString(6,"Y");
			pstm.setString(8,plant.getPublishOwner());
			pstm.setDate(7,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive plant "+plant.getPlantName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//inactive an existing plant
	public int inactivePlant(String plantCode) throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INACTIVE_PLANT);
			pstm.setString(1,plantCode);
			rowUpdate=pstm.executeUpdate();
			pstm.close();			
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive plant "+plantCode, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//activate it
public int activePlant(String plantCode) throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ACTIVE_PLANT);
			pstm.setString(1,plantCode);
			rowUpdate=pstm.executeUpdate();
			pstm.close();			
		} catch (SQLException e) {
			throw (new IIMexException("Error active plant "+plantCode, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//update an existing one
	public int updatePlant(PlantsFromCountry plant) throws IIMexException{	
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_PLANT);
			
			pstm.setString(1,plant.getPlantName());
			pstm.setString(2,plant.getM_strPlantName2());
			pstm.setString(3,plant.getCodeFromCountry());
			pstm.setString(4,plant.getPlantCompanyCode());
			if(plant.isActive())
				pstm.setString(5,"Y");
			else pstm.setString(5,"N");
			pstm.setString(6,plant.getPublishOwner());
			pstm.setDate(7,new java.sql.Date(new Date().getTime()));
			pstm.setString(8,plant.getCodePlant());
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive plant "+plant.getPlantName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
	return rowUpdate;	
	}
	//add a division to a plant
	public int addPlantDivision(String codePlant, String codeDivision, String Comment,String User) throws IIMexException{	
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INSERT_PLANT_DIVISION);
			pstm.setString(1,codePlant);
			pstm.setString(2,codeDivision);
			pstm.setString(3,Comment);
			TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
			Locale loc = Locale.FRANCE;
			Calendar cal = Calendar.getInstance(tz,loc);
			Date date = cal.getTime();
			pstm.setDate(5,new java.sql.Date(date.getTime()));
			pstm.setString(4,User);
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive plant division"+codePlant, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
	return rowUpdate;	
	}
	//remove a division from a plant
	public int deletePlantDivision(String codePlant, String codeDivision) throws IIMexException{	
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.DELETE_PLANT_DIVISION);
			pstm.setString(1,codePlant);
			pstm.setString(2,codeDivision);
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive plant division "+codePlant, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
	return rowUpdate;	
	}
	//update it
	public int updatePlantDivision(String codePlant, String codeDivision, String Comment,String User) throws IIMexException{	
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_PLANT_DIVISION);
			pstm.setString(4,codePlant);
			pstm.setString(5,codeDivision);
			pstm.setString(1,Comment);
			TimeZone tz = TimeZone.getTimeZone("Europe/Paris");
			Locale loc = Locale.FRANCE;
			Calendar cal = Calendar.getInstance(tz,loc);
			Date date = cal.getTime();
			pstm.setDate(3,new java.sql.Date(date.getTime()));
			pstm.setString(2,User);
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error inactive plant division"+codePlant, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
	return rowUpdate;	
	}
}

	

