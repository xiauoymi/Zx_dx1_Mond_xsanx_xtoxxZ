/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/



package com.monsanto.enterprise.iimex.tableloader;



import java.util.ArrayList;
import java.util.Date;

import java.util.HashMap;

import java.util.List;

import java.util.TreeMap;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;


import com.monsanto.AbstractLogging.Logger;

import com.monsanto.Util.Exceptions.WrappingException;

import com.monsanto.enterprise.iimex.DataBaseQueries;

import com.monsanto.enterprise.iimex.IIMexException;

import com.monsanto.enterprise.iimex.elements.Division;
import com.monsanto.enterprise.iimex.elements.ProductGroup;

import com.monsanto.enterprise.iimex.elements.ProductOrigin;



public class TableLoadProducts extends TableLoader {

	/**

	 * Load the data from the DB (IE_CUSTOM_ZONE) to a hashMap where the key is the prodOriginCode and the value is

	 * a productOrigin object

	 * @return

	 * @throws IIMexException

	 */

	public TreeMap<String, ProductOrigin> loadProductOrigin()

	throws IIMexException{

		Logger.traceEntry();

		TreeMap<String, ProductOrigin> tmProdOrigin = new TreeMap<String, ProductOrigin>();
         Connection con = null;

        try{
            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_FROM_CUSTOMS_ZONE).executeQuery();

			

			while (it.next()) {

				ProductOrigin oProdOrigin = new ProductOrigin();

				String prodOriginCode = it.getString(1);

				oProdOrigin.setProductOriginCode(prodOriginCode);

				String prodOriginName = it.getString(2);

				oProdOrigin.setProductOriginName(prodOriginName);

			tmProdOrigin.put(oProdOrigin.getProductOriginCode(), oProdOrigin);



			}

            it.close();

	



		} catch (SQLException _ex) {

		

			throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));

		

		} finally {



			closeConnection(con);

		}

		Logger.traceExit();

		return tmProdOrigin;

	}

	/**

	 * Load the data from the DB (IE_PRODUCT_GROUP) and stock the data in a hashMap where key is the productGroup code

	 * and value is a ProductGroup object.

	 * @return

	 * @throws IIMexException

	 */

	public HashMap<String, ProductGroup> loadProductGroup()

	throws IIMexException{

		Logger.traceEntry();

		HashMap<String, ProductGroup> mhProdGroup = new HashMap<String, ProductGroup>();


 Connection con = null;

        try{
            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_FROM_PRODUCT_GROUP).executeQuery();
			

			while (it.next()) {

				ProductGroup oProdGroup = new ProductGroup();

				String codeProdGroup = it.getString(1);

				oProdGroup.setProductGroupCode(codeProdGroup);

				String nameProdGroup = it.getString(2);

				oProdGroup.setProductGroupName(nameProdGroup);

				String divisionCode= it.getString(3);

				oProdGroup.setDivisionCode(divisionCode);
				
				String HTSCode= it.getString(4);
				if(HTSCode!=null)
					oProdGroup.setHTSCode(HTSCode);
				
				String botanicalName = it.getString(5);
				if(botanicalName!=null)
					oProdGroup.setBotanicalName(botanicalName);
				
				String publishOwner= it.getString(7);
				
				oProdGroup.setPublishOwner(publishOwner);
				
				Date publishDate = it.getDate(6);
				
				oProdGroup.setPublishDate(publishDate);

				mhProdGroup.put(oProdGroup.getProductGroupCode(), oProdGroup);

				

			



			}



	


        it.close();
		} catch (SQLException _ex) {

		

			throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));

		

		} finally {



			closeConnection(con);

		}

		Logger.traceExit();

		return mhProdGroup;

	}

	

	/**

	 * Load the column name in a List

	 * @return

	 * @throws IIMexException

	 */

	public List<String> loadProductGroupColumName()

	throws IIMexException{

		Logger.traceEntry();

		List<String> fieldList= new ArrayList<String>();
        Connection con=null;
		try{
            con = getConnection();
			fieldList=getColumnNames(DataBaseQueries.SELECT_FROM_PRODUCT_GROUP, con);

		}
        catch (SQLException e) {
           throw new IIMexException("error loading loadProductGroupColumNames: ",e);
        } finally{

			closeConnection(con);

		}

		Logger.traceExit();

		return fieldList;

	}
//add a new product in the base
	public int addProduct(ProductGroup prod)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INSERT_PRODUCT);
			pstm.setString(1,prod.getProductGroupCode());
			pstm.setString(2,prod.getProductGroupName());
			pstm.setString(3,prod.getDivisionCode());
			pstm.setString(4,prod.getHTSCode());
			pstm.setString(5,prod.getBotanicalName());
			pstm.setString(7,prod.getPublishOwner());
			pstm.setDate(6	,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error addind product group"+prod.getProductGroupName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//update one
	public int updateProduct(ProductGroup prod)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_PRODUCT);
			pstm.setString(6,prod.getProductGroupCode());
			pstm.setString(1,prod.getProductGroupName());
			pstm.setString(2,prod.getHTSCode());
			pstm.setString(3,prod.getBotanicalName());
			pstm.setString(4,prod.getPublishOwner());
			pstm.setDate(5,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating product group"+prod.getProductGroupName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//delete it
	public int removeProduct(String prod)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.DELETE_PRODUCT);
			pstm.setString(1,prod);
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error removing product"+prod, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}


}

