/*
Copyright:  Copyright � 2007 Monsanto.  All rights reserved.
This software was produced using Monsanto resources and is the sole property of Monsanto.
Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright
*/

package com.monsanto.enterprise.iimex.tableloader;

import java.util.HashMap;
import java.util.Vector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.PhytoRequirement;
import com.monsanto.dbdataservices.PersistentStoreDBConnection;

public class TableLoadRequirements extends TableLoader{

	/**
	 * Load the data from the database to a HashTable
	 * @return
	 * @throws IIMexException
	 */

	public HashMap<String, HashMap<String, HashMap<String, Vector<PhytoRequirement>>>> loadRequirements() throws IIMexException{
		Logger.traceEntry();
		HashMap<String, HashMap<String, HashMap<String, Vector<PhytoRequirement>>>> requirements
                = new HashMap<String, HashMap<String, HashMap<String, Vector<PhytoRequirement>>>>();
        Connection con=null;
		try {
            con = getConnection();
            ResultSet ite = con.prepareStatement(DataBaseQueries.SELECT_FROM_PHYTO_REQUIREMENT).executeQuery();
            String countryOfOriginCode;
            String destinationCountryCode;
                String productGroupCode;
			while (ite.next()) {
				PhytoRequirement req = new PhytoRequirement();
				req.setPlantID(ite.getString(4));
				req.setMicCode(ite.getString(5));
				req.setMicDescription(ite.getString(6));
				req.setPublishOwner(ite.getString(7));
				req.setPublishDate(ite.getDate(8));
                //new req. info field.
                req.setInfoField(ite.getString(9));
                countryOfOriginCode = ite.getString(1);
                destinationCountryCode = ite.getString(2);
                productGroupCode = ite.getString(3);
                if(requirements.containsKey(countryOfOriginCode)){
					HashMap<String, HashMap<String, Vector<PhytoRequirement>>> countryOfOrigin = requirements.get(countryOfOriginCode);
					if(countryOfOrigin.containsKey(destinationCountryCode)){
						HashMap<String, Vector<PhytoRequirement>> destination = countryOfOrigin.get(destinationCountryCode);
						if(destination.containsKey(productGroupCode)){
							destination.get(productGroupCode).add(req);
						}else{
							Vector<PhytoRequirement> group = new Vector<PhytoRequirement>();
							group.add(req);
							destination.put(productGroupCode, group);
						}
					}else{
						HashMap<String, Vector<PhytoRequirement>> destination = new HashMap<String, Vector<PhytoRequirement>>();
						Vector<PhytoRequirement> group = new Vector<PhytoRequirement>();
						group.add(req);
						destination.put(productGroupCode, group);
						countryOfOrigin.put(destinationCountryCode, destination);
					}
				}else{
					HashMap<String, HashMap<String, Vector<PhytoRequirement>>> countryOfOrigin =
                            new HashMap<String, HashMap<String, Vector<PhytoRequirement>>>();
					HashMap<String, Vector<PhytoRequirement>> destination = new HashMap<String, Vector<PhytoRequirement>>();
					Vector<PhytoRequirement> group = new Vector<PhytoRequirement>();					
					group.add(req);
					destination.put(productGroupCode, group);
					countryOfOrigin.put(destinationCountryCode, destination);
					requirements.put(countryOfOriginCode, countryOfOrigin);
				}
			}

		} catch (Exception e) {
			throw (new IIMexException("Error in the DB row", e));
		}finally{
			if (con!=null){
                try {
                    con.close();
                } catch (SQLException e) {
                   Logger.log(new LoggableError(e));
                }
            }
		}

		Logger.traceExit();
		return requirements;
	}
}