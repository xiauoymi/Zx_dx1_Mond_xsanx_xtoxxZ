package com.monsanto.enterprise.iimex.tableloader;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.ShippingRestrictionForReport;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 30, 2010
 * Time: 2:58:46 PM
 */
public class TableLoadShippingRestrictionReport extends TableLoader {

    public List<ShippingRestrictionForReport> loadAllShippingRestrictionForReport() throws IIMexException {
        Logger.traceEntry();

        List<ShippingRestrictionForReport> restrictions = new ArrayList<ShippingRestrictionForReport>();
        Connection con = null;

        try {
            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_SHIPPING_RESTRICTIONS_FOR_REPORT).executeQuery();
            while (it.next()) {

                ShippingRestrictionForReport restrictionForReport = new ShippingRestrictionForReport();

                restrictionForReport.setDestinationCountryName(it.getString("dest_name"));
                restrictionForReport.setDestination(it.getString("dest_code"));
                restrictionForReport.setOriginCountryName(it.getString("origin_name"));
                restrictionForReport.setOrigin(it.getString("origin_code"));
                restrictionForReport.setDivisionName(it.getString("division_name"));
                restrictionForReport.setProductGroupName(it.getString("product_group_name"));
                restrictionForReport.setRestrictionName(it.getString("shipping_restrict_name"));
                restrictionForReport.setComments(it.getString("comments"));
                restrictionForReport.setPublishOwnerId(it.getString("publish_owner"));
                restrictionForReport.setPublishDate(it.getDate("publish_date"));

                restrictions.add(restrictionForReport);
            }
            it.close();

        } catch (SQLException _ex) {
            throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();

        return restrictions;
    }
}
