package com.monsanto.enterprise.iimex.tableloader;

import java.util.Date;
import java.util.HashMap;
import java.util.Vector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.Approved;
import com.monsanto.enterprise.iimex.elements.Trait;

public class TableLoadTrait extends TableLoader {
	
	public Vector<Trait> loadTraits()	throws IIMexException{

		Logger.traceEntry();

		Vector<Trait> traits;

        Connection con=null;


        Vector<String> traitCodes = new Vector<String>();
        HashMap<String, Trait> traitsMap = new HashMap<String, Trait>();

        try{
            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_TRAIT).executeQuery();

			while (it.next()) {				
				
				Trait tr = new Trait();

				String traitCode = it.getString(1);
				String traitName = it.getString(2);
				String monNumber = it.getString(3);
				String productGroupCode = it.getString(4);
				String identifier = it.getString(5);
				String labOffice = it.getString(6);
				Date publishDate = it.getDate(7);
				String publishOwner = it.getString(8);
				
				tr.setTraitCode(traitCode);
				tr.setTraitName(traitName);
				tr.setMonNumber(monNumber);
				tr.setProductGroupCode(productGroupCode);
				tr.setOECDIdentifier(identifier);
				tr.setLabOfficeCode(labOffice);
				tr.setPublishDate(publishDate);
				tr.setPublishOwner(publishOwner);
				
				traitCodes.add(traitCode);
				
				traitsMap.put(traitCode, tr);
			}

            it.close();


            PreparedStatement pstm = con.prepareStatement(DataBaseQueries.SELECT_TRAIT_COUNTRY);
            ResultSet ite=null;

			for(int cpt = 0; cpt < traitCodes.size(); cpt++){
				String code = traitCodes.get(cpt);
				
				pstm.setString(1, code);

				ite = pstm.executeQuery();
				
				HashMap approved = new HashMap();
				Approved appr;
				
				while(ite.next()){
					appr = new Approved();
					appr.setProduction(ite.getString(2));
					appr.setImportation(ite.getString(3));
					appr.setFood(ite.getString(4));
					appr.setCountry(ite.getString(1));
					appr.setPublishOwner(ite.getString(5));
					appr.setPublishDate(ite.getDate(6));
					approved.put(ite.getString(1),appr);
				}				

				traitsMap.get(code).setApproved(approved);
                if (ite!=null){ite.close();}
			}
            if (pstm!=null){pstm.close();}
		} catch (SQLException _ex) {

			throw (new IIMexException("Error connection to the DB please contact your IT support contact", _ex));

		} finally {

			closeConnection(con);
			traits = new Vector<Trait>(traitsMap.values());
		}		

		Logger.traceExit();

		return traits;

	}
	//add a new trait
	public int addTrait(Trait tr)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INSERT_TRAIT);
			pstm.setString(1,tr.getTraitCode());
			pstm.setString(2,tr.getTraitName());
			pstm.setString(3,tr.getProductGroupCode());
			pstm.setString(4,tr.getOECDIdentifier());
			pstm.setString(5,tr.getLabOfficeCode());
			pstm.setString(7,tr.getPublishOwner());
			pstm.setDate(6	,new java.sql.Date(new Date().getTime()));
			pstm.setString(8,tr.getMonNumber());
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error addind trait"+tr.getTraitCode(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//update it
	public int updateTrait(Trait tr)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_TRAIT);
			pstm.setString(7,tr.getTraitCode());
			pstm.setString(1,tr.getTraitName());
			pstm.setString(2,tr.getMonNumber());
			pstm.setString(3,tr.getOECDIdentifier());
			pstm.setString(4,tr.getLabOfficeCode());
			pstm.setString(5,tr.getPublishOwner());
			pstm.setDate(6,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating trait"+tr.getTraitCode(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//delete one
	public int removeTrait(String tr)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.DELETE_TRAIT);
			pstm.setString(1,tr);
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error removing trait "+tr, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//add a new trait country
	public int addTraitCountry(String code, String destination, String production,String impor, String food, String owner)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.INSERT_TRAIT_COUNTRY);
			pstm.setString(1,code);
			pstm.setString(2,destination);
			pstm.setString(3,production);
			pstm.setString(4,impor);
			pstm.setString(5,owner);
			pstm.setDate(6	,new java.sql.Date(new Date().getTime()));
			pstm.setString(7	,food);
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error adding trait country"+code, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//update one
	public int updateTraitCountry(String code, String destination, String production,String impor, String food, String owner)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_TRAIT_COUNTRY);
			pstm.setString(6,code);
			pstm.setString(7,destination);
			pstm.setString(1,production);
			pstm.setString(2,impor);
			pstm.setString(3,food);
			pstm.setString(4,owner);
			pstm.setDate(5	,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating trait country"+code, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//remove it
	public int removeTraitCountry(String code, String destination)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.DELETE_TRAIT_COUNTRY);
			pstm.setString(1,code);
			pstm.setString(2,destination);
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error removing trait country"+code, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	
}