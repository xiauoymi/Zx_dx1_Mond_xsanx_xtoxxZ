package com.monsanto.enterprise.iimex.tableloader;



import java.util.Date;
import java.util.Vector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.WorldArea;

//table loader for the world areas

public class TableLoadWorldArea extends TableLoader{

	//load data
	public Vector<WorldArea> loadAreas()

	throws IIMexException{

		Logger.traceEntry();

		Vector<WorldArea> areas = new Vector<WorldArea>();
        Connection con = null;

        try{
            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_WORLD_AREA).executeQuery();

			while (it.next()) {
			
				WorldArea area = new WorldArea();
			
				area.setAreaCode(it.getString(1));
				
				area.setAreaName(it.getString(2));
			
				area.setPublisOwner(it.getString(3));
			
				area.setPublisDate((Date)it.getDate(4));
			
				areas.add(area);			
				
			}

            it.close();
		} catch (SQLException _ex) {

				throw (new IIMexException("Error conection to the DB please contact your IT support contact", _ex));

		} finally {

			closeConnection(con);

		}

		Logger.traceExit();

		return areas;

	}
	//add a new one
	public int addArea(WorldArea area)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.ADD_WORLD_AREA);
			pstm.setString(1,area.getAreaCode());
			pstm.setString(2,area.getAreaName());
			pstm.setString(3,area.getPublisOwner());
			pstm.setDate(4,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error addind world area"+area.getAreaName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//update one
	public int updateArea(WorldArea area)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.UPDATE_WORLD_AREA);
			pstm.setString(4,area.getAreaCode());
			pstm.setString(1,area.getAreaName());
			pstm.setString(2,area.getPublisOwner());
			pstm.setDate(3,new java.sql.Date(new Date().getTime()));
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating world area"+area.getAreaName(), e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
	//delete it
	public int removeArea(String area)	throws IIMexException{
		Logger.traceEntry();
		int rowUpdate=0;
		PreparedStatement pstm=null;
		Connection con=null;
		try {
            con = getConnection();
			pstm = con.prepareStatement(DataBaseQueries.REMOVE_WORLD_AREA);
			pstm.setString(1,area);
			rowUpdate=pstm.executeUpdate();
			pstm.close();
		} catch (SQLException e) {
			throw (new IIMexException("Error updating world area"+area, e));
		} finally {
			closeConnection(con);
		}
		Logger.traceExit();
		return rowUpdate;	
	}
}