/*

Copyright:  Copyright � 2007 Monsanto.  All rights reserved.

This software was produced using Monsanto resources and is the sole property of Monsanto.

Any duplication or public release of the code and/or logic is a direct infringement of Monsanto's copyright

*/


package com.monsanto.enterprise.iimex.tableloader;


import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import com.monsanto.AbstractLogging.Logger;
import com.monsanto.AbstractLogging.LoggableError;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.iimex.IIMexException;


import oracle.jdbc.pool.OracleConnectionPoolDataSource;
import javax.naming.InitialContext;
import javax.naming.Context;
import javax.sql.PooledConnection;


public class TableLoader {

    private static OracleConnectionPoolDataSource ds;
    private static final String IIMEX_JNDI_NAME = "java:/comp/env";
    private static final String IIMEX_JNDI_DATASOURCE = "jdbc/iimex";
    private static final String ERR_MESSAGE = "Error getting a connection";

    static {
        try {
            InitialContext ctx = new InitialContext();
            Context poolctx = (Context) ctx.lookup(IIMEX_JNDI_NAME);
            ds = (OracleConnectionPoolDataSource) poolctx.lookup(IIMEX_JNDI_DATASOURCE);
        } catch (Exception e) {
            e.printStackTrace();
            Logger.log(new LoggableError(e));
        } finally {
        }
    }

    public Connection getConnection() throws IIMexException {
        try {
            PooledConnection pc = ds.getPooledConnection();
            return pc.getConnection();
        } catch (Exception e) {
            e.printStackTrace();
            throw (new IIMexException(ERR_MESSAGE, e));
        }
    }

    protected void closeConnection(Connection con) {
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                Logger.log(new LoggableError(e));
            }
        }
    }

    protected List<String> getColumnNames(String query, Connection con) throws SQLException {
        ResultSet rs = con.prepareStatement(query).executeQuery();
        List<String> ls = new ArrayList<String>();
        final ResultSetMetaData data = rs.getMetaData();
        String aString;
        final int columnCount = data.getColumnCount();
        for (int i = 0; i < columnCount; i++) {
            aString = data.getColumnName(i + 1);
            if (!StringUtils.isNullOrEmpty(aString)) {
                aString = aString.replace('_', ' ');
            }
            ls.add(aString);
        }
        rs.close();
        return ls;
    }
}

	

