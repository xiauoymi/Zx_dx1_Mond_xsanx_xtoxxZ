package com.monsanto.enterprise.iimex.tableloader;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.ShippingRestrictionType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 18, 2010
 * Time: 2:15:34 PM
 */
public class TableLoaderShippingRestrictType extends TableLoader {

    public Vector<ShippingRestrictionType> loadShippingRestrictType() throws IIMexException {
        Logger.traceEntry();
        Connection con = null;
        Vector<ShippingRestrictionType> types = new Vector<ShippingRestrictionType>();

        try {
            con = getConnection();
            ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_SHIPPING_RESTRICT_TYPE_QUERY).executeQuery();
            while (it.next()) {
                ShippingRestrictionType type = new ShippingRestrictionType();
                type.setCode(it.getString(1));
                type.setName(it.getString(2));
                type.setComments(it.getString(3));
                type.setPublishOwnerId(it.getString(4));
                type.setPublishDate(it.getDate(5));
                types.add(type);
            }
        } catch (SQLException e) {
            throw (new IIMexException("Error in the DB row", e));
        } finally {
            closeConnection(con);
        }

        Logger.traceExit();
        return types;
    }

    public int addShipRestrictType(ShippingRestrictionType type) throws IIMexException {
        Logger.traceEntry();

        PreparedStatement pstm = null;
        Connection con = null;
        int addOk = 0;

        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.ADD_SHIPPING_RESTRICTION_TYPE_QUERY);
            pstm.setString(1, type.getName());
            pstm.setString(2, type.getComments());
            pstm.setString(3, type.getPublishOwnerId());
            pstm.setDate(4, new java.sql.Date(System.currentTimeMillis()));

            addOk = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error adding shipping restriction type " + type.getName(), e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return addOk;
    }

    public int removeShipRestrictType(String typeCode) throws IIMexException {
        Logger.traceEntry();

        PreparedStatement pstm = null;
        Connection con = null;
        int deleteOK = 0;

        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.REMOVE_SHIPPING_RESTRICT_TYPE_QUERY);
            pstm.setString(1, typeCode);

            deleteOK = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error deleting shipping restriction type with code " + typeCode, e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return deleteOK;
    }

    public int updateShipRestrictType(ShippingRestrictionType type) throws IIMexException {
        Logger.traceEntry();

        PreparedStatement pstm = null;
        Connection con = null;
        int updOk = 0;

        try {
            con = getConnection();
            pstm = con.prepareStatement(DataBaseQueries.UPDATE_SHIPPING_RESTRICT_TYPE_QUERY);
            pstm.setInt(5, Integer.valueOf(type.getCode()));
            pstm.setString(1, type.getName());
            pstm.setString(2, type.getComments());
            pstm.setString(3, type.getPublishOwnerId());
            pstm.setDate(4, new java.sql.Date(new Date().getTime()));

            updOk = pstm.executeUpdate();
            pstm.close();
        } catch (SQLException e) {
            throw (new IIMexException("Error updating shipping restriction type with type code of " + type.getCode(), e));
        } finally {
            closeConnection(con);
        }
        Logger.traceExit();
        return updOk;
    }
}
