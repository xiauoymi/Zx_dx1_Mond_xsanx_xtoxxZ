package com.monsanto.enterprise.iimex.tableloader;

import java.sql.Date;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.monsanto.AbstractLogging.Logger;
import com.monsanto.Util.Exceptions.WrappingException;
import com.monsanto.dataservices.PersistentStoreObjectResultSetForwardIterator;
import com.monsanto.dataservices.PersistentStoreResultSet;
import com.monsanto.dataservices.PersistentStoreResultSetFwdIterator;
import com.monsanto.dbdataservices.PersistentStoreDBPreparedStatement;
import com.monsanto.enterprise.iimex.DataBaseQueries;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.MonitoredUser;
import com.monsanto.enterprise.iimex.elements.Update;

public class UpdateTableLoader extends TableLoader{
	
	public Update[] loadLastUpdate()throws IIMexException{
		Logger.traceEntry();
		
		Update[] last= new Update[10];
		for(int i = 0 ; i< 10 ; i++){
			last[i]=new Update();
			last[i].setDate(new Date(0));
		}

		Connection con=null;
		try {
            con = getConnection();
			String owner;
			Date date;
			String type;

			ResultSet it = con.prepareStatement(DataBaseQueries.SELECT_UPDATE_DOC).executeQuery();
			while(it.next()){
				Update upd = new Update();
				owner = it.getString(2);
				date = it.getDate(1);
				type=" Document ";
				
				upd.setDate(date);
				upd.setOwner(owner);
				upd.setType(type);
				
				for(int i = 0; i < 10 ; i++ ){
					if(last[i].getDate().compareTo(upd.getDate())<0){
						for(int j=i;j<9;j++)
							last[j]=last[j+1];
						last[i]=upd;
						break;
					}
				}
				
			}
			it.close();
			it = con.prepareStatement(DataBaseQueries.SELECT_UPDATE_DOCCOND).executeQuery();
			while(it.next()){
				Update upd = new Update();
				owner = it.getString(2);
				date = it.getDate(1);
				type=" Document condition ";
				
				upd.setDate(date);
				upd.setOwner(owner);
				upd.setType(type);
				
				for(int i = 0; i < 10 ; i++ ){
					if(last[i].getDate().compareTo(upd.getDate())<0){
						for(int j=i;j<9;j++)
							last[j]=last[j+1];
						last[i]=upd;
						break;
					}
				}
				
			}
			it.close();
			it = con.prepareStatement(DataBaseQueries.SELECT_UPDATE_LINKDOC).executeQuery();
			while(it.next()){
				Update upd = new Update();
				owner = it.getString(2);
				date = it.getDate(1);
				type=" Link document ";
				
				upd.setDate(date);
				upd.setOwner(owner);
				upd.setType(type);
				
				for(int i = 0; i < 10 ; i++ ){
					if(last[i].getDate().compareTo(upd.getDate())<0){
						for(int j=i;j<9;j++)
							last[j]=last[j+1];
						last[i]=upd;
						break;
					}
				}
				
			}
			it.close();
			it = con.prepareStatement(DataBaseQueries.SELECT_UPDATE_LINKURL).executeQuery();
			while(it.next()){
				Update upd = new Update();
				owner = it.getString(2);
				date = it.getDate(1);
				type=" Link URL ";
				
				upd.setDate(date);
				upd.setOwner(owner);
				upd.setType(type);
				
				for(int i = 0; i < 10 ; i++ ){
					if(last[i].getDate().compareTo(upd.getDate())<0){
						for(int j=i;j<9;j++)
							last[j]=last[j+1];
						last[i]=upd;
						break;
					}
				}
				
			}
            it.close();
		} catch (SQLException e) {

			throw (new IIMexException("Error in the DB row", e));

		}finally{

			closeConnection(con);

		}
		
		Logger.traceExit();
		return last;
	}
	
}