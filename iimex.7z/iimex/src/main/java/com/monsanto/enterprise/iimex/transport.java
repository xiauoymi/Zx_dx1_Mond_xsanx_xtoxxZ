package com.monsanto.enterprise.iimex;
/*
 * Used to store transport name and code
 * 
 * @deprecated rename and move to com.monsanto.enterprise.iimex.elements.Transport.java
 */
@Deprecated
public class transport{
	private String code;
	private String name;
	
	public void setCode(String c){code=c;}
	public String getCode(){return code;}
	public void setName(String n){name=n;}
	public String getName(){return name;}
}