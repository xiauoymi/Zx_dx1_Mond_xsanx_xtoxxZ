package com.monsanto.enterprise.iimex;

/**
 * data class. Used to store the name and code of a world area
 * @author AGARGAN
 * @deprecated rename and move to com.monsanto.enterprise.iimex.elements.WorldArea.java
 *
 */

@Deprecated
public class worldArea{
	private String areaName;
	private String areaCode;

	public void setAreaName(String n){
		areaName = n ;
	}
	public void setAreaCode(String c){
		areaCode = c ;
	}

	public String getAreaName(){
		return areaName;
	}
	public String getAreaCode(){
		return areaCode;
	}

}