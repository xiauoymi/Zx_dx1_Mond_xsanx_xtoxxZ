var timerID = null;

    var timerRunning = false;

    var id,pause=0, position=0;

    function msgAlert() {

        if (document.getElementById('isSearched').value != 'y') return;

	clearTimeout(id);

      var i,k,msg=" Please click in the search button to carry out the changes!!";

      k=(75/msg.length)+1;

      for(i=0;i<=k;i++) msg+=" "+msg;

      document.selectionFields.infomsg.value=

                    msg.substring(position,position+75);

      if(position++==50) position=0;

      id=setTimeout("msgAlert()",1000/10); 

    }

    

    function actionPause() {

      if(!pause) {

        clearTimeout(id);

        pause=1; 

      }

      else {

        msgAlert();

        pause=0; 

      }

    }





 function collapse(obj){

 var el=document.getElementById(obj);

 el.style.display='none';

}

 function expand(obj){

 var el=document.getElementById(obj);

  el.style.display='';

 }



 function switchMenu(obj,status) {

	var el = document.getElementById(obj);

	var statusId=document.getElementById(status);

	if ( el.style.display != "none" ) {

		el.style.display = 'none';

		statusId.value='+';

	}

	else {

		el.style.display = 'block';

		statusId.value='-';

	}

}

function fillIncoterm(){
	var  tranport = this.selectionFields.lstTransp.options[this.selectionFields.lstTransp.selectedIndex].value;
	var incoterm =this.selectionFields.lstTranspMode;
	var list =this.selectionFields.hiddenList;
	
	var pos;
	var tmp;
	
	for(var i=incoterm.length-1;i>=0;i--)
		incoterm.options[i]=null;
	
	var step=0;
	
	for(i=0;i<list.length;i++){
		tmp = list.options[i].value;
		pos = tmp.indexOf("-", 0);
		if(tmp.substr(0,pos-1)==tranport){
			incoterm.options[step]=new Option(list.options[i].text,list.options[i].value);
			step++;
		}
	}
}

function fillProduct(){
	var division = this.selectionFields.lstDivision.options[this.selectionFields.lstDivision.selectedIndex].value;
	var productGroup =this.selectionFields.lstProdGroup;
	var list =this.selectionFields.groupList;
	
	var pos;
	var tmp;
	
	for(var i=productGroup.length-1;i>=0;i--)
		productGroup.options[i]=null;
	
	var step=0;
	
	for(i=0;i<list.length;i++){
		tmp = list.options[i].value;
		pos = tmp.indexOf("-", 0);
		if(tmp.substr(0,pos-1)==division){
			productGroup.options[step]=new Option(list.options[i].text,list.options[i].value);
			step++;
		}
	}
}

function fillTrait(){
	var prodGroupTmp = this.selectionFields.lstProdGroup.options[this.selectionFields.lstProdGroup.selectedIndex].value;
	var trait =this.selectionFields.lstTrait;
	var list =this.selectionFields.traitList;
	
	var pos;
	var tmp;
	
	pos = prodGroupTmp.indexOf("-", 0);
	
	var prodGroup = prodGroupTmp.substr(pos+1,prodGroupTmp.length).split(' ').join('');
	
	for(var i=trait.length-1;i>=1;i--)
		trait.options[i]=null;
	
	var step=1;
	
	for(i=0;i<list.length;i++){
		tmp = list.options[i].value;
		pos = tmp.indexOf("-", 0);
		if(tmp.substr(0,pos-1)==prodGroup){
			trait.options[step]=new Option(list.options[i].text,list.options[i].value);
			step++;
		}
	}
	if(step==0)
		trait.options[0]=new Option("No trait for this product group","No");
}


function confirmSubmit()
{
var agree=confirm("Are you sure you wish to continue?");
if (agree)
	return true ;
else
	return false ;
}

function checkLength(elementId, limit, refocus, display) {
    var element = document.getElementById(elementId);
    var length = element.value.length;
    if(length > limit) {
        alert(display + ' exceeds limit of ' + limit + ' characters (current length =' + length + ')');
        if (refocus) {
            element.focus();
        }
        return false;
    }
    else
        return true;
}

// allFieldsToCheck is an array of Object with element ("el") to validate, "limit" of element length,
// boolean "refocus" flag, and "displayTxt" of failed field description
function checkAllLengths(allFieldsToCheck) {
    var allOK = true;
    for (var i=0;(allOK && i<allFieldsToCheck.length);i++) {
        var parms = allFieldsToCheck[i];
        allOK = checkLength(parms.el, parms.limit, parms.refocus, parms.displayTxt);
    }
    return allOK;
}

function checkEmptyElement(elementId, refocus) {
    var element = document.getElementById(elementId);
    var value = element.value;
    if (value == null && element.tagName=="SELECT") {
        value = element.options[element.selectedIndex];
    }
    if (element.value.length == 0) {
        alert('You must enter a value for ' + element.title);
        if (refocus) {
            element.focus();
        }
        return false;
    }
    return true;
}




  



