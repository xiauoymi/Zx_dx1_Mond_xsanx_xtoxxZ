package com.monsanto.enterprise.iimex.collections;

import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.elements.CountryToCountry;
import com.monsanto.enterprise.iimex.elements.ShippingRestriction;
import junit.framework.TestCase;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 20, 2010
 * Time: 4:20:34 PM
 */
public class CountryToCountryCollectionUT extends TestCase {

    private CountryToCountryCollection ctryToCtryColl;
    private List<CountryToCountry> cToCList;
    private CountryToCountry c2c_dest1 = new CountryToCountry();
    private CountryToCountry c2c_dest2 = new CountryToCountry();
    private CountryToCountry c2c_dest3 = new CountryToCountry();
    private Vector<ShippingRestriction> dest1Restrs, dest2Restrs, dest3Restrs;
    private ShippingRestriction restr1 = new ShippingRestriction();
    private ShippingRestriction restr2 = new ShippingRestriction();
    private ShippingRestriction restr3 = new ShippingRestriction();
    private ShippingRestriction restr4 = new ShippingRestriction();

    public void setUp() throws Exception {
        super.setUp();
        ctryToCtryColl = new CountryToCountryCollection();
        cToCList = new ArrayList<CountryToCountry>();
        ctryToCtryColl.setCountryToCountryList(cToCList);

        dest1Restrs = new Vector<ShippingRestriction>();
        dest2Restrs = new Vector<ShippingRestriction>();
        dest3Restrs = new Vector<ShippingRestriction>();

        c2c_dest1.setRestrictions(dest1Restrs);
        c2c_dest2.setRestrictions(dest2Restrs);
        c2c_dest3.setRestrictions(dest3Restrs);
    }

    public void testGetRestrictions_c2cCollEmpty() throws IIMexException {
        assertTrue(ctryToCtryColl.getAllCountryToCountry().isEmpty());

        Set<ShippingRestriction> res = ctryToCtryColl.getRestrictions("dontCare", "dontCare");

        assertNotNull(res);
        assertTrue(res.isEmpty());
    }

    public void testGetRestrictions_NoMatchDest() throws IIMexException {
        c2c_dest1.setDestinationCode("ACTUAL_CODE");
        cToCList.add(c2c_dest1);
        assertFalse(ctryToCtryColl.getAllCountryToCountry().isEmpty());

        Set<ShippingRestriction> res = ctryToCtryColl.getRestrictions("NO_MATCH_DEST", "dontCare");

        assertTrue(res.isEmpty());
    }

    public void testGetRestrictions_DestMatchOriginNoMatch() throws IIMexException {
        c2c_dest1.setDestinationCode("DestMatches");
        cToCList.add(c2c_dest1);

        Set<ShippingRestriction> res = ctryToCtryColl.getRestrictions("DestMatches", "OriginMatches");

        assertTrue(res.isEmpty());
    }

    public void testGetRestrictions_DestAndOriginSingleMatch() throws IIMexException {
        cToCList.add(c2c_dest1);
        c2c_dest1.setDestinationCode("DestMatch");
        dest1Restrs.add(restr1);
        dest1Restrs.add(restr3);
        restr1.setOrigin("OriginMatch");
        restr3.setOrigin("OriginNoMatch");
        restr1.setProductGroupName("A");
        restr2.setProductGroupName("B");

        cToCList.add(c2c_dest2);
        c2c_dest2.setDestinationCode("DestNoMatch");
        dest2Restrs.add(restr2);
        restr2.setOrigin("OriginMatch"); // but no matter because destination does not match

        // perform test
        Set<ShippingRestriction> res = ctryToCtryColl.getRestrictions("DestMatch", "OriginMatch");

        assertEquals(1, res.size());
        assertTrue(res.contains(restr1));
    }

    public void testGetRestrictions_MultiMatch() throws IIMexException {
        cToCList.add(c2c_dest1);
        c2c_dest1.setDestinationCode("DestMatch");
        dest1Restrs.add(restr1);
        dest1Restrs.add(restr3);
        restr1.setOrigin("OriginMatch");
        restr1.setProductGroupName("A");
        restr3.setOrigin("OriginNoMatch");

        cToCList.add(c2c_dest2);
        c2c_dest2.setDestinationCode("DestNoMatch");
        dest2Restrs.add(restr2);
        restr2.setOrigin("OriginMatch"); // but no matter because destination does not match

        cToCList.add(c2c_dest3);
        c2c_dest3.setDestinationCode("DestMatch");
        dest3Restrs.add(restr4);
        restr4.setOrigin("OriginMatch");
        restr4.setProductGroupName("B");

        // perform test
        Set<ShippingRestriction> res = ctryToCtryColl.getRestrictions("DestMatch", "OriginMatch");

        assertEquals(2, res.size());
        assertTrue(res.contains(restr1));
        assertTrue(res.contains(restr4));
    }
    
    public void testGetRestrictions_SortOrder() throws IIMexException {
        cToCList.add(c2c_dest1);
        c2c_dest1.setDestinationCode("DestMatch");
        dest1Restrs.add(restr1);
        dest1Restrs.add(restr2);
        dest1Restrs.add(restr3);
        dest1Restrs.add(restr4);
        restr1.setOrigin("OriginMatch");
        restr2.setOrigin("OriginMatch");
        restr3.setOrigin("OriginMatch");
        restr4.setOrigin("OriginMatch");
        restr1.setProductGroupName("A");
        restr2.setProductGroupName("C");
        restr3.setProductGroupName("B");
        restr4.setProductGroupName("D");

        // perform test
        Set<ShippingRestriction> res = ctryToCtryColl.getRestrictions("DestMatch", "OriginMatch");

        assertEquals(4, res.size());
        Iterator<ShippingRestriction> iter = res.iterator();
        assertSame(restr1, iter.next());
        assertSame(restr3, iter.next());
        assertSame(restr2, iter.next());
        assertSame(restr4, iter.next());
    }
}
