package com.monsanto.enterprise.iimex.collections;

import com.monsanto.enterprise.iimex.elements.DocumentConditions;
import com.monsanto.enterprise.iimex.elements.Documents;
import junit.framework.TestCase;

import java.util.HashMap;
import java.util.TreeMap;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 6, 2010
 * Time: 2:23:39 PM
 */
public class DocumentCollectionUT extends TestCase {

    private DocumentCollection docs = new DocumentCollection();
    private TreeMap<Integer, Documents> codeToDocs = new TreeMap<Integer, Documents>();

    public void testGetAllDocuments_sortsBySDocName() throws Exception {
        Documents docA = makeDocsWithDocCodeAndName(3, "A", "Y");
        Documents docB = makeDocsWithDocCodeAndName(1, "B", "Y");
        Documents docC = makeDocsWithDocCodeAndName(2, "C", "Y");
        codeToDocs.put(docC.getIDocCode(), docC);
        codeToDocs.put(docA.getIDocCode(), docA);
        codeToDocs.put(docB.getIDocCode(), docB);
        docs.setSmDocuments(codeToDocs);

        Vector<Documents> docsVec = docs.getAllDocuments();

        assertEquals(3, docsVec.size());
        assertEquals("A", docsVec.get(0).getSDocName());
        assertEquals("B", docsVec.get(1).getSDocName());
        assertEquals("C", docsVec.get(2).getSDocName());
    }

    public void testGetAllDocuments_filtersInactives() throws Exception {
        Documents docA = makeDocsWithDocCodeAndName(3, "A", "Y");
        Documents docB = makeDocsWithDocCodeAndName(1, "B", "N");
        Documents docC = makeDocsWithDocCodeAndName(2, "C", "Y");
        codeToDocs.put(docC.getIDocCode(), docC);
        codeToDocs.put(docA.getIDocCode(), docA);
        codeToDocs.put(docB.getIDocCode(), docB);
        docs.setSmDocuments(codeToDocs);

        Vector<Documents> docsVec = docs.getAllDocuments();

        assertEquals(2, docsVec.size());
        assertTrue(docsVec.contains(docA));
        assertTrue(docsVec.contains(docC));
    }

    public void testGetDocumentConditionsById_NoDocuments() throws Exception {
        docs.setSmDocuments(codeToDocs);
        assertTrue(docs.getAllDocuments().isEmpty());

        DocumentConditions docCond = docs.getDocumentConditionsById("1");

        assertNull(docCond);
    }

    public void testGetDocumentConditionsById_DocumentWithoutConditions() throws Exception {
        Documents doc = makeDocsWithDocCodeAndName(1,"A", "Y");
        codeToDocs.put(doc.getIDocCode(), doc);
        docs.setSmDocuments(codeToDocs);
        assertFalse(docs.getAllDocuments().isEmpty());
        HashMap<Integer, DocumentConditions> docCondHM = new HashMap<Integer, DocumentConditions>();
        doc.setDocumentConditionsHM(docCondHM);

        DocumentConditions docCond = docs.getDocumentConditionsById("1");

        assertNull(docCond);
    }

    public void testGetDocumentConditionsById_DocumentWithNonMatchingConditions() throws Exception {
        Documents doc = makeDocsWithDocCodeAndName(1,"A", "Y");
        codeToDocs.put(doc.getIDocCode(), doc);
        docs.setSmDocuments(codeToDocs);
        assertFalse(docs.getAllDocuments().isEmpty());
        HashMap<Integer, DocumentConditions> docCondHM = new HashMap<Integer, DocumentConditions>();
        DocumentConditions docCondNonMatching = new DocumentConditions();
        docCondNonMatching.setDocConditionCode(2);
        docCondHM.put(docCondNonMatching.getDocConditionCode(), docCondNonMatching);
        doc.setDocumentConditionsHM(docCondHM);

        DocumentConditions docCond = docs.getDocumentConditionsById("1");

        assertNull(docCond);
    }

    public void testGetDocumentConditionsById_DocumentWithMatchingConditions() throws Exception {
        Documents doc = makeDocsWithDocCodeAndName(1,"A", "Y");
        codeToDocs.put(doc.getIDocCode(), doc);
        docs.setSmDocuments(codeToDocs);
        assertFalse(docs.getAllDocuments().isEmpty());
        HashMap<Integer, DocumentConditions> docCondHM = new HashMap<Integer, DocumentConditions>();
        DocumentConditions docCondMatching = new DocumentConditions();
        docCondMatching.setDocConditionCode(2);
        docCondHM.put(docCondMatching.getDocConditionCode(), docCondMatching);
        doc.setDocumentConditionsHM(docCondHM);

        DocumentConditions docCond = docs.getDocumentConditionsById("2");

        assertSame(docCondMatching, docCond);
    }

    private Documents makeDocsWithDocCodeAndName(int docCode, String docName, String activeFlag) {
        Documents doc = new Documents();
        doc.setIDocCode(docCode);
        doc.setSDocName(docName);
        doc.setFlag(activeFlag); // makes it active if "Y"
        return doc;
    }
}
