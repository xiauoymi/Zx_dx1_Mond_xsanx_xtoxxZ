package com.monsanto.enterprise.iimex.collections;

import com.monsanto.enterprise.iimex.elements.ShippingRestrictionType;
import com.monsanto.enterprise.iimex.tableloader.TableLoaderShippingRestrictType;
import junit.framework.TestCase;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Vector;

import static org.mockito.Mockito.verify;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 31, 2010
 * Time: 10:15:48 AM
 */

public class ShipRestrictTypeCollectionUT extends TestCase {

    private ShipRestrictTypeCollection collection;
    private Vector<ShippingRestrictionType> typesCache;

    @Mock private TableLoaderShippingRestrictType loader;

    public void setUp() throws Exception {
        super.setUp();
        collection = new ShipRestrictTypeCollection();
        MockitoAnnotations.initMocks(this);
        typesCache = new Vector<ShippingRestrictionType>();
        collection.setTypesCache(typesCache);
        collection.setLoader(loader);
    }

    public void testAddType_Collision() throws Exception {
        ShippingRestrictionType type = new ShippingRestrictionType();
        type.setName("MyName");
        typesCache.add(type);
        try {
            collection.addType(type);
            fail("Should have thrown IIMexEntityCollisionException");
        } catch (IIMexEntityCollisionException ex) {
            // happy path
        }
    }

    public void testUpdateType_NoCollisionWithSelf() throws Exception {
        ShippingRestrictionType origType = new ShippingRestrictionType();
        origType.setCode("someCode");
        origType.setName("MyName");
        typesCache.add(origType);
        // In this case the update data has the same code, so it is truly an update
        ShippingRestrictionType updateSameType = new ShippingRestrictionType();
        origType.setCode("someCode");
        origType.setName("MyName");

        collection.updateType(updateSameType);

        verify(loader).updateShipRestrictType(updateSameType);
    }

    public void testUpdateType_Collision() throws Exception {
        ShippingRestrictionType origType = new ShippingRestrictionType();
        origType.setCode("someCode");
        origType.setName("MyName");
        typesCache.add(origType);
        ShippingRestrictionType otherTypeBeingUpdatedWithExistingName = new ShippingRestrictionType();
        otherTypeBeingUpdatedWithExistingName.setCode("differentCode");
        otherTypeBeingUpdatedWithExistingName.setName("MyName");
        typesCache.add(otherTypeBeingUpdatedWithExistingName);
        try {
            collection.updateType(otherTypeBeingUpdatedWithExistingName);
            fail("Should have thrown IIMexEntityCollisionException");
        } catch (IIMexEntityCollisionException ex) {
            // happy path
        }
    }
}
