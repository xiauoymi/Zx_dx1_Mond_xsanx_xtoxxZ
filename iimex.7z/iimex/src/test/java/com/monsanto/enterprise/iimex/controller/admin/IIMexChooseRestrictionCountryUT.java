package com.monsanto.enterprise.iimex.controller.admin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.UserManager;
import com.monsanto.enterprise.iimex.collections.CountryCollection;
import com.monsanto.enterprise.iimex.elements.Country;
import junit.framework.TestCase;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Vector;

import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 20, 2010
 * Time: 1:12:53 PM
 */
public class IIMexChooseRestrictionCountryUT extends TestCase {

    private IIMexChooseRestrictionCountry chooser;

    @Mock private UCCHelper helper;
    @Mock private UserManager userMgr;
    @Mock private CountryCollection countryColl;

    private Vector<Country> countries;

    private static final String MY_CONTEXT_PATH = "/myContextPath";

    @Override
    public void setUp() throws Exception {
        super.setUp();
        chooser = new IIMexChooseRestrictionCountry();
        MockitoAnnotations.initMocks(this);

        countries = new Vector<Country>();
        IIMexServlet.iimexUsersManager = userMgr;
        when(helper.getContextPath()).thenReturn(MY_CONTEXT_PATH);
        when(userMgr.getCountryCollection()).thenReturn(countryColl);
        when(countryColl.getAllActiveCountry()).thenReturn(countries);
    }

    public void testRun() throws Exception {
        // no action request param
        assertNull(helper.getRequestParameterValue("action"));

        chooser.run(helper);

        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/chooseRestrictionCountry.jsp");
        verify(helper).setSessionParameter("allCountry", countries);
        verify(helper, never()).setSessionParameter(eq("action"), any()); // no action specified
    }
}
