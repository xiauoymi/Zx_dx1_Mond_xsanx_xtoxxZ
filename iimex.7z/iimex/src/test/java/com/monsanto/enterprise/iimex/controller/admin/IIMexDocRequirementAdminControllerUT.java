package com.monsanto.enterprise.iimex.controller.admin;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.enterprise.iimex.elements.Country;
import com.monsanto.enterprise.iimex.elements.DocumentConditions;
import junit.framework.TestCase;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 5, 2010
 * Time: 11:08:46 AM
 */
public class IIMexDocRequirementAdminControllerUT extends TestCase {

    public void testBuildConditions_includesComments() throws Exception {
        MockUCCHelper helper = new MockUCCHelper(null);
        Country country = new Country();
        String comment = "This is my comment \n with an embedded newline";
        helper.setRequestParameterValue("comment", comment);

        IIMexDocRequirementAdminController controller = new IIMexDocRequirementAdminController();

        // test
        DocumentConditions conditions = controller.buildConditions(helper, null, country);

        // post assert
        assertEquals(comment, conditions.getComments());
    }
}
