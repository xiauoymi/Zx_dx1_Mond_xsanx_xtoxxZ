package com.monsanto.enterprise.iimex.controller.admin;

import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.enterprise.iimex.IIMexException;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.UserManager;
import com.monsanto.enterprise.iimex.collections.CountryCollection;
import com.monsanto.enterprise.iimex.collections.CountryToCountryCollection;
import com.monsanto.enterprise.iimex.collections.ProductCollection;
import com.monsanto.enterprise.iimex.collections.ShipRestrictTypeCollection;
import com.monsanto.enterprise.iimex.elements.ProductGroup;
import com.monsanto.enterprise.iimex.elements.ShippingRestriction;
import com.monsanto.enterprise.iimex.elements.ShippingRestrictionType;
import junit.framework.TestCase;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.Vector;

import static com.monsanto.enterprise.iimex.controller.admin.IIMexRestrictionAdminController.ACTION_PARM;
import static com.monsanto.enterprise.iimex.controller.admin.IIMexRestrictionAdminController.PRODUCT_CODE_PARM;
import static org.mockito.Mockito.*;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 24, 2010
 * Time: 11:12:22 AM
 */
public class IIMexRestrictionAdminControllerUT extends TestCase {

    private IIMexRestrictionAdminController ctrl; // class to test

    @Mock private UCCHelper helper;
    @Mock private UserManager userMgr;
    @Mock private CountryToCountryCollection c2cColl;
    @Mock private CountryCollection ctryColl;
    @Mock private ShipRestrictTypeCollection typeColl;
    @Mock private ProductCollection prodColl;

    private Vector<ProductGroup> allProd;
    private Vector<ShippingRestrictionType> allTypes;
    private Set<ShippingRestriction> restricsUnchanged, restricsChanged;

    private static final String MY_CONTEXT_PATH = "/myContextPath";
    private static final String AUTH_USER_ID = "AuthenticatedUserId";

    public void setUp() throws Exception {
        super.setUp();
        ctrl = new IIMexRestrictionAdminController();
        MockitoAnnotations.initMocks(this);

        IIMexServlet.iimexUsersManager = userMgr;
        allProd = new Vector<ProductGroup>();
        allTypes = new Vector<ShippingRestrictionType>();
        restricsUnchanged = new HashSet<ShippingRestriction>();
        restricsChanged = new HashSet<ShippingRestriction>();

        when(helper.getAuthenticatedUserID()).thenReturn(AUTH_USER_ID);
        when(helper.getContextPath()).thenReturn(MY_CONTEXT_PATH);

        when(userMgr.getProducts()).thenReturn(prodColl);
        when(userMgr.getCountryCollection()).thenReturn(ctryColl);
        when(userMgr.getCountryToCountryCollection()).thenReturn(c2cColl);
        when(userMgr.getShipmentRestrictionTypeCollection()).thenReturn(typeColl);

        when(prodColl.getAllProductGroup()).thenReturn(allProd);
        when(typeColl.getAllTypes()).thenReturn(allTypes);
        when(c2cColl.getRestrictions(anyString(),anyString()))
                .thenReturn(restricsUnchanged) // 1st time called it is unchanged
                .thenReturn(restricsChanged);  // a 2nd call will represent a refresh
    }

    public void testRun_Default() throws Exception {
        setupOriginAndDestination();
        // no action request param
        assertNull(helper.getRequestParameterValue(ACTION_PARM));

        ctrl.run(helper);

        verifyCommonPostConditions(restricsUnchanged);
        verify(helper, times(1)).setSessionParameter(eq(ACTION_PARM), any()); // no more calls besides initial reset
    }

    public void testRun_Edit() throws Exception {
        setupOriginAndDestination();
        when(helper.getRequestParameterValue(ACTION_PARM)).thenReturn("edit");
        when(helper.getRequestParameterValue(PRODUCT_CODE_PARM)).thenReturn("someCode");

        ctrl.run(helper);

        verifyCommonPostConditions(restricsUnchanged);
        verify(helper).setSessionParameter(ACTION_PARM, "edit");
        verify(helper).setSessionParameter(PRODUCT_CODE_PARM, "someCode");
        verify(helper).setSessionParameter("allTypes", allTypes);
    }

    public void testRun_New() throws Exception {
        setupOriginAndDestination();
        when(helper.getRequestParameterValue(ACTION_PARM)).thenReturn("new");
        when(helper.getRequestParameterValue(PRODUCT_CODE_PARM)).thenReturn("someLeftoverCodeStillInSession");

        ctrl.run(helper);

        verifyCommonPostConditions(restricsUnchanged);
        verify(helper).setSessionParameter(ACTION_PARM, "new");
        verify(helper, times(1)).setSessionParameter(eq(PRODUCT_CODE_PARM), any()); // no more calls besides initial reset
        verify(helper).setSessionParameter("allTypes", allTypes);
        verify(helper).setSessionParameter("allProd", allProd);
    }

    public void testRun_DeleteOK() throws Exception {
        restricsUnchanged.add(new ShippingRestriction()); // restriction exists here before, but not after
        setupOriginAndDestination();
        when(helper.getRequestParameterValue(ACTION_PARM)).thenReturn("delete");
        when(helper.getRequestParameterValue(PRODUCT_CODE_PARM)).thenReturn("codeToDelete");
        when(c2cColl.removeRestriction("someDestCode", "someOriginCode", "codeToDelete")).thenReturn(1); // delete was OK

        ctrl.run(helper);

        verifyCommonPostConditions(restricsChanged);
        verify(c2cColl).removeRestriction("someDestCode", "someOriginCode", "codeToDelete");
        verify(helper, times(1)).setSessionParameter(eq(ACTION_PARM), any()); // no more calls besides initial reset
        verify(helper, times(1)).setSessionParameter(eq(PRODUCT_CODE_PARM), any()); // no more calls besides initial reset
        verify(userMgr).updateDBstatus();
    }

    public void testRun_DeletedNothing() throws Exception {
        restricsUnchanged.add(new ShippingRestriction()); // restriction exists both here before and after too
        setupOriginAndDestination();
        when(helper.getRequestParameterValue(ACTION_PARM)).thenReturn("delete");
        when(helper.getRequestParameterValue(PRODUCT_CODE_PARM)).thenReturn("codeToDelete");
        when(c2cColl.removeRestriction("someDestCode", "someOriginCode", "codeToDelete")).thenReturn(0); // deleted no rows

        ctrl.run(helper);

        verifyCommonPostConditions(restricsUnchanged);
        verify(helper, times(1)).setSessionParameter(eq(ACTION_PARM), any()); // no more calls besides initial reset
        verify(helper, times(1)).setSessionParameter(eq(PRODUCT_CODE_PARM), any()); // no more calls besides initial reset
        verify(userMgr, never()).updateDBstatus(); //db not updated
    }

    public void testRun_SaveOK() throws Exception { // save is for saving an edited row
        restricsUnchanged.add(new ShippingRestriction());
        restricsChanged.add(new ShippingRestriction()); // a different ShippingRestriction afterwards
        setupOriginAndDestination();
        when(helper.getRequestParameterValue(ACTION_PARM)).thenReturn("save");
        when(helper.getRequestParameterValue(PRODUCT_CODE_PARM)).thenReturn("codeToSave");
        when(helper.getRequestParameterValue("restrCode")).thenReturn("restrTypeCodeToSave");
        when(helper.getRequestParameterValue("comments")).thenReturn("commentsToSave");
        when(c2cColl.updateRestriction(any(ShippingRestriction.class))).thenReturn(1); // 1 row was updated

        // perform test
        ctrl.run(helper);

        // post asserts
        verifyCommonPostConditions(restricsChanged);

        ArgumentCaptor<ShippingRestriction> argCaptor = ArgumentCaptor.forClass(ShippingRestriction.class);
        verify(c2cColl).updateRestriction(argCaptor.capture());
        ShippingRestriction restricSaved = argCaptor.getValue();
        assertEquals("someDestCode", restricSaved.getDestination());
        assertEquals("someOriginCode", restricSaved.getOrigin());
        assertEquals("codeToSave", restricSaved.getProductCode());
        assertEquals("restrTypeCodeToSave", restricSaved.getRestrictionTypeCode());
        assertEquals("commentsToSave", restricSaved.getComments());
        assertEquals(AUTH_USER_ID, restricSaved.getPublishOwnerId());

        verify(helper, times(1)).setSessionParameter(eq(ACTION_PARM), any()); // no more calls besides initial reset
        verify(helper, times(1)).setSessionParameter(eq(PRODUCT_CODE_PARM), any()); // no more calls besides initial reset
        verify(userMgr).updateDBstatus();
    }

    public void testRun_SavedNothing() throws Exception { // attempt to update responds with zero records saved
        restricsUnchanged.add(new ShippingRestriction());
        restricsChanged.add(new ShippingRestriction()); // if succcess, would be a different ShippingRestriction afterwards
        setupOriginAndDestination();
        when(helper.getRequestParameterValue(ACTION_PARM)).thenReturn("save");
        when(helper.getRequestParameterValue(PRODUCT_CODE_PARM)).thenReturn("codeToSave");
        when(helper.getRequestParameterValue("restrName")).thenReturn("nameToSave");
        when(helper.getRequestParameterValue("comments")).thenReturn("commentsToSave");
        when(c2cColl.updateRestriction(any(ShippingRestriction.class))).thenReturn(0); // 0 rows were updated

        // perform test
        ctrl.run(helper);

        // post asserts
        verifyCommonPostConditions(restricsUnchanged);

        verify(c2cColl).updateRestriction(any(ShippingRestriction.class));
        verify(helper, times(1)).setSessionParameter(eq(ACTION_PARM), any()); // no more calls besides initial reset
        verify(helper, times(1)).setSessionParameter(eq(PRODUCT_CODE_PARM), any()); // no more calls besides initial reset
        verify(userMgr, never()).updateDBstatus(); // db not updated
    }

    public void testRun_AddOK() throws Exception { // register is for saving a new added row
        restricsChanged.add(new ShippingRestriction()); // updated list will have a new record
        setupOriginAndDestination();
        when(helper.getRequestParameterValue(ACTION_PARM)).thenReturn("register");
        when(helper.getRequestParameterValue(PRODUCT_CODE_PARM)).thenReturn("codeToAdd");
        when(helper.getRequestParameterValue("restrCode")).thenReturn("restrTypeCodeToAdd");
        when(helper.getRequestParameterValue("comments")).thenReturn("commentsToAdd");
        when(c2cColl.addRestriction(any(ShippingRestriction.class))).thenReturn(1); // 1 row was added

        // perform test
        ctrl.run(helper);

        // post asserts
        verifyCommonPostConditions(restricsChanged);

        ArgumentCaptor<ShippingRestriction> argCaptor = ArgumentCaptor.forClass(ShippingRestriction.class);
        verify(c2cColl).addRestriction(argCaptor.capture());
        ShippingRestriction restricSaved = argCaptor.getValue();
        assertEquals("someDestCode", restricSaved.getDestination());
        assertEquals("someOriginCode", restricSaved.getOrigin());
        assertEquals("codeToAdd", restricSaved.getProductCode());
        assertEquals("restrTypeCodeToAdd", restricSaved.getRestrictionTypeCode());
        assertEquals("commentsToAdd", restricSaved.getComments());
        assertEquals(AUTH_USER_ID, restricSaved.getPublishOwnerId());

        verify(helper, times(1)).setSessionParameter(eq(ACTION_PARM), any()); // no more calls besides initial reset
        verify(helper, times(1)).setSessionParameter(eq(PRODUCT_CODE_PARM), any()); // no more calls besides initial reset
        verify(userMgr).updateDBstatus();
    }

    public void testRun_AddedNothing() throws Exception { // attempt to add responds with zero records saved
        restricsChanged.add(new ShippingRestriction()); // if add were success, updated list will have a new record
        setupOriginAndDestination();
        when(helper.getRequestParameterValue(ACTION_PARM)).thenReturn("register");
        when(helper.getRequestParameterValue(PRODUCT_CODE_PARM)).thenReturn("codeToAdd");
        when(helper.getRequestParameterValue("restrName")).thenReturn("nameToAdd");
        when(helper.getRequestParameterValue("comments")).thenReturn("commentsToAdd");
        when(c2cColl.addRestriction(any(ShippingRestriction.class))).thenReturn(0); // 0 rows were added

        // perform test
        ctrl.run(helper);

        // post asserts
        verifyCommonPostConditions(restricsUnchanged);

        verify(c2cColl).addRestriction(any(ShippingRestriction.class));
        verify(helper, times(1)).setSessionParameter(eq(ACTION_PARM), any()); // no more calls besides initial reset
        verify(helper, times(1)).setSessionParameter(eq(PRODUCT_CODE_PARM), any()); // no more calls besides initial reset
        verify(userMgr, never()).updateDBstatus(); // db not updated
    }

    /*---------------------------- TEST HELPER METHODS ------------------------------------

     */
    private void setupOriginAndDestination() throws IOException, IIMexException {
        when(helper.getRequestParameterValue("originCountry")).thenReturn("someOriginCode");
        when(helper.getRequestParameterValue("destCountry")).thenReturn("someDestCode");
        when(ctryColl.getCountryName("someOriginCode")).thenReturn("someOriginName");
        when(ctryColl.getCountryName("someDestCode")).thenReturn("someDestName");
    }

    private void verifyCommonPostConditions(Set<ShippingRestriction> restricsAfter) throws IOException {
        verify(helper).setSessionParameter(ACTION_PARM, ""); // always clear action at start
        verify(helper).setSessionParameter(PRODUCT_CODE_PARM, ""); // always clear product code at start
        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionAdmin.jsp");
        verify(helper).setSessionParameter("allRestr", restricsAfter);
        verify(helper).setSessionParameter("originCountry", "someOriginCode");
        verify(helper).setSessionParameter("destCountry", "someDestCode");
        verify(helper).setSessionParameter("originName", "someOriginName");
        verify(helper).setSessionParameter("destName", "someDestName");
    }
}
