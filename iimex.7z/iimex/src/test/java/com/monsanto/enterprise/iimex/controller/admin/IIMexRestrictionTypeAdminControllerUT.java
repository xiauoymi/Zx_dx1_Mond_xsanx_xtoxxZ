package com.monsanto.enterprise.iimex.controller.admin;

import static org.mockito.Mockito.*;

import com.monsanto.ServletFramework.Test.MockUCCHelper;
import com.monsanto.ServletFramework.UCCHelper;
import com.monsanto.enterprise.iimex.Servlet.IIMexServlet;
import com.monsanto.enterprise.iimex.UserManager;
import com.monsanto.enterprise.iimex.collections.IIMexEntityCollisionException;
import com.monsanto.enterprise.iimex.collections.ShipRestrictTypeCollection;
import com.monsanto.enterprise.iimex.elements.ShippingRestrictionType;
import junit.framework.TestCase;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: KBWELK
 * Date: Aug 16, 2010
 * Time: 2:43:08 PM
 */
public class IIMexRestrictionTypeAdminControllerUT extends TestCase {

    private IIMexRestrictionTypeAdminController ctrl;

    @Spy private MockUCCHelper helper;
    @Mock private UserManager userMgr;
    @Mock private ShipRestrictTypeCollection sRestrictCollect;

    private Vector<ShippingRestrictionType> initialTypes;
    private Vector<ShippingRestrictionType> typesAfterUpdate;

    private static final String MY_CONTEXT_PATH = "/myContextPath";
    private static final String AUTH_USER_ID = "AuthenticatedUserId";

    @Override
    protected void setUp() throws Exception {
        super.setUp();
        ctrl = new IIMexRestrictionTypeAdminController();
        helper = new MockUCCHelper("");
        MockitoAnnotations.initMocks(this);

        IIMexServlet.iimexUsersManager = userMgr;
        initialTypes = new Vector<ShippingRestrictionType>();
        typesAfterUpdate = new Vector<ShippingRestrictionType>();

        when(helper.getAuthenticatedUserID()).thenReturn(AUTH_USER_ID);
        when(helper.getContextPath()).thenReturn(MY_CONTEXT_PATH);
        when(userMgr.getShipmentRestrictionTypeCollection()).thenReturn(sRestrictCollect);
        when(sRestrictCollect.getAllTypes()).thenReturn(initialTypes).thenReturn(typesAfterUpdate);
    }

    public void testRun_Default() throws Exception {
        // no action request param
        assertNull(helper.getRequestParameterValue("action"));

        ctrl.run(helper);

        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        assertSame(initialTypes, helper.getSessionParameter("allTypes"));
        assertEquals("", helper.getSessionParameter("action")); // no action specified
    }

    public void testRun_Edit() throws Exception {
        helper.setRequestParameterValue("action", "edit");
        helper.setRequestParameterValue("code", "someCode");

        ctrl.run(helper);

        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        assertSame(initialTypes, helper.getSessionParameter("allTypes"));
        assertEquals("edit", helper.getSessionParameter("action"));
        assertEquals("someCode", helper.getSessionParameter("code"));
    }

    public void testRun_New() throws Exception {
        helper.setRequestParameterValue("action", "new");
        helper.setRequestParameterValue("code", "someLeftoverCodeStillInSession");

        ctrl.run(helper);

        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        assertSame(initialTypes, helper.getSessionParameter("allTypes"));
        assertEquals("new", helper.getSessionParameter("action"));
        assertEquals("", helper.getSessionParameter("code")); // old session value is erased
    }

    public void testRun_DeleteOK() throws Exception {
        helper.setRequestParameterValue("action", "delete");
        helper.setRequestParameterValue("code", "codeToDelete");
        when(sRestrictCollect.removeType("codeToDelete")).thenReturn(1); // delete was OK

        ctrl.run(helper);

        verify(sRestrictCollect).removeType("codeToDelete");
        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        assertEquals("", helper.getSessionParameter("action")); // go back to default action
        assertEquals("", helper.getSessionParameter("code")); // old session value is erased
        assertSame(typesAfterUpdate, helper.getSessionParameter("allTypes")); // updated collection after delete
        verify(userMgr).updateDBstatus();
    }

    public void testRun_DeletedNothing() throws Exception {
        helper.setRequestParameterValue("action", "delete");
        helper.setRequestParameterValue("code", "codeToDelete");
        when(sRestrictCollect.removeType("codeToDelete")).thenReturn(0); // deleted no rows

        ctrl.run(helper);

        verify(sRestrictCollect).removeType("codeToDelete");
        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        assertEquals("", helper.getSessionParameter("action")); // go back to default action
        assertEquals("", helper.getSessionParameter("code")); // old session value is erased
        assertSame(initialTypes, helper.getSessionParameter("allTypes")); // types remain unchanged
        verify(userMgr, never()).updateDBstatus(); //db not updated
    }

    public void testRun_SaveOK() throws Exception { // save is for saving an edited row
        helper.setRequestParameterValue("action", "save");
        helper.setRequestParameterValue("code", "codeToSave");
        helper.setRequestParameterValue("name", "nameToSave");
        helper.setRequestParameterValue("comments", "commentsToSave");
        when(sRestrictCollect.updateType(any(ShippingRestrictionType.class))).thenReturn(1); // 1 row was updated

        // perform test
        ctrl.run(helper);

        // post asserts
        ArgumentCaptor<ShippingRestrictionType> argCaptor = ArgumentCaptor.forClass(ShippingRestrictionType.class);
        verify(sRestrictCollect).updateType(argCaptor.capture());
        ShippingRestrictionType typeSaved = argCaptor.getValue();
        assertEquals("codeToSave", typeSaved.getCode());
        assertEquals("nameToSave", typeSaved.getName());
        assertEquals("commentsToSave", typeSaved.getComments());
        assertEquals(AUTH_USER_ID, typeSaved.getPublishOwnerId());

        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        assertEquals("", helper.getSessionParameter("action")); // go back to default action
        assertEquals("", helper.getSessionParameter("code")); // old session value is erased
        assertSame(typesAfterUpdate, helper.getSessionParameter("allTypes")); //  // updated collection after save
        verify(userMgr).updateDBstatus();
    }

    public void testRun_SavedNothing() throws Exception { // attempt to update responds with zero records saved
        helper.setRequestParameterValue("action", "save");
        helper.setRequestParameterValue("code", "codeToSave");
        when(sRestrictCollect.updateType(any(ShippingRestrictionType.class))).thenReturn(0); // 0 rows were updated

        // perform test
        ctrl.run(helper);

        // post asserts
        verify(sRestrictCollect).updateType(any(ShippingRestrictionType.class));
        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        assertEquals("", helper.getSessionParameter("action")); // go back to default action
        assertEquals("", helper.getSessionParameter("code")); // old session value is erased
        assertSame(initialTypes, helper.getSessionParameter("allTypes")); // types remain unchanged
        verify(userMgr, never()).updateDBstatus(); // db not updated
    }

    public void testRun_SaveWithCollision() throws Exception {
        helper.setRequestParameterValue("action", "save");
        helper.setRequestParameterValue("code", "codeToSave");
        helper.setRequestParameterValue("name", "nameToSave");
        helper.setRequestParameterValue("comments", "commentsToSave");
        when(sRestrictCollect.updateType(any(ShippingRestrictionType.class))).thenThrow(new IIMexEntityCollisionException("SomeCollisionMessage"));

        // perform test
        ctrl.run(helper);

        // post asserts
//        verify(sRestrictCollect).addType(any(ShippingRestrictionType.class));
        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        // everything else remains unchanged
        assertEquals("edit", helper.getSessionParameter("action")); // go back to change name
        assertEquals("codeToSave", helper.getSessionParameter("code"));
        assertEquals("nameToSave", helper.getSessionParameter("name"));
        assertEquals("commentsToSave", helper.getSessionParameter("comments"));
        assertSame(initialTypes, helper.getSessionParameter("allTypes")); // types remain unchanged
        assertEquals("SomeCollisionMessage", helper.getSessionParameter("errorMsg"));
        verify(userMgr, never()).updateDBstatus(); // db not updated
    }

    public void testRun_AddOK() throws Exception { // register  is for saving a new added row
        helper.setRequestParameterValue("action", "register");
        helper.setRequestParameterValue("name", "nameToAdd");
        helper.setRequestParameterValue("comments", "commentsToAdd");
        when(sRestrictCollect.addType(any(ShippingRestrictionType.class))).thenReturn(1); // 1 row was added

        // perform test
        ctrl.run(helper);

        // post asserts
        ArgumentCaptor<ShippingRestrictionType> argCaptor = ArgumentCaptor.forClass(ShippingRestrictionType.class);
        verify(sRestrictCollect).addType(argCaptor.capture());
        ShippingRestrictionType typeSaved = argCaptor.getValue();
        assertEquals("nameToAdd", typeSaved.getName());
        assertEquals("commentsToAdd", typeSaved.getComments());
        assertEquals(AUTH_USER_ID, typeSaved.getPublishOwnerId());

        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        assertEquals("", helper.getSessionParameter("action")); // go back to default action
        assertEquals("", helper.getSessionParameter("code")); // no code for add (created at insert)
        assertSame(typesAfterUpdate, helper.getSessionParameter("allTypes")); // updated collection after save
        verify(userMgr).updateDBstatus();
    }

    public void testRun_AddedNothing() throws Exception { // attempt to add responds with zero records saved
        helper.setRequestParameterValue("action", "register");
        when(sRestrictCollect.addType(any(ShippingRestrictionType.class))).thenReturn(0); // 0 rows were added

        // perform test
        ctrl.run(helper);

        // post asserts
        verify(sRestrictCollect).addType(any(ShippingRestrictionType.class));
        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        assertEquals("", helper.getSessionParameter("action")); // go back to default action
        assertEquals("", helper.getSessionParameter("code")); // no code for add (created at insert)
        assertSame(initialTypes, helper.getSessionParameter("allTypes")); // types remain unchanged
        verify(userMgr, never()).updateDBstatus(); // db not updated
    }

    public void testRun_AddWithCollision() throws Exception {
        helper.setRequestParameterValue("action", "register");
        helper.setRequestParameterValue("name", "nameToAdd");
        helper.setRequestParameterValue("comments", "commentsToAdd");
        when(sRestrictCollect.addType(any(ShippingRestrictionType.class))).thenThrow(new IIMexEntityCollisionException("SomeCollisionMessage"));

        // perform test
        ctrl.run(helper);

        // post asserts
        verify(sRestrictCollect).addType(any(ShippingRestrictionType.class));
        verify(helper).redirect(MY_CONTEXT_PATH + "/admin/restrictionTypeAdmin.jsp");
        // everything else remains unchanged
        assertEquals("new", helper.getSessionParameter("action")); // go back to change name
        assertEquals("", helper.getSessionParameter("code")); // no code for add (created at insert)
        assertEquals("nameToAdd", helper.getSessionParameter("name"));
        assertEquals("commentsToAdd", helper.getSessionParameter("comments"));
        assertSame(initialTypes, helper.getSessionParameter("allTypes")); // types remain unchanged
        assertEquals("SomeCollisionMessage", helper.getSessionParameter("errorMsg"));
        verify(userMgr, never()).updateDBstatus(); // db not updated
    }

}
