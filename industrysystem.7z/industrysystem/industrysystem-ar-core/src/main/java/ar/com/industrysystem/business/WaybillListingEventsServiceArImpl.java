package ar.com.industrysystem.business;

import com.industrysystem.business.WaybillListingEventsService;
import com.industrysystem.business.WaybillListingEventsServiceImpl;
import com.industrysystem.business.dtos.waybilllisting.WaybillListingEvent;
import com.industrysystem.entities.Event;
import com.industrysystem.persistence.daos.report.ReportDao;
import com.industrysystem.persistence.daos.report.ReportRequest;
import com.industrysystem.persistence.daos.report.ReportResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * User: CGLLLO
 * Date: 21/02/14
 */
@Component
public class WaybillListingEventsServiceArImpl extends WaybillListingEventsServiceImpl {

    public static final String BASE_QUERY = "select event"
                                        + " from Event event, WaybillAr waybillAr"
                                        + " where event.waybill = waybillAr"
                                        ;

    public WaybillListingEventsServiceArImpl() {
        // The key is the report column name and he value is the query name.
        FILTER_MAP.put("identifier", "waybillAr.waybillNumber");
    }

    protected String getBaseQuery() {
        return BASE_QUERY;
    }
}
