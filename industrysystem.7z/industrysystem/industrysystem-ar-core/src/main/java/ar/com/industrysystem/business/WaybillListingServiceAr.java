package ar.com.industrysystem.business;

import com.industrysystem.persistence.daos.report.ReportRequest;
import com.industrysystem.persistence.daos.report.ReportResponse;
import org.springframework.transaction.annotation.Transactional;

/**
 * User: CGLLLO
 * Date: 18/02/14
 */
public interface WaybillListingServiceAr {

    ReportResponse createReportResponseForGrower(ReportRequest reportRequest, int maxResults);

    ReportResponse createReportResponseForTraitOwner(ReportRequest reportRequest, int maxResults);

    ReportResponse createReportResponseForPodBranchesOfUser(ReportRequest reportRequest, int maxResults);
}
