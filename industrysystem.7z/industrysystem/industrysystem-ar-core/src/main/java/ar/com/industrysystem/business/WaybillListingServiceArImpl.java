package ar.com.industrysystem.business;

import ar.com.industrysystem.business.dtos.waybilllisting.WaybillListingAr;
import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.business.WaybillService;
import com.industrysystem.business.users.UsersService;
import com.industrysystem.entities.Document;
import com.industrysystem.entities.DocumentType;
import com.industrysystem.entities.PodBranch;
import com.industrysystem.exceptions.PodNotFoundException;
import com.industrysystem.persistence.daos.DocumentTypeDao;
import com.industrysystem.persistence.daos.report.ReportDao;
import com.industrysystem.persistence.daos.report.ReportRequest;
import com.industrysystem.persistence.daos.report.ReportResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * User: CGLLLO
 * Date: 18/02/14
 */
@Component
public class WaybillListingServiceArImpl implements WaybillListingServiceAr {

    public static final String BASE_QUERY = "select waybill"
                                        + " from WaybillAr waybill, LoadDetail loadDetail"
                                        + " where loadDetail.waybill = waybill";

    private final Map<String, String> FILTER_MAP = new HashMap<String, String>();

    @Autowired
    private ReportDao reportDao;

    @Autowired
    DocumentTypeDao documentTypeDao;

    @Autowired
    private UsersService usersService;

    @Autowired
    private WaybillService waybillService;

    public WaybillListingServiceArImpl() {
        // The key is the report column name and the value is the query name.
        FILTER_MAP.put("identifier", "waybill.waybillNumber");
        FILTER_MAP.put("holder.documentType", "waybill.holderDocument.type.code");
        FILTER_MAP.put("holder.documentNumber", "waybill.holderDocument.number");
        FILTER_MAP.put("commercialSender.name", "waybill.commercialSenderName");
        FILTER_MAP.put("commercialSender.documentType", "waybill.commercialSenderDocument.type.code");
        FILTER_MAP.put("commercialSender.documentNumber", "waybill.commercialSenderDocument.number");
        FILTER_MAP.put("creationDate", "waybill.creationDate");
        FILTER_MAP.put("status", "waybill.status");
        FILTER_MAP.put("loadDetails.weight", "loadDetail.weight");
    }

    @Override
    @Transactional(readOnly = true)
    public ReportResponse createReportResponseForPodBranchesOfUser(ReportRequest reportRequest, int maxResults) {
        try {
            List<PodBranch> podBranchesFromCurrentUser = usersService.getPodBranchesFromCurrentUser();
            if (!podBranchesFromCurrentUser.isEmpty()) {
                String query = BASE_QUERY + " and waybill.destination in(:podBranchesFromCurrentUser)";
                Map<String, Object> namedParameters = new HashMap<String, Object>();
                namedParameters.put("podBranchesFromCurrentUser", podBranchesFromCurrentUser);
                return createReportResponse(reportRequest, maxResults, query, namedParameters);
            }
        } catch (PodNotFoundException ex) {}
        return new ReportResponse();
    }

    @Override
    @Transactional(readOnly = true)
    public ReportResponse createReportResponseForGrower(ReportRequest reportRequest, int maxResults) {
        List<Document> growerDocumentsForCurrentUser = usersService.listGrowerDocumentsForCurrentUser();
        if (!growerDocumentsForCurrentUser.isEmpty()) {
            resolveDocumentTypes(growerDocumentsForCurrentUser);
            String query = BASE_QUERY + " and waybill.holderDocument in(:growerDocumentsForCurrentUser)";
            Map<String, Object> namedParameters = new HashMap<String, Object>();
            namedParameters.put("growerDocumentsForCurrentUser", growerDocumentsForCurrentUser);
            return createReportResponse(reportRequest, maxResults, query, namedParameters);
        }
        return new ReportResponse();
    }

    // search the persistent DocumentType in the DB.
    private void resolveDocumentTypes(List<Document> growerDocumentsForCurrentUser) {
        for(Document document : growerDocumentsForCurrentUser) {
            document.setType(documentTypeDao.findByCode(document.getType().getCode()));
        }
    }

    @Override
    @Transactional(readOnly = true)
    public ReportResponse createReportResponseForTraitOwner(ReportRequest reportRequest, int maxResults) {
        Map<String, Object> namedParameters = new HashMap<String, Object>();
        return createReportResponse(reportRequest, maxResults, BASE_QUERY, namedParameters);
    }


    private ReportResponse createReportResponse(ReportRequest reportRequest, int maxResults, String query, Map<String, Object> namedParameters) {
        reportRequest.renameFields(FILTER_MAP);

        Collection<WaybillAr> waybills = reportDao.getReportContent(
                query,
                reportRequest,
                namedParameters,
                WaybillAr.class,
                maxResults
        );

        Collection<WaybillListingAr> reportContent = createReportContentFromQueryResult(waybills);

        int totalPages = reportDao.getTotalPages(
                query,
                reportRequest,
                namedParameters,
                maxResults
        );
        return new ReportResponse(reportContent, totalPages);
    }


    private Collection<WaybillListingAr> createReportContentFromQueryResult(Collection<WaybillAr> waybills) {
        Collection<WaybillListingAr> reportContent = new ArrayList<WaybillListingAr>();
        for (WaybillAr waybill : waybills) {
            WaybillListingAr waybillListingAr = new WaybillListingAr(waybill);
            String holderName = waybillService.getHolderName(waybill);
            waybillListingAr.getHolder().setName(holderName);
            reportContent.add(waybillListingAr);
        }
        return reportContent;
    }

}
