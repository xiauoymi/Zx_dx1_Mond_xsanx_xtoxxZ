package ar.com.industrysystem.business;

import ar.com.industrysystem.business.dtos.WaybillDtoAr;
import ar.com.industrysystem.business.mappers.WaybillMapperAr;
import ar.com.industrysystem.business.validators.WaybillValidatorAr;
import ar.com.industrysystem.entities.WaybillAr;
import com.google.common.base.Predicate;
import com.industrysystem.business.EventService;
import com.industrysystem.business.TestsService;
import com.industrysystem.business.WaybillService;
import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.WagonDetailDTO;
import com.industrysystem.entities.LoadDetail;
import com.industrysystem.entities.Sample;
import com.industrysystem.entities.TransportType;
import com.industrysystem.entities.WaybillStatusEnum;
import com.industrysystem.exceptions.*;
import com.industrysystem.persistence.daos.GrowerDao;
import com.industrysystem.persistence.daos.WaybillDao;
import com.industrysystem.utils.Sundial;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import static com.google.common.collect.Iterables.getOnlyElement;
import static com.google.common.collect.Sets.filter;
import static com.industrysystem.entities.TransportType.fromCode;
import static org.apache.commons.lang.StringUtils.isNotEmpty;
import static org.apache.commons.lang.StringUtils.upperCase;

@Service
public class WaybillServiceArImpl {

    @Autowired
    private Sundial sundial;

    @Autowired
    private WaybillMapperAr waybillMapperAr;

    @Autowired
    private WaybillDao waybillDao;

    @Autowired
    private TestsService testsService;

    @Autowired
    private EventService eventService;

	@Autowired
    private WaybillService waybillService;

    @Autowired
    private GrowerDao growerDao;

    @Autowired
    private WaybillValidatorAr waybillValidator;

    @Transactional(rollbackFor = {BusinessException.class})
    @PreAuthorize("hasStrictRolePodReceptionOperator(#waybillDto.destinationCommercialCode, #waybillDto.destinationDocumentType, #waybillDto.destinationDocument)")
    public void registerWaybill(WaybillDtoAr waybillDto) throws WaybillRegistrationException {
        try {
            waybillValidator.validate(waybillDto);

            WaybillAr waybill = waybillMapperAr.map(waybillDto);
            waybill.setInitialState(WaybillStatusEnum.RECEIVED);
            waybillDao.save(waybill);

            if (waybill.hasDeclaration()) {
                growerDao.findOrCreateGrower(waybill.getHolderDocument(), upperCase(waybillDto.getHolderName()));
            }

            waybill.changeState();
            eventService.saveWaybillReceivedEvent(waybill);
        } catch (BusinessException ex) {
            throw new WaybillRegistrationException(ex);
        } catch (Exception e) {
            throw new WaybillRegistrationException(e);
        }
    }

    @Transactional(rollbackFor = {BusinessException.class})
    @PreAuthorize("hasStrictRolePodReceptionOperator(#waybillDto.destinationCommercialCode, #waybillDto.destinationDocumentType, #waybillDto.destinationDocument)")
    public WaybillDtoAr waybillManualRegistration(WaybillDtoAr waybillDto) throws StoreWeightException, WaybillRegistrationException,
            LocationNotFoundException, LaboratoryNotFoundException, WaybillNotFoundException, SampleDeterminationException,
            StoreSampleException {
        waybillValidator.validateManualWaybill(waybillDto.removeDocumentsHyphens());

        registerWaybill(waybillDto);
        waybillService.storeWeightAndSampleInfo(waybillDto.getWaybillNumberAsLong(), waybillDto.getQuantitativeLabCode(),
                waybillDto.getQualitativeLabCode(), waybillDto.getLoadDetails());

        return waybillDto;
    }

    @Transactional(rollbackFor = {BusinessException.class})
    @PreAuthorize("hasStrictRolePodBatchOperator(#waybillDto.destinationCommercialCode, #waybillDto.destinationDocumentType, #waybillDto.destinationDocument)")
    public void registerFullWaybill(WaybillDtoAr waybillDto) throws WaybillRegistrationException {
        try {
            LoadDetailDTO loadDetailDTO = getOnlyElement(waybillDto.getLoadDetails());
            if (TransportType.VAGON_FERROVIARIO == fromCode(waybillDto.getWaybillType())) {
                wagonWaybillLoad(waybillDto, loadDetailDTO);
            } else {
                //It's a truck waybill
                truckLoad(waybillDto, loadDetailDTO);
            }
        } catch (BusinessException ex) {
            throw new WaybillRegistrationException(ex);
        } catch (Exception e) {
            throw new WaybillRegistrationException(e);
        }
    }

    private void truckLoad(WaybillDtoAr waybillDto, LoadDetailDTO loadDetailDTO) throws WaybillRegistrationException,
            ParseException, StoreWeightException, SampleDeterminationException, WaybillNotFoundException, StoreSampleException,
            TypeOfTestException, UserNotLoggedException {
        registerWaybill(waybillDto);
        storeWeight(waybillDto);
        testsService.shouldWaybillTakeSample(new Sample(waybillDto.getWaybillNumberAsLong()));
        storeSampleIfNeeded(waybillDto);
        waybillReadyToBeInformedIfTechnologyDeclared(waybillDto.getWaybillNumberAsLong(), loadDetailDTO);
    }

    private void waybillReadyToBeInformedIfTechnologyDeclared(Long waybillNumber, LoadDetailDTO loadDetailDTO)
            throws WaybillNotFoundException, UserNotLoggedException {
        if (isNotEmpty(loadDetailDTO.getDeclaredTechnology())) {
            waybillReadyToBeInformed(waybillNumber);
        }
    }

    private void wagonWaybillLoad(WaybillDtoAr waybillDto, LoadDetailDTO loadDetailDTO) throws WaybillRegistrationException,
            ParseException, StoreWeightException, SampleDeterminationException, StoreSampleException, TypeOfTestException,
            WaybillNotFoundException, UserNotLoggedException {
        try {
            wagonWaybillNextLoad(waybillDto, loadDetailDTO);
        } catch (WaybillNotFoundException e1) {
            wagonWaybillFirstLoad(waybillDto, loadDetailDTO);
        }
    }

    private void waybillReadyToBeInformed(Long waybillNumber) throws WaybillNotFoundException, UserNotLoggedException {
        WaybillAr waybillAr = (WaybillAr)waybillDao.findWaybillByWaybillNumber(waybillNumber);
        eventService.saveReadyToBeInformedEvent(waybillAr);
    }

    private boolean needSampleDetermination(Long waybillNumber) throws WaybillNotFoundException {
        WaybillAr waybillAr = (WaybillAr)waybillDao.findWaybillByWaybillNumber(waybillNumber);
        return waybillAr.isSampleRequired();
    }

    private void wagonWaybillNextLoad(WaybillDtoAr waybillDto, LoadDetailDTO loadDetailDTO) throws WaybillNotFoundException,
            WaybillRegistrationException, ParseException, StoreWeightException, SampleDeterminationException, StoreSampleException,
            TypeOfTestException {
        WaybillAr waybillAr = (WaybillAr)waybillDao.findWaybillByWaybillNumber(waybillDto.getWaybillNumberAsLong());
        if (!wagonDetailDtoIsRegisteredInLoadDetailSet((WagonDetailDTO)loadDetailDTO, waybillAr.getLoadDetails())) {
            registerWagonWaybill(waybillDto, waybillAr, loadDetailDTO);
            storeWeight(waybillDto);
            testsService.shouldWaybillTakeSample(new Sample(waybillDto.getWaybillNumberAsLong()));
            storeSampleIfNeeded(waybillDto);
        } else {
            throw new WaybillRegistrationException(new FieldBusinessError(BusinessError.LOAD_DETAIL_ALREADY_EXIST,
                    "error.invalid.wagon.identifier", "loadIdentifier", waybillDto.getWaybillNumber()));
        }
    }

    private void wagonWaybillFirstLoad(WaybillDtoAr waybillDto, LoadDetailDTO loadDetailDTO) throws WaybillRegistrationException,
            ParseException, StoreWeightException, StoreSampleException, TypeOfTestException, SampleDeterminationException,
            WaybillNotFoundException, UserNotLoggedException {
        if (Integer.valueOf(((WagonDetailDTO)loadDetailDTO).getWagonsQty()) > 1) {
            registerWagonWaybill(waybillDto, null, loadDetailDTO);
        } else {
            //It is like a truck because wagonQty == 1
            registerWaybill(waybillDto);
        }
        testsService.shouldWaybillTakeSample(new Sample(waybillDto.getWaybillNumberAsLong()));
        storeWeight(waybillDto);
        storeSampleIfNeeded(waybillDto);
        waybillReadyToBeInformedIfTechnologyDeclared(waybillDto.getWaybillNumberAsLong(), loadDetailDTO);
    }

    private Boolean wagonDetailDtoIsRegisteredInLoadDetailSet(WagonDetailDTO wagonDetailDTO, Set<LoadDetail> loadDetails) {
        if (loadDetails.size() != (Integer.parseInt(wagonDetailDTO.getWagonsQty()))) {
            return isLoadDetailDtoIdentifierInLoadDetailSet(wagonDetailDTO, loadDetails);
        } else {
            return Boolean.TRUE;
        }
    }

    private Boolean isLoadDetailDtoIdentifierInLoadDetailSet(final LoadDetailDTO loadDetailDTO, Set<LoadDetail> loadDetails) {
        Predicate<LoadDetail> withLoadIdentifier = new Predicate<LoadDetail>() {
            @Override
            public boolean apply(LoadDetail loadDetail) {
                return loadDetail.getIdentifier().equalsIgnoreCase(loadDetailDTO.getLoadIdentifier());
            }
        };

        return !filter(loadDetails, withLoadIdentifier).isEmpty();
    }

    private void storeSampleIfNeeded(WaybillDtoAr waybillDto) throws WaybillNotFoundException, StoreSampleException,
            TypeOfTestException, SampleDeterminationException {
        if (needSampleDetermination(waybillDto.getWaybillNumberAsLong())) {
            storeSample(waybillDto);
        }
    }

    private void storeSample(WaybillDtoAr waybillDto) throws StoreSampleException, TypeOfTestException, SampleDeterminationException {
        LoadDetailDTO loadDetailDTO = getOnlyElement(waybillDto.getLoadDetails());
        String sampleCode = loadDetailDTO.getSampleCode();
        if (isNotEmpty(sampleCode)) {
            testsService.storeSample(sampleCode, waybillDto.getQuantitativeLabCode(), waybillDto.getQualitativeLabCode(),
                    waybillDto.getWaybillNumberAsLong(), loadDetailDTO.getLoadIdentifier());
        }
    }

    private void storeWeight(WaybillDtoAr waybillDto) throws ParseException, StoreWeightException {
        Date unloadingDate = new SimpleDateFormat("dd/MM/yyyy").parse(waybillDto.getUnloadingDate().trim());
        if (sundial.isAfterNow(unloadingDate)) {
            throw new StoreWeightException(new BusinessError(BusinessError.INVALID_UNLOAD_TIME, "Unload time must not be a future time"));
        }

        LoadDetailDTO loadDetail = getOnlyElement(waybillDto.getLoadDetails());
        waybillService.storeWeight(waybillDto.getWaybillNumberAsLong(), loadDetail.getWeight(), loadDetail.getLoadIdentifier(), unloadingDate);
    }

    private void registerWagonWaybill(WaybillDtoAr waybillDto, WaybillAr waybillAr, LoadDetailDTO loadDetailDTO)
            throws WaybillRegistrationException {
        try {
            if (waybillAr == null) {
                waybillAr = waybillMapperAr.map(waybillDto);
                waybillAr.setInitialState(WaybillStatusEnum.PARTIALLY_RECEIVED);
                waybillDao.save(waybillAr);
                eventService.saveWaybillPartiallyReceivedEvent(waybillAr);
            } else {
                waybillAr = waybillMapperAr.mapWaybill(waybillAr, waybillDto);
                int dtoQty = Integer.valueOf(((WagonDetailDTO)loadDetailDTO).getWagonsQty());
                if (waybillAr.getLoadDetails().size() == dtoQty) {
                    eventService.saveWaybillReceivedEvent(waybillAr);
                } else {
                    eventService.saveWaybillPartiallyReceivedEvent(waybillAr);
                }
            }
            waybillAr.changeState();
        } catch (BusinessException ex) {
            throw new WaybillRegistrationException(ex);
        } catch (Exception e) {
            throw new WaybillRegistrationException(e);
        }
    }

}