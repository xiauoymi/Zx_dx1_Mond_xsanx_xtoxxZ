package ar.com.industrysystem.business.dtos;

import com.google.common.primitives.Ints;
import com.industrysystem.business.dtos.WaybillDto;
import com.industrysystem.entities.DocumentType;

public class WaybillDtoAr extends WaybillDto {

    private String originEstablishment;

    public String getOriginEstablishment() {
        return originEstablishment;
    }

    public void setOriginEstablishment(String originEstablishment) {
        this.originEstablishment = originEstablishment;
    }

    @Override
    public String getDestinationDocumentType() {
       return DocumentType.CUIT;
    }

    @Override
    public String getAddresseeDocumentType() {
       return DocumentType.CUIT;
    }

    @Override
    public String getHolderDocumentType() {
       return DocumentType.CUIT;
    }

	@Override
	public String getCommercialSenderDocumentType() {
		 return DocumentType.CUIT;
	}

    @Override
    public boolean isHolderDeclaredAsPod() {
        return getOriginEstablishment() != null && Ints.tryParse(getOriginEstablishment()) != null;
    }

}