package ar.com.industrysystem.business.dtos;

import com.industrysystem.business.dtos.WaybillTestResultDTO;
import com.industrysystem.entities.DocumentType;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 23/01/14
 */
public class WaybillTestResultDTOAr extends WaybillTestResultDTO {

    @Override
    public String getDestinationDocumentType() {
        return DocumentType.CUIT;
    }

    @Override
    public String getAddresseeDocumentType() {
        return DocumentType.CUIT;
    }

    @Override
    public String getHolderDocumentType() {
        return DocumentType.CUIT;
    }

    @Override
    public String getCommercialSenderDocumentType() {
        return DocumentType.CUIT;
    }

}
