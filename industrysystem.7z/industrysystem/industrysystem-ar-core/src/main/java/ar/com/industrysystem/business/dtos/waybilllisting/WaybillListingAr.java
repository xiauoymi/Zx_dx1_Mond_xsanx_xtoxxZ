package ar.com.industrysystem.business.dtos.waybilllisting;

import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.business.dtos.waybilllisting.WaybillListing;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 18/02/14
 * Time: 10:28
 */
public class WaybillListingAr extends WaybillListing {

    public WaybillListingAr(WaybillAr waybill) {
        super(waybill);
        setGoodsSource(new WaybillListingGoodsAr(waybill));
    }

}
