package ar.com.industrysystem.business.dtos.waybilllisting;

import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.business.dtos.waybilllisting.WaybillListingGoods;
import com.industrysystem.entities.Location;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 14/02/14
 * Time: 11:59
 */
public class WaybillListingGoodsAr extends WaybillListingGoods {

    private String establishment;

    public WaybillListingGoodsAr(WaybillAr waybill) {
        super(waybill.getGoodsSourceCity());
        establishment = waybill.getPlantCode();
    }

    public String getEstablishment() {
        return establishment;
    }
}
