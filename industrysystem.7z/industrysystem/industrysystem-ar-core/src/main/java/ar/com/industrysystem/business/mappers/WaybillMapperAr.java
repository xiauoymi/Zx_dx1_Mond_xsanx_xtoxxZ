package ar.com.industrysystem.business.mappers;

import org.springframework.stereotype.Component;

import ar.com.industrysystem.business.dtos.WaybillDtoAr;

import com.industrysystem.business.mappers.WaybillMapper;
import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.exceptions.WaybillRegistrationException;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 29/11/13
 */
@Component
public class WaybillMapperAr extends WaybillMapper {

	public WaybillAr map(WaybillDtoAr waybillDto) throws WaybillRegistrationException {
		WaybillAr waybill = new WaybillAr();
		waybill.setWaybillNumber(waybillDto.getWaybillNumberAsLong());
		waybill.setPlantCode(waybillDto.getOriginEstablishment());

        super.map(waybill, waybillDto);

		return waybill;
	}

    public WaybillAr mapWaybill(WaybillAr waybillAr, WaybillDtoAr waybillDtoAr) throws WaybillRegistrationException {
        super.map(waybillAr, waybillDtoAr);
        return waybillAr;
    }

}