package ar.com.industrysystem.business.validators;

import com.industrysystem.business.validators.DocumentValidator;
import com.industrysystem.entities.DocumentType;
import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.InvalidDocumentNumberException;
import org.springframework.stereotype.Component;

import static com.industrysystem.business.validators.Validator.isZeroOrNaturalNumber;

/**
 * User: PPERA
 * Date: 03/10/13
 * Time: 10:04
 */
@Component
public class DocumentValidatorAr extends DocumentValidator {

    @Override
    public void validate(String documentType, String documentNumber) throws InvalidDocumentNumberException {
        if (!DocumentType.CUIT.equalsIgnoreCase(documentType)) {
            throw new InvalidDocumentNumberException(new BusinessError(BusinessError.INVALID_DOCUMENT_TYPE, "The document type is invalid"));
        }
        validateCuit(documentNumber);
    }

    private void validateCuit(String documentNumber) throws InvalidDocumentNumberException {
        if (!isZeroOrNaturalNumber(documentNumber) || documentNumber.length() != 11) {
            throw new InvalidDocumentNumberException(new BusinessError(BusinessError.INVALID_DOCUMENT, "Document number is mandatory and should be 11 digits long"));
        }

        if (!(documentNumber.startsWith("2") || documentNumber.startsWith("3"))) {
            throw new InvalidDocumentNumberException(new BusinessError(BusinessError.INVALID_DOCUMENT, "Document number is invalid"));
        }
    }

}