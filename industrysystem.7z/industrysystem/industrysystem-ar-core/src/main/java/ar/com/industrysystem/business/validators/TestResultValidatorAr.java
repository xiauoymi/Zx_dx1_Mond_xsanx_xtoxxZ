package ar.com.industrysystem.business.validators;

import ar.com.industrysystem.entities.WaybillAr;
import com.google.common.base.Predicate;
import com.industrysystem.business.ProductsService;
import com.industrysystem.business.validators.TestResultValidator;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.*;
import com.industrysystem.persistence.daos.LoadDetailDao;
import com.industrysystem.persistence.daos.WaybillDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.google.common.collect.FluentIterable.from;
import static org.apache.commons.lang.StringUtils.equalsIgnoreCase;
import static org.apache.commons.lang.StringUtils.isEmpty;
import static org.apache.commons.lang.StringUtils.isNotEmpty;

/**
 * User: JPNORV
 * Date: 20/01/14
 */
@Component
public class TestResultValidatorAr extends TestResultValidator {

    @Autowired
    private WaybillDao waybillDao;

    @Autowired
    private LoadDetailDao loadDetailDao;

    @Autowired
    private ProductsService productsService;

    TestResultValidatorAr() {
        errors = new ArrayList<BusinessError>();
    }

    public void validate(String holderDocument, String commercialSenderDocument, String destinationDocumentNumber,
            String sampleCode, String technology, String technologyPercent, String testType, String holderName,
            String commercialSenderName, String testDate, String qualitativeResult, String quantitativeResult)
            throws TestResultRegistrationException, StoreTestResultException, LoadDetailNotFoundException {
        super.errors = new ArrayList<BusinessError>();
        validateTestType(testType, qualitativeResult, quantitativeResult);
        Document destinationDocument = new Document(DocumentType.CUIT, destinationDocumentNumber);
        WaybillAr waybillAr = findWaybillByParameters(destinationDocument, sampleCode);
        if (waybillAr != null) {
            validateStatus(waybillAr);
            validateSampleCode(sampleCode, waybillAr);
            if (isValidTechnology(technology)) {
                super.validate(holderDocument, DocumentType.CUIT, commercialSenderDocument, DocumentType.CUIT);
                super.validateDocument(destinationDocumentNumber, DocumentType.CUIT, new BusinessError(
                        BusinessError.INVALID_DESTINATION_DOCUMENT, "The destination document is invalid"));
                validateName(holderDocument, holderName);
                validateName(commercialSenderDocument, commercialSenderName);
            }
        }
        validateTestDate(testDate);

        throwErrorsIfExists();
    }

    protected WaybillAr findWaybillByParameters(Document destinationDocument, String sampleCode) {
        WaybillAr waybillAr = null;
        LoadDetail loadDetail = null;
        try {
            loadDetail = findLoadDetailByDestinationDocument(destinationDocument, sampleCode);
            // TODO: use loadDetail.getWaybill() instead of the dao.
            waybillAr = (WaybillAr) waybillDao.findWaybillByWaybillNumber(loadDetail.getWaybill().getWaybillNumber());
        } catch (LoadDetailNotFoundException e) {
            errors.add(new FieldBusinessError(BusinessError.LOAD_DETAIL_NOT_FOUND, "error.load.detail.not.found", "loadDetail", null));
        } catch (WaybillNotFoundException e) {
            errors.add(new FieldBusinessError(BusinessError.WAYBILL_NOT_FOUND, "error.registered.waybill",
                    "waybillNumber", loadDetail.getWaybill().getWaybillNumber()));
        } catch (Exception e) {
            errors.add(new FieldBusinessError(BusinessError.WAYBILL_NOT_FOUND, "error.registered.waybill",
                    "waybillNumber", null));
        } finally {
            return waybillAr;
        }
    }

    protected void validateStatus(WaybillAr waybillAr) {
        if (!WaybillStatusEnum.WAITING_FOR_TEST_RESULTS.equals(waybillAr.getStatus())) {
            errors.add(new FieldBusinessError(BusinessError.WAYBILL_STATE_IS_INVALID, "error.invalid.waybill.state",
                    "waybillNumber", waybillAr.getWaybillNumber()));
        }
    }

    protected boolean isValidTechnology(String technology) {
        try {
            productsService.findByCode(technology);
            return true;
        } catch (TechnologyNotFoundException e) {
            return false;
        }
    }

    protected void validateSampleCode(final String sampleCode, WaybillAr waybillAr) {
        if (sampleCode == null) {
            return;
        }
        if (sampleCode.isEmpty()) {
            errors.add(new FieldBusinessError(BusinessError.SAMPLE_CODE_EMPTY, "error.invalid.sample.code", "sampleCode", sampleCode));
        } else {
            List<LoadDetail> loadDetails = loadDetailDao.findLoadDetailsByWaybill(waybillAr);
            validateIfSampleCodeIsInLoadDetails(sampleCode, loadDetails);
        }
    }

    /**
     * Adds an error if the sample code is not in the loadDetails list.
     * If  the sample code is in the loadDetails list it is ok and do not add error.
     */
    protected void validateIfSampleCodeIsInLoadDetails(final String sampleCode, List<LoadDetail> loadDetails) {
        Predicate<LoadDetail> withSampleCode = new Predicate<LoadDetail>() {
            @Override
            public boolean apply(LoadDetail loadDetail) {
                return loadDetail.getSampleCode().equalsIgnoreCase(sampleCode);
            }
        };

        if (from(new ArrayList(loadDetails)).filter(withSampleCode).isEmpty()) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_SAMPLE_CODE, "error.invalid.sample.code", "sampleCode", sampleCode));
        }
    }

    protected void validateQuantitativeResult(String technologyPercent) {
        if (isEmpty(technologyPercent) ||  Integer.valueOf(technologyPercent) < 0 || Integer.valueOf(technologyPercent) > 100) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_TECHNOLOGY_PERCENT, "error.invalid.technology.percent", "percent", technologyPercent));
        }
    }

    protected void validateTestType(String testType, String qualitativeResult, String quantitativeResult) {
        if (equalsIgnoreCase(CUALITATIVO, testType)) {
            validateQualitativeResult(testType, qualitativeResult);
        } else if (equalsIgnoreCase(CUANTITATIVO, testType)) {
            validateQuantitativeResult(quantitativeResult);
        } else {
            errors.add(new FieldBusinessError(BusinessError.INVALID_TYPE_OF_TEST, "error.invalid.type.test", "testType", testType));
        }
    }

    protected void validateQualitativeResult(String testType, String qualitativeResult) {
        if (isEmpty(qualitativeResult)) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_TYPE_OF_TEST, "error.invalid.type.test", "testType", testType));
        } else if (!equalsIgnoreCase(POSITIVO, qualitativeResult) && !equalsIgnoreCase(NEGATIVO, qualitativeResult)) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_TYPE_OF_TEST, "error.invalid.type.test", "testType", testType));
        }
    }

    protected LoadDetail findLoadDetailByDestinationDocument(Document destinationDocument, String sampleCode)
            throws LoadDetailNotFoundException, StoreTestResultException {
        try {
            return loadDetailDao.findLoadDetailsBySampleCodeAndWaybillDestinationDocument(sampleCode, destinationDocument);
        } catch (NoResultException ex) {
            throw new LoadDetailNotFoundException(destinationDocument.getNumber(), sampleCode);
        } catch (NonUniqueResultException ex) {
            // There is more than one Waybill’s Load Detail matching with the provided Destination document number and Sample code.
            throw new StoreTestResultException(new BusinessError(BusinessError.LOAD_DETAIL_NOT_UNIQUE, "Load detail identifier matched more than one load"));
        }
    }

    protected void validateName(String document, String name) {
        if (isNotEmpty(document) && isEmpty(name)) {
            errors.add(new FieldBusinessError(BusinessError.EMPTY_NAME, "Name must be declared", "name", name));
        }
    }

    protected void validateTestDate(String testDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        if (isEmpty(testDate) || testDate.trim().length() != dateFormat.toPattern().length()) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_TEST_DATE, "error.invalid.test.date", "testDate", testDate));
        } else {
            try {
                Date now = new Date();
                Date parsedTestDate = dateFormat.parse(testDate.trim());
                if (now.before(parsedTestDate)) {
                    errors.add(new FieldBusinessError(BusinessError.INVALID_TEST_DATE, "error.invalid.test.date", "testDate", testDate));
                }
            } catch (ParseException e) {
                errors.add(new FieldBusinessError(BusinessError.INVALID_TEST_DATE, "error.invalid.test.date", "testDate", testDate));
            }
        }
    }

}