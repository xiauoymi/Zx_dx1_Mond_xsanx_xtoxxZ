package ar.com.industrysystem.business.validators;

import ar.com.industrysystem.business.dtos.WaybillDtoAr;
import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.TruckDetailDTO;
import com.industrysystem.business.dtos.WagonDetailDTO;
import com.industrysystem.business.dtos.WaybillDto;
import com.industrysystem.business.validators.WaybillValidator;
import com.industrysystem.entities.TransportType;
import com.industrysystem.exceptions.*;
import com.industrysystem.persistence.daos.TruckDetailDao;
import com.industrysystem.persistence.daos.WaybillDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.Iterables.getFirst;
import static com.google.common.collect.Iterables.getOnlyElement;
import static com.industrysystem.entities.TransportType.fromCode;
import static org.apache.commons.lang.StringUtils.upperCase;

/**
 * User: JPNORV
 * Date: 29/11/13
 */
@Component
public class WaybillValidatorAr extends WaybillValidator {

    @Autowired
    private WaybillDao waybillDao;

    @Autowired
    protected TruckDetailDao truckDetailDao;

    public void validate(WaybillDtoAr waybillDto) throws WaybillRegistrationException, WaybillNotFoundException {
        super.errors = new ArrayList<BusinessError>();
        waybillValidFormatNumber(waybillDto);
        if (TransportType.TRANSPORTE_AUTOMOTOR == fromCode(waybillDto.getWaybillType())) {
            validateExistCtgNumber(waybillDto);
        }
        waybillRegisteredValidation(waybillDto);
        super.validate(waybillDto);
    }

    public void validateExistCtgNumber(WaybillDtoAr waybillDto) throws WaybillRegistrationException {
        try {
            TruckDetailDTO truckDetailDTO = (TruckDetailDTO)getOnlyElement(waybillDto.getLoadDetails());
            truckDetailDao.findTruckDetailById(upperCase(truckDetailDTO.getCtg()));
        } catch (LoadDetailAlreadyExistsException tdnfe) {
            throw new WaybillRegistrationException(tdnfe.getErrors());
        } catch (LoadDetailNotFoundException e) {
            //Do nothing: If CTG number is not found then it is OK
        }
    }

    public void validateBatchWaybill(WaybillDto waybillDto) throws WaybillRegistrationException, LaboratoryNotFoundException,
            LocationNotFoundException, WaybillNotFoundException {
        errors = new ArrayList<BusinessError>();
        List<LoadDetailDTO> loadDetailDTOs = waybillDto.getLoadDetails();
        TruckDetailDTO truckDetailDTO;
        WagonDetailDTO wagonDetailDTO;
        waybillValidFormatNumber(waybillDto);
        validateTransportType(waybillDto.getWaybillType());
        if (TransportType.TRANSPORTE_AUTOMOTOR == fromCode(waybillDto.getWaybillType())) {
            waybillRegisteredValidation(waybillDto);
            truckDetailDTO = (TruckDetailDTO)getOnlyElement(loadDetailDTOs);
            validateCtg(truckDetailDTO.getLoadIdentifier());
            validateWeight(String.valueOf(truckDetailDTO.getWeight()));
            validateDeclaretedTechnology(waybillDto, truckDetailDTO);
        } else if (TransportType.VAGON_FERROVIARIO == fromCode(waybillDto.getWaybillType())) {
            wagonDetailDTO = (WagonDetailDTO)getOnlyElement(loadDetailDTOs);
            validateWagonNumber(wagonDetailDTO.getLoadIdentifier(), waybillDto);
            validateWagonQty(wagonDetailDTO.getWagonsQty());
            validateWeight(String.valueOf(wagonDetailDTO.getWeight()));
            validateDeclaretedTechnology(waybillDto, wagonDetailDTO);
        }
        validateHolderName(waybillDto);
        validateDocument(waybillDto.getHolderDocument(), waybillDto.getHolderDocumentType(),
                new FieldBusinessError(BusinessError.INVALID_HOLDER_DOCUMENT, "error.invalid.holder.document.number", "holderDocument", waybillDto.getHolderDocument()));
        validateDocument(waybillDto.getAddresseeDocument(), waybillDto.getAddresseeDocumentType(),
                new FieldBusinessError(BusinessError.INVALID_ADDRESSEE_DOCUMENT, "error.invalid.addressee.document.number", "addresseeDocument", waybillDto.getAddresseeDocument()));
        validateDocument(waybillDto.getDestinationDocument(), waybillDto.getDestinationDocumentType(),
                new FieldBusinessError(BusinessError.INVALID_DESTINATION_DOCUMENT, "error.invalid.destination.document.number", "destinationDocument", waybillDto.getDestinationDocument()));
        if (waybillDto.hasDeclaredTechnology()) {
            validateCommercialSender(waybillDto);
        }
        validateCropCode(waybillDto.getCropCode());
        validateOriginLocation(waybillDto.getOriginLocation());
        validateDestinationLocation(waybillDto.getDestinationLocation());
        validateUnloadDate(waybillDto.getUnloadingDate());

        throwErrorsIfExists();
    }

    private void validateCommercialSender(WaybillDto waybillDto) {
        if (waybillDto.getCommercialSenderDocument() != null) {
            validateDocument(waybillDto.getCommercialSenderDocument(), waybillDto.getCommercialSenderDocumentType(),
                    new FieldBusinessError(BusinessError.INVALID_COMMERCIAL_SENDER_DOCUMENT, "error.invalid.commercial.sender.document.number", "commercialSenderDocument", waybillDto.getCommercialSenderDocument()));
            validateCommercialSenderName(waybillDto);
        }
    }

    public void validateManualWaybill(WaybillDto waybillDto) throws WaybillRegistrationException, LaboratoryNotFoundException,
            LocationNotFoundException, WaybillNotFoundException {
        errors = new ArrayList<BusinessError>();
        List<LoadDetailDTO> loadDetailDTOs = waybillDto.getLoadDetails();
        TruckDetailDTO truckDetailDTO;
        WagonDetailDTO wagonDetailDTO;
        waybillValidFormatNumber(waybillDto);
        waybillRegisteredValidation(waybillDto);
        validateTransportType(waybillDto.getWaybillType());
        if (TransportType.TRANSPORTE_AUTOMOTOR == fromCode(waybillDto.getWaybillType())) {
            truckDetailDTO = (TruckDetailDTO)getOnlyElement(loadDetailDTOs);
            validateCtg(truckDetailDTO.getLoadIdentifier());
        } else if (TransportType.VAGON_FERROVIARIO == fromCode(waybillDto.getWaybillType())) {
            wagonDetailDTO = (WagonDetailDTO)getFirst(loadDetailDTOs, null);
            validateWagonQty(wagonDetailDTO.getWagonsQty());
            validateWagonNumbers(waybillDto);
        }

        validateDocument(waybillDto.getHolderDocument(), waybillDto.getHolderDocumentType(),
                new FieldBusinessError(BusinessError.INVALID_HOLDER_DOCUMENT, "The holder document is invalid", "DOCUMENTO DEL TITULAR", waybillDto.getHolderDocument()));
        validateDocument(waybillDto.getCommercialSenderDocument(), waybillDto.getCommercialSenderDocumentType(),
                new FieldBusinessError(BusinessError.INVALID_COMMERCIAL_SENDER_DOCUMENT, "The commercial sender document is invalid", "DOCUMENTO DEL REPRESENTANTE COMERCIAL", waybillDto.getCommercialSenderDocument()));
        validateDocument(waybillDto.getAddresseeDocument(), waybillDto.getAddresseeDocumentType(),
                new FieldBusinessError(BusinessError.INVALID_ADDRESSEE_DOCUMENT, "The addressee document is invalid", "DOCUMENTO DEL DESTINO", waybillDto.getAddresseeDocument()));
        validateDocument(waybillDto.getDestinationDocument(), waybillDto.getDestinationDocumentType(),
                new FieldBusinessError(BusinessError.INVALID_DESTINATION_DOCUMENT, "The destination document is invalid", "DOCUMENTO DEL DESTINATARIO", waybillDto.getDestinationDocument()));

        validateCropCode(waybillDto.getCropCode());
        validateOriginLocation(waybillDto.getOriginLocation());
        validateDestinationLocation(waybillDto.getDestinationLocation());

        throwErrorsIfExists();
    }

    /**
     * Validates that the waybill number is numeric.
     *
     * @param waybillDto
     */
    public void waybillValidFormatNumber(WaybillDto waybillDto) {
        String waybillNumber = waybillDto.getWaybillNumber();
        if (!isWaybillNumber(waybillNumber)) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_WAYBILL_NUMBER, INVALID_WAYBILL_NUMBER, "waybillNumber", waybillNumber));
        }
    }

    /**
     * Validates that the waybill is new.
     *
     * @param waybillDto
     */
    public void waybillRegisteredValidation(WaybillDto waybillDto) {
        try {
            if (isWaybillNumber(waybillDto.getWaybillNumber())) {
                waybillDao.findWaybillByWaybillNumber(waybillDto.getWaybillNumberAsLong());
                errors.add(new FieldBusinessError(BusinessError.WAYBILL_NUMBER_IS_ALREADY_REGISTERED,
                        WAYBILL_NUMBER_IS_ALREADY_REGISTERED, "waybillNumber", waybillDto.getWaybillNumber()));
            }
        } catch (WaybillNotFoundException e) {
            //Do nothing. It has to continue with the other validations. If an Exception the waybillNumber is new.
        } catch (NumberFormatException e) {
            //Do nothing. It has to continue with the other validations.
        }
    }

}