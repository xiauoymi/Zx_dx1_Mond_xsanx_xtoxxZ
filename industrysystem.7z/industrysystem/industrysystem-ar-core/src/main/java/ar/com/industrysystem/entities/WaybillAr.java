package ar.com.industrysystem.entities;

import com.industrysystem.entities.DocumentType;
import com.industrysystem.entities.Waybill;

import javax.persistence.*;

/**
 * User: PPERA
 * Date: 11/09/13
 * Time: 15:45
 */
@NamedQueries({
    @NamedQuery(name = "WaybillAr.findByWaybillNumber", query = "Select wb from WaybillAr wb where wb.waybillNumber = :waybillNumber"),
    @NamedQuery(name = "Waybill.findWaybillByGrowerAndCampaign",
                            query = "select waybill from WaybillAr waybill where waybill.holderDocument.number = :holderDocument and waybill.campaign = :campaign order by waybill.id asc")
})
@Entity
@Table(name = "WAYBILL_AR")
@PrimaryKeyJoinColumn(name = "ID")
public class WaybillAr extends Waybill {

    @ManyToOne
    @JoinColumn(name = "INTERMEDIARY_DOC_TYPE_ID")
    private DocumentType intermediaryDocumentType;

    @Column(name = "PLANT_CODE")
    private String plantCode;

    @Column(name = "WAYBILL_NUMBER")
    private Long waybillNumber;

    public String getPlantCode() {
        return plantCode;
    }

    public void setPlantCode(String plantCode) {
        this.plantCode = plantCode;
    }

    public DocumentType getIntermediaryDocumentType() {
        return intermediaryDocumentType;
    }

    public void setIntermediaryDocumentType(DocumentType intermediaryDocumentType) {
        this.intermediaryDocumentType = intermediaryDocumentType;
    }

    public Long getWaybillNumber() {
        return waybillNumber;
    }

    public void setWaybillNumber(Long waybillNumber) {
        this.waybillNumber = waybillNumber;
    }

}