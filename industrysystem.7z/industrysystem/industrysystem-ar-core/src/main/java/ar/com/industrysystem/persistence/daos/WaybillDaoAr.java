package ar.com.industrysystem.persistence.daos;

import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.entities.Campaign;
import com.industrysystem.entities.Grower;
import com.industrysystem.entities.Waybill;
import com.industrysystem.exceptions.WaybillNotFoundException;
import com.industrysystem.persistence.daos.WaybillDao;
import org.springframework.stereotype.Repository;

import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import java.util.List;

@Repository
public class WaybillDaoAr extends WaybillDao {

	public static final String WAYBILL_AR_FIND_BY_WAYBILL_NUMBER = "WaybillAr.findByWaybillNumber";

    protected TypedQuery<WaybillAr> query;

	@Override
	public Waybill findWaybillByWaybillNumber(Long waybillNumber) throws WaybillNotFoundException {
		try {
          query = this.em.createNamedQuery(WAYBILL_AR_FIND_BY_WAYBILL_NUMBER, WaybillAr.class);
          query.setParameter("waybillNumber", waybillNumber);
          return query.getSingleResult();
      } catch (NoResultException ex) {
          throw new WaybillNotFoundException(waybillNumber);
      }
	}

    public List<Waybill> findBy(Grower grower, Campaign campaign) {

        Query query = this.em.createNamedQuery(FIND_BY_NON_POD_PARTICIPANT_GROWER, WaybillAr.class);

        query.setParameter("holderDocument", grower.getDocument().getNumber());
        query.setParameter("campaign", campaign);

        return query.getResultList();
    }

}