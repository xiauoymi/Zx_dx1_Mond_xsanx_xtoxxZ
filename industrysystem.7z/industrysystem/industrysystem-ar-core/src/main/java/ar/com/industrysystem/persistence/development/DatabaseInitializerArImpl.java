package ar.com.industrysystem.persistence.development;

import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.entities.*;
import com.industrysystem.persistence.development.DatabaseInitializer;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import java.util.Date;

/**
 * User: PPERA
 * Date: 11/12/13
 * Time: 09:27
 */
@Component
public class DatabaseInitializerArImpl extends DatabaseInitializer {

    @Override
    protected void internalOnQApplicationEvent(Location location, Campaign campaign2013, Crop soja, DocumentType cuit, CropTechnology intactaSoja, TraitOwner monsanto, CropTechnologyForCampaign intactaSoja2013, EntityManager em) {
        // FS014-01
        WaybillAr waybill_014_01 = new WaybillAr();
        waybill_014_01.setWaybillNumber(14010123456789L);
        waybill_014_01.setCreationDate(new Date());
        waybill_014_01.setGoodsSourceCity(location);
        waybill_014_01.setGoodsDestinationCity(location);
        waybill_014_01.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        waybill_014_01.setCampaign(campaign2013);
        waybill_014_01.setCrop(soja);
        waybill_014_01.setHolderDocument(new Document(cuit, "1"));
        waybill_014_01.setHolderDeclaredIsPod(false);
        waybill_014_01.setCommercialSenderDocument(new Document(cuit, "1001"));
        waybill_014_01.setPlantCode("ESTANCIA MARIA");
        TruckLoadDetail loadDetail_014_01 = new TruckLoadDetail();
        loadDetail_014_01.setCtg("10000001");
        loadDetail_014_01.setWaybill(waybill_014_01);
        loadDetail_014_01.setWeight(150);
        Declaration declaration_014_01 = new Declaration();
        declaration_014_01.setLoadDetail(loadDetail_014_01);
        declaration_014_01.setCropTechnology(intactaSoja);
        TraitOwnerMessage traitOwnerMessage_014_01 = new TraitOwnerMessage();
        traitOwnerMessage_014_01.setTraitOwner(monsanto);
        traitOwnerMessage_014_01.setMessageSequence(30L);
        WaybillMessage waybillMessage_014_01 = new WaybillMessage();
        waybillMessage_014_01.setWaybill(waybill_014_01);
        waybillMessage_014_01.setTraitOwnerMessage(traitOwnerMessage_014_01);
        em.persist(waybill_014_01);
        em.persist(loadDetail_014_01);
        em.persist(declaration_014_01);
        em.persist(traitOwnerMessage_014_01);
        em.persist(waybillMessage_014_01);

        // FS014-02
        WaybillAr waybill_014_02 = new WaybillAr();
        waybill_014_02.setWaybillNumber(14020123456789L);
        waybill_014_02.setCreationDate(new Date());
        waybill_014_02.setGoodsSourceCity(location);
        waybill_014_02.setGoodsDestinationCity(location);
        waybill_014_02.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        waybill_014_02.setCampaign(campaign2013);
        waybill_014_02.setCrop(soja);
        waybill_014_02.setHolderDocument(new Document(cuit, "1"));
        waybill_014_02.setHolderDeclaredIsPod(true);
        waybill_014_02.setCommercialSenderDocument(new Document(cuit, "2001"));
        waybill_014_02.setPlantCode("ESTANCIA JOSEFA");
        Laboratory laboratory_014_02 = new Laboratory();
        laboratory_014_02.setCode("1402");
        laboratory_014_02.setCanPerformCuantitativeTests(true);
        TruckLoadDetail loadDetail_014_02 = new TruckLoadDetail();
        loadDetail_014_02.setCtg("10000002");
        loadDetail_014_02.setWaybill(waybill_014_02);
        loadDetail_014_02.setLaboratory(laboratory_014_02);
        loadDetail_014_02.setWeight(300);
        loadDetail_014_02.setSampleCode("sample1");
        QualitativeTestRequest qualitativeTestRequest_014_02 = new QualitativeTestRequest();
        qualitativeTestRequest_014_02.setLoadDetail(loadDetail_014_02);
        qualitativeTestRequest_014_02.setCropTechnologyForCampaign(intactaSoja2013);
        em.persist(waybill_014_02);
        em.persist(laboratory_014_02);
        em.persist(loadDetail_014_02);
        em.persist(qualitativeTestRequest_014_02);

        // FS014-03
        WaybillAr waybill_014_03 = new WaybillAr();
        waybill_014_03.setHolderDeclaredIsPod(false);
        waybill_014_03.setWaybillNumber(1232323L);
        waybill_014_03.setCreationDate(new Date());
        waybill_014_03.setGoodsSourceCity(location);
        waybill_014_03.setGoodsDestinationCity(location);
        waybill_014_03.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        waybill_014_03.setCampaign(campaign2013);
        waybill_014_03.setCrop(soja);
        waybill_014_03.setHolderDocument(new Document(cuit, "1"));
        waybill_014_03.setHolderDeclaredIsPod(true);
        WagonLoadDetail loadDetail_014_03 = new WagonLoadDetail();
        loadDetail_014_03.setWagonNumber("10000003");
        loadDetail_014_03.setWaybill(waybill_014_03);
        loadDetail_014_03.setLaboratory(laboratory_014_02);
        loadDetail_014_03.setWeight(500);
        loadDetail_014_03.setSampleCode("sample2");
        CuantitativeTestRequest cuantitativeTestRequest_014_03 = new CuantitativeTestRequest();
        cuantitativeTestRequest_014_03.setLoadDetail(loadDetail_014_03);
        em.persist(waybill_014_03);
        em.persist(loadDetail_014_03);
        em.persist(cuantitativeTestRequest_014_03);
    }

    @Override
    protected Waybill newWaybill(Long waybillIdentifier) {
        WaybillAr waybillAr = new WaybillAr();
        waybillAr.setWaybillNumber(waybillIdentifier);
        waybillAr.setHolderDeclaredIsPod(false);
        return waybillAr;
    }

}