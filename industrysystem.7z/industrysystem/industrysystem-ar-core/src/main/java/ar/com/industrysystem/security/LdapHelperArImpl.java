package ar.com.industrysystem.security;

import ar.com.industrysystem.security.mappers.ISUserAttributesMapperArImpl;
import com.industrysystem.security.LdapHelper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.stereotype.Component;

/**
 * User: PPERA
 * Date: 1/7/14
 * Time: 7:13 PM
 */
@Component
public class LdapHelperArImpl extends LdapHelper {
    @Value("${ldap.root.ar}")
    private String ldapRoot;

    public String getLdapRoot() {
        return ldapRoot;
    }

    @Override
    protected AttributesMapper newISUserAttributesMapper() {
        return new ISUserAttributesMapperArImpl();
    }
}
