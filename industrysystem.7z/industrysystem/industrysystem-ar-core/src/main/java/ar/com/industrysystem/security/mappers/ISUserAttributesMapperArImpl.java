package ar.com.industrysystem.security.mappers;

import com.industrysystem.security.mappers.ISUserAttributesMapper;
import org.springframework.beans.factory.annotation.Value;

/**
 * User: PPERA
 * Date: 1/7/14
 * Time: 7:20 PM
 */
public class ISUserAttributesMapperArImpl extends ISUserAttributesMapper {
    @Value("${ldap.root.ar}")
    private String ldapRoot;

    public String getLdapRoot() {
        return ldapRoot;
    }
}
