package ar.com.industrysystem.business;

import ar.com.industrysystem.business.dtos.WaybillDtoAr;
import ar.com.industrysystem.business.mappers.WaybillMapperAr;

import ar.com.industrysystem.business.validators.WaybillValidatorAr;
import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.business.*;
import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.TruckDetailDTO;
import com.industrysystem.business.dtos.WaybillDto;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.*;
import com.industrysystem.persistence.daos.*;
import com.industrysystem.utils.Sundial;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.text.SimpleDateFormat;
import java.util.*;

import static com.google.common.collect.Iterables.getOnlyElement;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class WaybillServiceArImpl_UT {

    private static final Long WAYBILL_NUMBER = 123L;

    private CropDao cropDao;
    @Mock
    private Sundial sundial;
    @Mock
    private WaybillDao waybillDao;
    @Mock
    private EventService eventService;
    @Mock
    private WaybillMapperAr waybillMapperAr;
    @Mock
    private WaybillValidatorAr waybillValidator;
    @Mock
    WaybillServiceImpl waybillService;
    @Mock
    private PodDao podDao;
    @Mock
    private TestsService testsService;

    @InjectMocks
    private WaybillServiceArImpl waybillServiceAr;

    @Test
    public void registerWaybill_ThrowsWaybillRegistrationException_when_waybillValidatorThrowsException() throws Exception {
        WaybillDtoAr dto = new WaybillDtoAr();
        doThrow(WaybillNotFoundException.class).when(this.waybillValidator).validate(dto);
        try {
            waybillServiceAr.registerWaybill(dto);
            fail();
        } catch (WaybillRegistrationException e) {
            // ok.
        }
    }

    @Test
    public void registerWaybill_ThrowWaybillRegistrationException_when_waybillMapperArThrowException() throws Exception {
        WaybillDtoAr dto = new WaybillDtoAr();
        doThrow(WaybillRegistrationException.class).when(this.waybillMapperAr).map(dto);
        try {
            waybillServiceAr.registerWaybill(dto);
            fail();
        } catch (WaybillRegistrationException e) {
            // ok.
        }
    }

    @Test
    public void registerWaybill_SavesTheCorrespondingWaybill_WhenCallingItWithAWaybillDto() throws Exception {
        WaybillAr waybill = new WaybillAr();
        WaybillDtoAr dto = new WaybillDtoAr();
        when(this.waybillMapperAr.map(any(WaybillDtoAr.class))).thenReturn(waybill);

        this.waybillServiceAr.registerWaybill(dto);

        assertEquals("The waybill state is not correct.", WaybillStatusEnum.RECEIVED, waybill.getStatus());
        verify(waybillDao).save(eq(waybill));
        verify(eventService).saveWaybillReceivedEvent(eq(waybill));
    }

    @Test
    public void waybillManualRegistration_ThrowsException_WhenWaybillValidatorThrowsException() throws Exception {
    	WaybillDtoAr waybillDto = new WaybillDtoAr();
        waybillDto.setAddresseeDocument("123");
        waybillDto.setHolderDocument("456");
        doThrow(WaybillNotFoundException.class).when(waybillValidator).validateManualWaybill(any(WaybillDto.class));
        try {
            this.waybillServiceAr.waybillManualRegistration(waybillDto);
            fail();
        } catch (WaybillNotFoundException ex) {
            // ok.
        }
    }

    @Test
    public void waybillManualRegistration_ThrowsException_WhenWaybillValidatorThrowsException2() throws Exception {
    	WaybillDtoAr waybillDto = new WaybillDtoAr();
        waybillDto.setWaybillNumber(WAYBILL_NUMBER.toString());
        waybillDto.setAddresseeDocument("123");
        waybillDto.setHolderDocument("456");

        WaybillAr waybill = new WaybillAr();
        waybill.setWaybillNumber(WAYBILL_NUMBER);
        when(waybillMapperAr.map(any(WaybillDtoAr.class))).thenReturn(waybill);

        waybillServiceAr.waybillManualRegistration(waybillDto);

        // register waybill
        assertEquals("The waybill state is not correct.", WaybillStatusEnum.RECEIVED, waybill.getStatus());
        verify(waybillDao).save(eq(waybill));
        verify(eventService).saveWaybillReceivedEvent(eq(waybill));
        verify(waybillService).storeWeightAndSampleInfo(eq(WAYBILL_NUMBER), eq(waybillDto.getQuantitativeLabCode()),
                eq(waybillDto.getQuantitativeLabCode()), eq(waybillDto.getLoadDetails()));
    }

    @Test
    public void registerFullWaybill_ThrowWaybillRegistrationException_when_waybillMapperArThrowException() throws Exception {
        WaybillDtoAr waybillDto = createWaybillDtoWithTruckDetailDto();

        doThrow(WaybillRegistrationException.class).when(this.waybillMapperAr).map(waybillDto);
        try {
            waybillServiceAr.registerFullWaybill(waybillDto);
            fail();
        } catch (WaybillRegistrationException e) {
            // ok.
        }
    }

    @Test
    public void registerFullWaybill_ok_when_waybillWithTruckDetail() throws Exception {
        WaybillDtoAr waybillDto = createWaybillDtoWithTruckDetailDto();

        WaybillAr waybill = mock(WaybillAr.class);
        when(waybill.isSampleRequired()).thenReturn(false);

        when(waybillMapperAr.map(waybillDto)).thenReturn(waybill);

        String dateStr = "01/01/2014";
        waybillDto.setUnloadingDate(dateStr);

        when(waybillDao.findWaybillByWaybillNumber(any(Long.class))).thenReturn(waybill);

        waybillServiceAr.registerFullWaybill(waybillDto);

        verify(waybill).setInitialState(WaybillStatusEnum.RECEIVED);
        verify(waybillDao).save(waybill);
        verify(eventService).saveWaybillReceivedEvent(waybill);

        LoadDetailDTO loadDetailDto = getOnlyElement(waybillDto.getLoadDetails());
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date unloadingDate = dateFormat.parse(dateStr);
        verify(waybillService).storeWeight(WAYBILL_NUMBER, loadDetailDto.getWeight(), loadDetailDto.getLoadIdentifier(), unloadingDate);

        verify(testsService).shouldWaybillTakeSample(any(Sample.class));
    }

    private WaybillDtoAr createWaybillDtoWithTruckDetailDto() {
        WaybillDtoAr waybillDto = new WaybillDtoAr();
        LoadDetailDTO loadDetailDto = new TruckDetailDTO();
        List<LoadDetailDTO> loadDetailDTOList = new ArrayList<LoadDetailDTO>();
        loadDetailDTOList.add(loadDetailDto);
        waybillDto.setWaybillNumber(WAYBILL_NUMBER.toString());
        waybillDto.setLoadDetails(loadDetailDTOList);
        waybillDto.setWaybillType(TransportType.TRANSPORTE_AUTOMOTOR.getDescriptionCode());
        return waybillDto;
    }

}