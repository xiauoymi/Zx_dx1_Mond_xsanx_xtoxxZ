package ar.com.industrysystem.business.dtos;

import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.entities.DocumentType;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.*;

/**
 * User: JPNORV
 * Date: 16/12/13
 */
public class WaybillDtoAr_UT {

    @Test
    public void testEmptyWhenCreated() {
        WaybillDtoAr dto = new WaybillDtoAr();

        assertTrue(dto.getWaybillNumber() == null);
        assertFalse(dto.isHolderDeclaredAsPod());
    }

    @Test
    public void testGettersAndSetters() {
        WaybillDtoAr dto = new WaybillDtoAr();
        dto.setOriginEstablishment("A");
        assertEquals("A", dto.getOriginEstablishment());
    }

    @Test
    public void testIsHolderDeclaredAsPodGivenNumericOriginEstablishmentWhenIsPod_ThenIsTrue() {
        WaybillDtoAr dto = new WaybillDtoAr();
        dto.setOriginEstablishment("168161886");

        assertTrue(dto.isHolderDeclaredAsPod());
    }

    @Test
    public void testIsHolderDeclaredAsPodGivenNullOriginEstablishmentWhenIsPod_ThenIsFalse() {
        WaybillDtoAr dto = new WaybillDtoAr();
        dto.setOriginEstablishment(null);

        assertFalse(dto.isHolderDeclaredAsPod());
    }

    @Test
    public void testIsHolderDeclaredAsPodGivenEmptyOriginEstablishmentWhenIsPod_ThenIsFalse() {
        WaybillDtoAr dto = new WaybillDtoAr();
        dto.setOriginEstablishment("");

        assertFalse(dto.isHolderDeclaredAsPod());
    }

    @Test
    public void testIsHolderDeclaredAsPodGivenBlankOriginEstablishmentWhenIsPod_ThenIsFalse() {
        WaybillDtoAr dto = new WaybillDtoAr();
        dto.setOriginEstablishment(" ");

        assertFalse(dto.isHolderDeclaredAsPod());
    }

    @Test
    public void testIsHolderDeclaredAsPodGivenAlphaNumericOriginEstablishmentWhenIsPod_ThenIsFalse() {
        WaybillDtoAr dto = new WaybillDtoAr();
        dto.setOriginEstablishment("1d");

        assertFalse(dto.isHolderDeclaredAsPod());
    }

    @Test
    public void testGetDestinationDocumentType_returnsCorrectValue_whenCalled() {
        WaybillDtoAr dto = new WaybillDtoAr();
        String result = dto.getDestinationDocumentType();
        assertThat(DocumentType.CUIT).isEqualTo(result);
    }

    @Test
    public void testGetAddresseeDocumentType_returnsCorrectValue_whenCalled() {
        WaybillDtoAr dto = new WaybillDtoAr();
        String result = dto.getAddresseeDocumentType();
        assertThat(DocumentType.CUIT).isEqualTo(result);
    }

    @Test
    public void testGetHolderDocumentType_returnsCorrectValue_whenCalled() {
        WaybillDtoAr dto = new WaybillDtoAr();
        String result = dto.getHolderDocumentType();
        assertThat(DocumentType.CUIT).isEqualTo(result);
    }

    @Test
    public void testGetCommercialSenderDocumentType_returnsCorrectValue_whenCalled() {
        WaybillDtoAr dto = new WaybillDtoAr();
        String result = dto.getCommercialSenderDocumentType();
        assertThat(DocumentType.CUIT).isEqualTo(result);
    }

}