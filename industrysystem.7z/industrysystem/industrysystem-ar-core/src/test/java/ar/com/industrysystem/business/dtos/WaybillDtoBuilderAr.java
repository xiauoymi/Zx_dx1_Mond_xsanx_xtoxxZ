package ar.com.industrysystem.business.dtos;

import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.TruckDetailDTO;
import com.industrysystem.business.dtos.WagonDetailDTO;
import com.industrysystem.entities.TransportType;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 23/01/14
 * Time: 14:14
 */
public class WaybillDtoBuilderAr {

    public static final String WAYBILL_NUMBER = "123456";
    public static final long ORIGIN_LOCATION = 3L;
    public static final long DESTINATION_LOCATION = 3L;
    public static final String HOLDER_DOCUMENT = "27500858628";
    public static final String ADDRESSEE_DOCUMENT = "27500858628";
    public static final String DESTINATION_DOCUMENT = "27500858628";
    public static final String ORIGIN_ESTABLISHMENT = "1";
    public static final String COMMERCIAL_SENDER_DOCUMENT = "27500858628";
    public static final String CROP_CODE = "SOJA";
    public static final String TRUCK_WAYBILL_TYPE = TransportType.TRANSPORTE_AUTOMOTOR.getDescriptionCode();
    public static final String TRAIN_WAYBILL_TYPE = TransportType.VAGON_FERROVIARIO.getDescriptionCode();
    public static final String COMERCIAL_SENDER_NAME = "Grower";
    public static final String HOLDER_NAME = "Grower";
    public static final Long DESTINATION_COMERCIAL_CODE = 1L;
    public static final String QUALITATIVE_LAB_CODE = "162";
    public static final String QUANTITATIVE_LAB_CODE = "164";
    public static final String DECLARED_TECHNOLOGY = "INTACTA";
    public static final String LOAD_IDENTIFIER = "123A";
    public static final Integer WEIGHT = 45;
    public static final String  SAMPLE_CODE = "123B";

    public WaybillDtoAr FactoryTruckTypeWaybillWithTechnologyDeclared(){
        WaybillDtoAr dto = FactoryTruckWaybillDtoAr();
        List<LoadDetailDTO> loadDetailDTOs = FactoryTruckDetailDTOWithDeclaration();
        dto.setLoadDetails(loadDetailDTOs);

        return dto;
    }

    public WaybillDtoAr FactoryTruckTypeWaybillWithNoTechnologyDeclared(){
        WaybillDtoAr dto = FactoryTruckWaybillDtoAr();
        List<LoadDetailDTO> loadDetailDTOs = FactoryTruckDetailDTOWithNoDeclaration();
        dto.setLoadDetails(loadDetailDTOs);

        return dto;
    }

    public WaybillDtoAr FactoryTrainTypeWaybillWithTechnologyDeclared(){
        WaybillDtoAr dto = FactoryTrainWaybillDtoAr();
        List<LoadDetailDTO> loadDetailDTOs = FactoryTrainDetailDTOWithAllWagonWithDeclaration();
        dto.setLoadDetails(loadDetailDTOs);

        return dto;
    }

    public WaybillDtoAr FactoryTrainTypeWaybillWithNoTechnologyDeclared(){
        WaybillDtoAr dto = FactoryTrainWaybillDtoAr();
        List<LoadDetailDTO> loadDetailDTOs = FactoryTrainDetailDTOWithNoWagonWithDeclaration();
        dto.setLoadDetails(loadDetailDTOs);

        return dto;
    }

    public WaybillDtoAr FactoryTrainTypeWaybillWithSomeTechnologyDeclared(){
        WaybillDtoAr dto = FactoryTrainWaybillDtoAr();
        List<LoadDetailDTO> loadDetailDTOs = FactoryTrainDetailDTOWithSomeWagonWithDeclaration();
        dto.setLoadDetails(loadDetailDTOs);

        return dto;
    }

    public WaybillDtoAr FactoryTruckWaybillDtoAr() {
        WaybillDtoAr dto = new WaybillDtoAr();
        dto.setWaybillNumber(WAYBILL_NUMBER);
        dto.setOriginLocation(ORIGIN_LOCATION);
        dto.setDestinationLocation(DESTINATION_LOCATION);
        dto.setWaybillType(TRUCK_WAYBILL_TYPE);
        dto.setHolderDocument(HOLDER_DOCUMENT);
        dto.setAddresseeDocument(ADDRESSEE_DOCUMENT);
        dto.setDestinationDocument(DESTINATION_DOCUMENT);
        dto.setOriginEstablishment(ORIGIN_ESTABLISHMENT);
        dto.setCommercialSenderDocument(COMMERCIAL_SENDER_DOCUMENT);
        dto.setCropCode(CROP_CODE);
        dto.setCommercialSenderName(COMERCIAL_SENDER_NAME);
        dto.setHolderName(HOLDER_NAME);
        dto.setDestinationCommercialCode(DESTINATION_COMERCIAL_CODE);
        dto.setQualitativeLabCode(QUALITATIVE_LAB_CODE);
        dto.setQuantitativeLabCode(QUANTITATIVE_LAB_CODE);
        return dto;
    }

    public WaybillDtoAr FactoryTrainWaybillDtoAr() {
        WaybillDtoAr dto = new WaybillDtoAr();
        dto.setWaybillNumber(WAYBILL_NUMBER);
        dto.setOriginLocation(ORIGIN_LOCATION);
        dto.setDestinationLocation(DESTINATION_LOCATION);
        dto.setWaybillType(TRAIN_WAYBILL_TYPE);
        dto.setHolderDocument(HOLDER_DOCUMENT);
        dto.setAddresseeDocument(ADDRESSEE_DOCUMENT);
        dto.setDestinationDocument(DESTINATION_DOCUMENT);
        dto.setOriginEstablishment(ORIGIN_ESTABLISHMENT);
        dto.setCommercialSenderDocument(COMMERCIAL_SENDER_DOCUMENT);
        dto.setCropCode(CROP_CODE);
        dto.setCommercialSenderName(COMERCIAL_SENDER_NAME);
        dto.setHolderName(HOLDER_NAME);
        dto.setDestinationCommercialCode(DESTINATION_COMERCIAL_CODE);
        dto.setQualitativeLabCode(QUALITATIVE_LAB_CODE);
        dto.setQuantitativeLabCode(QUANTITATIVE_LAB_CODE);
        return dto;
    }

    public List<LoadDetailDTO> FactoryTruckDetailDTOWithDeclaration() {
        TruckDetailDTO truckDetailDTO = new TruckDetailDTO();
        truckDetailDTO.setDeclaredTechnology(DECLARED_TECHNOLOGY);
        truckDetailDTO.setCtg(LOAD_IDENTIFIER);
        truckDetailDTO.setLoadIdentifier(LOAD_IDENTIFIER);
        truckDetailDTO.setWeight(WEIGHT);
        truckDetailDTO.setSampleCode(SAMPLE_CODE);
        List<LoadDetailDTO> loadDetailDTOs = new ArrayList<LoadDetailDTO>();
        loadDetailDTOs.add(truckDetailDTO);
        return loadDetailDTOs;
    }

    public List<LoadDetailDTO> FactoryTruckDetailDTOWithNoDeclaration() {
        TruckDetailDTO truckDetailDTO = new TruckDetailDTO();
        truckDetailDTO.setDeclaredTechnology(null);
        truckDetailDTO.setCtg(LOAD_IDENTIFIER);
        List<LoadDetailDTO> loadDetailDTOs = new ArrayList<LoadDetailDTO>();
        loadDetailDTOs.add(truckDetailDTO);
        return loadDetailDTOs;
    }

    public List<LoadDetailDTO> FactoryTrainDetailDTOWithAllWagonWithDeclaration() {
        WagonDetailDTO wagonDetailDTO = new WagonDetailDTO();
        wagonDetailDTO.setDeclaredTechnology(DECLARED_TECHNOLOGY);
        wagonDetailDTO.setWagonNumber(LOAD_IDENTIFIER);
        wagonDetailDTO.setWeight(WEIGHT);
        wagonDetailDTO.setSampleCode(SAMPLE_CODE);
        wagonDetailDTO.setWagonsQty("2");

        WagonDetailDTO secondWagonDetailDTO = new WagonDetailDTO();
        secondWagonDetailDTO.setDeclaredTechnology(DECLARED_TECHNOLOGY);
        secondWagonDetailDTO.setWagonNumber("456C");
        secondWagonDetailDTO.setWeight(WEIGHT);
        secondWagonDetailDTO.setSampleCode("456D");
        secondWagonDetailDTO.setWagonsQty("2");

        List<LoadDetailDTO> loadDetailDTOs = new ArrayList<LoadDetailDTO>();
        loadDetailDTOs.add(wagonDetailDTO);
        loadDetailDTOs.add(secondWagonDetailDTO);
        return loadDetailDTOs;
    }

    public List<LoadDetailDTO> FactoryTrainDetailDTOWithNoWagonWithDeclaration() {
        WagonDetailDTO wagonDetailDTO = new WagonDetailDTO();
        wagonDetailDTO.setWagonNumber(LOAD_IDENTIFIER);
        wagonDetailDTO.setWeight(WEIGHT);
        wagonDetailDTO.setSampleCode(SAMPLE_CODE);
        wagonDetailDTO.setWagonsQty("2");

        WagonDetailDTO secondWagonDetailDTO = new WagonDetailDTO();
        secondWagonDetailDTO.setWagonNumber("456C");
        secondWagonDetailDTO.setWeight(WEIGHT);
        secondWagonDetailDTO.setSampleCode("456D");
        secondWagonDetailDTO.setWagonsQty("2");

        List<LoadDetailDTO> loadDetailDTOs = new ArrayList<LoadDetailDTO>();
        loadDetailDTOs.add(wagonDetailDTO);
        loadDetailDTOs.add(secondWagonDetailDTO);
        return loadDetailDTOs;
    }

    public List<LoadDetailDTO> FactoryTrainDetailDTOWithSomeWagonWithDeclaration() {
        WagonDetailDTO wagonDetailDTO = new WagonDetailDTO();
        wagonDetailDTO.setDeclaredTechnology(DECLARED_TECHNOLOGY);
        wagonDetailDTO.setWagonNumber(LOAD_IDENTIFIER);
        wagonDetailDTO.setWeight(WEIGHT);
        wagonDetailDTO.setSampleCode(SAMPLE_CODE);
        wagonDetailDTO.setWagonsQty("2");

        WagonDetailDTO secondWagonDetailDTO = new WagonDetailDTO();
        secondWagonDetailDTO.setWagonNumber("456C");
        secondWagonDetailDTO.setWeight(WEIGHT);
        secondWagonDetailDTO.setSampleCode("456D");
        secondWagonDetailDTO.setWagonsQty("2");

        List<LoadDetailDTO> loadDetailDTOs = new ArrayList<LoadDetailDTO>();
        loadDetailDTOs.add(wagonDetailDTO);
        loadDetailDTOs.add(secondWagonDetailDTO);
        return loadDetailDTOs;
    }

}