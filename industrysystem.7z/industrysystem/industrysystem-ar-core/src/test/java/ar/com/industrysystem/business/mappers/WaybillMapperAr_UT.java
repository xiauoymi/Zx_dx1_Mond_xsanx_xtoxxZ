package ar.com.industrysystem.business.mappers;

import ar.com.industrysystem.business.dtos.WaybillDtoAr;
import ar.com.industrysystem.business.dtos.WaybillDtoBuilderAr;
import ar.com.industrysystem.business.validators.DocumentValidatorAr;
import ar.com.industrysystem.business.validators.WaybillValidatorAr;
import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.business.mappers.DocumentMapper;
import com.industrysystem.business.mappers.PodMapper;
import com.industrysystem.business.validators.DocumentValidator;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.CampaignNotFoundException;
import com.industrysystem.exceptions.LocationNotFoundException;
import com.industrysystem.exceptions.PodNotFoundException;
import com.industrysystem.exceptions.WaybillRegistrationException;
import com.industrysystem.persistence.daos.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 22/01/14
 * Time: 16:17
 */
public class WaybillMapperAr_UT {

    private WaybillMapperAr waybillMapperAr;
    private CropDao cropDao;
    private WaybillDao waybillDao;
    private CampaignDao campaignDao;
    private DocumentTypeDao documentTypeDao;
    private PodDao podDao;
    private TruckDetailDao truckDetailDao;
    private LocationDao locationDao;
    private CropTechnologyDao cropTechnologyDao;
    private WaybillValidatorAr waybillValidator;

    @Before
    public void setUp() {
        waybillDao = mock(WaybillDao.class);
        campaignDao = mock(CampaignDao.class);
        cropDao = mock(CropDao.class);
        documentTypeDao = mock(DocumentTypeDao.class);
        podDao = mock(PodDao.class);
        truckDetailDao = mock(TruckDetailDao.class);
        locationDao = mock(LocationDao.class);
        cropTechnologyDao= mock(CropTechnologyDao.class);
        waybillValidator = new WaybillValidatorAr();
        field("waybillDao").ofType(WaybillDao.class).in(waybillValidator).set(waybillDao);
        field("documentValidator").ofType(DocumentValidator.class).in(waybillValidator).set(new DocumentValidatorAr());

        waybillMapperAr = new WaybillMapperAr();
        field("cropDao").ofType(CropDao.class).in(waybillMapperAr).set(cropDao);
        field("campaignDao").ofType(CampaignDao.class).in(waybillMapperAr).set(campaignDao);

        DocumentMapper documentMapper=new DocumentMapper();
        field("documentMapper").ofType(DocumentMapper.class).in(waybillMapperAr).set(documentMapper);
        field("documentTypeDao").ofType(DocumentTypeDao.class).in(documentMapper).set(documentTypeDao);
        field("truckDetailDao").ofType(TruckDetailDao.class).in(waybillValidator).set(truckDetailDao);
        field("locationDao").ofType(LocationDao.class).in(waybillMapperAr).set(locationDao);
        field("cropTechnologyDao").ofType(CropTechnologyDao.class).in(waybillMapperAr).set(cropTechnologyDao);

        PodMapper podMapper=new PodMapper();
        field("podDao").ofType(PodDao.class).in(podMapper).set(podDao);
        field("podMapper").ofType(PodMapper.class).in(waybillMapperAr).set(podMapper);
        field("podDao").ofType(PodDao.class).in(waybillMapperAr).set(podDao);
    }

    @Test
    public void testGivenAWaybillDtoArWithTruckTypeAndTechnologyDeclarationNoParticipantHolderPod_ThenHolderAndCommercialSenderAreMappedToThWaybill()
            throws CampaignNotFoundException, WaybillRegistrationException, LocationNotFoundException, PodNotFoundException {
        // @Given a waybill dtos
        WaybillDtoAr dto = new WaybillDtoBuilderAr().FactoryTruckTypeWaybillWithTechnologyDeclared();

        when(locationDao.findLocationByCode(Matchers.anyLong())).thenReturn(new Location());
        when(campaignDao.findCampaignBy(any(Date.class))).thenReturn(new Campaign());

        List<Technology> techs = getTechnologies();
        when(cropTechnologyDao.findTechnologies()).thenReturn(techs);
        when(podDao.findByDocument(any(Document.class))).thenReturn(new PodHeadOffice());
        when(podDao.findByDocumentAndCommercialCode(any(Document.class), anyLong())).thenReturn(new PodBranch());
        when(podDao.isPODDocumentDeclared(any(Document.class))).thenReturn(false);
        when(documentTypeDao.findByCode(dto.getHolderDocumentType())).thenReturn(new DocumentType(dto.getHolderDocumentType()));

        // @When registering the waybill
        WaybillAr waybill = waybillMapperAr.map(dto);

        // @Then a waybill is loads with the dto waybill number ,dto plant code, the Holder and Commercial Sender
        assertThat(waybill.getWaybillNumber().toString()).isEqualTo(WaybillDtoBuilderAr.WAYBILL_NUMBER);
        assertThat(waybill.getPlantCode()).isEqualTo(WaybillDtoBuilderAr.ORIGIN_ESTABLISHMENT);
        assertThat(waybill.getHolderDocument().getNumber()).isEqualTo(WaybillDtoBuilderAr.HOLDER_DOCUMENT);
        assertThat(waybill.getCommercialSenderDocument().getNumber()).isEqualTo(WaybillDtoBuilderAr.COMMERCIAL_SENDER_DOCUMENT);
        assertThat(waybill.getCommercialSenderName()).isEqualTo(WaybillDtoBuilderAr.COMERCIAL_SENDER_NAME);
    }

    @Test
    public void testGivenAWaybillDtoArWithTruckTypeAndNoTechnologyDeclarationWithAParticipantHolderPod_ThenHolderAndCommercialSenderAreMappedToThWaybill()
            throws CampaignNotFoundException, WaybillRegistrationException, LocationNotFoundException, PodNotFoundException {
        // @Given a waybill dtos
        WaybillAr waybill = null;
        WaybillDtoAr dto = new WaybillDtoBuilderAr().FactoryTruckTypeWaybillWithNoTechnologyDeclared();

        when(locationDao.findLocationByCode(Matchers.anyLong())).thenReturn(new Location());
        when(campaignDao.findCampaignBy(any(Date.class))).thenReturn(new Campaign());

        List<Technology> techs = getTechnologies();
        when(cropTechnologyDao.findTechnologies()).thenReturn(techs);
        when(podDao.findByDocument(any(Document.class))).thenReturn(new PodHeadOffice());
        when(podDao.findByDocumentAndCommercialCode(any(Document.class), anyLong())).thenReturn(new PodBranch());
        when(podDao.isPODDocumentDeclared(any(Document.class))).thenReturn(true);
        when(documentTypeDao.findByCode(dto.getHolderDocumentType())).thenReturn(new DocumentType(dto.getHolderDocumentType()));

        // @When registering the waybill
        waybill = waybillMapperAr.map(dto);

        // @Then a waybill is loads with the dto waybill number ,dto plant code, the Holder and Commercial Sender
        assertThat(waybill.getWaybillNumber().toString()).isEqualTo(WaybillDtoBuilderAr.WAYBILL_NUMBER);
        assertThat(waybill.getPlantCode()).isEqualTo(WaybillDtoBuilderAr.ORIGIN_ESTABLISHMENT);
        assertThat(waybill.getHolderDocument().getNumber()).isEqualTo(WaybillDtoBuilderAr.HOLDER_DOCUMENT);
        assertThat(waybill.getCommercialSenderDocument().getNumber()).isEqualTo(WaybillDtoBuilderAr.COMMERCIAL_SENDER_DOCUMENT);
        assertThat(waybill.getCommercialSenderName()).isEqualTo(WaybillDtoBuilderAr.COMERCIAL_SENDER_NAME);
    }

    @Test
    public void testGivenAWaybillDtoArWithTruckTypeAndNoTechnologyDeclarationAndNoParticipantHolderPod_ThenHolderAndCommercialSenderMustNotBeMappedToThWaybill()
            throws CampaignNotFoundException, WaybillRegistrationException, LocationNotFoundException, PodNotFoundException {
        // @Given a waybill dtos
        WaybillAr waybill = null;
        WaybillDtoAr dto = new WaybillDtoBuilderAr().FactoryTruckTypeWaybillWithNoTechnologyDeclared();

        when(locationDao.findLocationByCode(Matchers.anyLong())).thenReturn(new Location());
        when(campaignDao.findCampaignBy(any(Date.class))).thenReturn(new Campaign());

        List<Technology> techs = getTechnologies();
        when(cropTechnologyDao.findTechnologies()).thenReturn(techs);
        when(podDao.findByDocument(any(Document.class))).thenReturn(new PodHeadOffice());
        when(podDao.findByDocumentAndCommercialCode(any(Document.class), anyLong())).thenReturn(new PodBranch());
        when(podDao.isPODDocumentDeclared(any(Document.class))).thenReturn(false);
        when(documentTypeDao.findByCode(dto.getHolderDocumentType())).thenReturn(new DocumentType(dto.getHolderDocumentType()));

        // @When registering the waybill
        waybill = waybillMapperAr.map(dto);

        // @Then a waybill is loads with the dto waybill number ,dto plant code, the Holder and Commercial Sender
        assertThat(waybill.getWaybillNumber().toString()).isEqualTo(WaybillDtoBuilderAr.WAYBILL_NUMBER);
        assertThat(waybill.getPlantCode()).isEqualTo(WaybillDtoBuilderAr.ORIGIN_ESTABLISHMENT);
        assertThat(waybill.getHolderDocument()).isNull();
        assertThat(waybill.getCommercialSenderDocument()).isNull();
        assertThat(waybill.getCommercialSenderName()).isNullOrEmpty();
    }

    @Test
    public void testGivenAWaybillDtoArWithTrainTypeAndTechnologyDeclarationOnAllWagonsAndNoParticipantHolderPod_ThenHolderAndCommercialSenderAreMappedToThWaybill()
            throws CampaignNotFoundException, WaybillRegistrationException, LocationNotFoundException, PodNotFoundException {
        // @Given a waybill dtos
        WaybillAr waybill = null;
        WaybillDtoAr dto = new WaybillDtoBuilderAr().FactoryTrainTypeWaybillWithTechnologyDeclared();

        when(locationDao.findLocationByCode(Matchers.anyLong())).thenReturn(new Location());
        when(campaignDao.findCampaignBy(any(Date.class))).thenReturn(new Campaign());

        List<Technology> techs = getTechnologies();
        when(cropTechnologyDao.findTechnologies()).thenReturn(techs);
        when(podDao.findByDocument(any(Document.class))).thenReturn(new PodHeadOffice());
        when(podDao.findByDocumentAndCommercialCode(any(Document.class), anyLong())).thenReturn(new PodBranch());
        when(podDao.isPODDocumentDeclared(any(Document.class))).thenReturn(false);
        when(documentTypeDao.findByCode(dto.getHolderDocumentType())).thenReturn(new DocumentType(dto.getHolderDocumentType()));

        // @When registering the waybill
        waybill = waybillMapperAr.map(dto);

        // @Then a waybill is loads with the dto waybill number ,dto plant code, the Holder and Commercial Sender
        assertThat(waybill.getWaybillNumber().toString()).isEqualTo(WaybillDtoBuilderAr.WAYBILL_NUMBER);
        assertThat(waybill.getPlantCode()).isEqualTo(WaybillDtoBuilderAr.ORIGIN_ESTABLISHMENT);
        assertThat(waybill.getHolderDocument().getNumber()).isEqualTo(WaybillDtoBuilderAr.HOLDER_DOCUMENT);
        assertThat(waybill.getCommercialSenderDocument().getNumber()).isEqualTo(WaybillDtoBuilderAr.COMMERCIAL_SENDER_DOCUMENT);
        assertThat(waybill.getCommercialSenderName()).isEqualTo(WaybillDtoBuilderAr.COMERCIAL_SENDER_NAME);
    }

    @Test
    public void testGivenAWaybillDtoArWithTrainTypeAndTechnologyDeclarationOnSomeWagonsAndNoParticipantHolderPod_ThenHolderAndCommercialSenderAreMappedToThWaybill()
            throws CampaignNotFoundException, WaybillRegistrationException, LocationNotFoundException, PodNotFoundException {
        // @Given a waybill dtos
        WaybillAr waybill = null;
        WaybillDtoAr dto = new WaybillDtoBuilderAr().FactoryTrainTypeWaybillWithSomeTechnologyDeclared();

        when(locationDao.findLocationByCode(Matchers.anyLong())).thenReturn(new Location());
        when(campaignDao.findCampaignBy(any(Date.class))).thenReturn(new Campaign());

        List<Technology> techs = getTechnologies();
        when(cropTechnologyDao.findTechnologies()).thenReturn(techs);
        when(podDao.findByDocument(any(Document.class))).thenReturn(new PodHeadOffice());
        when(podDao.findByDocumentAndCommercialCode(any(Document.class), anyLong())).thenReturn(new PodBranch());
        when(podDao.isPODDocumentDeclared(any(Document.class))).thenReturn(false);
        when(documentTypeDao.findByCode(dto.getHolderDocumentType())).thenReturn(new DocumentType(dto.getHolderDocumentType()));

        // @When registering the waybill
        waybill = waybillMapperAr.map(dto);

        // @Then a waybill is loads with the dto waybill number ,dto plant code, the Holder and Commercial Sender
        assertThat(waybill.getWaybillNumber().toString()).isEqualTo(WaybillDtoBuilderAr.WAYBILL_NUMBER);
        assertThat(waybill.getPlantCode()).isEqualTo(WaybillDtoBuilderAr.ORIGIN_ESTABLISHMENT);
        assertThat(waybill.getHolderDocument().getNumber()).isEqualTo(WaybillDtoBuilderAr.HOLDER_DOCUMENT);
        assertThat(waybill.getCommercialSenderDocument().getNumber()).isEqualTo(WaybillDtoBuilderAr.COMMERCIAL_SENDER_DOCUMENT);
        assertThat(waybill.getCommercialSenderName()).isEqualTo(WaybillDtoBuilderAr.COMERCIAL_SENDER_NAME);
    }

    @Test
    public void testGivenAWaybillDtoArWithTrainTypeAndNoTechnologyDeclarationOnWagonsWithParticipantHolderPod_ThenHolderAndCommercialSenderAreMappedToThWaybill()
            throws CampaignNotFoundException, WaybillRegistrationException, LocationNotFoundException, PodNotFoundException {
        // @Given a waybill dtos
        WaybillAr waybill = null;
        WaybillDtoAr dto = new WaybillDtoBuilderAr().FactoryTrainTypeWaybillWithNoTechnologyDeclared();

        when(locationDao.findLocationByCode(Matchers.anyLong())).thenReturn(new Location());
        when(campaignDao.findCampaignBy(any(Date.class))).thenReturn(new Campaign());

        List<Technology> techs = getTechnologies();
        when(cropTechnologyDao.findTechnologies()).thenReturn(techs);
        when(podDao.findByDocument(any(Document.class))).thenReturn(new PodHeadOffice());
        when(podDao.findByDocumentAndCommercialCode(any(Document.class), anyLong())).thenReturn(new PodBranch());
        when(podDao.isPODDocumentDeclared(any(Document.class))).thenReturn(true);
        when(documentTypeDao.findByCode(dto.getHolderDocumentType())).thenReturn(new DocumentType(dto.getHolderDocumentType()));

        // @When registering the waybill
        waybill = waybillMapperAr.map(dto);

        // @Then a waybill is loads with the dto waybill number ,dto plant code, the Holder and Commercial Sender
        assertThat(waybill.getWaybillNumber().toString()).isEqualTo(WaybillDtoBuilderAr.WAYBILL_NUMBER);
        assertThat(waybill.getPlantCode()).isEqualTo(WaybillDtoBuilderAr.ORIGIN_ESTABLISHMENT);
        assertThat(waybill.getHolderDocument().getNumber()).isEqualTo(WaybillDtoBuilderAr.HOLDER_DOCUMENT);
        assertThat(waybill.getCommercialSenderDocument().getNumber()).isEqualTo(WaybillDtoBuilderAr.COMMERCIAL_SENDER_DOCUMENT);
        assertThat(waybill.getCommercialSenderName()).isEqualTo(WaybillDtoBuilderAr.COMERCIAL_SENDER_NAME);
    }

    @Test
    public void testGivenAWaybillDtoArWithTrainTypeAndNoTechnologyDeclarationOnWagonsAndNoParticipantHolderPod_ThenHolderAndCommercialSenderMustNotBeMappedToThWaybill()
            throws CampaignNotFoundException, WaybillRegistrationException, LocationNotFoundException, PodNotFoundException {
        // @Given a waybill dtos
        WaybillAr waybill = null;
        WaybillDtoAr dto = new WaybillDtoBuilderAr().FactoryTrainTypeWaybillWithNoTechnologyDeclared();

        when(locationDao.findLocationByCode(Matchers.anyLong())).thenReturn(new Location());
        when(campaignDao.findCampaignBy(any(Date.class))).thenReturn(new Campaign());

        List<Technology> techs = getTechnologies();
        when(cropTechnologyDao.findTechnologies()).thenReturn(techs);
        when(podDao.findByDocument(any(Document.class))).thenReturn(new PodHeadOffice());
        when(podDao.findByDocumentAndCommercialCode(any(Document.class), anyLong())).thenReturn(new PodBranch());
        when(podDao.isPODDocumentDeclared(any(Document.class))).thenReturn(false);
        when(documentTypeDao.findByCode(dto.getHolderDocumentType())).thenReturn(new DocumentType(dto.getHolderDocumentType()));

        // @When registering the waybill
        waybill = waybillMapperAr.map(dto);

        // @Then a waybill is loads with the dto waybill number ,dto plant code, the Holder and Commercial Sender
        assertThat(waybill.getWaybillNumber().toString()).isEqualTo(WaybillDtoBuilderAr.WAYBILL_NUMBER);
        assertThat(waybill.getPlantCode()).isEqualTo(WaybillDtoBuilderAr.ORIGIN_ESTABLISHMENT);
        assertThat(waybill.getHolderDocument()).isNull();
        assertThat(waybill.getCommercialSenderDocument()).isNull();
        assertThat(waybill.getCommercialSenderName()).isNullOrEmpty();
    }

    private List<Technology> getTechnologies() {
        List<Technology> techs = new ArrayList<Technology>();
        Technology tech = new Technology();
        tech.setId(1);
        tech.setCode("INTACTA");
        tech.setDescription("INTACTA");
        tech.setTraitOwner(null);

        techs.add(tech);
        return techs;
    }

}