package ar.com.industrysystem.business.validators;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.InvalidDocumentNumberException;

/**
 * User: PMIRIB
 * Date: 10/12/13
 */
public class DocumentValidatorAr_UT {

    private DocumentValidatorAr documentValidatorAr;

    @Before
    public void setUp() {
        documentValidatorAr = new DocumentValidatorAr();
    }

    @Test
    public void validate_ThrowsInvalidDocumentNumberException_When_DocumentNumberIsNull() {
        try {
            documentValidatorAr.validate("CUIT", null);
            fail();
        } catch (InvalidDocumentNumberException e) {
            assertThat(e.getErrors()).onProperty("code").contains(BusinessError.INVALID_DOCUMENT);
            assertThat(e.getErrors()).onProperty("description").isNotEmpty();
        }
    }

    @Test
    public void validate_ThrowsInvalidDocumentNumberException_When_DocumentNumberLengthIsInvalid() {
        try {
            documentValidatorAr.validate("CUIT", "123456");
            fail();
        } catch (InvalidDocumentNumberException e) {
            assertThat(e.getErrors()).onProperty("code").contains(BusinessError.INVALID_DOCUMENT);
            assertThat(e.getErrors()).onProperty("description").isNotEmpty();
        }
    }

    @Test
    public void validate_ThrowsInvalidDocumentNumberException_When_DocumentNumberDigitsAreInvalid() {
        try {
            documentValidatorAr.validate("CUIT", "1234567890*");
            fail();
        } catch (InvalidDocumentNumberException e) {
            assertThat(e.getErrors()).onProperty("code").contains(BusinessError.INVALID_DOCUMENT);
            assertThat(e.getErrors()).onProperty("description").isNotEmpty();
        }
    }

    @Test
    public void validate_ThrowsInvalidDocumentNumberException_When_DocumentNumberStartIsInvalid() {
        try {
            documentValidatorAr.validate("CUIT", "12345678901");
            fail();
        } catch (InvalidDocumentNumberException e) {
            assertThat(e.getErrors()).onProperty("code").contains(BusinessError.INVALID_DOCUMENT);
            assertThat(e.getErrors()).onProperty("description").contains("Document number is invalid");
        }
    }
    
    @Test
    public void validate_ThrowsInvalidDocumentNumberException_When_DocumentTypeIsInvalid() {
        try {
            documentValidatorAr.validate("RUC", null);
            fail();
        } catch (InvalidDocumentNumberException e) {
            assertThat(e.getErrors()).onProperty("code").contains(BusinessError.INVALID_DOCUMENT_TYPE);
            assertThat(e.getErrors()).onProperty("description").contains("The document type is invalid");
        }
    }
    

    @Test
    public void validate_ThrowsInvalidDocumentTypeException_When_DocumentTypeIsInvalid() {
        try {
            documentValidatorAr.validate("CUAC", "12345678901");
            fail();
        } catch (InvalidDocumentNumberException e) {
            assertThat(e.getErrors()).onProperty("code").contains(BusinessError.INVALID_DOCUMENT_TYPE);
            assertThat(e.getErrors()).onProperty("description").contains("The document type is invalid");
        }
    }

    @Test
    public void validate_Ok_When_DocumentIsValid() throws InvalidDocumentNumberException {
        documentValidatorAr.validate("CUIT", "30123456789");
    }

}