package ar.com.industrysystem.business.validators;

import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.business.ProductsService;
import com.industrysystem.business.validators.TestResultValidator;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.*;
import com.industrysystem.persistence.daos.LoadDetailDao;
import com.industrysystem.persistence.daos.WaybillDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.when;

/**
 * User: PMIRIB
 * Date: 10/02/14
 */
@RunWith(MockitoJUnitRunner.class)
public class TestResultValidatorAr_UT {

    @Mock
    private WaybillDao waybillDao;
    @Mock
    private LoadDetailDao loadDetailDao;
    @Mock
    private ProductsService productsService;
    @InjectMocks
    private TestResultValidatorAr testResultValidatorAr;

    @Test
    public void testIsValidTechnology_returnTrue_whenIsValidTechnology() throws Exception {
        boolean result = testResultValidatorAr.isValidTechnology("goodTech");
        assertTrue(result);
    }

    @Test
    public void testIsValidTechnology_returnFalse_whenIsNotValidTechnology() throws Exception {
        when(productsService.findByCode(anyString())).thenThrow(TechnologyNotFoundException.class);
        boolean result = testResultValidatorAr.isValidTechnology("badTech");
        assertFalse(result);
    }

    @Test
    public void validateName_addError_whenNameIsEmpty() throws Exception {
        testResultValidatorAr.validateName("document", "");
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.EMPTY_NAME);
    }

    @Test
    public void validateName_doNotAddError_whenBothNotEmpty() throws Exception {
        testResultValidatorAr.validateName("document", "name");
        assertThat(testResultValidatorAr.getErrors()).isEmpty();
    }

    @Test
    public void validateName_doNotAddError_whenBothEmpty() throws Exception {
        testResultValidatorAr.validateName("", "");
        assertThat(testResultValidatorAr.getErrors()).isEmpty();
    }

    @Test
    public void validateSampleCode_addError_whenIsNotValid() throws Exception {
        String sampleCode = "";
        WaybillAr waybillAr = new WaybillAr();

        testResultValidatorAr.validateSampleCode(sampleCode, waybillAr);

        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.SAMPLE_CODE_EMPTY);
    }

    @Test
    public void validateSampleCode_doNotAddError_whenIsNull() throws Exception {
        String sampleCode = null;
        WaybillAr waybillAr = new WaybillAr();

        testResultValidatorAr.validateSampleCode(sampleCode, waybillAr);

        assertThat(testResultValidatorAr.getErrors()).isEmpty();
    }

    @Test
    public void validateSampleCode_addError_whenIsNotInWaybill() throws Exception {
        String sampleCode = "new";
        WaybillAr waybillAr = new WaybillAr();

        testResultValidatorAr.validateSampleCode(sampleCode, waybillAr);

        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.INVALID_SAMPLE_CODE);
    }

    @Test
    public void validateSampleCode_doNotAddError_whenIsNotInWaybill() throws Exception {
        String sampleCode = "notNew";
        WaybillAr waybillAr = new WaybillAr();
        List<LoadDetail> loadDetailList = new ArrayList<LoadDetail>();
        LoadDetail loadDetail = new TruckLoadDetail();
        loadDetail.setSampleCode(sampleCode);
        loadDetailList.add(loadDetail);
        when(loadDetailDao.findLoadDetailsByWaybill(any(Waybill.class))).thenReturn(loadDetailList);

        testResultValidatorAr.validateSampleCode(sampleCode, waybillAr);

        assertThat(testResultValidatorAr.getErrors()).isEmpty();
    }

    @Test
    public void validateTestType_addError_whenIsNotValid() throws Exception {
        testResultValidatorAr.validateTestType("fruit", null, null);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.INVALID_TYPE_OF_TEST);
    }

    @Test
    public void validateTestType_addError_whenTestQualitativeIsNull() throws Exception {
        testResultValidatorAr.validateTestType(TestResultValidator.CUALITATIVO, null, null);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.INVALID_TYPE_OF_TEST);
    }

    @Test
    public void validateTestType_addError_whenTestQualitativeResultIsInvalid() throws Exception {
        testResultValidatorAr.validateTestType(TestResultValidator.CUALITATIVO, "invalido", null);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.INVALID_TYPE_OF_TEST);
    }

    @Test
    public void validateTestType_doNotAddError_whenTestQualitativeResultIsValid() throws Exception {
        testResultValidatorAr.validateTestType(TestResultValidator.CUALITATIVO, TestResultValidator.POSITIVO, null);
        assertEquals(0, testResultValidatorAr.getErrors().size());
    }

    @Test
    public void validateTestType_doNotAddError_whenTestQualitativeResultIsNegative() throws Exception {
        testResultValidatorAr.validateTestType(TestResultValidator.CUALITATIVO, TestResultValidator.NEGATIVO, null);
        assertEquals(0, testResultValidatorAr.getErrors().size());
    }

    @Test
    public void validateTestType_addError_whenTestQuantitativeIsNull() throws Exception {
        testResultValidatorAr.validateTestType(TestResultValidator.CUANTITATIVO, null, null);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.INVALID_TECHNOLOGY_PERCENT);
    }

    @Test
    public void validateTestType_doNotAddError_whenTestQuantitativeIsOk() throws Exception {
        testResultValidatorAr.validateTestType(TestResultValidator.CUANTITATIVO, null, "80");
        assertEquals(0, testResultValidatorAr.getErrors().size());
    }

    @Test
    public void findWaybillByParameters_returnWaybillAndDoNotAddError_whenOk() throws Exception {
        Document destinationDocument = null;
        String sampleCode = null;

        LoadDetail loadDetail = new TruckLoadDetail();
        Waybill waybill = new WaybillAr();
        waybill.setStatus(WaybillStatusEnum.WAITING_FOR_TEST_RESULTS);
        loadDetail.setWaybill(waybill);
        when(loadDetailDao.findLoadDetailsBySampleCodeAndWaybillDestinationDocument(anyString(), any(Document.class))).thenReturn(loadDetail);
        when(waybillDao.findWaybillByWaybillNumber(anyLong())).thenReturn(loadDetail.getWaybill());

        Waybill result = testResultValidatorAr.findWaybillByParameters(destinationDocument, sampleCode);

        assertEquals(waybill, result);
        assertEquals(0, testResultValidatorAr.getErrors().size());
    }

    @Test
    public void validateStatus_addError_whenStatusInvalid() throws Exception {
        WaybillAr waybill = new WaybillAr();
        waybill.setStatus(WaybillStatusEnum.PARTIALLY_RECEIVED);

        testResultValidatorAr.validateStatus(waybill);

        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.WAYBILL_STATE_IS_INVALID);
    }

    @Test
    public void validateStatus_doNotAddError_whenStatusValid() throws Exception {
        WaybillAr waybill = new WaybillAr();
        waybill.setStatus(WaybillStatusEnum.WAITING_FOR_TEST_RESULTS);

        testResultValidatorAr.validateStatus(waybill);

        assertEquals(0, testResultValidatorAr.getErrors().size());
    }

    @Test
    public void validateTestDate_addError_whenDateInvalid1() throws Exception {
        String testDate = "";
        testResultValidatorAr.validateTestDate(testDate);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.INVALID_TEST_DATE);
    }

    @Test
    public void validateTestDate_addError_whenDateInvalid2() throws Exception {
        String testDate = "12345";
        testResultValidatorAr.validateTestDate(testDate);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.INVALID_TEST_DATE);
    }

    @Test
    public void validateTestDate_addError_whenTestDateAfterNow() throws Exception {
        String testDate = "01/12/2100";
        testResultValidatorAr.validateTestDate(testDate);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.INVALID_TEST_DATE);
    }

    @Test
    public void validateTestDate_doNotAddError_whenTestDateBeforeNow() throws Exception {
        String testDate = "01/12/2000";
        testResultValidatorAr.validateTestDate(testDate);
        assertEquals(0, testResultValidatorAr.getErrors().size());
    }

    @Test
    public void validateTestDate_addError_whenCannotParseDate() throws Exception {
        String testDate = "1234567890";
        testResultValidatorAr.validateTestDate(testDate);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.INVALID_TEST_DATE);
    }

    @Test
    public void findLoadDetailByDestinationDocument_returnLoadDetail_whenFound() throws Exception {
        Document destinationDocument = null;
        String sampleCode = null;
        LoadDetail loadDetail = new TruckLoadDetail();
        when(loadDetailDao.findLoadDetailsBySampleCodeAndWaybillDestinationDocument(anyString(), any(Document.class))).thenReturn(loadDetail);

        LoadDetail result = testResultValidatorAr.findLoadDetailByDestinationDocument(destinationDocument, sampleCode);
        assertEquals(loadDetail, result);
    }

    @Test
    public void findLoadDetailByDestinationDocument_throwsException_whenNoResultFound() throws Exception {
        Document destinationDocument = new Document();
        destinationDocument.setNumber("1");
        String sampleCode = null;
        when(loadDetailDao.findLoadDetailsBySampleCodeAndWaybillDestinationDocument(anyString(), any(Document.class))).thenThrow(NoResultException.class);
        try {
            testResultValidatorAr.findLoadDetailByDestinationDocument(destinationDocument, sampleCode);
            fail();
        } catch(LoadDetailNotFoundException ex) {
            // ok
        }
    }

    @Test
    public void findLoadDetailByDestinationDocument_throwsException_whenNoUniqueResult() throws Exception {
        Document destinationDocument = new Document();
        destinationDocument.setNumber("1");
        String sampleCode = null;
        when(loadDetailDao.findLoadDetailsBySampleCodeAndWaybillDestinationDocument(anyString(), any(Document.class))).thenThrow(NonUniqueResultException.class);
        try {
            testResultValidatorAr.findLoadDetailByDestinationDocument(destinationDocument, sampleCode);
            fail();
        } catch(StoreTestResultException ex) {
            // ok
        }
    }

    @Test
    public void findWaybillByParameters_addError_whenLoadDetailNotFound() throws Exception {
        Document destinationDocument = null;
        String sampleCode = null;
        when(loadDetailDao.findLoadDetailsBySampleCodeAndWaybillDestinationDocument(anyString(), any(Document.class))).thenThrow(LoadDetailNotFoundException.class);

        Waybill result = testResultValidatorAr.findWaybillByParameters(destinationDocument, sampleCode);

        assertNull(result);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.LOAD_DETAIL_NOT_FOUND);
    }

    @Test
    public void findWaybillByParameters_addError_whenWaybillNotFound() throws Exception {
        Document destinationDocument = null;
        String sampleCode = null;

        LoadDetail loadDetail = new TruckLoadDetail();
        Waybill waybill = new WaybillAr();
        waybill.setStatus(WaybillStatusEnum.WAITING_FOR_TEST_RESULTS);
        loadDetail.setWaybill(waybill);
        when(loadDetailDao.findLoadDetailsBySampleCodeAndWaybillDestinationDocument(anyString(), any(Document.class))).thenReturn(loadDetail);
        when(waybillDao.findWaybillByWaybillNumber(anyLong())).thenThrow(WaybillNotFoundException.class);

        Waybill result = testResultValidatorAr.findWaybillByParameters(destinationDocument, sampleCode);

        assertNull(result);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.WAYBILL_NOT_FOUND);
    }

    @Test
    public void findWaybillByParameters_addError_whenExceptionIsThrown() throws Exception {
        when(loadDetailDao.findLoadDetailsBySampleCodeAndWaybillDestinationDocument(anyString(), any(Document.class))).thenThrow(Exception.class);

        Waybill result = testResultValidatorAr.findWaybillByParameters(null, null);

        assertNull(result);
        assertEquals(1, testResultValidatorAr.getErrors().size());
        assertErrorCode(testResultValidatorAr.getErrors(), BusinessError.WAYBILL_NOT_FOUND);
    }

    @Test
    public void validate_throwsException_whenEverythingIsNull() throws Exception {
        try {
            testResultValidatorAr.validate(null, null, null, null, null, null, null, null, null, null, null, null);
            fail();
        } catch(TestResultRegistrationException ex) {
            // ok.
        }
    }

    @Test
    public void validate_throwsException_whenEverythingIsNull2() throws Exception {
        String holderDocument = null;
        String commercialSenderDocument = null;
        String destinationDocumentNumber = null;
        String sampleCode = null;
        String technology = null;
        String technologyPercent = null;
        String testType = null;
        String holderName = null;
        String commercialSenderName = null;
        String testDate = null;
        String qualitativeResult = null;
        String quantitativeResult = null;

        LoadDetail loadDetail = new TruckLoadDetail();
        Waybill waybill = new WaybillAr();
        waybill.setStatus(WaybillStatusEnum.WAITING_FOR_TEST_RESULTS);
        loadDetail.setWaybill(waybill);
        when(loadDetailDao.findLoadDetailsBySampleCodeAndWaybillDestinationDocument(anyString(), any(Document.class))).thenReturn(loadDetail);
        when(waybillDao.findWaybillByWaybillNumber(anyLong())).thenReturn(loadDetail.getWaybill());

        try {
            testResultValidatorAr.validate(holderDocument, commercialSenderDocument, destinationDocumentNumber,
                                           sampleCode, technology, technologyPercent, testType, holderName,
                                           commercialSenderName, testDate, qualitativeResult, quantitativeResult);
            fail();
        } catch(TestResultRegistrationException ex) {
            // ok.
        }
    }

    private void assertErrorCode(List<BusinessError> errors, String errorCode) {
        assertThat(errors).onProperty("code").contains(errorCode);
    }

}