package ar.com.industrysystem.business.validators;

import ar.com.industrysystem.business.dtos.WaybillDtoAr;
import com.industrysystem.business.CropService;
import com.industrysystem.business.LaboratoryService;
import com.industrysystem.business.LocationService;
import com.industrysystem.business.ProductsService;
import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.TruckDetailDTO;
import com.industrysystem.business.dtos.WagonDetailDTO;
import com.industrysystem.business.validators.DocumentValidator;
import com.industrysystem.entities.DocumentType;
import com.industrysystem.entities.Location;
import com.industrysystem.entities.TransportType;
import com.industrysystem.entities.WagonLoadDetail;
import com.industrysystem.exceptions.*;
import com.industrysystem.persistence.daos.LoadDetailDao;
import com.industrysystem.persistence.daos.TruckDetailDao;
import com.industrysystem.persistence.daos.WaybillDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.Iterables.getOnlyElement;
import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

/**
 * User: JPNORV
 * Date: 16/12/13
 */
@RunWith(MockitoJUnitRunner.class)
public class WaybillValidatorAr_UT {

    @Mock
    private WaybillDao waybillDao;
    @Mock
    private DocumentValidator documentValidator;
    @Mock
    private CropService cropService;
    @Mock
    private LocationService locationService;
    @Mock
    private ProductsService productsService;
    @Mock
    private LaboratoryService laboratoryService;
    @Mock
    private LoadDetailDao loadDetailDao;
    @Mock
    private TruckDetailDao truckDetailDao;
    @InjectMocks
    private WaybillValidatorAr waybillValidatorAr;

    private void assertErrorCode(WaybillRegistrationException e, String errorCode) {
        assertThat(e.getErrors()).onProperty("code").contains(errorCode);
    }

    @Test
    public void validateWaybill_ShouldThrowWaybillRegistrationException_WhenWaybillisNull() throws Exception {
        WaybillDtoAr waybillDtoAr = new WaybillDtoAr();
        waybillDtoAr.setDestinationLocation(22L);
        waybillDtoAr.setOriginLocation(21L);
        LoadDetailDTO loadDetailDTO = new TruckDetailDTO();
        loadDetailDTO.setDeclaredTechnology("INTACTA");
        List<LoadDetailDTO> loadDetailDTOs = new ArrayList<LoadDetailDTO>();
        loadDetailDTOs.add(loadDetailDTO);
        waybillDtoAr.setLoadDetails(loadDetailDTOs);

        when(locationService.findLocationById(anyLong())).thenThrow(LocationNotFoundException.class);
        when(cropService.findCropByCode(anyString())).thenThrow(CropNotFoundException.class);
        when(waybillDao.findWaybillByWaybillNumber(any(Long.class))).thenThrow(WaybillNotFoundException.class);

        try {
            waybillValidatorAr.validateBatchWaybill(waybillDtoAr);
        } catch (WaybillRegistrationException e) {
            assertErrorCode(e, BusinessError.INVALID_WAYBILL_NUMBER);
            assertErrorCode(e, BusinessError.INVALID_TRANSPORT_TYPE);
            assertErrorCode(e, BusinessError.INVALID_HOLDER_NAME);
            assertErrorCode(e, BusinessError.CROP_NOT_FOUND);
            assertErrorCode(e, BusinessError.INVALID_ORIGIN_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_DESTINATION_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_UNLOADING_DATE);
            assertThat(e.getErrors().size()).isEqualTo(7);
        }
    }

    @Test
    public void validateWaybill_ShouldThrowWaybillRegistrationException_WhenWaybillNumberIsNotValid() throws Exception {
        WaybillDtoAr waybillDtoAr = createWaybillDtoAr("AA2211456");
        waybillDtoAr.setHolderDocument("111");
        waybillDtoAr.setAddresseeDocument("111");
        waybillDtoAr.setDestinationDocument("111");
        waybillDtoAr.setCommercialSenderDocument("111");
        waybillDtoAr.setDestinationLocation(22L);
        waybillDtoAr.setOriginLocation(21L);

        when(locationService.findLocationById(anyLong())).thenThrow(LocationNotFoundException.class);
        when(cropService.findCropByCode(anyString())).thenThrow(CropNotFoundException.class);
        when(waybillDao.findWaybillByWaybillNumber(any(Long.class))).thenThrow(WaybillNotFoundException.class);

        doThrow(InvalidDocumentNumberException.class).when(this.documentValidator).validate(eq(DocumentType.CUIT.toString()), anyString());

        try {
            waybillValidatorAr.validateBatchWaybill(waybillDtoAr);
        } catch (WaybillRegistrationException e) {
            assertErrorCode(e, BusinessError.INVALID_WAYBILL_NUMBER);
            assertErrorCode(e, BusinessError.INVALID_TRANSPORT_TYPE);
            assertErrorCode(e, BusinessError.INVALID_HOLDER_DOCUMENT);
            assertErrorCode(e, BusinessError.INVALID_ADDRESSEE_DOCUMENT);
            assertErrorCode(e, BusinessError.INVALID_DESTINATION_DOCUMENT);
            assertErrorCode(e, BusinessError.INVALID_HOLDER_NAME);
            assertErrorCode(e, BusinessError.CROP_NOT_FOUND);
            assertErrorCode(e, BusinessError.INVALID_ORIGIN_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_DESTINATION_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_UNLOADING_DATE);
            assertThat(e.getErrors().size()).isEqualTo(10);
        }
    }

    @Test
    public void validateWaybill_ShouldThrowWaybillRegistrationException_WhenWaybillNumberIsNull() throws Exception {
        WaybillDtoAr waybillDtoAr = createWaybillDtoAr(null);
        waybillDtoAr.setDestinationLocation(22L);
        waybillDtoAr.setOriginLocation(21L);

        when(locationService.findLocationById(anyLong())).thenThrow(LocationNotFoundException.class);
        when(cropService.findCropByCode(anyString())).thenThrow(CropNotFoundException.class);
        when(waybillDao.findWaybillByWaybillNumber(any(Long.class))).thenThrow(WaybillNotFoundException.class);

        try {
            waybillValidatorAr.validateBatchWaybill(waybillDtoAr);
        } catch (WaybillRegistrationException e) {
            assertErrorCode(e, BusinessError.INVALID_WAYBILL_NUMBER);
            assertErrorCode(e, BusinessError.INVALID_TRANSPORT_TYPE);
            assertErrorCode(e, BusinessError.INVALID_HOLDER_NAME);
            assertErrorCode(e, BusinessError.CROP_NOT_FOUND);
            assertErrorCode(e, BusinessError.INVALID_ORIGIN_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_DESTINATION_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_UNLOADING_DATE);
            assertThat(e.getErrors().size()).isEqualTo(7);
        }
    }

    @Test
    public void validateWaybill_ShouldThrowWaybillRegistrationException_WhenTransportTypeIsTruckDeclared() throws Exception {
        WaybillDtoAr waybillDtoAr = createWaybillDtoArWithTruckDetailDto(null);
        waybillDtoAr.setDestinationLocation(22L);
        waybillDtoAr.setOriginLocation(21L);

        TruckDetailDTO truckDetailDTO = (TruckDetailDTO)getOnlyElement(waybillDtoAr.getLoadDetails());
        truckDetailDTO.setDeclaredTechnology("22");
        truckDetailDTO.setLoadIdentifier("AA12345678");
        truckDetailDTO.setSampleCode("SCOD1");

        when(locationService.findLocationById(anyLong())).thenThrow(LocationNotFoundException.class);
        when(cropService.findCropByCode(anyString())).thenThrow(CropNotFoundException.class);
        when(waybillDao.findWaybillByWaybillNumber(any(Long.class))).thenThrow(WaybillNotFoundException.class);
        when(productsService.findByCode(anyString())).thenThrow(TechnologyNotFoundException.class);

        try {
            waybillValidatorAr.validateBatchWaybill(waybillDtoAr);
        } catch (WaybillRegistrationException e) {
            assertErrorCode(e, BusinessError.INVALID_WAYBILL_NUMBER);
            assertErrorCode(e, BusinessError.INVALID_HOLDER_NAME);
            assertErrorCode(e, BusinessError.CROP_NOT_FOUND);
            assertErrorCode(e, BusinessError.INVALID_ORIGIN_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_DESTINATION_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_UNLOADING_DATE);
            assertErrorCode(e, BusinessError.INVALID_CTG_NUMBER);
            assertErrorCode(e, BusinessError.WEIGHT_INVALID);
            assertErrorCode(e, BusinessError.INVALID_TECHNOLOGY);

            assertThat(e.getErrors().size()).isEqualTo(9);
        }
    }

    @Test
    public void validateWaybill_ShouldThrowWaybillRegistrationException_WhenTransportTypeIsTruckNotDeclared() throws Exception {
        WaybillDtoAr waybillDtoAr = createWaybillDtoArWithTruckDetailDto(null);
        waybillDtoAr.setDestinationLocation(22L);
        waybillDtoAr.setOriginLocation(21L);

        TruckDetailDTO truckDetailDTO = (TruckDetailDTO)getOnlyElement(waybillDtoAr.getLoadDetails());
        truckDetailDTO.setLoadIdentifier("AA12345678");
        truckDetailDTO.setSampleCode("SCOD1");

        when(locationService.findLocationById(anyLong())).thenThrow(LocationNotFoundException.class);
        when(cropService.findCropByCode(anyString())).thenThrow(CropNotFoundException.class);
        when(waybillDao.findWaybillByWaybillNumber(any(Long.class))).thenThrow(WaybillNotFoundException.class);
        when(laboratoryService.findLaboratoryByLabCode(anyString())).thenThrow(LaboratoryNotFoundException.class);

        try {
            waybillValidatorAr.validateBatchWaybill(waybillDtoAr);
        } catch (WaybillRegistrationException e) {
            assertErrorCode(e, BusinessError.INVALID_WAYBILL_NUMBER);
            assertErrorCode(e, BusinessError.INVALID_HOLDER_NAME);
            assertErrorCode(e, BusinessError.CROP_NOT_FOUND);
            assertErrorCode(e, BusinessError.INVALID_ORIGIN_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_DESTINATION_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_UNLOADING_DATE);
            assertErrorCode(e, BusinessError.INVALID_CTG_NUMBER);
            assertErrorCode(e, BusinessError.WEIGHT_INVALID);
            assertErrorCode(e, BusinessError.LABORATORY_NOT_FOUND);

            assertThat(e.getErrors().size()).isEqualTo(10);
        }
    }

    @Test
    public void validateWaybill_ShouldThrowWaybillRegistrationException_WhenTransportTypeIsWagonDeclared() throws Exception {
        WaybillDtoAr waybillDtoAr = createWaybillDtoArWithWagonDetailDto(null);
        waybillDtoAr.setDestinationLocation(22L);
        waybillDtoAr.setOriginLocation(21L);
        waybillDtoAr.setHolderDocument("111");
        waybillDtoAr.setAddresseeDocument("111");
        waybillDtoAr.setDestinationDocument("111");
        waybillDtoAr.setCommercialSenderDocument("111");

        WagonDetailDTO wagonDetailDTO = (WagonDetailDTO)getOnlyElement(waybillDtoAr.getLoadDetails());
        wagonDetailDTO.setDeclaredTechnology("22");
        wagonDetailDTO.setLoadIdentifier("AA12345678");
        wagonDetailDTO.setSampleCode("SCOD1");
        wagonDetailDTO.setWagonsQty("3");

        when(locationService.findLocationById(anyLong())).thenThrow(LocationNotFoundException.class);

        WagonLoadDetail wagonLoadDetail = new WagonLoadDetail();
        wagonLoadDetail.setWeight(1000);
        wagonLoadDetail.setWagonNumber("AA12345678");
        wagonLoadDetail.setWagonQty(3);
        when(loadDetailDao.findEagerWaybillByID(waybillDtoAr.getWaybillNumber())).thenReturn(wagonLoadDetail);

        doThrow(InvalidDocumentNumberException.class).when(documentValidator).validate(eq(DocumentType.CUIT.toString()), anyString());
        when(waybillDao.findWaybillByWaybillNumber(any(Long.class))).thenThrow(WaybillNotFoundException.class);
        when(cropService.findCropByCode(anyString())).thenThrow(CropNotFoundException.class);
        when(productsService.findByCode(anyString())).thenThrow(TechnologyNotFoundException.class);

        try {
            waybillValidatorAr.validateBatchWaybill(waybillDtoAr);
        } catch (WaybillRegistrationException e) {
            assertErrorCode(e, BusinessError.INVALID_WAYBILL_NUMBER);
            assertErrorCode(e, BusinessError.INVALID_HOLDER_DOCUMENT);
            assertErrorCode(e, BusinessError.INVALID_ADDRESSEE_DOCUMENT);
            assertErrorCode(e, BusinessError.INVALID_DESTINATION_DOCUMENT);
            assertErrorCode(e, BusinessError.INVALID_COMMERCIAL_SENDER_DOCUMENT);
            assertErrorCode(e, BusinessError.INVALID_HOLDER_NAME);
            assertErrorCode(e, BusinessError.INVALID_COMMERCIAL_SENDER_NAME);
            assertErrorCode(e, BusinessError.CROP_NOT_FOUND);
            assertErrorCode(e, BusinessError.INVALID_ORIGIN_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_DESTINATION_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_UNLOADING_DATE);
            assertErrorCode(e, BusinessError.WEIGHT_INVALID);
            assertErrorCode(e, BusinessError.INVALID_TECHNOLOGY);

            assertThat(e.getErrors().size()).isEqualTo(13);
        }
    }

    @Test
    public void validateWaybill_ShouldThrowWaybillRegistrationException_WhenTransportTypeIsWagonNotDeclared() throws Exception {
        WaybillDtoAr waybillDtoAr = createWaybillDtoArWithWagonDetailDto(null);
        waybillDtoAr.setDestinationLocation(22L);
        waybillDtoAr.setOriginLocation(21L);

        WagonDetailDTO wagonDetailDTO = (WagonDetailDTO)getOnlyElement(waybillDtoAr.getLoadDetails());

        wagonDetailDTO.setLoadIdentifier("AA12345678");
        wagonDetailDTO.setSampleCode("SCOD1");
        wagonDetailDTO.setWagonsQty("3");

        when(locationService.findLocationById(anyLong())).thenThrow(LocationNotFoundException.class);

        WagonLoadDetail wagonLoadDetail = new WagonLoadDetail();
        wagonLoadDetail.setWeight(1000);
        wagonLoadDetail.setWagonNumber("AA12345678");
        wagonLoadDetail.setWagonQty(3);
        when(loadDetailDao.findEagerWaybillByID(waybillDtoAr.getWaybillNumber())).thenReturn(wagonLoadDetail);

        when(waybillDao.findWaybillByWaybillNumber(any(Long.class))).thenThrow(WaybillNotFoundException.class);
        when(cropService.findCropByCode(anyString())).thenThrow(CropNotFoundException.class);
        when(laboratoryService.findLaboratoryByLabCode(anyString())).thenThrow(LaboratoryNotFoundException.class);

        try {
            waybillValidatorAr.validateBatchWaybill(waybillDtoAr);
        } catch (WaybillRegistrationException e) {
            assertErrorCode(e, BusinessError.INVALID_WAYBILL_NUMBER);
            assertErrorCode(e, BusinessError.INVALID_HOLDER_NAME);
            assertErrorCode(e, BusinessError.CROP_NOT_FOUND);
            assertErrorCode(e, BusinessError.INVALID_ORIGIN_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_DESTINATION_LOCATION);
            assertErrorCode(e, BusinessError.INVALID_UNLOADING_DATE);
            assertErrorCode(e, BusinessError.WEIGHT_INVALID);
            assertErrorCode(e, BusinessError.LABORATORY_NOT_FOUND);

            assertThat(e.getErrors().size()).isEqualTo(9);
        }
    }

    @Test
	public void validateExistCtgNumber_ThrowLoadDetailAlreadyExistsException_WhenExistsCTG() throws Exception {
    	// Given TruckDetail with ctg existing in ddbb
    	WaybillDtoAr waybillDtoAr = createWaybillDtoArWithMockTruckDetailDto(null);
		try {
			doThrow(new LoadDetailAlreadyExistsException("msg")).when(truckDetailDao).findTruckDetailById(anyString());
		// When validate ctg existence
			waybillValidatorAr.validateExistCtgNumber(waybillDtoAr);
			fail();
		} catch (WaybillRegistrationException ldae) {
		// Then Throw Already Exist Exception
			assertThat(ldae.getErrors().get(0).getCode()).isEqualTo(BusinessError.LOAD_DETAIL_ALREADY_EXIST);
		}
	}

    @Test
	public void validate_WhenWaybillDtoArIsOk() throws LoadDetailAlreadyExistsException, LoadDetailNotFoundException, WaybillNotFoundException {
    	// Given WaybillDtoAr
        WaybillDtoAr waybillDtoAr = createWaybillDtoArWithMockTruckDetailDto(null);
		try {
			doThrow(LoadDetailNotFoundException.class).when(truckDetailDao).findTruckDetailById(anyString());
		// When validate WaybillDtoAr
			waybillValidatorAr.validate(waybillDtoAr);
			fail();
		} catch (WaybillRegistrationException ldae) {
		// Then Run Successful
		}
	}

    @Test
    public void testWaybillValidFormatNumberAddsErrorOnNull() {
        waybillValidatorAr.waybillValidFormatNumber(createWaybillDtoAr(null));

        assertEquals(1, waybillValidatorAr.getErrors().size());
        assertEquals(BusinessError.INVALID_WAYBILL_NUMBER, waybillValidatorAr.getErrors().get(0).getCode());
    }

    @Test
    public void testWaybillValidFormatNumberAddsErrorOnEmpty() {
        waybillValidatorAr.waybillValidFormatNumber(createWaybillDtoAr(""));

        assertEquals(1, waybillValidatorAr.getErrors().size());
        assertEquals(BusinessError.INVALID_WAYBILL_NUMBER, waybillValidatorAr.getErrors().get(0).getCode());
    }

    @Test
    public void testWaybillValidFormatNumberAddsErrorOnNotANumber() {
        waybillValidatorAr.waybillValidFormatNumber(createWaybillDtoAr("a"));

        assertEquals(1, waybillValidatorAr.getErrors().size());
        assertEquals(BusinessError.INVALID_WAYBILL_NUMBER, waybillValidatorAr.getErrors().get(0).getCode());
    }

    @Test
    public void testWaybillValidFormatNumberAddsErrorOnNegativeNumber() {
        waybillValidatorAr.waybillValidFormatNumber(createWaybillDtoAr("-12"));

        assertEquals(1, waybillValidatorAr.getErrors().size());
        assertEquals(BusinessError.INVALID_WAYBILL_NUMBER, waybillValidatorAr.getErrors().get(0).getCode());
    }

    @Test
    public void testWaybillValidFormatNumberAddsErrorOnVeryLongNumber() {
        waybillValidatorAr.waybillValidFormatNumber(createWaybillDtoAr("1234567890123"));

        assertEquals(1, waybillValidatorAr.getErrors().size());
        assertEquals(BusinessError.INVALID_WAYBILL_NUMBER, waybillValidatorAr.getErrors().get(0).getCode());
    }

    @Test
    public void testWaybillValidFormatNumberDoesNothingOnValidNumber() {
        waybillValidatorAr.waybillValidFormatNumber(createWaybillDtoAr("123456789012"));

        assertEquals(0, waybillValidatorAr.getErrors().size());
    }

    @Test
	public void validateManualWaybill_ThrowException_WhenInvalidWaybillNumberAndInvalidTruckId() throws Exception {
        WaybillDtoAr waybillDtoAr = createWaybillDtoArWithMockTruckDetailDto(null);
        waybillDtoAr.setOriginLocation(1L);
        waybillDtoAr.setDestinationLocation(2L);
        when(locationService.findLocationById(anyLong())).thenReturn(new Location());
        doThrow(LoadDetailNotFoundException.class).when(truckDetailDao).findTruckDetailById(anyString());
		try {
			waybillValidatorAr.validateManualWaybill(waybillDtoAr);
			fail();
		} catch (WaybillRegistrationException ex) {
            assertEquals(2, ex.getErrors().size());
            assertErrorCode(ex, BusinessError.INVALID_WAYBILL_NUMBER);
            assertErrorCode(ex, BusinessError.INVALID_CTG_NUMBER);
		}
	}

    @Test
	public void validateManualWaybill_ok_WhenEverythingOk() throws Exception {
        WaybillDtoAr waybillDtoAr = createWaybillDtoArWithMockTruckDetailDto("123456789012");
        waybillDtoAr.setOriginLocation(1L);
        waybillDtoAr.setDestinationLocation(2L);

        LoadDetailDTO truckDetailDTO = getOnlyElement(waybillDtoAr.getLoadDetails());
        when(truckDetailDTO.getLoadIdentifier()).thenReturn("1");
        when(locationService.findLocationById(anyLong())).thenReturn(new Location());
        doThrow(LoadDetailNotFoundException.class).when(truckDetailDao).findTruckDetailById(anyString());
        when(waybillDao.findWaybillByWaybillNumber(anyLong())).thenThrow(WaybillNotFoundException.class);

        waybillValidatorAr.validateManualWaybill(waybillDtoAr);
        // Ok, no errors!
	}

    @Test
	public void validateManualWaybill_ok_WhenWagonWaybillDtoOk() throws Exception {
        WaybillDtoAr waybillDtoAr = createWaybillDtoArWithMockWagonDetailDto("123456789012");
        waybillDtoAr.setOriginLocation(1L);
        waybillDtoAr.setDestinationLocation(2L);

        WagonDetailDTO wagonDetailDTO = (WagonDetailDTO)getOnlyElement(waybillDtoAr.getLoadDetails());
        when(wagonDetailDTO.getLoadIdentifier()).thenReturn("1");
        when(wagonDetailDTO.getWagonsQty()).thenReturn("1");

        when(locationService.findLocationById(anyLong())).thenReturn(new Location());
        doThrow(LoadDetailNotFoundException.class).when(truckDetailDao).findTruckDetailById(anyString());
        when(waybillDao.findWaybillByWaybillNumber(anyLong())).thenThrow(WaybillNotFoundException.class);

        waybillValidatorAr.validateManualWaybill(waybillDtoAr);
        // Ok, no errors!
	}

    private WaybillDtoAr createWaybillDtoArWithMockTruckDetailDto(String waybillNumber) {
        return createWaybillDtoAr(waybillNumber, TransportType.TRANSPORTE_AUTOMOTOR, mock(TruckDetailDTO.class));
    }

    private WaybillDtoAr createWaybillDtoArWithMockWagonDetailDto(String waybillNumber) {
        return createWaybillDtoAr(waybillNumber, TransportType.VAGON_FERROVIARIO, mock(WagonDetailDTO.class));
    }

    private WaybillDtoAr createWaybillDtoArWithTruckDetailDto(String waybillNumber) {
        return createWaybillDtoAr(waybillNumber, TransportType.TRANSPORTE_AUTOMOTOR, new TruckDetailDTO());
    }

    private WaybillDtoAr createWaybillDtoArWithWagonDetailDto(String waybillNumber) {
        return createWaybillDtoAr(waybillNumber, TransportType.VAGON_FERROVIARIO, new WagonDetailDTO());
    }

    private WaybillDtoAr createWaybillDtoAr(String waybillNumber, TransportType transportType, LoadDetailDTO loadDetailDTO) {
        WaybillDtoAr waybillDtoAr = createWaybillDtoAr(waybillNumber);
        if(transportType != null) {
            waybillDtoAr.setWaybillType(transportType.getDescriptionCode());
        }
        waybillDtoAr.getLoadDetails().add(loadDetailDTO);
        return waybillDtoAr;
    }

    private WaybillDtoAr createWaybillDtoAr(String waybillNumber) {
        WaybillDtoAr waybillDtoAr = new WaybillDtoAr();
        waybillDtoAr.setWaybillNumber(waybillNumber);
        List<LoadDetailDTO> loadDetails = new ArrayList<LoadDetailDTO>();
        waybillDtoAr.setLoadDetails(loadDetails);
        return waybillDtoAr;
    }

}