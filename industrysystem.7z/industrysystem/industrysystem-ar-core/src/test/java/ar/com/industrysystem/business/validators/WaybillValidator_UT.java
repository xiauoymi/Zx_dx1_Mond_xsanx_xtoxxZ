package ar.com.industrysystem.business.validators;

import ar.com.industrysystem.business.dtos.WaybillDtoAr;
import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.business.CropService;
import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.WagonDetailDTO;
import com.industrysystem.business.dtos.WaybillDto;
import com.industrysystem.business.validators.DocumentValidator;
import com.industrysystem.entities.Crop;
import com.industrysystem.entities.TransportType;
import com.industrysystem.entities.WagonLoadDetail;
import com.industrysystem.entities.Waybill;
import com.industrysystem.exceptions.*;
import com.industrysystem.persistence.daos.LoadDetailDao;
import com.industrysystem.persistence.daos.WaybillDao;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * User: AVIER
 * Date: 1/15/14
 * Time: 10:03 AM
 */
@RunWith(MockitoJUnitRunner.class)
public class WaybillValidator_UT {

    private static final Long WAYBILL_NUMBER = 2211456L;

    @Mock
    private DocumentValidator documentValidator;
    @Mock
    private CropService cropService;
    @Mock
    private WaybillDao waybillDao;
    @Mock
    private LoadDetailDao loadDetailDao;
    @InjectMocks
    private WaybillValidatorAr waybillValidator;

    @Test
    public void validateGivenAVValidWaybillDtoWhenICallValidateMethodInWaybillValidatorThenItValidatesMandatoryFields() throws WaybillNotFoundException, WaybillRegistrationException, InvalidDocumentNumberException {
        //@Given a WaybillDTO
        WaybillDto waybillDto = getWaybillDto();
        //@When I Call validateWaybill method
        waybillValidator.validate(waybillDto);
        //@Then validate method in documentValidator is called 4 times
        verify(documentValidator, times(4)).validate(anyString(), anyString());
    }

    @Test
    public void validateGivenAValidTransportTypeWhenIvalidateTransportTypeItShouldNotRaiseErrors() {
        //@Given a Transport Type
        String transportType = TransportType.TRANSPORTE_AUTOMOTOR.getDescriptionCode();
        //@When
        waybillValidator.validateTransportType(transportType);
        //@Then
        assertThat(waybillValidator.getErrors()).isEmpty();
    }

    @Test
    public void validateGivenACropCodWhenICallValidateCropCodeThenIsValidCropIsCalled() throws CropNotFoundException {
        //@Given a Crop Code
        String cropCode = "1";
        //@When a
        waybillValidator.validateCropCode(cropCode);
        //@Then
        verify(cropService, times(1)).findCropByCode(anyString());
    }

    @Test
    public void validateGivenAValidLoadDetailWhenICallValidateCtgThenItShouldNotRaiseError() {
        //@Given a Load
        String loadDetail = "1";
        //@When
        waybillValidator.validateCtg(loadDetail);
        //@Then
        assertThat(waybillValidator.getErrors()).isEmpty();
    }

    @Test
    public void validateGivenANonValidLoadDetailWhenICallValidateCtgThenItShouldRaiseError() {
        //@Given a Load
        String loadDetail = "1A";
        //@When
        waybillValidator.validateCtg(loadDetail);
        //@Then
        assertThat(waybillValidator.getErrors()).isNotEmpty();
    }

    @Test
    public void validateGivenALoadDetailWhenICallValidateWagonNumberItShouldNotRaiseError() throws WaybillNotFoundException {
        //@Given a Load
        String loadDetail = "1";
        //@Given A WaybillDto
        WaybillDto waybillDto = getWaybillDto();
        Waybill waybill = getWaybill();

        //@When
        when(waybillDao.findWaybillByWaybillNumber(WAYBILL_NUMBER)).thenReturn(waybill);
        waybillValidator.validateWagonNumber(loadDetail, waybillDto);
        //@Then
        assertThat(waybillValidator.getErrors()).isNotEmpty();
    }

    private WaybillDto getWaybillDto() {
        WaybillDtoAr waybillDtoAr = new WaybillDtoAr();
        waybillDtoAr.setWaybillNumber(WAYBILL_NUMBER.toString());
        waybillDtoAr.setHolderDocument("111");
        waybillDtoAr.setAddresseeDocument("111");
        waybillDtoAr.setDestinationDocument("111");
        waybillDtoAr.setCommercialSenderDocument("111");
        waybillDtoAr.setDestinationLocation(22L);
        waybillDtoAr.setOriginLocation(21L);
        waybillDtoAr.setLoadDetails(getLoadDetails());
        waybillDtoAr.setWaybillType(TransportType.VAGON_FERROVIARIO.getDescriptionCode());
        return waybillDtoAr;
    }

    private Crop createCrop(String string) {
        Crop crop = new Crop();
        crop.setCode(string);
        return crop;
    }

    private Waybill getWaybill() {
        Crop soja = createCrop("SOJA");
        Waybill waybill = new WaybillAr();

        waybill.setCrop(soja);
        waybill.setHolderDeclaredIsPod(false);
        waybill.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        WagonLoadDetail wagonLoadDetail = new WagonLoadDetail();
        wagonLoadDetail.setWagonNumber("1234");
        wagonLoadDetail.setWaybill(waybill);

        return waybill;
    }

    private List<LoadDetailDTO> getLoadDetails() {
        List<LoadDetailDTO> loadDetailDTOList = new ArrayList<LoadDetailDTO>();
        WagonDetailDTO wagonDetailDTO = new WagonDetailDTO();
        wagonDetailDTO.setDeclaredTechnology("22");
        wagonDetailDTO.setLoadIdentifier("AA12345678");
        wagonDetailDTO.setSampleCode("SCOD1");
        wagonDetailDTO.setWagonsQty("3");
        loadDetailDTOList.add(wagonDetailDTO);

        return loadDetailDTOList;
    }

}