package ar.com.industrysystem.entities;

import com.industrysystem.entities.*;

/**
 * User: PPERA
 * Date: 1/3/14
 * Time: 2:49 PM
 */
public class WaybillBuilderAr extends WaybillBuilder {

    @Override
    public Waybill build() {
        WaybillAr waybillAr = new WaybillAr();
        DocumentType docType = new DocumentType();
        docType.setCode(DOCUMENT_TYPE);
        waybillAr.setIntermediaryDocumentType(docType);

        waybillAr.setCommercialSenderDocument(new Document(DocumentType.CUIT, COMMERCIAL_SENDER_DOCUMENT_NUMBER));
        waybillAr.setPlantCode(PLANT_CODE);
        waybillAr.setWaybillNumber(WAYBILL_NUMBER);
        return initInternal(waybillAr);
    }

}