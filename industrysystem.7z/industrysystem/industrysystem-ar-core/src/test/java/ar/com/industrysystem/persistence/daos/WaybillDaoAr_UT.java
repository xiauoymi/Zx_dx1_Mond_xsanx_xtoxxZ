package ar.com.industrysystem.persistence.daos;

import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.entities.*;
import com.industrysystem.persistence.daos.WaybillDao;
import org.junit.Before;
import org.junit.Test;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.endsWith;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * User: ASEQU
 * Date: 1/14/14
 * Time: 2:44 PM
 */
public class WaybillDaoAr_UT {

    private static final String CUIT = "CUIT";
    private static final String CUIT_2028280787524 = "28078752";
    private TypedQuery<WaybillAr> query;
    private EntityManager entityManager;
    private WaybillDaoAr dao;
    private Grower grower;
    private DocumentType CuitDocumentType;
    private Document document;
    private Campaign dummyCampaign = new Campaign();

    @Before
    public void setUp() {
        this.query = mock(TypedQuery.class);
        this.entityManager = mock(EntityManager.class);
        this.dao = new WaybillDaoAr();
        this.CuitDocumentType = new DocumentType(CUIT);
        this.document = new Document(this.CuitDocumentType, CUIT_2028280787524);
        this.grower = new Grower();
        this.grower.setDocument(this.document);

        field("em").ofType(EntityManager.class).in(this.dao).set(this.entityManager);

        when(this.entityManager.createNamedQuery(WaybillDao.FIND_BY_NON_POD_PARTICIPANT_GROWER, WaybillAr.class)).thenReturn(this.query);
    }

    @Test
    public void testFindByReceiveCreateNamedQueryWaybillArClassAndFIND_BY_NON_POD_PARTICIPANT_GROWER_WhenCallsWithAnyGrowerAndCompany() {
        // @Given

        // @When
        this.dao.findBy(this.grower, this.dummyCampaign);

        // Then
        verify(this.entityManager).createNamedQuery(WaybillDaoAr.FIND_BY_NON_POD_PARTICIPANT_GROWER, WaybillAr.class);
    }

    @Test
    public void testFindByReceiveSetParameterHolderDocumentAndCuit_WhenCallsWithAnyGrowerAndCompany() {
        // @Given
        // @When
        this.dao.findBy(this.grower, this.dummyCampaign);

        // @Then
        verify(this.query).setParameter("holderDocument", CUIT_2028280787524);
    }

    @Test
    public void testFindByReceiveSetParameterCampaignAndAnyCampaign_WhenCallsWithAnyGrowerAndCompany() {
        // @Given

        // @When
        this.dao.findBy(this.grower, this.dummyCampaign);

        // @Then
        verify(this.query).setParameter("campaign", this.dummyCampaign);
    }
}
