package ar.com.industrysystem.persistence.daos;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.junit.Before;
import org.junit.Test;

import ar.com.industrysystem.entities.WaybillAr;
import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.WaybillNotFoundException;

/**
 * User: PMIRIB
 * Date: 26/09/13
 * Time: 15:35
 */
public class WaybillsDaoAr_UT {

    private EntityManager entityManager;
    private WaybillDaoAr waybillDao;
    private TypedQuery<WaybillAr> query;

    @Before
    public void setUp(){
        this.entityManager = mock(EntityManager.class);
        this.waybillDao = new WaybillDaoAr();
        field("em").ofType(EntityManager.class).in(this.waybillDao).set(this.entityManager);
        this.query = mock(TypedQuery.class);
        when(this.entityManager.createNamedQuery(anyString(), eq(WaybillAr.class))).thenReturn(this.query);
        when(this.entityManager.createQuery(anyString())).thenReturn(this.query);
    }

    @Test
    public void testWaybillFound_WhenFindingWaybillByWaybillNumber() throws Exception {
        // @Given a waybill number
        Long waybillNumber = 123L;

        WaybillAr expected = new WaybillAr();
        when(this.query.getSingleResult()).thenReturn(expected);

        // @When finding the waybill by the waybill number
        WaybillAr result = (WaybillAr) this.waybillDao.findWaybillByWaybillNumber(waybillNumber);

        // @Then the query result is returned
        assertThat(result).isEqualTo(expected);
        // Have to assert that the waybillNumber parameter was set to the query with the correct number.
    }

    @Test
    public void testWaybillNotFound_WhenFindingWaybillByWaybillNumber() throws Exception {
        // @Given a waybill number
        Long waybillNumber = 123L;

        new WaybillAr();
        when(this.query.getSingleResult()).thenThrow(new PersistenceException());

        // @When finding the waybill by the waybill number
        try {
            this.waybillDao.findWaybillByWaybillNumber(waybillNumber);
            fail("Should have thrown an exception");
        } catch (PersistenceException ex) {
            // @Then the exception is thrown and what else?
            assertThat(true);
        }
    }

    @Test
	public void testWithoutResult_FindWaybillByWaybillNumber() {
		// Given a waybillnumber
		Long waybillNumber = 54166861L;

		// When find a waybill for waybillnumber
		field("query").ofType(TypedQuery.class).in(this.waybillDao).set(this.query);
		doThrow(NoResultException.class).when(query).getSingleResult();
		try {
			waybillDao.findWaybillByWaybillNumber(waybillNumber);
			fail();
		// Then return not found exception
		} catch (WaybillNotFoundException e) {
			assertThat(e.getErrors().contains(BusinessError.INVALID_DOCUMENT));
		}
	}

}