package ar.com.industrysystem.security;

import ar.com.industrysystem.security.mappers.ISUserAttributesMapperArImpl;
import com.industrysystem.security.mappers.ISUserAttributesMapper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.ldap.core.AttributesMapper;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;

/**
 * User: PPERA
 * Date: 1/9/14
 * Time: 2:02 PM
 */
public class LdapHelperArImpl_UT {

    private LdapHelperArImpl ldapHelper;

    @Before
    public void setUp(){
        this.ldapHelper = new LdapHelperArImpl();
    }

    @Test
    public void testGetLdapRootReturnsJohn_WhenLdapRootIsJohn() {
        // @Given ldap root is John
        field("ldapRoot").ofType(String.class).in(this.ldapHelper).set("John");

        // @When getting the ldapRoot
        String ldapRoot = this.ldapHelper.getLdapRoot();

        // @Then John is returned
        assertThat(ldapRoot).isEqualTo("John");
    }

    @Test
    public void testGetLdapRootReturnsTobi_WhenLdapRootIsTobi() {
        // @Given ldap root is John
        field("ldapRoot").ofType(String.class).in(this.ldapHelper).set("Tobi");

        // @When getting the ldapRoot
        String ldapRoot = this.ldapHelper.getLdapRoot();

        // @Then John is returned
        assertThat(ldapRoot).isEqualTo("Tobi");
    }

    @Test
    public void testNewISUserAttributeMapperReturnsArImplInstance_WhenCreatingANewISUserAttributeMapper() {
        // @Given

        // @When creating a new mapper
        AttributesMapper attributesMapper = this.ldapHelper.newISUserAttributesMapper();

        // @Then John is returned
        assertThat(attributesMapper).isInstanceOf(ISUserAttributesMapperArImpl.class);
    }
}
