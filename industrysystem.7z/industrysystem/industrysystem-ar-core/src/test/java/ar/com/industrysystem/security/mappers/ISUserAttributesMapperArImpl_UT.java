package ar.com.industrysystem.security.mappers;


import org.junit.Before;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;

/**
 * User: PPERA
 * Date: 1/9/14
 * Time: 1:56 PM
 */
public class ISUserAttributesMapperArImpl_UT {

    private ISUserAttributesMapperArImpl mapper;

    @Before
    public void setUp(){
        this.mapper = new ISUserAttributesMapperArImpl();
    }

    @Test
    public void testGetLdapRootReturnsJohn_WhenLdapRootIsJohn() {
        // @Given ldap root is John
        field("ldapRoot").ofType(String.class).in(this.mapper).set("John");

        // @When getting the ldapRoot
        String ldapRoot = this.mapper.getLdapRoot();

        // @Then John is returned
        assertThat(ldapRoot).isEqualTo("John");
    }

    @Test
    public void testGetLdapRootReturnsTobi_WhenLdapRootIsTobi() {
        // @Given ldap root is John
        field("ldapRoot").ofType(String.class).in(this.mapper).set("Tobi");

        // @When getting the ldapRoot
        String ldapRoot = this.mapper.getLdapRoot();

        // @Then John is returned
        assertThat(ldapRoot).isEqualTo("Tobi");
    }
}
