requirejs.config({
    baseUrl: location.pathname.substring(0, location.pathname.indexOf('/spring', 1)) + '/resources/lib',
    paths: {
        fuelux: 'fuelux/dist',
        jquery: 'jquery-proxy'
    }
});

$('[data-toggle="tooltip"]').tooltip({
    container: "body"
});

$('[data-toggle="popover"]').popover({
    container: "body"
});

var app = angular.module('IndustrySystem', [
    'ngResource',
    'ngAnimate',
    'ewTable',
    'ew.ui.wizard',
    'is.services.api',
    'is.services.modal',
    'is.services.session',
    'is.services.waybill',
    'is.services.config',
    'is.services.message',
    'is.validation.cuit',
    'is.validation.integer',
    'is.validation.float',
    'is.validation.minValue',
    'is.validation.maxValue',
    'is.directives.form',
    'is.directives.preventDefault',
    'filters.moment',
    '$strap.directives',
    'ui.router',
    'autofillFix',
    'chieffancypants.loadingBar',
    'angular-flash.service',
    'angular-flash.flash-alert-directive',
    'is.validation.unique', // 2014-01-30 - Card #39
    'filters.weight', // 2014-01-31 - Card #48
    'is.services.document', // 2014-02-05 - Card #30
    'is.services.envelope',
    'is.services.data',
    'is.services.table',
    'is.directives.table.customFilters',
    'vcRecaptcha',
    'is.filters.document',
    'is.validation.passwordStrength',
    'is.validation.match'
]);

app.config(['$httpProvider', '$stateProvider', '$urlRouterProvider', 'cfpLoadingBarProvider',
    function ($httpProvider, $stateProvider, $urlRouterProvider, cfpLoadingBarProvider) {
        $urlRouterProvider.otherwise('/');
        cfpLoadingBarProvider.includeSpinner = false;
        $httpProvider.interceptors.push('errorHttpInterceptor');
    }]);

app.run(['$rootScope', '$state', '$stateParams', '$window', '$location', 'Session', 'Config', 'ISModalService',
    'MessageService',
    function ($rootScope, $state, $stateParams, $window, $location, Session, Config, ISModalService, MessageService) {
        $rootScope.$state = $state;
        $rootScope.$stateParams = $stateParams;
        $rootScope.Config = Config;
        $rootScope.Session = Session;
        $rootScope.MessageService = MessageService;

        $rootScope.$on('$stateChangeStart', function (event, toState, fromState, fromParams) {
            return;
            var isSecured = (!toState.data || toState.data.secure !== false);

            if (isSecured && !Session.user) {
                event.preventDefault();
                if (toState.data && toState.data.loginState) {
                    $state.go(toState.data.loginState);
                } else {
                    $location.url('/');
                }
            }
        });

        $rootScope.$on('requestError', function (event, message, code) {
            if (code == 401) {
                ISModalService.alert($rootScope, 'Su sesión ha expirado.').then(function () {
                    window.location = '/login';
                });
            } else {
                ISModalService.error($rootScope, message, code);
            }

        });
    }]);

app.factory('errorHttpInterceptor', ['$q', '$rootScope', function ($q, $rootScope) {
    return {
        'responseError': function (rejection) {
            var code = rejection.status;
            var message = 'Error desconocido.';

            if (rejection.data.error) {
                var errorMessages=rejection.data.error.messages;
                message='';
                for (m in errorMessages){
                    code = rejection.data.error.code;
                    message += errorMessages[m].description + '\n';
                }
            } else {
                message = rejection.data;
            }

            $rootScope.$emit('requestError', message, code);

            return $q.reject(rejection);
        }
    };
}]);

app.controller('LoginCtrl', ['$scope', function ($scope) {
    $scope.displayFormErrors = false;

    $scope.formHasError = function (formName) {
        formName = formName || 'form';

        var form = $scope[formName];

        if (!$scope[formName]) {
            return false;
        }

        return form.$invalid;
    };

    $scope.fieldHasError = function (fieldName, errorType, formName) {
        if (!$scope.displayFormErrors) {
            return false;
        }

        formName = formName || 'form';

        var form = $scope[formName];

        if (!form) {
            return false;
        }

        var field = form[fieldName];

        if (!field) {
            return false;
        }

        if (!field.$invalid) {
            return false;
        }

        if (!errorType) {
            return true;
        }

        return field.$error[errorType];
    };

    $scope.submit = function () {
        $scope.displayFormErrors = true;

        return false;
    };
}
]);


app.controller('LoggedUserCtrl', ['$scope', function ($scope) {
    $scope.loggedUser = {
        type: ''
    };
}
]);

app.controller('TechnologiesCtrl', ['$scope', 'Api', function ($scope, Api) {
    $scope.technologies = Api.Technology.query();
}]);