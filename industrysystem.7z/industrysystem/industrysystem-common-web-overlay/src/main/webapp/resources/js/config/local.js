angular.module('is.services.config')
    .run(['Config', function (Config) {
        Config.set('RECAPTCHA_PUBLIC_KEY', '6LcHJO8SAAAAAEu62LtpvieMOq0xDjWEcvyHVayq');

        // SERVICES
        var CONTEXT_PATH = location.pathname.substring(0, location.pathname.indexOf('/spring', 1));

        Config.set('CONTEXT_PATH', CONTEXT_PATH);
        Config.set('API_URL', CONTEXT_PATH + '/spring/rest/');

        Config.set('SERVICE_POD_DESTINATIONS', Config.get('API_URL') + 'pods/destinations.json');
        Config.set('SERVICE_POD_WAYBILL', Config.get('API_URL') + 'waybills/:waybill.json');
        Config.set('SERVICE_POD_WAYBILL_ACTIVE', Config.get('API_URL') + 'waybillListing.json');
        Config.set('SERVICE_POD_WAYBILL_PENDING', Config.get('API_URL') + 'pods/waybills/pending.json');
        Config.set('SERVICE_POD_WAYBILL_BATCH_LOAD', Config.get('API_URL') + 'waybills/batch-load');
        Config.set('SERVICE_POD_TEST_RESULT_BATCH_LOAD', Config.get('API_URL') + 'test-result/batch-load');
        Config.set('SERVICE_POD_WAYBILL_VALIDATE_NUMBER', Config.get('API_URL') + 'waybills/validate.json');
        Config.set('SERVICE_POD_WAYBILL_TEST_RESULT_BATCH_LOAD', Config.get('API_URL') + 'test-result/batch-load');
        Config.set('SERVICE_POD_WAYBILL_EVENTS', Config.get('API_URL') + 'waybillListingEvents.json');
        Config.set('SERVICE_POD_WAYBILL_STATUS_VALUES', Config.get('API_URL') + 'waybillStatusValues.json');

        Config.set('SERVICE_GROWER_WAYBILL_ACTIVE', Config.get('API_URL') + 'waybillListingGrower.json');

        Config.set('SERVICE_TRAIT_OWNER_WAYBILL_ACTIVE', Config.get('API_URL') + 'waybillListingTraitOwner.json');

        Config.set('SERVICE_STATE', Config.get('API_URL') + 'provinces.json');
        Config.set('SERVICE_CITY', Config.get('API_URL') + 'provinces/:province/cities.json');
        Config.set('SERVICE_CROP', Config.get('API_URL') + 'grains.json');
        Config.set('SERVICE_TECHNOLOGY', Config.get('API_URL') + 'technologies.json');
        Config.set('SERVICE_CUIT', Config.get('API_URL') + 'pods/:cuit/name.json');
        Config.set('SERVICE_ADDRESSEE_CUIT', Config.get('API_URL') + 'pods/:cuit/addresseeName.json');
        Config.set('SERVICE_PLANT', Config.get('API_URL') + 'pods/:plantCode/exists.json');
        Config.set('SERVICE_LABORATORY', Config.get('API_URL') + 'laboratories.json');
        Config.set('SERVICE_LABORATORY_ORDER_ACTIVE', Config.get('API_URL') + 'technology/testResultListing.json');

        Config.set('SERVICE_DOCUMENT', Config.get('API_URL') + 'pods/:document/:type/name.json');
        Config.set('SERVICE_ADDRESSEE_DOCUMENT', Config.get('API_URL') + 'pods/:document/:type/addresseeName.json');

        Config.set('SERVICE_PASSWORD_RECOVERY_REQUEST', '../../data/passwordRecoveryRequest.json');

        // PARTIALS
        Config.set('PARTIALS_HOME', 'home.jsp');

        Config.set('PARTIALS_ADMIN', 'admin/secured/admin.jsp');
        Config.set('PARTIALS_ADMIN_LOGIN', 'admin/login.jsp');
        Config.set('PARTIALS_ADMIN_DASHBOARD', 'admin/secured/dashboard.jsp');
        Config.set('PARTIALS_ADMIN_PARTICIPANT', 'admin/secured/participant.jsp');

        Config.set('PARTIALS_AGENT', 'admin.jsp');

        Config.set('PARTIALS_LABORATORY', 'laboratory.jsp');
        Config.set('PARTIALS_LABORATORY_MENU', 'laboratory/menu.jsp');
        Config.set('PARTIALS_LABORATORY_LOGIN', 'laboratory/login.jsp');
        Config.set('PARTIALS_LABORATORY_ORDER', 'laboratory/secured/order.jsp');
        Config.set('PARTIALS_LABORATORY_ORDER_RESULT', 'include/laboratory/secured/order/result.jsp');
        Config.set('PARTIALS_LABORATORY_SUMMARY', 'laboratory/secured/summary.jsp');

        Config.set('PARTIALS_COMMON_TECHNOLOGIES', 'common/technologies.jsp');
        Config.set('PARTIALS_COMMON_LOGIN', 'common/login.jsp');
        Config.set('PARTIALS_COMMON_WARNING_MONSANTO', 'common/warning-monsanto-portal.jsp');
        Config.set('PARTIALS_COMMON_PRIVACY', 'include/common/privacy.jsp');
        Config.set('PARTIALS_COMMON_TERMS', 'include/common/terms.jsp');
        Config.set('PARTIALS_COMMON_FOOTER', 'include/common/footer.jsp');
        Config.set('PARTIALS_COMMON_ABOUT_US', 'include/common/about-us.jsp');

        Config.set('PARTIALS_LABORATORY_RESULT_LOAD', 'laboratorio/carga-resultado.jsp');
        Config.set('PARTIALS_LABORATORY_WAYBILL_BATCH_LOAD', 'laboratory/secured/bulk/upload.jsp');

        Config.set('PARTIALS_GROWER', 'grower.jsp');
        Config.set('PARTIALS_GROWER_MENU', 'grower/menu.jsp');
        Config.set('PARTIALS_GROWER_LOGIN', 'grower/login.jsp');
        Config.set('PARTIALS_GROWER_SUMMARY', 'grower/secured/summary.jsp');
        Config.set('PARTIALS_GROWER_MANAGEMENT', 'grower/secured/management.jsp');
        Config.set('PARTIALS_GROWER_WAYBILL', 'grower/secured/waybill.jsp');
        Config.set('PARTIALS_GROWER_WAYBILL_LIST', 'include/grower/secured/waybill/list.jsp');
        Config.set('PARTIALS_GROWER_WAYBILL_DETAIL', 'grower/secured/waybill/detail.jsp');
        Config.set('PARTIALS_GROWER_AVAILABLE_TECHNOLOGY_DETAIL', 'grower/secured/summary/available-technology-detail.jsp');
        Config.set('PARTIALS_GROWER_PROVIDED_TECHNOLOGY', 'grower/secured/summary/provided-technology.jsp');

        Config.set('PARTIALS_POD', 'pod.jsp');
        Config.set('PARTIALS_POD_MENU', 'pod/menu.jsp');
        Config.set('PARTIALS_POD_LOGIN', 'pod/login.jsp');
        Config.set('PARTIALS_POD_WAYBILL', 'pod/secured/waybill.jsp');
        Config.set('PARTIALS_POD_SUMMARY', 'pod/secured/summary.jsp');
        Config.set('PARTIALS_POD_WAYBILL_LIST_CENTRAL', 'pod/secured/waybill/list-central.jsp');
        Config.set('PARTIALS_POD_WAYBILL_LIST', 'include/pod/secured/waybill/list.jsp');
        Config.set('PARTIALS_POD_WAYBILL_ACTIVE', 'include/pod/secured/waybill/active.jsp');
        Config.set('PARTIALS_POD_WAYBILL_BATCH_LOAD', 'pod/secured/waybill/bulk/upload.jsp');
        Config.set('PARTIALS_POD_WAYBILL_BATCH_LOAD_RETRY_WAYBILL', 'partials/pod/secured/waybill/bulk/edit_waybill.jsp');
        Config.set('PARTIALS_POD_WAYBILL_BATCH_LOAD_RETRY_SAMPLE', '/pod/secured/waybill/bulk/edit_result.jsp');
        Config.set('PARTIALS_POD_WAYBILL_LOAD', 'pod/secured/waybill/upload.jsp');
        Config.set('PARTIALS_POD_WAYBILL_WEIGHT_AND_SAMPLE', 'include/pod/secured/waybill/weight-and-sample.jsp');
        Config.set('PARTIALS_POD_WAYBILL_DETAIL', 'include/pod/secured/waybill/detail.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_CENTRAL', 'pod/secured/waybill/upload/load-detail-central.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_SUMMARY_CENTRAL', 'pod/secured/waybill/upload/load-detail-summary-central.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_TRANSPORTE AUTOMOTOR', 'pod/secured/waybill/upload/load-detail-truck.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_TRUCK', 'pod/secured/waybill/upload/load-detail-truck.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_TRAIN', 'pod/secured/waybill/upload/load-detail-train.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_VAGON FERROVIARIO', 'pod/secured/waybill/upload/load-detail-train.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_ROW_TRAIN', 'pod/secured/waybill/upload/load-detail-train-row.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_SUMMARY_TRANSPORTE AUTOMOTOR', 'pod/secured/waybill/upload/load-detail-summary-truck.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_SUMMARY_VAGON FERROVIARIO', 'pod/secured/waybill/upload/load-detail-summary-train.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_SUMMARY_ROW_TRUCK', 'pod/secured/waybill/upload/load-detail-summary-truck-row.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_LOAD_DETAIL_SUMMARY_ROW_TRAIN', 'pod/secured/waybill/upload/load-detail-summary-train-row.jsp');
        Config.set('PARTIALS_POD_WAYBILL_BATCH_LOAD_ERRORS', 'pod/secured/waybill/bulk/upload/errors.jsp');

        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_TRANSPORT_TYPES', 'include/pod/secured/waybill/upload/transport-types.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_MAIN_DATA', 'include/pod/secured/waybill/upload/main-data.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_INTERVENING', 'include/pod/secured/waybill/upload/intervening.jsp');
        Config.set('PARTIALS_POD_WAYBILL_UPLOAD_SUMMARY', 'include/pod/secured/waybill/upload/summary.jsp');

        Config.set('PARTIALS_TRAIT_OWNER', 'trait-owner.jsp');
        Config.set('PARTIALS_TRAIT_OWNER_LOGIN', 'trait-owner/login.jsp');
        Config.set('PARTIALS_TRAIT_OWNER_WAYBILL', 'trait-owner/secured/waybill.jsp');
        Config.set('PARTIALS_TRAIT_OWNER_WAYBILL_LIST', 'trait-owner/secured/waybill/list.jsp');

        Config.set('PARTIALS_ACCOUNT', 'account.jsp');
        Config.set('PARTIALS_ACCOUNT_PASSWORD_RECOVERY', 'account/password-recovery.jsp');
        Config.set('PARTIALS_ACCOUNT_PASSWORD_CHANGE', 'account/password-change.jsp');
    }]);