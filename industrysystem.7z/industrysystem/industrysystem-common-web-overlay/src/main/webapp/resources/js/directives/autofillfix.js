angular.module('autofillFix', [])
    .directive('autofillFix', ['$timeout', function($timeout) {
        return {
            restrict: 'A',
            link: function(scope, element, attr) {
                var $fields = $('input,select,textarea', element);
                $fields.each(function(index, el) {
                    var $el = $(el);
                    $el.on('change.autofill DOMAttrModified.autofill keydown.autofill propertychange.autofill', function(e) {
                        $timeout(function() {
                            if($el.val() !== '') {
                                $el.trigger('input');
                            }
                        }, 0);
                    });
                });
            }
        }
    }]);
