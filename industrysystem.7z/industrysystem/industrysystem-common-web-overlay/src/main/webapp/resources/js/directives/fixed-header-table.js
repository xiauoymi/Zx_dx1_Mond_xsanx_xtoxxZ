angular.module('jquery.fixed-header-table', [])
    .directive('fixedHeaderTable', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                $(element).fixedHeaderTable({ footer: false, cloneHeadToFoot: false, fixedColumn: false });
            }
        }
    });