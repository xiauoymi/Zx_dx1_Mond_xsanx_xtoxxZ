angular.module('is.directives.form', [])
    .directive('isForm', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var validationFn = attrs.isForm;
                element.on('submit', function () {
                    if (validationFn) {
                        return scope.$apply(validationFn);
                    }
                    return true;
                });
            }
        };
    });