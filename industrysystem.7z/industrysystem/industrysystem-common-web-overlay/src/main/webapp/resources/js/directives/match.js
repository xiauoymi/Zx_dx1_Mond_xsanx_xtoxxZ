angular.module('is.validation.match', [])
    .directive('match', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            require: '?ngModel',
            link: function (scope, element, attrs, ngModel) {
                if (!ngModel) {
                    return;
                }

                if (!attrs.match) {
                    return;
                }

                var firstPassword = $parse(attrs.match);

                var validator = function (value) {
                    var temp = firstPassword(scope),
                        v = !value || value === temp;
                    ngModel.$setValidity('match', v);
                    return value;
                }

                ngModel.$parsers.unshift(validator);
                //ngModel.$formatters.push(validator);

            }
        }
    }]);