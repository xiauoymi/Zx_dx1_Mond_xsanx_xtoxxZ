angular.module('is.validation.minValue', [])
    .directive('minValue', function () {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function(scope, elem, attr, ctrl) {
                scope.$watch(attr.minValue, function(){
                    ctrl.$setViewValue(ctrl.$viewValue);
                });
                var minValidator = function(value) {
                    var min = scope.$eval(attr.minValue) || 0;
                    if (!(angular.isUndefined(value) || value === '' || value === null || value !== value) && value < min) {
                        ctrl.$setValidity('minValue', false);
                        return undefined;
                    } else {
                        ctrl.$setValidity('minValue', true);
                        return value;
                    }
                };

                ctrl.$parsers.push(minValidator);
                ctrl.$formatters.push(minValidator);
            }
        };
    });
