angular.module('is.directives.preventDefault', [])
    .directive('isPreventDefault', [function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                var tag = attrs.isPreventDefault || 'a';
                $(tag, element).click(function (e) {
                    e.preventDefault();
                });
            }
        };
    }]);