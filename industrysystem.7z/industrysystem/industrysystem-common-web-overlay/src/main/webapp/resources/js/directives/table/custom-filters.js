angular.module('is.directives.table.customFilters', [])
    .factory('isTableFilterIntervening', ['ewFilterBase', function (ewFilterBase) {
        return angular.extend({}, ewFilterBase, {
            type: 'intervening',
            template: '<div class="ew-table-filter-form">' +
                '<div class="ew-table-filter-header clearfix"><button type="button" class="close" data-dismiss="popover" aria-hidden="true">&times;</button></div>' +
                '<div class="form-group">' +
                '<label>Nombre</label>' +
                '<input type="text" name="name" class="form-control" data-ng-model=\'filter.name\'>' +
                '</div>' +
                '<div class="form-group">' +
                '<label>Documento</label>' +
                '<input type="text" name="document" class="form-control" data-ng-model=\'filter.document\'>' +
                '</div>' +
                '<div class="form-group">' +
                '<a class="btn btn-success btn-sm btn-filter-apply">Aplicar</a> ' +
                '<a class="btn btn-default btn-sm btn-filter-clear">Quitar</a>' +
                '</div>' +
                '</div>',
            isEmpty: function () {
                var filterValue = this.getValue();
                return this.isEmptyValue(filterValue.name) && this.isEmptyValue(filterValue.document);
            },
            initDirtyCheck: function () {
                var self = this;

                var evalDirty = function (value, oldValue) {
                    if (!self.dirty && !(self.isEmptyValue(value) && self.isEmptyValue(oldValue)) && value != oldValue) {
                        self.dirty = true;
                    }
                }

                this.scope.$watch('filter.name', function (value, oldValue) {
                    evalDirty(value, oldValue);
                });

                this.scope.$watch('filter.document', function (value, oldValue) {
                    evalDirty(value, oldValue);
                });
            },
            serialize: function () {
                var filterValue = this.getValue();

                if (!_.isObject(filterValue)) {
                    return null;
                }

                var filters = [];

                if (filterValue.name) {
                    filters.push({
                        field: this.attrs.nameField,
                        type: null,
                        comparison: 'eq',
                        value: filterValue.name
                    });
                }

                if (filterValue.document) {
                    filters.push({
                        field: this.attrs.documentField,
                        type: null,
                        comparison: 'eq',
                        value: filterValue.document
                    });
                }

                return filters;
            }
        });
    }])
    .factory('isTableFilterIdentifier', ['ewFilterBase', function (ewFilterBase) {
        return angular.extend({}, ewFilterBase, {
            type: 'identifier',
            template: '<div class="ew-table-filter-form">' +
                '<div class="ew-table-filter-header clearfix"><button type="button" class="close" data-dismiss="popover" aria-hidden="true">&times;</button></div>' +
                '<div class="form-group">' +
                '<label>{{mainLabel}}</label>' +
                '<input type="text" name="main" class="form-control" data-ng-model=\'filter.main\'>' +
                '</div>' +
                '<div class="form-group" data-ng-show=\'false\'>' +
                '<label>{{secondaryLabel}}</label>' +
                '<input type="text" name="secondary" class="form-control" data-ng-model=\'filter.secondary\'>' +
                '</div>' +
                '<div class="form-group">' +
                '<a class="btn btn-success btn-sm btn-filter-apply">Aplicar</a> ' +
                '<a class="btn btn-default btn-sm btn-filter-clear">Quitar</a>' +
                '</div>' +
                '</div>',
            initScope: function () {
                this.scope.mainLabel = this.attrs.mainLabel;
                this.scope.secondaryLabel = this.attrs.secondaryLabel;
            },
            isEmpty: function () {
                var filterValue = this.getValue();
                return this.isEmptyValue(filterValue.main) && this.isEmptyValue(filterValue.secondary);
            },
            initDirtyCheck: function () {
                var self = this;

                var evalDirty = function (value, oldValue) {
                    if (!self.dirty && !(self.isEmptyValue(value) && self.isEmptyValue(oldValue)) && value != oldValue) {
                        self.dirty = true;
                    }
                };

                this.scope.$watch('filter.main', function (value, oldValue) {
                    evalDirty(value, oldValue);
                });

                this.scope.$watch('filter.secondary', function (value, oldValue) {
                    evalDirty(value, oldValue);
                });
            },
            serialize: function () {
                var filterValue = this.getValue();

                if (!_.isObject(filterValue)) {
                    return null;
                }

                var filters = [];

                if (filterValue.main) {
                    filters.push({
                        field: this.attrs.mainField,
                        type: null,
                        comparison: 'eq',
                        value: filterValue.main
                    });
                }

                if (filterValue.secondary) {
                    filters.push({
                        field: this.attrs.secondaryField,
                        type: null,
                        comparison: 'eq',
                        value: filterValue.secondary
                    });
                }

                return filters;
            }
        });
    }])
    .run(['ewFilter',
        'isTableFilterIntervening',
        'isTableFilterIdentifier',
        function (ewFilterProvider, isTableFilterIntervening,isTableFilterIdentifier) {
            ewFilterProvider.registerFilter('intervening', isTableFilterIntervening);
            ewFilterProvider.registerFilter('identifier', isTableFilterIdentifier);
        }]);
