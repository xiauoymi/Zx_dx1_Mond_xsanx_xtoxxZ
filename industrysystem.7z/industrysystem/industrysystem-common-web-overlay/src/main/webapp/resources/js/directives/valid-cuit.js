"use strict";
angular.module('is.validation.cuit', ['is.services.document']).
    directive('validCuit', ['CuitValidator', function (CuitValidator) {
        return {
            restrict: 'A',
            require: 'ngModel',
            ngModelAs: 'validCuit',
            link: function (scope, element, attr, ngModel) {
                var cache = '';
                var externalFn = attr.validCuit;
                var required = attr.required;

                function validate(cuit) {
                    if (cuit == cache) {
                        return;
                    }

                    cache = cuit;

                    // Si no se ingresa un cuit, resetar validaciones
                    if (!cuit) {
                        ngModel.$setValidity('cuit_complete', true);
                        ngModel.$setValidity('valid_cuit', true);
                        ngModel.$setValidity('validating', true);
                        ngModel.$setValidity('not_found', true);
                        return;
                    }

                    var isComplete = $(element).inputmask('isComplete');

                    // Solo validar si se completo el campo
                    if (isComplete) {
                        ngModel.$setValidity('cuit_complete', true);
                        ngModel.$setValidity('valid_cuit', CuitValidator.validate(cuit));
                        ngModel.$setValidity('validating', true);
                        ngModel.$setValidity('not_found', true);

                        if (!externalFn) {
                            return;
                        }

                        // Solo validar si no falló otra validación
                        if (ngModel.$valid) {
                            var response = scope.$eval(externalFn);

                            if (response && (response.$promise || response.promise)) {
                                ngModel.$setValidity('validating', false);

                                var promise = response.$promise || response.promise;

                                promise.then(
                                    function (found) {
                                        ngModel.$setValidity('valid_cuit', true);
                                        ngModel.$setValidity('validating', true);
                                        ngModel.$setValidity('not_found', found);
                                    },
                                    function () {
                                        ngModel.$setValidity('valid_cuit', false);
                                        ngModel.$setValidity('validating', true);
                                        ngModel.$setValidity('not_found', true);
                                    }
                                );
                            } else {
                                if (response == true) {
                                    ngModel.$setValidity('valid_cuit', true);
                                    ngModel.$setValidity('validating', true);
                                    ngModel.$setValidity('not_found', true);
                                } else {
                                    ngModel.$setValidity('valid_cuit', false);
                                    ngModel.$setValidity('validating', true);
                                    ngModel.$setValidity('not_found', true);
                                }
                            }
                        }
                    } else {
                        ngModel.$setValidity('cuit_complete', false);
                        ngModel.$setValidity('valid_cuit', !!(!required && !cuit));
                        ngModel.$setValidity('validating', true);
                        ngModel.$setValidity('not_found', true);
                    }
                }

                $(element).inputmask({
                    "mask": "99-99999999-9",
                    onKeyUp: function () {
                        var cuit = $(element).val();
                        scope.$apply(function () {
                            ngModel.$setViewValue(cuit);
                        });
                    }
                });

                scope.$watch(attr.ngModel, function (value) {
                    validate(value);
                });

            }
        };
    }]);
