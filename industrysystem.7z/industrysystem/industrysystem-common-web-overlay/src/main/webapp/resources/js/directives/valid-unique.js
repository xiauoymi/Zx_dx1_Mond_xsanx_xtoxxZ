// START 2014-01-30 - Card #39
"use strict";
angular.module('is.validation.unique', []).
    directive('validUnique', ['$parse', function ($parse) {
        return {
            restrict: 'A',
            require: 'ngModel',
            link: function (scope, element, attrs, ngModel) {
                var validate = function (value) {
                    ngModel.$setValidity('unique', true);

                    if (!ngModel.$valid) {
                        return;
                    }

                    var source = scope.$eval(attrs.validUniqueSource);
                    var property = attrs.validUniqueProperty;

                    if (!source)
                        return;

                    var values = [];

                    angular.forEach(source, function (v) {
                        if (property) {
                            var getter = $parse(property);
                            v = getter(v);
                        }
                        values.push(v);
                    });

                    if (countInArray(value, values) > 1) {
                        ngModel.$setValidity('unique', false);
                    }
                };

                var countInArray = function (needle, haystack) {
                    var count = 0;

                    angular.forEach(haystack, function (value) {
                        if (value == needle) {
                            count++;
                        }
                    });

                    return count;
                };

                scope.$watch(attrs.ngModel, function (value, oldValue) {
                    validate(value);
                });
            }
        };
    }]);
// END 2014-01-30 - Card #39
