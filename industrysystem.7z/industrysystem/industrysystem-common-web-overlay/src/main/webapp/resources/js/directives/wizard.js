var module = angular.module('ew.ui.wizard', []);

module.directive('wizard', [function () {
    return {
        restrict: 'A',
        controllerAs: 'wizard',
        controller: ['$scope', '$element', '$attrs', function ($scope, $element, $attrs) {
            var self = this;

            this.getCurrentStep = function () {
                var step = self.selectedItem();

                if (step) {
                    return step.step;
                }

                return 1;
            };

            this.selectedItem = function () {
                if (!$($element).wizard) {
                    return null;
                }

                return $($element).wizard('selectedItem');
            };

            this.next = function (validate) {
                if (!$($element).wizard) {
                    return;
                }

                if (validate === false) {
                    self.doValidate = false;
                }

                $($element).wizard('next');
            };

            this.previous = function () {
                if (!$($element).wizard) {
                    return;
                }

                $($element).wizard('previous');
            };

            this.isValid = true;
            this.doValidate = true;
        }],
        link: function (scope, element, attr, controller) {
            require(['fuelux/wizard'], function () {
                $(element).wizard();
            });

            element.bind('finished', function () {
                if (attr.finish) {
                    scope.$eval(attr.finish);
                }
            });

            element.bind('changed', function () {
                if (attr.changed) {
                    scope.$eval(attr.changed);
                }
            });

            element.bind('change', function (event, data) {
                    if (!data) {
                        return;
                    }

                    if (data.direction !== 'next') {
                        return;
                    }

                    if (attr.change && controller.doValidate) {
                        controller.isValid = false;
                        setTimeout(function () {
                            scope.$apply(function () {
                                var result = scope.$eval(attr.change);
                                if (result !== false) {
                                    event.preventDefault();
                                    controller.isValid = true;
                                    controller.doValidate = false;
                                    $(element).wizard('next');
                                }
                            });
                        }, 0);
                    }
                    else {
                        controller.isValid = true;
                        controller.doValidate = true;
                    }

                    if (!controller.isValid) {
                        event.preventDefault();
                    }
                }
            );
        }
    };
}]);