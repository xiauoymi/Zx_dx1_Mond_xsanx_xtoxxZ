angular.module('is.filters.document', [])
    .filter('document', ['DocumentService', function (DocumentService) {
        return function (digits, type) {
            if(digits === null || digits === undefined) {
                return "";
            }

            type = type ? ("" + type).toUpperCase() : 'CUIT';

            var validator = DocumentService.getValidator(type);

            if (!validator) {
                return digits;
            }

            return validator.addMask(digits);
        }
    }]);
