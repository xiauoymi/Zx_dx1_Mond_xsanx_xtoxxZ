var module = angular.module('filters.moment', []);

module.filter('moment', [function() {
    return function(input) {
        return moment(input).fromNow();
    }
}]);
