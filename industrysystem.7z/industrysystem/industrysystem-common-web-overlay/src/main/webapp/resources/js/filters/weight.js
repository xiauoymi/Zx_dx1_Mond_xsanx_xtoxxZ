// START 2014-01-31 - Card #48
angular.module('filters.weight', [])
    .filter('kgToTn', ['$filter', function ($filter) {
        return function (input) {
            var tn = input / 1000;
            return $filter('number')(tn);
        }
    }]);
// END 2014-01-31 - Card #48