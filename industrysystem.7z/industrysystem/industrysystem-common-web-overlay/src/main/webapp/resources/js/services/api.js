var api = angular.module('is.services.api', ['ngResource']);

api.factory('Api', ['$resource', 'Config', function ($resource, Config) {
    return {
        LaboratoryTest: $resource(Config.get('API_URL') + 'pendingtests', {}, {
            getPending: {
                method: 'GET',
                url: Config.get('API_URL') + 'pendingtests',
                isArray: true
            },
            getActive: {
                method: 'POST',
                url: Config.get('SERVICE_LABORATORY_ORDER_ACTIVE'),
                isArray: false
            }
        }),
        LaboratoryTestResult: $resource(Config.get('API_URL') + 'laboratory/test/result', {}, {
        }),
        LaboratorioMateriales: $resource(Config.get('API_URL') + 'laboratorios-gestion-de-materiales.json', {}, {
            pendientes: {
                method: 'GET',
                url: Config.get('API_URL') + 'laboratorios-gestion-de-materiales.json',
                isArray: true
            }
        }),
        PodWaybill: $resource(Config.get('SERVICE_POD_WAYBILL'), {waybill: '@id'}, {
            getActive: {
                method: 'POST',
                url: Config.get('SERVICE_POD_WAYBILL_ACTIVE'),
                isArray: false
            },
            getPending: {
                method: 'GET',
                url: Config.get('SERVICE_POD_WAYBILL_PENDING'),
                isArray: true
            },
            getEvents: {
                method: 'POST',
                url: Config.get('SERVICE_POD_WAYBILL_EVENTS'),
                isArray: false
            },
            getStatusValues: {
                method: 'GET',
                url: Config.get('SERVICE_POD_WAYBILL_STATUS_VALUES'),
                isArray: true
            },
            batchLoad: {
                method: 'POST',
                url: Config.get('SERVICE_POD_WAYBILL_BATCH_LOAD'),
                params: {waybill_ar: '@waybill'}
            },
            loadStoreSample: {
                method: 'POST',
                url: Config.get('SERVICE_POD_WAYBILL_LOAD_STORE_SAMPLE'),
                params: {load: '@load'}
            },
            validateNumber: {
                method: 'POST',
                url: Config.get('SERVICE_POD_WAYBILL_VALIDATE_NUMBER'),
                params: {waybillNumber: '@waybilllNumber'}
            },
            storeWeightAndSample: {
                method: 'PUT',
                url: Config.get('API_URL') + 'pods/waybills/:waybillNumber',
                params: {load: '@load'},
                isArray: true
            },
            testResultBatchLoad: {
                method: 'POST',
                url: Config.get('SERVICE_POD_WAYBILL_TEST_RESULT_BATCH_LOAD')
            }
        }),
        TraitOwnerWaybill: $resource(null, null, {
            getActive: {
                method: 'POST',
                url: Config.get('SERVICE_TRAIT_OWNER_WAYBILL_ACTIVE'),
                isArray: false
            }
        }),
        PodDestinations: $resource(Config.get('SERVICE_POD_DESTINATIONS')),
        Cuit: $resource(Config.get('SERVICE_CUIT'), {cuit: '@cuit'}),
        AddresseeCuit: $resource(Config.get('SERVICE_ADDRESSEE_CUIT'), {cuit: '@cuit'}),
        Grower: $resource(Config.get('API_URL') + 'grower/holder.json', {}, {
            brief: {
                method: 'GET',
                url: Config.get('API_URL') + 'grower/:documentNumber/:documentType/technology/:technologyCode',
                isArray: true
            },
            getWaybills: {
                method: 'GET',
                url: Config.get('API_URL') + 'grower/waybill.json',
                isArray: true
            }
        }),
        GrowerWaybill: $resource(null, null, {
            getActive: {
                method: 'POST',
                url: Config.get('SERVICE_GROWER_WAYBILL_ACTIVE'),
                isArray: false
            }
        }),
        Technology: $resource(Config.get('SERVICE_TECHNOLOGY')),
        State: $resource(Config.get('SERVICE_STATE')),
        City: $resource(Config.get('SERVICE_CITY'), {province: '@province'}),
        Crop: $resource(Config.get('SERVICE_CROP')),
        Plant: $resource(Config.get('SERVICE_PLANT'), {plantCode: '@plantCode'}),
        Laboratory: $resource(Config.get('SERVICE_LABORATORY')),
        Document: $resource(Config.get('SERVICE_DOCUMENT'), {document: '@document', type: 'type'}),
        AddresseeDocument: $resource(Config.get('SERVICE_ADDRESSEE_DOCUMENT'), {document: '@document', type: 'type'}),
        DocumentTypes: {

            CEDULA_CODE : "CEDULA",
            RUC_PJ_CODE : "RUC_PJ",
            RUC_SOCIEDAD_CODE : "RUC_SOCIEDAD",

            query: function () {
                return [
                    {
                        code: this.RUC_PJ_CODE,
                        description: 'RUC PF'
                    },
                    {
                        code: this.RUC_SOCIEDAD_CODE,
                        description: 'RUC SOCIEDAD'
                    },
                    {
                        code: this.CEDULA_CODE,
                        description: 'CÉDULA'
                    }
                ];
            }
        },
        PasswordRecoveryRequest: $resource(Config.get('SERVICE_PASSWORD_RECOVERY_REQUEST')),
        PasswordChangeRequest: $resource(Config.get('SERVICE_PASSWORD_CHANGE_REQUEST'))
    };
}
]);
