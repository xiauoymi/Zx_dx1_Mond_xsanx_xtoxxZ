angular.module('is.services.config', [])
    .service('Config', function () {
        var data = {};

        this.set = function (name, value) {
            data[name] = value;
        };

        this.get = function (name, defaultValue) {
            return data[name] !== undefined ? data[name] : defaultValue;
        }
    });