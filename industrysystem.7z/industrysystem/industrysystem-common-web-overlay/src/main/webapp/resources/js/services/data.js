angular.module('is.services.data', [])
    .factory('Data', ['$parse', function($parse) {
          return {
              extract: function(src, property) {
                  var getter = $parse(property);
                  var value = getter(src);
                  return value !== undefined ? value : null;
              }
          }
    }]);
