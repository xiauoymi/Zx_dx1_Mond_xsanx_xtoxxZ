angular.module('is.services.document', [])
    .service('RUCValidator', function () {
        var self = this;

        this.removeMask = function (digits) {
            var maskRegex = /\-/g;
            return maskRegex.test(digits) ? digits.replace(maskRegex, "") : digits;
        };

        this.isAllDigits = function (digits) {
            var numericRegex = /^[0-9]*$/;
            return numericRegex.test(digits);
        };

        this.validateLength = function (digits) {
            return digits.length > 1;
        };

        this.toDigit = function (c) {
            return parseInt(c);
        };

        this.calculateCheckDigit = function (digits) {
            var checkDigit = 0;
            var k = 2;
            for (var i = digits.length - 2; i >= 0; i--) {
                if (k > 11) {
                    k = 2;
                }
                var digit = self.toDigit(digits.charAt(i));
                checkDigit += digit * k;
                k++;
            }
            checkDigit = 11 - checkDigit % 11;
            switch (checkDigit) {
                case 11:
                    checkDigit = 0;
                    break;
                case 10:
                    checkDigit = 0;
                    break;
            }

            return checkDigit;
        };

        this.addMask = function (digits) {
            digits = this.removeMask(digits);

            var pattern = /^(\d{6,7})(\d{1})$/;

            var match = digits.match(pattern);

            if (!match) {
                return digits;
            }

            return match[1] + '-' + match[2];
        };

        this.validate = function (digits) {
            digits = digits || "";
            digits = self.removeMask(digits);
            if (self.isAllDigits(digits) && self.validateLength(digits)) {
                try {
                    var checkDigit = self.calculateCheckDigit(digits);
                    var lastDigit = self.toDigit(digits.charAt(digits.length - 1));
                    return lastDigit == checkDigit;
                } catch (error) {
                    return false;
                }
            }
            return false;
        };

        this.isComplete = function (digits) {
            return self.removeMask(digits).length >= 6;
        };
    })
    .service('RUCSocietyValidator', ['RUCValidator', function (RUCValidator) {
        var prefix = '800';

        this.validate = function (digits) {
            digits = digits || "";
            return ("" + digits).indexOf(prefix) == 0 ? RUCValidator.validate(digits) : false;
        };

        this.isComplete = function (digits) {
            return RUCValidator.removeMask(digits).length >= 8;
        };

        this.addMask = function (digits) {
            digits = RUCValidator.removeMask(digits);

            var pattern = /^(800\d{5})(\d{1})$/;

            var match = digits.match(pattern);

            if (!match) {
                return digits;
            }

            return match[1] + '-' + match[2];
        }
    }])
    .service('CedulaValidator', ['RUCValidator', function (RUCValidator) {
        this.validate = function (digits) {
            digits = digits || "";
            return RUCValidator.isAllDigits(digits);
        };

        this.isComplete = function (digits) {
            return RUCValidator.removeMask(digits).length >= 6;
        };

        this.addMask = function (digits) {
            return digits;
        }
    }])
    .service('CuitValidator', ['RUCValidator', function (RUCValidator) {
        this.validate = function (digits) {
            digits = digits || "";
            digits = RUCValidator.removeMask(digits);

            if (!RUCValidator.isAllDigits(digits)) {
                return false;
            }

            if (digits.length != 11) {
                return false;
            }

            if (digits.indexOf("2") != 0 && digits.indexOf("3") != 0) {
                return false;
            }

            return true;
        };

        this.isComplete = function (digits) {
            return RUCValidator.removeMask(digits).length >= 11;
        };

        this.addMask = function (digits) {
            digits = RUCValidator.removeMask(digits);

            var pattern = /(\d{2})(\d{8})(\d{1})/;

            var match = digits.match(pattern);

            if (!match) {
                return digits;
            }

            return match[1] + '-' + match[2] + '-' + match[3];
        };
    }])
    .service('DocumentService', [
        'RUCValidator',
        'RUCSocietyValidator',
        'CedulaValidator',
        'CuitValidator',
        function (RUCValidator, RUCSocietyValidator, CedulaValidator, CuitValidator) {
            var self = this;

            this.validators = {
                "RUC_PJ": RUCValidator,
                "RUC_SOCIEDAD": RUCSocietyValidator,
                "CEDULA": CedulaValidator,
                "CUIT": CuitValidator
            };

            this.getValidator = function (type) {
                type = type || "";
                return self.validators[type.toUpperCase()];
            };

            return {
                getValidator: function (type) {
                    return self.getValidator(type);
                },
                validateNumber: function (number, type) {
                    var validator = self.getValidator(type);
                    return validator ? validator.validate(number) : true;
                },
                isComplete: function (number, type) {
                    var validator = self.getValidator(type);
                    return validator ? validator.isComplete(number) : true;
                }
            }
        }])
    .directive('validDocument', ['DocumentService', function (DocumentService) {
        return {
            restrict: 'A',
            require: 'ngModel',
            scope: {
                value: '=ngModel',
                type: '=documentType',
                externalValidation: '&'
            },
            link: function (scope, element, attrs, ngModel) {
                var cache = '';
                var required = attrs.required;

                var validate = function (number, type) {
                    cache = number;

                    if (!number) {
                        ngModel.$setValidity('valid_document', true);
                        ngModel.$setValidity('not_found', true);
                        ngModel.$setValidity('validating', true);
                        return;
                    }

                    if (DocumentService.isComplete(number, type)) {
                        ngModel.$setValidity('valid_document', DocumentService.validateNumber(number, type));
                        ngModel.$setValidity('not_found', true);
                        ngModel.$setValidity('validating', true);

                        if (ngModel.$valid) {
                            var response = scope.$eval(scope.externalValidation);

                            if (response === null || response === undefined) {
                                return;
                            }

                            if (response && (response.$promise || response.promise)) {
                                ngModel.$setValidity('validating', false);

                                var promise = response.$promise || response.promise;

                                promise.then(
                                    function (found) {
                                        ngModel.$setValidity('valid_document', true);
                                        ngModel.$setValidity('validating', true);
                                        ngModel.$setValidity('not_found', found);
                                    },
                                    function () {
                                        ngModel.$setValidity('valid_document', false);
                                        ngModel.$setValidity('validating', true);
                                        ngModel.$setValidity('not_found', true);
                                    }
                                );
                            } else {
                                if (response == true) {
                                    ngModel.$setValidity('valid_document', true);
                                    ngModel.$setValidity('validating', true);
                                    ngModel.$setValidity('not_found', true);
                                } else {
                                    ngModel.$setValidity('valid_document', false);
                                    ngModel.$setValidity('validating', true);
                                    ngModel.$setValidity('not_found', true);
                                }
                            }
                        }
                    } else {
                        ngModel.$setValidity('valid_document', !!(!required && !number));
                        ngModel.$setValidity('not_found', true);
                        ngModel.$setValidity('validating', true);
                    }
                };

                scope.$watch('value', function (value) {
                    validate(value, scope.type);
                });

                scope.$watch('type', function (value) {
                    validate(scope.value, value);
                });
            }
        }
    }]);