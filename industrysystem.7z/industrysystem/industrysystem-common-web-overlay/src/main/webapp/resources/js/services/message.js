angular.module('is.services.message', [])
    .provider('MessageService', [function () {
        var self = this;

        /**
         * Para manejar los errores del lado del front mapear los códigos de errores
         * de los templates de de mensajes con los devueltos por el servidor
         */
        this.messageTemplates = {
            "ERROR_EMPTY": "Requerido",
            "ERROR_INTEGER": "Solo se permiten números",
            "ERROR_SIZE": "La longitud es inválida",

            "ERROR_0000":  "Error inesperado, vuelva a intentarlo más tarde o comuníquese con su administrador",
            "ERROR_1000":  "El número de carta de porte ya se encuentra registrado",
            "ERROR_1010":  "No se pudo grabar la carta de porte",
            "ERROR_1005":  "No requiere muestra",
            "ERROR_2001":  "La razón social del tituar es incorrecta",
            "ERROR_2013":  "La fecha ingresada es inválida",
            "ERROR_2021":  "El nombre del remitente comercial es inválido",
            "ERROR_8000":  "La muestra no se encuentra o no tiene los permisos para realizar esta operación.",
            "ERROR_10003": "El tipo de análisis es incorrecto, se espera cualitativo.",
            "ERROR_10004": "El tipo de análisis es incorrecto, se espera cuantitativo.",
            "ERROR_10005": "El resultado ya fue cargado",
            "ERROR_10011": "El laboratorio no puede realizar el test requerido.",
            "ERROR_12000": "El cultivo es incorrecto o inválido",
            "ERROR_20000": "No tiene los permisos necesarios para realizar esta operación",
            "ERROR_22000": "No se encontró el Trait Owner.",
            "ERROR_24000": "El destinatario no es válido",
            "ERROR_29000": "Laboratorio no encontrado",
            "ERROR_30000": "Tipo de test inválido",
            "ERROR_31000": "Campaña inválida",
            "ERROR_32000": "CTG inválida",
            "ERROR_34000": "Locación de origen inválida",
            "ERROR_35000": "Locación de destino inválida",
            "ERROR_36000": "Tipo de transporte inválido",
            "ERROR_37000": "Cantidad de vagones inválidos",
            "ERROR_38000": "Número de vagón inválido o repetido",
            "ERROR_39000": "El N° de Muestra ya existe para el Destinatario ingresado. Por favor ingrese un N° de Muestra diferente",
            "ERROR_39001": "La fecha ingresada es inválida",
            "ERROR_39002": "Código de comercio inválido",
            "ERROR_11000": "Porcentaje de tecnología inválido.",
            "ERROR_11001": "Tecnología inválida.",
            "ERROR_11002": "Fecha de test inváilda.",
            "ERROR_11003": "Error al guardar el resultado de test.",
            "ERROR_21002": "La muestra ya fue informada con anterioridad.",
            "ERROR_80000": "El numero de CTG ya existe",
            "ERROR_9000": "Ingrese un peso válido",
            "ERROR_5000": "El código de tecnología es inválido",

            "WAYBILL_UPLOAD_SUCCESS": "La carta de porte se cargó con éxito.",
            "WEIGHT": "Peso Neto"
        };

        this.setMessageTemplate = function (code, message) {
            this.messageTemplates[code] = message;
        };

        this.getMessageTemplate = function (code) {
            return this.messageTemplates[code];
        };

        this.$get = function () {
            return {
                parseMessage: function (message, params) {
                    _.each(params, function (value, key) {
                        message = message.replace("{" + key + "}", value);
                    });

                    return message;
                },
                getMessage: function (code, params, overrideMessage) {
                    code = code ? code.toUpperCase() : '';

                    var messageTemplate = overrideMessage || self.getMessageTemplate(code);

                    if (!messageTemplate) {
                        return code;
                    }

                    return this.parseMessage(messageTemplate, params);
                },
                getErrorMessage: function (code, params, overrideMessage) {
                    return this.getMessage("ERROR_" + code, params, overrideMessage);
                }
            }
        }
    }]);