var module = angular.module('is.services.modal', []);

module.factory('ISModalService', ['$http', '$compile', '$q', function ($http, $compile, $q) {
    var count = 0;

    return {
        load: function (scope, url, params) {
            var self = this;

            params = params || {};

            var deferred = $q.defer();

            $http.get(url).success(function (response) {
                var $el = self.open(scope, response, params);
                deferred.resolve($el);
            });

            return deferred.promise;
        },

        open: function (scope, content, params) {
            var self = this;
            params = params || {};
            angular.extend(scope, params);
            var $el = $(content);
            $compile($el)(scope);

            var cls = 'is_modal';
            var id = 'is_modal_' + (count++);

            $el.addClass(cls);
            $el.addClass(id);

            $('body').append($el);

            var $modal = $('.' + id);

            $modal.modal({backdrop:'static'});

            $modal.on('show.bs.modal', function () {
                scope.$broadcast('show.bs.modal', $modal);
            });

            $modal.on('shown.bs.modal', function () {
                scope.$broadcast('shown.bs.modal', $modal);
            });

            $modal.on('hide.bs.modal', function () {
                scope.$broadcast('hide.bs.modal', $modal);
            });

            $modal.on('hidden.bs.modal', function () {
                scope.$broadcast('hidden.bs.modal', $modal);
                $modal.remove();
            });

            scope.$on('complete', function () {
                self.close($modal);
            });

            return $modal;
        },

        close: function (element) {
            $(element).modal('hide');
        },

        alert: function (scope, message, title) {
            message = message || '';
            title = title || '¡Atención!';

            var deferred = $q.defer();

            var promise = this.load(scope, 'common/dialog/alert.jsp', {
                title: title,
                message: message
            });

            promise.then(function ($modal) {
                $modal.on('hidden.bs.modal', function () {
                    scope.$apply(function () {
                        deferred.resolve();
                    });
                });
            });

            return deferred.promise;
        },

        error: function (scope, message, code) {
            message = message || 'Ha ocurrido un error.';
            var title = 'Error ' + (!!code ? '(' + code + ')' : '');
            return this.alert(scope, message, title);
        },

        confirm: function (scope, message, title) {
            message = message || '¿Desea continuar?';
            title = title || '¡Atención!';

            var deferred = $q.defer();

            var promise = this.load(scope, 'common/dialog/confirm.jsp', {
                title: title,
                message: message
            });

            promise.then(function ($modal) {
                $modal.on('hidden.bs.modal', function () {
                    scope.$apply(function () {
                        if (scope.isModalAccepted) {
                            deferred.resolve();
                        } else {
                            deferred.reject();
                        }
                    });
                });
            });

            return deferred.promise;
        }
    }
}]);

module.directive('isModal', ['ISModalService', function (ISModalService) {
    return {
        restrict: 'A',
        scope: true,
        controllerAs: 'modal',
        controller: ['$scope', '$element', '$attrs', function ($scope, $element, $attrs) {
            var self = this;
            this.$el = null;
            var params = $scope.$eval($attrs.params) || {};

            this.getParams = function () {
                return params || {};
            };

            this.getStyle = function () {
                return params.style;
            };

            this.dismiss = function () {
                if (self.$el) {
                    ISModalService.close(self.$el);
                }
            }
        }],
        link: function (scope, element, attrs, controller) {
            element.bind('click', function () {
                var src = scope.$eval(attrs.isModal);
                if (src) {
                    ISModalService.load(scope, src, controller.getParams()).then(function ($el) {
                        controller.$el = $el;
                    });
                }
            });
        }
    }
}]);