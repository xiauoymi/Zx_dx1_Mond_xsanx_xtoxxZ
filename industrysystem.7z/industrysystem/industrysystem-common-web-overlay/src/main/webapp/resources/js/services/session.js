angular.module('is.services.session', [])
    .factory('Session', function () {
        return {
            user: null
        }
    });

