angular.module('is.services.table', []).
    factory('TableService', function () {
        var parseOperator = function (filter) {
            return filter.comparison;
        };

        return {
            parseFilters: function (rawFilters) {
                var filters = [];
                angular.forEach(rawFilters, function (filter) {
                    var parsedFilter = {};

                    switch (filter.type) {
                        case "list":
                            parsedFilter = {
                                field: filter.field,
                                operator: "in",
                                values: filter.value
                            };
                            break;
                        default:
                            parsedFilter = {
                                field: filter.field,
                                operator: parseOperator(filter),
                                values: [""+filter.value]
                            };
                    }

                    filters.push(parsedFilter);
                });
                return filters;
            },
            parseSort: function (rawSort) {
                var parsed = [];
                angular.forEach(rawSort, function (sort) {
                    var parsedSort = {
                        field: sort.property,
                        asc: sort.direction == 'ASC' ? true : false
                    };

                    parsed.push(parsedSort);
                });
                return parsed;
            }
        }
    });
