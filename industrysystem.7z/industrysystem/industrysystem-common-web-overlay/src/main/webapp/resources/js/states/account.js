angular.module('IndustrySystem')
    .config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.when('/account', '/account/password-recovery')

        $stateProvider.state('account', {
                url: '/account',
                abstract: true,
                templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_ACCOUNT')
            }
        ).state('account.passwordRecovery', {
                url: '/password-recovery',
                templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_ACCOUNT_PASSWORD_RECOVERY'),
                controller: ['$scope', 'Config', 'Api', function ($scope, Config, Api) {
                    $scope.showErrors = false;
                    $scope.view = 'form';

                    $scope.model = {
                        email: 'dperez@ebowe.com',
                        captcha: {}
                    }

                    var validate = function () {
                        return $scope.form.$valid && $scope.model.captcha.response;
                    }

                    $scope.submit = function () {
                        $scope.showErrors = true;

                        if (validate()) {
                            Api.PasswordRecoveryRequest.save($scope.model).$promise.then(function (resource) {
                                if (resource.success) {
                                    $scope.view = 'request-success';
                                } else {
                                    console.log('Error', resource);
                                }
                            });
                        }
                    }
                }]
            }
        ).state('account.passwordChange', {
                url: '/password-change/{token}',
                templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_ACCOUNT_PASSWORD_CHANGE'),
                controller: ['$scope', 'Api', function ($scope, Api) {
                    $scope.view = 'form';

                    $scope.model = {
                        full_name: 'Diego Perez',
                        username: 'dpere8',
                        email: 'dperez@ebowe.com'
                    };

                    var validate = function () {
                        return $scope.form.$valid;
                    };

                    $scope.submit = function () {
                        $scope.showErrors = true;
                        if (validate()) {
                           $scope.view = 'success';
                        }
                    };
                }]
            }
        );
    }]);
