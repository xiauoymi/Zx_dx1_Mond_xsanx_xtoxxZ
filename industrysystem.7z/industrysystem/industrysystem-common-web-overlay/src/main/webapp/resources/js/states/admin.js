var app = angular.module('IndustrySystem');

app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.when('/admin', '/admin/dashboard');

    $stateProvider
        .state('admin', {
            url: '/admin',
            abstract: true,
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_ADMIN'),
            data: {
                loginState: 'admin.login',
                section: 'admin'
            }
        })

        .state('admin.login', {
            url: '/login',
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_ADMIN_LOGIN'),
            data: {
                menu: null,
                secure: false
            }
        })

        .state('admin.dashboard', {
            url: '/dashboard',
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_DASHBOARD'),
            controller: ['$scope', 'Api', function ($scope, Api) {
                $scope.loggedUser.type = 'admin';
            }]
        })

        .state('admin.participant', {
            url: '/participant',
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_PARTICIPANT'),
            controller: ['$scope', '$resource', '$compile', 'Api', '$q', '$timeout',
                function ($scope, $resource, $compile, Api, $q, $timeout) {
                    $scope.loggedUser.type = 'admin';
                }
            ]
        })
}]);
