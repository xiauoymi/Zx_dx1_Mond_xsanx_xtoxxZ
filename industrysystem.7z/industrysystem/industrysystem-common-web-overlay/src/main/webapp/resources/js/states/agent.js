var app = angular.module('IndustrySystem');

app.config(['$stateProvider', function ($stateProvider) {
    $stateProvider.state('agent', {
        url: '/agent',
        templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_AGENT'),
        data: {
            secure: false,
            section: 'agent'
        }
    });
}]);
