angular.module('IndustrySystem')
    .config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
        $stateProvider.state('privacy', {
                url: '/privacy',
                templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_COMMON_PRIVACY')
            }
        ).state('terms', {
                url: '/terms',
                templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_COMMON_TERMS')
            }
        ).state('about-us', {
                url: '/about-us',
                templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_COMMON_ABOUT_US')
            }
        );
    }]);
