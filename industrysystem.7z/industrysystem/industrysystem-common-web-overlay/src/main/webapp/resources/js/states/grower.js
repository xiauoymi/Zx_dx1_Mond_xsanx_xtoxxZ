var app = angular.module('IndustrySystem');

app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.when('/grower', '/grower/summary');

    $stateProvider
        .state('grower', {
            url: '/grower',
            abstract: true,
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_GROWER'),
            data: {
                menu: angular.injector(['is.services.config']).get('Config').get('PARTIALS_GROWER_MENU'),
                loginState: 'grower.login',
                section: 'grower'
            }
        })

        .state('grower.login', {
            url: '/login',
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_GROWER_LOGIN'),
            data: {
                menu: null,
                secure: false
            }
        })

        .state('grower.summary', {
            url: '/summary',
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_GROWER_SUMMARY'),
            controller: ['$scope', 'Api', function ($scope, Api) {
                $scope.growers = Api.Grower.query();
                $scope.technologies = Api.Technology.query();
                $scope.loggedUser.type = 'grower';

                $scope.onSelectionChange = function () {
                    if ($scope.selectedGrower && $scope.technologyCode) {
                        $scope.brief = Api.Grower.brief({documentNumber: $scope.selectedGrower.documentNumber, documentType: $scope.selectedGrower.documentType, technologyCode: $scope.technologyCode});
                    } else {
                        $scope.brief = [];
                    }
                };

                $scope.sumUsedDetail = function (usedDetail) {
                    var sum = 0;

                    angular.forEach(usedDetail, function (i) {
                        sum += (i.usedPpt + i.usedPod);
                    });

                    return sum;
                };
            }]
        })

        .state('grower.management', {
            url: '/management',
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_GROWER_MANAGEMENT')
        })

        .state('grower.waybill', {
            url: '/waybill',
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_GROWER_WAYBILL'),
            controller: ['$scope', '$resource', '$compile', 'Api', '$q', '$timeout', 'TableService', 'ISModalService',
                'Config',
                function ($scope, $resource, $compile, Api, $q, $timeout, TableService, ISModalService, Config) {
                    $scope.loggedUser.type = 'grower';
                    $scope.growers = Api.Grower.query();

                    $scope.getActive = function (page, filters, sort) {
                        var defer = $q.defer();

                        Api.GrowerWaybill.getActive({
                            "filter": TableService.parseFilters(filters),
                            "orderBy": TableService.parseSort(sort),
                            "page": page
                        }).$promise.then(function (response) {
                                defer.resolve(response);
                            });

                        return defer.promise;
                    };

                    $scope.viewDetail = function (waybill) {
                        ISModalService.load($scope, Config.get("PARTIALS_POD_WAYBILL_DETAIL"), {model: waybill});
                    };
                }
            ]
        })
}]);

app.controller('GrowerWaybillDetailCtrl', ['$scope', 'Api', function ($scope, Api) {
    $scope.model = Api.Waybill.getDetail({id: $scope.id});
    $scope.loggedUser.type = 'grower';
}]);