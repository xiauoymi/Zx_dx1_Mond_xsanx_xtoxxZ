var app = angular.module('IndustrySystem');

app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
    $stateProvider.state('home', {
        url: '/',
        templateUrl: function () {
            var Config = angular.injector(['is.services.config']).get('Config');

            return Config.get('PARTIALS_HOME');
        },
        data: {
            secure: false
        }
    });
}]);
