var app = angular.module('IndustrySystem');

app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.when('/laboratory', '/laboratory/order');

    $stateProvider
        .state('laboratory', {
            url: '/laboratory',
            abstract: true,
            templateUrl: function () {
                var Config = angular.injector(['is.services.config']).get('Config');
                return Config.get('PARTIALS_LABORATORY');
            },
            data: {
                menu: angular.injector(['is.services.config']).get('Config').get('PARTIALS_LABORATORY_MENU'),
                loginState: 'laboratory.login',
                section: 'laboratory'
            }
        })

        .state('laboratory.login', {
            url: '/login',
            templateUrl: function () {
                var Config = angular.injector(['is.services.config']).get('Config');
                return Config.get('PARTIALS_LABORATORY_LOGIN');
            },
            data: {
                menu: null,
                secure: false
            }
        })

        .state('laboratory.order', {
            url: '/order',
            templateUrl: function () {
                var Config = angular.injector(['is.services.config']).get('Config');
                return Config.get('PARTIALS_LABORATORY_ORDER');
            },
            controller: ['$scope', '$resource', '$compile', 'Api', '$q',
                'TableService',
                function ($scope, $resource, $compile, Api, $q, TableService) {
                var self = this;
                $scope.loggedUser.type = 'laboratory';

                this.countIncomplete = function (list) {
                    return list.count;
                };

                $scope.getPending = function () {
                    var resources = Api.LaboratoryTest.getPending();
                    resources.$promise.then(function (list) {
                        $scope.incompleteCount = self.countIncomplete(list);
                    });
                    return resources;
                };

                $scope.getActive = function (page, filters, sort) {
                    var defer = $q.defer();

                    Api.LaboratoryTest.getActive({
                        "filter": TableService.parseFilters(filters),
                        "orderBy": TableService.parseSort(sort),
                        "page": page
                    }).$promise.then(function (response) {
                            defer.resolve(response);
                        });

                    return defer.promise;
                };

                $scope.getAll = function () {
                    return Api.LaboratoryTest.query();
                };

                $scope.incompleteCount = null;

                $scope.$on('sample:completed', function (event, waybill) {
                    $scope.sampleTable.reload();
                });

                $scope.$on('upload:completed', function (event, waybill) {
                    $scope.sampleTable.reload();
                });
            }
            ]
        })

        .state('laboratory.summary', {
            url: '/summary',
            templateUrl: function () {
                var Config = angular.injector(['is.services.config']).get('Config');
                return Config.get('PARTIALS_LABORATORY_SUMMARY');
            }
        })
}]);

app.controller('LaboratoryResultCtrl',
    ['$scope', 'Api', 'ISModalService', '$q', 'Envelope', function ($scope, Api, ISModalService, $q, Envelope) {
        var idx = 0;
        $scope.loggedUser.type = 'laboratory';

        $scope.model.technologyList = [
            {
                technology: null,
                percent: 0
            }
        ];

        $scope.model.bio = $scope.model.bio == undefined ? '' : $scope.model.bio;

        $scope.documentTypes = Api.DocumentTypes.query();

        $scope.showErrors = false;
        //should be query
        Api.Technology.query().$promise.then(function (response) {
            $scope.technologies = response;
        });

        $scope.hasError = function (name) {
            var tec = _.findWhere($scope.detectedTecnologies, {name: name});
            return !tec.value;
        };

        $scope.$watch('model.holderDocumentNumber', function (value) {
            $scope.model.holderName = '';
        });

        $scope.$watch('model.commercialSenderDocumentNumber', function (value) {
            $scope.model.commercialSenderName = '';
        });

        $scope.validateCuit = function (documentNumber, destPropertyName) {
            $scope.model[destPropertyName] = '';

            if (documentNumber) {
                var deferred = $q.defer();
                var apiCall = Api.Cuit.get({cuit: documentNumber});

                apiCall.$promise.then(
                    function (response) {
                        if (response.success) {
                            $scope.model[destPropertyName] = response.name;
                            var found = !!response.name;
                            deferred.resolve(found);
                        } else {
                            $scope.model[destPropertyName] = '';
                            deferred.reject();
                        }
                    },
                    function (error) {
                        $scope.model[destPropertyName] = '';
                    }
                );

                return deferred;
            }

            return false;
        };

        $scope.validateDocument = function(document, type, property) {
            $scope.model[property] = '';

            var api = null;

            switch (property) {
                case 'addresseeName':
                    api = Api.AddresseeDocument;
                    break;
                default:
                    api = Api.Document;
            }

            if(!api) {
                return true;
            }

            if (document && type) {
                var deferred = $q.defer();
                var apiCall = api.get({document: document, type: type});

                apiCall.$promise.then(
                    function (response) {
                        if (response.success) {
                            $scope.model[property] = response.name;
                            var found = !!response.name;
                            deferred.resolve(found);
                        } else {
                            $scope.model[property] = '';
                            deferred.reject();
                        }
                    },
                    function (error) {
                        $scope.model[property] = '';
                    }
                );

                return deferred;
            }

            return false;
        };

        $scope.save = function () {
            var deferred = $q.defer();

            $scope.showErrors = true;

            if ($scope.model.bio !== '') {
                if ($scope.model.bio === 0) {
                    ISModalService.confirm($scope/*, message, title*/).then(function () {
                        var envelope = Envelope.laboratoryTestResultNoBio($scope.model);

                        Api.LaboratoryTestResult.save(envelope, function(){
                            $scope.$emit('sample:completed');
                            deferred.resolve();
                        });

                    });
                } else {
                    var hasHolderName = $scope.form.holderDocumentNumber && $scope.form.holderDocumentNumber.$error.not_found && !!$scope.model.holderName;
                    var hasCommercialSenderName = $scope.form.commercialSenderDocumentNumber && $scope.form.commercialSenderDocumentNumber.$error.not_found && !!$scope.model.commercialSenderName;

                    if (!(($scope.form.holderDocumentNumber && $scope.form.holderDocumentNumber.$invalid && !hasHolderName) ||
                        ($scope.form.commercialSenderDocumentNumber && $scope.form.commercialSenderDocumentNumber.$invalid && !hasCommercialSenderName) ||
                        $scope.form.technologyListForm.$invalid)) {
                        $scope.showErrors = false;

                        ISModalService.confirm($scope/*, message, title*/).then(function () {
                            var envelope = Envelope.laboratoryTestResultBio($scope.model);

                            Api.LaboratoryTestResult.save(envelope, function(){
                                $scope.$emit('sample:completed');
                                deferred.resolve();
                            });
                        });
                    }
                }
            }

            return deferred.promise;
        };
    }]);
