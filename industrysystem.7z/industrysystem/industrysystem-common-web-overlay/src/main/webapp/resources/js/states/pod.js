var app = angular.module('IndustrySystem');

app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.when('/pod', '/pod/waybill');
    $urlRouterProvider.when('/pod/waybill', '/pod/waybill/list');

    $stateProvider
        .state('pod', {
            url: '/pod',
            abstract: true,
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_POD'),
            data: {
                menu: angular.injector(['is.services.config']).get('Config').get('PARTIALS_POD_MENU'),
                loginState: 'pod.login',
                section: 'pod'
            }
        })

        .state('pod.login', {
            url: '/login',
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_POD_LOGIN'),
            data: {
                menu: null,
                secure: false
            }
        })

        .state('pod.waybill', {
            url: '/waybill',
            abstract: true,
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_POD_WAYBILL')
        })

        .state('pod.waybill.list', {
            url: '/list',
            templateProvider: ['Session', '$http', '$q', 'Config', function (Session, $http, $q, Config) {
                var deferred = $q.defer(),
                    url = Config.get('PARTIALS_POD_WAYBILL_LIST');//_' + Session.user.type.toUpperCase());

                $http.get(url).success(function (data) {
                    deferred.resolve(data);
                });

                return deferred.promise;
            }],
            controller: ['$scope', 'Api', 'Session', 'TableService', '$q', 'ISModalService', 'Config', function ($scope, Api, Session, TableService, $q, ISModalService, Config) {
                var self = this;
                $scope.loggedUser.type = 'pod';
                $scope.pendingCount = null;
                $scope.incompleteCount = null;

                this.countPending = function (list) {
                    var count = 0;
                    angular.forEach(list, function (item) {
                        if (item.weight == null || item.sample_status == null) {
                            count++;
                        }
                    });

                    return count;
                };

                $scope.getPending = function () {
                    var resources = Api.PodWaybill.getPending();
                    resources.$promise.then(function (list) {
                        $scope.pendingCount = self.countPending(list);
                    });

                    return resources;
                };

                $scope.getActive = function (page, filters, sort) {
                    var defer = $q.defer();

                    Api.PodWaybill.getActive({
                        "filter": TableService.parseFilters(filters),
                        "orderBy": TableService.parseSort(sort),
                        "page": page
                    }).$promise.then(function (response) {
                            defer.resolve(response);
                        });

                    return defer.promise;
                };

                $scope.getBillable = function () {
                    return Api.PodWaybill.getBillable();
                };

                $scope.isActive = function (model) {
                    return model.weight != null && model.sample_status != null;
                };

                $scope.viewDetail = function (waybill) {
                    ISModalService.load($scope, Config.get("PARTIALS_POD_WAYBILL_DETAIL"), {model: waybill});
                };

                $scope.$on('landingBill:change', function (event, model, collection) {
                    var index = collection.indexOf(model);
                    if (index > -1) {
                        model.updated = true;
                        $timeout(function () {
                            collection.splice(index, 1);
                            $scope.incompleteCount = $scope.incompleteCount - 1;
                        }, 3000);
                    }
                });

                var waybillStatusValuesDefer = $q.defer();
                $scope.waybillStatusValues = waybillStatusValuesDefer.promise;

                Api.PodWaybill.getStatusValues().$promise.then(function (waybillStatusValues) {
                    var parsed = [];

                    angular.forEach(waybillStatusValues, function (i) {
                        parsed.push({
                            label: i.description,
                            value: i.status
                        });
                    });

                    waybillStatusValuesDefer.resolve(parsed);
                });

                $scope.$on('waybill:added', function (event, waybill) {
                    $scope.pendingTable.reload();
                    $scope.activeTable.reload();
                });

                $scope.$on('waybill:changed', function (event, waybill) {
                    $scope.pendingTable.reload();
                    $scope.activeTable.reload();
                });
            }]
        })

        .state('pod.summary', {
            url: '/summary',
            templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_POD_SUMMARY')
        })
}]);

app.controller('PodWaybillWeightCtrl', ['$scope', 'Api', '$q', function ($scope, Api, $q) {
    $scope.original = $scope.model;
    $scope.model = angular.copy($scope.original);
    $scope.loggedUser.type = 'pod';
    $scope.showErrors = {
        'step-load-detail': false
    };

    Api.Laboratory.query().$promise.then(function (response) {
        $scope.laboratories = response;
    });

    $scope.save = function () {
        var deferred = $q.defer();
        $scope.showErrors['step-load-detail'] = true;

        if ($scope.form.$valid) {

            Api.PodWaybill.storeWeightAndSample($scope.model, function () {
                deferred.resolve();
                $scope.$emit('waybill:changed', $scope.original, $scope.collection);
                //                ISModalService.alert($scope, "La carta de porte se cargó con éxito.", "Información");
            }, function () {
                deferred.reject();
            });

        } else {
            deferred.reject();
        }

        return deferred.promise;
    };
}
]);

app.controller('PodWaybillSampleCtrl', ['$scope', 'Api', function ($scope, Api) {
    if (!$scope.model) {
        $scope.model = new Api.LandingBill();
    }

    $scope.original = $scope.model;
    $scope.model = angular.copy($scope.original);

    $scope.loggedUser.type = 'pod';

    $scope.validate = function (model) {
        var valid = $scope.form.$valid;
        return valid;
    };

    $scope.save = function (model) {
        $scope.showErrors = true;

        if ($scope.validate($scope.model)) {
            $scope.original.sample_lab_id = $scope.model.sample_lab_id;
            $scope.original.sample_status = $scope.model.sample_status;
            $scope.$emit('waybill:change', $scope.original, $scope.collection);

            // Notificar a la modal
            $scope.$emit('complete');
        }
    };
}
]);

app.controller('PodWaybillDetailCtrl', ['$scope', 'Api', '$q', function ($scope, Api, $q) {
    $scope.getEvents = function (page) {
        var defer = $q.defer();

        Api.PodWaybill.getEvents({
            page: page,
            filter: [
                {
                    field: "identifier",
                    operator: "eq",
                    values: ["" + $scope.model.identifier]
                }
            ]
        }).$promise.then(function (resource) {
               defer.resolve(resource);
            }
        );

        return defer.promise;
    };
}]);

app.controller('PodWaybillUploadCtrl', ['$scope', 'Api', '$q', 'ISModalService', 'Session', 'Config', 'MessageService',
    'Envelope',
    function ($scope, Api, $q, ISModalService, Session, Config, MessageService, Envelope) {
        var stepMap = {
            1: 'step-transport-type',
            2: 'step-main-data',
            3: 'step-intervening',
            4: 'step-origin',
            5: 'step-load-detail',
            6: 'step-summary'
        };

        $scope.loggedUser.type = 'pod';

        var createLoadDetails = function (count, templateData) {
            if (count < 1) {
                count = 1;
            }

            var rows = [];
            templateData = templateData || {};

            for (var i = 0; i < count; i++) {
                rows.push(angular.extend({
                    loadIdentifier: null,
                    sampleCode: null,
                    weight: null,
                    declaredTechnology: null
                    //   wagonsQty: null
                }, templateData));
            }

            return rows;
        };


        $scope.showErrors = {
            'step-transport-type': false,
            'step-main-data': false,
            'step-intervening': false,
            'step-origin': false,
            'step-load-detail': false,
            'step-summary': false
        };

        $scope.model = {
            waybillType: null,
            ctg: null,
            waybillNumber: null,
            cropCode: null,
            holderDocumentNumber: null,
            holderName: null,
            commercialSenderDocumentNumber: null,
            commercialSenderName: null,
            addresseeDocumentNumber: null,
            addresseeName: null,
            destination: null,
            originState: null,
            originLocation: null,
            destinationState: null,
            destinationLocation: null,
            loadDetail: []
        };


        $scope.restModel = {
            originEstablishment: null,
            waybillType: null,
            holderName: null,
            holderDocument: null,
            commercialSenderName: null,
            commercialSenderDocument: null,
            destinationDocument: null,
            destinationCommercialCode: null,
            cropCode: null,
            originLocation: null,
            destinationLocation: null,
            waybillNumber: null,
            addresseeDocument: null,
            quantitativeLabCode: null,
            qualitativeLabCode: null,
            unloadingDate: null,
            loadDetails: []
        };

        $scope.originLocations = [];
        $scope.destinationLocations = [];
        $scope.destinations = [];
        $scope.customErrors = {};

        Api.State.query().$promise.then(function (response) {
            $scope.states = response;
        });

        Api.Crop.query().$promise.then(function (response) {
            $scope.crops = response;
        });

        Api.Technology.query().$promise.then(function (response) {
            $scope.technologies = response;
        });

        Api.Laboratory.query().$promise.then(function (response) {
            $scope.laboratories = response;
        });

        Api.PodDestinations.query().$promise.then(function (response) {
            $scope.destinations = response;
        });

        $scope.documentTypes = Api.DocumentTypes.query();

        $scope.$watch('model.originState', function (value) {
            if (value) {
                Api.City.query({province: value}).$promise.then(function (response) {
                    $scope.originLocations = response;
                });
            } else {
                $scope.model.originLocation = null;
                $scope.originLocations = [];
            }
        });

        $scope.$watch('model.destinationState', function (value) {
            if (value) {
                Api.City.query({province: value}).$promise.then(function (response) {
                    $scope.destinationLocations = response;
                });
            } else {
                $scope.model.destinationLocation = null;
                $scope.destinationLocations = [];
            }
        });

        $scope.$watch('model.holderDocumentNumber', function (value) {
            $scope.model.holderName = '';
        });

        $scope.$watch('model.commercialSenderDocumentNumber', function (value) {
            $scope.model.commercialSenderName = '';
        });

        $scope.$watch('model.addresseeDocumentNumber', function (value) {
            $scope.model.addresseeName = '';
        });

        $scope.setWaybillType = function (waybillType) {
            $scope.model.waybillType = waybillType;
        };

        $scope.validateCuit = function (documentNumber, destPropertyName) {
            $scope.model[destPropertyName] = '';

            if (documentNumber) {
                var deferred = $q.defer();
                var apiCall = Api.Cuit.get({cuit: documentNumber});

                apiCall.$promise.then(
                    function (response) {
                        if (response.success) {
                            $scope.model[destPropertyName] = response.name;
                            var found = !!response.name;
                            deferred.resolve(found);
                        } else {
                            $scope.model[destPropertyName] = '';
                            deferred.reject();
                        }
                    },
                    function (error) {
                        $scope.model[destPropertyName] = '';
                    }
                );

                return deferred;
            }

            return false;
        };

        $scope.validateAddresseeCuit = function (documentNumber, destPropertyName) {
            $scope.model[destPropertyName] = '';

            if (documentNumber) {
                var deferred = $q.defer();
                var apiCall = Api.AddresseeCuit.get({cuit: documentNumber});

                apiCall.$promise.then(
                    function (response) {
                        if (response.success) {
                            $scope.model[destPropertyName] = response.name;
                            var found = !!response.name;
                            deferred.resolve(found);
                        } else {
                            $scope.model[destPropertyName] = '';
                            deferred.reject();
                        }
                    },
                    function (error) {
                        $scope.model[destPropertyName] = '';
                    }
                );

                return deferred;
            }

            return false;
        };

        $scope.validateDocument = function (document, type, property) {
            $scope.model[property] = '';

            var api = null;

            switch (property) {
                case 'addresseeName':
                    api = Api.AddresseeDocument;
                    break;
                default:
                    api = Api.Document;
            }

            if (!api) {
                return true;
            }

            if (document && type) {
                var deferred = $q.defer();
                var apiCall = api.get({document: document, type: type});

                apiCall.$promise.then(
                    function (response) {
                        if (response.success) {
                            $scope.model[property] = response.name;
                            var found = !!response.name;
                            deferred.resolve(found);
                        } else {
                            $scope.model[property] = '';
                            deferred.reject();
                        }
                    },
                    function (error) {
                        $scope.model[property] = '';
                    }
                );

                return deferred;
            }

            return false;
        };

        $scope.validateStep = function (stepNum) {

            var stepName = stepMap[stepNum];
            $scope.customErrors = {};

            if (!stepName) {
                return true;
            }

            var stepIsValid = true;

            $scope.showErrors[stepName] = true;

            switch (stepName) {
                case 'step-transport-type':
                    stepIsValid = $scope.form.waybillType.$valid && $scope.form.wagonsQty.$valid;

                    if (stepIsValid) {
                        var count = $scope.model.waybillType != "TRANSPORTE AUTOMOTOR" ? $scope.model.wagonsQty : 1;
                        if ($scope.model.waybillType != 'TRANSPORTE AUTOMOTOR') {

                            $scope.model.loadDetail = createLoadDetails(count, {
                                loadType: 'train',
                                declaredTechnology: $scope.model.declaredTechnology,
                                wagonsQty: $scope.model.wagonsQty
                            });
                        } else {
                            $scope.model.loadDetail = createLoadDetails(count, {
                                loadType: 'truck',
                                loadIdentifier: $scope.model.ctg,
                                declaredTechnology: $scope.model.declaredTechnology
                            });
                        }
                    }

                    break;

                case 'step-main-data':
                    if (
                        ($scope.form.waybillNumber && $scope.form.waybillNumber.$invalid) ||
                            ($scope.form.ctg && $scope.form.ctg.$invalid) ||
                            ($scope.form.cropCode && $scope.form.cropCode.$invalid)
                        ) {
                        stepIsValid = false;
                    } else {
                        $scope.loading = true;
                        stepIsValid = false;

                        Api.PodWaybill.validateNumber({waybillNumber: $scope.model.waybillNumber})
                            .$promise.then(function (response) {
                                if (response.success) {
                                    $scope.loading = false;
                                    $scope.wizard.next(false);
                                } else {
                                    $scope.loading = false;
                                    var errors = response.errors || [];

                                    angular.forEach(errors, function (value, key) {
                                        var field = value.fieldName;

                                        // Para usar mensaje del server:
                                        // $scope.customErrors[field] = MessageService.getErrorMessage(value.code, null, value.message);

                                        // Para usar mensaje configurado en services/message.js:
                                        $scope.customErrors[field] = MessageService.getErrorMessage(value.code);
                                    });
                                }
                            },
                            function () {
                                $scope.loading = false;
                            }
                        );
                    }
                    break;

                case 'step-intervening':
                    var hasHolderName = $scope.form.holderDocumentNumber.$error.not_found && !!$scope.model.holderName;
                    var hasCommercialSenderName = $scope.form.commercialSenderDocumentNumber && $scope.form.commercialSenderDocumentNumber.$error.not_found && !!$scope.model.commercialSenderName;

                    if (
                        ($scope.form.holderDocumentNumber && $scope.form.holderDocumentNumber.$invalid && !hasHolderName) ||
                            ($scope.form.commercialSenderDocumentNumber && $scope.form.commercialSenderDocumentNumber.$invalid && !hasCommercialSenderName) ||
                            ($scope.form.addresseeDocumentNumber && $scope.form.addresseeDocumentNumber.$invalid) ||
                            $scope.form.destination && $scope.form.destination.$invalid) {
                        stepIsValid = false;
                    }
                    break;

                case 'step-origin':
                    if ($scope.form.originState.$invalid ||
                        $scope.form.originLocation.$invalid ||
                        $scope.form.destinationState.$invalid ||
                        $scope.form.destinationLocation.$invalid) {
                        stepIsValid = false;
                    }
                    break;

                case 'step-load-detail':
                    if ($scope.form.loadDetailContainerForm.$invalid) {
                        stepIsValid = false;
                    }
                    break;

            }
            return stepIsValid;
        };

        $scope.hasCtg = function (model) {
            return model.waybillType != 'VAGON FERROVIARIO';
        };

        $scope.hasWagons = function (model) {
            return model.waybillType == 'VAGON FERROVIARIO';
        };

        $scope.getStateNameByCode = function (code) {
            var state = _.findWhere($scope.states, {code: code});

            return !!state ? state.description : '';
        };

        $scope.getOriginLocationNameByCode = function (code) {
            var originLocation = _.findWhere($scope.originLocations, {code: code});

            return !!originLocation ? originLocation.description : '';
        };

        $scope.getDestinationLocationNameByCode = function (code) {
            var destinationLocation = _.findWhere($scope.destinationLocations, {code: code});

            return !!destinationLocation ? destinationLocation.description : '';
        };

        $scope.getCropCodeByCode = function (code) {
            var crop = _.findWhere($scope.crops, {code: code});

            return !!crop ? crop.description : '';
        };

        $scope.getDeclaredTechnologyById = function (id) {
            var declaredTechnology = _.findWhere($scope.technologies, {code: id});

            return !!declaredTechnology ? declaredTechnology.description : '';
        };

        $scope.getDestinationByDocumentNumber = function (documentNumber) {
            var destination = _.find($scope.destinations, function (d) {
                return d.document.number == documentNumber;
            });
            return destination || {};
        };

        $scope.save = function (model) {
            var promise = Api.PodWaybill.save(Envelope.waybill($scope.model)).$promise;

            promise.then(function () {
                $scope.$emit('waybill:added');
                ISModalService.alert($scope, MessageService.getMessage("WAYBILL_UPLOAD_SUCCESS"), "Información");
            });

            return promise;
        };
    }]);

app.controller('PodWaybillBulkUploadCtrl', ['$scope', '$resource', '$compile', 'Api', '$q', '$timeout', 'WaybillService',
    'ISModalService', 'Config', 'MessageService',
    function ($scope, $resource, $compile, Api, $q, $timeout, WaybillService, ISModalService, Config, MessageService) {

        $scope.model = {};
        $scope.loading = false;
        $scope.processing = false;
        $scope.totalCount = 0;
        $scope.successCount = 0;
        $scope.errorCount = 0;
        $scope.pending = [];
        $scope.errors = [];
        $scope.success = [];
        $scope.loggedUser.type = 'pod';
        $scope.fileProcessed = false;
        $scope.editWaybillModal = null;

        var haltProcessing = false;
        var pendingGauge = null;
        var successGauge = null;
        var errorGauge = null;


        var fileOnLoad = function (e) {
            $scope.$apply(function () {
                var text = reader.result;

                try {
                    $scope.pending = CSV.parse(text);
                } catch (error) {
                    console.error(error);

                    $scope.fileProcessed = false;

                    ISModalService.error($scope, "El formato del archivo es inválido.").then(function () {
                        $scope.wizard.previous();
                    });
                }

                $scope.totalCount = $scope.pending.length;
                createGauges();
                $scope.processing = true;
                processAll($scope.pending, $scope.model.fileType)
                    .then(function () {
                        $scope.$emit('upload:completed');
                        console.log('Done');
                    })
                    .finally(function () {
                        $scope.processing = false;
                    });
            });
        };

        var reader = new FileReader();
        reader.onload = fileOnLoad;

        var stepMap = {
            1: 'step-file',
            2: 'step-verify'
        };

        var createGauges = function () {
            if (!pendingGauge) {
                pendingGauge = new JustGage({
                    id: "pending",
                    value: $scope.pending.length,
                    min: 0,
                    max: $scope.totalCount,
                    label: "Registros",
                    title: "Pendientes",
                    levelColors: ["yellow"]
                });
            }

            if (!successGauge) {
                successGauge = new JustGage({
                    id: "success",
                    value: $scope.success.length,
                    min: 0,
                    max: $scope.totalCount,
                    label: "Registros",
                    title: "Importados",
                    levelColors: ["green"]
                });
            }

            if (!errorGauge) {
                errorGauge = new JustGage({
                    id: "error",
                    value: $scope.errors.length,
                    min: 0,
                    max: $scope.totalCount,
                    label: "Registros",
                    title: "Errores",
                    gaugeWidthScale: 1,
                    levelColors: ["red"]
                });
            }

            updateGauges();
        };

        var updateGauges = function () {
            pendingGauge.refresh($scope.pending.length, $scope.totalCount);
            successGauge.refresh($scope.success.length, $scope.totalCount);
            errorGauge.refresh($scope.errors.length, $scope.totalCount);
        };

        var resetGauges = function () {
            pendingGauge.refresh(0, 0);
            successGauge.refresh(0, 0);
            errorGauge.refresh(0, 0);
        };

        var resetCounters = function () {
            $scope.totalCount = 0;
            $scope.successCount = 0;
            $scope.errorCount = 0;
            $scope.errors = [];
            $scope.success = [];
        };

        var buildErrorObject = function (waybill, errors) {
            return {
                item: waybill,
                errors: errors
            }
        };

        var handleError = function (errorObject) {
            $scope.errors.push(errorObject);
            $scope.errorCount = $scope.errors.length;
            errorGauge.refresh($scope.errorCount, $scope.totalCount);
        };

        var processAll = function (rows, type) {
            var deferred = $q.defer();

            var count = rows.length;

            if (count == 0) {
                deferred.resolve();
            } else {
                var row = rows.shift();

                if (!haltProcessing) {
                    processRow(row, type).then(
                        function () {
                            $scope.success.push(row);
                            $scope.successCount = $scope.success.length;
                            successGauge.refresh($scope.successCount, $scope.totalCount);
                        },
                        function (errorObject) {
                            handleError(errorObject);
                        }).finally(function () {
                            count = rows.length;
                            pendingGauge.refresh(count, $scope.totalCount);
                            $timeout(function () {
                                processAll(rows, type).then(function () {
                                    deferred.resolve();
                                });
                            }, 1);
                        });
                } else {
                    deferred.reject();
                }
            }

            return deferred.promise;
        };

        var parseRow = function (row, type) {
            return WaybillService.fromArray(row, type);
        };

        var processRow = function (row, type) {
            console.log('processing', row, type);
            var deferred = $q.defer();

            var waybill = parseRow(row, type);

            var validationErrors = validateWaybill(waybill, type);

            if (validationErrors) {
                deferred.reject({item: waybill, errors: validationErrors});
            } else {
                var service = WaybillService.getUploadService(type);

                service.call(this, waybill).$promise.then(
                    function (response) {
                        if (!response.success) {
                            var parsedErrors = [];

                            angular.forEach(response.errors, function (value, key) {
                                parsedErrors.push({
                                    fieldName: value.fieldName,
                                    code: value.code,
                                    //message: MessageService.getErrorMessage(value.code, null, value.message) // Tomar mensajes del server
                                    message: MessageService.getErrorMessage(value.code)
                                });
                            });

                            deferred.reject({item: waybill, errors: parsedErrors});
                        } else {
                            deferred.resolve();
                        }
                    }
                );
            }

            return deferred.promise;
        };

        var validateWaybill = function (waybill, type) {
            return WaybillService.validate(waybill, type);
        };

        $scope.showErrors = {
            'step-file': false,
            'step-verify': false
        };

        $scope.validateStep = function (stepNum) {
            var stepName = stepMap[stepNum];

            if (!stepName) {
                return true;
            }

            var stepIsValid = true;

            $scope.showErrors[stepName] = true;

            switch (stepName) {
                case 'step-file':
                    if ($scope.form.file.$invalid || $scope.form.fileType.$invalid) {
                        stepIsValid = false;
                    }
                    break;
            }
            return stepIsValid;
        };

        $scope.initStep = function (stepNum) {
            var stepName = stepMap[stepNum];

            if (!stepName) {
                return;
            }

            $timeout(function () {
                switch (stepName) {
                    case 'step-file':
                        $scope.$apply(function () {
                            $scope.fileProcessed = false;
                        });
                        break;
                    case 'step-verify':
                        $scope.$apply(function () {
                            try {
                                if (!$scope.fileProcessed) {
                                    resetCounters();
                                    reader.readAsText($scope.file);
                                    $scope.fileProcessed = true;
                                }
                            } catch (error) {
                                console.log('error', error);
                            }
                        });
                        break;
                }
            }, 0);
        };

        $scope.fileSelect = function () {
            angular.element('#file_select').click();
        };

        $scope.fileNameChaged = function (element) {
            $scope.$apply(function (scope) {
                $scope.fileProcessed = false;

                if (element.files.length > 0) {
                    var file = element.files[0];
                    scope.file = file;
                    scope.model.file = file.name;
                }
            });
        };

        $scope.fileTypeChanged = function () {
            $scope.fileProcessed = false;
        };

        $scope.countErrors = function (errors) {
            console.log(errors);
            return errors.length;
        };

        $scope.editWaybillAndRetry = function (index, waybill, errors) {
            var url;

            switch ($scope.model.fileType) {
                case "waybill":
                    url = Config.get('PARTIALS_POD_WAYBILL_BATCH_LOAD_RETRY_WAYBILL');
                    break;
                case "sample":
                    url = Config.get('PARTIALS_POD_WAYBILL_BATCH_LOAD_RETRY_SAMPLE');
                    break;
            }

            if (!url) {
                throw new Error('Invalid waybill fileType: ' + $scope.model.fileType);
            }

            ISModalService.load($scope, url, {
                index: index,
                editWaybill: angular.copy(waybill),
                editErrors: errors,
                fileType: $scope.model.fileType
            }).then(function ($el) {
                    $scope.editWaybillModal = $el;
                }
            );
        };

        $scope.disacardWaybillByIndex = function (index, source) {
            return source.splice(index, 1);
        };

        $scope.$on('hidden.bs.modal', function ($modal) {
            if ($scope.editWaybillModal == $modal) {
                $scope.editWaybillModal = null;
            }
        });

        $scope.$on('editWaybill:complete', function (event, index) {
            $scope.success.push($scope.disacardWaybillByIndex(index, $scope.errors));

            updateGauges();

            if ($scope.editWaybillModal) {
                ISModalService.close($scope.editWaybillModal);
            }
        });

    }]);

app.controller('PodWaybillBulkUploadRetryCtrl', ['$scope', 'MessageService', 'WaybillService', 'Api',
    '$q',
    function ($scope, MessageService, WaybillService, Api, $q) {
        $scope.loading = false;

        $scope.upload = function (waybill) {
            var errors = WaybillService.validate(waybill, $scope.fileType);

            if (errors) {
                $scope.editErrors = errors;
            } else {
                $scope.editErrors = [];
                $scope.loading = true;

                var service = WaybillService.getUploadService(type);

                service.call(this, waybill).$promise.then(
                    function (response) {
                        if (response.success) {
                            $scope.$emit('editWaybill:complete', $scope.index);
                        } else if (response.errors) {
                            var parsedErrors = [];

                            angular.forEach(response.errors, function (value, key) {
                                parsedErrors.push({
                                    fieldName: value.fieldName,
                                    code: value.code,
                                    //message: MessageService.getErrorMessage(value.code, null, value.message) // Tomar mensajes del server
                                    message: MessageService.getErrorMessage(value.code)
                                });
                            });

                            $scope.editErrors = parsedErrors;

                            console.log($scope.editErrors);
                        }
                    }
                ).finally(function () {
                        $scope.loading = false;
                    }
                );
            }
        };

        $scope.fieldHasErrors = function (field) {
            return !!_.findWhere($scope.editErrors, {fieldName: field});
        };

        $scope.getFieldErrors = function (field) {
            var fieldErrors = [];

            var errors = _.where($scope.editErrors, {fieldName: field});

            _.each(errors, function (e) {
                fieldErrors.push(MessageService.getErrorMessage(e.code, {field: field}, e.message));
            });

            return fieldErrors;
        }

    }]);
