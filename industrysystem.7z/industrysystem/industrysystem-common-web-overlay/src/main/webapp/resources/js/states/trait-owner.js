angular.module('IndustrySystem')
    .config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.when('/trait-owner', '/trait-owner/waybill');
        $urlRouterProvider.when('/trait-owner/waybill', '/trait-owner/waybill/list');

        $stateProvider.state('trait-owner', {
                url: '/trait-owner',
                abstract: true,
                templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_TRAIT_OWNER'),
                data: {
                    loginState: 'trait-owner.login',
                    section: 'trait-owner'
                }
            }
        ).state('trait-owner.login', {
                url: '/login',
                templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_TRAIT_OWNER_LOGIN'),
                data: {
                    menu: null,
                    secure: false
                }
            }
        ).state('trait-owner.waybill', {
                url: '/waybill',
                abstract: true,
                templateUrl: angular.injector(['is.services.config']).get('Config').get('PARTIALS_TRAIT_OWNER_WAYBILL')
            }
        ).state('trait-owner.waybill.list', {
                url: '/list',
                templateProvider: ['Session', '$http', '$q', 'Config', function (Session, $http, $q, Config) {
                    var deferred = $q.defer(),
                        url = Config.get('PARTIALS_TRAIT_OWNER_WAYBILL_LIST');//_' + Session.user.type.toUpperCase());

                    $http.get(url).success(function (data) {
                        deferred.resolve(data);
                    });

                    return deferred.promise;
                }],
                controller: ['$scope', 'Api', 'Session', 'TableService', '$q', 'ISModalService', 'Config', function ($scope, Api, Session, TableService, $q, ISModalService, Config) {
                    var self = this;
                    $scope.loggedUser.type = 'trait-owner';

                    $scope.getActive = function (page, filters, sort) {
                        var defer = $q.defer();

                        Api.TraitOwnerWaybill.getActive({
                            "filter": TableService.parseFilters(filters),
                            "orderBy": TableService.parseSort(sort),
                            "page": page
                        }).$promise.then(function (response) {
                                defer.resolve(response);
                            });

                        return defer.promise;
                    };

                    $scope.viewDetail = function (waybill) {
                        ISModalService.load($scope, Config.get("PARTIALS_POD_WAYBILL_DETAIL"), {model: waybill});
                    };

                    var waybillStatusValuesDefer = $q.defer();
                    $scope.waybillStatusValues = waybillStatusValuesDefer.promise;

                    Api.PodWaybill.getStatusValues().$promise.then(function (waybillStatusValues) {
                        var parsed = [];

                        angular.forEach(waybillStatusValues, function (i) {
                            parsed.push({
                                label: i.description,
                                value: i.status
                            });
                        });

                        waybillStatusValuesDefer.resolve(parsed);
                    });
                }]
            }
        );
    }]);
