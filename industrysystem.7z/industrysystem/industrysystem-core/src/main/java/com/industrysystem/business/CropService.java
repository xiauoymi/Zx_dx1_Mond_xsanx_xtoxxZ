package com.industrysystem.business;

import com.industrysystem.entities.Crop;
import com.industrysystem.exceptions.CropNotFoundException;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 28/11/13
 */
public interface CropService {

    public List<Crop> findAllCrops();

    public Crop findCropByCode(String code) throws CropNotFoundException;

}
