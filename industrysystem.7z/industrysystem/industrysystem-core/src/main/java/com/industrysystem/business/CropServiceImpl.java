package com.industrysystem.business;

import com.industrysystem.entities.Crop;
import com.industrysystem.exceptions.CropNotFoundException;
import com.industrysystem.persistence.daos.CropDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 09/12/13
 */
@Service
public class CropServiceImpl implements CropService  {
    @Autowired
    private CropDao cropDao;

    @Override
    public List<Crop> findAllCrops() {
        return cropDao.findAllCrops();
    }
    
    @Override
    public Crop findCropByCode(String code) throws CropNotFoundException {
        return this.cropDao.findCropBy(code);
    }

}
