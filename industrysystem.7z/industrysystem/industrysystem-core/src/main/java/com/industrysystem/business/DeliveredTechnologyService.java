package com.industrysystem.business;

import com.industrysystem.business.dtos.UsedDetailDTO;
import com.industrysystem.entities.Campaign;
import com.industrysystem.entities.Grower;
import com.industrysystem.entities.Technology;

import java.math.BigDecimal;
import java.util.List;

/**
 * User: ASEQU
 * Date: 12/6/13
 * Time: 11:50 AM
 */
public interface DeliveredTechnologyService {
    public List<UsedDetailDTO> calculateTons(Grower grower, Technology technology, Campaign campaign);
    public BigDecimal calculateTotalTons(Grower grower, Technology technology, Campaign campaign);
}
