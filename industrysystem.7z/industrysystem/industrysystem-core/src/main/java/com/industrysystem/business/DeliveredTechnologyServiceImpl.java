package com.industrysystem.business;

import com.google.common.base.Function;
import com.google.common.base.Predicate;
import com.industrysystem.business.dtos.UsedDetailDTO;
import com.industrysystem.entities.*;
import com.industrysystem.persistence.daos.WaybillDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.List;

import static com.google.common.collect.Collections2.filter;
import static com.google.common.collect.Lists.newLinkedList;
import static com.google.common.collect.Lists.transform;

/**
 * User: ASEQU
 * Date: 12/6/13
 * Time: 2:33 PM
 */
@Service
public class DeliveredTechnologyServiceImpl implements DeliveredTechnologyService {

    @Autowired
    private WaybillDao waybillDao;

    @Override
    @PreAuthorize("hasStrictRoleGrower(#grower.document.typeCode, #grower.document.number)")
    public BigDecimal calculateTotalTons(Grower grower, Technology technology, Campaign campaign) {
        List<Waybill> waybills = this.waybillDao.findBy(grower, campaign);
        BigDecimal sum = new BigDecimal(0);

        for(Waybill waybill: waybills) {
            if (WaybillStatusEnum.WAYBILL_VALORIZED == waybill.getStatus() || WaybillStatusEnum.WAYBILL_VALORIZED_AND_UPDATED == waybill.getStatus()) {
                sum = sum.add(waybill.valorizationTonsSummationBy(technology).add(waybill.usedPpt()));
            }
        }

        return sum;
    }

    @Override
    @PreAuthorize("hasStrictRoleGrower(#grower.document.typeCode, #grower.document.number)")
    public List<UsedDetailDTO> calculateTons(Grower grower, Technology technology, Campaign campaign) {
        List<Waybill> waybills = waybillDao.findBy(grower, campaign);
        return newLinkedList(filter(transform(waybills, new WaybillTonsFunction(technology)), new WaybillTonsPredicate()));
    }

    class WaybillTonsPredicate implements Predicate<UsedDetailDTO> {

        @Override
        public boolean apply(UsedDetailDTO dto) {
            return WaybillStatusEnum.WAYBILL_VALORIZED.equals(dto.getWaybillStatus()) || WaybillStatusEnum.WAYBILL_VALORIZED_AND_UPDATED.equals(dto.getWaybillStatus());
        }
    }

    class WaybillTonsFunction implements Function<Waybill, UsedDetailDTO> {

        private static final String DATE_FORMAT_DD_MM_YYYY = "dd/MM/yyyy";

        Technology technology;
        SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT_DD_MM_YYYY);

        public WaybillTonsFunction(Technology technology) {
            this.technology = technology;
        }

        @Override
        public UsedDetailDTO apply(Waybill waybill) {
            BigDecimal usedPpt = waybill.usedPpt();
            BigDecimal usedPod = waybill.valorizationTonsSummationBy(this.technology);
            BigDecimal totalTons = usedPpt.add(usedPod);
            WaybillStatusEnum waybillStatus = waybill.getStatus();

            return new UsedDetailDTO(waybill.getWaybillNumber().toString(), totalTons, dateFormat.format(waybill.getCreationDate()),
                    usedPpt, usedPod, waybillStatus);
        }
    }

}