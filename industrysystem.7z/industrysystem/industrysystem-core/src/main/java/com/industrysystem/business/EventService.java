package com.industrysystem.business;

import com.industrysystem.entities.LoadDetail;
import com.industrysystem.entities.Waybill;
import com.industrysystem.entities.WaybillMessage;
import com.industrysystem.exceptions.UserNotLoggedException;

/**
 * User: AVIER
 * Date: 12/4/13
 * Time: 4:10 PM
 */
public interface EventService {
    public void saveWaybillReceivedEvent(Waybill waybill) throws UserNotLoggedException;

    public void saveSampleRequiredDeterminationEvent(LoadDetail detail) throws UserNotLoggedException;

    public void saveStoreSampleEvent(LoadDetail loadDetail) throws UserNotLoggedException;

    public void saveStoreWeightEvent(LoadDetail detail) throws UserNotLoggedException;

    public void saveValorizateWaybillEvent(LoadDetail loadDetail, WaybillMessage waybillMessage) throws UserNotLoggedException;

    public void saveWaybillExportingEvent(Waybill waybill, WaybillMessage waybillMessage) throws UserNotLoggedException;

    public void saveCuantitativeTestEvent(LoadDetail loadDetail) throws UserNotLoggedException;

    public void saveCualitativeTestEvent(LoadDetail loadDetail) throws UserNotLoggedException;

    public void saveReadyToBeInformedEvent(Waybill waybill) throws UserNotLoggedException;

    public void saveNegativeTestResultEvent(Waybill waybill) throws UserNotLoggedException;

    public void savePositiveTestResultEvent(Waybill waybill) throws UserNotLoggedException;

    void saveWaybillPartiallyReceivedEvent(Waybill waybill) throws UserNotLoggedException;

    public void saveValorizateWaybillEvent(Waybill waybill) throws UserNotLoggedException;
}
