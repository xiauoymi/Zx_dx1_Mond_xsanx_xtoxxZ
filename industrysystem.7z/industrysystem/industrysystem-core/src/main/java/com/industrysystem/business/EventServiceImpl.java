package com.industrysystem.business;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.UserNotLoggedException;
import com.industrysystem.persistence.daos.EventDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * User: AVIER
 * Date: 12/4/13
 * Time: 4:10 PM
 */

@Component
public class EventServiceImpl implements EventService {

    @Autowired
    private EventDao eventDao;

    @Autowired
    private UsersService userService;

    @Override
    @PreAuthorize("isAuthenticated()")
    public void saveWaybillReceivedEvent(Waybill waybill) throws UserNotLoggedException {
        String username = userService.getCurrentUsersUsername();
        Event event = new Event(EventTypeEnum.WAYBILL_REGISTRATION, username);
        event.setWaybill(waybill);
        eventDao.save(event);
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public void saveSampleRequiredDeterminationEvent(LoadDetail loadDetail) throws UserNotLoggedException {
        saveLoadDetailEvent(loadDetail, EventTypeEnum.SAMPLE_DETERMINATION);
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public void saveStoreSampleEvent(LoadDetail detail) throws UserNotLoggedException {
        saveLoadDetailEvent(detail, EventTypeEnum.STORE_SAMPLE_INFO);
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public void saveStoreWeightEvent(LoadDetail detail) throws UserNotLoggedException {
        this.saveLoadDetailEvent(detail, EventTypeEnum.STORE_WEIGHT);
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public void saveValorizateWaybillEvent(LoadDetail detail, WaybillMessage waybillMessage) throws UserNotLoggedException {
        String username = userService.getCurrentUsersUsername();
        Event event = new Event(EventTypeEnum.WAYBILL_VALORIZATION_RECEIVING, username);
        event.setWaybillMessage(waybillMessage);
        event.setWaybill(detail.getWaybill());
        event.setLoadDetail(detail);
        eventDao.save(event);

    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public void saveWaybillExportingEvent(Waybill waybill, WaybillMessage waybillMessage) throws UserNotLoggedException {
        String username = userService.getCurrentUsersUsername();
        Event event = new Event(EventTypeEnum.WAYBILL_EXPORTING, username);
        event.setWaybillMessage(waybillMessage);
        event.setWaybill(waybill);

        eventDao.save(event);
    }

    @PreAuthorize("isAuthenticated()")
    public void saveCuantitativeTestEvent(LoadDetail detail) throws UserNotLoggedException {
        saveLoadDetailEvent(detail, EventTypeEnum.QUANTITATIVE_TEST_DETERMINATION);//To change body of implemented methods use File | Settings | File Templates.
    }

    @PreAuthorize("isAuthenticated()")
    public void saveCualitativeTestEvent(LoadDetail detail) throws UserNotLoggedException {
        saveLoadDetailEvent(detail, EventTypeEnum.QUALITATIVE_TEST_DETERMINATION);
    }

    @PreAuthorize("isAuthenticated()")
    public void saveReadyToBeInformedEvent(Waybill waybill) throws UserNotLoggedException {
        for (LoadDetail loadDetail : waybill.getLoadDetails()) {
            Event event = new Event();
            event.setType(EventTypeEnum.WAYBILL_TO_BE_INFORMED_DETERMINATION);
            event.setWaybill(waybill);
            event.setLoadDetail(loadDetail);
            event.setUser(userService.getCurrentUsersUsername());
            event.setTime(new Date());
            eventDao.save(event);
        }
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public void saveNegativeTestResultEvent(Waybill waybill) throws UserNotLoggedException {
        String username = userService.getCurrentUsersUsername();
        Event event = new Event(EventTypeEnum.NEGATIVE_TEST_RESULT, username);
        event.setUser(username);
        event.setWaybill(waybill);

        eventDao.save(event);
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public void savePositiveTestResultEvent(Waybill waybill) throws UserNotLoggedException {
        String username = userService.getCurrentUsersUsername();
        Event event = new Event(EventTypeEnum.NO_TRAIT_OWNER_MESSAGE, username);
        event.setUser(username);
        event.setWaybill(waybill);

        eventDao.save(event);
    }

    private void saveLoadDetailEvent(LoadDetail detail, EventTypeEnum type) throws UserNotLoggedException {
        String username = userService.getCurrentUsersUsername();
        Event event = new Event(type, username);
        event.setWaybill(detail.getWaybill());
        event.setLoadDetail(detail);

        eventDao.save(event);
    }

    @Override
    public void saveWaybillPartiallyReceivedEvent(Waybill waybill) throws UserNotLoggedException {
        String username = userService.getCurrentUsersUsername();
        Event event = new Event(EventTypeEnum.WAYBILL_PARTIALLY_RECIVED, username);
        event.setWaybill(waybill);
        eventDao.save(event);
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public void saveValorizateWaybillEvent(Waybill waybill) throws UserNotLoggedException {
        String username = userService.getCurrentUsersUsername();
        for (LoadDetail loadDetail : waybill.getLoadDetails()) {
            Event event = new Event(EventTypeEnum.WAYBILL_VALORIZATION_RECEIVING, username);
            event.setTime(new Date());
            event.setWaybill(waybill);
            event.setLoadDetail(loadDetail);
            eventDao.save(event);
        }

    }

}