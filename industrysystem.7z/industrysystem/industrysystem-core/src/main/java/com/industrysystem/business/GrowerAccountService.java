package com.industrysystem.business;

import com.industrysystem.business.users.dtos.GrowerAccountDto;
import com.industrysystem.exceptions.GrowerAccountRegistrationException;
import org.springframework.security.access.prepost.PreAuthorize;

/**
 * Created with IntelliJ IDEA.
 * User: JFVERO
 * Date: 20/12/13
 * Time: 14:44
 */
public interface GrowerAccountService {

    public void register(GrowerAccountDto growerAccountDto) throws GrowerAccountRegistrationException;

}