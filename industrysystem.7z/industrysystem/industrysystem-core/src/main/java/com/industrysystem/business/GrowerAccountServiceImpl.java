package com.industrysystem.business;

import com.industrysystem.business.users.dtos.GrowerAccountDto;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.BusinessException;
import com.industrysystem.exceptions.GrowerAccountRegistrationException;
import com.industrysystem.persistence.daos.CropTechnologyDao;
import com.industrysystem.persistence.daos.DocumentTypeDao;
import com.industrysystem.persistence.daos.GrowerAccountDao;
import com.industrysystem.persistence.daos.GrowerDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import static org.apache.commons.lang.StringUtils.upperCase;

/**
 * Created with IntelliJ IDEA.
 * User: JFVERO
 * Date: 20/12/13
 * Time: 14:44
 */
@Component
public class GrowerAccountServiceImpl implements GrowerAccountService {

    @Autowired
    private GrowerAccountDao growerAccountDao;
    @Autowired
    private GrowerDao growerDao;
    @Autowired
    private DocumentTypeDao documentTypeDao;
    @Autowired
    private CropTechnologyDao cropTechnologyDao;

    @Transactional(rollbackFor = {BusinessException.class})
    @Override
    @PreAuthorize("hasStrictRoleTOCommercial(#growerAccountDto.traitOwnerCode)")
    public void register(GrowerAccountDto growerAccountDto) throws GrowerAccountRegistrationException {
        try {
            DocumentType documentType = documentTypeDao.findByCode(upperCase(growerAccountDto.getDocumentTypeCode()));
            Grower grower = growerDao.findOrCreateGrower(new Document(documentType, growerAccountDto.getDocumentNumber()),
                    upperCase(growerAccountDto.getName()));
            CropTechnology cropTechnology = cropTechnologyDao.findByCropCodeAndTechnologyCodeAndTraitOwnerCode(
                    upperCase(growerAccountDto.getCropCode()), upperCase(growerAccountDto.getTechnologyCode()),
                    upperCase(growerAccountDto.getTraitOwnerCode()));

            GrowerAccount growerAccount = new GrowerAccount();
            growerAccount.setNumber(growerAccountDto.getAccountNumber());
            growerAccount.setGrower(grower);
            growerAccount.setCropTechnology(cropTechnology);

            growerAccountDao.create(growerAccount);
        } catch (BusinessException e) {
            throw new GrowerAccountRegistrationException(e, growerAccountDto);
        } catch (Exception e) {
            throw new GrowerAccountRegistrationException(e, growerAccountDto);
        }
    }

}