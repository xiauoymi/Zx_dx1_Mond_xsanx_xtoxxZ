package com.industrysystem.business;

import com.industrysystem.business.dtos.GrowerBalanceDTO;
import com.industrysystem.business.dtos.GrowerBalanceOperationDto;
import com.industrysystem.business.dtos.TransactionDto;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.CampaignNotFoundException;
import com.industrysystem.exceptions.GrowerAccountUpdateException;
import com.industrysystem.exceptions.GrowerNotFoundException;
import com.industrysystem.exceptions.TechnologyNotFoundException;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;
import java.util.List;

public interface GrowerBalanceService {

    public Transaction registerBalanceOperations(TransactionDto transactionDto, List<GrowerBalanceOperationDto> growerBalanceOperationItemsDto, String traitOwnerCode) throws GrowerAccountUpdateException;
    public List<GrowerBalanceDTO> findConsolidatedNetAvailableCreditBy(String documentNumber, String documentType, String technologyCode) throws GrowerNotFoundException, CampaignNotFoundException, TechnologyNotFoundException;
}
