package com.industrysystem.business;

import com.industrysystem.business.dtos.*;
import com.industrysystem.business.mappers.GrowerBalanceMapper;
import com.industrysystem.business.validators.GrowerBalanceValidator;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.*;
import com.industrysystem.persistence.daos.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.NoResultException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import static com.google.common.collect.Iterables.getFirst;

@Service
public class GrowerBalanceServiceImpl implements GrowerBalanceService {

    @Autowired
    private GrowerBalanceDao growerBalanceDao;

    @Autowired
    private CropTechnologyForCampaignDao cropTechnologyForCampaignDao;

    @Autowired
    private TransactionDao transactionDao;

    @Autowired
    private GrowerBalanceValidator growerBalanceValidator;

    @Autowired
    private GrowerBalanceMapper growerBalanceMapper;

    @Autowired
    private DeliveredTechnologyService deliveredTechnologyService;
    
    @Autowired
    private GrowerDao growerDao;

    @Autowired
    private TechnologyDao technologyDao;

    @Autowired
    private CampaignDao campaignDao;

    @Autowired
    private WaybillDao waybillDao;

    @Autowired
    private WaybillTransactionDao waybillTransactionDao;

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    @PreAuthorize("hasStrictRoleTOCommercial(#traitOwnerCode)")
    public Transaction registerBalanceOperations(TransactionDto transactionDto,
            List<GrowerBalanceOperationDto> growerBalanceOperationItemsDto, String traitOwnerCode)
            throws GrowerAccountUpdateException {
        try{
            growerBalanceValidator.validateTransaction(transactionDto);
            growerBalanceValidator.validategrowerBalanceOperationItems(growerBalanceOperationItemsDto);
            Waybill waybill = waybillDao.findWaybillByWaybillNumber(transactionDto.getWaybillNumberAsLong());
            validateWayBillNotContainsTransaction(waybill);

            Transaction transaction= growerBalanceMapper.mapTransaction(transactionDto);

            for (GrowerBalanceOperationDto item : growerBalanceOperationItemsDto){

                growerBalanceValidator.validateGrowerBalanceOperation(item);

                GrowerBalance growerBalance=findGrowerBalance(growerBalanceMapper.mapGrowerAccount(item,traitOwnerCode), item.getCampaignCode());

                registerBalanceOperation(transaction,growerBalance,item.getValue(),item.getBalanceType());
            }

            transactionDao.save(transaction);

            createWayBillTransaction(waybill, transaction);

            return transaction;
        }catch (BusinessException e) {
            throw new GrowerAccountUpdateException(e);
        }catch (Exception e) {
            throw new GrowerAccountUpdateException(e);
        }
    }

    private void createWayBillTransaction(Waybill waybill, Transaction transaction) {
        WaybillTransaction waybillTransaction = new WaybillTransaction();
        waybillTransaction.setTransaction(transaction);
        waybillTransaction.setWaybill(waybill);
        waybillTransactionDao.save(waybillTransaction);
    }

    private void validateWayBillNotContainsTransaction(Waybill waybill) throws GrowerAccountUpdateException {
        if (waybill.getWaybillTransaction() != null) {
            throw new GrowerAccountUpdateException(new BusinessError(BusinessError.WAYBILL_HAS_TRANSACTION, "WayBill already has a Transaction associated"));
        }
    }

    @Override
    @Transactional
    @PreAuthorize("hasStrictRoleGrower(#documentType, #documentNumber)")
    public List<GrowerBalanceDTO> findConsolidatedNetAvailableCreditBy(String documentNumber, String documentType,
            String technologyCode) throws GrowerNotFoundException, CampaignNotFoundException, TechnologyNotFoundException {
        List<GrowerBalanceDTO> balances = new LinkedList<GrowerBalanceDTO>();
        DateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy");

        Grower grower = growerDao.findGrowerByDocument(new Document(documentType, documentNumber));
        Technology technology = technologyDao.findByCode(technologyCode);
        Campaign currentCampaign = campaignDao.findCampaignBy(new Date());

        BigDecimal currentCampaignAvailable = growerBalanceFor(grower, technology, currentCampaign).getAvailable();
        BigDecimal pastCampaignAvailable = addExtendedOfAllFollowingsCampaigns(grower, technology, currentCampaign.getPrevious());
        BigDecimal nextCampaignAvailable = growerBalanceFor(grower, technology, currentCampaign.getNext()).getAvailable();

        balances.add(new GrowerBalanceDTO(new CampaignDTO(currentCampaign.getCode(), currentCampaign.getDescription(), new DateDTO(dateFormatter.format(currentCampaign.getDateFrom()), dateFormatter.format(currentCampaign.getDateTo()))),
                deliveredTechnologyService.calculateTotalTons(grower, technology, currentCampaign), currentCampaignAvailable, deliveredTechnologyService.calculateTons(grower, technology, currentCampaign), pastCampaignAvailable));
        balances.add(new GrowerBalanceDTO(new CampaignDTO(currentCampaign.getNext().getCode(), currentCampaign.getNext().getDescription(), new DateDTO(dateFormatter.format(currentCampaign.getNext().getDateFrom()), dateFormatter.format(currentCampaign.getNext().getDateTo()))),
                deliveredTechnologyService.calculateTotalTons(grower, technology, currentCampaign.getNext()), nextCampaignAvailable, deliveredTechnologyService.calculateTons(grower, technology, currentCampaign.getNext()), null));

        return balances;
    }

    /**
     * Add the GrowerBalances extended of all past campaigns
     * @param grower to select the GrowerBalance
     * @param technology to select the GrowerBalance
     * @param untilCampaign the cut campaign to do the add, including its
     * @return the value off the add
     */
    protected BigDecimal addExtendedOfAllFollowingsCampaigns(Grower grower, Technology technology, Campaign untilCampaign) {
        BigDecimal sum = new BigDecimal(0);

        for (Campaign campaign = untilCampaign; campaign != null ; campaign = campaign.getPrevious()) {
            GrowerBalance growerBalance = new GrowerBalance();
            growerBalance.setExtended(new BigDecimal(0));
            sum = sum.add(getFirst(this.growerBalanceDao.findBy(grower, technology, campaign), growerBalance).getExtended());
        }

        return sum;
    }

    private GrowerBalance findGrowerBalance(GrowerAccount growerAccount, String campaignCode) throws GrowerAccountUpdateException {
        GrowerBalance growerBalance = growerBalanceDao.findBalanceByAccountAndCampaignCode(growerAccount, campaignCode);
        if (growerBalance == null) {
            growerBalance = createGrowerBalance(growerAccount, campaignCode);
            growerBalanceDao.save(growerBalance);
        }
        return growerBalance;
    }

    private GrowerBalance createGrowerBalance(GrowerAccount growerAccount, String campaignCode) throws GrowerAccountUpdateException {
            GrowerBalance growerBalance = new GrowerBalance();
            growerBalance.setGrowerAccount(growerAccount);

            CropTechnologyForCampaign cropTechnologyForCampaign;
            try{
                CropTechnology cropTechnology = growerAccount.getCropTechnology();
                cropTechnologyForCampaign = cropTechnologyForCampaignDao.findByCampaignCodeAndCropCodeAndTechnologyCode(
                        campaignCode, cropTechnology.getCrop().getCode(), cropTechnology.getTechnology().getCode());
            } catch (NoResultException e) {
                throw new GrowerAccountUpdateException(new BusinessError(BusinessError.CROP_TECHNOLOGY_CAMPAIGN_NOT_FOUND,
                        "Crop Technology for Campaign not exists"));
            }

            growerBalance.setCropTechnologyForCampaign(cropTechnologyForCampaign);

            return growerBalance;
    }

    private void registerBalanceOperation(Transaction transaction, GrowerBalance growerBalance, BigDecimal value,
            GrowerBalanceType balanceType) {
        addOperationValueToGrowerBalance(growerBalance, value, balanceType);
        transaction.add(growerBalanceMapper.mapTransactionItem(value, balanceType, growerBalance));
   }

    private void addOperationValueToGrowerBalance(GrowerBalance growerBalance, BigDecimal value, GrowerBalanceType balanceType) {
        switch (balanceType) {
            case AVAILABLE: growerBalance.addAvailable(value); break;
            case PENDING: growerBalance.addPending(value); break;
            case USED: growerBalance.addUsed(value); break;
            case EXPIRED: growerBalance.addExpired(value); break;
            case EXTENDED: growerBalance.addExtended(value); break;
            case EXTENDED_TRANSFER: growerBalance.addExtendedTransfer(value); break;
            case AVAILABLE_TRANSFER: growerBalance.addAvailableTransfer(value); break;
            case UNUSABLE: growerBalance.addUnusable(value); break;
        }
    }

    public GrowerBalance growerBalanceFor(Grower grower, Technology technology, Campaign campaign) {
        GrowerBalance balance = new GrowerBalance();
        balance.setAvailable(new BigDecimal(0));
        return getFirst(this.growerBalanceDao.findBy(grower, technology, campaign), balance);
    }

}