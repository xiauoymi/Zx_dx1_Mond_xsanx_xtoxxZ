package com.industrysystem.business;

import com.industrysystem.business.users.dtos.GrowerAccountDto;
import com.industrysystem.entities.Document;
import com.industrysystem.entities.Grower;
import com.industrysystem.entities.GrowerBalance;
import com.industrysystem.entities.Technology;
import com.industrysystem.exceptions.BusinessException;
import com.industrysystem.exceptions.GrowerAccountRegistrationException;
import com.industrysystem.exceptions.GrowerNotFoundException;
import com.industrysystem.persistence.daos.GrowerBalanceDao;
import com.industrysystem.persistence.daos.GrowerDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * User: PPERA
 * Date: 2/28/13
 * Time: 9:54 AM
 * <p/>
 * Implementation of the business application interface that controls the transaction scope.
 */
@Component
public class GrowerServiceImpl implements GrowersService {

    @Autowired
    private GrowerAccountService growerAccountService;

    @Autowired
    private GrowerDao growerDao;

    @Autowired
    private GrowerBalanceDao growerBalanceDao;

    @Transactional(rollbackFor = {BusinessException.class})
    @Override
    public List<GrowerBalance> findGrowerBalancesByDocument(Document document) throws GrowerNotFoundException {
        Grower grower = this.growerDao.findGrowerByDocument(document);
        return this.growerBalanceDao.findBalancesByGrower(grower);
    }

    @Transactional(rollbackFor = {BusinessException.class})
    @Override
    @PreAuthorize("isAuthenticated()")
    public Grower findGrowerByDocument(Document document) throws GrowerNotFoundException {
        return this.growerDao.findGrowerByDocument(document);
    }

    @Override
    public List<GrowerBalance> findGrowerBalancesByDocumentAndTechnology(Document document, Technology technology) throws GrowerNotFoundException {
        Grower grower = this.growerDao.findGrowerByDocument(document);
        return this.growerBalanceDao.findBalancesByGrowerAndTechnology(grower, technology);
    }
    
    @Override
    public List<Grower> findGrowersByDocuments(List<Document> documents) {
    	return this.growerDao.findGrowersByDocuments(documents);
    }

    @Transactional(rollbackFor = {BusinessException.class})
    @Override
    //TODO check with list.
//    @PreAuthorize("hasStrictRoleTOCommercial(#accounts.traitOwnerCode)")
    public void register(List<GrowerAccountDto> accounts) throws GrowerAccountRegistrationException {
        for (GrowerAccountDto account: accounts) {
            growerAccountService.register(account);
        }
    }

}