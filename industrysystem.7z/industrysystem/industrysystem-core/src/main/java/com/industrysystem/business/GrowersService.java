package com.industrysystem.business;

import com.industrysystem.business.users.dtos.GrowerAccountDto;
import com.industrysystem.entities.Document;
import com.industrysystem.entities.Grower;
import com.industrysystem.entities.GrowerBalance;
import com.industrysystem.entities.Technology;
import com.industrysystem.exceptions.GrowerAccountRegistrationException;
import com.industrysystem.exceptions.GrowerNotFoundException;

import java.util.List;

/**
 * User: PPERA
 * Date: 2/28/13
 * Time: 9:51 AM
 *
 * Provides the interface for the business logic layer of the application.
 * Implementations must perform business validations, business validations and
 * communicate with the persistence layer.
 */
public interface GrowersService {
	
	//TODO: PostFilter by traitOwner if applicable
	public List<GrowerBalance> findGrowerBalancesByDocument(Document document) throws GrowerNotFoundException;

	//TODO: PreAuthorize by traitOwner if applicable
	public List<GrowerBalance> findGrowerBalancesByDocumentAndTechnology(Document document, Technology technology) throws GrowerNotFoundException;
	
    public Grower findGrowerByDocument(Document document) throws GrowerNotFoundException;
    
    public List<Grower> findGrowersByDocuments(List<Document> documents);

    public void register(List<GrowerAccountDto> accounts) throws GrowerAccountRegistrationException;

}