package com.industrysystem.business;

import com.industrysystem.entities.Document;
import com.industrysystem.exceptions.IntervinientNotFoundException;

/**
 * User: IMDORI
 * Date: 27/01/14
 * Time: 14:44
 */
public interface IntervinientService {
    String getIntervinientName(Document document) throws IntervinientNotFoundException;
}
