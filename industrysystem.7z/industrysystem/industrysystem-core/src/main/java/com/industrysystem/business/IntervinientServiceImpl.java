package com.industrysystem.business;

import com.industrysystem.entities.Document;
import com.industrysystem.entities.Grower;
import com.industrysystem.entities.PodHeadOffice;
import com.industrysystem.exceptions.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * User: IMDORI
 * Date: 27/01/14
 * Time: 14:45
 */
@Service
public class IntervinientServiceImpl implements IntervinientService {

    @Autowired
    private PodService podService;
    @Autowired
    private GrowersService growerService;

    @Override
    public String getIntervinientName(Document document) throws IntervinientNotFoundException {
        try {
            try {
                PodHeadOffice pod = podService.findPodByDocument(document);
                return pod.getName();
            } catch (PodNotFoundException podEx) {
                Grower grower = growerService.findGrowerByDocument(document);
                return grower.getName();
            }
        } catch (BusinessException e) {
            throw new IntervinientNotFoundException(document);
        }
    }
}
