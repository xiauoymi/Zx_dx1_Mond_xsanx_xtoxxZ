package com.industrysystem.business;

import com.industrysystem.entities.Laboratory;
import com.industrysystem.exceptions.LaboratoryNotFoundException;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 17/12/13
 */
public interface LaboratoryService {
    public List<Laboratory> findLaboratories();
    public Laboratory findLaboratoryByLabCode(String labCode) throws LaboratoryNotFoundException;
}
