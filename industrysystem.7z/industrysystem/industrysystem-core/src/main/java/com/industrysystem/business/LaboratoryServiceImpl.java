package com.industrysystem.business;

import com.industrysystem.entities.Laboratory;
import com.industrysystem.exceptions.LaboratoryNotFoundException;
import com.industrysystem.persistence.daos.LaboratoryDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 11/12/13
 */

@Component
public class LaboratoryServiceImpl implements LaboratoryService {

    @Autowired
    private LaboratoryDao laboratoryDao;

    @Override
    @PreAuthorize("isAuthenticated()")
    public List<Laboratory> findLaboratories() {
        return laboratoryDao.findLaboratories();
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public Laboratory findLaboratoryByLabCode(String labCode) throws LaboratoryNotFoundException {
        return laboratoryDao.findLaboratoryByLabCode(labCode);
    }
}
