package com.industrysystem.business;

import com.industrysystem.entities.Location;
import com.industrysystem.exceptions.LocationNotFoundException;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 10/12/13
 */
public interface LocationService {

    
    public List<Location> findLocationsFrom(Long province);

    public Location findLocationById(long locationCode) throws LocationNotFoundException;

}
