package com.industrysystem.business;

import com.industrysystem.entities.Location;
import com.industrysystem.exceptions.LocationNotFoundException;
import com.industrysystem.persistence.daos.LocationDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 10/12/13
 */
@Component
public class LocationServiceImpl implements LocationService {

    @Autowired
    private LocationDao locationDAO;

    @Override
    @PreAuthorize("isAuthenticated()")
    public List<Location> findLocationsFrom(Long provinceCode) {
        return locationDAO.findLocationsFrom(provinceCode);
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public Location findLocationById(long locationCode) throws LocationNotFoundException {
        return locationDAO.findLocationByCode(locationCode);
    }
}
