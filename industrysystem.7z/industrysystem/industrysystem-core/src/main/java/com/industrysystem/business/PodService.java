package com.industrysystem.business;

import com.industrysystem.entities.Document;
import com.industrysystem.entities.PodBranch;
import com.industrysystem.entities.PodHeadOffice;
import com.industrysystem.exceptions.PodNotFoundException;

/**
 * User: PPERA
 * Date: 24/09/13
 * Time: 13:15
 */
public interface PodService {

    public PodBranch findPodByDocumentAndCommercialCode(Document document, Long commercialCode) throws PodNotFoundException;

    public PodHeadOffice findPodByDocument(Document document) throws PodNotFoundException;

}
