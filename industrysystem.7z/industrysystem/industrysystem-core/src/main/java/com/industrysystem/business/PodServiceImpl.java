package com.industrysystem.business;

import com.industrysystem.entities.Document;
import com.industrysystem.entities.PodBranch;
import com.industrysystem.entities.PodHeadOffice;
import com.industrysystem.exceptions.PodNotFoundException;
import com.industrysystem.persistence.daos.PodDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

/**
 * User: PPERA
 * Date: 24/09/13
 * Time: 13:15
 */
@Component
public class PodServiceImpl implements PodService {

    @Autowired
    private PodDao podDao;

    @Override
    @PreAuthorize("isAuthenticated()")
    public PodBranch findPodByDocumentAndCommercialCode(Document document, Long commercialCode) throws PodNotFoundException {
        return this.podDao.findByDocumentAndCommercialCode(document, commercialCode);
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public PodHeadOffice findPodByDocument(Document document) throws PodNotFoundException {
        return this.podDao.findByDocument(document);
    }

}