package com.industrysystem.business;

import com.industrysystem.entities.GrowerAccount;
import com.industrysystem.entities.Transaction;
import org.springframework.security.access.prepost.PreAuthorize;

import java.math.BigDecimal;

/**
 * User: CGLLLO
 * Date: 3/8/13
 * Time: 11:40 AM
 */
public interface PrepaidTonsService {
    

	@Deprecated
    public void registerSale(BigDecimal saleValue, Transaction transaction, GrowerAccount growerAccount, String campaignCode);

	@Deprecated
    public void registerPayment(BigDecimal paymentValue, Transaction transaction, GrowerAccount growerAccount, String campaignCode);

    public void registerSaleAndPayment(BigDecimal value, Transaction transaction, GrowerAccount growerAccount, String campaignCode);

    @Deprecated
    public void cancelSale(BigDecimal saleValue, Transaction transaction, GrowerAccount growerAccount, String campaignCode);
    
    public void cancelPayment(BigDecimal saleValue, Transaction transaction, GrowerAccount growerAccount, String campaignCode);

}
