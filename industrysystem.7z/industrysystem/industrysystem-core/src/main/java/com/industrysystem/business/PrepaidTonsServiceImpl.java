package com.industrysystem.business;

import com.industrysystem.entities.*;
import com.industrysystem.exceptions.BusinessException;
import com.industrysystem.persistence.daos.CropTechnologyForCampaignDao;
import com.industrysystem.persistence.daos.GrowerAccountDao;
import com.industrysystem.persistence.daos.GrowerBalanceDao;
import com.industrysystem.persistence.daos.TransactionDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

/**
 * User: CGLLLO
 * Date: 3/8/13
 * Time: 11:41 AM
 */
@Component
public class PrepaidTonsServiceImpl implements PrepaidTonsService {

    private static final Logger log = LoggerFactory.getLogger(PrepaidTonsServiceImpl.class);

    protected enum BalanceOperationType {
        CREATION("CREATION"),
        ADD_AVAILABLE("ADD_AVAILABLE"),
        ADD_PENDING("ADD_PENDING"),
        SUBTRACT_PENDING("SUBTRACT_PENDING"),
        ADD_UNUSABLE("ADD_UNUSABLE"), 
        SUBTRACT_AVAILABLE("SUBSTRACT_AVAILABLE");

        private String code;

        private BalanceOperationType(String code) {
            this.code = code;
        }

        @Override
        public String toString() {
            return code;
        }
    }

    @Autowired
    private GrowerAccountDao growerAccountDao;

    @Autowired
    private GrowerBalanceDao growerBalanceDao;

    @Autowired
    private TransactionDao transactionDao;

    @Autowired
    private CropTechnologyForCampaignDao cropTechnologyForCampaignDao;

    @Transactional(rollbackFor = {BusinessException.class})
    @Override
    public void registerSale(BigDecimal saleValue, Transaction transaction, GrowerAccount growerAccount, String campaignCode) {
        growerAccount = growerAccountDao.refreshAccount(growerAccount);
        GrowerBalance growerBalance = this.growerBalanceDao.findBalanceByAccountAndCampaignCode(growerAccount, campaignCode);

        if (growerBalance == null) {
            log.info("Creating new GrowerBalance: accountid=" + growerAccount.getId() + ", campaignCode=" + campaignCode);
            growerBalance = new GrowerBalance();
            growerBalance.setGrowerAccount(growerAccount);
            growerBalance.setPending(saleValue);

            CropTechnology cropTechnology = growerAccount.getCropTechnology();
            CropTechnologyForCampaign cropTechnologyForCampaign = cropTechnologyForCampaignDao.findByCampaignCodeAndCropCodeAndTechnologyCode(campaignCode, cropTechnology.getCrop().getCode(), cropTechnology.getTechnology().getCode());

            growerBalance.setCropTechnologyForCampaign(cropTechnologyForCampaign);

            transaction.add(createTransactionItem(transaction, saleValue, BalanceOperationType.CREATION, growerBalance));
            growerBalanceDao.save(growerBalance);
        } else {
            growerBalance.addPending(saleValue);
        }

        transaction.add(createTransactionItem(transaction, saleValue, BalanceOperationType.ADD_PENDING, growerBalance));
        transactionDao.save(transaction);
    }

    @Transactional(rollbackFor = {BusinessException.class})
    @Override
    public void registerPayment(BigDecimal paymentValue, Transaction transaction, GrowerAccount growerAccount, String campaignCode) {
        growerAccount = growerAccountDao.refreshAccount(growerAccount);
        GrowerBalance growerBalance = this.growerBalanceDao.findBalanceByAccountAndCampaignCode(growerAccount, campaignCode);

        if (growerBalance == null) {
        	throw new RuntimeException("GrowerBalance cannot be null at this point");
        }
        growerBalance.subtractPending(paymentValue);
        transaction.add(createTransactionItem(transaction, paymentValue, BalanceOperationType.SUBTRACT_PENDING, growerBalance));

        growerBalance.addAvailable(paymentValue);
        transaction.add(createTransactionItem(transaction, paymentValue, BalanceOperationType.ADD_AVAILABLE, growerBalance));
        transactionDao.save(transaction);
    }

    @Transactional(rollbackFor = {BusinessException.class})
    @Override
    public void cancelSale(BigDecimal saleValue, Transaction transaction, GrowerAccount growerAccount, String campaignCode) {
        growerAccount = growerAccountDao.refreshAccount(growerAccount);
        GrowerBalance growerBalance = this.growerBalanceDao.findBalanceByAccountAndCampaignCode(growerAccount, campaignCode);

        growerBalance.subtractPending(saleValue);
        GrowerTransactionItem txItemGrower = createTransactionItem(transaction, saleValue, BalanceOperationType.SUBTRACT_PENDING, growerBalance);
        transaction.add(txItemGrower);

        growerBalance.addUnusable(saleValue);
        txItemGrower = createTransactionItem(transaction, saleValue, BalanceOperationType.ADD_UNUSABLE, growerBalance);
        transaction.add(txItemGrower);

        transactionDao.save(transaction);
    }
    
    @Transactional(rollbackFor = {BusinessException.class})
	@Override
	public void cancelPayment(BigDecimal saleValue, Transaction transaction, GrowerAccount growerAccount, String campaignCode) {
		growerAccount = growerAccountDao.refreshAccount(growerAccount);
        GrowerBalance growerBalance = this.growerBalanceDao.findBalanceByAccountAndCampaignCode(growerAccount, campaignCode);

        growerBalance.subtractAvailable(saleValue);
        GrowerTransactionItem txItemGrower = createTransactionItem(transaction, saleValue, BalanceOperationType.SUBTRACT_AVAILABLE, growerBalance);
        transaction.add(txItemGrower);

        growerBalance.addUnusable(saleValue);
        txItemGrower = createTransactionItem(transaction, saleValue, BalanceOperationType.ADD_UNUSABLE, growerBalance);
        transaction.add(txItemGrower);

        transactionDao.save(transaction);
		
	}

	@Override
	@Transactional(rollbackFor = {BusinessException.class})
    public void registerSaleAndPayment(BigDecimal value, Transaction transaction, GrowerAccount growerAccount, String campaignCode) {
		registerSale(value, transaction, growerAccount, campaignCode);
		registerPayment(value, transaction, growerAccount, campaignCode);
	}

    private GrowerTransactionItem createTransactionItem(Transaction transaction, BigDecimal value, BalanceOperationType operationType, GrowerBalance growerBalance) {
        GrowerTransactionItem itemGrower = new GrowerTransactionItem();
        itemGrower.setGrowerBalance(growerBalance);
        itemGrower.setValue(value);
        itemGrower.setBalanceName(operationType.toString());
        itemGrower.setTransaction(transaction);
        return itemGrower;
    }

}