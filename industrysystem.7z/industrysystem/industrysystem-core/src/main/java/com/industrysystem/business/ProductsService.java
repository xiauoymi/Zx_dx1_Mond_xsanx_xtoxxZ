package com.industrysystem.business;

import com.industrysystem.entities.Technology;
import com.industrysystem.exceptions.TechnologyNotFoundException;

import java.util.List;

/**
 * User: PPERA
 * Date: 2/28/13
 * Time: 9:51 AM
 *
 * Provides the interface for the business logic layer of the application.
 * Implementations must perform business validations, business validations and
 * communicate with the persistence layer.
 */
public interface ProductsService {
	
	//TODO: PostFilter by traitOwner if applicable
    public List<Technology> findAvailableTechnologies();
    
    //TODO: PostAuthorize by traitOwner if applicable
    public Technology loadTechnology(long technologyId);

    public Technology findByCode(String technologyCode) throws TechnologyNotFoundException;
}
