package com.industrysystem.business;

import com.industrysystem.entities.Technology;
import com.industrysystem.exceptions.TechnologyNotFoundException;
import com.industrysystem.persistence.daos.CropTechnologyDao;
import com.industrysystem.persistence.daos.TechnologyDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * User: PPERA
 * Date: 2/28/13
 * Time: 9:54 AM
 * <p/>
 * Implementation of the business application interface that controls the transaction scope.
 */
@Component
public class ProductsServiceImpl implements ProductsService {

    @Autowired
    private CropTechnologyDao cropTechnologyDao;

    @Autowired
    private TechnologyDao technologyDao;

	@Override
	public List<Technology> findAvailableTechnologies() {
		return cropTechnologyDao.findTechnologies();
	}
	
	@Override
	public Technology loadTechnology(long technologyId) {
		return cropTechnologyDao.loadTechnology(technologyId);
	}

    @Override
    public Technology findByCode(String technologyCode) throws TechnologyNotFoundException {
        return technologyDao.findByCode(technologyCode);
    }
}
