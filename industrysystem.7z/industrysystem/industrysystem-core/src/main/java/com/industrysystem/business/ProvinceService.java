package com.industrysystem.business;

import com.industrysystem.entities.Province;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 05/12/13
 */
public interface ProvinceService {
    public List<Province> findProvinces();
}
