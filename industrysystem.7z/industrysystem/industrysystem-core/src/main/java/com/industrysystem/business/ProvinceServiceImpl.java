package com.industrysystem.business;

import com.industrysystem.entities.Province;
import com.industrysystem.persistence.daos.ProvinceDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 05/12/13
 */
@Service
public class ProvinceServiceImpl implements ProvinceService {
    @Autowired
    private ProvinceDao provinceDao;

    @Override
    @PreAuthorize("isAuthenticated()")
    public List<Province> findProvinces() {
        return provinceDao.findProvinces();
    }
}
