package com.industrysystem.business;

/**
 * Created with IntelliJ IDEA.
 * User: AVIER
 * Date: 12/9/13
 * Time: 3:48 PM
 * To change this template use File | Settings | File Templates.
 */
public interface StateService {
}
