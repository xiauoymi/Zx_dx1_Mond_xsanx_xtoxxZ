package com.industrysystem.business;

import com.industrysystem.persistence.daos.report.ReportRequest;
import com.industrysystem.persistence.daos.report.ReportResponse;

/**
 * User: CGLLLO
 * Date: 18/02/14
 */
public interface TestListingService {

    ReportResponse createReportResponse(ReportRequest reportRequest, int maxResults);
}
