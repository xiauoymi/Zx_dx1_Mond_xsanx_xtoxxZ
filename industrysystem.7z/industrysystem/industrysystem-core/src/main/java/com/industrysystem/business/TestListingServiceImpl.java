package com.industrysystem.business;



import com.google.common.collect.Lists;
import com.industrysystem.business.TestsServiceImpl;
import com.industrysystem.business.dtos.CompleteTestDto;
import com.industrysystem.business.users.UsersService;

import com.industrysystem.entities.TestRequest;
import com.industrysystem.entities.WaybillStatusEnum;

import com.industrysystem.persistence.daos.report.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * User: PMIRIB
 * Date: 25/02/14
 */
@Component
public class TestListingServiceImpl implements TestListingService {

    public static String COMMON_QUERY = "where tr.loadDetail.waybill.status in (:status) "
                                       +"and tr.loadDetail.laboratory.code in (:laboratoryCodes)";

    public static String BASE_QUERY = "select tr "
                                     +"from TestRequest tr "
                                     + COMMON_QUERY;

    public static String QUANTITATIVE_BASE_QUERY = "select tr "
                                                  +"from CuantitativeTestRequest tr "
                                                  + COMMON_QUERY;

    public static String QUALITATIVE_BASE_QUERY = "select tr "
                                                 +"from QualitativeTestRequest tr "
                                                 + COMMON_QUERY;

    private final Map<String, String> FILTER_MAP = new HashMap<String, String>();

    @Autowired
    private TestsServiceImpl testsServiceImpl;

    @Autowired
    private ReportDao reportDao;

    @Autowired
    private UsersService usersService;

    TestListingServiceImpl() {
        // The key is the report column name and he value is the query name.
        FILTER_MAP.put("testRequestDto.sampleCode", "tr.loadDetail.sampleCode");
        FILTER_MAP.put("testRequestDto.destination.name", "tr.loadDetail.waybill.destination.name");
        FILTER_MAP.put("testRequestDto.destination.documentType", "tr.loadDetail.waybill.destination.document.type");
        FILTER_MAP.put("testRequestDto.destination.documentNumber", "tr.loadDetail.waybill.destination.document.number");
        FILTER_MAP.put("testRequestDto.test.type", "tr.class");
        FILTER_MAP.put("dateCompleted", "tr.dateCompleted");
        FILTER_MAP.put("laboratoryCode", "tr.loadDetail.laboratory.code");

    }

    @Override
    @Transactional(readOnly = true)
    public ReportResponse createReportResponse(ReportRequest reportRequest, int maxResults) {
        List<String> laboratoryCodesForCurrentUser = usersService.listLaboratoryCodesForCurrentUser();
        List<WaybillStatusEnum> waybillStates = Lists.newArrayList(new WaybillStatusEnum[]{WaybillStatusEnum.COMPLETE_NEGATIVE,WaybillStatusEnum.COMPLETE_POSITIVE,WaybillStatusEnum.WAYBILL_TO_BE_INFORMED});
        if (!laboratoryCodesForCurrentUser.isEmpty()) {
          Map<String, Object> namedParameters = new HashMap<String, Object>();
        namedParameters.put("laboratoryCodes", laboratoryCodesForCurrentUser);
        namedParameters.put("status", waybillStates);
        return createReportResponse(reportRequest, maxResults, namedParameters);
        }

        return new ReportResponse();
    }


    private ReportResponse createReportResponse(ReportRequest reportRequest, int maxResults, Map<String, Object> namedParameters) {
        reportRequest.renameFields(FILTER_MAP);

        String baseQuery = this.createBaseQuery(reportRequest);

        //reportRequest.setFieldParser("tr.class", StringParserFactory.CLASS);

        Collection<TestRequest> testRequest = reportDao.getReportContent(
                baseQuery,
                reportRequest,
                namedParameters,
                TestRequest.class,
                maxResults
        );

        Collection<CompleteTestDto> reportContent = createReportContentFromQueryResult(testRequest);

        int totalPages = reportDao.getTotalPages(
                baseQuery,
                reportRequest,
                namedParameters,
                maxResults
        );

        return new ReportResponse(reportContent, totalPages);
    }

    private String createBaseQuery(ReportRequest reportRequest) {

        String query = BASE_QUERY;
        for (ReportFilter reportFilter : reportRequest.getFilter()) {
            String fieldName = reportFilter.getField();
            if (fieldName.equalsIgnoreCase("tr.class")){
                query = this.selectCorrectBaseQuery(reportFilter);
                reportRequest.getFilter().remove(reportFilter);
                break;
            }
        }
        return query;
    }

    private String selectCorrectBaseQuery(ReportFilter reportFilter) {
        if ( reportFilter.getValues().length == 1 && reportFilter.getValues()[0].toString().equalsIgnoreCase("cualitativo")){
            return QUALITATIVE_BASE_QUERY;
        }
        if (reportFilter.getValues().length == 1 && reportFilter.getValues()[0].toString().equalsIgnoreCase("cuantitativo")){
            return QUANTITATIVE_BASE_QUERY;
        }

        return BASE_QUERY;



    }


    private Collection<CompleteTestDto> createReportContentFromQueryResult(Collection<TestRequest> testRequests) {

        Collection<CompleteTestDto> reportContent = new ArrayList<CompleteTestDto>();
        for (TestRequest testRequest : testRequests) {
            reportContent.add(testsServiceImpl.createCompleteTestDto(testRequest));
        }
        return reportContent;
    }

}
