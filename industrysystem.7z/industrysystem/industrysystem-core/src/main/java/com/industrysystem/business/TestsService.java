package com.industrysystem.business;

import com.industrysystem.business.dtos.StakeholdersDto;
import com.industrysystem.business.dtos.QualitativeTestResultDto;
import com.industrysystem.business.dtos.QuantitativeTestResultDto;
import com.industrysystem.business.dtos.SampleDeterminationItem;
import com.industrysystem.entities.Document;
import com.industrysystem.entities.Sample;
import com.industrysystem.entities.TestRequest;
import com.industrysystem.exceptions.*;

import java.util.List;

/**
 * User: AVIER
 * Date: 9/24/13
 * Time: 4:58 PM
 */
public interface TestsService {

    /**
     * @param sample shows waybill information
     * @return SampleTestDetermination Determine whether the waybill requires sample or not
     */
    public List<SampleDeterminationItem> shouldWaybillTakeSample(Sample sample) throws SampleDeterminationException;

    public void storeSample(String sampleCode, String quantitativeLabCode, String qualitativeLabCode, Long waybillNumber, String identifier) throws StoreSampleException;

    public List<TestRequest> calculateRequiredTypeOfTests(Long waybillNumber) throws TypeOfTestException;

    public void storeTestResultsByDestination(Document destinationDocument, String sampleCode,
                                              List<QuantitativeTestResultDto> quantitativeTestResults,
                                              List<QualitativeTestResultDto> qualitativeTestResults,
                                              StakeholdersDto stakeholders) throws StoreTestResultException;

    public void storeWebTestResultsByDestination(Document destinationDocument, String sampleCode,
                                                List<QuantitativeTestResultDto> quantitativeTestResults,
                                                List<QualitativeTestResultDto> qualitativeTestResults,
                                                StakeholdersDto stakeholders) throws StoreTestResultException;

    public List<TestRequestDto> getPendingTestRequestDtoListForCurrentUser() throws TypeOfTestException;

    public List<TestRequestDto> getPendingTestRequestDtoList();

}