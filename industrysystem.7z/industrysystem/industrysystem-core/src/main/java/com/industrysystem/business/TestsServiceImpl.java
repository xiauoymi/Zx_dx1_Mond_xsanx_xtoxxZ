package com.industrysystem.business;

import com.google.common.base.Optional;
import com.industrysystem.business.dtos.*;
import com.industrysystem.business.users.UsersService;
import com.industrysystem.business.validators.StoreTestResultValidator;
import com.industrysystem.business.validators.Validator;
import com.industrysystem.entities.*;
import com.industrysystem.entities.utils.TestRequestsFactory;
import com.industrysystem.exceptions.*;
import com.industrysystem.guava.predicates.LoadDetailRequiresSamplePredicate;
import com.industrysystem.persistence.daos.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import static com.google.common.collect.FluentIterable.from;
import static com.google.common.collect.Iterables.getLast;
import static com.google.common.collect.Iterables.tryFind;
import static com.google.common.collect.Lists.newArrayList;
import static org.apache.commons.lang.StringUtils.isEmpty;
import static org.apache.commons.lang.StringUtils.isNotEmpty;
import static org.apache.commons.lang.StringUtils.upperCase;

/**
 * User: AVIER
 * Date: 9/24/13
 * Time: 4:59 PM
 */
@Service
public class TestsServiceImpl implements TestsService {

    private static final Logger log = LoggerFactory.getLogger(TestsServiceImpl.class);

    @Autowired
    private WaybillDao waybillDao;

    @Autowired
    private LoadDetailDao loadDetailDao;

    @Autowired
    private PodDao podDao;

    @Autowired
    private LaboratoryDao laboratoryDao;

    @Autowired
    private CropTechnologyForCampaignDao cropTechnologyForCampaignDao;

    @Autowired
    private TestRequestDao testRequestDao;

    @Autowired
    private CropTechnologyDao cropTechnologyDao;

    @Autowired
    private WaybillService waybillService;

    @Autowired
    private EventService eventService;

    @Autowired
    private Validator validator;

    @Autowired
    private StoreTestResultValidator storeTestResultValidator;

    @Autowired
    private DocumentTypeDao documentTypeDao;

    @Autowired
    private GrowerDao growerDao;

    @Autowired
    private TechnologyDao technologyDao;

    @Autowired
    private UsersService userService;

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    //TODO PREAUTHORIZE
    public List<SampleDeterminationItem> shouldWaybillTakeSample(Sample sample) throws SampleDeterminationException {
        List<SampleDeterminationItem> result = new ArrayList<SampleDeterminationItem>();

        try {
            Waybill waybill = waybillDao.findWaybillByWaybillNumber(sample.getWaybillNumber());
            validator.validateWaybillStatus(waybill);

            for (LoadDetail detail: waybill.getLoadDetails()) {
                boolean requiresSample = requiresSample(detail);
                detail.setSampleRequired(requiresSample);
                result.add(new SampleDeterminationItem(detail.getIdentifier(), requiresSample));

                eventService.saveSampleRequiredDeterminationEvent(detail);
            }

            //TODO check if it has no loaddeteails.
            waybill.changeState();
            waybillDao.save(waybill);
        } catch (BusinessException e) {
            throw new SampleDeterminationException(e);
        } catch (Exception e) {
            throw new SampleDeterminationException(e);
        }

        return result;
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    //TODO PREAUTHORIZE
//    @PreAuthorize("hasStrictRoleLABResultsLoader(#laboratoryCode)")
    public void storeSample(String sampleCode, String quantitativeLabCode, String qualitativeLabCode, Long waybillNumber,
            final String identifier) throws StoreSampleException {
        //Save the Sample
        //Step 1.  Get the Waybill that matches with the “service provided Waybill Number” parameter.
        try {
            Waybill waybill = waybillDao.findWaybillByWaybillNumber(waybillNumber);
            String laboratoryCode;
            List<TestRequest> testRequests = getOrCreateTestRequests(waybill, true);

            if (getLast(testRequests).getClass().isInstance(QualitativeTestRequest.class)) {
                laboratoryCode = qualitativeLabCode;
            } else {
                laboratoryCode = quantitativeLabCode;
            }

            Laboratory laboratory = laboratoryDao.findLaboratoryByLabCode(laboratoryCode);

            if (!islaboratoryCanMakeAnalysis(laboratory, testRequests)) {
                throw new StoreSampleException(new BusinessError(BusinessError.LABORATORY_CANNOT_PERFORM_TESTS,
                        "The Lab with code is " + laboratory.getCode() + " does not perform the type of test the waybill requires."));
            }

            if (isNotEmpty(identifier)) {
                Optional<LoadDetail> loadDetailOptional = tryFind(waybill.getLoadDetails(), new LoadDetailRequiresSamplePredicate(identifier));
                if (!loadDetailOptional.isPresent()) {
                    throw new LoadDetailNotFoundException(identifier);
                }
                updateLoadSample(sampleCode, waybillNumber, laboratory, loadDetailOptional.get(), waybill.getDestination().getDocument());
            } else {
                for (LoadDetail loadDetail: waybill.getLoadDetails()) {
                    updateLoadSample(sampleCode, waybillNumber, laboratory, loadDetail, waybill.getDestination().getDocument());
                }
            }

            waybill.changeState();
        } catch (BusinessException e) {
            throw new StoreSampleException(e);
        } catch (Exception e) {
            throw new StoreSampleException(e);
        }
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    //TODO PREAUTHORIZE
    public List<TestRequest> calculateRequiredTypeOfTests(Long waybillNumber) throws TypeOfTestException {
        try {
            Waybill waybill = waybillDao.findWaybillByWaybillNumber(waybillNumber);
            return getOrCreateTestRequests(waybill, false);
        } catch (BusinessException e) {
            throw new TypeOfTestException(e);
        } catch (Exception e) {
            throw new TypeOfTestException(e);
        }
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    //TODO PREAUTHORIZE
    public void storeWebTestResultsByDestination(Document destinationDocument, String sampleCode,
            List<QuantitativeTestResultDto> quantitativeTestResults, List<QualitativeTestResultDto> qualitativeTestResults,
            StakeholdersDto stakeholders) throws StoreTestResultException {
        try {
            LoadDetail loadDetail = findLoadDetailByDestinationDocument(destinationDocument, sampleCode);
            // TODO : Remove this after the web app get the technology from the test request.
            // For negative qualitative tests (with no technology) have to get the technology (cropCode, technologyCode and traitOwnerCode) from the testRequest.
            if (isQualitativeWithNoTechnology(qualitativeTestResults)) {
                QualitativeTestRequest testRequest = (QualitativeTestRequest) loadDetail.getTestRequests().iterator().next();
                CropTechnology cropTechnology = testRequest.getCropTechnologyForCampaign().getCropTechnology();
                Technology technology = cropTechnology.getTechnology();

                QualitativeTestResultDto testResult = qualitativeTestResults.get(0);
                testResult.setTechnologyCode(technology.getCode());
                testResult.setCropCode(cropTechnology.getCrop().getCode());
                testResult.setTraitOwnerCode(technology.getTraitOwner().getCode());
            }
            storeTestResults(loadDetail, quantitativeTestResults, qualitativeTestResults, stakeholders);
        } catch (LoadDetailNotFoundException e) {
            throw new StoreTestResultException(e);
        }
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    //TODO PREAUTHORIZE
    public void storeTestResultsByDestination(Document destinationDocument, String sampleCode,
            List<QuantitativeTestResultDto> quantitativeTestResults, List<QualitativeTestResultDto> qualitativeTestResults,
            StakeholdersDto stakeholders) throws StoreTestResultException {
        try {
            LoadDetail loadDetail = findLoadDetailByDestinationDocument(destinationDocument, sampleCode);
            storeTestResults(loadDetail, quantitativeTestResults, qualitativeTestResults, stakeholders);
        } catch (LoadDetailNotFoundException e) {
            throw new StoreTestResultException(e);
        }
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    public List<TestRequestDto> getPendingTestRequestDtoListForCurrentUser() throws TypeOfTestException {
        List<String> laboratoryCodes = userService.listLaboratoryCodesForCurrentUser();
        List<TestRequest> testRequests = testRequestDao.findPendingTestRequestsForLaboratories(laboratoryCodes);
        return createTestRequestDtoList(testRequests);
    }

    @Override
    @Transactional
    //TODO PREAUTHORIZE
    public List<TestRequestDto> getPendingTestRequestDtoList() {
        List<TestRequest> testRequests = testRequestDao.findPendingTestRequests();
        return createTestRequestDtoList(testRequests);
    }

    /**
     * If none of the lists have elements, that means that the test result is quantitative with no technology detected.
     * Otherwise, only one of the lists must have elements (size > 0).
     */
    private void storeTestResults(LoadDetail loadDetail, List<QuantitativeTestResultDto> quantitativeTestResults,
            List<QualitativeTestResultDto> qualitativeTestResults, StakeholdersDto stakeholders) throws StoreTestResultException {
        try {
            if (!qualitativeTestResults.isEmpty()) {
                obtainNonMandatorysFields(loadDetail, qualitativeTestResults);
                storeQualitativeTestResults(loadDetail, qualitativeTestResults, stakeholders);
            } else {
                obtainNonMandatorysFields(loadDetail, quantitativeTestResults);
                storeQuantitativeTestResults(loadDetail, quantitativeTestResults, stakeholders);
            }
            if (!quantitativeTestResults.isEmpty() || anyPositiveResult(qualitativeTestResults)) {
                saveStakeholders(loadDetail.getWaybill(), stakeholders);
            }
            waybillService.addWaybillToTraitOwnerMessages(loadDetail.getWaybill());
        } catch (BusinessException e) {
            throw new StoreTestResultException(e);
        } catch (RuntimeException e) {
            throw new StoreTestResultException(e);
        }
    }

    /*
     * This change allows storeTestResult WS set fields cropCode and traitOwnerCode as NO MANDATORY.
     * In these case values will be getting through Waybill (for Crop) and Technology (for TraitOwner)
     * This change was made by demand into several WS issues
     *
     */
    private <T extends TestResultDto> void obtainNonMandatorysFields(LoadDetail loadDetail, List<T> testResults)
            throws StoreTestResultException {
        String cropCode = loadDetail.getWaybill().getCrop().getCode();
        for (TestResultDto testResult: testResults) {
        	if (isEmpty(testResult.getCropCode())) {
        		testResult.setCropCode(cropCode);
        	}
        	if (isEmpty(testResult.getTraitOwnerCode())) {
        		try {
        			Technology technology = technologyDao.findByCode(upperCase(testResult.getTechnologyCode()));
					testResult.setTraitOwnerCode(technology.getTraitOwner().getCode());
				} catch (TechnologyNotFoundException e) {
					throw new StoreTestResultException(e);
				}
        	}
        }
    }

    private void storeQuantitativeTestResults(LoadDetail loadDetail, List<QuantitativeTestResultDto> quantitativeTestResults,
            StakeholdersDto stakeholders) throws StoreTestResultException, CropTechnologyNotFoundException {
        validator.validateTechnologyCodes(quantitativeTestResults);
        validator.validateCropCodes(quantitativeTestResults);
        validator.validateTraitOwnerCodes(quantitativeTestResults);
        List<TestRequest> cuantitativeTestRequests = findTestRequests(loadDetail);
        // Must be only 1 quantitative test request.
        validator.validateIfRequestsAlreadyHaveResponse(cuantitativeTestRequests);
        validator.validateThatQuantitativeResultIsExpected(cuantitativeTestRequests);
        validator.validateNoDuplicateResults(quantitativeTestResults);
        validator.validateResultsSum(quantitativeTestResults);
        if (quantitativeTestResults.isEmpty()) {
            storeTestResultValidator.validateStakeholdersForNegativeTestResult(stakeholders);
        } else {
            storeTestResultValidator.validateStakeholdersForPositiveTestResult(stakeholders);
        }
        TestRequest theTestRequest = cuantitativeTestRequests.get(0);
        generateQuantitativeResults(theTestRequest, quantitativeTestResults);
    }

    private void storeQualitativeTestResults(LoadDetail loadDetail, List<QualitativeTestResultDto> qualitativeTestResults,
            StakeholdersDto stakeholders) throws StoreTestResultException {
        validator.validateTechnologyCodes(qualitativeTestResults);
        validator.validateCropCodes(qualitativeTestResults);
        validator.validateTraitOwnerCodes(qualitativeTestResults);
        List<TestRequest> qualitativeTestRequests = findTestRequests(loadDetail);
        validator.validateIfRequestsAlreadyHaveResponse(qualitativeTestRequests);
        validator.validateThatAreAllQualitative(qualitativeTestRequests);
        validator.validateNumberOfTests(qualitativeTestResults, qualitativeTestRequests);
        validator.validateIfAllResultDataHaveRequest(qualitativeTestResults,
                from(qualitativeTestRequests).filter(QualitativeTestRequest.class).toImmutableList());
        if (anyPositiveResult(qualitativeTestResults)) {
            storeTestResultValidator.validateStakeholdersForPositiveTestResult(stakeholders);
        } else {
            storeTestResultValidator.validateStakeholdersForNegativeTestResult(stakeholders);
        }
        generateQualitativeResultsForRequests(qualitativeTestResults, qualitativeTestRequests);
    }

    private List<TestRequestDto> createTestRequestDtoList(List<TestRequest> testRequests) {
        List<TestRequestDto> testRequestDtoList = new ArrayList<TestRequestDto>();
        for (TestRequest testRequest : testRequests) {
            try {
                testRequestDtoList.add(createTestRequestDto(testRequest));
            } catch (Exception e) {
                log.error("There was an error when creating a TestRequestDto for the testRequest with id : " + testRequest.getId());
            }
        }
        return testRequestDtoList;
    }

    public TestRequestDto createTestRequestDto(TestRequest testRequest) {
        LoadDetail loadDetail = testRequest.getLoadDetail();
        Waybill waybill = loadDetail.getWaybill();
        PodBranch destination = waybill.getDestination();

        TestRequestDto testRequestDto = new TestRequestDto();
        testRequestDto.setSampleCode(loadDetail.getSampleCode());
        testRequestDto.setCreatingDate(waybill.getCreationDate());
        testRequestDto.getDestination().setName(destination.getPodHeadOffice().getName());
        testRequestDto.getDestination().setDocumentType(destination.getDocument().getTypeCode());
        testRequestDto.getDestination().setDocumentNumber(destination.getDocument().getNumber());
        testRequestDto.getTest().setType(testRequest instanceof QualitativeTestRequest? TestRequest.QUALITATIVE: TestRequest.QUANTITATIVE);
        return testRequestDto;
    }

    protected List<TestRequest> getOrCreateTestRequests(Waybill waybill, boolean persist) throws TypeOfTestException {
        try {
            validator.validateCancelledStatus(waybill);
            validator.validateIfHaveLoadDetail(waybill);
            validator.validateIfSampleRequired(waybill);

            boolean isPodParticipant = waybillService.isRegisteredPodWaybill(waybill);
            List<CropTechnologyForCampaign> cropTechnologyForCampaigns = cropTechnologyForCampaignDao.findByCampaignAndCrop(
                    waybill.getCrop(), waybill.getCampaign());
            TestRequestsFactory testRequestsFactory = new TestRequestsFactory(isPodParticipant, cropTechnologyForCampaigns);

            List<TestRequest> resultList = new ArrayList<TestRequest>();
            for (LoadDetail aLoadDetail: waybill.getLoadDetails()) {
                Set<TestRequest> testRequests = aLoadDetail.getTestRequests();
                if (testRequests.isEmpty() && aLoadDetail.getSampleRequired()) {
                    testRequests = testRequestsFactory.create(aLoadDetail);
                    if (persist) {
                        for (TestRequest testRequest: testRequests) {
                            testRequestDao.save(testRequest);
                            saveTestRequestCreatedEvent(testRequest);
                        }
                        aLoadDetail.setTestRequests(testRequests);
                    }
                }

                resultList.addAll(testRequests);
            }
            return resultList;
        } catch (BusinessException e) {
            throw new TypeOfTestException(e);
        } catch (Exception e) {
            throw new TypeOfTestException(e);
        }
    }

    protected boolean islaboratoryCanMakeAnalysis(Laboratory laboratory, List<TestRequest> testRequests) throws StoreSampleException {
        List<CuantitativeTestRequest> cuantitativeTestRequests = from(testRequests).filter(CuantitativeTestRequest.class).toImmutableList();
        List<QualitativeTestRequest> qualitativeTestRequests = from(testRequests).filter(QualitativeTestRequest.class).toImmutableList();
        return !qualitativeTestRequests.isEmpty() || (!cuantitativeTestRequests.isEmpty() && laboratory.getCanPerformCuantitativeTests());
    }

    /**
     * a. Get the sampling Category for the POD
     * b. Retrieve de probability Sampling CAtegory´s probability attribute value
     * c. Run a Random Probabilistic Boolean Function using as an argument the probability value obtained in the
     * previous step
     *
     * @param document
     * @return
     */
    protected boolean randomSampling(Document document) {
        double probability = 1.0;

        PodScoring scoring = podDao.findScoringByPod(document);
        if (scoring != null && scoring.getSamplingCategory() != null && scoring.getSamplingCategory().getProbability() != null) {
            probability = scoring.getSamplingCategory().getProbability().doubleValue();
        }

        return Math.random() <= probability;
    }

    private boolean requiresSample(LoadDetail detail) {
        if (detail.getSampleRequired() != null) {
            return detail.getSampleRequired();
        }

        Waybill waybill = detail.getWaybill();
        boolean isGrower = !waybill.getHolderDeclaredIsPod();
        boolean isPodParticipant = waybillService.isRegisteredPodWaybill(waybill);
        boolean isPodNotParticipant = !isGrower && !isPodParticipant;
        return (isGrower && detail.getDeclarations().isEmpty()) || isPodNotParticipant ||
                (isPodParticipant && randomSampling(waybill.getHolderDocument()));
    }

    private void updateLoadSample(String sampleCode, Long waybillNumber, Laboratory laboratory, LoadDetail loadDetail,
            Document destinationDocument) throws StoreSampleException, StoreTestResultException {
        if (!loadDetail.getSampleRequired()) {
            throw new StoreSampleException(new BusinessError(BusinessError.SAMPLE_NOT_REQUIRED, "The Waybill " +
                    waybillNumber + " does not require a sample code."));
        }

        if (isNotADiferentSampleForTheSameDestination(destinationDocument, sampleCode)) {
            throw new StoreSampleException(new BusinessError(BusinessError.INVALID_SAMPLE_CODE, "The Sample Code: '" +
                    sampleCode + "' already exists for the destination document number: " + destinationDocument.getNumber()));
        }

        loadDetail.setSampleCode(sampleCode);
        loadDetail.setLaboratory(laboratory);

        try {
            eventService.saveStoreSampleEvent(loadDetail);
        } catch (UserNotLoggedException e) {
            throw new StoreSampleException(e);
        }

    }

    private void saveTestRequestCreatedEvent(TestRequest testRequest) throws StoreTestResultException {
        try {
            LoadDetail loadDetail = testRequest.getLoadDetail();
            if (testRequest.isQuantitativeTestRequest()) {
                eventService.saveCuantitativeTestEvent(loadDetail);
            } else {
                eventService.saveCualitativeTestEvent(loadDetail);
            }

            Waybill waybill = loadDetail.getWaybill();
            waybill.changeState();
            waybillDao.save(waybill);
        } catch (UserNotLoggedException e) {
            throw new StoreTestResultException(e);
        }
    }

    private List<TestRequest> findTestRequests(LoadDetail loadDetail) throws StoreTestResultException {
        if (loadDetail.getTestRequests().isEmpty()) {
            throw new StoreTestResultException(new BusinessError(BusinessError.TEST_REQUESTS_NOT_FOUND,
                    "There were no matching test requests for this test results"));
        }
        return newArrayList(loadDetail.getTestRequests());
    }

    private LoadDetail findLoadDetailByDestinationDocument(Document destinationDocument, String sampleCode)
            throws LoadDetailNotFoundException, StoreTestResultException {
        try {
            return loadDetailDao.findLoadDetailsBySampleCodeAndWaybillDestinationDocument(sampleCode, destinationDocument);
        } catch (NoResultException ex) {
            throw new LoadDetailNotFoundException(destinationDocument.getNumber(), sampleCode);
        } catch (NonUniqueResultException ex) {
            // There is more than one Waybill’s Load Detail matching with the provided Destination document number and Sample code.
            throw new StoreTestResultException(new BusinessError(BusinessError.LOAD_DETAIL_NOT_UNIQUE, "Load detail identifier matched more than one load"));
        }
    }

    private void generateQualitativeResultsForRequests(List<QualitativeTestResultDto> testResults, List<? extends TestRequest> testRequests) {
        for (TestRequest testRequest: testRequests) {
            generateResultForRequest((QualitativeTestRequest) testRequest, testResults);
            testRequest.setDateCompleted(new Date());
        }
    }

    private void generateQuantitativeResults(TestRequest testRequest, List<QuantitativeTestResultDto> testResults)
            throws CropTechnologyNotFoundException {
        for (QuantitativeTestResultDto testResult: testResults) {
            CropTechnology cropTechnology = cropTechnologyDao.findByCropCodeAndTechnologyCodeAndTraitOwnerCode(
                    upperCase(testResult.getCropCode()), upperCase(testResult.getTechnologyCode()),
                    upperCase(testResult.getTraitOwnerCode()));

            CuantitativeTestRequest quantitativeTestRequest = (CuantitativeTestRequest)testRequest;
            CuantitativeTestResult quantitativeTestResult = new CuantitativeTestResult();
            quantitativeTestResult.setCuantitativeTestRequest(quantitativeTestRequest);
            quantitativeTestResult.setRatio(testResult.getPercentage());
            quantitativeTestResult.setCropTechnology(cropTechnology);
            quantitativeTestResult.setCuantitativeTestRequest(quantitativeTestRequest);
            quantitativeTestRequest.addQuantitativeTestResult(quantitativeTestResult);
        }

        testRequest.setDateCompleted(new Date());
    }

    private void generateResultForRequest(QualitativeTestRequest testRequest, List<QualitativeTestResultDto> testResultDataList) {
        for (QualitativeTestResultDto testResultData: testResultDataList) {
            if (testRequest.isResultDataForRequest(testResultData)) {
                QualitativeTestResult testResult = new QualitativeTestResult();
                testResult.setResult(Boolean.valueOf(testResultData.getIsPositive()));

                testRequest.setQualitativeTestResult(testResult);
            }
        }
    }

    private boolean anyPositiveResult(List<QualitativeTestResultDto> qualitativeTestResults) {
        for (QualitativeTestResultDto qualitativeTestResult: qualitativeTestResults) {
            if (Boolean.valueOf(qualitativeTestResult.getIsPositive())) {
                return true;
            }
        }
        return false;
    }

    /**
     * If already have stakeholders, they are overriden.
     */
    protected void saveStakeholders(Waybill waybill, StakeholdersDto stakeholders) {
        // Mandatory
        DocumentType holderDocumentType = documentTypeDao.findByCode(upperCase(stakeholders.getHolderDocumentType()));
        String holderDocumentNumber = String.valueOf(stakeholders.getHolderDocumentNumber());

        Document holderDocument = new Document(holderDocumentType, holderDocumentNumber);
        waybill.setHolderDocument(holderDocument);

        if (!waybillService.isRegisteredPodWaybill(waybill)) {
            growerDao.findOrCreateGrower(waybill.getHolderDocument(), upperCase(stakeholders.getHolderName()));
            waybill.setHolderIsRegisteredPod(false);
        } else {
            waybill.setHolderIsRegisteredPod(true);
        }

        // optional
        if (isNotEmpty(stakeholders.getCommercialSenderDocumentNumber())) {
            DocumentType documentType = documentTypeDao.findByCode(upperCase(stakeholders.getCommercialSenderDocumentType()));
            String documentNumber = String.valueOf(stakeholders.getCommercialSenderDocumentNumber());

            waybill.setCommercialSenderDocument(new Document(documentType, documentNumber));
            waybill.setCommercialSenderName(upperCase(stakeholders.getCommercialSenderName()));
        }
    }

    private boolean isQualitativeWithNoTechnology(List<QualitativeTestResultDto> qualitativeTestResults) {
        return !qualitativeTestResults.isEmpty() && isEmpty(qualitativeTestResults.get(0).getTechnologyCode());
    }

    private boolean isNotADiferentSampleForTheSameDestination(Document destinationDocument, String sampleCode)
            throws StoreTestResultException {
        try {
            findLoadDetailByDestinationDocument(destinationDocument, sampleCode);
            return true;
        } catch (LoadDetailNotFoundException ex) {
            return false;
        }
    }


    public CompleteTestDto createCompleteTestDto(TestRequest testRequest) {
        CompleteTestDto completeTestDto = new CompleteTestDto();

        completeTestDto.setTestRequestDto(this.createTestRequestDto(testRequest));

        if (!testRequest.isQuantitativeTestRequest()){
            QualitativeTestResultDto qualitativeTestResultDto = new QualitativeTestResultDto();
            qualitativeTestResultDto.setIsPositive(String.valueOf(testRequest.isPositiveResult()));

            CropTechnology cropTechnology = ((QualitativeTestRequest) testRequest).getCropTechnologyForCampaign().getCropTechnology();

            qualitativeTestResultDto.setCropCode(cropTechnology.getCrop().getCode());
            qualitativeTestResultDto.setTechnologyCode(cropTechnology.getTechnology().getCode());
            qualitativeTestResultDto.setTraitOwnerCode(cropTechnology.getTechnology().getTraitOwner().getCode());
            completeTestDto.getTestResultDto().add(qualitativeTestResultDto);
        }else{
            for (CuantitativeTestResult quantitativeTestResult : ((CuantitativeTestRequest) testRequest).getCuantitativeTestResults()){

                QuantitativeTestResultDto quantitativeTestResultDto = new QuantitativeTestResultDto();
                quantitativeTestResultDto.setPercentage(quantitativeTestResult.getRatio());

                CropTechnology cropTechnology = quantitativeTestResult.getCropTechnology();

                quantitativeTestResultDto.setCropCode(cropTechnology.getCrop().getCode());
                quantitativeTestResultDto.setTechnologyCode(cropTechnology.getTechnology().getCode());
                quantitativeTestResultDto.setTraitOwnerCode(cropTechnology.getTechnology().getTraitOwner().getCode());
                completeTestDto.getTestResultDto().add(quantitativeTestResultDto);
            }
        }
        completeTestDto.setLaboratoryCode(testRequest.getLoadDetail().getLaboratory().getCode());
        completeTestDto.setDateCompleted(testRequest.getDateCompleted());
        completeTestDto.setTimeElapsed(testRequest.getDateCompleted().getTime() - testRequest.getLoadDetail().getWaybill().getCreationDate().getTime());

        return completeTestDto;
    }
}