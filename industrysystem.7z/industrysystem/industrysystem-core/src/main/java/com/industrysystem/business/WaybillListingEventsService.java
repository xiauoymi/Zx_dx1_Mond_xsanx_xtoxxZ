package com.industrysystem.business;

import com.industrysystem.persistence.daos.report.ReportRequest;
import com.industrysystem.persistence.daos.report.ReportResponse;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 21/02/14
 * Time: 11:20
 */
public interface WaybillListingEventsService {

    ReportResponse createReportResponse(ReportRequest reportRequest, int maxResults);

}
