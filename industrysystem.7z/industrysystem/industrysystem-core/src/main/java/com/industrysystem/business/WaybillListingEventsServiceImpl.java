package com.industrysystem.business;

import com.industrysystem.business.dtos.waybilllisting.WaybillListingEvent;
import com.industrysystem.entities.Event;
import com.industrysystem.persistence.daos.report.ReportDao;
import com.industrysystem.persistence.daos.report.ReportRequest;
import com.industrysystem.persistence.daos.report.ReportResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

/**
 * User: CGLLLO
 * Date: 21/02/14
 */
@Component
public abstract class WaybillListingEventsServiceImpl implements WaybillListingEventsService {

    protected final Map<String, String> FILTER_MAP = new HashMap<String, String>();

    @Autowired
    private ReportDao reportDao;

    protected abstract String getBaseQuery();

    @Override
    @Transactional(readOnly = true)
    public ReportResponse createReportResponse(ReportRequest reportRequest, int maxResults) {
        reportRequest.renameFields(FILTER_MAP);

        Collection<Event> events = reportDao.getReportContent(
                getBaseQuery(),
                reportRequest,
                Event.class,
                maxResults
        );

        Collection<WaybillListingEvent> reportContent = new ArrayList<WaybillListingEvent>();
        for (Event event : events) {
            reportContent.add(new WaybillListingEvent(event));
        }

        int totalPages = reportDao.getTotalPages(
                getBaseQuery(),
                reportRequest,
                maxResults
        );

        return new ReportResponse(reportContent, totalPages);
    }
}
