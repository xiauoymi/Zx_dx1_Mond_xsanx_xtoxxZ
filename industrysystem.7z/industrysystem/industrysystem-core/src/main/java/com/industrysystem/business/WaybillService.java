package com.industrysystem.business;

import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.TraitOwnerMessagesContainerDTO;
import com.industrysystem.business.dtos.WaybillValorizationItemDto;
import com.industrysystem.entities.Document;
import com.industrysystem.entities.Waybill;
import com.industrysystem.exceptions.*;

import java.util.Date;
import java.util.List;

/**
 * User: PPERA
 * Date: 25/09/13
 * Time: 17:43
 */
public interface WaybillService {

    public void storeWeight(Long waybillNumber, Integer weight, String loadIdentifier, Date unloadTime) throws StoreWeightException;

    /**
     * Method that search the waybills where the POD match with the holderDocumentNumber
     * or waybills that received in their establishment and which appears as addressee.
     *
     * @param holderDocument
     * @return a Pod's waybills list
     */
    public List<Waybill> findListOfWaybillsByPod(Document holderDocument);

    /**
     * Method that search a unique waybill by the passed ID.
     *
     * @param waybillId
     * @return unique waybill
     */
    public Waybill findWaybillDetailByWaybillId(Long waybillId);

    /**
     * Method that search a unique waybill with eager fetch type by the passed ID.
     *
     * @param waybillId
     * @return unique waybill
     */
    public Waybill findEagerWaybillDetailByWaybillId(Long waybillId);

    /**
     * Method that returns true if it is a unique waybill, or if the waybill
     * exist but its status is not active. False in other cases.
     *
     * @param waybillNumber
     * @return boolean
     */
    public boolean isWaybillUnique(Long waybillNumber);

    public void addWaybillToTraitOwnerMessages(Waybill waybill) throws StoreWeightException;

    public boolean isRegisteredPodWaybill(Waybill waybill);

    public void valorizateWaybill(Long waybillNumber, String traitOwnerCode, List<WaybillValorizationItemDto> itemsDto)
            throws WaybillValorizationException, UserNotLoggedException;

    public TraitOwnerMessagesContainerDTO retrieveTraitOwnerMessages(long fromId) throws UserNotLoggedException;

    public void storeWeightAndSampleInfo(Long waybillNumber, String quantitativeLabCode,String qualitativeLabCode, List<LoadDetailDTO> loadDetailDTOs)
            throws StoreWeightException, StoreSampleException, SampleDeterminationException, WaybillNotFoundException;

    public String getHolderName(Waybill waybill);

}