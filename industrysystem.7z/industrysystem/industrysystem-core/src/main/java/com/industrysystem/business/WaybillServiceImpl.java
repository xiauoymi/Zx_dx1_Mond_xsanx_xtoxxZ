package com.industrysystem.business;

import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableList;
import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.TraitOwnerMessagesContainerDTO;
import com.industrysystem.business.dtos.WaybillValorizationItemDto;
import com.industrysystem.business.mappers.WaybillValorizationMapper;
import com.industrysystem.business.users.UsersService;
import com.industrysystem.business.validators.Validator;
import com.industrysystem.business.validators.WaybillValorizationValidator;
import com.industrysystem.entities.*;
import com.industrysystem.entities.utils.WaybillTechnologiesBuilder;
import com.industrysystem.exceptions.*;
import com.industrysystem.guava.functions.CuantitativeTestResultToTraitOwnerFunction;
import com.industrysystem.guava.functions.DeclarationToTraitOwnerFunction;
import com.industrysystem.guava.functions.QualitativeTestRequestToTraitOwnerFunction;
import com.industrysystem.guava.predicates.LoadDetailMatchesIdentifierPredicate;
import com.industrysystem.guava.predicates.QualitativeTestRequestHasPositiveResultPredicate;
import com.industrysystem.persistence.daos.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.text.MessageFormat;
import java.util.*;

import static com.google.common.collect.FluentIterable.from;
import static com.google.common.collect.Iterables.filter;
import static com.google.common.collect.Iterables.getOnlyElement;
import static com.google.common.collect.Iterables.tryFind;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Sets.newHashSet;
import static org.apache.commons.lang.StringUtils.isBlank;
import static org.apache.commons.lang.StringUtils.isEmpty;
import static org.apache.commons.lang.StringUtils.isNotEmpty;

/**
 * User: PPERA
 * Date: 25/09/13
 * Time: 17:44
 */
@Component
public class WaybillServiceImpl implements WaybillService {

    private static final int BATCH_SIZE = 10;

    @Autowired
    private WaybillDao waybillDao;

    @Autowired
    private TraitOwnerMessageDao traitOwnerMessageDao;

    @Autowired
    private PodDao podDao;

    @Autowired
    private WaybillValorizationValidator waybillValorizationValidator;

    @Autowired
    private WaybillValorizationMapper waybillValorizationMapper;

    @Autowired
    private WaybillValorizationDao waybillValorizationDao;

    @Autowired
    private UsersService usersService;

    @Autowired
    private GrowerDao growerDao;

    @Autowired
    private Validator validator;

    @Autowired
    private EventService eventService;

    @Autowired
    private TestsService testsService;

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    //TODO PREAUTHORIZE
    public void storeWeight(Long waybillNumber, Integer weight, final String loadIdentifier, Date unloadTime) throws StoreWeightException {
        validator.validateStoreWeight(waybillNumber, weight, unloadTime);

        Waybill waybill = findWaybill(waybillNumber);

        if (isEmpty(loadIdentifier) && TransportType.TRANSPORTE_AUTOMOTOR != waybill.getTransportType()) {
            throw new StoreWeightException(new BusinessError(BusinessError.LOAD_DETAIL_NOT_FOUND, "Load identifier cannot be null for a Train waybill"));
        }

        LoadDetail loadDetail = findLoadDetailByIdentifier(loadIdentifier, waybill);

        if (loadDetail.getWeight() != null) {
            throw new StoreWeightException(new BusinessError(BusinessError.ILLEGAL_STATE_OF_WAYBILL, "Weight already informed"));
        }

        waybill.setUnloadingTime(unloadTime);
        loadDetail.setWeight(weight);

        try {
            eventService.saveStoreWeightEvent(loadDetail);
        } catch (UserNotLoggedException e) {
            throw new StoreWeightException(e);
        }

        addWaybillToTraitOwnerMessages(waybill);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    //TODO PREAUTHORIZE
    public void addWaybillToTraitOwnerMessages(Waybill waybill) throws StoreWeightException {
        waybill.changeState();

        try {
            if (WaybillStatusEnum.COMPLETE_NEGATIVE.equals(waybill.getStatus())) {
                // No trait owner means no technology was found
                eventService.saveNegativeTestResultEvent(waybill);
                return;
            }

            if (WaybillStatusEnum.COMPLETE_POSITIVE.equals(waybill.getStatus())) {
                // In this case, the waybill is not informed because the technology has already been charged
                // some other time when it came into the system through the previous POD
                eventService.savePositiveTestResultEvent(waybill);
                return;
            }

            if (WaybillStatusEnum.WAYBILL_TO_BE_INFORMED.equals(waybill.getStatus())) {
                Set<TraitOwner> associatedTraitOwners = this.determinateAssociatedTraitOwners(waybill);
                addWaybillToTraitOwnersMessages(waybill, associatedTraitOwners);
                eventService.saveReadyToBeInformedEvent(waybill);
                return;
            }
        } catch (UserNotLoggedException e) {
           throw new StoreWeightException(e);
        }
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    @PreAuthorize("isAuthenticated()")
    public List<Waybill> findListOfWaybillsByPod(Document holderDocument) {
        return waybillDao.findListOfWaybillsByPod(holderDocument);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    @PreAuthorize("isAuthenticated()")
    public Waybill findWaybillDetailByWaybillId(Long waybillId) {
        return waybillDao.findWaybillByID(waybillId);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    @PreAuthorize("isAuthenticated()")
    public boolean isWaybillUnique(Long waybillNumber){
        try{
            waybillDao.findWaybillByWaybillNumber(waybillNumber);
            return false;
        }catch(WaybillNotFoundException ex){
            return true;
        }
    }

    @Override
    @Transactional
    @PreAuthorize("isAuthenticated()")
    public Waybill findEagerWaybillDetailByWaybillId(Long waybillId) {
        return waybillDao.findEagerWaybillByID(waybillId);
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public boolean isRegisteredPodWaybill(Waybill waybill) {
        Document holderDocument = waybill.getHolderDocument();
        return waybill.getHolderDeclaredIsPod() && holderDocument != null && podDao.isPODDocumentDeclared(holderDocument);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    @PreAuthorize("hasStrictRoleTOCommercial(#traitOwnerCode)")
    public void valorizateWaybill(Long waybillNumber, String traitOwnerCode, List<WaybillValorizationItemDto> itemsDto)
            throws WaybillValorizationException, UserNotLoggedException {
        waybillValorizationValidator.validateWaybillNumber(waybillNumber);

        Waybill waybill = waybillValorizationMapper.mapWaybill(waybillNumber);

        for (WaybillValorizationItemDto item : itemsDto) {
            waybillValorizationValidator.validate(item);

            WaybillValorization valorization = waybillValorizationMapper.map(traitOwnerCode, waybill, item);

            waybillValorizationDao.save(valorization);
        }

        eventService.saveValorizateWaybillEvent(waybill);
        waybill.setInitialState(WaybillStatusEnum.WAYBILL_VALORIZED);
        waybillDao.save(waybill);
    }

    @Override
    //TODO PREAUTHORIZE
    @Transactional(rollbackFor = BusinessException.class)
    public TraitOwnerMessagesContainerDTO retrieveTraitOwnerMessages(long fromId) throws UserNotLoggedException {
        if (fromId < 0) {
            fromId = 0L;
        }

        List<String> traitOwners = usersService.listTraitOwnersForCurrentUser();
        String traitOwnerCode = traitOwners.get(0);

        TraitOwnerMessagesContainerDTO dto = new TraitOwnerMessagesContainerDTO();
        fillTraitOwnerMessages(dto, traitOwnerCode, fromId);
        fillNames(dto);
        fillWaybillTechnologies(dto, traitOwnerCode);

        return dto;
    }

    @Override
    @Transactional(rollbackFor = BusinessException.class)
    //TODO PREAUTHORIZE
    public void storeWeightAndSampleInfo(final Long waybillNumber, final String quantitativeLabCode,
            final String qualitativeLabCode, List<LoadDetailDTO> loadDetailDTOs) throws StoreWeightException,
            StoreSampleException, SampleDeterminationException, WaybillNotFoundException {
        Predicate<LoadDetailDTO> withWeight = new Predicate<LoadDetailDTO>() {
            @Override
            public boolean apply(LoadDetailDTO loadDetailDTO) {
                return loadDetailDTO.getWeight() != null;
            }
        };

        Predicate<LoadDetailDTO> withSample = new Predicate<LoadDetailDTO>() {
            @Override
            public boolean apply(LoadDetailDTO loadDetailDTO) {
                return loadDetailDTO.getLoadIdentifier() != null && isNotEmpty(loadDetailDTO.getSampleCode()) &&
                        quantitativeLabCode != null && qualitativeLabCode != null;
            }
        };

        List<LoadDetailDTO> loadDetailsWithWeight= newArrayList(filter(loadDetailDTOs, withWeight));

        testsService.shouldWaybillTakeSample(new Sample(waybillNumber));

        if (!loadDetailsWithWeight.isEmpty()){
            storeWeight(waybillNumber, loadDetailsWithWeight);
        }

        List<LoadDetailDTO> loadDetailsWithSample= newArrayList(filter(loadDetailDTOs, withSample));

        if (!loadDetailsWithSample.isEmpty()){
            storeSample(waybillNumber, quantitativeLabCode, qualitativeLabCode, loadDetailsWithSample);
        }
    }

    private void storeSample(Long waybillNumber, String quantitativeLabCode, String qualitativeLabCode,
            List<LoadDetailDTO> loadDetailsWithSample) throws StoreSampleException, StoreWeightException {
        Waybill waybill = findWaybill(waybillNumber);

        for (LoadDetailDTO loadDetailDTO : loadDetailsWithSample) {
            if (!alreadyHasSample(waybill, loadDetailDTO.getLoadIdentifier())){
                testsService.storeSample(loadDetailDTO.getSampleCode(), quantitativeLabCode, qualitativeLabCode,
                        waybillNumber, loadDetailDTO.getLoadIdentifier());
            }
        }
    }

    private boolean alreadyHasSample(Waybill waybill, String loadIdentifier) throws StoreWeightException {
        LoadDetail loadDetail = findLoadDetailByIdentifier(loadIdentifier, waybill);
        return loadDetail.getSampleCode() != null && loadDetail.getLaboratory()!=null;
    }

    private void storeWeight(Long waybillNumber, List<LoadDetailDTO> loadDetailsWithWeight)
            throws StoreWeightException, SampleDeterminationException {
        Waybill waybill = findWaybill(waybillNumber);

        for (LoadDetailDTO loadDetailDTO : loadDetailsWithWeight) {
            if (!alreadyHasWeight(waybill,loadDetailDTO.getLoadIdentifier())){
                storeWeight(waybillNumber, loadDetailDTO.getWeight(), loadDetailDTO.getLoadIdentifier(), new Date());
            }
        }
    }

    private Waybill findWaybill(Long waybillNumber) throws StoreWeightException {
        try {
            return waybillDao.findWaybillByWaybillNumber(waybillNumber);
        } catch (WaybillNotFoundException e) {
            throw new StoreWeightException(new BusinessError(BusinessError.WAYBILL_NOT_FOUND, "Waybill not found"));
        }
    }

    private boolean alreadyHasWeight(Waybill waybill, String loadIdentifier) throws StoreWeightException {
        LoadDetail loadDetail = findLoadDetailByIdentifier(loadIdentifier, waybill);
        return loadDetail.getWeight() != null;
    }

    @Override
    @PreAuthorize("isAuthenticated()")
    public String getHolderName(Waybill waybill){
        if (waybill.getHolderDocument() == null) {
            return null;
        }

        String name = null;
        if (waybill.getHolderDeclaredIsPod()) {
            name = getPodName(waybill.getHolderDocument());
        }
        if (isBlank(name)) {
            return getGrowerName(waybill.getHolderDocument());
        }
        return name;
    }

    void fillTraitOwnerMessages(TraitOwnerMessagesContainerDTO messagesContainer, String traitOwnerCode, long fromId) {
        traitOwnerMessageDao.updateSentTime(traitOwnerCode, fromId, BATCH_SIZE);

        List<TraitOwnerMessage> traitOwnerMessages = traitOwnerMessageDao
                .findTraitOwnerMessagesByTraitOwnerAndMessageSequence(traitOwnerCode, fromId, BATCH_SIZE + 1);
        if (traitOwnerMessages.size() > BATCH_SIZE) {
            messagesContainer.setHasMore(true);
            traitOwnerMessages = new ArrayList<TraitOwnerMessage>(traitOwnerMessages);
            traitOwnerMessages.remove(BATCH_SIZE);
        }
        messagesContainer.setTraitOwnerMessages(traitOwnerMessages);
    }

    void fillNames(TraitOwnerMessagesContainerDTO messagesContainer) throws UserNotLoggedException {
        for (TraitOwnerMessage traitOwnerMessage: messagesContainer.getTraitOwnerMessages()) {
            for (WaybillMessage waybillMessage: traitOwnerMessage.getWaybillMessages()) {
                Waybill waybill = waybillMessage.getWaybill();

                fillHolderName(messagesContainer,waybill);

                eventService.saveWaybillExportingEvent(waybill, waybillMessage);
                waybill.setInitialState(WaybillStatusEnum.WAYBILL_TO_BE_VALORIZED);
                waybillDao.save(waybill);

                fillPodName(messagesContainer, waybill.getAddressee());
                fillPodName(messagesContainer, waybill.getDestination());
            }
        }
    }

    boolean fillPodName(TraitOwnerMessagesContainerDTO messagesContainer, PodBranch pod) {
          if (pod == null) return false;

          if (messagesContainer.getName(pod.getDocument()) == null) {
              messagesContainer.setName(pod.getDocument(), pod.getName());
          }
          return true;
    }

    void fillHolderName(TraitOwnerMessagesContainerDTO messagesContainer, Waybill waybill) {
        if (messagesContainer.getName(waybill.getHolderDocument()) == null) {
            String holderName = getHolderName(waybill);
            if (holderName != null) {
                messagesContainer.setName(waybill.getHolderDocument(), holderName);
            }
        }
    }

    void fillWaybillTechnologies(TraitOwnerMessagesContainerDTO messagesContainer, String traitOwnerCode) {
        WaybillTechnologiesBuilder builder = new WaybillTechnologiesBuilder().setTraitOwnerCode(traitOwnerCode);

        for (TraitOwnerMessage traitOwnerMessage : messagesContainer.getTraitOwnerMessages()) {
            for (WaybillMessage waybillMessage : traitOwnerMessage.getWaybillMessages()) {
                Waybill waybill = waybillMessage.getWaybill();
                messagesContainer.setWaybillTechnologies(waybill.getId(), builder.setWaybill(waybill).build());
            }
        }
    }

    private String getPodName(Document document) {
        try {
            PodHeadOffice pod = podDao.findByDocument(document);
            return pod.getName();
        } catch (PodNotFoundException ex) {
            return null;
        }
    }

    private String getGrowerName(Document document) {
       try {
           Grower grower = growerDao.findGrowerByDocument(document);
           return grower.getName();
       } catch (GrowerNotFoundException ex) {
           return null;
       }
    }

    private LoadDetail findLoadDetailByIdentifier(final String loadIdentifier, Waybill waybill) throws StoreWeightException {
        try {
            if (isEmpty(loadIdentifier) && TransportType.TRANSPORTE_AUTOMOTOR == waybill.getTransportType()) {
                return getOnlyElement(waybill.getLoadDetails());
            }

            return tryFind(waybill.getLoadDetails(), new LoadDetailMatchesIdentifierPredicate(loadIdentifier)).get();
        } catch (NoSuchElementException e) {
            throw new StoreWeightException(new BusinessError(BusinessError.WAYBILL_WITHOUT_LOAD_DETAIL, "The waybill has no registered loads"));
        } catch (IllegalStateException e) {
            throw new StoreWeightException(new BusinessError(BusinessError.LOAD_DETAIL_NOT_FOUND,
                    MessageFormat.format("The Load {0} doesn't match any waybill associated valid code", loadIdentifier)));
        }
    }

    private List<TraitOwner> determinateAssociatedTraitOwners(LoadDetail loadDetail) {
        return extractTraitOwnersFromQualitativeResultsOrDeclarations(loadDetail);
    }

    private List<TraitOwner> extractTraitOwnersFromQualitativeResultsOrDeclarations(LoadDetail loadDetail) {
        Set<TraitOwner> traitOwners = newHashSet();
        List<TraitOwner> cuantitatives = extractTraitOwnersFromCuantitativeResults(loadDetail);
        traitOwners.addAll(cuantitatives);
        ImmutableList<TraitOwner> cualitatives = extractTraitOwnersFromQualitativeTestResults(loadDetail);
        traitOwners.addAll(cualitatives);
        traitOwners.addAll(extractTraitOwnersFromDeclaration(loadDetail));
        return new ArrayList<TraitOwner>(traitOwners);
    }

    private List<TraitOwner> extractTraitOwnersFromDeclaration(LoadDetail loadDetail) {
        if (loadDetail.getTestRequests().isEmpty() && !loadDetail.getDeclarations().isEmpty()) {
            return from(loadDetail.getDeclarations()).transform(new DeclarationToTraitOwnerFunction()).toImmutableList();
        }

        return newArrayList();
    }

    private ImmutableList<TraitOwner> extractTraitOwnersFromQualitativeTestResults(LoadDetail loadDetail) {
        return from(loadDetail.getQualitativeTestRequests()).filter(new QualitativeTestRequestHasPositiveResultPredicate())
                .transform(new QualitativeTestRequestToTraitOwnerFunction()).toImmutableList();
    }

    private List<TraitOwner> extractTraitOwnersFromCuantitativeResults(LoadDetail loadDetail) {
        List<TraitOwner> traitOwners = newArrayList();

        for (CuantitativeTestRequest cuantitativeTestRequest : loadDetail.getCuantitativeTestRequests()) {
            // If it is a POD it should only have quantitative requests and Cuantitative Analysys will always load test
            // result if test request is positive
            if (cuantitativeTestRequest.getCuantitativeTestResults() != null) {
                List<TraitOwner> cuantitativeResultsTraitOwners = from(cuantitativeTestRequest.getCuantitativeTestResults())
                        .transform(new CuantitativeTestResultToTraitOwnerFunction()).toImmutableList();
                traitOwners.addAll(cuantitativeResultsTraitOwners);
            }
        }

        return traitOwners;
    }

    private void addWaybillToTraitOwnersMessages(Waybill waybill, Set<TraitOwner> associatedTraitOwners) {
        for (TraitOwner traitOwner : associatedTraitOwners) {
            traitOwnerMessageDao.addWaybillToOpenTraitOwnerMessage(waybill, traitOwner);
        }
    }

    private Set<TraitOwner> determinateAssociatedTraitOwners(Waybill waybill) {
        Set<TraitOwner> traitOwners = newHashSet();
        for (LoadDetail waybillLoadDetail : waybill.getLoadDetails()) {
            List<TraitOwner> waybillLoadDetailTraitOwnerList = this.determinateAssociatedTraitOwners(waybillLoadDetail);
            traitOwners.addAll(waybillLoadDetailTraitOwnerList);
        }
        return traitOwners;
    }

}