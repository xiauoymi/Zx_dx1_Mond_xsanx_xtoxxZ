package com.industrysystem.business.dtos;

/**
 * User: ASEQU
 * Date: 1/6/14
 * Time: 9:14 AM
 */
public class CampaignDTO {
    private String code;
    private String description;
    private DateDTO date;
    private String availableTransferDescription = "12/10/2013";

    public CampaignDTO(String code, String description, DateDTO date) {
        this.code = code;
        this.description = description;
        this.date = date;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public DateDTO getDate() {
        return date;
    }

    public String getAvailableTransferDescription() {
        return availableTransferDescription;
    }
}
