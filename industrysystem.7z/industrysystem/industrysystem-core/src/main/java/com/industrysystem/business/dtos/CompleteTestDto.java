package com.industrysystem.business.dtos;

import com.industrysystem.business.TestRequestDto;
import com.industrysystem.entities.Laboratory;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 06/03/14
 * Time: 15:07
 * To change this template use File | Settings | File Templates.
 */
public class CompleteTestDto {

    private TestRequestDto testRequestDto;
    private List<TestResultDto> testResultDto = new ArrayList<TestResultDto>();
    private String laboratoryCode;
    private Date dateCompleted;
    private Long timeElapsed;


    public Date getDateCompleted() {
        return dateCompleted;
    }

    public void setDateCompleted(Date dateCompleted) {
        this.dateCompleted = dateCompleted;
    }

    public Long getTimeElapsed() {
        return timeElapsed;
    }

    public void setTimeElapsed(Long timeElapsed) {
        this.timeElapsed = timeElapsed;
    }

    public String getLaboratoryCode() {
        return laboratoryCode;
    }

    public void setLaboratoryCode(String laboratoryCode) {
        this.laboratoryCode = laboratoryCode;
    }

    public List<TestResultDto> getTestResultDto() {
        return testResultDto;
    }

    public void setTestResultDto(List<TestResultDto> testResultDto) {
        this.testResultDto = testResultDto;
    }

    public TestRequestDto getTestRequestDto() {
        return testRequestDto;
    }

    public void setTestRequestDto(TestRequestDto testRequestDto) {
        this.testRequestDto = testRequestDto;
    }


}
