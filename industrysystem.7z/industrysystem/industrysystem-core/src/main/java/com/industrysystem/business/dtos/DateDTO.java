package com.industrysystem.business.dtos;

/**
 * User: ASEQU
 * Date: 1/3/14
 * Time: 3:02 PM
 */
public class DateDTO {
    private String from;
    private String to;

    public DateDTO(){
        super();
    }

    public DateDTO(String from, String to){
        this.from = from;
        this.to = to;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }
}
