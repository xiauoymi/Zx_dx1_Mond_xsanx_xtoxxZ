package com.industrysystem.business.dtos;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * User: ASEQU
 * Date: 11/21/13
 * Time: 4:24 PM
 */
public class GrowerBalanceDTO {
    private BigDecimal available;
    private BigDecimal availableTransfer;
    private BigDecimal used;
    private CampaignDTO campaign;
    private List<UsedDetailDTO> usedDetail;

    public GrowerBalanceDTO(CampaignDTO campaign, BigDecimal used, BigDecimal available, List<UsedDetailDTO> usedDetail, BigDecimal availableTransfer) {
        this.campaign = campaign;
        this.used = used;
        this.available = available;
        this.usedDetail = usedDetail;
        this.availableTransfer = availableTransfer;
    }

    public BigDecimal getAvailable() {
        return this.available;
    }

    public BigDecimal getUsed() {
        return used;
    }

    public CampaignDTO getCampaign() {
        return campaign;
    }

    public List<UsedDetailDTO> getUsedDetail() {
        return usedDetail;
    }

    public BigDecimal getAvailableTransfer() {
        return availableTransfer;
    }
}
