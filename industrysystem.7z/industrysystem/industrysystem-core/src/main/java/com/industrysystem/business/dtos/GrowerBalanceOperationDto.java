package com.industrysystem.business.dtos;

import com.industrysystem.entities.GrowerBalanceType;

import javax.xml.bind.annotation.XmlType;
import java.math.BigDecimal;

/**
 * User: LSCHW1
 */
@XmlType(name = "growerBalanceOperation" ,propOrder = {"accountNumber","campaignCode","balanceType","value"})
public class GrowerBalanceOperationDto {

    private String accountNumber;
    private String campaignCode;
    private GrowerBalanceType balanceType;
    private BigDecimal value;


    public GrowerBalanceType getBalanceType() {
        return balanceType;
    }

    public void setBalanceType(GrowerBalanceType balanceType) {
        this.balanceType = balanceType;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCampaignCode() {
        return campaignCode;
    }

    public void setCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
    }
}
