package com.industrysystem.business.dtos;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@JsonTypeInfo(
        // We use the name defined in @JsonSubTypes.Type to map a type to its implementation.
        use = JsonTypeInfo.Id.NAME,
        // The information that stores the mapping information is a property.
        include = JsonTypeInfo.As.PROPERTY,
        // The property is called "loadType".
        property = "loadType"
)
@JsonSubTypes({
        @JsonSubTypes.Type(value = TruckDetailDTO.class, name = "truck"),
        @JsonSubTypes.Type(value = WagonDetailDTO.class, name = "train")
})
public abstract class LoadDetailDTO {
    private String loadIdentifier;
    private String sampleCode;
    private String declaredTechnology;
    private Integer weight;
    private Boolean sampleRequired;

    public String getLoadIdentifier() {
        return loadIdentifier;
    }

    public void setLoadIdentifier(String loadIdentifier) {
        this.loadIdentifier = loadIdentifier;
    }

    public String getSampleCode() {
        return sampleCode;
    }

    public void setSampleCode(String sampleCode) {
        this.sampleCode = sampleCode;
    }

    public String getDeclaredTechnology() {
        return declaredTechnology;
    }

    public void setDeclaredTechnology(String declaredTechnology) {
        this.declaredTechnology = declaredTechnology;
    }

    public Integer getWeight() {
        return weight;
    }

    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    public Boolean getSampleRequired() {
        return sampleRequired;
    }

    public void setSampleRequired(Boolean sampleRequired) {
        this.sampleRequired = sampleRequired;
    }
}
