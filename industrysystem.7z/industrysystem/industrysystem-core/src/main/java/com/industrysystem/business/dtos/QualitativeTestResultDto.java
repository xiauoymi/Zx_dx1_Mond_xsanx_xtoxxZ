package com.industrysystem.business.dtos;

import com.industrysystem.entities.TestResult;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

/**
 * User: PMIRIB
 * Date: 10/10/13
 */
@XmlRootElement
public class QualitativeTestResultDto extends TestResultDto implements Serializable {

    private String isPositive;

    public String getIsPositive() {
        return isPositive;
    }

    public void setIsPositive(String isPositive) {
        this.isPositive = isPositive;
    }
}
