package com.industrysystem.business.dtos;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 * User: PMIRIB
 * Date: 10/10/13
 * Time: 18:21
 */
@XmlRootElement
public class QuantitativeTestResultDto extends TestResultDto implements Serializable {

    private BigDecimal percentage;

    public BigDecimal getPercentage() {
        return percentage;
    }

    public void setPercentage(BigDecimal percentage) {
        this.percentage = percentage;
    }

}
