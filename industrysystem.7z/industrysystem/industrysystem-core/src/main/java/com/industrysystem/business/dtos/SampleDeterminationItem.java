package com.industrysystem.business.dtos;

/**
 * User: AVIER
 * Date: 9/25/13
 * Time: 4:53 PM
 */
public class SampleDeterminationItem {

    private String loadIdentifier;
    private Boolean sampleRequired;

    public SampleDeterminationItem(String loadIdentifier, Boolean sampleRequired) {
        this.loadIdentifier = loadIdentifier;
        this.sampleRequired = sampleRequired;
    }

    public String getLoadIdentifier() {
        return loadIdentifier;
    }

    public void setLoadIdentifier(String loadIdentifier) {
        this.loadIdentifier = loadIdentifier;
    }

    public Boolean getSampleRequired() {
        return sampleRequired;
    }

    public void setSampleRequired(Boolean sampleRequired) {
        this.sampleRequired = sampleRequired;
    }

}