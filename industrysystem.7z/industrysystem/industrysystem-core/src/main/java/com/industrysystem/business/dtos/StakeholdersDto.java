package com.industrysystem.business.dtos;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

import static org.apache.commons.lang.StringUtils.isNotEmpty;

/**
 * User: PMIRIB
 * Date: 26/11/13
 */
@XmlRootElement
public class StakeholdersDto implements Serializable {

    private String commercialSenderName;
    private String commercialSenderDocumentType;
    private String commercialSenderDocumentNumber;

    private String holderName;
    private String holderDocumentType;
    private String holderDocumentNumber;

    public String getCommercialSenderName() {
        return commercialSenderName;
    }

    public void setCommercialSenderName(String commercialSenderName) {
        this.commercialSenderName = commercialSenderName;
    }

    public String getCommercialSenderDocumentNumber() {
        return commercialSenderDocumentNumber;
    }

    public void setCommercialSenderDocumentNumber(String commercialSenderDocumentNumber) {
        this.commercialSenderDocumentNumber = commercialSenderDocumentNumber;
    }

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public String getHolderDocumentNumber() {
        return holderDocumentNumber;
    }

    public void setHolderDocumentNumber(String holderDocumentNumber) {
        this.holderDocumentNumber = holderDocumentNumber;
    }

    public String getCommercialSenderDocumentType() {
        return commercialSenderDocumentType;
    }

    public void setCommercialSenderDocumentType(String commercialSenderDocumentType) {
        this.commercialSenderDocumentType = commercialSenderDocumentType;
    }

    public String getHolderDocumentType() {
        return holderDocumentType;
    }

    public void setHolderDocumentType(String holderDocumentType) {
        this.holderDocumentType = holderDocumentType;
    }

    public boolean hasCommercialSender() {
        return hasCommercialSenderDocument() || hasCommercialSenderName();
    }

    public boolean isCommercialSenderComplete() {
        return hasCommercialSenderDocument() && hasCommercialSenderName();
    }

    public boolean isHolderComplete() {
        return hasHolderDocument() && hasHolderName();
    }

    public boolean hasCommercialSenderDocument() {
        return isNotEmpty(commercialSenderDocumentType) || isNotEmpty(commercialSenderDocumentNumber);
    }

    public boolean hasCommercialSenderName() {
        return isNotEmpty(commercialSenderName);
    }

    public boolean hasHolder() {
        return hasHolderDocument() || hasHolderName();
    }

    public boolean hasHolderDocument() {
        return isNotEmpty(holderDocumentType) || isNotEmpty(holderDocumentNumber);
    }

    public boolean hasHolderName() {
        return isNotEmpty(holderName);
    }

}