package com.industrysystem.business.dtos;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 28/11/13
 */
public class TechnologyDTO {
    private String technologyCode;
    private String technologyPercent;
    private String testDate;

    public TechnologyDTO(){}

    public TechnologyDTO(String technologyCode, String technologyPercent, String testDate){
        this.technologyCode = technologyCode;
        this.technologyPercent = technologyPercent;
        this.testDate = testDate;
    }

    public String getTechnologyCode() {
        return technologyCode;
    }

    public void setTechnologyCode(String technologyCode) {
        this.technologyCode = technologyCode;
    }

    public String getTechnologyPercent() {
        return technologyPercent;
    }

    public void setTechnologyPercent(String technologyPercent) {
        this.technologyPercent = technologyPercent;
    }

    public String getTestDate() {
        return testDate;
    }

    public void setTestDate(String testDate) {
        this.testDate = testDate;
    }
}
