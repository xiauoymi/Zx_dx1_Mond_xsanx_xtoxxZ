package com.industrysystem.business.dtos;

import com.industrysystem.entities.TestResult;

/**
 * User: PMIRIB
 * Date: 11/10/13
 */
public abstract class TestResultDto {

    private String cropCode;
    private String technologyCode;
    private String traitOwnerCode;

    public String getCropCode() {
        return cropCode;
    }

    public void setCropCode(String cropCode) {
        this.cropCode = cropCode;
    }

    public String getTechnologyCode() {
        return technologyCode;
    }

    public void setTechnologyCode(String technologyCode) {
        this.technologyCode = technologyCode;
    }

    public String getTraitOwnerCode() {
        return traitOwnerCode;
    }

    public void setTraitOwnerCode(String traitOwnerCode) {
        this.traitOwnerCode = traitOwnerCode;
    }

}