package com.industrysystem.business.dtos;

import com.industrysystem.entities.Document;
import com.industrysystem.entities.WaybillTechnology;
import com.industrysystem.entities.TraitOwnerMessage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TraitOwnerMessagesContainerDTO {

    private List<TraitOwnerMessage> traitOwnerMessages = new ArrayList<TraitOwnerMessage>();
    private Map<Document, String> docToNameMap = new HashMap<Document, String>();
    private Map<Long, List<WaybillTechnology>> waybillIdToWaybillTechnologyListMap = new HashMap<Long, List<WaybillTechnology>>();
    private boolean hasMore;

    public List<TraitOwnerMessage> getTraitOwnerMessages() {
        return traitOwnerMessages;
    }

    public void setTraitOwnerMessages(List<TraitOwnerMessage> traitOwnerMessages) {
        this.traitOwnerMessages = traitOwnerMessages;
    }

    public String getName(Document document) {
        return docToNameMap.get(document);
    }

    public void setName(Document document, String name) {
        docToNameMap.put(document, name);
    }

    public List<WaybillTechnology> getWaybillTechnologies(Long waybillId) {
        return waybillIdToWaybillTechnologyListMap.get(waybillId);
    }

    public void setWaybillTechnologies(Long waybillId, List<WaybillTechnology> waybillTechnologies) {
        waybillIdToWaybillTechnologyListMap.put(waybillId, waybillTechnologies);
    }

    public boolean isHasMore() {
        return hasMore;
    }

    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }

}