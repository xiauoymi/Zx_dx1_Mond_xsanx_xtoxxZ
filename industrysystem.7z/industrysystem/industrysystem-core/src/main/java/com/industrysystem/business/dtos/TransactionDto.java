package com.industrysystem.business.dtos;

import javax.xml.bind.annotation.XmlType;

/**
 * User: LSCHW1
 */
@XmlType(name = "transaction" ,propOrder = {"sourceOrderNumber","source","type","remark","waybillNumber"})
public class TransactionDto {

    private Long sourceOrderNumber;
    private String source;
    private String type;
    private String remark;
    private String waybillNumber;

    public Long getSourceOrderNumber() {
        return sourceOrderNumber;
    }

    public void setSourceOrderNumber(Long sourceOrderNumber) {
        this.sourceOrderNumber = sourceOrderNumber;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getWaybillNumber() {
        return waybillNumber;
    }

    public Long getWaybillNumberAsLong() {
        return waybillNumber != null? Long.parseLong(waybillNumber): null;
    }

    public void setWaybillNumber(String waybillNumber) {
        this.waybillNumber = waybillNumber;
    }

}