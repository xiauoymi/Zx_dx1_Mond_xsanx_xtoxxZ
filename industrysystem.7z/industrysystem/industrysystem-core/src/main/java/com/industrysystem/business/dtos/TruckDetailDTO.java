package com.industrysystem.business.dtos;

public class TruckDetailDTO extends LoadDetailDTO {


    public TruckDetailDTO(String ctg) {
        this.setLoadIdentifier(ctg);
    }

    public TruckDetailDTO() {
        super();
    }

    public String getCtg() {
        return this.getLoadIdentifier();
    }

    public void setCtg(String ctg) {
        this.setLoadIdentifier(ctg);
    }

}
