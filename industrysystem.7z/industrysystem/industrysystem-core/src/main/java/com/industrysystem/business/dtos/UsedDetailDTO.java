package com.industrysystem.business.dtos;

import com.industrysystem.entities.WaybillStatusEnum;

import java.math.BigDecimal;

/**
 * User: ASEQU
 * Date: 12/6/13
 * Time: 3:01 PM
 */
public class UsedDetailDTO {

    private String waybillNumber;
    private BigDecimal totalTons;
    private String date = "";
    private String addressee = "";
    private String destination = "";
    private BigDecimal usedPpt;
    private BigDecimal usedPod;
    private WaybillStatusEnum waybillStatus;

    public UsedDetailDTO(String waybillNumber, BigDecimal totalTons, String date, BigDecimal usedPpt, BigDecimal usedPod, WaybillStatusEnum waybillStatus) {
        this.waybillNumber = waybillNumber;
        this.totalTons = totalTons;
        this.date = date;
        this.usedPpt = usedPpt;
        this.usedPod = usedPod;
        this.waybillStatus = waybillStatus;
    }

    public String getWaybillNumber() {
        return waybillNumber;
    }

    public BigDecimal getUsedPpt() {
        return this.usedPpt;
    }

    public BigDecimal getUsedPod() {
        return this.usedPod;
    }

    public BigDecimal getTotalTons() {
        return totalTons;
    }

    public String getDate() {
        return date;
    }

    public String getAddressee() {
        return addressee;
    }

    public String getDestination() {
        return destination;
    }

    public WaybillStatusEnum getWaybillStatus() {
        return waybillStatus;
    }
}
