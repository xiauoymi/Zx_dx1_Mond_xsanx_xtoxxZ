package com.industrysystem.business.dtos;

public class WagonDetailDTO extends LoadDetailDTO {

    private String wagonsQty;

    public WagonDetailDTO() {
    }

    public WagonDetailDTO(String wagonNumber, String wagonsQty) {
        this.setLoadIdentifier(wagonNumber);
        this.setWagonsQty(wagonsQty);
    }

    public String getWagonNumber() {
        return getLoadIdentifier();
    }

    public void setWagonNumber(String wagonNumber) {
        setLoadIdentifier(wagonNumber);
    }

	public String getWagonsQty() {
		return wagonsQty;
	}

	public void setWagonsQty(String wagonsQty) {
		this.wagonsQty = wagonsQty;
	}

}