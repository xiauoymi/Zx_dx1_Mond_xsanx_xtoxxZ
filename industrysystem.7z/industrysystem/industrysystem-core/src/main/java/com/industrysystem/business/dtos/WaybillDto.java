package com.industrysystem.business.dtos;

import java.util.List;

import static com.industrysystem.entities.utils.DocumentUtils.removeHyphens;
import static org.apache.commons.lang.StringUtils.isNotEmpty;

public abstract class WaybillDto {

    private String waybillType;
    private String holderName;
    private String holderDocument;
    private String commercialSenderName;
    private String commercialSenderDocument;
    private String destinationDocument;
    private Long destinationCommercialCode;
    private String cropCode;
    private List<LoadDetailDTO> loadDetails;
    private Long originLocation;
    private Long destinationLocation;
    private String waybillNumber;
    private String addresseeDocument;
    private String quantitativeLabCode;
    private String qualitativeLabCode;
    private String unloadingDate;

    public abstract String getDestinationDocumentType();

    public abstract String getAddresseeDocumentType();

    public abstract String getHolderDocumentType();

    public abstract String getCommercialSenderDocumentType();

    public abstract boolean isHolderDeclaredAsPod();

    public String getWaybillNumber() {
        return waybillNumber;
    }

    public Long getWaybillNumberAsLong() {
        return waybillNumber != null? Long.parseLong(waybillNumber): null;
    }

    public void setWaybillNumber(String waybillNumber) {
        this.waybillNumber = waybillNumber;
    }
    
    public String getWaybillType() {
        return waybillType;
    }

    public void setWaybillType(String waybillType) {
        this.waybillType = waybillType;
    }

    public String getHolderDocument() {
        return holderDocument;
    }

    public void setHolderDocument(String holderDocument) {
        this.holderDocument = holderDocument;
    }

    public String getDestinationDocument() {
        return destinationDocument;
    }

    public void setDestinationDocument(String destinationDocument) {
        this.destinationDocument = destinationDocument;
    }

    public Long getOriginLocation() {
        return originLocation;
    }

    public void setOriginLocation(Long originLocation) {
        this.originLocation = originLocation;
    }

    public Long getDestinationLocation() {
        return destinationLocation;
    }

    public void setDestinationLocation(Long destinationLocation) {
        this.destinationLocation = destinationLocation;
    }

    public List<LoadDetailDTO> getLoadDetails() {
        return loadDetails;
    }

    public void setLoadDetails(List<LoadDetailDTO> loadDetails) {
        this.loadDetails = loadDetails;
    }

    public String getCropCode() {
        return cropCode;
    }

    public void setCropCode(String cropCode) {
        this.cropCode = cropCode;
    }

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public String getCommercialSenderName() {
        return commercialSenderName;
    }

	public void setCommercialSenderName(String commercialSenderName) {
		this.commercialSenderName = commercialSenderName;
	}
	
	public String getCommercialSenderDocument() {
        return commercialSenderDocument;
    }

    public void setCommercialSenderDocument(String commercialSenderDocument) {
        this.commercialSenderDocument = commercialSenderDocument;
    }

	public String getAddresseeDocument() {
		return addresseeDocument;
	}

	public void setAddresseeDocument(String addresseeDocument) {
		this.addresseeDocument = addresseeDocument;
	}

    public String getQuantitativeLabCode() {
        return quantitativeLabCode;
    }

    public void setQuantitativeLabCode(String quantitativeLabCode) {
        this.quantitativeLabCode = quantitativeLabCode;
    }

    public String getQualitativeLabCode() {
        return qualitativeLabCode;
    }

    public void setQualitativeLabCode(String qualitativeLabCode) {
        this.qualitativeLabCode = qualitativeLabCode;
    }

    public String getUnloadingDate() {
        return unloadingDate;
    }

    public void setUnloadingDate(String unloadingDate) {
        this.unloadingDate = unloadingDate;
    }

    public Long getDestinationCommercialCode() {
        return destinationCommercialCode;
    }

    public void setDestinationCommercialCode(Long destinationCommercialCode) {
        this.destinationCommercialCode = destinationCommercialCode;
    }

    public boolean hasDeclaredTechnology() {
        for (LoadDetailDTO loadDetail: getLoadDetails()) {
            if (isNotEmpty(loadDetail.getDeclaredTechnology())) {
                return true;
            }
        }
        return false;
    }

    public WaybillDto removeDocumentsHyphens() {
        addresseeDocument = removeHyphens(addresseeDocument);
        holderDocument = removeHyphens(holderDocument);
        commercialSenderDocument = removeHyphens(commercialSenderDocument);
        return this;
    }

}