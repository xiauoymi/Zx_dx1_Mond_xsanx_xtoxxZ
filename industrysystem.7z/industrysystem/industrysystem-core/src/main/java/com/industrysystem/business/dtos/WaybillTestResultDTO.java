package com.industrysystem.business.dtos;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 28/11/13
 */
public abstract class WaybillTestResultDTO {

    private String waybillNumber;
    private String sampleCode;
    private List<TechnologyDTO> technologyList;
    private String holderName;
    private String holderDocument;
    private String commercialSenderDocument;
    private String commercialSenderName;

    public abstract String getDestinationDocumentType();

    public abstract String getAddresseeDocumentType();

    public abstract String getHolderDocumentType();

    public abstract String getCommercialSenderDocumentType();

    public String getWaybillNumber() {
        return waybillNumber;
    }

    public void setWaybillNumber(String waybillNumber) {
        this.waybillNumber = waybillNumber;
    }

    public String getSampleCode() {
        return sampleCode;
    }

    public void setSampleCode(String sampleCode) {
        this.sampleCode = sampleCode;
    }

    public List<TechnologyDTO> getTechnologyList() {
        return technologyList;
    }

    public void setTechnologyList(List<TechnologyDTO> technologyList) {
        this.technologyList = technologyList;
    }

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public String getHolderDocument() {
        return holderDocument;
    }

    public void setHolderDocument(String holderDocument) {
        this.holderDocument = holderDocument;
    }

    public String getCommercialSenderDocument() {
        return commercialSenderDocument;
    }

    public void setCommercialSenderDocument(String commercialSenderDocument) {
        this.commercialSenderDocument = commercialSenderDocument;
    }

    public String getCommercialSenderName() {
        return commercialSenderName;
    }

    public void setCommercialSenderName(String commercialSenderName) {
        this.commercialSenderName = commercialSenderName;
    }

}