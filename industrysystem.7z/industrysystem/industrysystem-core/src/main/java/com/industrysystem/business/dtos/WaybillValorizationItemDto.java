package com.industrysystem.business.dtos;

import com.industrysystem.entities.CurrencyCode;

import java.math.BigDecimal;

/**
 * User: LSCHW1
 */
public class WaybillValorizationItemDto {


    private String cropCode;
    private String technologyCode;
    private Integer quantity;
    private BigDecimal value;
    private CurrencyCode currencyCode;


    public String getCropCode() {
        return cropCode;
    }

    public void setCropCode(String cropCode) {
        this.cropCode = cropCode;
    }

    public String getTechnologyCode() {
        return technologyCode;
    }

    public void setTechnologyCode(String technologyCode) {
        this.technologyCode = technologyCode;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }

    public CurrencyCode getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(CurrencyCode currencyCode) {
        this.currencyCode = currencyCode;
    }
}
