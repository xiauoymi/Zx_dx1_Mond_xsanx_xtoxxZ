package com.industrysystem.business.dtos.waybilllisting;

import com.industrysystem.entities.*;

import java.text.SimpleDateFormat;
import java.util.*;

import static java.util.Collections.sort;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 13/02/14
 * Time: 11:15
 */
public class WaybillListing {

    private Long identifier;
    private TransportType transportType;
    private WaybillListingHolder holder;

    private WaybillListingCommercialSender commercialSender;

    private String creationDate;
    private String status;

    private WaybillListingPodBranch addressee;
    private WaybillListingPodBranch destination;

    private WaybillListingGoods goodsSource;
    private WaybillListingGoods goodsDestination;

    private String crop;
    private String campaign;
    private WaybillListingTechnology technology;

    private List<WaybillListingLoadDetail> loadDetails;
    private List<WaybillListingValorization> valorizations;

    public WaybillListing(Waybill waybill) {
        identifier = waybill.getWaybillNumber();
        transportType = waybill.getTransportType();
        status = waybill.getStatus() != null? waybill.getStatus().getDescription(): null;
        creationDate = waybill.getCreationDate() != null? new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").format(waybill.getCreationDate()): null;
        crop = waybill.getCrop() != null? waybill.getCrop().getDescription(): null;
        campaign = waybill.getCampaign() != null? waybill.getCampaign().getDescription(): null;
        holder = new WaybillListingHolder(waybill);
        commercialSender = new WaybillListingCommercialSender(waybill);
        addressee = new WaybillListingPodBranch(waybill.getAddressee());
        destination = new WaybillListingPodBranch(waybill.getDestination());
        goodsSource = new WaybillListingGoods(waybill.getGoodsSourceCity());
        goodsDestination = new WaybillListingGoods(waybill.getGoodsDestinationCity());
        technology = !waybill.getLoadDetails().isEmpty()? new WaybillListingTechnology(waybill.getLoadDetails().iterator().next()): null;

        fillLoadDetails(waybill.getLoadDetails());
        fillValorizations(waybill.getValorizations());
    }

    private void fillValorizations(Collection<WaybillValorization> valorizations) {
        this.valorizations = new ArrayList<WaybillListingValorization>();
        if (valorizations != null) {
            for (WaybillValorization valorization: valorizations) {
                this.valorizations.add(new WaybillListingValorization(valorization));
            }
        }
    }

    private void fillLoadDetails(Collection<LoadDetail> loadDetails) {
        this.loadDetails = new ArrayList<WaybillListingLoadDetail>();
        if (loadDetails != null) {
            for (LoadDetail loadDetail: loadDetails) {
                this.loadDetails.add(new WaybillListingLoadDetail(loadDetail));
            }
            sort(this.loadDetails, new Comparator<WaybillListingLoadDetail>() {
                @Override
                public int compare(WaybillListingLoadDetail o1, WaybillListingLoadDetail o2) {
                    return o1.getIdentifier().compareTo(o2.getIdentifier());
                }
            });
        }
    }

    public Long getIdentifier() {
        return identifier;
    }

    public TransportType getTransportType() {
        return transportType;
    }

    public WaybillListingHolder getHolder() {
        return holder;
    }

    public WaybillListingCommercialSender getCommercialSender() {
        return commercialSender;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public String getStatus() {
        return status;
    }

    public WaybillListingPodBranch getAddressee() {
        return addressee;
    }

    public WaybillListingPodBranch getDestination() {
        return destination;
    }

    public WaybillListingGoods getGoodsSource() {
        return goodsSource;
    }

    protected void setGoodsSource(WaybillListingGoods goodsSource) {
        this.goodsSource = goodsSource;
    }

    public WaybillListingGoods getGoodsDestination() {
        return goodsDestination;
    }

    public String getCrop() {
        return crop;
    }

    public String getCampaign() {
        return campaign;
    }

    public WaybillListingTechnology getTechnology() {
        return technology;
    }

    public List getLoadDetails() {
        return loadDetails;
    }

    public List getValorizations() {
        return valorizations;
    }

}