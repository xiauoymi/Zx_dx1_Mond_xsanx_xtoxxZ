package com.industrysystem.business.dtos.waybilllisting;

import com.industrysystem.entities.Document;
import com.industrysystem.entities.DocumentType;
import com.industrysystem.entities.Waybill;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 14/02/14
 * Time: 11:43
 */
public class WaybillListingCommercialSender {

    private String name;
    private String documentType;
    private String documentNumber;

    public WaybillListingCommercialSender(Waybill waybill) {
        this.name = waybill.getCommercialSenderName();
        Document document = waybill.getCommercialSenderDocument();
        if (document != null) {
            this.documentNumber = document.getNumber();
            if (document.getType() != null) {
                this.documentType = document.getType().getCode();
            }
        }
    }

    public String getName() {
        return name;
    }

    public String getDocumentType() {
        return documentType;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }
}
