package com.industrysystem.business.dtos.waybilllisting;

import com.industrysystem.entities.Event;
import com.industrysystem.entities.EventTypeEnum;

import java.text.SimpleDateFormat;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 21/02/14
 * Time: 11:00
 */
public class WaybillListingEvent {

    private String time;
    private EventTypeEnum type;
    private String user;

    public WaybillListingEvent(Event event) {
        this.type = event.getType();
        this.user = event.getUser();
        if (event.getTime() != null) {
            this.time = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss").format(event.getTime());
        }
    }

    public String getTime() {
        return time;
    }

    public EventTypeEnum getType() {
        return type;
    }

    public String getUser() {
        return user;
    }
}
