package com.industrysystem.business.dtos.waybilllisting;

import com.industrysystem.entities.Location;
import com.industrysystem.entities.Province;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 14/02/14
 * Time: 11:57
 */
public class WaybillListingGoods {

    private String city;
    private String province;

    public WaybillListingGoods(Location location) {
        if (location != null) {
            this.city = location.getDescription();
            Province province = location.getProvince();
            if (province != null) {
                this.province = province.getDescription();
            }
        }
    }

    public String getCity() {
        return city;
    }

    public String getProvince() {
        return province;
    }
}
