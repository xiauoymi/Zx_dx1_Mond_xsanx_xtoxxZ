package com.industrysystem.business.dtos.waybilllisting;

import com.industrysystem.entities.Document;
import com.industrysystem.entities.DocumentType;
import com.industrysystem.entities.Waybill;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 14/02/14
 * Time: 11:41
 */
public class WaybillListingHolder {

    private String name;
    private String documentType;
    private String documentNumber;

    public WaybillListingHolder(Waybill waybill) {
        Document document = waybill.getHolderDocument();
        if (document != null) {
            this.documentNumber = document.getNumber();
            if (document.getType() != null) {
                this.documentType = document.getType().getCode();
            }
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDocumentType() {
        return documentType;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }
}
