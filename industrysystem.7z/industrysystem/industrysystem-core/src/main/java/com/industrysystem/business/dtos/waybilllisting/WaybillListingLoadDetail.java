package com.industrysystem.business.dtos.waybilllisting;

import com.industrysystem.entities.Laboratory;
import com.industrysystem.entities.LoadDetail;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 14/02/14
 * Time: 17:22
 */
public class WaybillListingLoadDetail {

    private String identifier;
    private String sampleCode;
    private Integer weight;
    private String laboratory;

    public WaybillListingLoadDetail(LoadDetail loadDetail) {
        if (loadDetail != null) {
            this.identifier = loadDetail.getIdentifier();
            this.sampleCode = loadDetail.getSampleCode();
            this.weight = loadDetail.getWeight();
            Laboratory laboratory = loadDetail.getLaboratory();
            if (laboratory != null) {
                this.laboratory = laboratory.getCode();
            }
        }
    }

    public String getIdentifier() {
        return identifier;
    }

    public String getSampleCode() {
        return sampleCode;
    }

    public Integer getWeight() {
        return weight;
    }

    public String getLaboratory() {
        return laboratory;
    }
}
