package com.industrysystem.business.dtos.waybilllisting;

import com.industrysystem.entities.*;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 14/02/14
 * Time: 11:50
 */
public class WaybillListingPodBranch {

    private String name;
    private String documentType;
    private String documentNumber;
    private String address;
    private Long commercialCode;
    private String province;
    private String city;

    public WaybillListingPodBranch(PodBranch podBranch) {
        if (podBranch != null) {
            this.name = podBranch.getName();

            Document document = podBranch.getDocument();
            if (document != null) {
                this.documentNumber = document.getNumber();
                if (document.getType() != null) {
                    this.documentType = document.getType().getCode();
                }
            }

            this.address = podBranch.getAddress();
            this.commercialCode = podBranch.getCommercialCode();

            Province province = podBranch.getProvince();
            if (province != null) {
                this.province = province.getDescription();
            }

            Location location = podBranch.getLocation();
            if (location != null) {
                this.city = location.getDescription();
            }
        }
    }

    public String getName() {
        return name;
    }

    public String getDocumentType() {
        return documentType;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public String getAddress() {
        return address;
    }

    public Long getCommercialCode() {
        return commercialCode;
    }

    public String getProvince() {
        return province;
    }

    public String getCity() {
        return city;
    }
}
