package com.industrysystem.business.dtos.waybilllisting;

import com.industrysystem.entities.*;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import static java.util.Collections.sort;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 17/02/14
 * Time: 11:30
 */
public class WaybillListingTechnology {

    private String declaration;
    private List<WaybillListingTestResult> testResults;

    public WaybillListingTechnology(LoadDetail loadDetail) {
        if (loadDetail != null) {
            try {
                for (Declaration declaration: loadDetail.getDeclarations()) {
                    this.declaration = declaration.getCropTechnology().getTechnology().getDescription();
                    break;
                }
            } catch (NullPointerException ex) {}

            testResults = new ArrayList<WaybillListingTestResult>();
            fillQualitativeTestResults(loadDetail.getQualitativeTestRequests());
            fillCuantitativeTestResults(loadDetail.getCuantitativeTestRequests());

            sort(testResults, new Comparator<WaybillListingTestResult>() {
                @Override
                public int compare(WaybillListingTestResult o1, WaybillListingTestResult o2) {
                    int compareDescription = o1.getDescription().compareTo(o2.getDescription());
                    if (compareDescription == 0) {
                        return o1.getPercentage().compareTo(o2.getPercentage());
                    }
                    return compareDescription;
                }
            });
        }
    }

    private void fillQualitativeTestResults(List<QualitativeTestRequest> testRequests) {
        if (testRequests != null) {
            for (QualitativeTestRequest testRequest: testRequests) {
                testResults.add(new WaybillListingTestResult(testRequest));
            }
        }
    }

    private void fillCuantitativeTestResults(List<CuantitativeTestRequest> testRequests) {
        if (testRequests != null) {
            for (CuantitativeTestRequest testRequest: testRequests) {
                testResults.add(new WaybillListingTestResult(testRequest));
            }
        }
    }

    public String getDeclaration() {
        return declaration;
    }

    public List<WaybillListingTestResult> getTestResults() {
        return testResults;
    }

}