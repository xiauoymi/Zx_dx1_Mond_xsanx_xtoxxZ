package com.industrysystem.business.dtos.waybilllisting;

import com.industrysystem.entities.*;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 17/02/14
 * Time: 12:04
 */
public class WaybillListingTestResult {

    private String description;
    private BigDecimal percentage;

    public WaybillListingTestResult(CuantitativeTestRequest testRequest) {
        try {
            for (CuantitativeTestResult result : testRequest.getCuantitativeTestResults()) {
                this.percentage = result.getRatio();
                this.description = result.getCropTechnology().getTechnology().getDescription();
                break;
            }
        } catch (NullPointerException ex) {}
    }

    public WaybillListingTestResult(QualitativeTestRequest testRequest) {
        try {
            description = testRequest.getCropTechnologyForCampaign().getCropTechnology().getTechnology().getDescription();
        } catch (NullPointerException ex) {}
        QualitativeTestResult qualitativeTestResult = testRequest.getQualitativeTestResult();
        if (qualitativeTestResult != null) {
            percentage = qualitativeTestResult.getResult() ? new BigDecimal(100) : new BigDecimal(0);
        }
    }

    public String getDescription() {
        return description;
    }

    public BigDecimal getPercentage() {
        return percentage;
    }
}
