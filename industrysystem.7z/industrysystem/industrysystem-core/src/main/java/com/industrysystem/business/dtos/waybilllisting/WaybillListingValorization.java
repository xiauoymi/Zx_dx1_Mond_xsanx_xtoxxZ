package com.industrysystem.business.dtos.waybilllisting;

import com.industrysystem.entities.WaybillValorization;

import java.math.BigDecimal;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 14/02/14
 * Time: 17:58
 */
public class WaybillListingValorization {

    private String technology;
	private Integer quantity;
	private BigDecimal value;

    public WaybillListingValorization(WaybillValorization valorization) {
        try {
            this.quantity = valorization.getQuantity();
            this.value = valorization.getValue();
            this.technology = valorization.getCropTechnology().getTechnology().getDescription();
        } catch (NullPointerException ex) {}
    }

    public String getTechnology() {
        return technology;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public BigDecimal getValue() {
        return value;
    }
}
