package com.industrysystem.business.mappers;

import com.industrysystem.entities.Document;
import com.industrysystem.entities.DocumentType;
import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.BusinessException;
import com.industrysystem.persistence.daos.DocumentTypeDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.NoResultException;

import static com.google.common.collect.Lists.newArrayList;
import static org.apache.commons.lang.StringUtils.upperCase;

@Component
public class DocumentMapper {

    @Autowired
    private DocumentTypeDao documentTypeDao;

    public Document map(String documentTypeCode,String documentNumber) throws BusinessException {
        Document document = new Document();
        document.setNumber(documentNumber);
        document.setType(findDocumentTypeByCode(documentTypeCode));
        return document;
    }

    private DocumentType findDocumentTypeByCode(String documentTypeCode) throws BusinessException {
        try{
            return documentTypeDao.findByCode(upperCase((documentTypeCode)));
        }catch (NoResultException e){
            throw new BusinessException(newArrayList(new BusinessError(BusinessError.INVALID_DOCUMENT_TYPE, "Invalid Document Type")));
        }
    }

}