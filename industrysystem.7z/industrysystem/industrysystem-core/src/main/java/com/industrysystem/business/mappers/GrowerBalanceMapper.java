package com.industrysystem.business.mappers;

import com.industrysystem.business.dtos.GrowerBalanceOperationDto;
import com.industrysystem.business.dtos.TransactionDto;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.GrowerAccountUpdateException;
import com.industrysystem.persistence.daos.GrowerAccountDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;

/**
 * User: LSCHW1
 */
@Component
public class GrowerBalanceMapper {

    @Autowired
    private GrowerAccountDao growerAccountDao;

    public Transaction mapTransaction(TransactionDto transactionDto) {
        Transaction transaction=new Transaction();
        transaction.setType(transactionDto.getType());
        transaction.setSource(transactionDto.getSource());
        transaction.setSourceOrderNumber(transactionDto.getSourceOrderNumber());
        transaction.setRemark(transactionDto.getRemark());
        transaction.setDate(new Date());
        return transaction;
    }

    public GrowerTransactionItem mapTransactionItem(BigDecimal value, GrowerBalanceType balanceType, GrowerBalance growerBalance) {
        GrowerTransactionItem transactionItem=new GrowerTransactionItem();
        transactionItem.setBalanceName(balanceType.name());
        transactionItem.setValue(value);
        transactionItem.setGrowerBalance(growerBalance);
        return transactionItem;
    }

    public GrowerAccount mapGrowerAccount(GrowerBalanceOperationDto item, String traitOwnerCode) throws GrowerAccountUpdateException {
        GrowerAccount growerAccount=new GrowerAccount();

        CropTechnology cropTechnology = new CropTechnology();
        cropTechnology.setTechnology(new Technology(null, new TraitOwner(traitOwnerCode)));
        growerAccount.setCropTechnology(cropTechnology);

        growerAccount.setNumber(item.getAccountNumber());

        growerAccount=growerAccountDao.refreshAccount(growerAccount);
        if (growerAccount==null){
            throw new GrowerAccountUpdateException(new BusinessError(BusinessError.ACCOUNT_GROWER_NOT_FOUND,"Grower Account not exists"));
        }

        return growerAccount;
    }
}
