package com.industrysystem.business.mappers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.industrysystem.business.dtos.WaybillDto;
import com.industrysystem.entities.Document;
import com.industrysystem.entities.PodBranch;
import com.industrysystem.entities.PodHeadOffice;
import com.industrysystem.exceptions.PodNotFoundException;
import com.industrysystem.persistence.daos.PodDao;

import static org.apache.commons.lang.StringUtils.upperCase;

@Component
public class PodMapper {

    @Autowired
    private PodDao podDao;

    public PodBranch mapAddressee(WaybillDto waybillDto) throws PodNotFoundException {
        Document addresseeDocument = new Document(upperCase(waybillDto.getAddresseeDocumentType()), waybillDto.getAddresseeDocument());
        PodHeadOffice addresseeHeadOffice = podDao.findByDocument(addresseeDocument);
        return addresseeHeadOffice.getMainPodBranch();
    }

    public PodBranch mapDestination(WaybillDto waybillDto) throws PodNotFoundException {
        Document destinationDocument = new Document(upperCase(waybillDto.getDestinationDocumentType()), waybillDto.getDestinationDocument());
        return podDao.findByDocumentAndCommercialCode(destinationDocument, waybillDto.getDestinationCommercialCode());
    }

}