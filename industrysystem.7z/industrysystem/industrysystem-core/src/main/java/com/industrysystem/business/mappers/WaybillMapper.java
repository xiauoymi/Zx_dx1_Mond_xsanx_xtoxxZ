package com.industrysystem.business.mappers;

import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.TruckDetailDTO;
import com.industrysystem.business.dtos.WagonDetailDTO;
import com.industrysystem.business.dtos.WaybillDto;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.BusinessException;
import com.industrysystem.exceptions.CropTechnologyNotFoundException;
import com.industrysystem.exceptions.WaybillRegistrationException;
import com.industrysystem.persistence.daos.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

import static com.industrysystem.entities.TransportType.fromCode;
import static org.apache.commons.lang.StringUtils.isNotEmpty;
import static org.apache.commons.lang.StringUtils.upperCase;

/**
 * User: JPNORV
 * Date: 29/11/13
 */
@Component
public class WaybillMapper {

    @Autowired
    private CampaignDao campaignDao;
    @Autowired
    private CropDao cropDao;
    @Autowired
    private CropTechnologyDao cropTechnologyDao;
    @Autowired
    private PodMapper podMapper;
    @Autowired
    private DocumentMapper documentMapper;
    @Autowired
    private LocationDao locationDao;
    @Autowired
    private PodDao podDao;

    public Waybill map(Waybill waybill, WaybillDto waybillDto) throws WaybillRegistrationException {
        Campaign campaign;
        Crop crop;
        Location goodsSourceCity;
        Location goodsDestinationCity;
        boolean isPodParticipant;
        Date now = new Date();
        try {
            campaign = campaignDao.findCampaignBy(now);
            crop = cropDao.findCropBy(upperCase(waybillDto.getCropCode()));
            goodsSourceCity = locationDao.findLocationByCode(waybillDto.getOriginLocation());
            goodsDestinationCity = locationDao.findLocationByCode(waybillDto.getDestinationLocation());
            waybill.setAddressee(podMapper.mapAddressee(waybillDto));
            waybill.setDestination(podMapper.mapDestination(waybillDto));

            Document holderDocument = new Document(waybillDto.getHolderDocumentType(), waybillDto.getHolderDocument());

            boolean podDocumentDeclared = podDao.isPODDocumentDeclared(holderDocument);
            isPodParticipant = waybillDto.isHolderDeclaredAsPod() && podDocumentDeclared;
            waybill.setHolderIsRegisteredPod(podDocumentDeclared);

            if (isPodParticipant || waybillDto.hasDeclaredTechnology()) {
                waybill.setHolderDocument(documentMapper.map(waybillDto.getHolderDocumentType(), waybillDto.getHolderDocument()));
                fillCommercialSenderDocument(waybill, waybillDto);
            }
		} catch (BusinessException ex) {
			throw new WaybillRegistrationException(ex);
		}

        waybill.setCampaign(campaign);
        waybill.setCrop(crop);
        waybill.setCreationDate(now); //TODO should be given by the user interface
        waybill.setGoodsSourceCity(goodsSourceCity);
        waybill.setGoodsDestinationCity(goodsDestinationCity);
        waybill.setHolderDeclaredIsPod(waybillDto.isHolderDeclaredAsPod());
        waybill.setUnloadingTime(now);
        waybill.setTransportType(fromCode(waybillDto.getWaybillType()));
        waybill.setGoodsSourceCity(goodsSourceCity);
        waybill.setGoodsDestinationCity(goodsDestinationCity);

        try {
            fillLoadDetails(waybillDto, crop, isPodParticipant, waybill);
        } catch (CropTechnologyNotFoundException e) {
            throw new WaybillRegistrationException(e);
        }

        return waybill;
    }

    protected void fillCommercialSenderDocument(Waybill waybill, WaybillDto waybillDto) throws BusinessException {
        if (waybillDto.getCommercialSenderDocument() != null) {
            Document document = documentMapper.map(waybillDto.getCommercialSenderDocumentType(), waybillDto.getCommercialSenderDocument());
            waybill.setCommercialSenderDocument(document);
            waybill.setCommercialSenderName(waybillDto.getCommercialSenderName());
        }
    }

    private void fillLoadDetails(WaybillDto waybillDto, Crop crop, boolean isPodParticipant, Waybill waybill)
            throws CropTechnologyNotFoundException {
        List<Technology> technologyList = cropTechnologyDao.findTechnologies();

        for (LoadDetailDTO loadDetailDTO: waybillDto.getLoadDetails()) {
            LoadDetail loadDetail = newLoadDetail(loadDetailDTO, fromCode(waybillDto.getWaybillType()));

            String declaredTechnology = loadDetailDTO.getDeclaredTechnology();
            if (!isPodParticipant && isNotEmpty(declaredTechnology)) {
                Technology technology = findTechnologyByCode(technologyList, declaredTechnology);
                CropTechnology cropTechnology = cropTechnologyDao.findByCropAndTechnology(crop, technology);

                Declaration declaration = new Declaration();
                declaration.setCropTechnology(cropTechnology);
                declaration.setLoadDetail(loadDetail);
                loadDetail.getDeclarations().add(declaration);
            }

            loadDetail.setWaybill(waybill);
            waybill.addLoadDetail(loadDetail);
        }
    }

    protected LoadDetail newLoadDetail(LoadDetailDTO dto, TransportType transportType) {
        LoadDetail loadDetail;
        if (TransportType.VAGON_FERROVIARIO == transportType) {
            WagonDetailDTO wagonDto = (WagonDetailDTO)dto;
            loadDetail = new WagonLoadDetail(upperCase(wagonDto.getWagonNumber()), Integer.valueOf(wagonDto.getWagonsQty()));
        } else {
            loadDetail = new TruckLoadDetail(upperCase(((TruckDetailDTO)dto).getCtg()));
        }
        return loadDetail;
    }

    protected Technology findTechnologyByCode(List<Technology> technologyList, String technologyCode) throws CropTechnologyNotFoundException {
        for (Technology technology: technologyList) {
            if (technologyCode.equalsIgnoreCase(technology.getCode())) {
                return technology;
            }
        }
        throw new CropTechnologyNotFoundException(technologyCode);
    }

}