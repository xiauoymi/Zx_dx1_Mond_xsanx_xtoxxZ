package com.industrysystem.business.mappers;

import com.industrysystem.business.dtos.WaybillValorizationItemDto;
import com.industrysystem.entities.CropTechnology;
import com.industrysystem.entities.Waybill;
import com.industrysystem.entities.WaybillValorization;
import com.industrysystem.exceptions.*;
import com.industrysystem.persistence.daos.CropTechnologyDao;
import com.industrysystem.persistence.daos.WaybillDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * User: LSCHW1
 */
@Component
public class WaybillValorizationMapper {

    @Autowired
    private CropTechnologyDao cropTechnologyDao;

    @Autowired
    private WaybillDao waybillDao;

    public WaybillValorization map(String traitOwnerCode, Waybill waybill, WaybillValorizationItemDto item) throws WaybillValorizationException {
            WaybillValorization valorization = new WaybillValorization();
            valorization.setCurrencyCode(item.getCurrencyCode());
            valorization.setQuantity(item.getQuantity());
            valorization.setValue(item.getValue());
            valorization.setWaybill(waybill);
            valorization.setCropTechnology(findCropTechnology(item.getCropCode(), item.getTechnologyCode(), traitOwnerCode));
            return valorization;
    }

    //TODO extract to CropTechnologyMapper (throw BussinessException)
    private CropTechnology findCropTechnology(String cropCode, String technologyCode, String traitOwnerCode) throws WaybillValorizationException {
        try {
            return cropTechnologyDao.findByCropCodeAndTechnologyCodeAndTraitOwnerCode(cropCode, technologyCode, traitOwnerCode);
        } catch (CropTechnologyNotFoundException e) {
            throw new WaybillValorizationException(new BusinessError(BusinessError.CROP_TECHNOLOGY_NOT_FOUND, "Crop Technology must exists"));
        }
    }


    //TODO extract to waybillMapper (throw BussinessException)
    public Waybill mapWaybill(Long wayBillNumber) throws WaybillValorizationException {
        try{
            return waybillDao.findWaybillByWaybillNumber(wayBillNumber);
        } catch (WaybillNotFoundException e) {
            throw new WaybillValorizationException(new BusinessError(BusinessError.WAYBILL_NOT_FOUND, "Waybill not found"));
        }

    }

}