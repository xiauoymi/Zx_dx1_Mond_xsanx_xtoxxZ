package com.industrysystem.business.users;

import org.springframework.security.ldap.userdetails.InetOrgPerson;

import com.industrysystem.exceptions.SendingEmailException;

public interface MailSender {
	void sendPasswordRecoveryMail(String urlToSend, String baseImagesUrl, InetOrgPerson person) throws SendingEmailException;
}
