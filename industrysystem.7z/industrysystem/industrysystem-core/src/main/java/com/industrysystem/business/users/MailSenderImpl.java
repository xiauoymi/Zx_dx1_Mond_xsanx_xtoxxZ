package com.industrysystem.business.users;

import com.industrysystem.exceptions.SendingEmailException;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.ldap.userdetails.InetOrgPerson;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

@Component
public class MailSenderImpl implements MailSender{

    @Autowired
    private JavaMailSender javaMailSender;
    
    @Autowired
    private MessageSource messageSource;
    
	private static final Logger logger = LoggerFactory.getLogger(MailSenderImpl.class);

    public void sendPasswordRecoveryMail(String urlToSend, String baseImagesUrl, InetOrgPerson person) throws SendingEmailException {
		
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		try {

			prepareMessage(person, mimeMessage);
			
			Template template = createTemplate();
			
			String content = createContent(urlToSend, baseImagesUrl, person, template);
			
			mimeMessage.setContent(content, "text/html");
			
			javaMailSender.send(mimeMessage);

		} catch (Exception e) {
			logger.error("Error sending mail", e);
			throw new SendingEmailException(e);
		}
	}

	private String createContent(String urlToSend, String baseImagesUrl, InetOrgPerson person, Template template) throws TemplateException,
			IOException {
		StringWriter out = new StringWriter();
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("name", person.getSn());
		data.put("link", urlToSend);
		data.put("baseImages", baseImagesUrl);
		template.process(data, out);
		return out.toString();
	}

	private void prepareMessage(InetOrgPerson person, MimeMessage mimeMessage)
			throws MessagingException, UnsupportedEncodingException {
		
		MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, false, "utf-8");
		helper.setTo(person.getMail());
		String subject = messageSource.getMessage("recover_password.email.subject", null, LocaleContextHolder.getLocale());
		helper.setSubject(subject);
		String fromAddress = messageSource.getMessage("recover_password.email.from.address", null, LocaleContextHolder.getLocale());
		String fromName = messageSource.getMessage("recover_password.email.from.name", null, LocaleContextHolder.getLocale());
		helper.setFrom(fromAddress, fromName);
	}

	private Template createTemplate() throws IOException {
		Configuration cfg = new Configuration();
		cfg.setClassForTemplateLoading(this.getClass(), "/email_templates");
		cfg.setEncoding(LocaleContextHolder.getLocale(), "utf-8");
		return cfg.getTemplate("recover_password.ftl");
	}

}
