package com.industrysystem.business.users;

import com.industrysystem.entities.*;
import com.industrysystem.exceptions.*;
import com.industrysystem.security.groups.FunctionalSecurityGroup;
import com.industrysystem.security.groups.SecurityGroup;
import org.springframework.security.ldap.userdetails.InetOrgPerson;

import javax.naming.InvalidNameException;
import javax.naming.NamingException;
import java.util.List;

public interface UsersService {

    public static final int MAX_FAILED_LOGIN_ATTEMPTS_BEFORE_CHECKING_CAPTCHA = 3;

    public boolean isPasswordValid(String uid, String password);

    public void changePassword(String uid, String oldPassword, String newPassword) throws NamingException;

    public void resetPassword(String uid, String newPassword) throws NamingException;

    public List<String> findAllRoleNames();

    public void assignGroups(String document, List<String> groups) throws InvalidNameException, NamingException;

    public List<Document> listGrowerDocumentsForCurrentUser();

    public List<String> listTraitOwnersForCurrentUser();

    public List<String> listLaboratoryCodesForCurrentUser();

    public void createUser(String uid, String password, List<FunctionalSecurityGroup> assignedGroups, String sn, String email) throws InvalidNameException, NamingException;

    public List<SecurityGroup> findAllGroups();

    public void sendMailForPasswordRecovery(String emailAddress, String urlToSend, String baseImagesUrl) throws SendingEmailException;

    public InetOrgPerson findPersonWithEmailAddress(String emailAddress) throws DirectorySearchResultsException;

    public String generatePasswordResetToken(String emailAddress);
    
    public List<ChallengeQuestion> findChallengeQuestions(String emailAddress);

    public InetOrgPerson obtainPersonForPasswordResetToken(String token) throws InvalidTokenException, DirectorySearchResultsException;

    public boolean isExistentUser(String user);

    public boolean hasRequiredCaptchasForAuthentication(String remoteAddress, String recaptchaChallengeField, String recaptchaResponseField);

    public Integer findFailedAttemptsCount(String remoteAddress);

    public void incrementFailedAttempt(String remoteAddr);

    public void cleanFailedAuthenticationAttemptsCount(String remoteAddr);

    public boolean hasRequiredCaptchasForRecoverPassword(String remoteAddress, String recaptchaChallengeField, String recaptchaResponseField);

	public void addChallengeQuestion(String emailAddress, String question, String answer);

	public void removeChallengeQuestionByIndex(String emailAddress,
			Integer toRemove);

	public boolean challengeQuestionRespondedOk(String expetcted, String actual);

	public void resetRemainingChallengeQuestionsAttempts(String mail);

	public void consumeRemainingChallengeQuestionsAttempt(String mail);

	public List<ChallengeQuestion> findDoableChallengeQuestions(String mail);

    public String getCurrentUsersUsername() throws UserNotLoggedException;

    public List<PodBranch> getPodBranchesFromCurrentUser() throws PodNotFoundException;

    public List<Waybill> findPendingWaybillsFromCurrentUser() throws PodNotFoundException;

}
