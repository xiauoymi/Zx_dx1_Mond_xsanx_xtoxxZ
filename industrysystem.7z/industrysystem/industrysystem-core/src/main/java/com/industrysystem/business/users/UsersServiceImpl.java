package com.industrysystem.business.users;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.annotation.Nullable;
import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;

import net.tanesha.recaptcha.ReCaptcha;
import net.tanesha.recaptcha.ReCaptchaResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.keygen.BytesKeyGenerator;
import org.springframework.security.crypto.keygen.KeyGenerators;
import org.springframework.security.ldap.userdetails.InetOrgPerson;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Function;
import com.industrysystem.entities.ChallengeQuestion;
import com.industrysystem.entities.Document;
import com.industrysystem.entities.PodBranch;
import com.industrysystem.entities.PodHeadOffice;
import com.industrysystem.entities.Waybill;
import com.industrysystem.entities.WaybillStatusEnum;
import com.industrysystem.exceptions.BusinessException;
import com.industrysystem.exceptions.DirectorySearchResultsException;
import com.industrysystem.exceptions.InvalidTokenException;
import com.industrysystem.exceptions.PodNotFoundException;
import com.industrysystem.exceptions.SendingEmailException;
import com.industrysystem.exceptions.UserNotLoggedException;
import com.industrysystem.persistence.daos.ChallengeQuestionDao;
import com.industrysystem.persistence.daos.FailedAttemptsCountDao;
import com.industrysystem.persistence.daos.PodDao;
import com.industrysystem.persistence.daos.SecurityDao;
import com.industrysystem.persistence.daos.WaybillDao;
import com.industrysystem.security.LdapHelper;
import com.industrysystem.security.groups.BranchFunctionalSecurityGroup;
import com.industrysystem.security.groups.FunctionalSecurityGroup;
import com.industrysystem.security.groups.GrowerFunctionalSecurityGroup;
import com.industrysystem.security.groups.HeadOfficeFunctionalSecurityGroup;
import com.industrysystem.security.groups.SecurityGroup;

import static com.google.common.collect.FluentIterable.from;
import static com.google.common.collect.Lists.newArrayList;
import static java.util.Collections.emptyList;
import static java.util.Collections.shuffle;

@Component
public class UsersServiceImpl implements UsersService {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private LdapHelper ldapHelper;

    @Autowired
    private MailSender mailSender;

    @Value("${ldap.admin.user.unrooted}")
    private String adminUser;

    @Value("${ldap.admin.password}")
    private String adminUserPassword;

    @Autowired
    private SecurityDao securityDao;

    @Autowired
    private FailedAttemptsCountDao failedAttemptsCountDao;

    @Autowired
    private ReCaptcha reCaptcha;

    @Autowired
    private ChallengeQuestionDao challengeQuestionDao;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private PodDao podDao;

    @Autowired
    private WaybillDao waybillDao;

    private final BytesKeyGenerator saltGenerator = KeyGenerators.secureRandom();

    @Override
    public boolean isPasswordValid(String uid, String password) {
        boolean isPasswordValid = true;
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(uid, password));
        } catch (BadCredentialsException e) {
            isPasswordValid = false;
        }
        return isPasswordValid;
    }

    @Override
    public void changePassword(String uid, String oldPassword, String newPassword) throws NamingException {
        ldapHelper.changePassword(uid, oldPassword, newPassword);
    }

    @Override
    public void resetPassword(String uid, String newPassword) throws NamingException {
        ldapHelper.resetPassword(uid, newPassword, adminUser, adminUserPassword);

    }

    @Override
    //TODO:@PreAuthorize("isAdministrator()")
    // or hasLenientRole(final String inputRole)
    // or hasStrictRole(final String inputRole, final String inputGroup)
    public List<String> findAllRoleNames() {
        return ldapHelper.findAllRoleNames();
    }

    @Override
    @PreAuthorize("isAdministrator()")
    public void assignGroups(String document, List<String> groups) throws InvalidNameException, NamingException {
        DirContext adminContext = ldapHelper.getAuthenticatedContext(adminUser, adminUserPassword);
        for (String groupName: groups) {
            addDocumentSubgroupToGroup(groupName, document, adminContext);
        }
    }

    @Override
    public List<Document> listGrowerDocumentsForCurrentUser() {
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        return from(authorities).filter(GrowerFunctionalSecurityGroup.class).transform(new Function<GrowerFunctionalSecurityGroup, Document>() {
            @Override
            public Document apply(@Nullable GrowerFunctionalSecurityGroup input) {
                return input.getDocument();
            }
        }).toImmutableList();
    }

     @Override
     public List<PodBranch> getPodBranchesFromCurrentUser() throws PodNotFoundException {
        Set<PodBranch> branches = new HashSet<PodBranch>();
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();

        for (GrantedAuthority grantedAuthority: authorities) {
            if (grantedAuthority instanceof BranchFunctionalSecurityGroup) {
                BranchFunctionalSecurityGroup branchGroup = (BranchFunctionalSecurityGroup) grantedAuthority;
                branches.add(podDao.findByDocumentAndCommercialCode(branchGroup.getDocument(), branchGroup.getCommercialCode()));
            } else if (grantedAuthority instanceof HeadOfficeFunctionalSecurityGroup) {
                HeadOfficeFunctionalSecurityGroup headOfficeGroup = (HeadOfficeFunctionalSecurityGroup) grantedAuthority;
                PodHeadOffice headOffice = podDao.findByDocumentWithBranches(headOfficeGroup.getDocument());
                branches.addAll(headOffice.getPodBranches());
            }
        }

        return new ArrayList<PodBranch>(branches);
     }

    @Override
    public List<String> listTraitOwnersForCurrentUser() {
        List<String> traitOwners = new ArrayList<String>();
        traitOwners.addAll(getGroupNameFromFunctionalSecurityGroup(FunctionalSecurityGroup.RolNames.TO_COLLECTION.name()));
        traitOwners.addAll(getGroupNameFromFunctionalSecurityGroup(FunctionalSecurityGroup.RolNames.TO_COMMERCIAL.name()));
        traitOwners.addAll(getGroupNameFromFunctionalSecurityGroup(FunctionalSecurityGroup.RolNames.TO_AUDIT.name()));

        return traitOwners;
    }

    @Override
    public List<String> listLaboratoryCodesForCurrentUser() {
        return getGroupNameFromFunctionalSecurityGroup(FunctionalSecurityGroup.RolNames.LAB_RESULTS_LOADER.name());
    }

    private List<String> getGroupNameFromFunctionalSecurityGroup(String securityGroup) {
        List<String> toReturn = new ArrayList<String>();
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        for (GrantedAuthority grantedAuthority: authorities) {
            if (grantedAuthority instanceof FunctionalSecurityGroup) {
                FunctionalSecurityGroup functionalSecurityGroup = (FunctionalSecurityGroup) grantedAuthority;
                if (functionalSecurityGroup.isA(securityGroup)) {
                    toReturn.add(functionalSecurityGroup.getGroupName());
                }
            }
        }
        return toReturn;
    }

    @Override
    @PreAuthorize("isAdministrator()")
    public void createUser(String uid, String password, List<FunctionalSecurityGroup> assignedGroups, String sn, String email)
            throws NamingException {
        DirContext adminContext = ldapHelper.getAuthenticatedContext(adminUser, adminUserPassword);
        Name name = ldapHelper.buildUserDn(uid);
        DirContextAdapter dirContextAdapter = ldapHelper.makeUserObject(uid, sn, password, email);
        adminContext.bind(name, dirContextAdapter, null);
        for (FunctionalSecurityGroup securityGroup: assignedGroups) {
            ldapHelper.addUserToGroup(uid, securityGroup, adminContext);
        }
    }

    @Override
    @PreAuthorize("isAdministrator()")
    public List<SecurityGroup> findAllGroups() {
        return ldapHelper.findAllGroups();
    }

    private void addDocumentSubgroupToGroup(String groupName, String document, DirContext adminContext) throws NamingException {
        Name name = ldapHelper.buildGroupDn(groupName, document);
        DirContextAdapter dirContextAdapter = ldapHelper.makeGroupObject(document);
        adminContext.bind(name, dirContextAdapter, null);
    }

    private InetOrgPerson obtainPerson(String emailAddress) {
        try {
            return findPersonWithEmailAddress(emailAddress);
        } catch (DirectorySearchResultsException e1) {
            //Should have been validated before;
            throw new RuntimeException(e1);
        }
    }

    @Override
    public InetOrgPerson findPersonWithEmailAddress(String emailAddress) throws DirectorySearchResultsException {
        return ldapHelper.findPersonByEmailAddress(emailAddress);
    }

    @Override
    public void sendMailForPasswordRecovery(String emailAddress, String urlToSend, String baseImagesUrl) throws SendingEmailException {
        InetOrgPerson person = obtainPerson(emailAddress);
        mailSender.sendPasswordRecoveryMail(urlToSend, baseImagesUrl, person);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    public String generatePasswordResetToken(String emailAddress) {
        String token = UUID.randomUUID().toString();
        securityDao.persistTokenForEmailAddress(token, emailAddress);
        return token;
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class}, noRollbackFor = {InvalidTokenException.class, DirectorySearchResultsException.class})
    public InetOrgPerson obtainPersonForPasswordResetToken(String token) throws InvalidTokenException, DirectorySearchResultsException {
        String emailAddress = securityDao.consumePasswordResetToken(token);
        return findPersonWithEmailAddress(emailAddress);
    }

    @Override
    public boolean isExistentUser(String username) {
        return ldapHelper.isExistentUser(username);
    }

    @Override
    public boolean hasRequiredCaptchasForAuthentication(String remoteAddress, String recaptchaChallengeField, String recaptchaResponseField) {
        return !requiresCaptchaToLogin(remoteAddress) || isValidCaptcha(remoteAddress, recaptchaChallengeField, recaptchaResponseField);
    }

    @Override
    public Integer findFailedAttemptsCount(String remoteAddress) {
        return failedAttemptsCountDao.findCountByRemoteAddress(remoteAddress);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    public void incrementFailedAttempt(String remoteAddr) {
        failedAttemptsCountDao.incrementFailedAttempt(remoteAddr);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    public void cleanFailedAuthenticationAttemptsCount(String remoteAddr) {
        failedAttemptsCountDao.cleanFailedAuthenticationAttemptsCount(remoteAddr);
    }

    @Override
    public boolean hasRequiredCaptchasForRecoverPassword(String remoteAddress, String recaptchaChallengeField, String recaptchaResponseField) {
        return isValidCaptcha(remoteAddress, recaptchaChallengeField, recaptchaResponseField);
    }

    private boolean requiresCaptchaToLogin(String remoteAddress) {
        return failedAttemptsCountDao.findCountByRemoteAddress(remoteAddress) >= MAX_FAILED_LOGIN_ATTEMPTS_BEFORE_CHECKING_CAPTCHA;
    }

    private boolean isValidCaptcha(String remoteAddress, String recaptchaChallengeField, String recaptchaResponseField) {
        if (recaptchaChallengeField == null || recaptchaResponseField == null || remoteAddress == null) {
            return false;
        }

        ReCaptchaResponse reCaptchaResponse = reCaptcha.checkAnswer(remoteAddress, recaptchaChallengeField, recaptchaResponseField);
        return reCaptchaResponse.isValid();
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    public List<ChallengeQuestion> findChallengeQuestions(String emailAddress) {
        return challengeQuestionDao.findChallengeQuestions(emailAddress);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    public void addChallengeQuestion(String emailAddress, String question, String answer) {
        String encodedAnswer = passwordEncoder.encodePassword(answer, saltGenerator.generateKey());
        challengeQuestionDao.addChallengeQuestion(emailAddress, question, encodedAnswer);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    public void removeChallengeQuestionByIndex(String emailAddress, Integer toRemove) {
        ChallengeQuestion challengeQuestionToRemove = challengeQuestionDao.findChallengeQuestions(emailAddress).get(toRemove);
        challengeQuestionDao.removeChallengeQuestion(challengeQuestionToRemove);
    }

    @Override
    public boolean challengeQuestionRespondedOk(String expected, String actual) {
        return passwordEncoder.isPasswordValid(expected, actual, null);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    public void resetRemainingChallengeQuestionsAttempts(String mail) {
        challengeQuestionDao.resetRemainingChallengeQuestionsAttempts(mail);
    }

    @Override
    @Transactional(rollbackFor = {BusinessException.class})
    public void consumeRemainingChallengeQuestionsAttempt(String mail) {
        challengeQuestionDao.consumeRemainingChallengeQuestionsAttempt(mail);
    }

    @Override
    public List<ChallengeQuestion> findDoableChallengeQuestions(String mail) {
        int databaseRemaining = challengeQuestionDao.obtainRemainingChallengeQuestionsAttempts(mail);
        if (databaseRemaining == 0) {
            return emptyList();
        }

        List<ChallengeQuestion> allChallengeQuestions = findChallengeQuestions(mail);
        if (allChallengeQuestions.isEmpty()) {
            return emptyList();
        }

        shuffle(allChallengeQuestions);
        return allChallengeQuestions.subList(0, Math.min(allChallengeQuestions.size(), databaseRemaining));
    }

    @Override
    public String getCurrentUsersUsername() throws UserNotLoggedException {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal == null) {
            throw new UserNotLoggedException();
        }
        return ((InetOrgPerson)principal).getUsername();
    }

    public List<Waybill> findPendingWaybillsFromCurrentUser() throws PodNotFoundException {
        List<PodBranch> podBranchesFromUser = getPodBranchesFromCurrentUser();
        if (podBranchesFromUser.isEmpty()) {
            return newArrayList();
        }

        return waybillDao.findWaybillsByDestinationsAndStates(podBranchesFromUser,
                newArrayList(WaybillStatusEnum.RECEIVED, WaybillStatusEnum.CONFIRMED));
    }

}