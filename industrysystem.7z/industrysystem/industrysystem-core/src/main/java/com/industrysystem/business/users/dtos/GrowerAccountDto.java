package com.industrysystem.business.users.dtos;

/**
 * Created with IntelliJ IDEA.
 * User: JFVERO
 * Date: 20/12/13
 * Time: 12:34
 */
public class GrowerAccountDto {

    private String accountNumber;
    private String documentTypeCode;
    private String documentNumber;
    private String name;
    private String traitOwnerCode;
    private String cropCode;
    private String technologyCode;

    public GrowerAccountDto(String accountNumber,
                            String documentTypeCode,
                            String documentNumber,
                            String name,
                            String traitOwnerCode,
                            String cropCode,
                            String technologyCode) {

        this.accountNumber = accountNumber;
        this.documentTypeCode = documentTypeCode;
        this.documentNumber = documentNumber;
        this.name = name;
        this.traitOwnerCode = traitOwnerCode;
        this.cropCode = cropCode;
        this.technologyCode = technologyCode;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getDocumentTypeCode() {
        return documentTypeCode;
    }

    public void setDocumentTypeCode(String documentTypeCode) {
        this.documentTypeCode = documentTypeCode;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getTraitOwnerCode() {
        return traitOwnerCode;
    }

    public void setTraitOwnerCode(String traitOwnerCode) {
        this.traitOwnerCode = traitOwnerCode;
    }

    public String getCropCode() {
        return cropCode;
    }

    public void setCropCode(String cropCode) {
        this.cropCode = cropCode;
    }

    public String getTechnologyCode() {
        return technologyCode;
    }

    public void setTechnologyCode(String technologyCode) {
        this.technologyCode = technologyCode;
    }

}