package com.industrysystem.business.validators;

import com.industrysystem.exceptions.InvalidDocumentNumberException;
import org.springframework.stereotype.Component;

/**
 * User: PPERA
 * Date: 03/10/13
 * Time: 10:00
 */
@Component
public abstract class DocumentValidator {

    public abstract void validate(String documentType, String documentNumber) throws InvalidDocumentNumberException;

}
