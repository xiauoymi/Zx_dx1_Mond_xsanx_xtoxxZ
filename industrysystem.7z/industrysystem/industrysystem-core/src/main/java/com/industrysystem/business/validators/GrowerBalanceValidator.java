package com.industrysystem.business.validators;

import com.industrysystem.business.dtos.GrowerBalanceOperationDto;
import com.industrysystem.business.dtos.TransactionDto;
import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.GrowerAccountUpdateException;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.apache.commons.lang.StringUtils.isBlank;

/**
 * User: LSCHW1
 */
@Component
public class GrowerBalanceValidator {

    public void validategrowerBalanceOperationItems( List<GrowerBalanceOperationDto> growerBalanceOperationItemsDto)
            throws GrowerAccountUpdateException{
       if (growerBalanceOperationItemsDto.isEmpty()) {
           throw new GrowerAccountUpdateException(new BusinessError(BusinessError.GROWER_BALANACE_ITEMS_EMPTY,
                   "item are mandatory inside the tag growerBalanceOperationItems"));
       }
    }

    public void validateTransaction(TransactionDto transactionDto) throws GrowerAccountUpdateException {
        if (isBlank(transactionDto.getSource())) {
            throw new GrowerAccountUpdateException(new BusinessError(BusinessError.TRANSACTION_SOURCE_EMPTY, "Source can not be empty"));
        }

        if (transactionDto.getRemark() != null && transactionDto.getRemark().length() > 255) {
            throw new GrowerAccountUpdateException(new BusinessError(BusinessError.TRANSACTION_REMARK_INVALID, "Remark can not be greater than 255 chars"));
        }

        if (transactionDto.getSourceOrderNumber() == null) {
            throw new GrowerAccountUpdateException(new BusinessError(BusinessError.TRANSACTION_SOURCE_ORDER_NUMBER_EMPTY,
                    "Source Order Number can not be empty"));
        }

        if (isBlank(transactionDto.getType())) {
            throw new GrowerAccountUpdateException(new BusinessError(BusinessError.TRANSACTION_TYPE_EMPTY, "Transaction Type can not be empty"));
        }

        if (isBlank(transactionDto.getWaybillNumber())) {
            throw new GrowerAccountUpdateException(new BusinessError(BusinessError.WAYBILL_NUMBER_EMPTY, "Waybill Number can not be empty"));
        }
    }

    public void validateGrowerBalanceOperation(GrowerBalanceOperationDto item) throws GrowerAccountUpdateException {
        if (isBlank(item.getAccountNumber())) {
            throw new GrowerAccountUpdateException(new BusinessError(BusinessError.ACCOUNT_GROWER_EMPTY, "Grower Account can not be empty"));
        }

        if (isBlank(item.getCampaignCode())) {
            throw new GrowerAccountUpdateException(new BusinessError(BusinessError.CAMPAIGN_EMPTY, "Campaign can not be empty"));
        }

        if (item.getBalanceType() == null) {
            throw new GrowerAccountUpdateException(new BusinessError(BusinessError.BALANCE_TYPE_EMPTY, "Balance Type can not be empty"));
        }
    }

}