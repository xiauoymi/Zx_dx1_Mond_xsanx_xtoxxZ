package com.industrysystem.business.validators;

import com.industrysystem.business.dtos.StakeholdersDto;
import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.InvalidDocumentNumberException;
import com.industrysystem.exceptions.StoreTestResultException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import static org.apache.commons.lang.StringUtils.upperCase;

/**
 * User: PMIRIB
 * Date: 03/12/13
 */
@Component
public class StoreTestResultValidator {

    @Autowired
    private DocumentValidator documentValidator;

    public void validateStakeholdersForPositiveTestResult(StakeholdersDto stakeholders) throws StoreTestResultException {
        // required values : holder.
        // optional values : commercialSender.
        validateHolder(stakeholders);

        if (stakeholders.hasCommercialSender()) {
            validateCommercialSender(stakeholders);
        }
    }

    public void validateStakeholdersForNegativeTestResult(StakeholdersDto stakeholders) throws StoreTestResultException {
        // Neither the holder nor the commercial sender should be sent.
        if (stakeholders.hasHolder()) {
            throw new StoreTestResultException(new BusinessError(BusinessError.INVALID_HOLDER,
                    "The holder should not be sent with negative test results"));
        }
        if (stakeholders.hasCommercialSender()) {
            throw new StoreTestResultException(new BusinessError(BusinessError.INVALID_COMMERCIAL_SENDER,
                    "The commercial sender should not be sent with negative test results"));
        }
    }

    private void validateHolder(StakeholdersDto stakeholders) throws StoreTestResultException {
        // The name must be informed for a new grower (not POD or participant Grower).
        if (!stakeholders.hasHolderName()) {
            throw new StoreTestResultException(new BusinessError(BusinessError.INVALID_HOLDER_NAME, "The holder name is required"));
        }

        validateDocument(stakeholders.getHolderDocumentType(), stakeholders.getHolderDocumentNumber(),
                new BusinessError(BusinessError.INVALID_HOLDER_DOCUMENT, "The holder document is invalid"));
    }

    private void validateCommercialSender(StakeholdersDto stakeholders) throws StoreTestResultException {
        if (!stakeholders.isCommercialSenderComplete()) {
            String msg = "The commercial sender is not complete, name, document type and document number must be sent.";
            throw new StoreTestResultException(new BusinessError(BusinessError.INVALID_COMMERCIAL_SENDER, msg));
        }
        validateDocument(stakeholders.getCommercialSenderDocumentType(), stakeholders.getCommercialSenderDocumentNumber(),
                new BusinessError(BusinessError.INVALID_COMMERCIAL_SENDER_DOCUMENT, "The commercial sender document is invalid"));
    }

    private void validateDocument(String documentType, String documentNumber, BusinessError businessError) throws StoreTestResultException {
        try {
            documentValidator.validate(upperCase(documentType), documentNumber);
        } catch (InvalidDocumentNumberException e) {
            throw new StoreTestResultException(businessError);
        }
    }

}