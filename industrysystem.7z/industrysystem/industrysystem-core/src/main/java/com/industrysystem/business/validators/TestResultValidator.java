package com.industrysystem.business.validators;

import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.InvalidDocumentNumberException;
import com.industrysystem.exceptions.TestResultRegistrationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.util.List;

import static org.apache.commons.lang.StringUtils.isNotEmpty;

/**
 * User: JPNORV
 * Date: 20/01/14
 */

@Component
@Scope("prototype")
public class TestResultValidator {

    public static final String CUALITATIVO = "CUALITATIVO";
    public static final String CUANTITATIVO = "CUANTITATIVO";
    public static final String POSITIVO = "POSITIVO";
    public static final String NEGATIVO = "NEGATIVO";

    @Autowired
    private DocumentValidator documentValidator;

    protected List<BusinessError> errors;

    public void validate(String holderDocument, String holderDocumentType, String commercialSenderDocument,
            String commercialSenderDocumentType) throws TestResultRegistrationException {
        validateDocument(holderDocument, holderDocumentType, new BusinessError(BusinessError.INVALID_HOLDER_DOCUMENT, "The holder document is invalid"));
        validateDocument(commercialSenderDocument, commercialSenderDocumentType, new BusinessError(BusinessError.INVALID_COMMERCIAL_SENDER_DOCUMENT, "The commercial sender document is invalid"));
    }

    protected void throwErrorsIfExists() throws TestResultRegistrationException {
        if (!errors.isEmpty()) {
            throw new TestResultRegistrationException(errors);
        }
    }

    public List<BusinessError> getErrors() {
        return errors;
    }

    protected void validateDocument(String documentNumber, String documentType, BusinessError error) {
        try {
            if (isNotEmpty(documentNumber)) {
                documentValidator.validate(documentType, documentNumber);
            }
        } catch (InvalidDocumentNumberException e) {
            errors.add(error);
        }
    }

}