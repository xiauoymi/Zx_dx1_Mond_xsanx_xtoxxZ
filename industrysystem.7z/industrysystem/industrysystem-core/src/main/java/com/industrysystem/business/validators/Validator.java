package com.industrysystem.business.validators;

import com.google.common.base.Predicate;
import com.industrysystem.business.dtos.QualitativeTestResultDto;
import com.industrysystem.business.dtos.QuantitativeTestResultDto;
import com.industrysystem.business.dtos.TestResultDto;
import com.industrysystem.entities.CuantitativeTestRequest;
import com.industrysystem.entities.QualitativeTestRequest;
import com.industrysystem.entities.TestRequest;
import com.industrysystem.entities.Waybill;
import com.industrysystem.exceptions.*;
import com.industrysystem.persistence.daos.CropDao;
import com.industrysystem.persistence.daos.TechnologyDao;
import com.industrysystem.persistence.daos.TraitOwnerDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.persistence.NoResultException;
import java.math.BigDecimal;
import java.util.*;

import static com.google.common.collect.Iterables.any;
import static org.apache.commons.lang.StringUtils.join;
import static org.apache.commons.lang.StringUtils.upperCase;

/**
 * User: PPERA
 * Date: 30/10/13
 * Time: 10:20
 */
@Component
public class Validator {

    private static final String RESULT_ALREADY_STORED = "A result for this sample code already exists";

    @Autowired
    private TechnologyDao technologyDao;

    @Autowired
    private TraitOwnerDao traitOwnerDao;

    @Autowired
    private CropDao cropDao;

    public static final boolean isZeroOrNaturalNumber(String value) {
        return value != null && value.matches("[0-9]+");
    }

    public static final boolean isZeroOrNaturalNumber(String value, int maxLength) {
        return isZeroOrNaturalNumber(value) && value.length() <= maxLength;
    }

    public static final boolean isNaturalNumber(String value) {
        return isZeroOrNaturalNumber(value) && !value.matches("0+");
    }

    public void validateStoreWeight(Long waybillNumber, Integer weight, Date unloadTime) throws StoreWeightException {
        if (waybillNumber == null) {
            throw new StoreWeightException(new BusinessError(BusinessError.WAYBILL_NOT_FOUND, "Waybill number cannot be null"));
        }

        if (weight == null)  {
            throw new StoreWeightException(new BusinessError(BusinessError.WEIGHT_INVALID, "Weight cannot be null"));
        }

        if (weight == 0) {
            throw new StoreWeightException(new BusinessError(BusinessError.WEIGHT_INVALID, "Weight must be a number greater than zero"));
        }

        if (weight < 0) {
            throw new StoreWeightException(new BusinessError(BusinessError.WEIGHT_INVALID, "Weight must be positive"));
        }

        if (unloadTime == null) {
            throw new StoreWeightException(new BusinessError(BusinessError.INVALID_UNLOAD_TIME, "Unload time cannot be null"));
        }
    }

    public <T extends TestResultDto> void validateTechnologyCodes(List<T> testResults) throws StoreTestResultException {
        List<String> invalidCodes = new ArrayList<String>();
        for (TestResultDto testResult: testResults) {
            try {
                technologyDao.findByCode(upperCase(testResult.getTechnologyCode()));
            } catch (TechnologyNotFoundException e) {
                invalidCodes.add(testResult.getTechnologyCode());
            }
        }
        if (!invalidCodes.isEmpty()) {
            String msg = "The following Technology codes are invalid: " + join(invalidCodes, ", ");
            throw new StoreTestResultException(new BusinessError(BusinessError.TECHNOLOGY_NOT_FOUND, msg));
        }
    }

    public <T extends TestResultDto> void validateCropCodes(List<T> testResults) throws StoreTestResultException {
        List<String> invalidCodes = new ArrayList<String>();
        for (TestResultDto testResult: testResults) {
            try {
                cropDao.findCropBy(upperCase(testResult.getCropCode()));
            } catch (CropNotFoundException ex) {
                invalidCodes.add(testResult.getCropCode());
            }
        }
        if (!invalidCodes.isEmpty()) {
            String msg = "The following Crop codes are invalid: " + join(invalidCodes, ", ");
            throw new StoreTestResultException(new BusinessError(BusinessError.CROP_NOT_FOUND, msg));
        }
    }

    public <T extends TestResultDto> void validateTraitOwnerCodes(List<T> testResults) throws StoreTestResultException {
        List<String> invalidCodes = new ArrayList<String>();
        for (TestResultDto testResult: testResults) {
            try {
                traitOwnerDao.findByCode(upperCase(testResult.getTraitOwnerCode()));
            } catch (NoResultException ex) {
                invalidCodes.add(testResult.getTraitOwnerCode());
            }
        }
        if (!invalidCodes.isEmpty()) {
            String msg = "The following Trait Owner codes are invalid: " + join(invalidCodes, ", ");
            throw new StoreTestResultException(new BusinessError(BusinessError.TRAIT_OWNER_NOT_FOUND, msg));
        }
    }

    public void validateIfAllResultDataHaveRequest(List<QualitativeTestResultDto> testResultDataList,
            List<QualitativeTestRequest> testRequests) throws StoreTestResultException {
        for (QualitativeTestResultDto testResultData: testResultDataList) {
            validateIfResultHaveRequestInList(testResultData, testRequests);
        }
    }

    public void validateNumberOfTests(List<QualitativeTestResultDto> testResults, List<? extends TestRequest> testRequests)
            throws StoreTestResultException {
        if (testResults.size() != testRequests.size()) {
            throw new StoreTestResultException(new BusinessError(BusinessError.INVALID_NUMBER_OF_QUALITATIVE_TESTS_RESULTS,
                    "There are more or less qualitative test results than expected for the waybill's load detail's sample code {Sample code}."));
        }
    }

    /**
     * All requests must be qualitative.
     */
    public void validateThatAreAllQualitative(List<? extends TestRequest> testRequests) throws StoreTestResultException {
        for (TestRequest testRequest : testRequests) {
            if (!(testRequest instanceof QualitativeTestRequest)) {
                throw new StoreTestResultException(new BusinessError(BusinessError.QUALITATIVE_TEST_RESULT_NOT_EXPECTED,
                        "The tests requests are not consistent"));
            }
        }
    }

    /**
     * For quantitative results there must be only 1 quantitative request (and no qualitative requests) (precondition).
     * There must be 1 and only 1 quantitative test request.
     */
    public void validateThatQuantitativeResultIsExpected(List<? extends TestRequest> testRequests) throws StoreTestResultException {
        if (testRequests.size() != 1 || !(testRequests.get(0) instanceof CuantitativeTestRequest)) {
            throw new StoreTestResultException(new BusinessError(BusinessError.QUANTITATIVE_TEST_RESULT_NOT_EXPECTED,
                    "The tests requests are not consistent"));
        }
    }

    /**
     * Checks if the Qualitative TestResultData have a TestRequest associated in the list.
     * If it does not have throws an Exception.
     */
    public void validateIfResultHaveRequestInList(final QualitativeTestResultDto testResultData,
            List<QualitativeTestRequest> testRequests) throws StoreTestResultException {
        boolean haveRequest = any(testRequests, new Predicate<QualitativeTestRequest>() {
            @Override
            public boolean apply(QualitativeTestRequest testRequest) {
                return testRequest.isResultDataForRequest(testResultData);
            }
        });

        if (!haveRequest) {
            throw new StoreTestResultException(new BusinessError(BusinessError.INVALID_NUMBER_OF_QUALITATIVE_TESTS_RESULTS,
                    "The test result has no associated test request"));
        }
    }

    /**
     * Check if the result was already sent for the request.
     * The the result should be sent complete in one shipping (confirm that).
     */
    public void validateIfRequestsAlreadyHaveResponse(List<? extends TestRequest> testRequests) throws StoreTestResultException {
        for (TestRequest testRequest: testRequests) {
            if (testRequest.isCompleted()) {
                throw new StoreTestResultException(new BusinessError(BusinessError.RESULT_ALREADY_STORED, RESULT_ALREADY_STORED));
            }
        }
    }

    public void validateIfHaveLoadDetail(Waybill waybill) throws WaybillWithoutLoadDetailException {
        if (waybill.getLoadDetails().isEmpty()) {
            throw new WaybillWithoutLoadDetailException();
        }
    }

    public void validateIfSampleRequired(Waybill waybill) throws SampleDeterminationServiceNotCalledException, SampleNotRequiredException {
        if (!waybill.wasSampleServiceCalled()) {
            throw new SampleDeterminationServiceNotCalledException();
        }
        if (!waybill.isSampleRequired()) {
            throw new SampleNotRequiredException();
        }
    }

    public void validateCancelledStatus(Waybill waybill) throws WaybillCancelledException {
        if (waybill.isCancelled()) {
            throw new WaybillCancelledException(waybill.getWaybillNumber());
        }
    }


    public void validateWaybillStatus(Waybill waybill) throws WaybillCancelledException {
        if (waybill.isCancelled()) {
            throw new WaybillCancelledException(waybill.getWaybillNumber());
        }
    }

    public <T extends TestResultDto> void validateNoDuplicateResults(List<T> testResults) throws StoreTestResultException {
        // Check that the combination of cropCode - traitOwnerCode - technologyCode are not duplicated in the list.
        Set<String> technologyCodes = new HashSet<String>();
        for (TestResultDto testResultData: testResults) {
            String key = upperCase(testResultData.getCropCode() + "-" + testResultData.getTraitOwnerCode() + "-" + testResultData.getTechnologyCode());
            if (technologyCodes.contains(key)) {
                String message = "The technology is duplicated: " + key;
                throw new StoreTestResultException(new BusinessError(BusinessError.TECHNOLOGY_DUPLICATED, message));
            } else {
                technologyCodes.add(key);
            }
        }
    }

    public void validateResultsSum(List<QuantitativeTestResultDto> testResults) throws StoreTestResultException {
        BigDecimal total = BigDecimal.ZERO;
        for (QuantitativeTestResultDto testResult: testResults) {
            if (testResult.getPercentage() == null || testResult.getPercentage().signum() <= 0) {
                throw new StoreTestResultException(new BusinessError(BusinessError.QUANTITATIVE_RESULT_PERCENTAGE_INVALID,
                        "Quantitative test results must have percentage greater than 0."));
            }
            total = total.add(testResult.getPercentage());
        }
        if (total.compareTo(BigDecimal.valueOf(100L)) > 0) {
            throw new StoreTestResultException(new BusinessError(BusinessError.TOTAL_PERCENTAGE_GREATER_THAN_100,
                    "It was provided quantitative results whose percentages together exceed 100%."));
        }
    }

}