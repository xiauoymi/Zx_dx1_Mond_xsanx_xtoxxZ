package com.industrysystem.business.validators;

import com.google.common.base.Predicate;
import com.google.common.primitives.Ints;
import com.industrysystem.business.CropService;
import com.industrysystem.business.LaboratoryService;
import com.industrysystem.business.LocationService;
import com.industrysystem.business.ProductsService;
import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.WagonDetailDTO;
import com.industrysystem.business.dtos.WaybillDto;
import com.industrysystem.entities.LoadDetail;
import com.industrysystem.entities.TransportType;
import com.industrysystem.entities.WagonLoadDetail;
import com.industrysystem.entities.Waybill;
import com.industrysystem.exceptions.*;
import com.industrysystem.guava.functions.LoadDetailDTOToLoadIdentifierFunction;
import com.industrysystem.persistence.daos.LoadDetailDao;
import com.industrysystem.persistence.daos.WaybillDao;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.google.common.collect.FluentIterable.from;
import static com.google.common.collect.Iterables.filter;
import static com.google.common.collect.Iterables.getOnlyElement;
import static com.industrysystem.business.validators.Validator.isZeroOrNaturalNumber;
import static org.apache.commons.lang.StringUtils.isEmpty;
import static org.apache.commons.lang.StringUtils.isNotEmpty;

/**
 * User: JPNORV
 * Date: 29/11/13
 */
@Component
@Scope("prototype")
public abstract class WaybillValidator {

    protected static final String WAYBILL_NUMBER_IS_ALREADY_REGISTERED = "The Waybill number is already registered";
    protected static final String INVALID_WAYBILL_NUMBER = "Invalid Waybill number";
    private static final Predicate<LoadDetailDTO> WAGON_DETAIL_FILTER = new Predicate<LoadDetailDTO>() {
        @Override
        public boolean apply(LoadDetailDTO input) {
            return input instanceof WagonDetailDTO;
        }
    };

    @Autowired
    private DocumentValidator documentValidator;

    @Autowired
    private CropService cropService;

    @Autowired
    private LocationService locationService;

    @Autowired
    private ProductsService productsService;

    @Autowired
    private LaboratoryService laboratoryService;

    @Autowired
    private LoadDetailDao loadDetailDao;

    @Autowired
    private WaybillDao waybillDao;

    protected List<BusinessError> errors = new ArrayList<BusinessError>();

    public static final boolean isWaybillNumber(String waybillNumber) {
        return isZeroOrNaturalNumber(waybillNumber, Waybill.WAYBILL_NUMBER_LENGTH);
    }

    public static final boolean isWagonNumber(String wagonNumber) {
        return wagonNumber != null && wagonNumber.matches("[a-zA-Z0-9]{1," + WagonLoadDetail.WAGON_NUMBER_LENGTH + "}")
                && !wagonNumber.matches("[a-zA-Z]+");
    }

    public void validate(WaybillDto waybillDto) throws WaybillRegistrationException, WaybillNotFoundException {
        validateWagonDetails(waybillDto.getLoadDetails());
        validateDocument(waybillDto.getHolderDocument(), waybillDto.getHolderDocumentType(),
                new BusinessError(BusinessError.INVALID_HOLDER_DOCUMENT, "The holder document is invalid"));
        validateDocument(waybillDto.getAddresseeDocument(), waybillDto.getAddresseeDocumentType(),
                new BusinessError(BusinessError.INVALID_ADDRESSEE_DOCUMENT, "The addressee document is invalid"));
        validateDocument(waybillDto.getDestinationDocument(), waybillDto.getDestinationDocumentType(),
                new BusinessError(BusinessError.INVALID_DESTINATION_DOCUMENT, "The destination document is invalid"));
        validateDocument(waybillDto.getCommercialSenderDocument(), waybillDto.getCommercialSenderDocumentType(),
                new BusinessError(BusinessError.INVALID_COMMERCIAL_SENDER_DOCUMENT, "The commercial sender document is invalid"));

        throwErrorsIfExists();
    }

    protected void throwErrorsIfExists() throws WaybillRegistrationException {
        if (!errors.isEmpty()) {
            throw new WaybillRegistrationException(errors);
        }
    }

    public List<BusinessError> getErrors() {
        return errors;
    }

    void validateWagonDetails(List<LoadDetailDTO> loadDetails) {
        if (loadDetails == null) {
            return;
        }

        Set<String> sampleCodes = new HashSet<String>();
        for (LoadDetailDTO loadDetail: filter(loadDetails, WAGON_DETAIL_FILTER)) {
            WagonDetailDTO wagonDetail = (WagonDetailDTO)loadDetail;

            String wagonNumber = wagonDetail.getWagonNumber();
            if (wagonNumber != null && !isWagonNumber(wagonNumber)) {
                errors.add(new BusinessError(BusinessError.INVALID_WAGON_NUMBER, "The wagon number is invalid"));
            }

            if (NumberUtils.toInt(wagonDetail.getWagonsQty()) <= 0 || NumberUtils.toInt(wagonDetail.getWagonsQty()) >50) {
                errors.add(new BusinessError(BusinessError.INVALID_WAGON_QTY,
                        "The wagons quantity field should be greater than 0 and lower than 50 inclusive"));
            }

            String sampleCode = wagonDetail.getSampleCode();
            if (sampleCode != null) {
                if (sampleCodes.contains(sampleCode)) {
                    errors.add(new BusinessError(BusinessError.SAMPLE_CODE_DUPLICATED, "The sample code cannot be repeated"));
                } else {
                    sampleCodes.add(sampleCode);
                }
            }
        }
    }

    public void validateTransportType(final String transportType) {
        if (!TransportType.isValidTransportType(transportType)) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_TRANSPORT_TYPE, "error.invalid.transport", "waybillType", transportType));
        }
    }

    public void validateCropCode(String cropCode) {
        try {
            this.cropService.findCropByCode(cropCode);
        } catch (CropNotFoundException e) {
            errors.add(new FieldBusinessError(BusinessError.CROP_NOT_FOUND, "error.invalid.crop", "cropCode", cropCode));
        }
    }

    protected void validateDocument(String documentNumber, String documentType, BusinessError error) {
        try {
            if (isNotEmpty(documentNumber)) {
                documentValidator.validate(documentType, documentNumber);
            }
        } catch (InvalidDocumentNumberException e) {
            errors.add(error);
        }
    }

    public void validateCtg(String loadIdentifier) {
        if (isEmpty(loadIdentifier) || Ints.tryParse(loadIdentifier) == null || Integer.valueOf(loadIdentifier) <= 0) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_CTG_NUMBER, "error.invalid.truck.identifier",
                    "loadIdentifier", loadIdentifier));
        }
    }

    public void validateWagonNumber(String loadIdentifier, WaybillDto waybillDto) {
        if (isEmpty(loadIdentifier)) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_WAGON_NUMBER, "error.invalid.wagon.empty",
                    "loadIdentifier", loadIdentifier));
        }

        try {
            Waybill waybill = waybillDao.findWaybillByWaybillNumber(waybillDto.getWaybillNumberAsLong());
            if (waybill != null) {
                validateWagonQtyAndWagonNumber(loadIdentifier, waybillDto, waybill);
            }
        } catch (WaybillNotFoundException e) {
            //Do nothing
        }
    }

    private void validateWagonQtyAndWagonNumber(String loadIdentifier, WaybillDto waybillDto, Waybill waybill) {
        List<LoadDetail> wagonLoadDetails = loadDetailDao.findLoadDetailsByWaybill(waybill);
        WagonDetailDTO wagonDetailDTO = (WagonDetailDTO)getOnlyElement(waybillDto.getLoadDetails());
        if (wagonLoadDetails.isEmpty()) {
            errors.add(new FieldBusinessError(BusinessError.LOAD_DETAIL_NOT_FOUND, "error.invalid.load.detail",
                    "loadIdentifier", loadIdentifier));
        } else if(wagonLoadDetails.size() == Integer.valueOf(wagonDetailDTO.getWagonsQty())) {
            errors.add(new FieldBusinessError(BusinessError.WAYBILL_NUMBER_IS_ALREADY_REGISTERED, "error.already.registered.waybill",
                    "loadIdentifier", loadIdentifier));
        }

        for (LoadDetail wagonLoadDetail: wagonLoadDetails) {
            validateWagonNumber(wagonDetailDTO, (WagonLoadDetail)wagonLoadDetail);
        }
        validateWagonsQty(wagonDetailDTO, wagonLoadDetails);
    }

    private void validateWagonNumber(WagonDetailDTO wagonDetailDTO, WagonLoadDetail wagonLoadDetail) {
        if (wagonDetailDTO.getWagonNumber().equalsIgnoreCase(wagonLoadDetail.getWagonNumber())) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_WAGON_NUMBER, "error.wagon.number.exists",
                    "loadIdentifier", wagonDetailDTO.getWagonNumber()));
        }
    }

    public void validateWagonNumbers(WaybillDto waybillDto) {
        Set<String> wagonNumbersSet = from(waybillDto.getLoadDetails()).transform(new LoadDetailDTOToLoadIdentifierFunction()).toImmutableSet();

        if (wagonNumbersSet.size() < waybillDto.getLoadDetails().size()) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_WAGON_NUMBER, "error.wagon.number.exists",
                    "loadIdentifier", wagonNumbersSet));
        }

        for (final LoadDetailDTO wagonDetailDTO: waybillDto.getLoadDetails()) {
            if (isEmpty(wagonDetailDTO.getLoadIdentifier())) {
                errors.add(new FieldBusinessError(BusinessError.INVALID_WAGON_NUMBER, "error.invalid.wagon.identifier",
                        "loadIdentifier", wagonDetailDTO.getLoadIdentifier()));
            }
        }
    }

    protected void validateWagonsQty(WagonDetailDTO wagonDetailDTO, List<LoadDetail> wagonLoadDetails) {
        if (Integer.parseInt(wagonDetailDTO.getWagonsQty()) <= wagonLoadDetails.size()) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_WAGON_QTY, "error.invalid.wagon.quantity",
                    "wagonsQty", wagonDetailDTO.getWagonsQty()));
        }
    }

    public void validateHolderName(WaybillDto waybillDto) {
        if (isEmpty(waybillDto.getHolderName())) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_HOLDER_NAME, "error.invalid.holder.name.empty",
                    "holderName", waybillDto.getHolderName()));
        }
    }

    public void validateCommercialSenderName(WaybillDto waybillDto) {
        if (waybillDto.getCommercialSenderName() == null || waybillDto.getCommercialSenderName().isEmpty()) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_COMMERCIAL_SENDER_NAME,
                    "error.invalid.commercial.sender.name.empty", "commercialSenderName", waybillDto.getCommercialSenderName()));
        }
    }

    public void validateOriginLocation(Long originLocation) {
        try {
            locationService.findLocationById(originLocation);
        } catch (LocationNotFoundException e) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_ORIGIN_LOCATION, "error.invalid.origin.location.code=",
                    "originLocation", originLocation));
        }
    }

    public void validateDestinationLocation(Long destinationLocation) {
        try {
            locationService.findLocationById(destinationLocation);
        } catch (LocationNotFoundException e) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_DESTINATION_LOCATION, "error.invalid.destination.location.code",
                    "destinationLocation", destinationLocation));
        }
    }

    public void validateWagonQty(String wagonQty) {
        if (isEmpty(wagonQty) || Ints.tryParse(wagonQty) == null || Integer.valueOf(wagonQty) <= 0) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_WAGON_QTY, "error.invalid.wagon.quantity", "wagonsQty", wagonQty));
        }
    }

    public void validateWeight(String weight) {
        if (!isZeroOrNaturalNumber(weight)) {
            errors.add(new FieldBusinessError(BusinessError.WEIGHT_INVALID, "error.invalid.weight", "weight", weight));
        }
    }

    public void validateTechnologyDeclared(String technology) {
        try {
            productsService.findByCode(technology);
        } catch (TechnologyNotFoundException e) {
            errors.add(new FieldBusinessError(BusinessError.INVALID_TECHNOLOGY, "error.invalid.technology.code",
                    "declaredTechnology", technology));
        }
    }

    public void validateQualitativeLabCode(String laboratoryCodeQualitative) {
        try {
            laboratoryService.findLaboratoryByLabCode(laboratoryCodeQualitative);
        } catch (LaboratoryNotFoundException e) {
            errors.add(new FieldBusinessError(BusinessError.LABORATORY_NOT_FOUND, "error.invalid.qualitative.lab",
                    "qualitativeLabCode", laboratoryCodeQualitative));
        }
    }

    public void validateQuantitativeLabCode(String laboratoryCodeQuantitative) {
        try {
            laboratoryService.findLaboratoryByLabCode(laboratoryCodeQuantitative);
        } catch (LaboratoryNotFoundException e) {
            errors.add(new FieldBusinessError(BusinessError.LABORATORY_NOT_FOUND, "error.invalid.quantitative.lab",
                    "QuantitativeLabCode", laboratoryCodeQuantitative));
        }
    }

    public void validateUnloadDate(String unloadingDate) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date dateOfUnload;
        Date now = new Date();
        if (isNotEmpty(unloadingDate) && unloadingDate.trim().length() == dateFormat.toPattern().length()) {
            try {
                dateOfUnload = dateFormat.parse(unloadingDate.trim());
                if (dateOfUnload.after(now)) {
                    errors.add(new FieldBusinessError(BusinessError.INVALID_UNLOADING_DATE, "error.invalid.unload.date",
                            "unloadingDate", unloadingDate));
                }
            } catch (ParseException e) {
                errors.add(new FieldBusinessError(BusinessError.INVALID_UNLOADING_DATE, "error.invalid.unload.date",
                        "unloadingDate", unloadingDate));
            }
        } else {
            errors.add(new FieldBusinessError(BusinessError.INVALID_UNLOADING_DATE, "error.invalid.unload.date",
                    "unloadingDate", unloadingDate));
        }
    }

    protected void validateDeclaretedTechnology(WaybillDto waybillDto, LoadDetailDTO loadDetailDTO) {
        if (isEmpty(loadDetailDTO.getDeclaredTechnology())) {
            validateQualitativeLabCode(waybillDto.getQualitativeLabCode());
            validateQuantitativeLabCode(waybillDto.getQuantitativeLabCode());
        } else {
            validateTechnologyDeclared(loadDetailDTO.getDeclaredTechnology());
        }
    }

}