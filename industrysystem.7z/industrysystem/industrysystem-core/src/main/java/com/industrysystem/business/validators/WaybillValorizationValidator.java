package com.industrysystem.business.validators;

import com.industrysystem.business.dtos.WaybillValorizationItemDto;
import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.WaybillValorizationException;
import org.springframework.stereotype.Component;

import static org.apache.commons.lang.StringUtils.isBlank;

/**
 * User: LSCHW1
 */
@Component
public class WaybillValorizationValidator {

    //TODO extract to waybillValidator (Throw BusinessException)
    public void validateWaybillNumber(Long waybillNumber) throws WaybillValorizationException {
        if (waybillNumber == null) {
            throw new WaybillValorizationException(new BusinessError(BusinessError.WAYBILL_NUMBER_BLANK_OR_ABSENT, "Waybill number cannot be null"));
        }
    }

    public void validate(WaybillValorizationItemDto itemDto) throws WaybillValorizationException {
        if (isBlank(itemDto.getCropCode())) {
            throw new WaybillValorizationException(new BusinessError(BusinessError.CROP_NOT_FOUND, "Crop code is required."));
        }

        if (isBlank(itemDto.getTechnologyCode())) {
            throw new WaybillValorizationException(new BusinessError(BusinessError.TECHNOLOGY_NOT_FOUND, "Waybill number cannot be null"));
        }

        if (itemDto.getQuantity() < 0) {
            throw new WaybillValorizationException(new BusinessError(BusinessError.WEIGHT_INVALID, "Quantity is invalid"));
        }
    }

}