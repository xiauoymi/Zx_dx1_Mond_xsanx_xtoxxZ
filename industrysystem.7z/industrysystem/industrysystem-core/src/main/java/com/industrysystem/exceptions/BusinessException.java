package com.industrysystem.exceptions;

import org.springframework.security.access.AccessDeniedException;

import java.util.List;

import static com.google.common.collect.Lists.newArrayList;

/**
 * User: PPERA
 * Date: 22/10/13
 * Time: 17:43
 */
public class BusinessException extends Exception {

    private List<BusinessError> errors;

    protected BusinessException(BusinessError error) {
        super(error.getDescription());
        setErrors(newArrayList(error));
    }

    public BusinessException(List<BusinessError> errors) {
        setErrors(errors);
    }

    public BusinessException(Throwable th) {
        super(th);
        if (th instanceof AccessDeniedException) {
            setErrors(newArrayList(new BusinessError(BusinessError.ACCESS_DENIED, th.getMessage())));
        } else if (th instanceof BusinessException) {
            setErrors(((BusinessException)th).getErrors());
        } else {
            setErrors(newArrayList(new BusinessError(BusinessError.GENERAL_ERROR, BusinessError.GENERAL_ERROR_MESSAGE)));
        }
    }

    public BusinessException(Exception e, BusinessError error) {
        super(error.getDescription(), e);
        setErrors(newArrayList(error));
    }

    public List<BusinessError> getErrors() {
        return errors;
    }

    public void setErrors(List<BusinessError> errors) {
        this.errors = errors;
    }

}