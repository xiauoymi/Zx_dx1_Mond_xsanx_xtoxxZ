package com.industrysystem.exceptions;

/**
 * User: PPERA
 * Date: 23/10/13
 * Time: 12:14
 */
public class CampaignNotFoundException extends BusinessException {
    public CampaignNotFoundException() {
        super(new BusinessError(BusinessError.CAMPAIGN_NOT_FOUND, "The field Harvest value entered is invalid"));
    }
}
