package com.industrysystem.exceptions;

/**
 * User: PPERA
 * Date: 23/10/13
 * Time: 17:07
 */
public class CropNotFoundException extends BusinessException {
    public CropNotFoundException() {
        super(new BusinessError(BusinessError.CROP_NOT_FOUND, "No crop matching the code was found"));
    }
}
