package com.industrysystem.exceptions;


@SuppressWarnings("serial")
    /**
     * Thrown when search in ldap is not what was expected
     * @author dfoge
     *
     */
	public class DirectorySearchResultsException extends Exception{

    	private int count;

		public int getCount() {
			return count;
		}

		public DirectorySearchResultsException(int i) {
            this.count = i;
		}
	}