package com.industrysystem.exceptions;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 27/11/13
 */
public class FieldBusinessError extends BusinessError{

    private String fieldName;
    private Object fieldValue;

    public FieldBusinessError(String code, String description, String fieldName, Object fieldValue) {
        super(code, description);
        this.fieldName = fieldName;
        this.fieldValue = fieldValue;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public Object getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(Object fieldValue) {
        this.fieldValue = fieldValue;
    }
}
