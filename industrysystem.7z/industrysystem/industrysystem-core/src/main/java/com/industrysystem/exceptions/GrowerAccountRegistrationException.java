package com.industrysystem.exceptions;

import com.industrysystem.business.users.dtos.GrowerAccountDto;

/**
 * User: PPERA
 * Date: 03/10/13
 * Time: 14:32
 */
public class GrowerAccountRegistrationException extends BusinessException {

    private GrowerAccountDto growerAccountDto;

    public GrowerAccountRegistrationException(BusinessException e, GrowerAccountDto growerAccountDto) {
        super(e);
        this.growerAccountDto = growerAccountDto;
    }

    public GrowerAccountRegistrationException(Exception e, GrowerAccountDto growerAccountDto) {
        super(e);
        this.growerAccountDto = growerAccountDto;
    }

    public GrowerAccountDto getGrowerAccountDto() {
        return growerAccountDto;
    }

}