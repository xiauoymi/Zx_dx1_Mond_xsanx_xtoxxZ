package com.industrysystem.exceptions;

/**
 * User: PPERA
 * Date: 09/10/13
 * Time: 10:30
 */
public class GrowerAccountUpdateException extends BusinessException{

    public GrowerAccountUpdateException(BusinessError error) {
        super(error);
    }

    public GrowerAccountUpdateException(BusinessException e) {
        super(e);
    }

    public GrowerAccountUpdateException(Exception e) {
        super(e);
    }
}
