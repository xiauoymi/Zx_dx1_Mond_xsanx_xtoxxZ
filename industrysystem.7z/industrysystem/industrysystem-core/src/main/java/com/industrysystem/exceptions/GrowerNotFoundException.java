package com.industrysystem.exceptions;

@SuppressWarnings("serial")
public class GrowerNotFoundException extends BusinessException {
	
	public GrowerNotFoundException() {
		super(new BusinessError(BusinessError.GROWER_NOT_FOUND, "No grower matching the document number was found"));
	}

}