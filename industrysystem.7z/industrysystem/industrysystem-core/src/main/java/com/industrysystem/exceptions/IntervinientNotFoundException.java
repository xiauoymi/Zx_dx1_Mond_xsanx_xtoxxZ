package com.industrysystem.exceptions;

import com.industrysystem.entities.Document;

/**
 * User: IMDORI
 * Date: 27/01/14
 * Time: 14:51
 */
public class IntervinientNotFoundException extends BusinessException {
    public IntervinientNotFoundException(Document document) {
        super(new BusinessError(BusinessError.INVALID_DOCUMENT, "No match found for document number " + document.getNumber() + " of type " + document.getTypeCode() ));

    }
}
