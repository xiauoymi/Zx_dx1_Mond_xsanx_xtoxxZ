package com.industrysystem.exceptions;

import com.industrysystem.entities.waybill.states.WaybillState;

/**
 * User: LSCHW1
 */
public class InvalidStateTransitionException extends BusinessException {

    public InvalidStateTransitionException(WaybillState stateFrom, WaybillState stateTo) {
        super(new BusinessError(BusinessError.INVALID_STATE_TRANSITION, "Invalid state transition from "+stateFrom.getName().name()+ " to "+stateTo.getName().name()));
    }
}
