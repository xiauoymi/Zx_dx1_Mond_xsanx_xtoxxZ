package com.industrysystem.exceptions;

/**
 * Thrown when an one time token is not found during
 * the password recovery process
 * @author dfoge
 *
 */
@SuppressWarnings("serial")
public class InvalidTokenException extends Exception{

    public InvalidTokenException() {
    }
}
