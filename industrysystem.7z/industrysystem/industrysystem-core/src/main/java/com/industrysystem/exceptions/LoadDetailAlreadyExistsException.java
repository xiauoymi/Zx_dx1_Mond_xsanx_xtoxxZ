package com.industrysystem.exceptions;

public class LoadDetailAlreadyExistsException extends BusinessException {

	private static final long serialVersionUID = -2915211896225161484L;

	public LoadDetailAlreadyExistsException(String msg) {
		super(new BusinessError(BusinessError.LOAD_DETAIL_ALREADY_EXIST, msg));
	}

}