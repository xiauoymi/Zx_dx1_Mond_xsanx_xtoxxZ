package com.industrysystem.exceptions;

import java.text.MessageFormat;

/**
 * User: PMIRIB
 * Date: 08/10/13
 * Time: 13:56
 */
public class LoadDetailNotFoundException extends BusinessException {
    public LoadDetailNotFoundException(String loadIdentifier) {
        super(new BusinessError(BusinessError.LOAD_DETAIL_NOT_FOUND, MessageFormat.format("No load matched the load identifier {0} provided", loadIdentifier)));
    }

    public LoadDetailNotFoundException(String destinationDocumentNumber, String sampleCode) {
        super(new BusinessError(BusinessError.LOAD_DETAIL_NOT_FOUND, MessageFormat.format("No load matched the sample code {0} and the destination document number {1}", sampleCode, destinationDocumentNumber)));
    }

    public LoadDetailNotFoundException(){
        super(new BusinessError(BusinessError.LOAD_DETAIL_NOT_FOUND, "Location not found"));
    }
}
