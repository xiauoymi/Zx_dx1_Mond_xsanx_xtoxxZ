package com.industrysystem.exceptions;

/**
 * User: PPERA
 * Date: 28/10/13
 * Time: 08:55
 */
public class SampleDeterminationException extends BusinessException {
    public SampleDeterminationException(BusinessException e) {
        super(e);
    }

    public SampleDeterminationException(Exception e) {
        super(e);
    }

    public SampleDeterminationException(BusinessError error) {
        super(error);
    }
}
