package com.industrysystem.exceptions;

/**
 * User: PMIRIB
 * Date: 04/10/13
 * Time: 13:19
 */
public class SampleNotRequiredException extends BusinessException {
    public static final String SAMPLE_NOT_REQUIRED_MESSAGE = "The waybill number does not require a sample.";

    public SampleNotRequiredException() {
        super(new BusinessError(BusinessError.SAMPLE_NOT_REQUIRED, SAMPLE_NOT_REQUIRED_MESSAGE));
    }
}
