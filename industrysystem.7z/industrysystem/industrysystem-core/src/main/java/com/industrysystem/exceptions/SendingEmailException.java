package com.industrysystem.exceptions;

@SuppressWarnings("serial")
public class SendingEmailException extends BusinessException {

    public SendingEmailException() {
        super(new BusinessError(BusinessError.MAIL_SEND_EXCEPTION, "An error ocurred when sending an e-mail"));
    }

    public SendingEmailException(Exception e) {
        super(e, new BusinessError(BusinessError.MAIL_SEND_EXCEPTION, "An error ocurred when sending an e-mail"));
    }

}