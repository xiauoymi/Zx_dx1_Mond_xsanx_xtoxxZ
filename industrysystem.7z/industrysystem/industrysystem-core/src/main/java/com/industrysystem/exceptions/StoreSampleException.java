package com.industrysystem.exceptions;

/**
 * User: PPERA
 * Date: 25/10/13
 * Time: 12:47
 */
public class StoreSampleException extends BusinessException {
    public StoreSampleException(BusinessError error) {
        super(error);
    }

    public StoreSampleException(BusinessException e) {
        super(e);
    }

    public StoreSampleException(Exception e) {
        super(e);
    }
}
