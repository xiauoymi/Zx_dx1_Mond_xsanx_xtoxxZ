package com.industrysystem.exceptions;

/**
 * User: PMIRIB
 * Date: 10/10/13
 * Time: 10:25
 */
public class StoreTestResultException extends BusinessException {

    public StoreTestResultException(BusinessError error) {
        super(error);
    }

    public StoreTestResultException(BusinessException e) {
        super(e);
    }

    public StoreTestResultException(Exception e) {
        super(e);
    }
}
