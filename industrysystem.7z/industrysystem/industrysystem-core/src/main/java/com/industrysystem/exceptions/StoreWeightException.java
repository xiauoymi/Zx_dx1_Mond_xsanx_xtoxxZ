package com.industrysystem.exceptions;

/**
 * User: PPERA
 * Date: 09/10/13
 * Time: 10:30
 */
public class StoreWeightException extends BusinessException{
    public StoreWeightException(BusinessError error) {
        super(error);
    }

    public StoreWeightException(BusinessException e) {
        super(e);
    }
}
