package com.industrysystem.exceptions;

public class TechnologyNotFoundException extends BusinessException {

	public TechnologyNotFoundException() {
		super(new BusinessError(BusinessError.TECHNOLOGY_NOT_FOUND, "Technology not found"));
	}
}
