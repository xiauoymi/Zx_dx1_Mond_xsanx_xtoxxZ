package com.industrysystem.exceptions;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 28/01/14
 */
public class TestResultRegistrationException extends BusinessException{

    public TestResultRegistrationException(List<BusinessError> errors) {
        super(errors);
    }

}