package com.industrysystem.exceptions;

/**
 * User: PPERA
 * Date: 23/10/13
 * Time: 10:40
 */
public class TypeOfTestException extends BusinessException {
    public TypeOfTestException(BusinessException e) {
        super(e);
    }

    public TypeOfTestException(Exception e) {
        super(e);
    }
}
