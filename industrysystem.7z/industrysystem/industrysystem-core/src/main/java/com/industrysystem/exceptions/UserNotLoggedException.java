package com.industrysystem.exceptions;

/**
 * User: AVIER
 * Date: 12/4/13
 * Time: 4:06 PM
 */
public class UserNotLoggedException extends BusinessException {

    public UserNotLoggedException() {
        super(new BusinessError(BusinessError.USER_NOT_LOGGED_CODE, "No user was found"));
    }

}