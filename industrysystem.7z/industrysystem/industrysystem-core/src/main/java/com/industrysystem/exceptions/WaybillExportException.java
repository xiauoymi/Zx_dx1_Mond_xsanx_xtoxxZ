package com.industrysystem.exceptions;

/**
 * User: AVIER
 * Date: 12/4/13
 * Time: 5:40 PM
 */
public class WaybillExportException extends BusinessException {

    public WaybillExportException(Throwable th) {
        super(th);
    }

}