package com.industrysystem.exceptions;

import java.text.MessageFormat;

/**
 * User: PMIRIB
 * Date: 30/09/13
 * Time: 11:33
 */
public class WaybillNotFoundException extends BusinessException {

    public static final String WAYBILL_NOT_FOUND_MESSAGE = "There is no Waybill matching document for the Waybill number {0}.";

    public WaybillNotFoundException() {
        super(new BusinessError(BusinessError.WAYBILL_NOT_FOUND, "The waybill number does not match an existing waybill"));
    }

    public WaybillNotFoundException(Long waybillNumber) {
        super(new BusinessError(BusinessError.WAYBILL_NOT_FOUND, MessageFormat.format(WAYBILL_NOT_FOUND_MESSAGE, waybillNumber)));
    }

}