package com.industrysystem.persistence.daos;

import java.util.Date;
import java.util.List;

import com.industrysystem.entities.Campaign;
import com.industrysystem.exceptions.CampaignNotFoundException;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

@Repository
public class CampaignDao {

	protected static final String CAMPAIGN_FIND_CAMPAIGN_BY_CODE = "Campaign.findCampaignByCode";
    protected static final String CAMPAIGN_FIND_ALL_CAMPAIGNS_ORDERED_ASC_BY_DATE_FROM = "Campaign.findAllOrderAscByDateFrom";
    protected static final String CAMPAIGN_FIND_BY_DATE = "Campaign.findCampaignByDate";

	@PersistenceContext
	private EntityManager em;

	public Campaign findCampaignByCode(String code) throws CampaignNotFoundException {
		TypedQuery<Campaign> query = em.createNamedQuery(CAMPAIGN_FIND_CAMPAIGN_BY_CODE, Campaign.class);
		query.setParameter("code", code);
		try {
			return query.getSingleResult();
		} catch (NoResultException ex) {
			throw new CampaignNotFoundException();
		}
	}

    public List<Campaign> findAllOrderAscByDateFrom() {
        TypedQuery<Campaign> query = em.createNamedQuery(CAMPAIGN_FIND_ALL_CAMPAIGNS_ORDERED_ASC_BY_DATE_FROM, Campaign.class);
        return query.getResultList();
    }

    public Campaign findCampaignBy(Date date) {
        TypedQuery<Campaign> query = em.createNamedQuery(CAMPAIGN_FIND_BY_DATE, Campaign.class);
        query.setParameter("date", date);
        return query.getSingleResult();
    }

}