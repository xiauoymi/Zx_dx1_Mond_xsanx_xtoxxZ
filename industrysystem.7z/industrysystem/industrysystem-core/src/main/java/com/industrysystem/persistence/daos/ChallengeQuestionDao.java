package com.industrysystem.persistence.daos;

import com.industrysystem.entities.ChallengeQuestion;
import com.industrysystem.entities.ChallengeQuestionOwner;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
public class ChallengeQuestionDao {

    @PersistenceContext
    private EntityManager em;

    protected static final String FIND_CHALLENGES_BY_OWNER = "Select challengeQuestion from ChallengeQuestion challengeQuestion where challengeQuestion.owner = :owner";

    
    public List<ChallengeQuestion> findChallengeQuestions(String emailaddress)
    {
    	ChallengeQuestionOwner owner = findOrCreateOwnerByEmail(emailaddress);
    	Query query = this.em.createQuery(FIND_CHALLENGES_BY_OWNER);
        query.setParameter("owner", owner);
		return query.getResultList();

    }


	private ChallengeQuestionOwner findOrCreateOwnerByEmail(String emailaddress) {
		
		ChallengeQuestionOwner owner = em.find(ChallengeQuestionOwner.class, emailaddress);
    	if (owner == null)
    	{
    		owner = new ChallengeQuestionOwner();
    		owner.setEmailAddress(emailaddress);
    		owner.setRemainingAttempts(ChallengeQuestionOwner.ATTEMPTS_TO_FAIL);
    		em.persist(owner);
    	}
		return owner;
	}


	public void addChallengeQuestion(String emailAddress, String question,	String answer) {
		ChallengeQuestion challengeQuestion = new ChallengeQuestion();
		challengeQuestion.setQuestion(question);
		challengeQuestion.setAnswer(answer);
		challengeQuestion.setOwner(findOrCreateOwnerByEmail(emailAddress));
		em.persist(challengeQuestion);
	}


	public void removeChallengeQuestion(ChallengeQuestion challengeQuestionToRemove) {
		em.remove(challengeQuestionToRemove);
	}


	public int obtainRemainingChallengeQuestionsAttempts(String mail) {
		return findOrCreateOwnerByEmail(mail).getRemainingAttempts();
	}


	public void resetRemainingChallengeQuestionsAttempts(String mail) {
		ChallengeQuestionOwner owner = findOrCreateOwnerByEmail(mail);
		owner.setRemainingAttempts(ChallengeQuestionOwner.ATTEMPTS_TO_FAIL);
		em.persist(owner);
		
	}


	public void consumeRemainingChallengeQuestionsAttempt(String mail) {
		ChallengeQuestionOwner owner = findOrCreateOwnerByEmail(mail);
		owner.setRemainingAttempts(owner.getRemainingAttempts() - 1);
		em.persist(owner);
		
	}

}
