package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Crop;
import com.industrysystem.exceptions.CropNotFoundException;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * User: PMIRIB
 * Date: 11/10/13
 * Time: 09:00
 */
@Repository
public class CropDao {

    static final String CROP_FIND_CROP_BY_CODE = "Crop.findByCode";
    static final String CROP_FIND_ALL = "Crop.findAll";

    @PersistenceContext
    private EntityManager em;

    public Crop findCropBy(String code) throws CropNotFoundException {
        TypedQuery<Crop> query = em.createNamedQuery(CROP_FIND_CROP_BY_CODE, Crop.class);
        query.setParameter("cropCode", code);
        try{
            return query.getSingleResult();
        }catch (NoResultException ex){
            throw new CropNotFoundException();
        }
    }

    public List<Crop> findAllCrops(){
        TypedQuery<Crop> query = em.createNamedQuery(CROP_FIND_ALL, Crop.class);
        return query.getResultList();
    }

}