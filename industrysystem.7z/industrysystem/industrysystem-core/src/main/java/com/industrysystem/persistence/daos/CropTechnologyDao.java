package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Crop;
import com.industrysystem.entities.CropTechnology;
import com.industrysystem.entities.Technology;
import com.industrysystem.exceptions.CropTechnologyNotFoundException;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class CropTechnologyDao {

    @PersistenceContext
    private EntityManager em;

    public CropTechnology findByCropCodeAndTechnologyCodeAndTraitOwnerCode(String cropCode, String technologyCode, String traitOwnerCode) throws CropTechnologyNotFoundException {
        TypedQuery<CropTechnology> query = em.createNamedQuery("CropTechnology.findByCropCodeAndTechnologyCodeAndTraitOwnerCode", CropTechnology.class);
        query.setParameter("cropCode", cropCode);
        query.setParameter("technologyCode", technologyCode);
        query.setParameter("traitOwnerCode", traitOwnerCode);
        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            throw new CropTechnologyNotFoundException(cropCode,technologyCode, traitOwnerCode);
        }
    }

    public List<Technology> findTechnologies() {
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<Technology> query = builder.createQuery(Technology.class);
        Root<Technology> root = query.from(Technology.class);
        query.select(root);
        return em.createQuery(query).getResultList();
    }
    
    public Technology loadTechnology(Long id) {
        return em.find(Technology.class, id);
    }

	public CropTechnology findByCropAndTechnology(Crop crop, Technology technology) throws CropTechnologyNotFoundException {
        TypedQuery<CropTechnology> query = em.createNamedQuery("CropTechnology.findByCropAndTechnology", CropTechnology.class);
        query.setParameter("crop", crop);
        query.setParameter("technology", technology);
        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            throw new CropTechnologyNotFoundException(crop.getCode(),technology.getCode(), "Unknown");
        }
	}

}