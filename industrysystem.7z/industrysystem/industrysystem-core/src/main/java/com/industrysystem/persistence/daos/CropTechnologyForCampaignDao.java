package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Campaign;
import com.industrysystem.entities.Crop;
import com.industrysystem.entities.CropTechnologyForCampaign;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * User: CGLLLO
 * Date: 4/19/13
 * Time: 1:26 PM
 */
@Repository
public class CropTechnologyForCampaignDao {

    @PersistenceContext
    private EntityManager em;

	public CropTechnologyForCampaign findByCampaignCodeAndCropCodeAndTechnologyCode(String campaignCode, String cropCode, String technologyCode) {
		TypedQuery<CropTechnologyForCampaign> query = this.em.createNamedQuery("CropTechnologyForCampaign.findByCropCodeAndTechnologyCodeAndCampaignCode", CropTechnologyForCampaign.class);
        query.setParameter("campaignCode", campaignCode);
        query.setParameter("cropCode", cropCode);
        query.setParameter("technologyCode", technologyCode);
		return query.getSingleResult();
	}

    public List<CropTechnologyForCampaign> findByCampaignAndCrop(Crop crop, Campaign campaign) {
   		TypedQuery<CropTechnologyForCampaign> query = this.em.createNamedQuery("CropTechnologyForCampaign.findByCampaignAndCrop", CropTechnologyForCampaign.class);
           query.setParameter("campaign", campaign);
           query.setParameter("crop", crop);
   		return query.getResultList();
   	}

}
