package com.industrysystem.persistence.daos;

import com.industrysystem.entities.DocumentType;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 * User: PMIRIB
 * Date: 06/12/13
 */
@Repository
public class DocumentTypeDao {

    @PersistenceContext
    private EntityManager em;

    public DocumentType findByCode(String documentTypeCode) {
        TypedQuery<DocumentType> query = em.createNamedQuery("DocumentType.findByCode", DocumentType.class);
        query.setParameter("documentTypeCode", documentTypeCode);
        return query.getSingleResult();
    }

}
