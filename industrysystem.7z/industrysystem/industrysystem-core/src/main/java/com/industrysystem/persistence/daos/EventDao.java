package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Event;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * User: AVIER
 * Date: 11/27/13
 * Time: 12:02 PM
 */
@Repository
public class EventDao {

    @PersistenceContext
    private EntityManager em;

    public void save(Event event) {
        this.em.persist(event);
    }
}
