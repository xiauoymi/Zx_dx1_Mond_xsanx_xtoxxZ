package com.industrysystem.persistence.daos;

import com.industrysystem.entities.FailedAttemptsCount;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * User: PPERA
 * Date: 5/31/13
 * Time: 3:25 PM
 */
@Repository
public class FailedAttemptsCountDao {
    @PersistenceContext
    private EntityManager entityManager;

    public void incrementFailedAttempt(String remoteAddr) {
        FailedAttemptsCount failedAttemptsCount = this.entityManager.find(FailedAttemptsCount.class, remoteAddr);
        if (failedAttemptsCount != null) {
            failedAttemptsCount.increment();
        } else {
            failedAttemptsCount = new FailedAttemptsCount();
            failedAttemptsCount.setValue(1);
            failedAttemptsCount.setRemoteAddress(remoteAddr);
            this.entityManager.persist(failedAttemptsCount);
        }
    }

    public Integer findCountByRemoteAddress(String remoteAddress) {
        FailedAttemptsCount failedAttemptsCount = entityManager.find(FailedAttemptsCount.class, remoteAddress);

        if (failedAttemptsCount == null) {
            return 0;
        }

        return failedAttemptsCount.getValue();
    }

    public void cleanFailedAuthenticationAttemptsCount(String remoteAddr) {
        FailedAttemptsCount count = this.entityManager.find(FailedAttemptsCount.class, remoteAddr);
        if (count != null) {
            entityManager.remove(count);
        }
    }
}
