package com.industrysystem.persistence.daos;

import com.industrysystem.entities.BroadcastMessage;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class GreetingDao {

    @PersistenceContext
    private EntityManager em;

    public List<BroadcastMessage> getAll() {
        CriteriaBuilder builder = em.getCriteriaBuilder();
        CriteriaQuery<BroadcastMessage> query = builder.createQuery(BroadcastMessage.class);
        Root<BroadcastMessage> variableRoot = query.from(BroadcastMessage.class);
        query.select(variableRoot);
        return em.createQuery(query).getResultList();
    }

    public void insertGreeting(String greeting) {
        BroadcastMessage mb = new BroadcastMessage();
        mb.setMessage(greeting);
        em.persist(mb);
    }
}
