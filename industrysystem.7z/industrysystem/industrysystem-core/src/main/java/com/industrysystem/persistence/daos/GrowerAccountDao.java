package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Grower;
import com.industrysystem.entities.GrowerAccount;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.ArrayList;
import java.util.List;

@Repository
public class GrowerAccountDao {

    @PersistenceContext
    private EntityManager em;

    public List<GrowerAccount> findAccountsByGrower(Grower grower) {
    	TypedQuery<GrowerAccount> query = this.em.createNamedQuery("GrowerAccount.findByGrower", GrowerAccount.class);
        query.setParameter("grower", grower);
        try {
            return query.getResultList();
        } catch (NoResultException e) {
            return new ArrayList<GrowerAccount>();
        }
    }

    public void create(GrowerAccount growerAccount) {
    	em.persist(growerAccount);
    }

    public GrowerAccount refreshAccount(GrowerAccount growerAccount) {
        TypedQuery<GrowerAccount> query = this.em.createNamedQuery("GrowerAccount.findByAccountNumberAndCompanyCode", GrowerAccount.class);
        query.setParameter("accountNumber", growerAccount.getNumber());
        query.setParameter("traitOwnerCode", growerAccount.getCropTechnology().getTechnology().getTraitOwner().getCode());

        try {
            return query.getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }

}
