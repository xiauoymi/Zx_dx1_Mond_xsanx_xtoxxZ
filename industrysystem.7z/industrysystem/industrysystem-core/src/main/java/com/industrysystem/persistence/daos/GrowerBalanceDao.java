package com.industrysystem.persistence.daos;

import com.industrysystem.entities.*;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.ArrayList;
import java.util.List;

/**
 * User: PPERA
 * Date: 3/1/13
 * Time: 12:20 PM
 */
@Repository
public class GrowerBalanceDao {
    public static final String FIND_BALANCES_BY_GROWER = "Select balance from GrowerBalance balance where balance.growerAccount.grower = :grower";
    public static final String FIND_BY_ACCOUNT_AND_CAMPAIGN_CODE_NAMED_QUERY = "GrowerBalance.findByAccountAndCampaignCode";
	public static final String FIND_BALANCES_BY_GROWER_AND_TECHNOLOGY = "Select balance from GrowerBalance balance where balance.growerAccount.grower = :grower and balance.growerAccount.cropTechnology.technology = :technology";
    public static final String FIND_GROWER_BALANCE_BY_GROWER_TECHNOLOGY_AND_CAMPAIGN = "GrowerBalance.findByGrowerTechnologyAndCampaign";

    @PersistenceContext
    private EntityManager em;

    public void save(GrowerBalance growerBalance) {
        em.persist(growerBalance);
    }

    public List<GrowerBalance> findBalancesByGrower(Grower grower) {
        TypedQuery<GrowerBalance> query = this.em.createQuery(FIND_BALANCES_BY_GROWER, GrowerBalance.class);
        query.setParameter("grower", grower);

        return query.getResultList();
    }

    public List<GrowerBalance> findBalancesByGrowerAndTechnology(Grower grower, Technology technology) {
        TypedQuery<GrowerBalance> query = this.em.createQuery(FIND_BALANCES_BY_GROWER_AND_TECHNOLOGY, GrowerBalance.class);
        query.setParameter("grower", grower);
        query.setParameter("technology", technology);

        return query.getResultList();
    }

    public GrowerBalance findBalanceByAccountAndCampaignCode(GrowerAccount growerAccount, String campaignCode) {
        TypedQuery<GrowerBalance> query = this.em.createNamedQuery(FIND_BY_ACCOUNT_AND_CAMPAIGN_CODE_NAMED_QUERY, GrowerBalance.class);
        query.setParameter("account", growerAccount);
        query.setParameter("campaignCode", campaignCode);

        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    public List<GrowerBalance> findBy(Grower grower, Technology technology, Campaign campaign) {
        TypedQuery<GrowerBalance> query = this.em.createNamedQuery(FIND_GROWER_BALANCE_BY_GROWER_TECHNOLOGY_AND_CAMPAIGN, GrowerBalance.class);

        query.setParameter("grower", grower);
        query.setParameter("technology", technology);
        query.setParameter("campaign", campaign);

        return query.getResultList();
    }
}
