package com.industrysystem.persistence.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.google.common.base.Function;
import com.industrysystem.entities.Document;
import com.industrysystem.entities.Grower;
import com.industrysystem.exceptions.GrowerNotFoundException;

import static com.google.common.base.Predicates.notNull;
import static com.google.common.collect.FluentIterable.from;

@Repository
public class GrowerDao {

    @PersistenceContext
    private EntityManager em;

    public static final String FIND_GROWER_BY_DOCUMENT = "Select grower from Grower grower " +
            "where grower.document.number = :documentNumber and grower.document.type.code = :documentTypeCode";

    public void registerGrower(Grower grower) {
        em.persist(grower);
    }
    
    public List<Grower> findGrowersByDocuments(List<Document> documents) {
    	return from(documents).transform(new Function<Document, Grower>() {
            @Override
			public Grower apply(Document document) {
				try {
					return findGrowerByDocument(document);
				} catch (GrowerNotFoundException e) {
					return null;
				}
			}
		}).filter(notNull()).toImmutableList();
    }

    public Grower findGrowerByDocument(Document document) throws GrowerNotFoundException {
        Query query = em.createQuery(FIND_GROWER_BY_DOCUMENT);
        query.setParameter("documentNumber", document.getNumber());
        query.setParameter("documentTypeCode", document.getTypeCode());
        try {
            return (Grower)query.getSingleResult();
        } catch (NoResultException e) {
            throw new GrowerNotFoundException();
        }
    }

    public Grower findOrCreateGrower(Document document, String name) {
        try {
            return findGrowerByDocument(document);
        } catch (GrowerNotFoundException e) {
            Grower grower = new Grower(document, name);
            registerGrower(grower);
            return grower;
        }
    }

}