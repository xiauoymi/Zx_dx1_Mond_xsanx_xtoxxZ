package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Laboratory;
import com.industrysystem.exceptions.LaboratoryNotFoundException;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: AVIER
 * Date: 10/4/13
 */
@Repository
public class LaboratoryDao {
    @PersistenceContext
    private EntityManager em;

    public Laboratory findLaboratoryByLabCode(String labCode) throws LaboratoryNotFoundException {
        Query query = this.em.createNamedQuery("Laboratory.findByLabCode", Laboratory.class);
        query.setParameter("labCode", labCode);
        try {
            return (Laboratory) query.getSingleResult();
        } catch (NoResultException e) {
            throw new LaboratoryNotFoundException();
        }
    }

    public List<Laboratory> findLaboratories() {
        Query query = this.em.createNamedQuery("Laboratory.findAll", Laboratory.class);
        return query.getResultList();
    }
}
