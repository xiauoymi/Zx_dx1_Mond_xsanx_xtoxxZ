package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Document;
import com.industrysystem.entities.LoadDetail;
import com.industrysystem.entities.Waybill;
import org.springframework.stereotype.Repository;

import javax.persistence.*;
import java.util.List;

/**
 * User: PPERA
 * Date: 25/09/13
 * Time: 17:42
 */
@Repository
public class LoadDetailDao {

    @PersistenceContext
    private EntityManager em;

    public List<LoadDetail> findLoadDetailsByWaybill(Waybill waybill){
            TypedQuery<LoadDetail> query = this.em.createNamedQuery("LoadDetail.findByWaybill", LoadDetail.class);
            query.setParameter("wayBill", waybill);
            return query.getResultList();
    }

    public LoadDetail findLoadDetailsBySampleCodeAndWaybillDestinationDocument(String sampleCode, Document destinationDocument) {
        TypedQuery<LoadDetail> query = this.em.createNamedQuery("LoadDetail.findBySampleCodeAndWaybillDestinationDocument", LoadDetail.class);
        query.setParameter("sampleCode", sampleCode);
        query.setParameter("destinationDocumentNumber", destinationDocument.getNumber());
        query.setParameter("destinationDocumentTypeCode", destinationDocument.getTypeCode());
        return query.getSingleResult();
    }


    public LoadDetail findLoadDetailsBySampleCodeAndWaybillAddresseeDocument(String sampleCode, Document addresseeDocument) {
        TypedQuery<LoadDetail> query = this.em.createNamedQuery("LoadDetail.findBySampleCodeAndWaybillDestinationDocument", LoadDetail.class);
        query.setParameter("sampleCode", sampleCode);
        query.setParameter("addresseeDocumentNumber", addresseeDocument.getNumber());
        query.setParameter("addresseeDocumentTypeCode", addresseeDocument.getTypeCode());
        return query.getSingleResult();
    }


    public LoadDetail findEagerWaybillByID(String waybillNumber) {
        StringBuilder queryStr = new StringBuilder()
                .append("SELECT DISTINCT wb FROM Waybill wb LEFT JOIN FETCH wb.loadDetails ld ")
                .append("WHERE wb.waybillNumber = :waybillNumber");

        Query query = em.createQuery(queryStr.toString());
        query.setParameter("waybillNumber", waybillNumber);

        try {
            return (LoadDetail) query.getSingleResult();
        } catch (Exception ex) {
            throw new PersistenceException("An error ocurred when excecuting the query for the waybill number " + waybillNumber);
        }
    }

}