package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Location;
import com.industrysystem.exceptions.LocationNotFoundException;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

@Repository
public class LocationDao {

    @PersistenceContext
    private EntityManager em;

    public Location findLocationByCode(Long locationCode) throws LocationNotFoundException {
        TypedQuery<Location> query = this.em.createNamedQuery("Location.findByCode", Location.class);
        query.setParameter("locationCode", locationCode);
        try {
            return query.getSingleResult();
        } catch (NoResultException nre) {
            throw new LocationNotFoundException();
        }
    }
    public List<Location> findLocationsFrom(Long provinceCode){
        TypedQuery<Location> query = this.em.createNamedQuery("Location.findByProvinceCode", Location.class);
        query.setParameter("provinceCode", provinceCode);
        return query.getResultList();
    }

}
