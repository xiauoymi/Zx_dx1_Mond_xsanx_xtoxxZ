package com.industrysystem.persistence.daos;

import com.industrysystem.entities.*;
import com.industrysystem.exceptions.PodNotFoundException;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * User: PPERA
 * Date: 24/09/13
 * Time: 13:24
 */
@Repository
public class PodDao {

    @PersistenceContext
    private EntityManager em;

    public PodHeadOffice findByDocument(Document document) throws PodNotFoundException {
        TypedQuery<PodHeadOffice> query = this.em.createNamedQuery("PodHeadOffice.findByDocument", PodHeadOffice.class);
        query.setParameter("documentNumber", document.getNumber());
        query.setParameter("documentTypeCode", document.getTypeCode());
        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            throw new PodNotFoundException(document);
        }
    }

    public boolean isPODDocumentDeclared(Document document) {
        try {
            findByDocument(document);
            return true;
        } catch (PodNotFoundException e) {
            return false;
        }
    }

    public PodScoring findScoringByPod(Document document) {
        TypedQuery<PodScoring> query = this.em.createNamedQuery("PodScoring.findScoringByPod", PodScoring.class);
        query.setParameter("documentNumber", document.getNumber());
        query.setParameter("documentTypeCode", document.getTypeCode());
        try {
            return query.getSingleResult();
        } catch (NoResultException ex) {
            return null;
        }
    }

    public List<Declaration> findDeclarationsByLoadDetail(LoadDetail detail) {
        TypedQuery<Declaration> query = this.em.createNamedQuery("Declaration.findDeclarationsByLoadDetail", Declaration.class);
        query.setParameter("loadDetail", detail);
        return query.getResultList();
    }

    public PodBranch findByDocumentAndCommercialCode(Document document, Long commercialCode) throws PodNotFoundException {
        TypedQuery<PodBranch> query = this.em.createNamedQuery("PodBranch.findByDocumentAndCommercialCode", PodBranch.class);
        query.setParameter("documentNumber", document.getNumber());
        query.setParameter("documentTypeCode", document.getTypeCode());
        query.setParameter("commercialCode", commercialCode);
        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            throw new PodNotFoundException(document);
        }
    }

    public PodHeadOffice findByDocumentWithBranches(Document document) throws PodNotFoundException {
        TypedQuery<PodHeadOffice> query = this.em.createNamedQuery("PodHeadOffice.findByDocumentWithBranches", PodHeadOffice.class);
        query.setParameter("documentNumber", document.getNumber());
        query.setParameter("documentTypeCode", document.getTypeCode());
        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            throw new PodNotFoundException(document);
        }
    }

}