package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Province;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 05/12/13
 */
@Repository
public class ProvinceDao {
    @PersistenceContext
    private EntityManager em;
    static final String FIND_PROVINCES = "Province.findProvinces";

    public List<Province> findProvinces(){
        TypedQuery<Province> query = this.em.createNamedQuery(FIND_PROVINCES, Province.class);
        return query.getResultList();
    }

}
