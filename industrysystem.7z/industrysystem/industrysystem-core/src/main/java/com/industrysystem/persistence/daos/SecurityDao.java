package com.industrysystem.persistence.daos;

import com.industrysystem.entities.ResetPasswordToken;
import com.industrysystem.exceptions.InvalidTokenException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Calendar;

@Repository
public class SecurityDao {

    @PersistenceContext
    private EntityManager em;

    @Value(value = "${recover_password.token.validity.minutes}")
    private Integer tokenValidityMinutes; 
    
    public void persistTokenForEmailAddress(String token, String email) {
    	
    	removeByEmail(email);
    	ResetPasswordToken resetPasswordToken = new ResetPasswordToken();
    	resetPasswordToken.setToken(token);
    	resetPasswordToken.setEmailAddress(email);
    	Calendar expiration = Calendar.getInstance();
    	expiration.add(Calendar.MINUTE, tokenValidityMinutes);
		resetPasswordToken.setExpiration(expiration.getTime());
    	em.persist(resetPasswordToken);
    }

    public String consumePasswordResetToken(String token) throws InvalidTokenException
    {
    	ResetPasswordToken obtained = em.find(ResetPasswordToken.class, token);
		if (obtained != null)
		{
			em.remove(obtained);
			Calendar now = Calendar.getInstance();
			Calendar persisted = Calendar.getInstance();
			persisted.setTime(obtained.getExpiration());
			if (now.after(persisted))
				throw new InvalidTokenException();
			return obtained.getEmailAddress();
		}
		throw new InvalidTokenException();
    }

	private void removeByEmail(String emailAddress) {
		Query query = em.createQuery("delete from ResetPasswordToken rpt where rpt.emailAddress = :emailAddress");
		query.setParameter("emailAddress", emailAddress);
		query.executeUpdate();
		
	}
	



}
