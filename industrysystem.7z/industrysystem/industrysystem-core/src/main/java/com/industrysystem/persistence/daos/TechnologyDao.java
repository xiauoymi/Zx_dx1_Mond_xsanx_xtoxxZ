package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Technology;
import com.industrysystem.exceptions.TechnologyNotFoundException;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 * User: PMIRIB
 * Date: 11/10/13
 * Time: 09:00
 */
@Repository
public class TechnologyDao {

    @PersistenceContext
    private EntityManager em;

    public Technology findByCode(String technologyCode) throws TechnologyNotFoundException {
        TypedQuery<Technology> query = em.createNamedQuery("Technology.findByCode", Technology.class);
        query.setParameter("technologyCode", technologyCode);
        try {
            return query.getSingleResult();
        } catch (NoResultException nre) {
            throw new TechnologyNotFoundException();
        }
    }

}