package com.industrysystem.persistence.daos;

import com.industrysystem.entities.LoadDetail;
import com.industrysystem.entities.TestRequest;
import com.industrysystem.entities.WaybillStatusEnum;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.util.List;

/**
 * User: PPERA
 * Date: 25/09/13
 * Time: 17:42
 */
@Repository
public class TestRequestDao {

    @PersistenceContext
    private EntityManager em;

    public void save(TestRequest testRequest) {
        em.persist(testRequest);
    }

    public List<TestRequest> findByLoadDetail(LoadDetail loadDetail) {
        TypedQuery<TestRequest> query = em.createQuery("from TestRequest tr where tr.loadDetail = :loadDetail", TestRequest.class);
        query.setParameter("loadDetail", loadDetail);
        return query.getResultList();
    }

    public List<TestRequest> findPendingTestRequests() {
        TypedQuery<TestRequest> query = em.createQuery("from TestRequest tr where tr.dateCompleted is null", TestRequest.class);
        return query.getResultList();
    }

    public List<TestRequest> findPendingTestRequestsForLaboratories(List<String> laboratoryCodes) {
        String queryString = "from TestRequest tr where tr.loadDetail.waybill.status=:status and tr.loadDetail.laboratory.code in (:laboratoryCodes)";
        TypedQuery<TestRequest> query = em.createQuery(queryString , TestRequest.class);
        query.setParameter("laboratoryCodes", laboratoryCodes);
        query.setParameter("status", WaybillStatusEnum.WAITING_FOR_TEST_RESULTS);
        return query.getResultList();
    }

}