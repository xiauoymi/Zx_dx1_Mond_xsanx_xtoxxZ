package com.industrysystem.persistence.daos;

import com.industrysystem.entities.TraitOwner;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

/**
 * User: PMIRIB
 * Date: 11/10/13
 * Time: 09:00
 */
@Repository
public class TraitOwnerDao {

    @PersistenceContext
    private EntityManager em;

    public TraitOwner findByCode(String traitOwnerCode) {
        TypedQuery<TraitOwner> query = em.createNamedQuery("TraitOwner.findByCode", TraitOwner.class);
        query.setParameter("traitOwnerCode", traitOwnerCode);
        return query.getSingleResult();
    }

}