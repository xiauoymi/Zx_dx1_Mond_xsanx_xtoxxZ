package com.industrysystem.persistence.daos;

import com.industrysystem.entities.*;
import com.industrysystem.exceptions.BusinessException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.Date;
import java.util.List;

@Repository
public class TraitOwnerMessageDao {

    public static final String FIND_MAX_SEQUENCE_FOR_TRAIT_OWNER = "select max(message.messageSequence) from TraitOwnerMessage message where message.traitOwner = :traitOwner";
    public static final String FIND_OPEN_MESSAGE_FOR_TRAIT_OWNER_CODE = "select message from TraitOwnerMessage message where message.traitOwner = :traitOwner and message.sentTime = null order by message.id desc";

    @PersistenceContext
    private EntityManager em;
    @Autowired
    protected EventDao eventDao;

    @Transactional(rollbackFor = {BusinessException.class})
    public void updateSentTime(String traitOwnerCode, long fromMessageSequence, int limit) {
        long toMessageSequence = fromMessageSequence++ + limit;
        String queryStr = "UPDATE TraitOwnerMessage tom SET tom.sentTime = :sentTime " +
                "WHERE tom.messageSequence BETWEEN :fromMessageSequence AND :toMessageSequence " +
                "AND tom.traitOwner = (SELECT to FROM TraitOwner to WHERE to.code = :traitOwnerCode)";

        Query query = em.createQuery(queryStr)
                .setParameter("sentTime", new Date())
                .setParameter("fromMessageSequence", fromMessageSequence)
                .setParameter("toMessageSequence", toMessageSequence)
                .setParameter("traitOwnerCode", traitOwnerCode);
        query.executeUpdate();
    }

    public List<TraitOwnerMessage> findTraitOwnerMessagesByTraitOwnerAndMessageSequence(String traitOwnerCode,
                                                                                        long fromMessageSequence, int limit) {
        long toMessageSequence = fromMessageSequence++ + limit;
        String queryStr = "SELECT DISTINCT tom FROM TraitOwnerMessage tom " +
                "LEFT JOIN FETCH tom.waybillMessages wm " +
                "LEFT JOIN FETCH wm.waybill w " +
                "LEFT JOIN FETCH w.loadDetails ld " +
                "LEFT JOIN FETCH ld.declarations d " +
                "LEFT JOIN FETCH ld.testRequests tr " +
                "LEFT JOIN FETCH tr.cuantitativeTestResults ctr " +
                "WHERE tom.messageSequence BETWEEN :fromMessageSequence AND :toMessageSequence " +
                "AND tom.traitOwner.code = :traitOwnerCode " +
                "ORDER BY tom.messageSequence ASC";

        Query query = em.createQuery(queryStr)
                .setParameter("fromMessageSequence", fromMessageSequence)
                .setParameter("toMessageSequence", toMessageSequence)
                .setParameter("traitOwnerCode", traitOwnerCode);
        return query.getResultList();
    }

    public void addWaybillToOpenTraitOwnerMessage(Waybill waybill, TraitOwner traitOwner) {
        TraitOwnerMessage traitOwnerMessage = this.getOpenTraitOwnerMessage(traitOwner);
        WaybillMessage waybillMessage = new WaybillMessage();
        waybillMessage.setWaybill(waybill);
        waybillMessage.setTraitOwnerMessage(traitOwnerMessage);
        traitOwnerMessage.getWaybillMessages().add(waybillMessage);
        em.persist(traitOwnerMessage);
    }

    private TraitOwnerMessage getOpenTraitOwnerMessage(TraitOwner traitOwner) {
        Query query = this.em.createQuery(FIND_OPEN_MESSAGE_FOR_TRAIT_OWNER_CODE);
        query.setParameter("traitOwner", traitOwner);
        query.setFirstResult(0);
        query.setMaxResults(1);

        TraitOwnerMessage traitOwnerMessage;
        try {
            traitOwnerMessage = (TraitOwnerMessage) query.getSingleResult();
            return traitOwnerMessage;
        } catch (NoResultException e) {
            traitOwnerMessage = new TraitOwnerMessage();
            traitOwnerMessage.setTraitOwner(traitOwner);
            Long maxSequence = this.getCurrentMaxSequenceForTraitOwner(traitOwner);
            traitOwnerMessage.setMessageSequence(maxSequence + 1l);
            return traitOwnerMessage;
        }
    }

    private Long getCurrentMaxSequenceForTraitOwner(TraitOwner traitOwner) {
        Query maxSequenceQuery = this.em.createQuery(FIND_MAX_SEQUENCE_FOR_TRAIT_OWNER);
        maxSequenceQuery.setParameter("traitOwner", traitOwner);
        Long maxSequence = (Long) maxSequenceQuery.getSingleResult();

        if (maxSequence == null) {
            return 0l;
        }

        return maxSequence;
    }

}