package com.industrysystem.persistence.daos;

import com.industrysystem.entities.Transaction;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * User: CGLLLO
 * Date: 3/4/13
 * Time: 12:36 PM
 */
@Repository
public class TransactionDao {

    @PersistenceContext
    private EntityManager em;

    public void save(Transaction transaction) {
        em.persist(transaction);
    }
}
