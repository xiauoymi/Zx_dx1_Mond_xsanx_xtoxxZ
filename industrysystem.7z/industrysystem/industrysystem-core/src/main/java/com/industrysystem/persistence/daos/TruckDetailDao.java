package com.industrysystem.persistence.daos;

import com.industrysystem.entities.TruckLoadDetail;
import com.industrysystem.exceptions.LoadDetailAlreadyExistsException;
import com.industrysystem.exceptions.LoadDetailNotFoundException;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import java.text.MessageFormat;

@Repository
public class TruckDetailDao {

	@PersistenceContext
    private EntityManager em;

	public void findTruckDetailById(String ctg) throws LoadDetailAlreadyExistsException, LoadDetailNotFoundException{
		try {
			TypedQuery<TruckLoadDetail> query = em.createNamedQuery("TruckDetail.findByCtg", TruckLoadDetail.class);
			query.setParameter("ctg", ctg);
			query.getSingleResult();
			throw new LoadDetailAlreadyExistsException(MessageFormat.format("The CTG {0} already exists", ctg));
		} catch (NoResultException nre) {
			throw new LoadDetailNotFoundException(ctg);
		}
	}

}