package com.industrysystem.persistence.daos;

import com.industrysystem.entities.*;
import com.industrysystem.exceptions.WaybillNotFoundException;
import com.industrysystem.entities.Campaign;
import com.industrysystem.entities.Document;
import com.industrysystem.entities.Grower;
import com.industrysystem.entities.Waybill;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * User: PPERA
 * Date: 25/09/13
 * Time: 17:41
 */
public abstract class WaybillDao {

    public static final String WAYBILL_FIND_BY_WAYBILL_NUMBER = "Waybill.findByWaybillNumber";
    public static final String FIND_BY_NON_POD_PARTICIPANT_GROWER = "Waybill.findWaybillByGrowerAndCampaign";

    @PersistenceContext
    public EntityManager em;

    public abstract Waybill findWaybillByWaybillNumber(Long waybillNumber) throws WaybillNotFoundException;

    public void save(Waybill waybill) {
        em.persist(waybill);
    }

    public List<Waybill> findListOfWaybillsByPod(Document document) {
        TypedQuery<Waybill> query = this.em.createNamedQuery("Waybill.findListOfWaybillsByPod", Waybill.class);
        query.setParameter("documentNumber", document.getNumber());
        query.setParameter("documentTypeCode", document.getTypeCode());
        query.setParameter("holderDeclaredIsPod", true);
        try {
            return query.getResultList();
        } catch (Exception ex) {
            return new ArrayList<Waybill>();
        }
    }

    public Waybill findWaybillByID(Long waybillId) {
        TypedQuery<Waybill> query = this.em.createNamedQuery("Waybill.findByWaybillId", Waybill.class);
        query.setParameter("waybillId", waybillId);
        try {
            return query.getSingleResult();
        } catch (Exception ex) {
            throw new PersistenceException("An error ocurred excecuting the query for the waybill id " + waybillId);
        }
    }

    public Waybill findEagerWaybillByID(Long waybillId) {
        StringBuilder queryStr = new StringBuilder()
                .append("SELECT DISTINCT wb FROM Waybill wb ")
                .append("LEFT JOIN FETCH wb.loadDetails ld ")
                .append("LEFT JOIN FETCH ld.testRequests tr ")
                .append("LEFT JOIN FETCH tr.cuantitativeTestResults ")
                .append("where wb.id = :waybillId ");

        Query query = em.createQuery(queryStr.toString());
        query.setParameter("waybillId", waybillId);

        try {
            return (Waybill) query.getSingleResult();
        } catch (Exception ex) {
            throw new PersistenceException("An error ocurred when excecuting the query for the waybill id " + waybillId);
        }
    }

    public List<Waybill> findWaybillsByDestinationsAndStates(List<PodBranch> podBranches, List<WaybillStatusEnum> status){

        TypedQuery<Waybill> query = this.em.createNamedQuery("Waybill.findWaybillsByDestinationsAndStates", Waybill.class);
        query.setParameter("podBranches", podBranches);
        query.setParameter("status", status);

        try {
            return query.getResultList();
        } catch (Exception ex) {
            throw new PersistenceException("An error ocurred when excecuting the query for the Pod Branch");
        }
    }

    public abstract List<Waybill> findBy(Grower grower, Campaign campaign);

    public void updateWaybill(Waybill waybill) {
        em.merge(waybill);
    }

}