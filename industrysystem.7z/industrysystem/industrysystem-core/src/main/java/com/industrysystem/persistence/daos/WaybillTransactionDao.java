package com.industrysystem.persistence.daos;

import com.industrysystem.entities.WaybillTransaction;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 * Created with IntelliJ IDEA.
 * User: MEFAZZ
 * Date: 1/13/14
 * Time: 11:14 AM
 * To change this template use File | Settings | File Templates.
 */
@Repository
public class WaybillTransactionDao {

    @PersistenceContext
    public EntityManager em;


    public void save(WaybillTransaction waybillTransaction) {
          em.persist(waybillTransaction);
    }

}
