package com.industrysystem.persistence.daos;

import com.industrysystem.entities.WaybillValorization;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Repository
public class WaybillValorizationDao {

    @PersistenceContext
    private EntityManager em;

    public void save(WaybillValorization waybillValorization) {
        this.em.persist(waybillValorization);
    }

}
