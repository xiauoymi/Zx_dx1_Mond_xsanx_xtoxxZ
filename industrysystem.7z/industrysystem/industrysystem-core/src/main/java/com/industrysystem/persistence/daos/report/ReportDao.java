package com.industrysystem.persistence.daos.report;

import org.springframework.stereotype.Repository;

import javax.persistence.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.swing.*;
import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 30/01/14
 * Time: 17:35
 */
@Repository
public class ReportDao {

    @PersistenceContext
    private EntityManager entityManager;

    private interface SetParameterCommand {
        int execute(Query query, int position, Object... values);
    }

    private Map<ReportOperator, SetParameterCommand> setParameterCommandMap = new HashMap<ReportOperator, SetParameterCommand>();

    public ReportDao() {
        setParameterCommandMap.put(ReportOperator.between, new SetParameterCommand() {
            @Override
            public int execute(Query query, int position, Object... values) {
                query.setParameter(position, values[0]);
                query.setParameter(position + 1, values[1]);
                return ReportOperator.between.countArgs();
            }
        });
        setParameterCommandMap.put(ReportOperator.in, new SetParameterCommand() {
            @Override
            public int execute(Query query, int position, Object... values) {
                query.setParameter(position, Arrays.asList(values));
                return 1;
            }
        });
        for (ReportOperator reportOperator : ReportOperator.values()) {
            if (!setParameterCommandMap.containsKey(reportOperator)) {
                setParameterCommandMap.put(reportOperator, new SetParameterCommand() {
                    @Override
                    public int execute(Query query, int position, Object... values) {
                        query.setParameter(position, values[0]);
                        return 1;
                    }
                });
            }
        }
    }

    public <T> List<T> getReportContent(String baseQuery, ReportRequest reportRequest, Class<T> contentClass, int maxResults) {
        return getReportContent(baseQuery, reportRequest, new HashMap<String, Object>(), contentClass, maxResults);
    }

    public <T> List<T> getReportContent(String baseQuery, ReportRequest reportRequest, Map<String, Object> namedParameters, Class<T> contentClass, int maxResults) {
        if (reportRequest.getPage() > 0) {
            String queryString = reportRequest.createQuery(baseQuery);
            TypedQuery<T> query = entityManager.createQuery(queryString, contentClass);
            for (String key : namedParameters.keySet()) {
                query.setParameter(key, namedParameters.get(key));
            }
            setParameters(query, reportRequest);
            query.setMaxResults(maxResults);
            query.setFirstResult(maxResults * (reportRequest.getPage() - 1));
            return query.getResultList();
        } else {
            return new ArrayList<T>();
        }
    }

    public int getTotalPages(String baseQuery, ReportRequest reportRequest, int maxResults) {
        return getTotalPages(baseQuery, reportRequest, new HashMap<String, Object>(), maxResults);
    }

    public int getTotalPages(String baseQuery, ReportRequest reportRequest, Map<String, Object> namedParameters, int maxResults) {
        String queryString = reportRequest.createCountQuery(baseQuery);
        Query query = entityManager.createQuery(queryString);
        for (String key : namedParameters.keySet()) {
            query.setParameter(key, namedParameters.get(key));
        }
        setParameters(query, reportRequest);
        double count = ((Number) query.getSingleResult()).intValue();
        return (int) Math.ceil(count / maxResults);
    }

    private Query setParameters(Query query, ReportRequest reportRequest) {
        int i = 0;
        for (ReportFilter reportFilter : reportRequest.getFilter()) {
            SetParameterCommand command = setParameterCommandMap.get(reportFilter.getOperator());
            try {
                i += command.execute(query, i, reportFilter.getValues());
            } catch (IllegalArgumentException ex) {
                String message = ex.getMessage();
                String className = message.substring(message.lastIndexOf('[')+1, message.lastIndexOf(']'));
                try {
                    Object[] values = reportFilter.setClass(Class.forName(className)).getValues();
                    i += command.execute(query, i, values);
                } catch (ClassNotFoundException e) {
                    throw new IllegalArgumentException(e);
                }
            }
        }
        return query;
    }

}