package com.industrysystem.persistence.daos.report;

import javax.swing.*;
import java.util.Arrays;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 23/01/14
 * Time: 17:15
 */
public class ReportFilter {

    private String field = "";
    private ReportOperator operator = ReportOperator.eq;
    private Object[] values = new Object[]{};

    public ReportFilter() {
    }

    public ReportFilter(String field, ReportOperator operator, Object... values) {
        this.field = field;
        this.operator = operator;
        this.values = values;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public ReportOperator getOperator() {
        return operator;
    }

    public Object[] getValues() {
        return values;
    }

    public ReportFilter setClass(Class<?> clazz) {
        return parseValues(new StringParserFactory().create(clazz));
    }

    public ReportFilter parseValues(StringParser<?> stringParser) {
        for (int i=0; i < values.length; i++) {
            try {
                values[i] = stringParser.parse((String) values[i]);
            } catch (ClassCastException ex) {
                String message = String.format("Values already parsed in filter '%s'. Value='%s' '%s'."
                        , field
                        , values[i]
                        , values[i].getClass()
                );
                throw new IllegalArgumentException(message, ex);
            }
        }
        return this;
    }

    public String toSql(int argumentPosition) {
        return operator.toSql(field, argumentPosition);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ReportFilter that = (ReportFilter) o;

        if (field != null ? !field.equals(that.field) : that.field != null) return false;
        if (operator != that.operator) return false;
        if (!Arrays.equals(values, that.values)) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = field != null ? field.hashCode() : 0;
        result = 31 * result + operator.hashCode();
        result = 31 * result + Arrays.hashCode(values);
        return result;
    }
}
