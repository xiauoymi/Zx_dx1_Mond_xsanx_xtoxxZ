package com.industrysystem.persistence.daos.report;

import java.util.MissingFormatArgumentException;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 24/01/14
 * Time: 13:05
 */
public enum ReportOperator {

    eq("%s = %s"),
    ne("%s <> %s"),
    gt("%s > %s"),
    ge("%s >= %s"),
    lt("%s < %s"),
    le("%s <= %s"),
    between("%s between %s and %s"),
    in("%s in(%s)");

    private String sqlPattern;

    private ReportOperator(String sqlPattern) {
        this.sqlPattern = sqlPattern;
    }

    public int countArgs() {
        return sqlPattern.split("%s").length -1;
    }

    private String toSql(String field, String... value) {
        String[] args = new String[value.length + 1];
        args[0] = field;
        System.arraycopy(value, 0, args, 1, value.length);
        try {
            return String.format(sqlPattern, args);
        } catch (MissingFormatArgumentException ex) {
            String pattern = "%d argument(s) received, but %d argument(s) needed.";
            throw new IllegalArgumentException(String.format(pattern, value.length, countArgs()), ex);
        }
    }

    public String toSql(String field, int position) {
        String[] args = new String[countArgs()];
        for (int i=0; i < countArgs(); i++) {
            args[i] = String.format("?%d", position + i);
        }
        return toSql(field, args);
    }
}
