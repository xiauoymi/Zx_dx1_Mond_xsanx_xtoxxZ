package com.industrysystem.persistence.daos.report;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 21/01/14
 * Time: 17:54
 */
public class ReportOrderBy {

    private String field = "";
    private boolean asc = true;

    public ReportOrderBy() {
    }

    public ReportOrderBy(String field, boolean asc) {
        this.field = field;
        this.asc = asc;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public boolean isAsc() {
        return asc;
    }

    public String toSql() {
        return asc ? field : String.format("%s desc", field);
    }
}
