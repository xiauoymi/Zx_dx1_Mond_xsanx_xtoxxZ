package com.industrysystem.persistence.daos.report;

import java.util.*;

/**
 * User: CGLLLO
 * Date: 21/01/14
 */
public class ReportRequest {

    private List<ReportFilter> filter = new ArrayList<ReportFilter>();
    private List<ReportOrderBy> orderBy = new ArrayList<ReportOrderBy>();
    private int page = 0;

    /**
     * Change report column names to query column names.
     */
    public void renameFields(Map<String, String> map) {
        for (ReportFilter reportFilter : filter) {
            String fieldName = reportFilter.getField();
            if (map.containsKey(fieldName)) {
                reportFilter.setField(map.get(fieldName));
            }
        }
        for (ReportOrderBy reportOrderBy : orderBy) {
            String fieldName = reportOrderBy.getField();
            if (map.containsKey(fieldName)) {
                reportOrderBy.setField(map.get(fieldName));
            }
        }
    }

    public ReportRequest setFieldParser(String field, StringParser<?> stringParser) {
        for (ReportFilter reportFilter : findFilter(field)) {
            reportFilter.parseValues(stringParser);
        }
        return this;
    }

    public ReportRequest setFieldClass(String field, Class<?> clazz) {
        for (ReportFilter reportFilter : findFilter(field)) {
            reportFilter.setClass(clazz);
        }
        return this;
    }

    private Collection<ReportFilter> findFilter(String field) {
        Collection<ReportFilter> result = new ArrayList<ReportFilter>();
        for (ReportFilter cursor : filter) {
            if (cursor.getField().equals(field)) {
                result.add(cursor);
            }
        }
        return result;
    }

    public List<ReportFilter> getFilter() {
        return filter;
    }

    public List<ReportOrderBy> getOrderBy() {
        return orderBy;
    }

    public int getPage() {
        return page;
    }

    public ReportRequest setPage(int page) {
        this.page = page;
        return this;
    }

    private ReportRequest addFilter(ReportFilter reportFilter) {
        filter.add(reportFilter);
        return this;
    }

    public ReportRequest addBetween(String field, Object from, Object to) {
        return addFilter(new ReportFilter(field, ReportOperator.between, from, to));
    }

    public ReportRequest addIn(String field, Object... values) {
        return addFilter(new ReportFilter(field, ReportOperator.in, values));
    }

    public ReportRequest addEquals(String field, Object value) {
        return addFilter(new ReportFilter(field, ReportOperator.eq, value));
    }

    public ReportRequest addOrderBy(String field, boolean asc) {
        orderBy.add(new ReportOrderBy(field, asc));
        return this;
    }

    public ReportRequest addOrderBy(String field) {
        return addOrderBy(field, true);
    }

    private String getQueryWithoutSelect(String baseQuery) {
        int index = indexOf(baseQuery, "from");
        return baseQuery.substring(index, baseQuery.length()).trim();
    }

    public String createCountQuery(String baseQuery) {
        baseQuery = "select count(*) " + getQueryWithoutSelect(baseQuery);
        return injectFilter(baseQuery);
    }

    public String createQuery(String baseQuery) {
        return injectOrderBy(injectFilter(baseQuery));
    }

    private String injectFilter(String baseQuery) {
        String toInject = filterToSql(baseQuery);
        int index = -1;
        for (String part : new String[] {"group by", "order by"}) {
            index = indexOf(baseQuery, part);
            if (index < baseQuery.length()) {
                break;
            }
        }
        return baseQuery.substring(0, index) + toInject + baseQuery.substring(index, baseQuery.length());
    }

    private String injectOrderBy(String query) {
        return query + orderByToSql(query.toLowerCase());
    }

    private String filterToSql(String baseQuery) {
        String separator = " and ";
        String prefix = getQueryWithoutSelect(baseQuery).toLowerCase().matches("^[^(]*\\swhere\\s.*$") ? separator.trim() : "where";
        return filter.isEmpty() ? "" : String.format(" %s %s", prefix, join(filter, separator, new Appender<ReportFilter>() {
            @Override
            public int append(ReportFilter reportFilter, StringBuilder stringBuilder, int position) {
                stringBuilder.append(reportFilter.toSql(position));
                return position + reportFilter.getOperator().countArgs();
            }
        }));
    }

    private String orderByToSql(String baseQuery) {
        String separator = ", ";
        String prefix = baseQuery.toLowerCase().matches("^.*\\sorder by\\s[^)]*$") ? separator.trim() : " order by";
        return orderBy.isEmpty() ? "" : String.format("%s %s", prefix, join(orderBy, separator, new Appender<ReportOrderBy>() {
            @Override
            public int append(ReportOrderBy reportOrderBy, StringBuilder stringBuilder, int position) {
                stringBuilder.append(reportOrderBy.toSql());
                return position + 1;
            }
        }));
    }

    interface Appender<T> {
        int append(T t, StringBuilder separator, int position);
    }

    private <T> String join(Collection<T> collection, String separator, Appender<T> appender) {
        StringBuilder stringBuilder = new StringBuilder();
        int i = 0;
        for (T t : collection) {
            if (i > 0) {
                stringBuilder.append(separator);
            }
            i = appender.append(t, stringBuilder, i);
        }
        return stringBuilder.toString();
    }

    private int indexOf(String query, String part) {
        int index = 0;
        if (!query.matches("^" + part.trim() + "\\s.*")) {
            int parenthesesCount = 0;
            part = String.format(" %s ", part);
            for (String queryPart : query.toLowerCase().split(part)) {
                index += queryPart.length();
                parenthesesCount += countNotClosedParentheses(queryPart);
                if (parenthesesCount == 0) {
                    break;
                }
                index += part.length();
            }
        }
        return index;
    }

    private int countNotClosedParentheses(String s) {
        int parenthesesCount = 0;
        for (int i=0; i<s.length(); i++) {
            switch (s.charAt(i)) {
                case '(':
                    parenthesesCount++;
                    break;
                case ')':
                    parenthesesCount--;
                    break;
            }
        }
        return parenthesesCount;
    }
}