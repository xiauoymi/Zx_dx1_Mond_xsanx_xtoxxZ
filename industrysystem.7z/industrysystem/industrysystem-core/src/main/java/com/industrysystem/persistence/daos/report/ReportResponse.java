package com.industrysystem.persistence.daos.report;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 03/02/14
 * Time: 17:18
 */
public class ReportResponse {

    private Collection<?> reportContent;
    private int totalPages;

    public ReportResponse(Collection<?> reportContent, int totalPages) {
        this.reportContent = reportContent;
        this.totalPages = totalPages;
    }

    public ReportResponse() {
        this(new ArrayList<Object>(), 0);
    }

    public Collection<?> getReportContent() {
        return reportContent;
    }

    public int getTotalPages() {
        return totalPages;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ReportResponse that = (ReportResponse) o;

        if (totalPages != that.totalPages) return false;
        if (reportContent != null ? !reportContent.equals(that.reportContent) : that.reportContent != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = reportContent != null ? reportContent.hashCode() : 0;
        result = 31 * result + totalPages;
        return result;
    }

    @Override
    public String toString() {
        return "ReportResponse{" +
                "reportContent=" + reportContent +
                ", totalPages=" + totalPages +
                '}';
    }
}
