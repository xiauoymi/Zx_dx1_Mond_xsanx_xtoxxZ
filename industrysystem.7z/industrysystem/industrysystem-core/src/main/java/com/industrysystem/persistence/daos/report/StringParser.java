package com.industrysystem.persistence.daos.report;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 03/02/14
 * Time: 15:44
 */
public interface StringParser<T> {
    T parse(String s);
}
