package com.industrysystem.persistence.daos.report;

import com.industrysystem.entities.CuantitativeTestRequest;
import com.industrysystem.entities.QualitativeTestRequest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 06/02/14
 * Time: 15:33
 */
public class StringParserFactory {

    private Map<Class, StringParser<?>> stringParsers = new HashMap<Class, StringParser<?>>();

    public static final StringParser<String> DEFAULT = new StringParser<String>() {
        @Override
        public String parse(String s) {
            return s;
        }
    };
    public static final StringParser<Boolean> BOOL = new StringParser<Boolean>() {
        @Override
        public Boolean parse(String s) {
            return Boolean.parseBoolean(s);
        }
    };
    public static final StringParser<Long> LONG = new StringParser<Long>() {
        @Override
        public Long parse(String s) {
            return Long.parseLong(s);
        }
    };
    public static final StringParser<Integer> INT = new StringParser<Integer>() {
        @Override
        public Integer parse(String s) {
            return Integer.parseInt(s);
        }
    };
    public static final StringParser<Double> DOUBLE = new StringParser<Double>() {
        @Override
        public Double parse(String s) {
            return Double.parseDouble(s);
        }
    };
    public static final StringParser<Float> FLOAT = new StringParser<Float>() {
        @Override
        public Float parse(String s) {
            return Float.parseFloat(s);
        }
    };
    public static final StringParser<Date> DATE = new StringParser<Date>() {
        @Override
        public Date parse(String s) {
            try {
                return new SimpleDateFormat("dd/MM/yyyy").parse(s);
            } catch (ParseException e) {
                throw new IllegalArgumentException(e);
            }
        }
    };
    /*public static final StringParser<Class> CLASS = new StringParser<Class>() {
        @Override
        public Class parse(String s) {
            try {
                if (s.equalsIgnoreCase("cuantitativo")){
                    return CuantitativeTestRequest.class;
                }
                if (s.equalsIgnoreCase("cualitativo")){
                    return QualitativeTestRequest.class;
                }
                throw new ClassNotFoundException();
            } catch (ClassNotFoundException e) {
                throw new IllegalArgumentException(e);
            }
        }
    }; */

    public StringParserFactory() {
        stringParsers.put(Boolean.class, BOOL);
        stringParsers.put(Long.class, LONG);
        stringParsers.put(Integer.class, INT);
        stringParsers.put(Float.class, FLOAT);
        stringParsers.put(Double.class, DOUBLE);
        stringParsers.put(Date.class, DATE);
    }

    public StringParser create(final Class<?> clazz) {
        if (clazz.isEnum()) {
            return new StringParser<Enum>() {
                @Override
                public Enum parse(String s) {
                    return Enum.valueOf((Class<? extends Enum>) clazz, s);
                }
            };
        }
        return stringParsers.containsKey(clazz) ? stringParsers.get(clazz) : DEFAULT;
    }
}
