package com.industrysystem.persistence.development;

import com.industrysystem.business.dtos.TestResultDto;
import com.industrysystem.entities.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;

import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.math.BigDecimal;
import java.util.*;

public abstract class DatabaseInitializer implements ApplicationListener<ContextRefreshedEvent> {

    @Autowired
    private EntityManagerFactory emf;

    @Value("${development_mode.initialize_database}")
    private String initializeDatabase;

    private DocumentType cuit;

    public void onApplicationEvent(ContextRefreshedEvent event) {
        if (Boolean.parseBoolean(initializeDatabase)) {
            EntityManager em = emf.createEntityManager();
            CriteriaBuilder builder = em.getCriteriaBuilder();
            CriteriaQuery<Crop> query = builder.createQuery(Crop.class);
            Root<Crop> variableRoot = query.from(Crop.class);
            query.select(variableRoot);
            if (em.createQuery(query).getResultList().isEmpty()) {
                em.getTransaction().begin();

                Province province = new Province();
                province.setCode(1L);
                province.setDescription("Buenos Aires");
                em.persist(province);

                Location location = new Location();
                location.setCode(3L);
                location.setProvince(province);
                location.setDescription("12 DE AGOSTO");
                em.persist(location);

                createDocumentTypes(em);

                Crop algodon = createCrop("ALGODON");
                Crop soja = createCrop("SOJA");
                em.persist(algodon);
                em.persist(soja);

                TraitOwner monsanto = createCompany("MONSANTO ARGENTINA");
                TraitOwner bayer = createCompany("BAYER");
                em.persist(monsanto);
                em.persist(bayer);

                Technology intacta = createTechnology("INTACTA", monsanto);
                Technology techBayer = createTechnology("BAYER_TECH", bayer);
                em.persist(intacta);
                em.persist(techBayer);

                CropTechnology intactaSoja = createCropTechnology(intacta, soja);
                CropTechnology intactaAlgodon = createCropTechnology(intacta,
                        algodon);
                CropTechnology bayerTechSoja = createCropTechnology(techBayer, soja);
                em.persist(intactaSoja);
                em.persist(intactaAlgodon);
                em.persist(bayerTechSoja);

                Grower juan = createGrower("Juan", "20244386379", cuit);
                Grower pedro = createGrower("Pedro", "20244386378", cuit);
                em.persist(juan);
                em.persist(pedro);

                GrowerAccount juanIntactaSoja = createAccount(juan, intactaSoja);
                GrowerAccount juanBayerSoja = createAccount(juan, bayerTechSoja);
                GrowerAccount pedroBayerSoja = createAccount(pedro, bayerTechSoja);
                em.persist(juanIntactaSoja);
                em.persist(juanBayerSoja);
                em.persist(pedroBayerSoja);
                Calendar date = Calendar.getInstance();

                date.set(2014, 1, 1);
                Date dateFrom = date.getTime();
                date.set(2014, 12, 31);
                Date  dateTo = date.getTime();
                Campaign nextCampaign = null;
                Campaign campaign2014 = createCampaign("14-15", "2014/15", CampaignStatus.ACTIVE, dateFrom,dateTo,nextCampaign);
                em.persist(campaign2014);

                date.set(2013, 1, 1);
                dateFrom = date.getTime();
                date.set(2013, 12, 31);
                dateTo = date.getTime();
                nextCampaign = campaign2014;
                Campaign campaign2013 = createCampaign("13-14", "2013/14", CampaignStatus.ACTIVE, dateFrom,dateTo,nextCampaign);
                em.persist(campaign2013);

                date.set(2012, 1, 1);
                dateFrom = date.getTime();
                date.set(2012, 12, 31);
                dateTo = date.getTime();
                nextCampaign = campaign2013;
                Campaign campaign2012 = createCampaign("12-13", "2012/13", CampaignStatus.ACTIVE, dateFrom,dateTo,nextCampaign);
                em.persist(campaign2012);

                CropTechnologyForCampaign intactaSoja2012 = createCropTechnologyForCampaign(intactaSoja, campaign2012, newDate(2013, 2, 1), newDate(2014, 1, 31), null);
                CropTechnologyForCampaign intactaSoja2013 = createCropTechnologyForCampaign(intactaSoja, campaign2013, newDate(2014, 2, 1), newDate(2015, 1, 31), null);
                CropTechnologyForCampaign intactaSoja2014 = createCropTechnologyForCampaign(intactaSoja, campaign2014, newDate(2014, 2, 1), newDate(2015, 1, 31), null);
                CropTechnologyForCampaign bayerTechSoja2012 = createCropTechnologyForCampaign(bayerTechSoja, campaign2012, newDate(2013, 2, 1), newDate(2014, 1, 31), null);
                em.persist(intactaSoja2012);
                em.persist(intactaSoja2013);
                em.persist(intactaSoja2014);
                em.persist(bayerTechSoja2012);

                GrowerBalance juanIntactaSoja2012GrowerBalance = createCropTechnologyForCampaignBalance(juanIntactaSoja, intactaSoja2012, BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ONE, BigDecimal.ONE);
                GrowerBalance juanIntactaSoja2013GrowerBalance = createCropTechnologyForCampaignBalance(juanIntactaSoja, intactaSoja2013, BigDecimal.valueOf(2), BigDecimal.valueOf(3), BigDecimal.valueOf(4), BigDecimal.valueOf(5), BigDecimal.valueOf(6), BigDecimal.valueOf(7), BigDecimal.valueOf(8), BigDecimal.valueOf(9));
                GrowerBalance juanIntactaSoja2014GrowerBalance = createCropTechnologyForCampaignBalance(juanIntactaSoja, intactaSoja2014, BigDecimal.valueOf(2), BigDecimal.valueOf(3), BigDecimal.valueOf(4), BigDecimal.valueOf(5), BigDecimal.valueOf(6), BigDecimal.valueOf(7), BigDecimal.valueOf(8), BigDecimal.valueOf(9));
                GrowerBalance juanBayerTechSoja2012GrowerBalance = createCropTechnologyForCampaignBalance(juanBayerSoja, bayerTechSoja2012, BigDecimal.valueOf(2), BigDecimal.valueOf(3), BigDecimal.valueOf(4), BigDecimal.valueOf(5), BigDecimal.valueOf(6), BigDecimal.valueOf(7), BigDecimal.valueOf(8), BigDecimal.valueOf(9));
                GrowerBalance pedroBayerTechSoja2012GrowerBalance = createCropTechnologyForCampaignBalance(pedroBayerSoja, bayerTechSoja2012, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO);
                em.persist(juanIntactaSoja2012GrowerBalance);
                em.persist(juanIntactaSoja2013GrowerBalance);
                em.persist(juanIntactaSoja2014GrowerBalance);
                em.persist(juanBayerTechSoja2012GrowerBalance);
                em.persist(pedroBayerTechSoja2012GrowerBalance);

                TraitOwnerMessage traitOwnerMessage = new TraitOwnerMessage();
                traitOwnerMessage.setTraitOwner(monsanto);
                traitOwnerMessage.setMessageSequence(1l);
                traitOwnerMessage.setWaybillMessages(new HashSet<WaybillMessage>());
                em.persist(traitOwnerMessage);

                this.internalOnQApplicationEvent(location, campaign2013, soja, cuit, intactaSoja, monsanto, intactaSoja2013, em);

                /**
                 * FS007-1	Access to Sample Determination Service. And Waybills actives must exist.	Complete Waybill number field  with valid information and  Waybill has at least one declaration	The information is saved and  parameter  Sampling responses indicates the value “NO”
                 */
                Waybill waybill = newWaybill(1111111019L);
                waybill.setCrop(soja);
                waybill.setHolderDeclaredIsPod(false);
                waybill.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
                waybill.setStatus(WaybillStatusEnum.RECEIVED);
                WagonLoadDetail wagonLoadDetail = new WagonLoadDetail();
                wagonLoadDetail.setWagonNumber("1234");
                wagonLoadDetail.setWaybill(waybill);
                Declaration declaration = new Declaration();
                declaration.setCropTechnology(intactaSoja);
                declaration.setLoadDetail(wagonLoadDetail);
                em.persist(waybill);
                em.persist(wagonLoadDetail);
                em.persist(declaration);

                /**
                 * FS007-2
                 The value on the Waybill Number field corresponds to a Waybill with attribute “Transporte automotor” and Waybill holder is POD and has no declaration   when the information is sent.
                 The information is saved and    parameter  Sampling responses indicates the value “YES”
                 */
                Waybill waybillcase2 = newWaybill(1111111112L);
                waybillcase2.setCrop(soja);
                waybillcase2.setHolderDeclaredIsPod(true);
                waybillcase2.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
                waybillcase2.setStatus(WaybillStatusEnum.RECEIVED);
                TruckLoadDetail truckLoadDetail = new TruckLoadDetail();
                truckLoadDetail.setWaybill(waybillcase2);
                em.persist(waybillcase2);
                em.persist(truckLoadDetail);

                /**
                 * FS007-3		The value on the Waybill Number field corresponds to a Waybill with attribute “Transporte automotor”
                 * and Waybill holder is Grower and has no declaration when the information is sent.
                 * The information is saved and    parameter  Sampling responses indicates the value “YES”
                 */
                Waybill waybillcase3 = newWaybill(1111111113L);
                waybillcase3.setCrop(soja);
                waybillcase3.setHolderDocument(new Document(cuit, "1"));
                waybillcase3.setHolderDeclaredIsPod(false);
                waybillcase3.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
                waybillcase3.setStatus(WaybillStatusEnum.RECEIVED);
                TruckLoadDetail truckLoadDetail3 = new TruckLoadDetail();
                truckLoadDetail3.setWaybill(waybillcase3);
                PodHeadOffice podHO = new PodHeadOffice();
                podHO.setDocument(new Document(cuit, "27500858628"));
                podHO.setName("Grower");
                PodBranch pod = new PodBranch();
                pod.setCommercialCode(1L);
                podHO.addPodBranch(pod);
                podHO.setMainPodBranch(pod);

                em.persist(waybillcase3);
                em.persist(truckLoadDetail3);
                em.persist(podHO);

                /**
                 * FS007-4		The value on the Waybill Number field corresponds to a Waybill with attribute
                 * “Transporte automotor” and Waybill holder is Participant POD
                 * and has no declaration   when the information is sent.
                 * The information is saved and parameter  Sampling responses always indicates the value “YES”
                 * if the “Random Sampling Function” returns “True”,
                 * or “NO” if the “Random Sampling Function” returns “False” for the same Waybill number
                 */
                Waybill waybillcase4 = newWaybill(1111111114L);
                waybillcase4.setCrop(soja);
                waybillcase4.setHolderDocument(new Document(cuit,"4"));
                waybillcase4.setHolderDeclaredIsPod(false);
                waybillcase4.setHolderDeclaredIsPod(true);
                waybillcase4.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
                waybillcase4.setStatus(WaybillStatusEnum.RECEIVED);
                TruckLoadDetail truckLoadDetail4 = new TruckLoadDetail();
                truckLoadDetail4.setWaybill(waybillcase4);

                PodHeadOffice podHO4 = new PodHeadOffice();
                podHO4.setDocument(new Document(cuit,"30500858628"));
                PodBranch pod4 = new PodBranch();
                podHO4.setName("Participant POD");
                pod4.setCommercialCode(1L);
                podHO4.addPodBranch(pod4);
                podHO4.setMainPodBranch(pod4);

                PodScoring podScoring4 = new PodScoring();
                podScoring4.setPod(pod4);
                SamplingCategory samplingCategory4 = new SamplingCategory();
                samplingCategory4.setProbability(new BigDecimal(0.5));
                podScoring4.setSamplingCategory(samplingCategory4);
                podScoring4.setTraitOwner(monsanto);
                em.persist(waybillcase4);
                em.persist(truckLoadDetail4);
                em.persist(samplingCategory4);
                em.persist(podHO4);
                em.persist(podScoring4);

                /**
                 * FS007-5		The value on the Waybill Number field corresponds to a Waybill with attribute
                 * “Vagón Ferroviario”, and a Load Detail indicates Waybill holder is POD and has no declaration
                 * when the information is sent.	For each WagonLoad N° the information is saved and parameter  Sampling responses indicates the value (N°WagonLoad,YES)
                 */
                Waybill waybillcase5 = newWaybill(1111111115L);
                waybillcase5.setCrop(soja);
                waybillcase5.setHolderDocument(new Document(cuit, "8"));
                waybillcase5.setHolderDeclaredIsPod(true);
                waybillcase5.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
                waybillcase5.setDestination(createPodBranch(em, "head office pi 5", "55", cuit, 555L));
                waybillcase5.setStatus(WaybillStatusEnum.RECEIVED);
                WagonLoadDetail wagonLoadDetail1 = new WagonLoadDetail();
                wagonLoadDetail1.setWagonNumber("51234-1");
                wagonLoadDetail1.setWaybill(waybillcase5);
                WagonLoadDetail wagonLoadDetail2 = new WagonLoadDetail();
                wagonLoadDetail2.setWagonNumber("51234-2");
                wagonLoadDetail2.setWaybill(waybillcase5);
                WagonLoadDetail wagonLoadDetail3 = new WagonLoadDetail();
                wagonLoadDetail3.setWagonNumber("51234-3");
                wagonLoadDetail3.setWaybill(waybillcase5);
                em.persist(waybillcase5);
                em.persist(wagonLoadDetail1);
                em.persist(wagonLoadDetail2);
                em.persist(wagonLoadDetail3);

                /**
                 * FS007-6		The value on the Waybill Number field corresponds to a Waybill with attribute “Vagón Ferroviario”,
                 * and a Load Detail indicates Waybill holder is Grower and has no declaration   when the information is sent.
                 * For each WagonLoad N° the information is saved and parameter  Sampling responses indicates the value (N°WagonLoad,YES)
                 */
                Waybill waybillcase6 = newWaybill(1111111116L);
                waybillcase6.setCrop(soja);
                waybillcase6.setHolderDeclaredIsPod(false);
                waybillcase6.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
                waybillcase6.setStatus(WaybillStatusEnum.RECEIVED);
                WagonLoadDetail wagonLoadDetail61 = new WagonLoadDetail();
                wagonLoadDetail61.setWagonNumber("61234-1");
                wagonLoadDetail61.setWaybill(waybillcase6);
                WagonLoadDetail wagonLoadDetail62 = new WagonLoadDetail();
                wagonLoadDetail62.setWagonNumber("61234-2");
                wagonLoadDetail62.setWaybill(waybillcase6);
                WagonLoadDetail wagonLoadDetail63 = new WagonLoadDetail();
                wagonLoadDetail63.setWagonNumber("61234-3");
                wagonLoadDetail63.setWaybill(waybillcase6);
                em.persist(waybillcase6);
                em.persist(wagonLoadDetail61);
                em.persist(wagonLoadDetail62);
                em.persist(wagonLoadDetail63);

                /****
                 * FS007-7		The value on the Waybill Number field corresponds to an Waybill with attribute “Vagón Ferroviario”,
                 * and a Load Detail indicates Waybill holder is Participant POD and has no declaration
                 * when the information is sent	For each WagonLoad N° the information is saved and parameter
                 * Sampling responses indicates the value YES”
                 * if the “Random Sampling Function” returns “True”, or “NO” if the “Random Sampling Function”
                 * returns “False” for the same Waybill number
                 */
                Waybill waybillcase7 = newWaybill(1111111117L);
                waybillcase7.setCrop(soja);
                waybillcase7.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
                waybillcase7.setHolderDeclaredIsPod(true);
                waybillcase7.setHolderDocument(new Document(cuit, "20295426811"));
                waybillcase7.setStatus(WaybillStatusEnum.RECEIVED);
                PodHeadOffice pod7HO=new PodHeadOffice();
                pod7HO.setDocument(new Document(cuit, "20295426811"));
                pod7HO.setName("Participant POD");
                PodBranch pod7 = new PodBranch();
                pod7.setCommercialCode(1L);
                pod7HO.addPodBranch(pod7);
                pod7HO.setMainPodBranch(pod7);

                PodScoring podScoring7 = new PodScoring();
                podScoring7.setPod(pod7);
                SamplingCategory samplingCategory7 = new SamplingCategory();
                samplingCategory7.setProbability(new BigDecimal(0.5));
                podScoring7.setSamplingCategory(samplingCategory7);
                podScoring7.setTraitOwner(monsanto);
                WagonLoadDetail wagonLoadDetail71 = new WagonLoadDetail();
                wagonLoadDetail71.setWagonNumber("71234-1");
                wagonLoadDetail71.setWaybill(waybillcase7);
                WagonLoadDetail wagonLoadDetail72 = new WagonLoadDetail();
                wagonLoadDetail72.setWagonNumber("71234-2");
                wagonLoadDetail72.setWaybill(waybillcase7);
                WagonLoadDetail wagonLoadDetail73 = new WagonLoadDetail();
                wagonLoadDetail73.setWagonNumber("71234-3");
                wagonLoadDetail73.setWaybill(waybillcase7);
                em.persist(waybillcase7);
                em.persist(wagonLoadDetail71);
                em.persist(wagonLoadDetail72);
                em.persist(wagonLoadDetail73);
                em.persist(samplingCategory7);
                em.persist(pod7HO);
                em.persist(podScoring7);

                // FS007-12		Complete Waybill number field with valid information and Waybill has at least one declaration.
                // Close the system and repeat steps  with same Waybill number	The information is saved and  parameter  Sampling responses always
                // indicates the value “NO”  for the same Waybill number
                Waybill waybillcase12 = newWaybill(1111111118L);
                waybillcase12.setCrop(soja);
                waybillcase12.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
                waybillcase12.setHolderDeclaredIsPod(true);
                waybillcase12.setHolderDocument(new Document(cuit, "12"));
                waybillcase12.setStatus(WaybillStatusEnum.RECEIVED);
                Declaration declaration12 = new Declaration();
                declaration12.setCropTechnology(intactaSoja);
                TruckLoadDetail truckLoadDetail12 = new TruckLoadDetail();
                truckLoadDetail12.setWaybill(waybillcase12);
                declaration12.setLoadDetail(truckLoadDetail12);
                em.persist(waybillcase12);
                em.persist(truckLoadDetail12);
                em.persist(declaration12);

                createDataForFS019(soja, intactaSoja, em);

                //FS016-2
                /**
                 * The user adds the WB number, Load Identifier and test (quantitative or qualitative) results and enters “Transporte automotor” as WB transport type code
                 */
                truckLoadDetail.setSampleRequired(true);
                Laboratory lab = new Laboratory();
                lab.setCode("162");
                Laboratory lab2 = new Laboratory();
                lab2.setCode("163");
                Laboratory lab3 = new Laboratory();
                lab3.setCode("164");
                lab3.setCanPerformCuantitativeTests(true);

                /**
                 * FS016-3
                 *  The user adds the WB number, Load Identifier and test (quantitative or qualitative) results and enters “Vagón Ferroviario” as WB transport type code.
                 */
                wagonLoadDetail2.setSampleRequired(true);

                /**
                 *  FS016-5
                 *   POD System requests IS to store the sample code for a WB
                 *	The user enters a sample code that does not match the WB.
                 *	The system validates the entered sample code.
                 *   The system will display:”The waybill {Waybill number} doesn’t require a sample code.”
                 */
                wagonLoadDetail3.setSampleRequired(false);

                /**
                 * FS016-8		The user enters a WB that does not require a test.
                 The system validates that the WB does not require a test sample.
                 The system will display:”The Lab witch code is {Laboratory Code} doesn´t perform the type of test the waybill requires”
                 */
                lab.setCanPerformCuantitativeTests(false);
                CuantitativeTestRequest ctr = new CuantitativeTestRequest();
                ctr.setLoadDetail(wagonLoadDetail2);
                wagonLoadDetail1.setSampleRequired(true);
                wagonLoadDetail2.setSampleRequired(true);
                wagonLoadDetail3.setSampleRequired(true);
                lab2.setCanPerformCuantitativeTests(false);
                QualitativeTestRequest crq = new QualitativeTestRequest();
                crq.setLoadDetail(truckLoadDetail);
                crq.setCropTechnologyForCampaign(intactaSoja2013);

                em.persist(lab);
                em.persist(lab2);
                em.persist(lab3);
                em.persist(ctr);
                em.persist(crq);

                createTypeOfTestData(em, soja, intactaSoja2013, cuit);

                em.getTransaction().commit();
            }
            em.close();
        }
    }

    protected PodBranch createPodBranch(EntityManager em, String name, String docNumber, DocumentType documentType, Long commercialCode) {
        PodHeadOffice headOffice = new PodHeadOffice();
        PodBranch branch = new PodBranch();
        headOffice.setDocument(new Document(documentType ,docNumber));
        headOffice.setName(name);
        branch.setCommercialCode(commercialCode);
        headOffice.addPodBranch(branch);
        headOffice.setMainPodBranch(branch);
        try {
            em.persist(headOffice);
        } catch(EntityExistsException ex) {
            ex.printStackTrace();
            // it's ok
        }
        return branch;
    }

    protected abstract void internalOnQApplicationEvent(Location location, Campaign campaign2013, Crop soja, DocumentType cuit, CropTechnology intactaSoja, TraitOwner monsanto, CropTechnologyForCampaign intactaSoja2013, EntityManager em);

    protected abstract Waybill newWaybill(Long waybillIdentifier);

    private void createTypeOfTestData(EntityManager em, Crop crop, CropTechnologyForCampaign intactaSoja2013, DocumentType cuit) {
        create_StoreTestResult_Test1_data(em, crop, cuit);

        /*
        Test 1 : storeTestResultService throw TestRequestsNotFoundException
            find a loadDetail when findLoadDetailsBySampleCodeAndWaybillDestinationDocumentNumber is called.
                sampleCode : "sc 999"
                destinationDocumentNumber : "ddnpi1"
            don't find TestRequest when findByLoadDetail is called.
        */
        String sampleCode = "1";
        String destinationDocumentNumber = "2";
        List<TestResultDto> testResults = new ArrayList<TestResultDto>();

        create_StoreTestResult_Test3_data(em, crop);

        create_StoreTestResult_Test4_data(em, crop);

        create_StoreTestResult_Test5_data(em, crop);

        create_StoreTestResult_Test6_data(em, crop, intactaSoja2013);
    }

    private void create_StoreTestResult_Test1_data(EntityManager em, Crop crop, DocumentType cuit) {
        // waybill for 1 cuantitative test request
        // waybill number 999
        // 1 loadDetail (sc 999) with sample required
        // Grower
        Waybill waybill_1 = newWaybill(1111111119L);
        waybill_1.setCrop(crop);
        waybill_1.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        waybill_1.setHolderDeclaredIsPod(false);
        waybill_1.setHolderDocument(new Document(cuit,"12"));

        LoadDetail loadDetail_1 = new TruckLoadDetail();
        loadDetail_1.setSampleRequired(true);
        loadDetail_1.setSampleCode("sc 999");
        Set loadDetails = new HashSet<LoadDetail>();
        loadDetails.add(loadDetail_1);

        waybill_1.setLoadDetails(loadDetails);
        loadDetail_1.setWaybill(waybill_1);

        // croptecheforCamp : intactaSoja2013
        em.persist(waybill_1);
        em.persist(loadDetail_1);
    }

    private void create_StoreTestResult_Test3_data(EntityManager em, Crop crop) {
        /*
        TEST 3
        Input:
            sampleCode = "pi3"
            WaybillDestinationDocumentNumber = "pi3"
            a list of TestResultData empty
        Given :
            a loadDetail
            a list of TestRequest with 1 CuantitativeTestRequest assigned to the loadDetail
            the loadDetail found when findLoadDetailsBySampleCodeAndWaybillDestinationDocumentNumber is called.
            the list of TestRequest found when findByLoadDetail is called.
        Then :
            a TestRequestWithoutTestResultException is thrown
        */
        Waybill waybill_3 = newWaybill(1111111110L);
        waybill_3.setCreationDate(new Date());
        waybill_3.setCrop(crop);
        waybill_3.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        waybill_3.setHolderDeclaredIsPod(false);
        waybill_3.setDestination(createPodBranch(em, "head office pi 3", "33", cuit, 333L));

        LoadDetail loadDetail_3 = new TruckLoadDetail();
        loadDetail_3.setSampleCode("pi3");
        Set loadDetails_3 = new HashSet<LoadDetail>();
        loadDetails_3.add(loadDetail_3);

        waybill_3.setLoadDetails(loadDetails_3);
        loadDetail_3.setWaybill(waybill_3);

        CuantitativeTestRequest ctr_3 = new CuantitativeTestRequest();
        ctr_3.setLoadDetail(loadDetail_3);

        em.persist(waybill_3);
        em.persist(loadDetail_3);
        em.persist(ctr_3);
    }

    private void create_StoreTestResult_Test4_data(EntityManager em, Crop crop) {
        /*
        ----------------------------------------------------------------------------
        TEST 4
        Input:
            sampleCode = "pi4"
            WaybillDestinationDocumentNumber = "pi4"
            a list of TestResultData (qualitatives or quantitatives) not empty
        Given :
            a loadDetail
            no TestRequest assigned to the loadDetail
            the loadDetail found when findLoadDetailsBySampleCodeAndWaybillDestinationDocumentNumber is called.
        Then :
            a TestResultWithoutTestRequestException is thrown
        */
        Waybill waybill = newWaybill(1111111011L);
        waybill.setCrop(crop);
        waybill.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        waybill.setHolderDeclaredIsPod(false);

        LoadDetail loadDetail = new TruckLoadDetail();
        loadDetail.setSampleCode("pi4");
        Set loadDetails = new HashSet<LoadDetail>();
        loadDetails.add(loadDetail);

        waybill.setLoadDetails(loadDetails);
        loadDetail.setWaybill(waybill);

        em.persist(waybill);
        em.persist(loadDetail);
    }

    private void create_StoreTestResult_Test5_data(EntityManager em, Crop crop) {
        /*
        TEST 5
        Input:
            sampleCode = "pi5"
            WaybillDestinationDocumentNumber = "pi5"
            a list of QuantitativeTestResult
        Given :
            a loadDetail identified by the sampleCode and the WaybillDestinationDocumentNumber
            a QuantitativeTestRequest assigned to the loadDetail
        Then :
            a TestResult must be created and associated to the loadDetail and the TestRequest
        */

        Waybill waybill = newWaybill(1111111012L);
        waybill.setCreationDate(new Date());
        waybill.setCrop(crop);
        waybill.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        waybill.setDestination(createPodBranch(em, "head office pi 6", "66", cuit, 666L));
        waybill.setHolderDeclaredIsPod(false);

        LoadDetail loadDetail = new TruckLoadDetail();
        loadDetail.setSampleCode("pi5");
        Set loadDetails = new HashSet<LoadDetail>();
        loadDetails.add(loadDetail);

        waybill.setLoadDetails(loadDetails);
        loadDetail.setWaybill(waybill);

        CuantitativeTestRequest ctr = new CuantitativeTestRequest();
        ctr.setLoadDetail(loadDetail);

        em.persist(waybill);
        em.persist(loadDetail);
        em.persist(ctr);
    }

    private void create_StoreTestResult_Test6_data(EntityManager em, Crop crop, CropTechnologyForCampaign intactaSoja2013) {
        /*
        TEST 6
        Input:
            sampleCode = "pi6"
            WaybillDestinationDocumentNumber = "pi6"
            a list of QualitativeTestResult with 1 testResult
        Given :
            a loadDetail identified by sampleCode and WaybillDestinationDocumentNumber
            a QualitativeTestRequest assigned to the loadDetail and associated with the testResult
        Then :
            a QualitativeTestResult must be created and associated with the testRequest
        */

        Waybill waybill = newWaybill(1111111013L);
        waybill.setCreationDate(new Date());
        waybill.setCrop(crop);
        waybill.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        waybill.setDestination(createPodBranch(em, "head office pi 7", "77", cuit, 777L));
        waybill.setHolderDeclaredIsPod(false);

        LoadDetail loadDetail = new TruckLoadDetail();
        loadDetail.setSampleCode("pi6");
        Set loadDetails = new HashSet<LoadDetail>();
        loadDetails.add(loadDetail);

        waybill.setLoadDetails(loadDetails);
        loadDetail.setWaybill(waybill);

        QualitativeTestRequest ctr = new QualitativeTestRequest();
        ctr.setLoadDetail(loadDetail);
        ctr.setCropTechnologyForCampaign(intactaSoja2013);

        em.persist(waybill);
        em.persist(loadDetail);
        em.persist(ctr);
    }

    private void createDataForFS019(Crop crop, CropTechnology cropTechnology, EntityManager em) {
        this.case1OfFS019(crop, em, cropTechnology);
        this.case2And3And4And6OfFS019(crop, em, cropTechnology);
        this.case8OfFS019(crop, em, cropTechnology);

    }

    private void case8OfFS019(Crop crop, EntityManager em, CropTechnology cropTechnology) {
        Waybill waybill = newWaybill(1111111016L);
        waybill.setCrop(crop);
        waybill.setHolderDeclaredIsPod(false);
        waybill.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        WagonLoadDetail wagonLoadDetail = new WagonLoadDetail();
        wagonLoadDetail.setWagonNumber("190031");
        wagonLoadDetail.setWaybill(waybill);
        em.persist(waybill);
        em.persist(wagonLoadDetail);
    }

    /**
     * FS019 - 2: (10/10/2013)
     * - The value on the Waybill Number field corresponds to a WB with attribute “Vagón Ferroviario” and
     * Load Identifier field is correct when the information is sent
     * - The information is saved and returns a message of success
     * FS019 - 3: (10/10/2013)
     * - The value on the Waybill Number field corresponds to a WB with attribute “Vagón Ferroviario” and Load
     * Identifier field is empty when the information is sent
     * - The information is not sent to IS and returns an error message: “The Load Number is required because the
     * waybill’s type of transport is train”
     * FS019 - 4: (10/10/2013)
     * - The value on the Waybill Number field corresponds to a WB with attribute “Vagón Ferroviario” and Load
     * Identifier field is not associated with the WB when the information is sent
     * - The information is not sent to IS and returns an error message: “The Load  {Load identifier} doesn’t match with
     * any waybill associated valid code “
     * FS019 - 6: (10/10/2013)
     * - The value on the Waybill Number field does not exist on SI Database when the information is sent
     * - The information is not sent to IS and returns an error message: “There is no Waybill matching document for the
     * Waybill number {waybill number}.”
     */
    private void case2And3And4And6OfFS019(Crop crop, EntityManager em, CropTechnology cropTechnology) {
        Waybill waybill = newWaybill(1111111017L);
        waybill.setCrop(crop);
        waybill.setHolderDeclaredIsPod(false);
        waybill.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        WagonLoadDetail wagonLoadDetail = new WagonLoadDetail();
        wagonLoadDetail.setWagonNumber("190021");
        wagonLoadDetail.setWaybill(waybill);
        Declaration declaration = new Declaration();
        declaration.setCropTechnology(cropTechnology);
        declaration.setLoadDetail(wagonLoadDetail);
        wagonLoadDetail.setSampleRequired(false);
        em.persist(waybill);
        em.persist(wagonLoadDetail);
        em.persist(declaration);
    }

    /**
     * FS019 - 1: (10/10/2013)
     * - The value on the Waybill Number field corresponds to a WB with attribute “Transporte automotor” when
     * the information is sent.
     * - The information is saved and returns a message of success
     */
    private void case1OfFS019(Crop crop, EntityManager em, CropTechnology cropTechnology) {
        Waybill waybill = newWaybill(1111111018L);
        waybill.setCrop(crop);
        waybill.setHolderDeclaredIsPod(false);
        waybill.setTransportType(TransportType.TRANSPORTE_AUTOMOTOR);
        TruckLoadDetail truckLoadDetail = new TruckLoadDetail();
        truckLoadDetail.setCtg("190011");
        truckLoadDetail.setWaybill(waybill);
        Declaration declaration = new Declaration();
        declaration.setCropTechnology(cropTechnology);
        declaration.setLoadDetail(truckLoadDetail);
        truckLoadDetail.setSampleRequired(false);
        em.persist(waybill);
        em.persist(truckLoadDetail);
        em.persist(declaration);
    }

    private GrowerBalance createCropTechnologyForCampaignBalance(GrowerAccount growerAccount, CropTechnologyForCampaign cropTechnologyForCampaign, BigDecimal available, BigDecimal availableTransfer, BigDecimal expired, BigDecimal extended, BigDecimal extenderTransfer, BigDecimal pending, BigDecimal usable, BigDecimal used) {
        GrowerBalance growerBalance = new GrowerBalance();
        growerBalance.setGrowerAccount(growerAccount);
        growerBalance.setCropTechnologyForCampaign(cropTechnologyForCampaign);
        growerBalance.setAvailable(available);
        growerBalance.setAvailableTransfer(availableTransfer);
        growerBalance.setExpired(expired);
        growerBalance.setExtended(extended);
        growerBalance.setExtenderTransfer(extenderTransfer);
        growerBalance.setPending(pending);
        growerBalance.setUnusable(usable);
        growerBalance.setUsed(used);
        return growerBalance;
    }

    private CropTechnologyForCampaign createCropTechnologyForCampaign(CropTechnology cropTechnology, Campaign campaign, Date fromDate, Date expiryDate, Date extendedExpiryDate) {
        CropTechnologyForCampaign cropTechnologyForCampaign = new CropTechnologyForCampaign();
        cropTechnologyForCampaign.setCampaign(campaign);
        cropTechnologyForCampaign.setCropTechnology(cropTechnology);
        cropTechnologyForCampaign.setDateFrom(fromDate);
        cropTechnologyForCampaign.setExtensionDate(extendedExpiryDate);
        cropTechnologyForCampaign.setDateTo(expiryDate);
        return cropTechnologyForCampaign;
    }

    private Campaign createCampaign(String code, String description, CampaignStatus status,Date dateFrom,Date dateTo, Campaign nextCampaign) {
        Campaign campaign = new Campaign();
        campaign.setDescription(description);
        campaign.setStatus(status);
        campaign.setCode(code);
        campaign.setDateFrom(dateFrom);
        campaign.setDateTo(dateTo);
        campaign.setNext(nextCampaign);
        return campaign;
    }

    private GrowerAccount createAccount(Grower grower, CropTechnology cropTechnology) {
        GrowerAccount growerAccount = new GrowerAccount();
        growerAccount.setGrower(grower);
        growerAccount.setCropTechnology(cropTechnology);
        growerAccount.setNumber(grower.getDocument().getNumber() + "-" + cropTechnology.getId());
        return growerAccount;
    }

    private Grower createGrower(String name, String documentNumber, DocumentType cuit) {
        Grower grower = new Grower();
        grower.setName(name);
        grower.setDocument(new Document(cuit, documentNumber));
        return grower;
    }

    private CropTechnology createCropTechnology(Technology technology, Crop crop) {
        CropTechnology ct = new CropTechnology();
        ct.setCrop(crop);
        ct.setTechnology(technology);
        return ct;
    }

    private Technology createTechnology(String string, TraitOwner traitOwner) {
        Technology tech = new Technology();
        tech.setCode(string);
        tech.setDescription(string);
        tech.setTraitOwner(traitOwner);
        return tech;
    }

    private TraitOwner createCompany(String string) {
        TraitOwner traitOwner = new TraitOwner();
        traitOwner.setCode(string);
        return traitOwner;
    }

    private Crop createCrop(String string) {
        Crop crop = new Crop();
        crop.setCode(string);
        return crop;
    }

    /**
     * Costruct a Date with the given expiryDate part without time part
     *
     * @param year  the number of the year (4 digits)
     * @param month the month number (january = 1)
     * @param day   the day of the month (1-31)
     * @return a Date
     */
    private static Date newDate(int year, int month, int day) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(year, month - 1, day);
        return c.getTime();
    }

    private void createDocumentTypes(EntityManager em) {
        DocumentType dt;

        cuit = new DocumentType();
        cuit.setCode(DocumentType.CUIT);
        cuit.setDescription("Tipo de documento de Argentina");
        em.persist(cuit);

        dt = new DocumentType();
        dt.setCode(DocumentType.CEDULA);
        dt.setDescription("Tipo de documento de Paraguay. Formato: entre 6 y 8 dig.");
        em.persist(dt);

        dt = new DocumentType();
        dt.setCode(DocumentType.RUC_PJ);
        dt.setDescription("Tipo de documento de Paraguay. Formato : entre 6 y 7 dig + guion + 1 dig.");
        em.persist(dt);

        dt = new DocumentType();
        dt.setCode(DocumentType.RUC_SOCIEDAD);
        dt.setDescription("Tipo de documento de Paraguay. Formato : 800 + 5 dig + guion + 1 dig.");
        em.persist(dt);
    }

}