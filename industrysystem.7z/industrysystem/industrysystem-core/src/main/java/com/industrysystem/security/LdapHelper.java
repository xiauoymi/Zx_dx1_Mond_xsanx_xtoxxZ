package com.industrysystem.security;

import com.google.common.base.Function;
import com.industrysystem.exceptions.DirectorySearchResultsException;
import com.industrysystem.security.groups.FunctionalSecurityGroup;
import com.industrysystem.security.groups.SecurityGroup;
import com.industrysystem.security.mappers.IndustrySystemGroupContextMapper;
import com.industrysystem.security.mappers.IndustrySystemUserContextMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import org.springframework.security.crypto.keygen.BytesKeyGenerator;
import org.springframework.security.crypto.keygen.KeyGenerators;
import org.springframework.security.ldap.userdetails.InetOrgPerson;
import org.springframework.security.ldap.userdetails.InetOrgPersonContextMapper;

import javax.naming.InvalidNameException;
import javax.naming.Name;
import javax.naming.NamingException;
import javax.naming.directory.*;
import javax.naming.ldap.LdapName;
import javax.naming.ldap.Rdn;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Lists.transform;
import static java.util.Collections.max;

/**
 * User: PPERA
 * Date: 6/26/13
 * Time: 11:25 AM
 */

public abstract class LdapHelper {

    protected static final String GID_NUMBER = "gidNumber";
    protected static final String POSIX_GROUP = "posixGroup";
    protected static final String USER_PASSWORD = "userPassword";
    protected static final String OBJECT_CLASS = "objectClass";
    public static final String CN = "cn";
    public static final String OU = "ou";
    public static final String UID = "uid";
    public static final String SN = "sn";
    public static final String MAIL = "mail";
    public static final String POSIX_ACCOUNT = "posixAccount";
    public static final String INET_ORG_PERSON = "inetOrgPerson";
    public static final String ORGANIZATIONAL_PERSON = "organizationalPerson";
    public static final String PERSON = "person";
    public static final String MEMBER_UID = "memberUid";
    public static final String GROWER = "grower";
    public static final String MULTIPLIER = "multiplier";
    public static final String POD = "pod";
    public static final String RETAILER = "retailer";
    public static final String SERVICE_ACCOUNT = "service_account";
    public static final String TRAITOWNER = "traitowner";

    @Value("${ldap.groups.base}")
    private String groupsBase;

    @Value("${ldap.users.base}")
    private String usersBase;

    @Autowired
    private LdapTemplate ldapTemplate;

    @Autowired
    private InetOrgPersonContextMapper inetOrgPersonContextMapper;

    @Autowired
    private IndustrySystemUserContextMapper industrySystemUserContextMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    private final BytesKeyGenerator saltGenerator = KeyGenerators.secureRandom();

    public DirContextAdapter makeGroupObject(String document) {
        DirContextAdapter dirContextAdapter = new DirContextAdapter();
        dirContextAdapter.addAttributeValue(OBJECT_CLASS, POSIX_GROUP);
        dirContextAdapter.setAttributeValue(CN, document);
        dirContextAdapter.addAttributeValue(GID_NUMBER, this.makeGidNumber());
        return dirContextAdapter;
    }


    public DirContext getAuthenticatedContext(String userDn, String password) {
        return ldapTemplate.getContextSource().getContext(userDn + "," + this.getLdapRoot(), password);
    }

    public List<String> findAllRoleNames() {
        return newArrayList(GROWER, MULTIPLIER, POD, RETAILER, SERVICE_ACCOUNT, TRAITOWNER);
    }

    public List<SecurityGroup> findAllGroups() {
        return ldapTemplate.search(groupsBase, OBJECT_CLASS + "=" + POSIX_GROUP, new IndustrySystemGroupContextMapper());
    }

    public void changePassword(String uid, String oldPassword, String newPassword) throws NamingException {
        String userDn = CN + "=" + uid + "," + usersBase;
        DirContext ctx = this.getAuthenticatedContext(userDn, oldPassword);
        doSetNewPassword(newPassword, userDn, ctx);
    }

    protected abstract String getLdapRoot();

    public void resetPassword(String uid, String newPassword, String adminUser, String adminUserPassword) throws NamingException {
        String userDn = CN + "=" + uid + "," + usersBase;
        DirContext ctx = this.getAuthenticatedContext(adminUser, adminUserPassword);
        doSetNewPassword(newPassword, userDn, ctx);
    }

    private void doSetNewPassword(String newPassword, String userDn, DirContext ctx) throws NamingException {
        try {
            modifyPassword(userDn, newPassword, ctx);
        } finally {
            if (ctx != null) {
                ctx.close();
            }
        }
    }

    public void addUserToGroup(String uid, FunctionalSecurityGroup securityGroup, DirContext adminContext) throws NamingException {
        ModificationItem[] modItems = new ModificationItem[] {
            new ModificationItem(DirContext.ADD_ATTRIBUTE, new BasicAttribute(MEMBER_UID, uid))
        };
        adminContext.modifyAttributes(CN + "=" + securityGroup.getGroupName() + "," + OU + "=" + securityGroup.getRoleName() +
                "," + groupsBase, modItems);
    }

    public Name buildUserDn(String uid) throws InvalidNameException {
        LdapName ldapName = new LdapName(usersBase);
        ldapName.add(new Rdn(CN, uid));
        return ldapName;
    }

    public Name buildGroupDn(String groupName, String document) throws InvalidNameException {
        LdapName ldapName = new LdapName(groupsBase);
        ldapName.add(new Rdn(OU, groupName));
        ldapName.add(new Rdn(CN, document));
        return ldapName;
    }

    public DirContextAdapter makeUserObject(String uid, String sn, String userPassword, String email) {
        DirContextAdapter dirContextAdapter = new DirContextAdapter();
        InetOrgPerson.Essence essence = new InetOrgPerson.Essence();

        essence.setCn(new String[]{uid});
        essence.setUid(uid);
        essence.setSn(sn);
        essence.setPassword(passwordEncoder.encodePassword(userPassword, randSalt()));
        essence.setMail(email);
        essence.setDn(CN + "=" + uid + "," + this.usersBase + "," + this.getLdapRoot());

        InetOrgPerson inetOrgPerson = (InetOrgPerson) essence.createUserDetails();

        inetOrgPersonContextMapper.mapUserToContext(inetOrgPerson, dirContextAdapter);
        return dirContextAdapter;
    }

    private void modifyPassword(String userDn, String newPassword, DirContext ctx) throws NamingException {
        ModificationItem[] mods;
        mods = createModificationItems(userDn, newPassword, ctx);
        ctx.modifyAttributes(userDn, mods);
    }

    private ModificationItem[] createModificationItems(String userDn, String newPassword, DirContext ctx) throws NamingException {
        Attributes attributes;
        attributes = ctx.getAttributes(userDn, new String[] {USER_PASSWORD});
        Attribute passwordAttributeToRemove = attributes.getAll().nextElement();
        ModificationItem[] mods = new ModificationItem[2];
        mods[0] = new ModificationItem(DirContextOperations.REMOVE_ATTRIBUTE, passwordAttributeToRemove);
        mods[1] = new ModificationItem(DirContextOperations.ADD_ATTRIBUTE, new BasicAttribute(USER_PASSWORD,
                passwordEncoder.encodePassword(newPassword, randSalt())));
        return mods;
    }

    public InetOrgPerson findPersonByEmailAddress(String emailAddress) throws DirectorySearchResultsException {
        List<InetOrgPerson> peopleByEmail = searchPeopleBySingleAtribute(MAIL, emailAddress);

        if (peopleByEmail.isEmpty()) {
            throw new DirectorySearchResultsException(0);
        }
        if (peopleByEmail.size() > 1) {
            throw new DirectorySearchResultsException(peopleByEmail.size());
        }
        return peopleByEmail.iterator().next();
    }

    public boolean isExistentUser(String username) {
        List matchingUsers = ldapTemplate.search(usersBase, new EqualsFilter(UID, username).encode(), SearchControls.SUBTREE_SCOPE,
                newISUserAttributesMapper());
        return !matchingUsers.isEmpty();
    }

    protected abstract AttributesMapper newISUserAttributesMapper();

    @SuppressWarnings("unchecked")
    private List<InetOrgPerson> searchPeopleBySingleAtribute(String attributeName, String attributeValue) {
        return ldapTemplate.search(usersBase, attributeName + "=" + attributeValue, industrySystemUserContextMapper);
    }

    private String makeGidNumber() {
        AttributesMapper attributesMapper = gidNumberAttributeMapper();
        List<BasicAttribute> gidNumberAttributes = ldapTemplate.search(groupsBase, "(|(" + OBJECT_CLASS + "=" + POSIX_GROUP +
                ")(" + OBJECT_CLASS + "=" + POSIX_ACCOUNT + "))", attributesMapper);
        List<Integer> gidNumbers = numberAttributeListToIntegerList(gidNumberAttributes);
        return Integer.toString(max(gidNumbers) + 1);
    }

    private List<Integer> numberAttributeListToIntegerList(List<BasicAttribute> gidNumberAttributes) {
        return transform(gidNumberAttributes, new Function<BasicAttribute, Integer>() {
            @Override
            public Integer apply(BasicAttribute input) {
                try {
                    return Integer.valueOf(input.get().toString());
                } catch (NamingException e) {
                    // TODO do something with this exception
                    return null;
                }
            }
        });
    }

    private AttributesMapper gidNumberAttributeMapper() {
        return new AttributesMapper() {
            @Override
            public Object mapFromAttributes(Attributes attributes) throws NamingException {
                return attributes.get(GID_NUMBER);
            }
        };
    }

    private byte[] randSalt() {
        return saltGenerator.generateKey();
    }

}