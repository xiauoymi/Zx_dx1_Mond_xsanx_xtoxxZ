package com.industrysystem.security.groups;

/**
 * User: ppera
 * Date: 10/07/13
 * Time: 16:00
 */
public class AdminSecurityGroup extends SecurityGroup {

    public static final String ADMIN = "ADMIN";

    @Override
    public String toAuthorityString() {
        return ADMIN;
    }

    @Override
    public boolean isAdmin() {
        return true;
    }
}
