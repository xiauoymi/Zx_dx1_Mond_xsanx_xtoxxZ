package com.industrysystem.security.groups;

import com.industrysystem.entities.Document;

/**
 * User: LSCHW1
 */
public class BranchFunctionalSecurityGroup extends FunctionalSecurityGroup{

    private Document document;
    private BranchGroupParser branchGroupParser;

    public static enum RolNames {
        POD_ADMINISTRATOR,
        POD_BALANCE_OPERATOR,
        POD_BATCH_OPERATOR,
        POD_LIQUIDATOR,
        POD_RECEPTION_OPERATOR,
        POD_SAMPLER_OPERATOR,
        POD_SUPERVISOR;
    }

    public BranchFunctionalSecurityGroup(String roleName, String groupName){
        super(roleName, groupName);

        branchGroupParser = new BranchGroupParser(groupName);

        this.document=new Document(branchGroupParser.getDocumentTypeCode(),branchGroupParser.getDocumentNumber());
    }

    public Long getCommercialCode() {
        return branchGroupParser.getCommercialCode();
    }

    public Document getDocument() {
        return document;
    }

    public static boolean isValidRoleName(String role) {
        for (RolNames validRole : RolNames.values()){
            if (validRole.name().equalsIgnoreCase(role)) return true;
        }
        return false;
    }

    public static String createGroupName(Long commercialCode, String documentTypeCode, String documentNumber) {
          StringBuilder groupName=new StringBuilder();
          groupName.append(commercialCode.toString()).append(BranchGroupParser.SEPARATOR);
          groupName.append(documentTypeCode).append(BranchGroupParser.SEPARATOR);
          groupName.append(documentNumber);
          return groupName.toString();
    }
}

