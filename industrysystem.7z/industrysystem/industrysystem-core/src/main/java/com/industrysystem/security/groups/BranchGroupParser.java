package com.industrysystem.security.groups;

public class BranchGroupParser {

    public static final String SEPARATOR = "-";

    private Long commercialCode;
    private String documentNumber;
    private String documentTypeCode;

    public BranchGroupParser(String groupName) {
        String[] fields=getFieldsFromGroupName(groupName);

        this.commercialCode=Long.valueOf(fields[0]);
        this.documentTypeCode=fields[1];
        this.documentNumber=fields[2];
    }


    private String[] getFieldsFromGroupName(String groupName){
        String[] fields = groupName.split(SEPARATOR);
        if (fields.length!=3){
            throw new RuntimeException("Invalid Group: "+groupName);
        }
        return fields;
    }

    public Long getCommercialCode() {
        return commercialCode;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public String getDocumentTypeCode() {
        return documentTypeCode;
    }
}