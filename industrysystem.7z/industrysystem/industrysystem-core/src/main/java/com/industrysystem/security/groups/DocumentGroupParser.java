package com.industrysystem.security.groups;

public class DocumentGroupParser {

    public static final String SEPARATOR = "-";

    private String documentNumber;
    private String documentTypeCode;

    public DocumentGroupParser(String groupName) {
        String[] fields=getFieldsFromGroupName(groupName);

        this.documentTypeCode=fields[0];
        this.documentNumber=fields[1];
    }


    private String[] getFieldsFromGroupName(String groupName){
        String[] fields = groupName.split(SEPARATOR);
        if (fields.length!=2){
            throw new RuntimeException("Invalid Group: "+groupName);
        }
        return fields;
    }

    public String getDocumentNumber() {
        return documentNumber;
    }

    public String getDocumentTypeCode() {
        return documentTypeCode;
    }
}