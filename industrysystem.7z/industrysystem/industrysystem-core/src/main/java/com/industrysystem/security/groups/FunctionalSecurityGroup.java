package com.industrysystem.security.groups;

/**
 * User: ppera
 * Date: 10/07/13
 * Time: 15:00
 */
public class FunctionalSecurityGroup extends SecurityGroup {

    private static final String GROUP_ROLE_SEPARATOR = "@";

    protected String groupName;

    public static enum RolNames {
        LAB_RESULTS_LOADER,
        LAB_SUPERVISOR,
        TO_AUDIT,
        TO_COLLECTION,
        TO_COMMERCIAL;
    }

    public FunctionalSecurityGroup(String roleName, String groupName) {
        super();
        this.roleName = roleName;
        this.groupName = groupName;
    }

    @Override
    public String toAuthorityString() {
        return this.roleName + GROUP_ROLE_SEPARATOR + this.groupName;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public boolean isA(String roleName) {
        return this.roleName.equalsIgnoreCase(roleName);
    }

}