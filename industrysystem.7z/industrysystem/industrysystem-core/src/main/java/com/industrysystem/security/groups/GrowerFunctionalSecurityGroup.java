package com.industrysystem.security.groups;

import com.google.common.base.Predicate;
import com.industrysystem.entities.Document;


import static com.google.common.collect.Iterables.any;
import static com.google.common.collect.Lists.newArrayList;

/**
 * User: LSCHW1
 */
public class GrowerFunctionalSecurityGroup extends FunctionalSecurityGroup{

    private Document document;
    private DocumentGroupParser documentGroupParser;

    public static enum RolNames {
        GROWER
    }

    public GrowerFunctionalSecurityGroup(String roleName, String groupName){
        super(roleName, groupName);
        documentGroupParser = new DocumentGroupParser(groupName);
        document = new Document(documentGroupParser.getDocumentTypeCode(), documentGroupParser.getDocumentNumber());
    }

    public Document getDocument() {
        return document;
    }

    public static boolean isValidRoleName(final String role) {
        return any(newArrayList(RolNames.values()), new Predicate<RolNames>() {
            @Override
            public boolean apply(RolNames input) {
                return input.name().equalsIgnoreCase(role);
            }
        });
    }

    public static String createGroupName(String documentTypeCode, String documentNumber) {
        StringBuilder groupName = new StringBuilder()
                .append(DocumentGroupParser.SEPARATOR).append(documentTypeCode)
                .append(DocumentGroupParser.SEPARATOR).append(documentNumber);
        return groupName.toString();
    }

}