package com.industrysystem.security.groups;

import org.springframework.security.core.GrantedAuthority;

/**
 * User: ppera
 * Date: 10/07/13
 * Time: 14:57
 */
public abstract class SecurityGroup implements GrantedAuthority{
    public static final String ROLE_PREFIX = "ROLE_";

    protected String roleName;

    public String getRoleName() {
        return roleName;
    }

    public String getRoleWithPrefix(){
        return ROLE_PREFIX + roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public abstract String toAuthorityString();

    public boolean isAdmin(){
        return false;
    }

    @Override
    public String getAuthority() {
        return ROLE_PREFIX + toAuthorityString().toUpperCase();
    }

    @Override
    public String toString() {
        return this.toAuthorityString();
    }
}
