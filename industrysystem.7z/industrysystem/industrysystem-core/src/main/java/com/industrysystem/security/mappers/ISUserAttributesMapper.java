package com.industrysystem.security.mappers;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.DistinguishedName;
import org.springframework.security.ldap.userdetails.InetOrgPerson;
import org.springframework.security.ldap.userdetails.InetOrgPersonContextMapper;

import javax.naming.NamingException;
import javax.naming.directory.Attributes;

/**
 * User: PPERA
 * Date: 6/6/13
 * Time: 5:48 PM
 */
public abstract class ISUserAttributesMapper extends InetOrgPersonContextMapper implements AttributesMapper {
    @Override
    public Object mapFromAttributes(Attributes attributes) throws NamingException {
        InetOrgPerson user = new InetOrgPerson();
        super.mapUserToContext(user, new DirContextAdapter(attributes, new DistinguishedName(this.getLdapRoot())));
        return user;
    }

    protected abstract String getLdapRoot();
}
