package com.industrysystem.security.mappers;

import com.industrysystem.security.groups.*;
import org.springframework.ldap.core.ContextMapper;
import org.springframework.ldap.core.DirContextAdapter;

import javax.naming.Name;

/**
 * User: PPERA
 * Date: 04/07/13
 * Time: 10:26
 */
public class IndustrySystemGroupContextMapper implements ContextMapper {
    @Override
    public Object mapFromContext(Object o) {
        DirContextAdapter g = (DirContextAdapter) o;
        Name dn = g.getDn();

        String group = this.extractGroupNameString(dn);

        if(AdminSecurityGroup.ADMIN.equalsIgnoreCase(group)){
            return new AdminSecurityGroup();
        }

        String role = this.extractRoleNameString(dn);

        if (BranchFunctionalSecurityGroup.isValidRoleName(role)){
             return new BranchFunctionalSecurityGroup(role, group);
        }

        if (HeadOfficeFunctionalSecurityGroup.isValidRoleName(role)){
             return new HeadOfficeFunctionalSecurityGroup(role, group);
        }

        if (GrowerFunctionalSecurityGroup.isValidRoleName(role)){
             return new GrowerFunctionalSecurityGroup(role, group);
        }

        return new FunctionalSecurityGroup(role, group);
    }

    private String extractRoleNameString(Name dn) {
        String role = dn.get(dn.size() - 2);
        role = role.substring(role.indexOf("=") + 1).trim();
        return role;
    }

    private String extractGroupNameString(Name dn) {
        String group = dn.get(dn.size() - 1);
        group = group.substring(group.indexOf("=") + 1).trim();
        return group;
    }
}
