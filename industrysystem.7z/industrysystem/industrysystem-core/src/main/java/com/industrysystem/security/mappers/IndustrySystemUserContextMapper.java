package com.industrysystem.security.mappers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.ContextMapper;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.ldap.userdetails.InetOrgPersonContextMapper;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public class IndustrySystemUserContextMapper implements ContextMapper {

	@Autowired
	private InetOrgPersonContextMapper inetOrgPersonContextMapper;

	@Override
	public Object mapFromContext(Object arg0) {
		DirContextOperations ctx = (DirContextOperations) arg0;
		return inetOrgPersonContextMapper.mapUserFromContext(ctx, "annonymus", new ArrayList<GrantedAuthority>());
	}
}
