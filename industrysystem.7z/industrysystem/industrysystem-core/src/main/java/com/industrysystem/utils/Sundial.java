package com.industrysystem.utils;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: JFVERO
 * Date: 12/03/14
 * Time: 15:48
 */
public interface Sundial {

    public Date getCurrentTime();

    public boolean isAroundNowOrEarlier(Date instant, int marginInMillis);

    public boolean isAfterNow(Date instant);

}