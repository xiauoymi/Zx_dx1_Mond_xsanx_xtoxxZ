package com.industrysystem.utils;

import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: JFVERO
 * Date: 12/03/14
 * Time: 16:47
 */
@Component
public class SundialImpl implements Sundial {

    @Override
    public Date getCurrentTime() {
        return new Date();
    }

    @Override
    public boolean isAroundNowOrEarlier(Date instant, int marginInMillis) {
        return instant != null && instant.getTime() <= getCurrentTime().getTime() + marginInMillis;
    }

    @Override
    public boolean isAfterNow(Date instant) {
        return instant != null && instant.after(getCurrentTime());
    }

}