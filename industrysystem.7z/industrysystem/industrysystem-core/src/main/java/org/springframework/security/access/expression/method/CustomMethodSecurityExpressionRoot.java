package org.springframework.security.access.expression.method;

import com.industrysystem.guava.predicates.GrantedAuthorityMatchesLenientRolePredicate;
import com.industrysystem.guava.predicates.GrantedAuthorityMatchesStrictRoleBranchPredicate;
import com.industrysystem.guava.predicates.GrantedAuthorityMatchesStrictRoleGrowerPredicate;
import com.industrysystem.guava.predicates.GrantedAuthorityMatchesStrictRolePredicate;
import com.industrysystem.security.groups.AdminSecurityGroup;
import com.industrysystem.security.groups.BranchFunctionalSecurityGroup;
import com.industrysystem.security.groups.FunctionalSecurityGroup;
import com.industrysystem.security.groups.GrowerFunctionalSecurityGroup;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Collection;

import static com.google.common.collect.Iterables.tryFind;

public class CustomMethodSecurityExpressionRoot extends MethodSecurityExpressionRoot {

    public CustomMethodSecurityExpressionRoot(Authentication a) {
        super(a);
    }

    public boolean hasStrictRole(final String inputRole, final String inputGroup) {
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        return tryFind(authorities, new GrantedAuthorityMatchesStrictRolePredicate(inputRole, inputGroup)).isPresent();
    }

    public boolean hasStrictRoleTOCommercial(final String traitOwnerCode) {
        String role = getRole(FunctionalSecurityGroup.RolNames.TO_COMMERCIAL.name());
        return hasStrictRole(role,traitOwnerCode);
    }

    public boolean hasStrictRoleLABResultsLoader(final String laboratoryCode) {
        String role = getRole(FunctionalSecurityGroup.RolNames.LAB_RESULTS_LOADER.name());
        return hasStrictRole(role,laboratoryCode);
    }

    public boolean hasStrictRolePodAdministrator(final Long commercialCode, final String documentTypeCode, final String documentNumber) {
        String role = getRole(BranchFunctionalSecurityGroup.RolNames.POD_ADMINISTRATOR.name());
        return hasStrictRolePodBranch(role,commercialCode,documentTypeCode,documentNumber);
    }


    public boolean hasStrictRolePodReceptionOperator(final Long commercialCode, final String documentTypeCode, final String documentNumber) {
        String role = getRole(BranchFunctionalSecurityGroup.RolNames.POD_RECEPTION_OPERATOR.name());
        return hasStrictRolePodBranch(role,commercialCode,documentTypeCode,documentNumber);
    }

    public boolean hasStrictRolePodBatchOperator(final Long commercialCode, final String documentTypeCode, final String documentNumber) {
        String role=getRole(BranchFunctionalSecurityGroup.RolNames.POD_BATCH_OPERATOR.name());
        return hasStrictRolePodBranch(role,commercialCode,documentTypeCode,documentNumber);
    }

    public boolean hasStrictRoleGrower(final String documentTypeCode, final String documentNumber) {
        String role = getRole(GrowerFunctionalSecurityGroup.RolNames.GROWER.name());
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        return tryFind(authorities, new GrantedAuthorityMatchesStrictRoleGrowerPredicate(role, documentTypeCode, documentNumber)).isPresent();
    }

    public boolean hasStrictRolePodBranch(final String inputRole,final Long commercialCode, final String documentTypeCode, final String documentNumber) {
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        return tryFind(authorities, new GrantedAuthorityMatchesStrictRoleBranchPredicate(inputRole, commercialCode, documentTypeCode, documentNumber)).isPresent();
    }

    public boolean isAdministrator() {
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        for (GrantedAuthority grantedAuthority: authorities) {
            if (grantedAuthority instanceof AdminSecurityGroup) {
                return true;
            }
        }
        return false;
    }

    public boolean hasLenientRole(final String inputRole) {
        Collection<? extends GrantedAuthority> authorities = SecurityContextHolder.getContext().getAuthentication().getAuthorities();
        return tryFind(authorities, new GrantedAuthorityMatchesLenientRolePredicate(inputRole)).isPresent();
    }

    private String getRole(String roleName) {
        StringBuilder role = new StringBuilder();
        role.append(FunctionalSecurityGroup.ROLE_PREFIX).append(roleName);
        return role.toString();
    }

}