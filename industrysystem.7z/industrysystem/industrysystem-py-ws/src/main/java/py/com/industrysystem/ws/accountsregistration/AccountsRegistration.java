package py.com.industrysystem.ws.accountsregistration;

import com.industrysystem.ws.accountsregistration.request.NewAccountData;
import com.industrysystem.ws.exceptions.RegisterAccountsWebServiceException;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.util.List;


//Security applied in core service
@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public interface AccountsRegistration {

    @WebMethod(operationName = "registerAccounts")
    public String registerAccounts(@WebParam(name = "newAccountDataItems") List<NewAccountData> newAccountDataItems) throws RegisterAccountsWebServiceException;
}