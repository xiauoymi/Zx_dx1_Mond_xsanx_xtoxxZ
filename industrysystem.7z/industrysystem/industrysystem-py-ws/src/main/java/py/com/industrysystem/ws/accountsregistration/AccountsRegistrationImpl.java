package py.com.industrysystem.ws.accountsregistration;

import com.industrysystem.ws.accountsregistration.AccountsRegistrationCommonImpl;
import com.industrysystem.ws.accountsregistration.request.NewAccountData;
import com.industrysystem.ws.exceptions.RegisterAccountsWebServiceException;
import org.apache.cxf.feature.Features;

import javax.jws.WebService;
import java.util.List;

@WebService(endpointInterface = "py.com.industrysystem.ws.accountsregistration.AccountsRegistration", serviceName = "AccountsRegistrationPODPY")
@Features(classes = org.apache.cxf.feature.LoggingFeature.class)
public class AccountsRegistrationImpl extends AccountsRegistrationCommonImpl implements AccountsRegistration {

    @Override
    public String registerAccounts(List<NewAccountData> newAccountDataItems) throws RegisterAccountsWebServiceException {
        return super.registerAccounts(newAccountDataItems);
    }

}