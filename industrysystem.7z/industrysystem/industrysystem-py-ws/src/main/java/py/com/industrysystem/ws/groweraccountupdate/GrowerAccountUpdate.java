package py.com.industrysystem.ws.groweraccountupdate;

import com.industrysystem.business.dtos.GrowerBalanceOperationDto;
import com.industrysystem.business.dtos.TransactionDto;
import com.industrysystem.ws.exceptions.GrowerAccountUpdateServiceException;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.util.List;

/**
 * User: LSCH1
 */
@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public interface GrowerAccountUpdate {

    @WebMethod(operationName = "growerAccountUpdate")
    public String growerAccountUpdate(
            @WebParam(name = "growerBalanceOperationItems") List<GrowerBalanceOperationDto> growerBalanceOperationItemsDto,
            @WebParam(name = "transaction") TransactionDto transaction,
            @WebParam(name = "traitOwnerCode") String traitOwnerCode) throws GrowerAccountUpdateServiceException;
}
