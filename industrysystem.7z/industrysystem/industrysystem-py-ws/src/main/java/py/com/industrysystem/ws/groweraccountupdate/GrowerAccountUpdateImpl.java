package py.com.industrysystem.ws.groweraccountupdate;

import com.industrysystem.business.GrowerBalanceService;
import com.industrysystem.business.dtos.GrowerBalanceOperationDto;
import com.industrysystem.business.dtos.TransactionDto;
import com.industrysystem.ws.exceptions.GrowerAccountUpdateServiceException;
import org.apache.cxf.feature.Features;
import org.springframework.beans.factory.annotation.Autowired;

import javax.jws.WebService;
import java.util.List;

/**
 * User: LSCHW1
 */
@WebService(endpointInterface = "py.com.industrysystem.ws.groweraccountupdate.GrowerAccountUpdate", serviceName = "GrowerAccountUpdatePY")
@Features(classes = org.apache.cxf.feature.LoggingFeature.class)
public class GrowerAccountUpdateImpl implements GrowerAccountUpdate {

    @Autowired
    private GrowerBalanceService growerBalanceService;

    @Override
    public String growerAccountUpdate(List<GrowerBalanceOperationDto> growerBalanceOperationItemsDto, TransactionDto transaction, String traitOwnerCode) throws GrowerAccountUpdateServiceException{
        try{
            growerBalanceService.registerBalanceOperations(transaction,growerBalanceOperationItemsDto,traitOwnerCode);
             return "OK";
         } catch (Exception e) {
          throw new GrowerAccountUpdateServiceException(e);
        }
    }

}