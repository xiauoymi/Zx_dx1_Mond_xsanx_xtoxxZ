package py.com.industrysystem.ws.prepaidtons;

import com.industrysystem.ws.prepaidtons.request.Transaction;
import com.industrysystem.ws.prepaidtons.response.Response;
import org.springframework.security.access.prepost.PreAuthorize;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

/**
 * User: CGLLLO
 * Date: 2/28/13
 * Time: 3:21 PM
 */
@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public interface PrepaidTonsService {

    @WebMethod(operationName = "manageAccount")
    public Response updatePrepaidTons(
            @WebParam(name = "accountNumber") String accountNumber,
            @WebParam(name = "traitOwnerCode") String traitOwnerCode,
            @WebParam(name = "transaction") Transaction transaction
    );
}
