package py.com.industrysystem.ws.prepaidtons;

import com.industrysystem.entities.CropTechnology;
import com.industrysystem.entities.GrowerAccount;
import com.industrysystem.entities.Technology;
import com.industrysystem.entities.TraitOwner;
import com.industrysystem.ws.prepaidtons.PrepaidTonsServiceCommonImpl;
import com.industrysystem.ws.prepaidtons.request.Transaction;
import com.industrysystem.ws.prepaidtons.response.Response;
import com.industrysystem.ws.prepaidtons.response.Result;
import org.apache.cxf.feature.Features;
import org.springframework.beans.factory.annotation.Autowired;

import javax.jws.WebService;
import java.util.Date;

/**
 * User: CGLLLO
 * Date: 2/28/13
 * Time: 3:35 PM
 */
@WebService(endpointInterface = "py.com.industrysystem.ws.prepaidtons.PrepaidTonsService", serviceName = "PrepaidTonsPODPY")
@Features(classes = org.apache.cxf.feature.LoggingFeature.class)
public class PrepaidTonsServiceImpl extends PrepaidTonsServiceCommonImpl implements PrepaidTonsService {

    public Response updatePrepaidTons(String accountNumber, String traitOwnerCode, Transaction transaction) {
        return super.updatePrepaidTons(accountNumber, traitOwnerCode, transaction);
    }
}
