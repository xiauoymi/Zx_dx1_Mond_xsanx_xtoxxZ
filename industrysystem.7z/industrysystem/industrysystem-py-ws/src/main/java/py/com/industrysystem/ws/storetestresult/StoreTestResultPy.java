package py.com.industrysystem.ws.storetestresult;

import com.industrysystem.business.dtos.StakeholdersDto;
import com.industrysystem.business.dtos.QualitativeTestResultDto;
import com.industrysystem.business.dtos.QuantitativeTestResultDto;
import com.industrysystem.ws.exceptions.StoreSampleWebServiceException;
import com.industrysystem.ws.exceptions.StoreTestResultWebServiceException;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.util.List;

/**
 * User: PMIRIB
 * Date: 07/10/13
 * Time: 15:09
 */
@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public interface StoreTestResultPy {

    @WebMethod(operationName = "storeTestResult")
    public String storeTestResults(
            @WebParam(name = "destinationDocumentNumber") String destinationDocumentNumber,
            @WebParam(name = "destinationDocumentType") String destinationDocumentType,
            @WebParam(name = "sampleCode") String sampleCode,
            @WebParam(name = "quantitatives") List<QuantitativeTestResultDto> quantitatives,
            @WebParam(name = "qualitatives") List<QualitativeTestResultDto> qualitatives,
            @WebParam(name = "stakeholders") StakeholdersDto stakeholders
            ) throws StoreSampleWebServiceException, StoreTestResultWebServiceException;

}