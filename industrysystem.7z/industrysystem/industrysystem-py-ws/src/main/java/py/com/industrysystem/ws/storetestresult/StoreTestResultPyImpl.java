package py.com.industrysystem.ws.storetestresult;

import com.industrysystem.business.TestsService;
import com.industrysystem.business.dtos.StakeholdersDto;
import com.industrysystem.business.dtos.QualitativeTestResultDto;
import com.industrysystem.business.dtos.QuantitativeTestResultDto;
import com.industrysystem.entities.Document;
import com.industrysystem.exceptions.BusinessException;
import com.industrysystem.ws.exceptions.StoreTestResultWebServiceException;
import com.industrysystem.ws.exceptions.WebServiceError;
import com.industrysystem.ws.validators.Validator;
import org.apache.cxf.feature.Features;
import org.springframework.beans.factory.annotation.Autowired;

import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;
import java.util.List;

import static org.apache.commons.lang.StringUtils.upperCase;

/**
 * User: PMIRIB
 * Date: 10/10/13
 */
@WebService(endpointInterface = "py.com.industrysystem.ws.storetestresult.StoreTestResultPy")
@Features(classes = org.apache.cxf.feature.LoggingFeature.class)
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
@XmlSeeAlso(WebServiceError.class)
public class StoreTestResultPyImpl implements StoreTestResultPy {

    @Autowired
    private TestsService testService;

    @Autowired
    private Validator validator;

    public String storeTestResults(
            @WebParam(name = "destinationDocumentNumber") String destinationDocumentNumber,
            @WebParam(name = "destinationDocumentType") String destinationDocumentType,
            @WebParam(name = "sampleCode") String sampleCode,
            @WebParam(name = "quantitatives") List<QuantitativeTestResultDto> quantitatives,
            @WebParam(name = "qualitatives") List<QualitativeTestResultDto> qualitatives,
            @WebParam(name = "stakeholders") StakeholdersDto stakeholders
            ) throws StoreTestResultWebServiceException {
        validator.validateRequest(destinationDocumentType, destinationDocumentNumber, sampleCode, quantitatives, qualitatives);

        try {
            Document destinationDocument = new Document(upperCase(destinationDocumentType), destinationDocumentNumber);
            testService.storeTestResultsByDestination(destinationDocument, sampleCode, quantitatives, qualitatives, stakeholders);
            return "OK";
        } catch (BusinessException ex) {
            throw new StoreTestResultWebServiceException(ex);
        } catch (Exception ex) {
            throw new StoreTestResultWebServiceException(ex);
        }
    }

}