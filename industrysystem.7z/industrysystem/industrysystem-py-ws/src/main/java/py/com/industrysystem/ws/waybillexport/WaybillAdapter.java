package py.com.industrysystem.ws.waybillexport;

import com.industrysystem.business.dtos.TraitOwnerMessagesContainerDTO;
import com.industrysystem.entities.*;
import py.com.industrysystem.ws.waybillexport.response.*;
import py.com.industrysystem.ws.waybillexport.response.TransportType;
import py.com.industrysystem.ws.waybillexport.response.Waybill;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

class WaybillAdapter {

    private com.industrysystem.entities.Waybill waybill;
    private TraitOwnerMessagesContainerDTO traitOwnerMessagesContainerDTO;

    WaybillAdapter(com.industrysystem.entities.Waybill waybill, TraitOwnerMessagesContainerDTO traitOwnerMessagesContainerDTO) {
        this.waybill = waybill;
        this.traitOwnerMessagesContainerDTO = traitOwnerMessagesContainerDTO;
    }

    public Waybill getWaybill() {
        Waybill newWaybill = new Waybill();

        newWaybill.setCtgNumber(getCtgNumber());
        newWaybill.setWaybillNumber(BigInteger.valueOf(waybill.getWaybillNumber()));
        newWaybill.setTransportType(TransportType.fromEntity(waybill.getTransportType()));
        newWaybill.setHolderName(traitOwnerMessagesContainerDTO.getName(waybill.getHolderDocument()));
        newWaybill.setHolderDocumentNumber(Long.parseLong(waybill.getHolderDocument().getNumber()));
        newWaybill.setAddresseeName(traitOwnerMessagesContainerDTO.getName(waybill.getAddressee().getDocument()));
        newWaybill.setAddresseeDocumentNumber(Long.parseLong(waybill.getAddressee().getDocument().getNumber()));
        newWaybill.setDestinationName(traitOwnerMessagesContainerDTO.getName(waybill.getDestination().getDocument()));
        newWaybill.setDestinationDocumentNumber(Long.parseLong(waybill.getDestination().getDocument().getNumber()));
        newWaybill.setCampaignCode(waybill.getCampaign().getCode());
        newWaybill.setCropCode(waybill.getCrop().getCode());
        newWaybill.setNetWeight(getNetWeight());
        newWaybill.setSourceCityCode(waybill.getGoodsSourceCity().getCode());
        newWaybill.setSourceStateCode("NOT INFORMED");
        newWaybill.setDestinationCityCode(waybill.getGoodsDestinationCity().getCode());
        newWaybill.setDestinationStateCode("NOT INFORMED");
        newWaybill.setDeviation(getDeviation());
        newWaybill.setLabResults(getLabResults());

        return newWaybill;
    }

    public BigInteger getCtgNumber() {
        Set<LoadDetail> loadDetails = waybill.getLoadDetails();
        if (!loadDetails.isEmpty()) {
            LoadDetail loadDetail = loadDetails.iterator().next();
            if (loadDetail instanceof TruckLoadDetail) {
                TruckLoadDetail truckLoadDetail = (TruckLoadDetail)loadDetail;
                if (truckLoadDetail.getCtg() != null) {
                    return new BigInteger(truckLoadDetail.getCtg());
                }
            }
        }
        return null;
    }

    public BigInteger getNetWeight() {
        long total = 0L;
        for (LoadDetail loadDetail: waybill.getLoadDetails()) {
            Integer weight = loadDetail.getWeight();
            if (weight != null) {
                total += weight;
            }
        }
        return BigInteger.valueOf(total);
    }

    public Deviation getDeviation() {
        WaybillDeviation waybillDeviation = waybill.getWaybillDeviation();
        if (waybillDeviation != null) {
            Deviation deviation = new Deviation();
            deviation.setDestinationDocumentNumber(getDeviationDestinationDocumentNumber());
            deviation.setDestinationPlantCode(waybillDeviation.getPlantCode());
            deviation.setAddresseeDocumentNumber(getDeviationAddresseeDocumentNumber());
            deviation.setAddresseeCityCode(waybillDeviation.getAddresseeCity());
            return deviation;
        }
        return null;
    }

    public Long getDeviationDestinationDocumentNumber() {
        WaybillDeviation waybillDeviation = waybill.getWaybillDeviation();
        if (waybillDeviation != null && waybillDeviation.getDestinationDocumentNumber() != null) {
            return Long.parseLong(waybillDeviation.getDestinationDocumentNumber());
        }
        return null;
    }

    public Long getDeviationAddresseeDocumentNumber() {
        WaybillDeviation waybillDeviation = waybill.getWaybillDeviation();
        if (waybillDeviation != null && waybillDeviation.getAdresseeDocumentNumber() != null) {
            return Long.parseLong(waybillDeviation.getAdresseeDocumentNumber());
        }
        return null;
    }

    public List<LabResult> getLabResults() {
        List<LabResult> labResults = new ArrayList<LabResult>();
        for (WaybillTechnology waybillTechnology: traitOwnerMessagesContainerDTO.getWaybillTechnologies(waybill.getId())) {
            LabResult labResult = new LabResult();
            labResult.setTechnologyCode(waybillTechnology.getCropTechnology().getTechnology().getCode());
            labResult.setWeightDetected(BigInteger.valueOf(waybillTechnology.getWeight()));
            if (waybillTechnology.getLaboratory() != null) {
                labResult.setLabCode(waybillTechnology.getLaboratory().getCode());
            }
            labResults.add(labResult);
        }
        return labResults;
    }

}