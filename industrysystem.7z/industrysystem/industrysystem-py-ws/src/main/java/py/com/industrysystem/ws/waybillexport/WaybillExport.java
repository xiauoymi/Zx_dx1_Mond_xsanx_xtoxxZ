package py.com.industrysystem.ws.waybillexport;

import com.industrysystem.exceptions.WaybillExportException;
import py.com.industrysystem.ws.waybillexport.response.Response;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;

@WebService
@SOAPBinding(style=SOAPBinding.Style.RPC, use=SOAPBinding.Use.LITERAL)
public interface WaybillExport {

    @WebMethod(operationName="exportWaybills")
    public Response exportWaybills(@WebParam(name="fromId") long fromId) throws WaybillExportException;

}