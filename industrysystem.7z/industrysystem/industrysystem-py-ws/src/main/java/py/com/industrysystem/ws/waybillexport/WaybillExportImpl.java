package py.com.industrysystem.ws.waybillexport;

import com.industrysystem.business.WaybillService;
import com.industrysystem.business.dtos.TraitOwnerMessagesContainerDTO;
import com.industrysystem.entities.TraitOwnerMessage;
import com.industrysystem.entities.WaybillMessage;
import com.industrysystem.exceptions.UserNotLoggedException;
import com.industrysystem.exceptions.WaybillExportException;
import org.apache.cxf.feature.Features;
import org.springframework.beans.factory.annotation.Autowired;
import py.com.industrysystem.ws.waybillexport.response.Bulk;
import py.com.industrysystem.ws.waybillexport.response.Response;

import javax.jws.WebService;

@WebService(endpointInterface="py.com.industrysystem.ws.waybillexport.WaybillExport", serviceName = "WaybillExportPY")
@Features(classes=org.apache.cxf.feature.LoggingFeature.class)
public class WaybillExportImpl implements WaybillExport {

    @Autowired
    private WaybillService waybillExportService;

    @Override
    public Response exportWaybills(long fromId) throws WaybillExportException {
        try {
            TraitOwnerMessagesContainerDTO messagesContainer = waybillExportService.retrieveTraitOwnerMessages(fromId);

            Response response = new Response();
            response.setHasMore(messagesContainer.isHasMore());
            for (TraitOwnerMessage traitOwnerMessage: messagesContainer.getTraitOwnerMessages()) {
                Bulk bulk = new Bulk();
                bulk.setId(traitOwnerMessage.getMessageSequence());
                for (WaybillMessage waybillMessage: traitOwnerMessage.getWaybillMessages()) {
                    bulk.addWaybill(new WaybillAdapter(waybillMessage.getWaybill(), messagesContainer).getWaybill());
                }
                response.addBulk(bulk);
            }
            return response;
        } catch (UserNotLoggedException ex) {
            throw new WaybillExportException(ex);
        }
    }

}