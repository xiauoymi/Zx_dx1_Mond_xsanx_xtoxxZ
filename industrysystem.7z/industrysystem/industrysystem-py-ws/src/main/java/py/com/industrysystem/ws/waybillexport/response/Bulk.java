package py.com.industrysystem.ws.waybillexport.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
public class Bulk {

    @XmlElement(required=true)
    private long id;
    @XmlElement(name="waybill")
    private List<Waybill> waybills = new ArrayList<Waybill>();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public List<Waybill> getWaybills() {
        return waybills;
    }

    public void setWaybills(List<Waybill> waybills) {
        this.waybills = waybills;
    }

    public void addWaybill(Waybill waybill) {
        waybills.add(waybill);
    }

}