package py.com.industrysystem.ws.waybillexport.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.datatype.XMLGregorianCalendar;

@XmlAccessorType(XmlAccessType.FIELD)
public class Deviation {

    private Long destinationDocumentNumber;
    private String destinationAddress;
    private String destinationPlantCode;
    @XmlSchemaType(name="date")
    private XMLGregorianCalendar deviationDate;
    private String transferRequestedBy;
    private Long addresseeDocumentNumber;
    private String addresseeCityCode;

    public Long getDestinationDocumentNumber() {
        return destinationDocumentNumber;
    }

    public void setDestinationDocumentNumber(Long destinationDocumentNumber) {
        this.destinationDocumentNumber = destinationDocumentNumber;
    }

    public String getDestinationAddress() {
        return destinationAddress;
    }

    public void setDestinationAddress(String destinationAddress) {
        this.destinationAddress = destinationAddress;
    }

    public String getDestinationPlantCode() {
        return destinationPlantCode;
    }

    public void setDestinationPlantCode(String destinationPlantCode) {
        this.destinationPlantCode = destinationPlantCode;
    }

    public XMLGregorianCalendar getDeviationDate() {
        return deviationDate;
    }

    public void setDeviationDate(XMLGregorianCalendar deviationDate) {
        this.deviationDate = deviationDate;
    }

    public String getTransferRequestedBy() {
        return transferRequestedBy;
    }

    public void setTransferRequestedBy(String transferRequestedBy) {
        this.transferRequestedBy = transferRequestedBy;
    }

    public Long getAddresseeDocumentNumber() {
        return addresseeDocumentNumber;
    }

    public void setAddresseeDocumentNumber(Long addresseeDocumentNumber) {
        this.addresseeDocumentNumber = addresseeDocumentNumber;
    }

    public String getAddresseeCityCode() {
        return addresseeCityCode;
    }

    public void setAddresseeCityCode(String addresseeCityCode) {
        this.addresseeCityCode = addresseeCityCode;
    }

}