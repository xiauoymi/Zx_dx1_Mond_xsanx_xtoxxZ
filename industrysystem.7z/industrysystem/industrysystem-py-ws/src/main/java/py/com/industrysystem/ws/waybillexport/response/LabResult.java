package py.com.industrysystem.ws.waybillexport.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.math.BigInteger;

@XmlAccessorType(XmlAccessType.FIELD)
public class LabResult {

    @XmlElement(required=true)
    private String technologyCode;
    @XmlElement(required=true)
    private BigInteger weightDetected;
    private String labCode;

    public String getTechnologyCode() {
        return technologyCode;
    }

    public void setTechnologyCode(String technologyCode) {
        this.technologyCode = technologyCode;
    }

    public BigInteger getWeightDetected() {
        return weightDetected;
    }

    public void setWeightDetected(BigInteger weightDetected) {
        this.weightDetected = weightDetected;
    }

    public String getLabCode() {
        return labCode;
    }

    public void setLabCode(String labCode) {
        this.labCode = labCode;
    }

}