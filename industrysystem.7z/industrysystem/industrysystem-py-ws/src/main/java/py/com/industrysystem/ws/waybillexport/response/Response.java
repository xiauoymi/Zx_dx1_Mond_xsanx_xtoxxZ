package py.com.industrysystem.ws.waybillexport.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import java.util.ArrayList;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
public class Response {

    @XmlElement(name="bulk")
    private List<Bulk> bulks = new ArrayList<Bulk>();
    @XmlElement(required=true)
    private boolean hasMore;

    public List<Bulk> getBulks() {
        return bulks;
    }

    public void setBulks(List<Bulk> bulks) {
        this.bulks = bulks;
    }

    public void addBulk(Bulk bulk) {
        bulks.add(bulk);
    }

    public boolean isHasMore() {
        return hasMore;
    }

    public void setHasMore(boolean hasMore) {
        this.hasMore = hasMore;
    }

}