package py.com.industrysystem.ws.waybillexport.response;

public enum TransportType {

    TRUCK, TRAIN, BARGE;

    public static final TransportType fromEntity(com.industrysystem.entities.TransportType transportType) {
        return TransportType.values()[transportType.ordinal()];
    }

}