package py.com.industrysystem.ws.waybillexport.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@XmlAccessorType(XmlAccessType.FIELD)
public class Waybill {

    private BigInteger ctgNumber;
    private String ctgStatus;
    private Date ctgIssueDate;
    @XmlSchemaType(name="date")
    private XMLGregorianCalendar ctgDateSince;
    @XmlSchemaType(name="date")
    private XMLGregorianCalendar ctgDateUntil;
    private Integer ctgKilometersTraveled;
    @XmlElement(required=true)
    private BigInteger waybillNumber;
    @XmlElement(required=true)
    private TransportType transportType;
    @XmlElement(required=true)
    private String holderName;
    @XmlElement(required=true)
    private Long holderDocumentNumber;
    private String intermediaryName;
    private Long intermediaryDocumentNumber;
    private String commercialSenderName;
    private Long commercialSenderDocumentNumber;
    private String brokerName;
    private Long brokerDocumentNumber;
    private String agentName;
    private Long agentDocumentNumber;
    @XmlElement(required=true)
    private String addresseeName;
    @XmlElement(required=true)
    private Long addresseeDocumentNumber;
    @XmlElement(required=true)
    private String destinationName;
    @XmlElement(required=true)
    private Long destinationDocumentNumber;
    @XmlElement(required=true)
    private String campaignCode;
    @XmlElement(required=true)
    private String cropCode;
    private String sourceAddress;
    private String establishment;
    private BigInteger netWeight;
    @XmlElement(required=true)
    private long sourceCityCode;
    @XmlElement(required=true)
    private String sourceStateCode;
    private String destinationAddress;
    @XmlElement(required=true)
    private long destinationCityCode;
    @XmlElement(required=true)
    private String destinationStateCode;
    private Deviation deviation;
    @XmlElement(name="labResult", required=true)
    private List<LabResult> labResults = new ArrayList<LabResult>();

    public BigInteger getCtgNumber() {
        return ctgNumber;
    }

    public void setCtgNumber(BigInteger ctgNumber) {
        this.ctgNumber = ctgNumber;
    }

    public String getCtgStatus() {
        return ctgStatus;
    }

    public void setCtgStatus(String ctgStatus) {
        this.ctgStatus = ctgStatus;
    }

    public Date getCtgIssueDate() {
        return ctgIssueDate;
    }

    public void setCtgIssueDate(Date ctgIssueDate) {
        this.ctgIssueDate = ctgIssueDate;
    }

    public XMLGregorianCalendar getCtgDateSince() {
        return ctgDateSince;
    }

    public void setCtgDateSince(XMLGregorianCalendar ctgDateSince) {
        this.ctgDateSince = ctgDateSince;
    }

    public XMLGregorianCalendar getCtgDateUntil() {
        return ctgDateUntil;
    }

    public void setCtgDateUntil(XMLGregorianCalendar ctgDateUntil) {
        this.ctgDateUntil = ctgDateUntil;
    }

    public Integer getCtgKilometersTraveled() {
        return ctgKilometersTraveled;
    }

    public void setCtgKilometersTraveled(Integer ctgKilometersTraveled) {
        this.ctgKilometersTraveled = ctgKilometersTraveled;
    }

    public BigInteger getWaybillNumber() {
        return waybillNumber;
    }

    public void setWaybillNumber(BigInteger waybillNumber) {
        this.waybillNumber = waybillNumber;
    }

    public TransportType getTransportType() {
        return transportType;
    }

    public void setTransportType(TransportType transportType) {
        this.transportType = transportType;
    }

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public Long getHolderDocumentNumber() {
        return holderDocumentNumber;
    }

    public void setHolderDocumentNumber(Long holderDocumentNumber) {
        this.holderDocumentNumber = holderDocumentNumber;
    }

    public String getIntermediaryName() {
        return intermediaryName;
    }

    public void setIntermediaryName(String intermediaryName) {
        this.intermediaryName = intermediaryName;
    }

    public Long getIntermediaryDocumentNumber() {
        return intermediaryDocumentNumber;
    }

    public void setIntermediaryDocumentNumber(Long intermediaryDocumentNumber) {
        this.intermediaryDocumentNumber = intermediaryDocumentNumber;
    }

    public String getCommercialSenderName() {
        return commercialSenderName;
    }

    public void setCommercialSenderName(String commercialSenderName) {
        this.commercialSenderName = commercialSenderName;
    }

    public Long getCommercialSenderDocumentNumber() {
        return commercialSenderDocumentNumber;
    }

    public void setCommercialSenderDocumentNumber(Long commercialSenderDocumentNumber) {
        this.commercialSenderDocumentNumber = commercialSenderDocumentNumber;
    }

    public String getBrokerName() {
        return brokerName;
    }

    public void setBrokerName(String brokerName) {
        this.brokerName = brokerName;
    }

    public Long getBrokerDocumentNumber() {
        return brokerDocumentNumber;
    }

    public void setBrokerDocumentNumber(Long brokerDocumentNumber) {
        this.brokerDocumentNumber = brokerDocumentNumber;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public Long getAgentDocumentNumber() {
        return agentDocumentNumber;
    }

    public void setAgentDocumentNumber(Long agentDocumentNumber) {
        this.agentDocumentNumber = agentDocumentNumber;
    }

    public String getAddresseeName() {
        return addresseeName;
    }

    public void setAddresseeName(String addresseeName) {
        this.addresseeName = addresseeName;
    }

    public Long getAddresseeDocumentNumber() {
        return addresseeDocumentNumber;
    }

    public void setAddresseeDocumentNumber(Long addresseeDocumentNumber) {
        this.addresseeDocumentNumber = addresseeDocumentNumber;
    }

    public String getDestinationName() {
        return destinationName;
    }

    public void setDestinationName(String destinationName) {
        this.destinationName = destinationName;
    }

    public Long getDestinationDocumentNumber() {
        return destinationDocumentNumber;
    }

    public void setDestinationDocumentNumber(Long destinationDocumentNumber) {
        this.destinationDocumentNumber = destinationDocumentNumber;
    }

    public String getCampaignCode() {
        return campaignCode;
    }

    public void setCampaignCode(String campaignCode) {
        this.campaignCode = campaignCode;
    }

    public String getCropCode() {
        return cropCode;
    }

    public void setCropCode(String cropCode) {
        this.cropCode = cropCode;
    }

    public String getSourceAddress() {
        return sourceAddress;
    }

    public void setSourceAddress(String sourceAddress) {
        this.sourceAddress = sourceAddress;
    }

    public String getEstablishment() {
        return establishment;
    }

    public void setEstablishment(String establishment) {
        this.establishment = establishment;
    }

    public BigInteger getNetWeight() {
        return netWeight;
    }

    public void setNetWeight(BigInteger netWeight) {
        this.netWeight = netWeight;
    }

    public long getSourceCityCode() {
        return sourceCityCode;
    }

    public void setSourceCityCode(long sourceCityCode) {
        this.sourceCityCode = sourceCityCode;
    }

    public String getSourceStateCode() {
        return sourceStateCode;
    }

    public void setSourceStateCode(String sourceStateCode) {
        this.sourceStateCode = sourceStateCode;
    }

    public String getDestinationAddress() {
        return destinationAddress;
    }

    public void setDestinationAddress(String destinationAddress) {
        this.destinationAddress = destinationAddress;
    }

    public long getDestinationCityCode() {
        return destinationCityCode;
    }

    public void setDestinationCityCode(long destinationCityCode) {
        this.destinationCityCode = destinationCityCode;
    }

    public String getDestinationStateCode() {
        return destinationStateCode;
    }

    public void setDestinationStateCode(String destinationStateCode) {
        this.destinationStateCode = destinationStateCode;
    }

    public Deviation getDeviation() {
        return deviation;
    }

    public void setDeviation(Deviation deviation) {
        this.deviation = deviation;
    }

    public List<LabResult> getLabResults() {
        return labResults;
    }

    public void setLabResults(List<LabResult> labResults) {
        this.labResults = labResults;
    }

}