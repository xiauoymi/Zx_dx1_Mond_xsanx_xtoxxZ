package py.com.industrysystem.ws.waybillregistration;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;

import py.com.industrysystem.ws.waybillregistration.request.WaybillRequestImpl;

import com.industrysystem.ws.exceptions.WaybillRegistrationWebServiceException;
import com.industrysystem.ws.exceptions.WebServiceError;

@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
@XmlSeeAlso(WebServiceError.class)
public interface WaybillRegistrationService {

    @WebMethod(operationName = "registerWaybill")
    long registerWaybill(@WebParam(name = "waybillEntity") WaybillRequestImpl request) throws WaybillRegistrationWebServiceException;
}
