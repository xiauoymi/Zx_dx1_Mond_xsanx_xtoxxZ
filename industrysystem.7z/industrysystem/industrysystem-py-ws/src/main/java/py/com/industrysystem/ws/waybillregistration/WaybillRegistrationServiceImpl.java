package py.com.industrysystem.ws.waybillregistration;

import com.industrysystem.exceptions.BusinessException;
import com.industrysystem.ws.exceptions.WaybillRegistrationWebServiceException;
import com.industrysystem.ws.exceptions.WebServiceError;
import com.industrysystem.ws.waybillregistration.WaybillRegistrationServiceCommonImpl;
import com.industrysystem.ws.waybillregistration.request.validator.NotNillableFieldValidator;
import org.apache.cxf.feature.Features;
import org.springframework.beans.factory.annotation.Autowired;
import py.com.industrysystem.business.WaybillServicePyImpl;
import py.com.industrysystem.business.dtos.WaybillDtoPy;
import py.com.industrysystem.ws.waybillregistration.request.WaybillRequestImpl;
import py.com.industrysystem.ws.waybillregistration.request.validator.NotNillableFieldValidatorPy;

import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;

@WebService(endpointInterface = "py.com.industrysystem.ws.waybillregistration.WaybillRegistrationService")
@Features(classes = org.apache.cxf.feature.LoggingFeature.class)
@XmlSeeAlso(WebServiceError.class)
public class WaybillRegistrationServiceImpl extends WaybillRegistrationServiceCommonImpl<WaybillDtoPy> implements WaybillRegistrationService {

    @Autowired
    private WaybillServicePyImpl waybillService;

    private NotNillableFieldValidator validator = new NotNillableFieldValidatorPy();

    public long registerWaybill(WaybillRequestImpl request) throws WaybillRegistrationWebServiceException {
        validator.validate(request);
        WaybillDtoPy waybillDto = mapToDto(request);
        try {
        	return this.waybillService.registerWaybill(waybillDto);
        } catch (BusinessException e) {
            throw new WaybillRegistrationWebServiceException(e);
        } catch (Exception e) {
            throw new WaybillRegistrationWebServiceException(e);
        }
    }

    protected WaybillDtoPy mapToDto(WaybillRequestImpl request) {
    	WaybillDtoPy waybillDto = super.mapToDto(request);
        waybillDto.setHolderDeclaredAsPod(request.isHolderPodDeclared());
    	waybillDto.setReceiptNumber(request.getReceiptNumber());
    	waybillDto.setHolderDocumentType(request.getHolderDocumentType());
    	waybillDto.setCommercialSenderDocumentType(request.getCommercialSenderDocumentType());
    	waybillDto.setAddresseeDocumentType(request.getAddresseeDocumentType());
    	waybillDto.setDestinationDocumentType(request.getDestinationDocumentType());
        return waybillDto;
    }

    @Override
    protected WaybillDtoPy newWaybillDto() {
        return new WaybillDtoPy();
    }

}