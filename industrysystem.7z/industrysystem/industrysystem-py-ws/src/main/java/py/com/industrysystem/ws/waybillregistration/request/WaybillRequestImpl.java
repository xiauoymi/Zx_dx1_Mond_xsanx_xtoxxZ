package py.com.industrysystem.ws.waybillregistration.request;

import com.industrysystem.ws.waybillregistration.request.WaybillRequest;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class WaybillRequestImpl extends WaybillRequest {

	private String receiptNumber;
    @XmlElement(required=true)
    private Boolean holderPodDeclared;
    private String holderDocumentType;
    private String commercialSenderDocumentType;
    private String addresseeDocumentType;
    private String destinationDocumentType;

    public boolean isHolderPodDeclared() {
        return holderPodDeclared;
    }

    public void setHolderPodDeclared(Boolean holderPodDeclared) {
        this.holderPodDeclared = holderPodDeclared;
    }

	public String getReceiptNumber() {
		return receiptNumber;
	}

	public void setReceiptNumber(String receiptNumber) {
		this.receiptNumber = receiptNumber;
	}

	public String getHolderDocumentType() {
		return holderDocumentType;
	}

	public void setHolderDocumentType(String holderDocumentType) {
		this.holderDocumentType = holderDocumentType;
	}

	public String getCommercialSenderDocumentType() {
		return commercialSenderDocumentType;
	}

	public void setCommercialSenderDocumentType(String commercialSenderDocumentType) {
		this.commercialSenderDocumentType = commercialSenderDocumentType;
	}

	public String getAddresseeDocumentType() {
		return addresseeDocumentType;
	}

	public void setAddresseeDocumentType(String addresseeDocumentType) {
		this.addresseeDocumentType = addresseeDocumentType;
	}

	public String getDestinationDocumentType() {
		return destinationDocumentType;
	}

	public void setDestinationDocumentType(String destinationDocumentType) {
		this.destinationDocumentType = destinationDocumentType;
	}

}