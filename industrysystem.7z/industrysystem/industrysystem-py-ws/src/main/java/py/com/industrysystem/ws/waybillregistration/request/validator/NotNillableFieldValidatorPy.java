package py.com.industrysystem.ws.waybillregistration.request.validator;

import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.ws.exceptions.WaybillRegistrationWebServiceException;
import com.industrysystem.ws.waybillregistration.request.validator.NotNillableFieldValidator;
import py.com.industrysystem.ws.waybillregistration.request.WaybillRequestImpl;

/**
 * User: PPERA
 * Date: 15/01/14
 * Time: 15:28
 */
public class NotNillableFieldValidatorPy extends NotNillableFieldValidator<WaybillRequestImpl> {

    @Override
    public void validate(WaybillRequestImpl request) throws WaybillRegistrationWebServiceException {
        try {
            request.isHolderPodDeclared();
        } catch (NullPointerException ex) {
            throw new WaybillRegistrationWebServiceException(new BusinessError(BusinessError.EMPTY_MANDATORY_FIELDS,
                    "Mandatory field(s) holderPodDeclared"));
        }

        super.validate(request);
    }

    @Override
    protected String getEmptyFieldsNames(WaybillRequestImpl request) {
        StringBuilder emptyFields = new StringBuilder();
        getCommonEmptyFieldsNames(request, emptyFields);
        return emptyFields.toString();
    }

}