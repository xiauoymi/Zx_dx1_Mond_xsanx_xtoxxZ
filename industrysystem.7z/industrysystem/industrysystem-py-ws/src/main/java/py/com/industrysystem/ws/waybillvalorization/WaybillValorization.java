package py.com.industrysystem.ws.waybillvalorization;

import com.industrysystem.business.dtos.WaybillValorizationItemDto;
import com.industrysystem.ws.exceptions.WaybillValorizationServiceException;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import java.util.List;

/**
 * User: LSCH1
 */
@WebService
@SOAPBinding(style = SOAPBinding.Style.RPC, use = SOAPBinding.Use.LITERAL)
public interface WaybillValorization {
    @WebMethod(operationName = "waybillValorization")
    public String waybillValorization(@WebParam(name = "waybillNumber") String waybillNumber,
                                      @WebParam(name = "traitOwnerCode") String traitOwnerCode,
                                      @WebParam(name = "items") List<WaybillValorizationItemDto> items
    ) throws WaybillValorizationServiceException;
}
