package py.com.industrysystem.ws.waybillvalorization;

import com.industrysystem.business.WaybillService;
import com.industrysystem.business.dtos.WaybillValorizationItemDto;
import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.WaybillValorizationException;
import com.industrysystem.ws.exceptions.WaybillValorizationServiceException;
import com.industrysystem.ws.exceptions.WebServiceError;
import org.apache.cxf.feature.Features;
import org.springframework.beans.factory.annotation.Autowired;

import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import java.util.List;

import static com.industrysystem.business.validators.WaybillValidator.isWaybillNumber;
import static org.apache.commons.lang.StringUtils.isEmpty;

/**
 * User: LSCHW1
 */
@WebService(endpointInterface = "py.com.industrysystem.ws.waybillvalorization.WaybillValorization", serviceName = "WaybillValorizationPY")
@Features(classes = org.apache.cxf.feature.LoggingFeature.class)
@XmlSeeAlso(WebServiceError.class)
public class WaybillValorizationImpl implements WaybillValorization {

    @Autowired
    private WaybillService waybillService;

    @Override
    public String waybillValorization(String waybillNumber, String traitOwnerCode, List<WaybillValorizationItemDto> items)
            throws WaybillValorizationServiceException {
        try {
            if (isEmpty(waybillNumber)) {
                throw new WaybillValorizationException(new BusinessError(BusinessError.WAYBILL_NUMBER_BLANK_OR_ABSENT, "Waybill number cannot be null"));
            }
            if (!isWaybillNumber(waybillNumber)) {
                throw new WaybillValorizationException(new BusinessError(BusinessError.INVALID_WAYBILL_NUMBER, "Waybill number is invalid"));
            }

            waybillService.valorizateWaybill(Long.parseLong(waybillNumber), traitOwnerCode, items);

            return "OK";
        } catch (Exception e) {
            throw new WaybillValorizationServiceException(e);
        }
    }

}