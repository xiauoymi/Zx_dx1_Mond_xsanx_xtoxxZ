package py.com.industrysystem.ws.accountsregistration;

import com.industrysystem.business.GrowersService;
import com.industrysystem.business.users.dtos.GrowerAccountDto;
import com.industrysystem.ws.accountsregistration.AccountsRegistrationCommonImpl;
import com.industrysystem.ws.accountsregistration.request.NewAccountData;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * User: PMIRIB
 * Date: 22/01/14
 */
public class AccountsRegistrationImpl_UT {

    private AccountsRegistrationImpl accountsRegistrationImpl;
    private GrowersService coreService;

    @Before
    public void setUp() {
        this.accountsRegistrationImpl = new AccountsRegistrationImpl();
        this.coreService = mock(GrowersService.class);
        field("coreService").ofType(GrowersService.class).in(this.accountsRegistrationImpl).set(this.coreService);
    }

    @Test
    public void testRegisterAccounts() throws Exception {
        List<NewAccountData> newAccountDataList = new ArrayList<NewAccountData>();
        NewAccountData newAccountData = new NewAccountData();
        newAccountDataList.add(newAccountData);

        // @When registering the newAccountData list
        this.accountsRegistrationImpl.registerAccounts(newAccountDataList);

        // @Then accountsDao.save is called for an newAccountData entity
        verify(this.coreService).register((List<GrowerAccountDto>)any());

    }
}
