package py.com.industrysystem.ws.groweraccountupdate;

import com.industrysystem.business.GrowerBalanceService;
import com.industrysystem.business.dtos.GrowerBalanceOperationDto;
import com.industrysystem.business.dtos.TransactionDto;
import com.industrysystem.exceptions.GrowerAccountUpdateException;
import com.industrysystem.exceptions.WaybillValorizationException;
import com.industrysystem.ws.exceptions.GrowerAccountUpdateServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.emptyList;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

/**
 * User: LSCHW1
 */

@RunWith(MockitoJUnitRunner.class)
public class GrowerAccountUpdateImpl_UT {

    @Mock
    private GrowerBalanceService growerBalanceService;
    @InjectMocks
    private GrowerAccountUpdateImpl growerAccountUpdate;
    @Captor
    private ArgumentCaptor<ArrayList<GrowerBalanceOperationDto>> listCaptor;
    @Captor
    private ArgumentCaptor<TransactionDto> transactionCaptor;

    @Test
    public void growerAccountUpdate_ShouldCallregisterBalanceOperationsAndReturnOK_WhenregisterBalanceOperationsProcessOk()
            throws GrowerAccountUpdateServiceException, GrowerAccountUpdateException {
       String traitOwnerCode = "MONSANTO";
       List<GrowerBalanceOperationDto> itemsDto = emptyList();
       TransactionDto transactionDto = new TransactionDto();

       String result = growerAccountUpdate.growerAccountUpdate(itemsDto, transactionDto, traitOwnerCode);

       verify(growerBalanceService).registerBalanceOperations(transactionCaptor.capture(), listCaptor.capture(), eq(traitOwnerCode));
       assertThat(listCaptor.getValue()).isEqualTo(itemsDto);
       assertThat(transactionCaptor.getValue()).isEqualTo(transactionDto);
       assertThat(result).isEqualTo("OK");
    }

    @Test
    public void growerAccountUpdate_ShouldThrowGrowerAccountUpdateServiceException_WhenregisterBalanceOperationsThrowsException()
            throws WaybillValorizationException, GrowerAccountUpdateException {
       String traitOwnerCode = "MONSANTO";
       List<GrowerBalanceOperationDto> itemsDto = emptyList();
       TransactionDto transactionDto = new TransactionDto();
       doThrow(GrowerAccountUpdateServiceException.class).when(growerBalanceService).registerBalanceOperations(any(TransactionDto.class),
               anyList(), anyString());

       try {
           growerAccountUpdate.growerAccountUpdate(itemsDto,transactionDto, traitOwnerCode);

           fail();
       } catch (GrowerAccountUpdateServiceException e) {
           assertThat(true);
       }
    }

}