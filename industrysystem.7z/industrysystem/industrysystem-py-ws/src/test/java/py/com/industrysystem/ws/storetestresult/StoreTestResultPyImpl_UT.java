package py.com.industrysystem.ws.storetestresult;

import com.industrysystem.business.TestsService;
import com.industrysystem.business.dtos.QualitativeTestResultDto;
import com.industrysystem.business.dtos.QuantitativeTestResultDto;
import com.industrysystem.business.dtos.StakeholdersDto;
import com.industrysystem.entities.Document;
import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.exceptions.StoreTestResultException;
import com.industrysystem.ws.exceptions.StoreTestResultWebServiceException;
import com.industrysystem.ws.exceptions.WebServiceException;
import com.industrysystem.ws.validators.Validator;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;

/**
 * User: PMIRIB
 * Date: 16/10/13
 */
public class StoreTestResultPyImpl_UT {

    private StoreTestResultPy storeTestResultPy;
    private TestsService testService;

    private String sampleCode;
    private Document destinationDocument = new Document("CEDULA", "2");
    private List<QualitativeTestResultDto> qualitativeTestResults = new ArrayList<QualitativeTestResultDto>();
    private List<QuantitativeTestResultDto> quantitativeTestResults = new ArrayList<QuantitativeTestResultDto>();
    private StakeholdersDto stakeholders;

    @Before
    public void setUp() {
        this.storeTestResultPy = new StoreTestResultPyImpl();
        this.testService = mock(TestsService.class);
        field("testService").ofType(TestsService.class).in(this.storeTestResultPy).set(this.testService);
        Validator validator = mock(Validator.class);
        field("validator").ofType(Validator.class).in(this.storeTestResultPy).set(validator);
    }

    @Test
    public void storeTestResults_throwsException_whenValidateThrowsException() throws Exception {
        Throwable exception = new StoreTestResultException(new BusinessError(BusinessError.QUANTITATIVE_TEST_RESULT_NOT_EXPECTED, "dummy"));
        doThrow(exception).when(this.testService).storeTestResultsByDestination(destinationDocument, sampleCode, quantitativeTestResults, qualitativeTestResults, stakeholders);
        try {
            storeTestResultPy.storeTestResults(destinationDocument.getNumber(),destinationDocument.getTypeCode(), sampleCode, quantitativeTestResults, qualitativeTestResults, stakeholders);
            fail("A WebServiceException should be thrown");
        } catch (WebServiceException ex) {
            assertThat(ex.getErrors()).onProperty("code").contains(BusinessError.QUANTITATIVE_TEST_RESULT_NOT_EXPECTED);
        }
    }

    @Test
    public void storeTestResults_throwsException_whenTestServiceThrowsException() throws Exception {
        Throwable exception = new RuntimeException();
        doThrow(exception).when(this.testService).storeTestResultsByDestination(destinationDocument, sampleCode, quantitativeTestResults, qualitativeTestResults, stakeholders);
        try {
            storeTestResultPy.storeTestResults(destinationDocument.getNumber(),destinationDocument.getTypeCode(), sampleCode, quantitativeTestResults, qualitativeTestResults, stakeholders);
            fail("A StoreTestResultWebServiceException should be thrown");
        } catch (StoreTestResultWebServiceException ex) {
            assertTrue(true);
        }
    }

    @Test
    public void storeTestResults_OK_whenEverythingOk() throws Exception {
        storeTestResultPy.storeTestResults(destinationDocument.getNumber(),destinationDocument.getTypeCode(), sampleCode, quantitativeTestResults, qualitativeTestResults, stakeholders);
        assertTrue(true);
    }

}
