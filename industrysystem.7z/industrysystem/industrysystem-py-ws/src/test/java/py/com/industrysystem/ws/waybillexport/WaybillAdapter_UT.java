package py.com.industrysystem.ws.waybillexport;

import com.industrysystem.business.dtos.TraitOwnerMessagesContainerDTO;
import com.industrysystem.entities.*;
import org.junit.Before;
import org.junit.Test;

import java.math.BigInteger;
import java.util.ArrayList;

import static java.util.Collections.singletonList;
import static org.junit.Assert.*;

public class WaybillAdapter_UT {

    private Waybill waybill;
    private TraitOwnerMessagesContainerDTO traitOwnerMessagesContainerDTO;
    private WaybillAdapter adapter;

    @Before
    public void setUp() {
        waybill = new WaybillBuilderForCoreTests().build();
        traitOwnerMessagesContainerDTO = new TraitOwnerMessagesContainerDTO();
        adapter = new WaybillAdapter(waybill, traitOwnerMessagesContainerDTO);
    }

    @Test
    public void testGetWaybillSucceeds() {
        Technology technology = new Technology();
        technology.setCode("INTACTA");
        CropTechnology cropTechnology = new CropTechnology();
        cropTechnology.setTechnology(technology);
        Laboratory laboratory = new Laboratory();
        laboratory.setCode("MICRO TECH SA");
        traitOwnerMessagesContainerDTO.setName(new Document(WaybillBuilder.DOCUMENT_TYPE_CODE, WaybillBuilder.HOLDER_DOCUMENT_NUMBER), "JUAN");
        traitOwnerMessagesContainerDTO.setName(new Document(WaybillBuilder.DOCUMENT_TYPE_CODE, WaybillBuilder.ADDRESSEE_DOCUMENT_NUMBER), "PEDRO");
        traitOwnerMessagesContainerDTO.setName(new Document(WaybillBuilder.DOCUMENT_TYPE_CODE, WaybillBuilder.DESTINATION_DOCUMENT_NUMBER), "MATEO");
        traitOwnerMessagesContainerDTO.setWaybillTechnologies(waybill.getId(), singletonList(new WaybillTechnology(cropTechnology, 50, laboratory)));

        py.com.industrysystem.ws.waybillexport.response.Waybill result = adapter.getWaybill();

        assertEquals(WaybillBuilder.CTG, result.getCtgNumber().toString());
        //For PY waybillNumber is ID of Waybill
        assertEquals("45", result.getWaybillNumber().toString());
        assertEquals(py.com.industrysystem.ws.waybillexport.response.TransportType.TRUCK, result.getTransportType());
        assertEquals("JUAN", result.getHolderName());
        assertEquals(WaybillBuilder.HOLDER_DOCUMENT_NUMBER, result.getHolderDocumentNumber().toString());
        assertNull(result.getIntermediaryDocumentNumber());
        assertNull(result.getCommercialSenderDocumentNumber());
        assertNull(result.getBrokerDocumentNumber());
        assertNull(result.getAgentDocumentNumber());
        assertEquals("PEDRO", result.getAddresseeName());
        assertEquals(WaybillBuilder.ADDRESSEE_DOCUMENT_NUMBER, result.getAddresseeDocumentNumber().toString());
        assertEquals("MATEO", result.getDestinationName());
        assertEquals(WaybillBuilder.DESTINATION_DOCUMENT_NUMBER, result.getDestinationDocumentNumber().toString());
        assertEquals(WaybillBuilder.CAMPAIGN_CODE, result.getCampaignCode());
        assertEquals(WaybillBuilder.CROP_CODE, result.getCropCode());
        assertNull(result.getEstablishment());
        assertEquals(WaybillBuilder.WEIGHT.intValue(), result.getNetWeight().intValue());
        assertEquals(WaybillBuilder.GOODS_SOURCE_CITY, result.getSourceCityCode());
        assertEquals("NOT INFORMED", result.getSourceStateCode());
        assertEquals(WaybillBuilder.GOODS_DESTINATION_CITY, result.getDestinationCityCode());
        assertEquals("NOT INFORMED", result.getDestinationStateCode());
        assertEquals(WaybillBuilder.DEVIATION_DESTINATION_DOCUMENT_NUMBER, result.getDeviation().getDestinationDocumentNumber().toString());
        assertEquals(WaybillBuilder.DEVIATION_PLANT_CODE, result.getDeviation().getDestinationPlantCode());
        assertEquals(WaybillBuilder.DEVIATION_ADDRESSEE_DOCUMENT_NUMBER, result.getDeviation().getAddresseeDocumentNumber().toString());
        assertEquals(WaybillBuilder.DEVIATION_ADDRESSEE_CITY, result.getDeviation().getAddresseeCityCode());
        assertEquals(1, result.getLabResults().size());
        assertEquals("INTACTA", result.getLabResults().get(0).getTechnologyCode());
        assertEquals(50, result.getLabResults().get(0).getWeightDetected().intValue());
        assertEquals("MICRO TECH SA", result.getLabResults().get(0).getLabCode());
    }

    @Test
    public void testGetCtgNumberWithoutCtgReturnsNull() {
        ((TruckLoadDetail)waybill.getLoadDetails().iterator().next()).setCtg(null);

        assertNull(adapter.getCtgNumber());
    }

    @Test
    public void testGetCtgNumberWithWagonLoadDetailReturnsNull() {
        waybill.getLoadDetails().clear();
        waybill.getLoadDetails().add(new WagonLoadDetail());

        assertNull(adapter.getCtgNumber());
    }

    @Test
    public void testGetCtgNumberWithNoLoadDetailsReturnsNull() {
        waybill.getLoadDetails().clear();

        assertNull(adapter.getCtgNumber());
    }

    @Test
    public void testGetNetWeightWithNoLoadDetailsReturnsZero() {
        waybill.getLoadDetails().clear();

        assertEquals(BigInteger.ZERO, adapter.getNetWeight());
    }

    @Test
    public void testGetNetWeightWithNoWeightReturnsZero() {
        waybill.getLoadDetails().iterator().next().setWeight(null);

        assertEquals(BigInteger.ZERO, adapter.getNetWeight());
    }

    @Test
    public void testGetDeviationWithNoDeviationReturnsNull() {
        waybill.setWaybillDeviation(null);

        assertNull(adapter.getDeviation());
    }

    @Test
    public void testGetDeviationDestinationDocumentNumberWithNoDeviationReturnsNull() {
        waybill.setWaybillDeviation(null);

        assertNull(adapter.getDeviationDestinationDocumentNumber());
    }

    @Test
    public void testGetDeviationDestinationDocumentNumberWithNoDeviationDestinationDocumentNumberReturnsNull() {
        waybill.getWaybillDeviation().setDestinationDocumentNumber(null);

        assertNull(adapter.getDeviationDestinationDocumentNumber());
    }

    @Test
    public void testGetDeviationAddresseeDocumentNumberWithNoDeviationReturnsNull() {
        waybill.setWaybillDeviation(null);

        assertNull(adapter.getDeviationAddresseeDocumentNumber());
    }

    @Test
    public void testGetDeviationAddresseeDocumentNumberWithNoDeviationAddresseeDocumentNumberReturnsNull() {
        waybill.getWaybillDeviation().setAdresseeDocumentNumber(null);

        assertNull(adapter.getDeviationAddresseeDocumentNumber());
    }

    @Test
    public void testGetLabResultsWithNoWaybillTechnologiesReturnsEmptyList() {
        traitOwnerMessagesContainerDTO.setWaybillTechnologies(waybill.getId(), new ArrayList<WaybillTechnology>());

        assertTrue(adapter.getLabResults().isEmpty());
    }

    @Test
    public void testGetLabResultsWithNoLaboratoryReturnsNullLabCode() {
        Technology technology = new Technology();
        technology.setCode("INTACTA");
        CropTechnology cropTechnology = new CropTechnology();
        cropTechnology.setTechnology(technology);
        traitOwnerMessagesContainerDTO.setWaybillTechnologies(waybill.getId(), singletonList(new WaybillTechnology(cropTechnology, 150, null)));

        assertNull(adapter.getLabResults().get(0).getLabCode());
    }

}