package py.com.industrysystem.ws.waybillexport;

import com.industrysystem.business.EventService;
import com.industrysystem.business.WaybillService;
import com.industrysystem.business.dtos.TraitOwnerMessagesContainerDTO;
import com.industrysystem.entities.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import py.com.industrysystem.ws.waybillexport.response.Response;


import java.util.List;

import static java.util.Collections.emptyList;
import static java.util.Collections.singleton;
import static java.util.Collections.singletonList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class WaybillExportImpl_UT {

    @Mock private WaybillService waybillExportService;
    @InjectMocks private WaybillExportImpl waybillExport;
    @Mock private EventService eventService;

    @Test
    public void testExportWaybillsSucceeds() throws Exception {
        List<WaybillTechnology> waybillTechnologies = emptyList();
        Waybill waybill = new WaybillBuilderForCoreTests().build();
        WaybillMessage waybillMessage = new WaybillMessage();
        waybillMessage.setWaybill(waybill);
        TraitOwnerMessage traitOwnerMessage = new TraitOwnerMessage();
        traitOwnerMessage.setMessageSequence(33L);
        traitOwnerMessage.setWaybillMessages(singleton(waybillMessage));
        TraitOwnerMessagesContainerDTO dto = new TraitOwnerMessagesContainerDTO();
        dto.setTraitOwnerMessages(singletonList(traitOwnerMessage));
        dto.setWaybillTechnologies(waybill.getId(), waybillTechnologies);
        dto.setHasMore(true);
        when(waybillExportService.retrieveTraitOwnerMessages(5)).thenReturn(dto);

        Response response = waybillExport.exportWaybills(5);

        assertEquals(1, response.getBulks().size());
        assertEquals(33L, response.getBulks().get(0).getId());
        assertEquals(1, response.getBulks().get(0).getWaybills().size());
        assertEquals(waybill.getWaybillNumber().toString(), response.getBulks().get(0).getWaybills().get(0).getWaybillNumber().toString());
        assertTrue(response.isHasMore());
        verify(waybillExportService).retrieveTraitOwnerMessages(5);
    }

}