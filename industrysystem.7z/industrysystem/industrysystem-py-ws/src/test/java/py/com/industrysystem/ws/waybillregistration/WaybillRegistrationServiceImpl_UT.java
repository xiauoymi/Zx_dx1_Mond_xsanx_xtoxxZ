package py.com.industrysystem.ws.waybillregistration;

import com.industrysystem.business.dtos.TruckDetailDTO;
import com.industrysystem.ws.exceptions.WebServiceException;
import com.industrysystem.ws.waybillregistration.request.LoadDetail;
import com.industrysystem.ws.waybillregistration.request.TruckLoadDetail;
import org.junit.Test;
import py.com.industrysystem.business.dtos.WaybillDtoPy;
import py.com.industrysystem.ws.waybillregistration.request.WaybillRequestImpl;

import java.util.LinkedList;

import static com.google.common.collect.Iterables.getOnlyElement;
import static org.fest.assertions.Assertions.assertThat;

public class WaybillRegistrationServiceImpl_UT {

    @Test
    public void testMapToDtoGivenWaybillRequestAndRequestServiceWithTruckWhenMapToDtoThenMapAllTheAttributes() throws WebServiceException {
        // Given waybill request
        // a waybill service
        // a truck
        WaybillRegistrationServiceImpl service = new WaybillRegistrationServiceImpl();
        WaybillDtoPy dto;
        WaybillRequestImpl request = createRequest();

        // When map to dtos
        dto = service.mapToDto(request);

        // Then map all the dtos attributes
        assertThat(((TruckDetailDTO)getOnlyElement(dto.getLoadDetails())).getCtg()).isEqualTo(((TruckLoadDetail)getOnlyElement(request.getLoadsDetail())).getCtg());
        assertThat((getOnlyElement(dto.getLoadDetails())).getDeclaredTechnology()).isEqualTo(getOnlyElement(request.getLoadsDetail()).getTechnology());
        assertThat(dto.getWaybillType()).isEqualTo(request.getWaybillType());
        assertThat(dto.getHolderDocument() == request.getHolderDocument()).isTrue();
        assertThat(dto.getAddresseeDocument() == request.getAddresseeDocument()).isTrue();
        assertThat(dto.getDestinationDocument() == request.getDestinationDocument()).isTrue();
        assertThat(dto.getOriginLocation()).isEqualTo(Long.valueOf(request.getOriginLocation()));
        assertThat(dto.getDestinationLocation()).isEqualTo(Long.valueOf(request.getDestinationLocation()));
        assertThat(dto.isHolderDeclaredAsPod() == request.isHolderPodDeclared()).isTrue();
    }

    private WaybillRequestImpl createRequest() {
        WaybillRequestImpl request = new WaybillRequestImpl();
        TruckLoadDetail truck = new TruckLoadDetail();
        LinkedList<LoadDetail> loadDetails = new LinkedList<LoadDetail>();

        truck.setCtg("CTG");
        truck.setTechnology("TECHNOLOGY");
        loadDetails.add(truck);

        request.setLoadsDetail(loadDetails);
        request.setWaybillType("TRANSPORTE AUTOMOTOR");
        request.setHolderName("MARIA");
        request.setHolderDocument("1228078452");
        request.setCommercialSenderName("TEST");
        request.setCommercialSenderDocument("2518183183");
        request.setAddresseeDocument("3131318611");
        request.setDestinationDocument("161863186186");
        request.setGrain("SOJA");
        request.setOriginLocation("3");
        request.setDestinationLocation("4");
        request.setDestinationCommercialCode("2");
        request.setHolderPodDeclared(false);

        return request;
    }

}