package py.com.industrysystem.ws.waybillregistration.request.validators;

import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.entities.TransportType;
import com.industrysystem.exceptions.BusinessError;
import com.industrysystem.ws.exceptions.WaybillRegistrationWebServiceException;
import com.industrysystem.ws.waybillregistration.request.LoadDetail;
import junit.framework.Assert;
import org.junit.Test;
import py.com.industrysystem.ws.waybillregistration.request.WaybillRequestImpl;
import py.com.industrysystem.ws.waybillregistration.request.validator.NotNillableFieldValidatorPy;

import static com.google.common.collect.Lists.newArrayList;
import static junit.framework.Assert.assertTrue;
import static org.apache.commons.lang.StringUtils.EMPTY;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;

public class NotNillableFieldValidatorPyImpl_UT {

    @Test
    public void testValidate_ThrowsNullPointerException_WhenGetIsPodDeclared(){
    	//Given WaybillRequest
    	WaybillRequestImpl waybillRequest = mock(WaybillRequestImpl.class);

    	//When get idPodDeclared from Request
    	doThrow(NullPointerException.class).when(waybillRequest).isHolderPodDeclared();

    	//Then NullPointerException is obtained
    	try{
            new NotNillableFieldValidatorPy().validate(waybillRequest);
    		Assert.fail();
    	}catch(WaybillRegistrationWebServiceException wrwse){
    		assertThat(wrwse.getMessage().contains(BusinessError.EMPTY_MANDATORY_FIELDS));
    	}
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsExceptNullWaybillType_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with null waybillNumber field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setWaybillType(null);

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) waybillType ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsExceptEmptyWaybillType_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with empty waybillNumber field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setWaybillType("");

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) waybillType ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsExceptNullHolderName_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with null holderName field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setHolderName(null);

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) holderName ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsExceptEmptyHolderName_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with empty waybillNumber field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setHolderName("");

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) holderName ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsExceptNegativeHolderDoc_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with negative holderDocument field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setHolderDocument(EMPTY);

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) holderDocument ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsExceptNegativeAddresseeDocument_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with negative addresseeDocument field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setAddresseeDocument(EMPTY);

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) addresseeDocument ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsExceptNegativeDestinationDocument_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with negative destinationDocument field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setDestinationDocument(EMPTY);

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) destinationDocument ");
        } catch (Throwable throwable) {
            fail();
        }
    }


    @Test
    public void testValidateGivenRequestWithAllFieldsExceptNullGrain_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with null grain field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setGrain(null);

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) grain ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsEmptyGrain_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with empty grain field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setGrain("");

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) grain ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsExceptNullOriginLocation_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with null originLocation field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setOriginLocation(null);

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) originLocation ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsEmptyOriginLocation_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with empty originLocation field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setOriginLocation(EMPTY);

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) originLocation ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsExceptNullDestinationLocation_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with null destinationLocation field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setDestinationLocation(null);

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) destinationLocation ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithAllFieldsEmptyDestinationLocation_WhenValidate_ThenThrowWaybillRegistrationWebServiceException() {
        // Given
        // a request with empty destinationLocation field and the rest of the field filled
        // a validator
        WaybillRequestImpl request = createFullFillWaybillRequest();
        request.setDestinationLocation(EMPTY);

        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        // When request is validated
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException ex) {
            // Then an Web Service exception is throw with mandatory field message
            assertThat(ex).hasMessage("Mandatory field(s) destinationLocation ");
        } catch (Throwable throwable) {
            fail();
        }
    }

    @Test
    public void testValidateGivenRequestWithMandatoryFields_WhenValidate_NotThrowWaybillRegistrationWebServiceException() {
        // Given a waybill object with all the mandatory field filled and
        // a request validator for paraguay
        WaybillRequestImpl request = createWaybillRequestWithMandatoryFields();
        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();

        try {
            // When the do validation
            validator.validate(request);

            // Then no validation error exception is throw
            assertTrue(true);
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    public void testValidateGivenWaybillRequestWithTwoMandatoryFieldsEmptyWhenValidateThenThenThrowExceptionWithMessage() {
        // Given a waybill request with two mandatory fields empty and
        // a paraguay validator
        WaybillRequestImpl request = createWaybillRequestWithMandatoryFields();
        NotNillableFieldValidatorPy validator = new NotNillableFieldValidatorPy();
        request.setGrain(null);

        // When validate the request
        try {
            validator.validate(request);
            fail();
        } catch (WaybillRegistrationWebServiceException e) {
            // Then an exception with the mandatory fields error
            assertThat(e.getMessage().contains("Mandatory field(s)")).isTrue();
            assertThat(e.getMessage().contains("grain")).isTrue();
        }
    }

    private WaybillRequestImpl createWaybillRequestWithMandatoryFields() {
        WaybillRequestImpl request = new WaybillRequestImpl();

        request.setWaybillType("BARCAZA");
        request.setHolderName("JUAN");
        request.setHolderDocument("12345678901");
        request.setAddresseeDocument("12345678901");
        request.setDestinationDocument("12345678901");
        request.setGrain("SOJA");
        request.setOriginLocation("3");
        request.setDestinationLocation("3");
        request.setHolderPodDeclared(true);
        request.setDestinationCommercialCode("2");
        request.setLoadsDetail(newArrayList((LoadDetail)new LoadDetail() {
            @Override
            public LoadDetailDTO toDto() {
                return null;
            }
            @Override
            public boolean isOfTransportType(TransportType transportType) {
                return false;
            }
        }));

        return request;
    }

    private WaybillRequestImpl createFullFillWaybillRequest() {
        WaybillRequestImpl request = new WaybillRequestImpl();

        request.setWaybillType("BARCAZA");
        request.setHolderName("JUAN");
        request.setHolderDocument("12345678901");
        request.setCommercialSenderName("ROBERTO");
        request.setCommercialSenderDocument("12345678901");
        request.setAddresseeDocument("12345678901");
        request.setDestinationDocument("12345678901");
        request.setGrain("SOJA");
        request.setOriginLocation("3");
        request.setDestinationLocation("3");
        request.setDestinationCommercialCode("1");
        request.setHolderPodDeclared(true);

        return request;
    }

}