package py.com.industrysystem.ws.waybillvalorization;

import com.industrysystem.business.WaybillService;
import com.industrysystem.business.dtos.WaybillValorizationItemDto;
import com.industrysystem.exceptions.UserNotLoggedException;
import com.industrysystem.exceptions.WaybillValorizationException;
import com.industrysystem.ws.exceptions.WaybillValorizationServiceException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.emptyList;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.assertions.Fail.fail;
import static org.mockito.Matchers.*;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;

/**
 * User: LSCHW1
 */
@RunWith(MockitoJUnitRunner.class)
public class WaybillValorizationImpl_UT {

    @Mock private WaybillService waybillService;
    @InjectMocks private WaybillValorizationImpl waybillValorization;
    @Captor private ArgumentCaptor<ArrayList<WaybillValorizationItemDto>> listCaptor;

    @Test
    public void waybillValorization_ShouldCallvalorizateWaybillAndReturnOK_WhenvalorizateWaybillProcessOk()
            throws WaybillValorizationException, WaybillValorizationServiceException, UserNotLoggedException {
        Long waybillNumber = 123L;
        String traitOwnerCode = "MONSANTO";
        List<WaybillValorizationItemDto> itemsDto = emptyList();

        String result = waybillValorization.waybillValorization(waybillNumber.toString(), traitOwnerCode, itemsDto);

        verify(waybillService).valorizateWaybill(eq(waybillNumber), eq(traitOwnerCode), listCaptor.capture());
        assertThat(listCaptor.getValue()).isEqualTo(itemsDto);
        assertThat(result).isEqualTo("OK");
    }

    @Test
    public void waybillValorization_ShouldThrowWaybillValorizationServiceException_WhenvalorizateWaybillThrowsException()
            throws WaybillValorizationException, UserNotLoggedException {
        String waybillNumber = "123";
        String traitOwnerCode = "MONSANTO";
        List<WaybillValorizationItemDto> itemsDto = emptyList();
        doThrow(WaybillValorizationServiceException.class).when(waybillService).valorizateWaybill(any(Long.class), anyString(), anyList());

        try {
            waybillValorization.waybillValorization(waybillNumber, traitOwnerCode, itemsDto);

            fail();
        } catch (WaybillValorizationServiceException e) {
            assertThat(true);
        }
    }

}