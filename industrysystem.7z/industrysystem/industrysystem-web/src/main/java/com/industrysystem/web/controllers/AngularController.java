package com.industrysystem.web.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.view.DefaultRequestToViewNameTranslator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * User: PPERA
 * Date: 12/12/13
 * Time: 09:48
 */
@Controller
public class AngularController {

    @RequestMapping(value = "/partials/grower/loginerror.jsp")
    public void viewGrowerAuthErrorPage(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.sendRedirect("spring/partials/index.jsp#/grower");
        request.getSession().setAttribute("loginError", true);

    }

    @RequestMapping(value = "/partials/admin/loginerror.jsp")
    public void viewAdminAuthErrorPage(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.sendRedirect("spring/partials/index.jsp#/admin");
        request.getSession().setAttribute("loginError", true);

    }

    @RequestMapping(value = "/partials/laboratory/loginerror.jsp")
    public void viewLaboratoryAuthErrorPage(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.sendRedirect("spring/partials/index.jsp#/laboratory");
        request.getSession().setAttribute("loginError", true);

    }

    @RequestMapping(value = "/partials/pod/loginerror.jsp")
    public void viewPodAuthErrorPage(HttpServletResponse response, HttpServletRequest request) throws IOException {
        response.sendRedirect("spring/partials/index.jsp#/pod");
        request.getSession().setAttribute("loginError", true);

    }

    @RequestMapping(value = "/partials/**/login.jsp")
    public String viewLoginPage(HttpServletRequest request, @RequestParam(required = false) String loginType, Model model) {

        Boolean loginError = (Boolean) request.getSession().getAttribute("loginError");
        model.addAttribute("authenticationError", loginError);
        model.addAttribute("loginType", loginType);

        return makePageViewName(request);
    }

    @RequestMapping(value = "/partials/grower/secured/summary.jsp")
    public String viewGrowerSummaryPage(HttpServletRequest request, Model model) {
        model.addAttribute("today", new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
        return makePageViewName(request);
    }

    @RequestMapping(value = "/partials/**/*.jsp")
    public String viewPage(HttpServletRequest request) {
        return makePageViewName(request);
    }

    private String makePageViewName(HttpServletRequest request) {
        DefaultRequestToViewNameTranslator translator = new DefaultRequestToViewNameTranslator();
        String viewName = translator.getViewName(request);
        int slashIndex = viewName.indexOf("/");
        return viewName.substring(slashIndex);
    }
}
