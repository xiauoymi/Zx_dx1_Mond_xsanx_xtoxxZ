package com.industrysystem.web.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Function;
import com.industrysystem.business.GrowerBalanceService;
import com.industrysystem.business.GrowersService;
import com.industrysystem.business.dtos.GrowerBalanceDTO;
import com.industrysystem.business.users.UsersService;
import com.industrysystem.entities.Document;
import com.industrysystem.entities.Grower;
import com.industrysystem.exceptions.CampaignNotFoundException;
import com.industrysystem.exceptions.GrowerNotFoundException;
import com.industrysystem.exceptions.TechnologyNotFoundException;
import com.industrysystem.web.dtos.GrowerDTO;

import static com.google.common.collect.Lists.transform;

/**
 * User: ASEQU
 * Date: 11/21/13
 * Time: 9:09 AM
 */
@Controller
public class BalanceController {

	@Autowired
    private UsersService usersService;

    @Autowired
    private GrowersService growersService;
	
    @Autowired
    private GrowerBalanceService growerBalanceService;

    @RequestMapping(value = "/rest/grower/{documentNumber}/{documentType}/technology/{technologyCode}", method= RequestMethod.GET)
    @ResponseBody
    public List<GrowerBalanceDTO> getBalancesFilteredBy(@PathVariable String documentNumber, @PathVariable String documentType,
            @PathVariable String technologyCode) throws CampaignNotFoundException, GrowerNotFoundException, TechnologyNotFoundException {
        return growerBalanceService.findConsolidatedNetAvailableCreditBy(documentNumber, documentType, technologyCode);
    }

    @RequestMapping(value = "/rest/grower/holder.json", method= RequestMethod.GET)
    @ResponseBody
    public List<GrowerDTO> listCurrentUserHolders() {
    	List<Document> growerDocumentsForCurrentUser = usersService.listGrowerDocumentsForCurrentUser();

    	if (growerDocumentsForCurrentUser.isEmpty()) {
			return null;
        }

        List<Grower> selectableGrowers = growersService.findGrowersByDocuments(growerDocumentsForCurrentUser);
        
        return transform(selectableGrowers, new Function<Grower, GrowerDTO>() {
			public GrowerDTO apply(Grower grower) {
				GrowerDTO growerDTO = new GrowerDTO();
				growerDTO.setName(grower.getName());
				growerDTO.setDocumentNumber(grower.getDocument().getNumber());
				growerDTO.setDocumentType(grower.getDocument().getTypeCode());
				return growerDTO;
			}
		});
    }

}