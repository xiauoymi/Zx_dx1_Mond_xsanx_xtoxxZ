package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.entities.ChallengeQuestion;
import com.industrysystem.web.forms.ChallengeQuestionsForm;
import com.industrysystem.web.forms.NewChallengeQuestionForm;
import com.industrysystem.web.forms.validators.NewChallengeQuestionFormValidator;
import com.industrysystem.web.util.ModelMessagesHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.ldap.userdetails.InetOrgPerson;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Controller
public class ChallengeQuestionController {

	protected static final String CHALLENGEQUESTION_VIEW = "challengequestionform";

	@Autowired
	private ModelMessagesHelper modelMessagesHelper;

	@Autowired
	private UsersService usersService;

	@RequestMapping(value = "/secured/challenge/*.html", method = RequestMethod.GET)
	public String showForm(Model model) {

		populateModel(model, new NewChallengeQuestionForm());

		return CHALLENGEQUESTION_VIEW;
	}

	private void populateModel(Model model,
			NewChallengeQuestionForm newChallengeQuestionForm) {

		String emailAddress = getEmailAddress();

		List<ChallengeQuestion> challengeQuestions = usersService.findChallengeQuestions(emailAddress);

		model.addAttribute("challengeQuestionsForm", new ChallengeQuestionsForm(challengeQuestions));

		model.addAttribute("newChallengeQuestionForm", newChallengeQuestionForm);
	}

	private String getEmailAddress() {
		UsernamePasswordAuthenticationToken authentication = (UsernamePasswordAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
		InetOrgPerson inetOrgPerson = (InetOrgPerson) authentication.getPrincipal();
		return inetOrgPerson.getMail();
	}

	@RequestMapping(value = "/secured/challenge/addChallengeQuestion.html", method = RequestMethod.POST)
	public String addChallengeQuestion(Model model,	@ModelAttribute("newChallengeQuestionForm") @Valid NewChallengeQuestionForm newChallengeQuestionForm, BindingResult result) {

		if (!result.hasErrors()) {
			usersService.addChallengeQuestion(getEmailAddress(), newChallengeQuestionForm.getQuestion(), newChallengeQuestionForm.getAnswer());
			modelMessagesHelper.success("challenge_question.add.success", model);
		}
		populateModel(model, new NewChallengeQuestionForm());
		return CHALLENGEQUESTION_VIEW;
	}
	
	@RequestMapping(value = "/secured/challenge/removeChallengeQuestion.html", method = RequestMethod.POST)
	public String removeChallengeQuestion(Model model, @RequestParam("toRemove") Integer toRemove, @Valid ChallengeQuestionsForm form, BindingResult result) {

		if (!result.hasErrors()) {
			usersService.removeChallengeQuestionByIndex(getEmailAddress(), toRemove);
			modelMessagesHelper.success("challenge_question.remove.success", model);
		}
		populateModel(model, new NewChallengeQuestionForm());
		return CHALLENGEQUESTION_VIEW;
	}

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		binder.setValidator(new NewChallengeQuestionFormValidator());
	}

}
