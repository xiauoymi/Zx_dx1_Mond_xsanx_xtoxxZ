package com.industrysystem.web.controllers;

import com.industrysystem.business.CropService;
import com.industrysystem.entities.Crop;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 12/12/13
 */
@Controller
public class CropController {
    @Autowired
    private CropService cropService;

    @RequestMapping(value="/rest/grains.json", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Crop> populateCrops() {
        return cropService.findAllCrops();
    }
}
