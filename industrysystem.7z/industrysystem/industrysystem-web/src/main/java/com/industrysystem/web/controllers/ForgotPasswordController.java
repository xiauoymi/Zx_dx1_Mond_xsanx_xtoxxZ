package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.exceptions.SendingEmailException;
import com.industrysystem.web.forms.ForgotPasswordForm;
import com.industrysystem.web.forms.validators.ForgotPasswordFormValidator;
import com.industrysystem.web.util.ModelMessagesHelper;
import com.industrysystem.web.util.ServletHelper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@Controller
public class ForgotPasswordController {

	static final String FORGOTPASSWORDFORM_VIEW = "forgotpasswordform";

    static final String RESETPASSWORDMAILSENT_VIEW = "resetpasswordmailsent";

	@Autowired
	private ModelMessagesHelper modelMessagesHelper;

	@Autowired
	private UsersService usersService;
	
	@Autowired
	private ForgotPasswordFormValidator forgotPasswordFormValidator;
	
	@Autowired
	private ServletHelper servletHelper;
	
	@RequestMapping(value="/recoverpasswordinvalidtoken.html", method = RequestMethod.GET)
	public String invalidToken(Model model) {
		
		model.addAttribute("forgotPasswordForm", new ForgotPasswordForm());
		modelMessagesHelper.error("recoverpassword.invalid.token", model);
		return FORGOTPASSWORDFORM_VIEW;
	}
	
	@RequestMapping(value="/recoverpasswordmailerror.html", method = RequestMethod.GET)
	public String findingEmailError(Model model) {
		model.addAttribute("forgotPasswordForm", new ForgotPasswordForm());
		modelMessagesHelper.error("recoverpassword.mail.input.error", model);
		return FORGOTPASSWORDFORM_VIEW;
	}
	
	@RequestMapping(value="/forgotpassword.html", method = RequestMethod.GET)
	public String forgotPassword(Model model) {
		model.addAttribute("forgotPasswordForm", new ForgotPasswordForm());
		return FORGOTPASSWORDFORM_VIEW;
	}
	
	@RequestMapping(value="/forgotpassword.html", method = RequestMethod.POST)
	public String sendMail(Model model, @ModelAttribute("forgotPasswordForm") @Valid ForgotPasswordForm forgotPasswordForm, BindingResult result, HttpServletRequest request) {
		if(result.hasErrors()) {
			model.addAttribute("forgotPasswordForm", forgotPasswordForm);
			return FORGOTPASSWORDFORM_VIEW;
        }

		
		String emailAddress = forgotPasswordForm.getEmailAddress();
		
		
		if (noChallengeQuestionsToMake(emailAddress))
		{
			return PasswordRecoveryController.NO_CHALLENGES_TO_ANSWER;
		}
		
		String generatedToken = usersService.generatePasswordResetToken(emailAddress);
		StringBuffer url = servletHelper.getRequestURL(request);
		String tokenUrl = url + "/spring/recoverpasswordform.html?token=" + generatedToken;
		String baseImagesUrl = url + "/resources/img/mail";
		try {
			usersService.sendMailForPasswordRecovery(emailAddress, tokenUrl, baseImagesUrl);
		} catch (SendingEmailException e) {
			modelMessagesHelper.error("forgot_password.send.mail.error", model);
			return FORGOTPASSWORDFORM_VIEW;
		}
		model.addAttribute("email", emailAddress);
		return RESETPASSWORDMAILSENT_VIEW;
	}
	

	private boolean noChallengeQuestionsToMake(String emailAddress) {
		
		return usersService.findDoableChallengeQuestions(emailAddress).isEmpty();
	}

	@InitBinder
	protected void initBinder(WebDataBinder binder)
	{
		binder.setValidator(forgotPasswordFormValidator);
	}
	

	
}
