package com.industrysystem.web.controllers;

import com.industrysystem.entities.BroadcastMessage;
import com.industrysystem.persistence.daos.GreetingDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;

/**
 * Sample controller for going to the securedHome page with a message
 */
@Controller
public class GreetingController {

	@Autowired
	private GreetingDao dao;
	
	private static final Logger logger = LoggerFactory
			.getLogger(GreetingController.class);

	/**
	 * Selects the securedHome page and populates the model with a message
     * @param model
     * @return
     */
	@RequestMapping(value = "/secured/greeting.html", method = RequestMethod.GET)
	public String home(Model model) {
		
		List<BroadcastMessage> allGreetings = dao.getAll();
        model.addAttribute("controllerMessage",
				allGreetings.get(allGreetings.size()-1).getMessage());
		
		return "greeting";
	}

}
