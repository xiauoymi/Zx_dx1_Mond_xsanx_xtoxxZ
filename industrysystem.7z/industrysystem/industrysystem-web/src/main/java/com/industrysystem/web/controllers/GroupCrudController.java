package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.web.forms.UserGroupsForm;
import com.industrysystem.web.forms.validators.UserGroupsFormValidator;
import com.industrysystem.web.util.ModelMessagesHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;

/**
 * User: PPERA
 * Date: 30/07/13
 * Time: 16:08
 */
@Controller
@RequestMapping(value = "/secured/security/groups")
public class GroupCrudController {

    @Autowired
    private UsersService usersService;

    @Autowired
    private ModelMessagesHelper messagesHelper;

    @Autowired
    private UserGroupsFormValidator userGroupsFormValidator;

    @InitBinder
    public void initBinderAll(WebDataBinder binder) {
        binder.setValidator(userGroupsFormValidator);
    }

    @RequestMapping(value = "/userGroups.html", method = RequestMethod.GET)
    public String newGroupAssignationForm(Model model) {
        UserGroupsForm userGroupsForm = new UserGroupsForm();
        fillModelWithAssignedGroupsAndForm(model, userGroupsForm);
        return "newGroupAssignationForm";
    }

    @RequestMapping(value = "/userGroups.html", method = RequestMethod.POST)
    public String newGroupAssignationForm(@Valid UserGroupsForm form, BindingResult result, Model model) {
        if (result.hasErrors()) {
            fillModelWithAssignedGroupsAndForm(model, form);
            return "newGroupAssignationForm";
        }

        try {
            usersService.assignGroups(form.getDocument(), form.getAssignedGroups());
            messagesHelper.info("security.assign.group.success", model);
        } catch (Exception e) {
            messagesHelper.error("security.assign.group.error", model);
        }

        fillModelWithAssignedGroupsAndForm(model, form);
        return "newGroupAssignationForm";
    }


    private void fillModelWithAssignedGroupsAndForm(Model model, UserGroupsForm userGroupsForm) {
        List<String> allGroups = usersService.findAllRoleNames();
        userGroupsForm.setAssignedGroups(new ArrayList<String>());
        model.addAttribute("userGroupsForm", userGroupsForm);
        model.addAttribute("groups", allGroups);
    }

}