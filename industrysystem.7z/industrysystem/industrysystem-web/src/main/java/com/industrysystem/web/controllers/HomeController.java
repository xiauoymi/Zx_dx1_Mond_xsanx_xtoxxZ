package com.industrysystem.web.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Sample controller for going to the securedHome page with a message
 */
@Controller
public class HomeController {

    /**
     * Selects the securedHome page and populates the model with a message
     *
     * @return
     */
    @RequestMapping(value = "/home.html", method = RequestMethod.GET)
    public String home() {
        return "home";
    }

    @RequestMapping(value = "/secured/home.html", method = RequestMethod.GET)
    public String securedHome() {
        return "securedHome";
    }

    @RequestMapping(value = "/terms-and-conditions.html", method = RequestMethod.GET)
    public String termsAndConditions() {
        return "termsAndConditions";
    }

    @RequestMapping(value = "/privacy-policy.html", method = RequestMethod.GET)
    public String privacyPolicy() {
        return "privacyPolicy";
    }

    @RequestMapping(value = "/about-us.html", method = RequestMethod.GET)
    public String aboutUs() {
        return "aboutUs";
    }

}
