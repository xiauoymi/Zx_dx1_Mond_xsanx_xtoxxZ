package com.industrysystem.web.controllers;

import com.industrysystem.business.LaboratoryService;
import com.industrysystem.entities.Laboratory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 17/12/13
 */
@Controller
public class LaboratoryController {

    @Autowired
    private LaboratoryService laboratoryService;

    @RequestMapping(value="/rest/laboratories.json", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Laboratory> populateLaboratories(){
        return laboratoryService.findLaboratories();

    }

}
