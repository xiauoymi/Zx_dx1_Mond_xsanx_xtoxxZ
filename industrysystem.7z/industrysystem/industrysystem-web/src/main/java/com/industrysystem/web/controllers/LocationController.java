package com.industrysystem.web.controllers;

import com.industrysystem.business.LocationService;
import com.industrysystem.business.ProvinceService;
import com.industrysystem.entities.Location;
import com.industrysystem.entities.Province;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 12/12/13
 */
@Controller
public class LocationController {
    @Autowired
    private ProvinceService provinceService;
    @Autowired
    private LocationService locationService;

    @RequestMapping(value="/rest/provinces.json", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<Province> findProvinces() {
        return provinceService.findProvinces();
    }

    @RequestMapping(value="/rest/provinces/{province}/cities.json", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    List<Location> findProvincesLocation (@PathVariable(value = "province") Long province) {
        return locationService.findLocationsFrom(province);
    }
}
