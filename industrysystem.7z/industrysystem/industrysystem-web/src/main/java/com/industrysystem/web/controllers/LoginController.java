package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.web.util.ModelMessagesHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.ldap.userdetails.Person;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class LoginController {

    protected static final String RETAILER_LOGIN_VIEW = "loginretailer";
    private static final String GROWER_LOGIN_VIEW = "logingrower";
    private static final String HOME = "home";

    @Autowired
    private ModelMessagesHelper messagesHelper;

    @Autowired
    private UsersService usersService;


    @RequestMapping(value = "/logingrower.html", method = RequestMethod.GET)
    public String showForm(ModelMap model, HttpServletRequest request) {
        if (isReallyAuthenticated()) {
            return HOME;
        }

        this.showCaptcha(model, request);

        return GROWER_LOGIN_VIEW;
    }

    private void showCaptcha(ModelMap model, HttpServletRequest request) {
        String remoteAddress = request.getRemoteAddr();
        boolean showCaptcha = isFailedAttemptsCountEqualOrGreaterThanThreshold(remoteAddress);
        model.addAttribute("showCaptcha", showCaptcha);
    }

    private boolean isFailedAttemptsCountEqualOrGreaterThanThreshold(String remoteAddress) {
        return !(this.usersService.findFailedAttemptsCount(remoteAddress) < UsersService.MAX_FAILED_LOGIN_ATTEMPTS_BEFORE_CHECKING_CAPTCHA);
    }

    private boolean isReallyAuthenticated() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        boolean authenticated = authentication.isAuthenticated();
        authenticated = authenticated && authentication.getPrincipal() != null;
        authenticated = authenticated && authentication.getPrincipal() instanceof Person;
        return authenticated;
    }

    @RequestMapping(value = "/loginretailer.html", method = RequestMethod.GET)
    public String showRetailerLogin() {
        return RETAILER_LOGIN_VIEW;
    }

    @RequestMapping(value = "/autherror.html", method = RequestMethod.GET)
    public String showError(ModelMap model, HttpServletRequest request) {
        model.addAttribute("authenticationError", true);
        this.showCaptcha(model, request);
        return GROWER_LOGIN_VIEW;
    }

    @RequestMapping(value = "/changepasswordsuccess.html", method = RequestMethod.GET)
    public String changePasswordSuccess(Model model, HttpSession session) {

        if (session != null) {
            session.invalidate();
        }

        SecurityContextHolder.clearContext();

        messagesHelper.success("login.change_password.success", model);
        return HOME;
    }

    @RequestMapping(value = "/csrferror.html", method = RequestMethod.GET)
    public String csrfError(ModelMap model) {
        model.addAttribute("csrfError", true);
        return GROWER_LOGIN_VIEW;
    }

    @RequestMapping(value = "/sessionended.html", method = RequestMethod.GET)
    public String sessionExpired(ModelMap model) {
        model.addAttribute("sessionEnded", true);
        return HOME;
    }

}
