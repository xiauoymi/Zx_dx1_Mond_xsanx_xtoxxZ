package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.web.forms.ChangePasswordForm;
import com.industrysystem.web.forms.validators.ChangePasswordFormValidator;
import com.industrysystem.web.util.ModelMessagesHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.naming.NamingException;
import javax.validation.Valid;
import java.security.Principal;

@Controller
@RequestMapping(value = "/secured/password")
public class PasswordHandlingController {

	@Autowired
	private UsersService usersService;

    @Autowired
    private ModelMessagesHelper modelMessagesHelper;
	
	@Autowired
	private ChangePasswordFormValidator changePasswordFormValidator;
	
	@InitBinder
	protected void initBinder(WebDataBinder binder)
	{
		binder.setValidator(changePasswordFormValidator);
	}
	
    @RequestMapping(value = "/change.html", method = RequestMethod.GET)
    public String changePassword(ModelMap model, Principal principal) {
    	ChangePasswordForm form = new ChangePasswordForm();
    	form.setUserName(principal.getName());
		model.put("changePasswordForm", form);
    	return "changePassword";
    }
    
    @RequestMapping(value = "/change.html", method = RequestMethod.POST)
    public String changePassword(@ModelAttribute("changePasswordForm") @Valid ChangePasswordForm changePasswordForm, BindingResult result, Model model) {
    	
    	if (result.hasErrors())
    	{
    		return "changePassword";
    	}

        try {
            usersService.changePassword(SecurityContextHolder.getContext().getAuthentication().getName(), changePasswordForm.getOldPassword(), changePasswordForm.getNewPassword());
        } catch (AuthenticationException e) {
            this.modelMessagesHelper.error("changePassword.error.authentication", model);
        } catch (NamingException e) {
        	this.modelMessagesHelper.error("changePassword.error", model);
		}

        return "redirect:/spring/changepasswordsuccess.html";
    }
    

}



