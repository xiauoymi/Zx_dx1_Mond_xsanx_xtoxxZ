package com.industrysystem.web.controllers;

import java.util.Iterator;
import java.util.List;

import javax.naming.NamingException;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.ldap.userdetails.InetOrgPerson;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.entities.ChallengeQuestion;
import com.industrysystem.exceptions.DirectorySearchResultsException;
import com.industrysystem.exceptions.InvalidTokenException;
import com.industrysystem.web.forms.RecoverPasswordForm;
import com.industrysystem.web.forms.validators.RecoverPasswordFormValidator;
import com.industrysystem.web.util.ModelMessagesHelper;

@Controller
public class PasswordRecoveryController {

	public static final String NO_CHALLENGES_TO_ANSWER = "nochallengestoanswer";

	private static final String CHALLENGE_QUESTIONS_LIST = "CHALLENGE_QUESTIONS_LIST";

	static final String RECOVERPASSWORDFORM_VIEW = "recoverpasswordform";

	private static final String NEEDS_CHALLENGE_QUESTION = "NEEDS_CHALLENGE_QUESTION";


	@Autowired
	private ModelMessagesHelper modelMessagesHelper;
	
	@Autowired
	private UsersService usersService;
	
	@Autowired
	private RecoverPasswordFormValidator recoverPasswordFormValidator;

	@RequestMapping(value="/recoverpasswordform.html", method = RequestMethod.GET)
	public String recoverPassword(Model model, @RequestParam("token") String token, HttpSession session) {
		
		InetOrgPerson user;
		try {
			user = usersService.obtainPersonForPasswordResetToken(token);
		} catch (InvalidTokenException e) {
			return "redirect:/spring/recoverpasswordinvalidtoken.html";
		} catch (DirectorySearchResultsException e) {
			return "redirect:/spring/recoverpasswordmailerror.html";
		}
		
		setChallengeQuestionsInSession(session, user);
		
		completeFormFormAndSetIntoModel(model, user, new RecoverPasswordForm(), session);
		
		return RECOVERPASSWORDFORM_VIEW;
	}

	private void setChallengeQuestionsInSession(HttpSession session, InetOrgPerson user) {
		List<ChallengeQuestion> challengeQuestions = usersService.findDoableChallengeQuestions(user.getMail());
		session.setAttribute(CHALLENGE_QUESTIONS_LIST, challengeQuestions);
		session.setAttribute(NEEDS_CHALLENGE_QUESTION, Boolean.TRUE);
	}
	
	@RequestMapping(value="/recoverpasswordform.html", method = RequestMethod.POST)
	public String doChangePassword(Model model, @ModelAttribute("recoverPasswordForm") @Valid RecoverPasswordForm recoverPasswordForm, BindingResult result, HttpSession session) {
		
		String token = recoverPasswordForm.getToken();
		InetOrgPerson user;
		try {
			user = usersService.obtainPersonForPasswordResetToken(token);
		} catch (InvalidTokenException e) {
			return "redirect:/spring/recoverpasswordinvalidtoken.html";
		} catch (DirectorySearchResultsException e) {
			return "redirect:/spring/recoverpasswordmailerror.html";
		}
		
		handleChallengeAnswer(model, recoverPasswordForm.getChallengeAnswer(), session, user);
		
		if (needsChallengeQuestions(session) && getChallengeQuestionsToMake(session).isEmpty())
		{
			return NO_CHALLENGES_TO_ANSWER;
		}
		
		
		if(result.hasErrors() || needsChallengeQuestions(session)) {
			completeFormFormAndSetIntoModel(model, user, recoverPasswordForm, session);
			return RECOVERPASSWORDFORM_VIEW;
        }
		
		
		try {
			usersService.resetPassword(user.getUid(), recoverPasswordForm.getNewPassword());
		} catch (NamingException e) {
			modelMessagesHelper.error("resetpassword.error.unknown", model);
			completeFormFormAndSetIntoModel(model, user, recoverPasswordForm, session);
			return RECOVERPASSWORDFORM_VIEW;
		}
		return "redirect:/spring/changepasswordsuccess.html";
	}

	private boolean needsChallengeQuestions(HttpSession session) {
		return (Boolean) session.getAttribute(NEEDS_CHALLENGE_QUESTION);
	}

	@SuppressWarnings("unchecked")
	private List<ChallengeQuestion> getChallengeQuestionsToMake(HttpSession session) {
		return (List<ChallengeQuestion>) session.getAttribute(CHALLENGE_QUESTIONS_LIST);
	}

	private void handleChallengeAnswer(Model model, String answer, HttpSession session, InetOrgPerson user) 
	{
		if (needsChallengeQuestions(session))
		{
			List<ChallengeQuestion> challengeQuestions = getChallengeQuestionsToMake(session);
			Iterator<ChallengeQuestion> iterator = challengeQuestions.iterator();
			boolean challengeAnswerPassed = usersService.challengeQuestionRespondedOk(iterator.next().getAnswer(), answer);
			{
				if (challengeAnswerPassed)
				{
					usersService.resetRemainingChallengeQuestionsAttempts(user.getMail());
					session.setAttribute(NEEDS_CHALLENGE_QUESTION, Boolean.FALSE);
				}
				else
				{
					usersService.consumeRemainingChallengeQuestionsAttempt(user.getMail());
					modelMessagesHelper.error("reset_password.error.wrong_challenge_answer", model);
					iterator.remove();
				}
			}
		}
		
	}
	

	private void completeFormFormAndSetIntoModel(Model model, InetOrgPerson user, RecoverPasswordForm recoverPasswordForm, HttpSession session) {
		recoverPasswordForm.setSurename(user.getSn());
		recoverPasswordForm.setUserName(user.getUid());
		recoverPasswordForm.setEmailAddress(user.getMail());
		String newToken = usersService.generatePasswordResetToken(user.getMail());
		recoverPasswordForm.setToken(newToken);
		completeChallengeQuestionIfNeeded(recoverPasswordForm, session);
		model.addAttribute("recoverPasswordForm", recoverPasswordForm);
		
	}

	private void completeChallengeQuestionIfNeeded(RecoverPasswordForm recoverPasswordForm, HttpSession session) {
		if (needsChallengeQuestions(session))
		{
			List<ChallengeQuestion> challengeQuestions = getChallengeQuestionsToMake(session);
			recoverPasswordForm.setChallengeQuestion(challengeQuestions.get(0).getQuestion());
		}
	}

	@InitBinder
	protected void initBinder(WebDataBinder binder)
	{
		binder.setValidator(recoverPasswordFormValidator);
	}
	
}
