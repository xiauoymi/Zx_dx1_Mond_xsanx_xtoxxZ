package com.industrysystem.web.controllers;

import com.industrysystem.business.TestListingService;
import com.industrysystem.persistence.daos.report.ReportRequest;
import com.industrysystem.persistence.daos.report.ReportResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * User: CGLLLO
 * Date: 18/02/14
 */
@Controller
public class TechnologyListingController {

    static final int MAX_RESULTS = 10;

    @Autowired
    private TestListingService testListingService;

    @RequestMapping(value="/rest/technology/testResultListing.json", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public ReportResponse getReport(@RequestBody ReportRequest reportRequest) {
        return testListingService.createReportResponse(reportRequest, MAX_RESULTS);
    }
}
