package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.security.groups.FunctionalSecurityGroup;
import com.industrysystem.security.groups.SecurityGroup;
import com.industrysystem.web.forms.UserForm;
import com.industrysystem.web.forms.validators.UserFormValidator;
import com.industrysystem.web.util.ModelMessagesHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.validation.Valid;
import java.util.List;
import java.util.Map;

import static com.google.common.collect.Maps.newHashMap;

/**
 * User: PPERA
 * Date: 30/07/13
 * Time: 16:07
 */
@Controller
@RequestMapping(value = "/secured/security/users")
public class UserCrudController {

    public final String ERROR_CREATING_USER = "security.new_user.error";
    private final String USER_CREATED = "security.new_user.success";

    @Autowired
    private UserFormValidator userFormValidator;

    @Autowired
    private UsersService usersService;

    @Autowired
    private ModelMessagesHelper messagesHelper;

    @InitBinder
    public void initBinderAll(WebDataBinder binder) {
        binder.setValidator(userFormValidator);
    }

    @RequestMapping(value = "/userForm.html", method = RequestMethod.GET)
    public String newUserForm(Model model) {
        UserForm userForm = new UserForm();
        model.addAttribute("userForm", userForm);

        initGroups(model);
        initRolesByGroupsMap(userForm);

        return "newUserForm";
    }

    @RequestMapping(value = "/userForm.html", method = RequestMethod.POST)
    public String newUserForm(@Valid UserForm userForm, BindingResult result, Model model) {
        if (result.hasErrors()) {
            initGroups(model);
            initRolesByGroupsMap(userForm);
            return "newUserForm";
        }

        try {
            usersService.createUser(userForm.getUserName(), userForm.getNewPassword(), userForm.getAssignedGroups(),
                    userForm.getSn(), userForm.getMail());
            messagesHelper.success(USER_CREATED, model);
        } catch (Exception e) {
            messagesHelper.error(ERROR_CREATING_USER, model);
        }

        UserForm cleanUserForm = new UserForm();
        model.addAttribute("userForm", cleanUserForm);

        initGroups(model);

        initRolesByGroupsMap(cleanUserForm);

        return "newUserForm";
    }

    private void initRolesByGroupsMap(UserForm userForm) {
        Map<String, Map<String, Boolean>> rolesByGroupMap = makeRolesByGroupMap();
        userForm.setRolesByGroupMap(rolesByGroupMap);
    }

    private void initGroups(Model model) {
        List<String> groups = usersService.findAllRoleNames();
        model.addAttribute("groups", groups);
    }

    private Map<String, Map<String, Boolean>> makeRolesByGroupMap() {
        List<SecurityGroup> securityGroups = usersService.findAllGroups();
        Map<String, Map<String, Boolean>> rolesByGroupMap = newHashMap();
        for (SecurityGroup securityGroup: securityGroups) {
            if (!securityGroup.isAdmin()) {
                FunctionalSecurityGroup functionalSecurityGroup = (FunctionalSecurityGroup) securityGroup;
                Map<String, Boolean> roleMap = rolesByGroupMap.get(functionalSecurityGroup.getGroupName());

                if (roleMap == null) {
                    roleMap = newHashMap();
                    rolesByGroupMap.put(functionalSecurityGroup.getGroupName(), roleMap);
                }

                roleMap.put(functionalSecurityGroup.getRoleName(), Boolean.FALSE);
            }
        }

        return rolesByGroupMap;
    }

}