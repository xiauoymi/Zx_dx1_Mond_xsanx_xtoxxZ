package com.industrysystem.web.controllers;

import com.industrysystem.business.WaybillService;
import com.industrysystem.entities.Waybill;
import com.industrysystem.web.dtos.LoadDetailDTO;
import com.industrysystem.web.dtos.TestDataDTO;
import com.industrysystem.web.dtos.WaybillDetailDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

/**
 * User: JPNORV
 * Date: 04/10/13
 */
@Controller
@RequestMapping(value = "/secured/waybill")
public class WaybillDetailController {

    @Autowired
    private WaybillService waybillService;


    @RequestMapping(value = "/viewWaybillDetail.html", method = RequestMethod.GET)
    public String viewWaybillDetail(@RequestParam(value = "id", required = true) Long id, Model model) {
        WaybillDetailDTO waybillDetailDTO = populateWaybillDetailDTO(id);
        model.addAttribute("selectedWaybill", waybillDetailDTO);
        List<LoadDetailDTO> loadDetailDTOList = waybillDetailDTO.getLoadDetailDTOList();
        model.addAttribute("selectedLoadDetail", loadDetailDTOList);
        List<TestDataDTO> testDataDTOs = new ArrayList<TestDataDTO>();
        for(LoadDetailDTO loadDetailDTO : loadDetailDTOList){
            testDataDTOs.addAll(loadDetailDTO.getTestDataDTOList());
        }
        model.addAttribute("selectedTestData", testDataDTOs);
        return "viewWaybillDetail";
    }


    private WaybillDetailDTO populateWaybillDetailDTO(Long id) {
        Waybill waybill = waybillService.findEagerWaybillDetailByWaybillId(id);
        return new WaybillDetailDTO(waybill);
    }


}
