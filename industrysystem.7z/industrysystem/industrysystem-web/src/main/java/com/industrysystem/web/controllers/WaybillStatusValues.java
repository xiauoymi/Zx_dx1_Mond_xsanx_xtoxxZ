package com.industrysystem.web.controllers;

import com.industrysystem.entities.WaybillStatusEnum;
import com.industrysystem.web.dtos.WaybillStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.Collection;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 21/02/14
 * Time: 15:58
 */
@Controller
public class WaybillStatusValues {

    @RequestMapping(value="/rest/waybillStatusValues.json", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Collection<WaybillStatus> getWaybillStatusValues() {
        Collection<WaybillStatus> waybillStatuses = new ArrayList<WaybillStatus>();
        for (WaybillStatusEnum waybillStatusEnum : WaybillStatusEnum.values()) {
            waybillStatuses.add(new WaybillStatus(waybillStatusEnum));
        }
        return waybillStatuses;
    }
}
