package com.industrysystem.web.controllers.pod.waybill;

import com.industrysystem.business.WaybillService;
import com.industrysystem.business.users.UsersService;
import com.industrysystem.entities.Waybill;
import com.industrysystem.exceptions.BusinessException;
import com.industrysystem.exceptions.PodNotFoundException;
import com.industrysystem.web.dtos.pod.waybill.WaybillPendingDTO;
import org.dozer.DozerBeanMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.emptyList;

/**
 * User: LSCHW1
 */
@Controller
@RequestMapping(value = "/rest/pods/waybills")
public class WaybillPendingController {

    @Autowired
    private UsersService usersService;

    @Autowired
    private WaybillService waybillService;

    @Autowired
    private DozerBeanMapper dozerMapper;

    @RequestMapping(value = "/pending.json", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<WaybillPendingDTO> getPendingWaybills() throws PodNotFoundException {
        List<WaybillPendingDTO> pendings = new ArrayList<WaybillPendingDTO>();
        for (Waybill waybill: usersService.findPendingWaybillsFromCurrentUser()) {
            WaybillPendingDTO waybillPending = dozerMapper.map(waybill, WaybillPendingDTO.class);
            waybillPending.setHolderName(waybillService.getHolderName(waybill));
            pendings.add(waybillPending);
        }

        return pendings;
    }

    @RequestMapping(value = "", method = RequestMethod.PUT, consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ResponseBody
    public void storeWeightAndSampleInfo(@RequestBody WaybillPendingDTO waybillPendingDTO) throws BusinessException {
        Long waybillNumber = waybillPendingDTO.getWaybillNumber() != null? Long.parseLong(waybillPendingDTO.getWaybillNumber()): null;
        waybillService.storeWeightAndSampleInfo(waybillNumber, waybillPendingDTO.getQuantitativeLabCode(),
                waybillPendingDTO.getQuantitativeLabCode(), waybillPendingDTO.getLoadDetail());
    }

    @RequestMapping(value = "/waybills.json", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public List<WaybillPendingDTO> getCompleteWaybills() {
        return emptyList();
    }

}