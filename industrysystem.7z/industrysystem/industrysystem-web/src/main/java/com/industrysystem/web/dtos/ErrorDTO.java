package com.industrysystem.web.dtos;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 02/01/14
 */
public class ErrorDTO {

    private String code;
    private String fieldValue;
    private String fieldName;
    private String message;
    private String waybillNumber;
    private String wagonNumber;

    public ErrorDTO(String code, String fieldName, String fieldValue ,String message){
        this.code = code;
        this.fieldName = fieldName;
        this.fieldValue= fieldValue;
        this.message = message;
    }

    public String getWaybillNumber() {
        return waybillNumber;
    }

    public void setWaybillNumber(String waybillNumber) {
        this.waybillNumber = waybillNumber;
    }

    public String getWagonNumber() {
        return wagonNumber;
    }

    public void setWagonNumber(String wagonNumber) {
        this.wagonNumber = wagonNumber;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getFieldValue() {
        return fieldValue;
    }

    public void setFieldValue(String fieldValue) {
        this.fieldValue = fieldValue;
    }

    public String getFieldName() {
        return fieldName;
    }

    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
