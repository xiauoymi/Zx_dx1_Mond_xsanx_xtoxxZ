package com.industrysystem.web.dtos;

/**
 * User: ASEQU
 * Date: 1/7/14
 * Time: 6:18 PM
 */
public class GrowerDTO {
    private String documentNumber;
    private String documentType;
    private String name;

    public String getDocumentNumber() {
        return documentNumber;
    }

    public void setDocumentNumber(String documentNumber) {
        this.documentNumber = documentNumber;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
