package com.industrysystem.web.dtos;

import com.industrysystem.exceptions.FieldBusinessError;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 20/12/13
 */
public class IsDeclaredPODDTO {

    private Boolean success;
    private Boolean declaredPOD;
    private FieldBusinessError error;

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public Boolean getDeclaredPOD() {
        return declaredPOD;
    }

    public void setDeclaredPOD(Boolean declaredPOD) {
        this.declaredPOD = declaredPOD;
    }

    public FieldBusinessError getError() {
        return error;
    }

    public void setError(FieldBusinessError error) {
        this.error = error;
    }

}