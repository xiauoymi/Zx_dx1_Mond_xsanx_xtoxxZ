package com.industrysystem.web.dtos;

import com.google.common.base.Function;
import com.industrysystem.entities.*;

import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Lists.transform;

/**
 * User: JPNORV
 * Date: 09/10/13
 *
 */
public class LoadDetailDTO {

    public static final String SI = "SI";
    public static final String NO = "NO";

    private String sampleCode;
    private String laboratory;
    private String sampleRequired;
    private String weight;
    private String identifier;
    private List<TestDataDTO> testDataDTOList;

    public LoadDetailDTO(LoadDetail loadDetail, TransportType transportType) {
        if (loadDetail.getLaboratory() != null) {
            laboratory = loadDetail.getLaboratory().getCode();
        }

        sampleCode = loadDetail.getSampleCode();

        if (loadDetail.getSampleRequired() != null && loadDetail.getSampleRequired()) {
            sampleRequired = SI;
        }else {
            sampleRequired = NO;
        }

        if (loadDetail.getWeight() != null) {
            weight = loadDetail.getWeight().toString();
        }

        identifier = loadDetail.getIdentifier();

        testDataDTOList = new ArrayList<TestDataDTO>();
        testDataDTOList.addAll(transform(newArrayList(loadDetail.getTestRequests()), new Function<TestRequest, TestDataDTO>() {
            public TestDataDTO apply(TestRequest testRequest) {
                return new TestDataDTO(testRequest);
            }
        }));
    }

    public String getSampleCode() {
        return sampleCode;
    }

    public void setSampleCode(String sampleCode) {
        this.sampleCode = sampleCode;
    }

    public String getLaboratory() {
        return laboratory;
    }

    public String getSampleRequired() {
        return sampleRequired;
    }

    public void setSampleRequired(String sampleRequired) {
        this.sampleRequired = sampleRequired;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public void setLaboratory(String laboratory) {
        this.laboratory = laboratory;
    }

    public String getIdentifier() {
        return identifier;
    }

    public void setIdentifier(String identifier) {
        this.identifier = identifier;
    }

    public List<TestDataDTO> getTestDataDTOList() {
        return testDataDTOList;
    }

    public void setTestDataDTOList(List<TestDataDTO> testDataDTOList) {
        this.testDataDTOList = testDataDTOList;
    }

}