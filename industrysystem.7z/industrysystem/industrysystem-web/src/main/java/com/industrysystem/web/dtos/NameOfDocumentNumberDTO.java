package com.industrysystem.web.dtos;

import com.industrysystem.exceptions.FieldBusinessError;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 22/11/13
 */
public class NameOfDocumentNumberDTO {
    private Boolean success;
    private String name;
    private FieldBusinessError error;

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public FieldBusinessError getError() {
        return error;
    }

    public void setError(FieldBusinessError error) {
        this.error = error;
    }
}
