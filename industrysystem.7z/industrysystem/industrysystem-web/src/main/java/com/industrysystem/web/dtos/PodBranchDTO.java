package com.industrysystem.web.dtos;

import com.industrysystem.entities.Document;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 30/12/13
 * Time: 18:59
 */
public class PodBranchDTO {

    private Long commercialCode;
    private Document document;
    private String name;

    public Long getCommercialCode() {
        return commercialCode;
    }

    public void setCommercialCode(Long commercialCode) {
        this.commercialCode = commercialCode;
    }

    public Document getDocument() {
        return document;
    }

    public void setDocument(Document document) {
        this.document = document;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}