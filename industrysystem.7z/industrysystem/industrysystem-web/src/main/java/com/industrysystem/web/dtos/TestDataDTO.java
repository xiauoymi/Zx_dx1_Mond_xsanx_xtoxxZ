package com.industrysystem.web.dtos;

import com.industrysystem.entities.CuantitativeTestRequest;
import com.industrysystem.entities.CuantitativeTestResult;
import com.industrysystem.entities.QualitativeTestRequest;
import com.industrysystem.entities.TestRequest;

import java.util.Date;

/**
 * User: JPNORV
 * Date: 09/10/13
 */
public class TestDataDTO {

    /**
     * QualitativeTestRequest values
     */
    private String technology;
    private Date dateCompleted;
    private Boolean qualitativeTestResult;
    /**
     * CuantitativeTestRequest values
     */
    private StringBuffer cuantitativeTestResults = new StringBuffer();

    public TestDataDTO(TestRequest testRequest) {
        if (testRequest instanceof QualitativeTestRequest) {
            QualitativeTestRequest qualitativeTestRequest = (QualitativeTestRequest)testRequest;
            technology = qualitativeTestRequest.getCropTechnologyForCampaign().getCropTechnology().getTechnology().getCode();
            dateCompleted = qualitativeTestRequest.getDateCompleted();
            qualitativeTestResult = qualitativeTestRequest.getQualitativeTestResult().getResult();
        } else {
            CuantitativeTestRequest cuantitativeTestRequest = (CuantitativeTestRequest)testRequest;
            dateCompleted = cuantitativeTestRequest.getDateCompleted();
            for (CuantitativeTestResult cuantitativeTestResult: cuantitativeTestRequest.getCuantitativeTestResults()) {
                cuantitativeTestResults.append(cuantitativeTestResult.getCropTechnology().getTechnology().getCode())
                        .append(": ").append(cuantitativeTestResult.getRatio().toString()).append("% ");
            }
        }
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    public Date getDateCompleted() {
        return dateCompleted;
    }

    public void setDateCompleted(Date dateCompleted) {
        this.dateCompleted = dateCompleted;
    }

    public Boolean getQualitativeTestResult() {
        return qualitativeTestResult;
    }

    public void setQualitativeTestResult(Boolean qualitativeTestResult) {
        this.qualitativeTestResult = qualitativeTestResult;
    }

    public StringBuffer getCuantitativeTestResults() {
        return cuantitativeTestResults;
    }

    public void setCuantitativeTestResults(StringBuffer cuantitativeTestResults) {
        this.cuantitativeTestResults = cuantitativeTestResults;
    }

}