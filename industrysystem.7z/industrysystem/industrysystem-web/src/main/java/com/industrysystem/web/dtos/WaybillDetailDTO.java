package com.industrysystem.web.dtos;

import com.google.common.base.Function;
import com.industrysystem.entities.LoadDetail;
import com.industrysystem.entities.Waybill;

import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Lists.transform;

/**
 *
 * User: JPNORV
 * Date: 08/10/13
 */
public class WaybillDetailDTO {

    public String waybillNumber;
    public String waybillType;
    public String holderDocumentNumber;
    public String addresseeDocumentNumber;
    public String destinationDocumentNumber;
    public String campaign;
    public String crop;
    public String transportType;

    public List<LoadDetailDTO> loadDetailDTOList;

    public String technology;
    public String testResult;

    public WaybillDetailDTO(final Waybill waybill){
        this.waybillNumber = waybill.getWaybillNumber().toString();
        this.waybillType = waybill.getTransportType().toString();
        this.holderDocumentNumber = waybill.getHolderDocument().getNumber();
        this.addresseeDocumentNumber = waybill.getAddressee().getDocument().getNumber();
        this.destinationDocumentNumber = waybill.getDestination().getDocument().getNumber();
        this.campaign = waybill.getCampaign().getCode();
        this.crop = waybill.getCrop().getCode();
        this.loadDetailDTOList = new ArrayList<LoadDetailDTO>();
        this.transportType = waybill.getTransportType().toString();

        if(waybill.getLoadDetails().size()>0){
            List<LoadDetail> loadDetailsList = newArrayList(waybill.getLoadDetails());
            List<LoadDetailDTO> loadDetailDTOList = transform(loadDetailsList, new Function<LoadDetail, LoadDetailDTO>() {
                public LoadDetailDTO apply(LoadDetail loadDetail) {
                    return new LoadDetailDTO(loadDetail, waybill.getTransportType());
                }
            });
            this.loadDetailDTOList.addAll(loadDetailDTOList);
        }

    }

    public String getWaybillNumber() {
        return waybillNumber;
    }

    public void setWaybillNumber(String waybillNumber) {
        this.waybillNumber = waybillNumber;
    }

    public String getWaybillType() {
        return waybillType;
    }

    public void setWaybillType(String waybillType) {
        this.waybillType = waybillType;
    }


    public String getHolderDocumentNumber() {
        return holderDocumentNumber;
    }

    public void setHolderDocumentNumber(String holderDocumentNumber) {
        this.holderDocumentNumber = holderDocumentNumber;
    }


    public String getAddresseeDocumentNumber() {
        return addresseeDocumentNumber;
    }

    public void setAddresseeDocumentNumber(String addresseeDocumentNumber) {
        this.addresseeDocumentNumber = addresseeDocumentNumber;
    }


    public String getDestinationDocumentNumber() {
        return destinationDocumentNumber;
    }

    public void setDestinationDocumentNumber(String destinationDocumentNumber) {
        this.destinationDocumentNumber = destinationDocumentNumber;
    }

    public String getCampaign() {
        return campaign;
    }

    public void setCampaign(String campaign) {
        this.campaign = campaign;
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology;
    }

    public String getTestResult() {
        return testResult;
    }

    public void setTestResult(String testResult) {
        this.testResult = testResult;
    }

    public List<LoadDetailDTO> getLoadDetailDTOList() {
        return loadDetailDTOList;
    }

    public void setLoadDetailDTOList(List<LoadDetailDTO> loadDetailDTOList) {
        this.loadDetailDTOList = loadDetailDTOList;
    }

    public String getTransportType() {
        return transportType;
    }

    public void setTransportType(String transportType) {
        this.transportType = transportType;
    }

}