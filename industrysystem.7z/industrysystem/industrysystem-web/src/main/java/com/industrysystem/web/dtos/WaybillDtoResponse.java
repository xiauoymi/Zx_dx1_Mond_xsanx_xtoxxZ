package com.industrysystem.web.dtos;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: JPNORV
 * Date: 27/11/13
 */
public class WaybillDtoResponse {

    private Boolean success;
    private List<ErrorDTO> errors = new ArrayList<ErrorDTO>();

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public List<ErrorDTO> getErrors() {
        return errors;
    }

    public void setErrors(List<ErrorDTO> errors) {
        this.errors = errors;
    }

}