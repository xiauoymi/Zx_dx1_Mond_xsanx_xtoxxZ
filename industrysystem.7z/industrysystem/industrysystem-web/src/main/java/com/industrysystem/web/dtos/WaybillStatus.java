package com.industrysystem.web.dtos;

import com.industrysystem.entities.WaybillStatusEnum;

/**
 * Created by IntelliJ IDEA.
 * User: CGLLLO
 * Date: 21/02/14
 * Time: 16:01
 */
public class WaybillStatus {

    private WaybillStatusEnum status;
    private String description;

    public WaybillStatus(WaybillStatusEnum waybillStatusEnum) {
        status = waybillStatusEnum;
        description = waybillStatusEnum.getDescription();
    }

    public WaybillStatusEnum getStatus() {
        return status;
    }

    public String getDescription() {
        return description;
    }
}
