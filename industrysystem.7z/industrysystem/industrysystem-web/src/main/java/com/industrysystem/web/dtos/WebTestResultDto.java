package com.industrysystem.web.dtos;

import com.industrysystem.entities.TestRequest;

import static com.industrysystem.entities.utils.DocumentUtils.removeHyphens;
import static org.apache.commons.lang.StringUtils.isEmpty;

/**
 * User: PMIRIB
 * Date: 11/10/13
 */
public class WebTestResultDto {

    private String sampleCode;
    private DestinationDto destination;
    private String testType;
    private TechnologyDto technology;
    private CommercialSenderDto commercialSender;
    private HolderDto holder;

    public DestinationDto getDestination() {
        return destination;
    }

    public void setDestination(DestinationDto destination) {
        this.destination = destination;
    }

    public CommercialSenderDto getCommercialSender() {
        return commercialSender;
    }

    public void setCommercialSender(CommercialSenderDto commercialSender) {
        this.commercialSender = commercialSender;
    }

    public boolean isCommercialSenderEmpty() {
        return commercialSender == null || isEmpty(removeHyphens(commercialSender.getCommercialSenderDocumentNumber()));
    }

    public HolderDto getHolder() {
        return holder;
    }

    public void setHolder(HolderDto holder) {
        this.holder = holder;
    }

    public boolean isHolderEmpty() {
        return holder == null || isEmpty(removeHyphens(holder.getDocumentNumber()));
    }

    public String getTestType() {
        return testType;
    }

    public void setTestType(String testType) {
        this.testType = testType;
    }

    public String getSampleCode() {
        return sampleCode;
    }

    public void setSampleCode(String sampleCode) {
        this.sampleCode = sampleCode;
    }

    public TechnologyDto getTechnology() {
        return technology;
    }

    public void setTechnology(TechnologyDto technology) {
        this.technology = technology;
    }

    public boolean hasTechnology() {
        return technology != null;
    }

    public boolean isQualitative() {
        return TestRequest.QUALITATIVE.equalsIgnoreCase(testType);
    }

    public boolean isQuantitative() {
        return TestRequest.QUANTITATIVE.equalsIgnoreCase(testType);
    }

    public class TechnologyDto {

        private String technology;
        private String qualitativeResult;
        private String percent;
        private String testDate;

        public String getTechnology() {
            return technology;
        }

        public void setTechnology(String technology) {
            this.technology = technology;
        }

        public String getTestDate() {
            return testDate;
        }

        public void setTestDate(String testDate) {
            this.testDate = testDate;
        }

        public String getQualitativeResult() {
            return qualitativeResult;
        }

        public void setQualitativeResult(String qualitativeResult) {
            this.qualitativeResult = qualitativeResult;
        }

        public String getPercent() {
            return percent;
        }

        public void setPercent(String percent) {
            this.percent = percent;
        }
    }

    public class HolderDto {

        private String name;
        private String documentType;
        private String documentNumber;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getDocumentNumber() {
            return documentNumber;
        }

        public void setDocumentNumber(String documentNumber) {
            this.documentNumber = documentNumber;
        }

        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }
    }

    public class CommercialSenderDto {

        private String name;
        private String documentType;
        private String documentNumber;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getCommercialSenderDocumentNumber() {
            return documentNumber;
        }

        public void setDocumentNumber(String documentNumber) {
            this.documentNumber = documentNumber;
        }

        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }
    }

    public class DestinationDto {

        private String name;
        private String documentType;
        private String documentNumber;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getDocumentNumber() {
            return documentNumber;
        }

        public void setDocumentNumber(String documentNumber) {
            this.documentNumber = documentNumber;
        }

        public String getDocumentType() {
            return documentType;
        }

        public void setDocumentType(String documentType) {
            this.documentType = documentType;
        }
    }

}