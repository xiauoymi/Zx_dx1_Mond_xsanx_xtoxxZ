package com.industrysystem.web.dtos.pod.waybill;

import com.industrysystem.business.dtos.LoadDetailDTO;

import java.util.Date;
import java.util.List;

/**
 * User: LSCHW1
 */
public class WaybillPendingDTO {

    private String waybillNumber;
    private String waybillType;
    private String addresseeDocumentNumber;
    private String addresseeName;
    private String holderName;
    private String holderDocumentNumber;
    private Date creationDate;
    private String ctg;
    private String quantitativeLabCode;
    private String receiptNumber;
    private List<LoadDetailDTO> loadDetail;


    public String getWaybillNumber() {
        return waybillNumber;
    }

    public void setWaybillNumber(String waybillNumber) {
        this.waybillNumber = waybillNumber;
    }

    public String getWaybillType() {
        return waybillType;
    }

    public void setWaybillType(String waybillType) {
        this.waybillType = waybillType;
    }

    public String getAddresseeDocumentNumber() {
        return addresseeDocumentNumber;
    }

    public void setAddresseeDocumentNumber(String addresseeDocumentNumber) {
        this.addresseeDocumentNumber = addresseeDocumentNumber;
    }

    public String getAddresseeName() {
        return addresseeName;
    }

    public void setAddresseeName(String addresseeName) {
        this.addresseeName = addresseeName;
    }

    public String getHolderName() {
        return holderName;
    }

    public void setHolderName(String holderName) {
        this.holderName = holderName;
    }

    public String getHolderDocumentNumber() {
        return holderDocumentNumber;
    }

    public void setHolderDocumentNumber(String holderDocumentNumber) {
        this.holderDocumentNumber = holderDocumentNumber;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getCtg() {
        return ctg;
    }

    public void setCtg(String ctg) {
        this.ctg = ctg;
    }

    public List<LoadDetailDTO> getLoadDetail() {
        return loadDetail;
    }

    public void setLoadDetail(List<LoadDetailDTO> loadDetail) {
        this.loadDetail = loadDetail;
    }

    public String getQuantitativeLabCode() {
        return quantitativeLabCode;
    }

    public void setQuantitativeLabCode(String quantitativeLabCode) {
        this.quantitativeLabCode = quantitativeLabCode;
    }

    public String getReceiptNumber() {
        return receiptNumber;
    }

    public void setReceiptNumber(String receiptNumber) {
        this.receiptNumber = receiptNumber;
    }
}