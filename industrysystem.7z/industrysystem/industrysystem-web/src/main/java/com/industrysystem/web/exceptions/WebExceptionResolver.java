package com.industrysystem.web.exceptions;

import com.industrysystem.exceptions.*;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.DefaultHandlerExceptionResolver;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created with IntelliJ IDEA.
 * User: IMDORI
 * Date: 07/02/14
 * Time: 12:11
 */
public class WebExceptionResolver extends DefaultHandlerExceptionResolver {

    @Override
    protected ModelAndView doResolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
            Exception ex) {
        super.doResolveException(request, response, handler, ex);

        try {
            if (ex instanceof BusinessException) {
                return createModelAndViewWithErrorMessages(response, (BusinessException)ex);
            }
            if (ex instanceof AccessDeniedException) {
                return createModelAndViewWithErrorMessages(response, new BusinessException(ex));
            }
        } catch (Exception e) {
            logger.error("send back error status and message : " + ex.getMessage(), e);
        }
        return null;
    }

    private static ModelAndView createModelAndViewWithErrorMessages(HttpServletResponse response, BusinessException ex) {
        response.reset();
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("text/json");

        Map<String, List<BusinessError>> errors = new HashMap<String, List<BusinessError>>();
        errors.put("messages", ex.getErrors());

        Map<String, Object> error = new HashMap<String, Object>();
        error.put("error", errors);

        MappingJacksonJsonView view = new MappingJacksonJsonView();
        view.setAttributesMap(error);

        return new ModelAndView(view);
    }

}