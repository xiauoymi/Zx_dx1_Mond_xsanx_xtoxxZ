package com.industrysystem.web.forms;

import java.util.List;

import com.industrysystem.entities.ChallengeQuestion;

public class ChallengeQuestionsForm {

	private List<ChallengeQuestion> challengeQuestions;
	private Integer toRemove;
	
	public Integer getToRemove() {
		return toRemove;
	}

	public void setToRemove(Integer toRemove) {
		this.toRemove = toRemove;
	}

	public List<ChallengeQuestion> getChallengeQuestions() {
		return challengeQuestions;
	}
	
	public ChallengeQuestionsForm(List<ChallengeQuestion> challengeQuestions) {
		this.challengeQuestions = challengeQuestions;
	}
	
	public ChallengeQuestionsForm() {
		
	}
	
	
	
	

}
