package com.industrysystem.web.forms;


public class ChangePasswordForm extends NewAndConfirmNewPasswordForm
{
	private String oldPassword;
	
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(String oldPassword) {
		this.oldPassword = oldPassword;
	}
}
