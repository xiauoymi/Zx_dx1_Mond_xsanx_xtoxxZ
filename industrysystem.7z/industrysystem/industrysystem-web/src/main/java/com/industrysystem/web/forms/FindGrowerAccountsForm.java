package com.industrysystem.web.forms;

import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
 * User: PPERA
 * Date: 2/28/13
 * Time: 5:43 PM
 */
public class FindGrowerAccountsForm {
    @NotEmpty
    @Size(min = 1, max = 50)
    private String document;
	private long technologyId;

    public long getTechnologyId() {
		return technologyId;
	}

	public void setTechnologyId(long technologyId) {
		this.technologyId = technologyId;
	}

	public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

}
