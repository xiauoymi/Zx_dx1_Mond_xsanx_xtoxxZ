package com.industrysystem.web.forms;

import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Size;

/**
 * User: JPNORV
 * Date: 30/09/13
 * Time: 18:09
 */
public class FindPodAccountsForm {

    @NotEmpty
    @Size(min = 1, max = 50)
    private String document;

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }
}
