package com.industrysystem.web.forms;

public class RecoverPasswordForm extends NewAndConfirmNewPasswordForm
{
	private String emailAddress;
	private String surename;
	private String token;
	private String challengeQuestion;
	private String challengeAnswer;
	
	
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getSurename() {
		return surename;
	}
	public void setSurename(String surename) {
		this.surename = surename;
	}

	public String getChallengeQuestion() {
		return challengeQuestion;
	}
	public void setChallengeQuestion(String challengeQuestion) {
		this.challengeQuestion = challengeQuestion;
	}
	public String getChallengeAnswer() {
		return challengeAnswer;
	}
	public void setChallengeAnswer(String challengeAnswer) {
		this.challengeAnswer = challengeAnswer;
	}
}
