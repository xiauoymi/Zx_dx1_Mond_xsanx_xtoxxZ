package com.industrysystem.web.forms;

import com.industrysystem.security.groups.FunctionalSecurityGroup;

import java.util.List;
import java.util.Map;

import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Maps.newHashMap;

/**
 * User: PPERA
 * Date: 6/25/13
 * Time: 3:22 PM
 */
public class UserForm extends NewAndConfirmNewPasswordForm{
    private Map<String, Map<String, Boolean>> rolesByGroupMap = newHashMap();
    private String sn;
    private String mail;

    public Map<String, Map<String, Boolean>> getRolesByGroupMap() {
        return rolesByGroupMap;
    }

    public void setRolesByGroupMap(Map<String, Map<String, Boolean>> rolesByGroupMap) {
        this.rolesByGroupMap = rolesByGroupMap;
    }

    public String getSn() {
        return sn;
    }

    public void setSn(String sn) {
        this.sn = sn;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public List<FunctionalSecurityGroup> getAssignedGroups() {
        List<FunctionalSecurityGroup> securityGroups = newArrayList();

        for (String group: getRolesByGroupMap().keySet()) {
            for (String role: getRolesByGroupMap().get(group).keySet()) {
                if (getRolesByGroupMap().get(group).get(role)) {
                    FunctionalSecurityGroup securityGroup = new FunctionalSecurityGroup(role, group);
                    securityGroups.add(securityGroup);
                }
            }
        }

        return securityGroups;
    }

}