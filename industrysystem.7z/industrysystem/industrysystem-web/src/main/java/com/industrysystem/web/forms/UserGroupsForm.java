package com.industrysystem.web.forms;

import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import java.util.List;

/**
 * User: PPERA
 * Date: 6/24/13
 * Time: 3:04 PM
 */
public class UserGroupsForm {
    private String document;

    private List<String> assignedGroups;

    public String getDocument() {
        return document;
    }

    public void setDocument(String document) {
        this.document = document;
    }

    public List<String> getAssignedGroups() {
        return assignedGroups;
    }

    public void setAssignedGroups(List<String> assignedGroups) {
        this.assignedGroups = assignedGroups;
    }
}
