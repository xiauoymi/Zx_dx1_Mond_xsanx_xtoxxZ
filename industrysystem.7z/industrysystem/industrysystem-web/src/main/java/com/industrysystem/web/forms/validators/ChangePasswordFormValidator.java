package com.industrysystem.web.forms.validators;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.web.forms.ChangePasswordForm;
import com.industrysystem.web.forms.NewAndConfirmNewPasswordForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public class ChangePasswordFormValidator extends NewAndConfirmNewPasswordFormValidator implements Validator
{
	@Autowired
	private UsersService usersService;
	
	public boolean supports(Class<?> clazz) {
		return ChangePasswordForm.class.isAssignableFrom(clazz);
	}

	@Override
	protected void validateSpecific(NewAndConfirmNewPasswordForm target, Errors errors) {
		ChangePasswordForm form = (ChangePasswordForm) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "oldPassword", "changePassword.error.oldPassword.empty", "Enter a value for Old Password");
		if (!usersService.isPasswordValid(SecurityContextHolder.getContext().getAuthentication().getName() , form.getOldPassword()))
		{
			errors.rejectValue("oldPassword", "changePassword.error.badcredentials", "Your current passwors was not right");
		}
		
	}
}
