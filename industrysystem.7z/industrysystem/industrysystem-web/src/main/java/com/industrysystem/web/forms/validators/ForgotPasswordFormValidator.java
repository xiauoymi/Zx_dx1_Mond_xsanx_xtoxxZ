package com.industrysystem.web.forms.validators;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.exceptions.DirectorySearchResultsException;
import com.industrysystem.web.forms.ForgotPasswordForm;
import org.hibernate.validator.constraints.impl.EmailValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Component
public class ForgotPasswordFormValidator implements Validator {
    @Autowired
    private UsersService usersService;

    public boolean supports(Class<?> clazz) {
        return ForgotPasswordForm.class.isAssignableFrom(clazz);
    }

    public void validate(Object target, Errors errors) {
        ForgotPasswordForm form = (ForgotPasswordForm) target;
        ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        String remoteAddr = requestAttributes.getRequest().getRemoteAddr();

        if (!this.usersService.hasRequiredCaptchasForRecoverPassword(remoteAddr, form.getRecaptcha_challenge_field(), form.getRecaptcha_response_field())) {
            errors.rejectValue("recaptcha_response_field", "forgot_password.error.invalid-captcha");
        }

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailAddress", "forgotPassword.error.emailAddress.empty", "Enter your email address");
        if (!errors.hasErrors()) {
            EmailValidator validator = new EmailValidator();
            if (!validator.isValid(form.getEmailAddress(), null)) {
                errors.rejectValue("emailAddress", "forgot_password.error.malformedAddress", "Malformed email address");
            }
        }

        if (!errors.hasErrors()) {
            try {
                usersService.findPersonWithEmailAddress(form.getEmailAddress());
            } catch (DirectorySearchResultsException e) {
                if (e.getCount() == 0) {
                    errors.rejectValue("emailAddress", "forgot_password.error.inexistingAddress", "No users registered with that email address");
                } else if (e.getCount() > 1) {
                    errors.rejectValue("emailAddress", "forgot_password.error.tooManyPeopleForAddress", "More than one user registered with that email address");
                }

            }
        }
    }
}
