package com.industrysystem.web.forms.validators;

import com.industrysystem.web.forms.NewAndConfirmNewPasswordForm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

@Component
public abstract class NewAndConfirmNewPasswordFormValidator<T extends NewAndConfirmNewPasswordForm> implements Validator {
    @Value("${password_reset_required_strenght_1_to_6}")
    private Integer requiredStrength;

    public void validate(Object target, Errors errors) {

        NewAndConfirmNewPasswordForm form = (NewAndConfirmNewPasswordForm) target;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "newPassword", "changePassword.error.newPassword.empty", "Enter a value for New Password");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "confirmNewPassword", "changePassword.error.confirmNewPassword.empty", "Enter a value for Confirm New Password");

        if (form.getNewPassword() != null && !form.getNewPassword().isEmpty()) {
            this.validatePasswordStrength(form.getNewPassword(), errors);
        }

        if (form.getNewPassword() != null && !form.getNewPassword().equals(form.getConfirmNewPassword())) {
            errors.rejectValue("confirmNewPassword", "changePassword.error.mismatch", "New pass and confirmation don't match");
        }

        boolean validateInclussion = form.getNewPassword() != null && !form.getNewPassword().isEmpty() && form.getUserName() != null && !form.getUserName().isEmpty();

        if (validateInclussion) {
            String upperPass = form.getNewPassword().toUpperCase();
            String upperUser = form.getUserName().toUpperCase();
            if (upperPass.contains(upperUser) || upperUser.contains(upperPass)) {
                errors.rejectValue("newPassword", "changePassword.error.inclussion", "Password must not include your user name and viceversa");
            }
        }


        validateSpecific((T) form, errors);
    }

    public void validatePasswordStrength(String password, Errors errors) {
        int score = 1;

        //if password bigger than 6 give 1 point
        if (password.length() > 6) {
            score++;
        }

        //if password has both lower and uppercase characters give 1 point
        if ((password.matches(".*[a-z].*")) && (password.matches(".*[A-Z].*"))) {
            score++;
        }

        //if password has at least one number give 1 point
        if (password.matches(".*[\\d].*")) {
            score++;
        }

        //if password has at least one special caracther give 1 point
        if (password.matches(".*[!@#$%^&*?_~\\-\\(\\)\\.].*")) {
            score++;
        }

        //if password bigger than 12 give another 1 point
        if (password.length() > 12) {
            score++;
        }

        if (score < this.requiredStrength) {
            errors.rejectValue("newPassword", "changePassword.error.password-strength", "Password is not strong enough");
        }
    }

    protected abstract void validateSpecific(T target, Errors errors);
}
