package com.industrysystem.web.forms.validators;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.industrysystem.web.forms.ChallengeQuestionsForm;
import com.industrysystem.web.forms.NewChallengeQuestionForm;

public class NewChallengeQuestionFormValidator implements Validator {

	//TODO: Create separate controllers and validators
	public boolean supports(Class<?> clazz) {
		return NewChallengeQuestionForm.class.isAssignableFrom(clazz) 
				|| ChallengeQuestionsForm.class.isAssignableFrom(clazz);
	}

	public void validate(Object target, Errors errors) {
		if (target instanceof NewChallengeQuestionForm)
		{
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "question", "challenge_question.error.question.empty");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "answer", "challenge_question.error.answer.empty");
		}
		
	}

}
