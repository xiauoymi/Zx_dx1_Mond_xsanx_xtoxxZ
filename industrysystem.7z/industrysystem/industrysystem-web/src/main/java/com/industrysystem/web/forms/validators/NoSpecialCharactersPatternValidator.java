package com.industrysystem.web.forms.validators;

import javax.annotation.Nullable;
import javax.validation.ConstraintValidatorContext;
import javax.validation.constraints.Pattern;
import java.util.regex.Matcher;

/**
 * User: PPERA
 * Date: 30/07/13
 * Time: 15:50
 */
public class NoSpecialCharactersPatternValidator implements javax.validation.ConstraintValidator<Pattern, String> {

    private java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(
            "[a-z0-9_\u00f1@\u00e1\u00e9\u00ed\u00f3\u00fa ]*", java.util.regex.Pattern.CASE_INSENSITIVE);

    public void initialize(Pattern pattern) {}

    public boolean isValid(String value, @Nullable ConstraintValidatorContext context) {
        if (value == null || value.length() == 0) {
            return true;
        }
        Matcher m = pattern.matcher(value);
        return m.matches();
    }

}