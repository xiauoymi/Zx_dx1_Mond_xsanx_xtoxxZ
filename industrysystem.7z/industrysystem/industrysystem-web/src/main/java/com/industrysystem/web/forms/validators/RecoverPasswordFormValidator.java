package com.industrysystem.web.forms.validators;

import com.industrysystem.web.forms.RecoverPasswordForm;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

@Component
public class RecoverPasswordFormValidator extends NewAndConfirmNewPasswordFormValidator<RecoverPasswordForm> implements Validator
{
	public boolean supports(Class<?> clazz) {
		return RecoverPasswordForm.class.isAssignableFrom(clazz);
	}

	@Override
	protected void validateSpecific(RecoverPasswordForm target, Errors errors) {
		//No specific fields to validate
	}

}
