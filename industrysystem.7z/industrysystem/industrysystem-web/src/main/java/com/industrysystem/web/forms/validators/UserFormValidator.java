package com.industrysystem.web.forms.validators;

import com.industrysystem.web.forms.UserForm;
import org.hibernate.validator.constraints.impl.EmailValidator;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;

/**
 * User: PPERA
 * Date: 03/07/13
 * Time: 11:55
 */
@Component
public class UserFormValidator extends NewAndConfirmNewPasswordFormValidator<UserForm> {

    public boolean supports(Class<?> clazz) {
        return UserForm.class.isAssignableFrom(clazz);
    }

    @Override
    protected void validateSpecific(UserForm form, Errors errors) {
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "userForm.error.userName.empty");

        NoSpecialCharactersPatternValidator noSpecialCharactersPatternValidator = new NoSpecialCharactersPatternValidator();

        if (!noSpecialCharactersPatternValidator.isValid(form.getUserName(), null)) {
            errors.rejectValue("userName", "userForm.error.userName.invalid");
        }

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "sn", "userForm.error.sn.empty");

        if (!noSpecialCharactersPatternValidator.isValid(form.getSn(), null)) {
            errors.rejectValue("sn", "userForm.error.sn.invalid");
        }

        if (form.getRolesByGroupMap().isEmpty()) {
            errors.rejectValue("rolesByGroupMap", "userForm.error.rolesByGroupMap.empty");
        }

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "mail", "userForm.error.mail.empty");

        EmailValidator validator = new EmailValidator();
        if (form.getMail() != null && !form.getMail().isEmpty() && !validator.isValid(form.getMail(), null)) {
            errors.rejectValue("mail", "userForm.error.malformedAddress");
        }
    }
}
