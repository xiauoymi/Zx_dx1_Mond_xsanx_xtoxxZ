package com.industrysystem.web.forms.validators;

import com.industrysystem.web.forms.UserGroupsForm;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

/**
 * User: PPERA
 * Date: 30/07/13
 * Time: 10:41
 */
@Component
public class UserGroupsFormValidator implements Validator {

    public boolean supports(Class<?> clazz) {
        return UserGroupsForm.class.isAssignableFrom(clazz);
    }

    public void validate(Object target, Errors errors) {
        UserGroupsForm form = (UserGroupsForm) target;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "document", "userGroupsForm.error.document.empty");

        NoSpecialCharactersPatternValidator noSpecialCharactersPatternValidator = new NoSpecialCharactersPatternValidator();

        if(!noSpecialCharactersPatternValidator.isValid(form.getDocument(), null)){
            errors.rejectValue("document", "userForm.error.document.invalid");
        }

        if(form.getAssignedGroups() == null || form.getAssignedGroups().isEmpty()){
            errors.rejectValue("assignedGroups", "userForm.error.assignedGroups.empty");
        }
    }
}
