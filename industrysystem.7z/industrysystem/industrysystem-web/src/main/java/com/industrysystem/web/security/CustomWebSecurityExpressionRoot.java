package com.industrysystem.web.security;

import org.springframework.security.access.expression.method.CustomMethodSecurityExpressionRoot;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.FilterInvocation;

import javax.servlet.http.HttpServletRequest;
import java.util.Set;

/**
 * User: PPERA
 * Date: 05/07/13
 * Time: 14:11
 */
public class CustomWebSecurityExpressionRoot extends CustomMethodSecurityExpressionRoot {

    private Set<String> userRoles;
    /*
      * This is for emulating WebSecurityExpressionRoot
      */
    public HttpServletRequest request;

    /**
     * @param authentication
     */
    public CustomWebSecurityExpressionRoot(Authentication authentication) {
        super(authentication);
    }

    public CustomWebSecurityExpressionRoot(Authentication authentication, FilterInvocation filterInvocation) {
        super(authentication);
        this.request = filterInvocation.getRequest();
    }
}
