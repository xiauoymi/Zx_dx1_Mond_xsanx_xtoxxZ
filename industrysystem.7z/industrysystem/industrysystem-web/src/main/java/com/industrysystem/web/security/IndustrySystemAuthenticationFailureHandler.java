package com.industrysystem.web.security;

import com.industrysystem.business.users.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * User: PPERA
 * Date: 5/31/13
 * Time: 2:28 PM
 */
public class IndustrySystemAuthenticationFailureHandler extends SimpleUrlAuthenticationFailureHandler {

    @Autowired
    private UsersService usersService;

    /**
     * This method does not require the user to exist. It would be wise to filter unexistent users before attempting
     * to authenticate them. (see ExistingUserFilter)
     *
     * @param request
     * @param response
     * @param exception
     * @throws IOException
     * @throws ServletException
     */
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) throws IOException, ServletException {
        this.usersService.incrementFailedAttempt(request.getRemoteAddr());
        super.onAuthenticationFailure(request, response, exception);
    }
}
