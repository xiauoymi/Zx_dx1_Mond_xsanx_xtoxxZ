package com.industrysystem.web.security;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.web.security.interceptors.NoChallengesQuestionsWarningInterceptor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.ldap.userdetails.InetOrgPerson;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * User: PPERA
 * Date: 29/07/13
 * Time: 09:51
 */
@Component
public class IndustrySystemAuthenticationSuccessHandler extends SavedRequestAwareAuthenticationSuccessHandler {

    @Autowired
    private UsersService usersService;

    public IndustrySystemAuthenticationSuccessHandler(){
        this.setTargetUrlParameter("targetUrl");
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws ServletException, IOException {
        
    	InetOrgPerson user = (InetOrgPerson)authentication.getPrincipal();
		String mail = user.getMail();
		this.usersService.resetRemainingChallengeQuestionsAttempts(mail);
		
		if (this.usersService.findChallengeQuestions(mail).isEmpty())
		{
			request.getSession().setAttribute(NoChallengesQuestionsWarningInterceptor.WARN_NO_CHALLENGE_QUESTIONS, Boolean.TRUE);
		}
		
    	this.usersService.cleanFailedAuthenticationAttemptsCount(request.getRemoteAddr());
        super.onAuthenticationSuccess(request, response, authentication);
    }
}
