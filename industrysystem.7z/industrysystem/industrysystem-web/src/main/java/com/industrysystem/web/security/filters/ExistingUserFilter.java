package com.industrysystem.web.security.filters;

import com.industrysystem.business.users.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * User: PPERA
 * Date: 6/6/13
 * Time: 3:10 PM
 * <p/>
 * When a user tries to log in, then this filter takes the request that goes
 * to j_security_check and veifies the user exists. If it does not, the user is
 * rejected without an authentication attempt.
 */
@Component
public class ExistingUserFilter implements Filter {

    @Autowired
    private UsersService usersService;

    @Autowired
    protected MessageSource messages;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        if (!usersService.isExistentUser(request.getParameter("j_username"))) {
            ((HttpServletRequest)request).getSession().setAttribute("SPRING_SECURITY_LAST_EXCEPTION", new BadCredentialsException(
                    messages.getMessage("LdapAuthenticationProvider.badCredentials",new Object[0], LocaleContextHolder.getLocale())));
            ((HttpServletResponse)response).sendRedirect(((HttpServletRequest) request).getContextPath() + "/spring/autherror.html");
            //Let it pass and let the authentication failure handler increase failure attemps
            chain.doFilter(request, response);
        } else {
            if (!usersService.hasRequiredCaptchasForAuthentication(request.getRemoteAddr(),
                    request.getParameter("recaptcha_challenge_field"), request.getParameter("recaptcha_response_field"))) {
            	//Needed captcha and didn't get it right, so don't continue with the chain
            	((HttpServletRequest)request).getSession().setAttribute("SPRING_SECURITY_LAST_EXCEPTION", new BadCredentialsException(
                        messages.getMessage("LdapAuthenticationProvider.badCredentials", new Object[0], LocaleContextHolder.getLocale())));
                ((HttpServletResponse)response).sendRedirect(((HttpServletRequest) request).getContextPath() + "/spring/autherror.html");
            } else {
            	//If password is wrong, the authentication failure handler will increase failure attemps
            	 chain.doFilter(request, response);
            }
        }
    }

    @Override
    public void destroy() {
    }

}