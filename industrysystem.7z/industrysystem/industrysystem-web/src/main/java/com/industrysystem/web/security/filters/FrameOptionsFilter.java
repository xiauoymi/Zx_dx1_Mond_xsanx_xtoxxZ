package com.industrysystem.web.security.filters;

import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class FrameOptionsFilter implements Filter {

    private Mode mode = Mode.SAME_ORIGIN;
    private String allowFromUrl = "";

    enum Mode {

        DENY("DENY"), SAME_ORIGIN("SAMEORIGIN"), ALLOW_FROM("ALLOW-FROM");

        private String value;

        Mode(String value) {
            this.value = value;
        }

        String getValue() {
            return value;
        }

        static Mode fromValue(String value) {
            for (Mode mode: Mode.values()) {
                if (mode.value.equalsIgnoreCase(value)) {
                    return mode;
                }
            }
            return null;
        }
    }

    /**
     * Allowed parameters and values:
     * - "mode": "DENY" | "SAMEORIGIN" | "ALLOW-FROM"
     * - "allowFromUrl": {uri}
     */
    public void init(FilterConfig filterConfig) throws ServletException {
        String modeStr = filterConfig.getInitParameter("mode");
        if (modeStr != null) {
            Mode mode = Mode.fromValue(modeStr);
            if (mode != null) {
                this.mode = mode;
            } else {
                throw new ServletException("Invalid mode: " + modeStr);
            }
        }

        String allowFromUrl = filterConfig.getInitParameter("allowFromUrl");
        if (allowFromUrl != null) {
            this.allowFromUrl = allowFromUrl;
        }
    }

    String getFrameOptionsValue() {
        return mode != Mode.ALLOW_FROM? mode.getValue(): mode.getValue() + " " + allowFromUrl;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {
        HttpServletResponse httpResponse = (HttpServletResponse)response;
        httpResponse.addHeader("X-Frame-Options", getFrameOptionsValue());
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {}

}