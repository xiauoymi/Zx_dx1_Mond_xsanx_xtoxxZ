package com.industrysystem.web.security.filters;

import org.apache.log4j.MDC;

import javax.servlet.*;
import java.io.IOException;

/**
 * An example authentication filter which is used to intercept all the requests
 * for fetching the user name from it and put the user name to the Log4j Mapped
 * Diagnostic Context (MDC), so that the user name could be used for
 * differentiating log messages.
 * 
 * @author veerasundar.com/blog
 * 
 */
public class MDCFilter implements Filter {

    @Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		try {
			MDC.put("ip", request.getRemoteAddr());
			chain.doFilter(request, response);
		} finally {
			MDC.remove("ip");
		}
	}

    @Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

    @Override
	public void destroy() {
	}

}