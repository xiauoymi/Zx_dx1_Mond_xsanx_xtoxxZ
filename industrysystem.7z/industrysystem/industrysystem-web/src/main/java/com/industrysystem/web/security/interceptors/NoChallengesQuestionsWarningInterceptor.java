package com.industrysystem.web.security.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.industrysystem.web.util.ModelMessagesHelper;
import com.industrysystem.web.util.ServletHelper;

public class NoChallengesQuestionsWarningInterceptor extends HandlerInterceptorAdapter {

	public static final String WARN_NO_CHALLENGE_QUESTIONS = "warn_no_challenge_questions"; 
	
	@Autowired
	private ModelMessagesHelper modelMessagesHelper;

	@Autowired
	private ServletHelper servletHelper;
	
	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		super.postHandle(request, response, handler, modelAndView);
		Object attribute = request.getSession().getAttribute(WARN_NO_CHALLENGE_QUESTIONS);
		
		if (Boolean.TRUE.equals(attribute) && modelAndView!=null)
		{
			modelMessagesHelper.warning("challenge_question.warning.none_present", modelAndView.getModel(), servletHelper.getRequestURL(request).append("/spring/secured/challenge/change.html").toString() );
			request.getSession().removeAttribute(WARN_NO_CHALLENGE_QUESTIONS);
		}

	}
}
