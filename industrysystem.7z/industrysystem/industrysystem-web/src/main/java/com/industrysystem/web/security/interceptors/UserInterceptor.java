package com.industrysystem.web.security.interceptors;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UserInterceptor extends HandlerInterceptorAdapter {

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		super.postHandle(request, response, handler, modelAndView);
		if (SecurityContextHolder.getContext().getAuthentication() != null && modelAndView!=null) {
			modelAndView.addObject("user", SecurityContextHolder.getContext().getAuthentication().getPrincipal());	
		}
	}
}
