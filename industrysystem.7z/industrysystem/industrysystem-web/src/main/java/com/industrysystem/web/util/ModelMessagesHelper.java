package com.industrysystem.web.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * User: PPERA
 * Date: 6/25/13
 * Time: 1:22 PM
 */

@Component
public class ModelMessagesHelper {
    
	@Autowired
	private MessageSource messageSource;
	
	private static final String SUCCESS_MESSAGES = "successMessages";
    private static final String INFO_MESSAGES = "infoMessages";
    private static final String WARNING_MESSAGES = "warningMessages";
    private static final String ERROR_MESSAGES = "errorMessages";
    
	public void success(String message, Model model, String...arguments) {
    	process(message, model, SUCCESS_MESSAGES, arguments);
    }
	public void info(String message, Model model, String...arguments) {
    	process(message, model, INFO_MESSAGES, arguments);
    }
	public void warning(String message, Model model, String...arguments) {
    	process(message, model, WARNING_MESSAGES, arguments);
    }
	public void warning(String message, Map<String, Object> modelMap, String...arguments) {
    	process(message, modelMap, WARNING_MESSAGES, arguments);
    }
	public void error(String message, Model model, String...arguments) {
    	process(message, model, ERROR_MESSAGES, arguments);
    }

	private void process(String message, Model model, String key, String...arguments) {
		process(message, model.asMap(), key, arguments);
	}
	
	private void process(String message, Map<String, Object> modelMap, String key, String...arguments) {
		if (!modelMap.containsKey(key))
		{
			modelMap.put(key, new ArrayList<String>());
		}

		@SuppressWarnings("unchecked")
		List<String> messagesForKey = (List<String>) modelMap.get(key);
    	
    	try{
    		String localizedMessage = messageSource.getMessage(message, arguments, LocaleContextHolder.getLocale());
    		messagesForKey.add(localizedMessage);
    	}
    	catch(NoSuchMessageException e)
    	{
    		messagesForKey.add("${" + message + "}");
    	}
	}

}
