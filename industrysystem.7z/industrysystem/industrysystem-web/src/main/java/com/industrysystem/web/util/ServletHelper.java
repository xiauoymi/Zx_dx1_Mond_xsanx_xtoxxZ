package com.industrysystem.web.util;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;

@Component
public class ServletHelper {

	public StringBuffer getRequestURL(HttpServletRequest req) {
        String scheme = req.getScheme();
        int port = req.getServerPort();

        StringBuffer url = new StringBuffer().append(scheme).append("://").append(req.getServerName());
        if ((scheme.equals("http") && port != 80) || (scheme.equals("https") && port != 443)) {
            url.append(':').append(req.getServerPort());
        }
        url.append(req.getContextPath());

        return url;
    }

}