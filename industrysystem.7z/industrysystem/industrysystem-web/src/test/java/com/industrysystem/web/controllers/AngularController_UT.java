package com.industrysystem.web.controllers;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.ui.Model;

import static org.fest.assertions.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * User: PPERA
 * Date: 1/9/14
 * Time: 1:38 PM
 */
public class AngularController_UT {
    private AngularController angularController;

    @Before
    public void setUp() {
        this.angularController = new AngularController();
    }

    @Test
    public void testViewLoginPageReturnsGrowerLogin_WhenRequestUrlIsPartialsGrowerLogin() {
        // Given a request for the grower login page
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/partials/grower/login.jsp");
        String loginType = null;
        Model model = mock(Model.class);

        // @When resolving the view name
        String viewName = this.angularController.viewLoginPage(request, loginType, model);

        // @Then the view name returned is login
        assertThat(viewName).isEqualTo("/grower/login");
    }

    @Test
    public void testViewLoginPageReturnsPodLogin_WhenRequestUrlIsPartialsPodLogin() {
        // Given a request for the grower login page
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/partials/pod/login.jsp");
        String loginType = null;
        Model model = mock(Model.class);

        // @When resolving the view name
        String viewName = this.angularController.viewLoginPage(request, loginType, model);

        // @Then the view name returned is login
        assertThat(viewName).isEqualTo("/pod/login");
    }

    @Test
    public void testViewLoginPageSetsPodLoginTypeInModel_WhenLoginTypeIsPod() {
        // Given a request for the grower login page
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/partials/pod/login.jsp");
        String loginType = "pod";
        Model model = mock(Model.class);

        // @When resolving the view name
        String viewName = this.angularController.viewLoginPage(request, loginType, model);

        // @Then the view name returned is login
        verify(model).addAttribute("loginType", "pod");
    }

    @Test
    public void testViewLoginPageSetsLaboratoryLoginTypeInModel_WhenLoginTypeIsLaboratory() {
        // Given a request for the grower login page
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/partials/laboratory/login.jsp");
        String loginType = "laboratory";
        Model model = mock(Model.class);

        // @When resolving the view name
        String viewName = this.angularController.viewLoginPage(request, loginType, model);

        // @Then the view name returned is login
        verify(model).addAttribute("loginType", "laboratory");
    }

    @Test
    public void testViewPageReturnsPage1_WhenRequestUrlIsPartialsPage1() {
        // Given a request for the grower login page
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/partials/page1.jsp");
        String loginType = null;
        Model model = mock(Model.class);

        // @When resolving the view name
        String viewName = this.angularController.viewPage(request);

        // @Then the view name returned is login
        assertThat(viewName).isEqualTo("/page1");
    }

    @Test
    public void testViewPageReturnsPage2_WhenRequestUrlIsPartialsPage2() {
        // Given a request for the grower login page
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRequestURI("/partials/page2.jsp");
        String loginType = null;
        Model model = mock(Model.class);

        // @When resolving the view name
        String viewName = this.angularController.viewPage(request);

        // @Then the view name returned is login
        assertThat(viewName).isEqualTo("/page2");
    }
}
