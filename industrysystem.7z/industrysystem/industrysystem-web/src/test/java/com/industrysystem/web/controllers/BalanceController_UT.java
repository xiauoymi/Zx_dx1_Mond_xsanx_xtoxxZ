package com.industrysystem.web.controllers;

import com.industrysystem.business.DeliveredTechnologyServiceImpl;
import com.industrysystem.business.GrowerBalanceService;
import com.industrysystem.business.dtos.GrowerBalanceDTO;
import com.industrysystem.business.mappers.GrowerBalanceMapper;
import com.industrysystem.entities.GrowerBalance;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: ASEQU
 * Date: 11/21/13
 * Time: 9:11 AM
 */
public class BalanceController_UT {


    private BalanceController controller;
    private GrowerBalanceService growerBalanceService;
    private GrowerBalanceMapper growerBalanceMapper;
    private static final BigDecimal BALANCE_ZERO = new BigDecimal(0);
    private static final BigDecimal BALANCE_SEVEN = new BigDecimal(7);

    @Before
    public void setUp() {
        this.controller = new BalanceController();
        this.growerBalanceService = mock(GrowerBalanceService.class);
        field("growerBalanceService").ofType(GrowerBalanceService.class).in(this.controller).set(this.growerBalanceService);
    }

    private GrowerBalance newGrowerBalance(Integer id, BigDecimal available, BigDecimal extended) {

        GrowerBalance growerBalance = new GrowerBalance();

        growerBalance.setId(id);
        growerBalance.setAvailable(available);
        growerBalance.setExtended(extended);

        return growerBalance;
    }
}
