package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.ldap.userdetails.InetOrgPerson;
import org.springframework.ui.Model;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * User: PPERA
 * Date: 22/10/13
 * Time: 14:35
 */
public class ChallengeQuestionController_UT {

    private ChallengeQuestionController challengeQuestionController;
    private Model model;
    private Authentication authentication;
    private UsersService userService;

    @Before
    public void setUp(){
        this.challengeQuestionController = new ChallengeQuestionController();
        this.model = mock(Model.class);
        this.userService = mock(UsersService.class);

        field("usersService").ofType(UsersService.class).in(this.challengeQuestionController).set(this.userService);

        SecurityContext securityContext = mock(SecurityContext.class);
        this.authentication = mock(UsernamePasswordAuthenticationToken.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        InetOrgPerson inetOrgPerson = mock(InetOrgPerson.class);
        when(this.authentication.getPrincipal()).thenReturn(inetOrgPerson);
        SecurityContextHolder.setContext(securityContext);
    }

    @Test
    public void testShowFormReturnsChallengeQuestionViewName_WhenShowingTheForm(){
        // @Given

        // @When showing the form
        String viewName = this.challengeQuestionController.showForm(this.model);

        // @Then the challengeQuestion view name is returned
        assertThat(viewName).isEqualTo(ChallengeQuestionController.CHALLENGEQUESTION_VIEW);
    }
}
