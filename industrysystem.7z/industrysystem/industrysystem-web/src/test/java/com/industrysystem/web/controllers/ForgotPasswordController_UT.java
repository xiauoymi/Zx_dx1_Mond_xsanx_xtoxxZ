package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.entities.ChallengeQuestion;
import com.industrysystem.exceptions.SendingEmailException;
import com.industrysystem.web.forms.ForgotPasswordForm;
import com.industrysystem.web.forms.validators.ForgotPasswordFormValidator;
import com.industrysystem.web.util.ModelMessagesHelper;
import com.industrysystem.web.util.ServletHelper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;

import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static java.util.Collections.emptyList;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 3/15/13
 * Time: 12:46 PM
 */
public class ForgotPasswordController_UT {

    private static final String EMAIL_ADDRESS = "email@address";
    private static final String TOKEN = "token";
    private static final String LINK_SCHEME = "https";
    private static final int LINK_PORT = 1503;
    private static final String LINK_SERVER_NAME = "server_name";
    private static final String LINK_CONTEXT_PATH = "/context_path";

    private ForgotPasswordController controller;
    private Model model;
    private ForgotPasswordFormValidator forgotPasswordFormValidator;
    private ForgotPasswordForm forgotPasswordForm;
    private ModelMessagesHelper modelMessagesHelper;
    private WebDataBinder binder;
    private BindingResult bindingResult;
    private UsersService usersService;
    private MockHttpServletRequest request;
    
    @Before
    public void setUp() {
        controller = new ForgotPasswordController();
        field("forgotPasswordFormValidator").ofType(ForgotPasswordFormValidator.class).in(controller).set(forgotPasswordFormValidator);
        usersService = mock(UsersService.class);
        field("usersService").ofType(UsersService.class).in(controller).set(usersService);
        modelMessagesHelper = mock(ModelMessagesHelper.class);
        field("modelMessagesHelper").ofType(ModelMessagesHelper.class).in(controller).set(modelMessagesHelper);
        field("servletHelper").ofType(ServletHelper.class).in(controller).set(new ServletHelper());

        request = new MockHttpServletRequest();
        request.setScheme(LINK_SCHEME);
        request.setServerPort(LINK_PORT);
        request.setServerName(LINK_SERVER_NAME);
        request.setContextPath(LINK_CONTEXT_PATH);
        
        model = new ExtendedModelMap();
        binder = mock(WebDataBinder.class);
        forgotPasswordForm = mock(ForgotPasswordForm.class);
        bindingResult = mock(BindingResult.class);
        
        when(forgotPasswordForm.getEmailAddress()).thenReturn(EMAIL_ADDRESS);
    }

    @Test
    public void testInitBinder() {
        controller.initBinder(binder);
        verify(binder).setValidator(forgotPasswordFormValidator);
    }

    @Test
    public void testLandingPage() {
        String returned = controller.forgotPassword(model);
        assertThat(model.asMap().get("forgotPasswordForm")).isInstanceOf(ForgotPasswordForm.class);
        assertThat(returned).isEqualTo(ForgotPasswordController.FORGOTPASSWORDFORM_VIEW);
    }
    
    @Test
    public void testEnteringWithInvalidToken() {
    	String returned = controller.invalidToken(model);
        
        assertThat(model.asMap().get("forgotPasswordForm")).isInstanceOf(ForgotPasswordForm.class);
        assertThat(returned).isEqualTo(ForgotPasswordController.FORGOTPASSWORDFORM_VIEW);
        verify(modelMessagesHelper).error("recoverpassword.invalid.token", model);
    }
    
    @Test
    public void testMailNotFound() {
    	String returned = controller.findingEmailError(model);
        
        assertThat(model.asMap().get("forgotPasswordForm")).isInstanceOf(ForgotPasswordForm.class);
        assertThat(returned).isEqualTo(ForgotPasswordController.FORGOTPASSWORDFORM_VIEW);
        verify(modelMessagesHelper).error("recoverpassword.mail.input.error", model);
    }

    @Test
    public void testSendMail_Successful() throws SendingEmailException {
    	when(bindingResult.hasErrors()).thenReturn(false);
    	when(usersService.generatePasswordResetToken(EMAIL_ADDRESS)).thenReturn(TOKEN);
    	when(usersService.findDoableChallengeQuestions(EMAIL_ADDRESS)).thenReturn(newArrayList(createDummyChallengeQuestion()));
    	
    	String returned = controller.sendMail(model, forgotPasswordForm, bindingResult, request);
        
    	String linkToRecoverPassword = LINK_SCHEME + "://" + LINK_SERVER_NAME + ":" + LINK_PORT + LINK_CONTEXT_PATH +
                "/spring/recoverpasswordform.html?token=" + TOKEN;
		String baseImagesUrl = LINK_SCHEME + "://" + LINK_SERVER_NAME + ":" + LINK_PORT + LINK_CONTEXT_PATH + "/resources/img/mail";
		verify(usersService).sendMailForPasswordRecovery(EMAIL_ADDRESS, linkToRecoverPassword, baseImagesUrl);
        assertThat(model.asMap().get("email")).isEqualTo(EMAIL_ADDRESS);
        assertThat(returned).isEqualTo(ForgotPasswordController.RESETPASSWORDMAILSENT_VIEW);
    }

    @Test
    public void testSendMail_NoChallengeQuestionsConfigured() throws SendingEmailException {
    	when(bindingResult.hasErrors()).thenReturn(false);
    	when(usersService.generatePasswordResetToken(EMAIL_ADDRESS)).thenReturn(TOKEN);
    	List<ChallengeQuestion> emptyList = emptyList();
		when(usersService.findDoableChallengeQuestions(EMAIL_ADDRESS)).thenReturn(emptyList);
    	
    	String returned = controller.sendMail(model, forgotPasswordForm, bindingResult, request);

        assertThat(returned).isEqualTo(PasswordRecoveryController.NO_CHALLENGES_TO_ANSWER);
    }

	private ChallengeQuestion createDummyChallengeQuestion() {
		return new ChallengeQuestion();
	}
    
    @Test
    public void testSendMail_WhenInvalidEmail() throws SendingEmailException {
    	when(bindingResult.hasErrors()).thenReturn(true);
    	
    	String returned = controller.sendMail(model, forgotPasswordForm, bindingResult, request);
        
    	assertThat(model.asMap().get("forgotPasswordForm")).isSameAs(forgotPasswordForm);
        assertThat(returned).isEqualTo(ForgotPasswordController.FORGOTPASSWORDFORM_VIEW);
    }
    
    @Test
    public void testSendMail_ErrorSendingEmail() throws SendingEmailException{
    	when(bindingResult.hasErrors()).thenReturn(false);
    	when(usersService.generatePasswordResetToken(EMAIL_ADDRESS)).thenReturn(TOKEN);
    	doThrow(new SendingEmailException()).when(usersService).sendMailForPasswordRecovery(anyString(), anyString(), anyString());
		when(usersService.findDoableChallengeQuestions(EMAIL_ADDRESS)).thenReturn(newArrayList(createDummyChallengeQuestion()));
    	
    	String returned = controller.sendMail(model, forgotPasswordForm, bindingResult, request);
        
    	verify(modelMessagesHelper).error("forgot_password.send.mail.error", model);
    	assertThat(returned).isEqualTo(ForgotPasswordController.FORGOTPASSWORDFORM_VIEW);
    }

}