package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.web.forms.UserGroupsForm;
import com.industrysystem.web.util.ModelMessagesHelper;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import javax.naming.NamingException;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 30/07/13
 * Time: 16:15
 */
public class GroupCrudController_UT {

    private GroupCrudController groupCrudController;
    private UsersService usersService;
    private ModelMessagesHelper messagesHelper;

    @Before
    public void setUp() {
        groupCrudController = new GroupCrudController();
        usersService = mock(UsersService.class);
        field("usersService").ofType(UsersService.class).in(groupCrudController).set(usersService);
        messagesHelper = mock(ModelMessagesHelper.class);
        field("messagesHelper").ofType(ModelMessagesHelper.class).in(groupCrudController).set(messagesHelper);
    }

    @Test
    public void testNewGroupAssignationFormReturnsNewGroupAssignationView_WhenRequestingTheFormForGroupAssignation() {
        // @Given
        Model model = mock(Model.class);

        // @When
        String viewName = groupCrudController.newGroupAssignationForm(model);

        // @Then
        assertThat(viewName).isEqualTo("newGroupAssignationForm");
    }

    @Test
    public void testNewGroupAssignationFormReturnsAUserGrupsFormInTheModel_WhenRequestingTheGroupAssignationForm() {
        // @Given
        Model model = new ExtendedModelMap();

        // @When
        groupCrudController.newGroupAssignationForm(model);

        // @Then
        assertThat(model.asMap().get("userGroupsForm")).isNotNull();
        assertThat(model.asMap().get("userGroupsForm")).isInstanceOf(UserGroupsForm.class);
    }

    @Test
    public void testNewGroupAssignationFormReturnsAGroupInTheModel_WhenRequestingTheFormForGroupAssignationAndThereIsOneGroup() {
        // @Given
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("aGroup"));

        // @When
        groupCrudController.newGroupAssignationForm(model);

        // @Then
        assertThat(model.asMap().get("groups")).isNotNull();
        assertThat(model.asMap().get("groups")).isInstanceOf(List.class);
        assertThat((List) model.asMap().get("groups")).isEqualTo(usersService.findAllRoleNames());
    }

    @Test
    public void testNewGroupAssignationFormReturnsTwoGroupsInTheModel_WhenRequestingTheFormForGroupAssignationAndThereIsTwoGroups() {
        // @Given
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("aGroup", "anotherGroup"));

        // @When
        groupCrudController.newGroupAssignationForm(model);

        // @Then
        assertThat(model.asMap().get("groups")).isNotNull();
        assertThat(model.asMap().get("groups")).isInstanceOf(List.class);
        assertThat((List) model.asMap().get("groups")).isEqualTo(usersService.findAllRoleNames());
    }

    @Test
    public void testNewGroupAssignationFormReturnsAssignedGroupsAsEmptyInTheUserGroupsForm_WhenRequestingTheFormForGroupAssignation() {
        // @Given
        Model model = new ExtendedModelMap();

        // @When
        groupCrudController.newGroupAssignationForm(model);

        // @Then
        UserGroupsForm userGroupsForm = (UserGroupsForm) model.asMap().get("userGroupsForm");
        assertThat(userGroupsForm.getAssignedGroups()).isEmpty();
    }

    @Test
    public void testNewGroupAssignationFormReturnsNewGroupAssignationView_WhenPostingTheFormForGroupAssignation() {
        // @Given
        Model model = mock(Model.class);
        UserGroupsForm userGroupsForm = new UserGroupsForm();
        BindingResult result = mock(BindingResult.class);

        // @When
        String viewName = groupCrudController.newGroupAssignationForm(userGroupsForm, result, model);

        // @Then
        assertThat(viewName).isEqualTo("newGroupAssignationForm");
    }

    @Test
    public void testNewGroupAssignationFormReturnsPostedUserGrupsFormInTheModel_WhenPostingTheGroupAssignationForm() {
        // @Given
        Model model = new ExtendedModelMap();
        UserGroupsForm userGroupsForm = new UserGroupsForm();
        BindingResult result = mock(BindingResult.class);

        // @When
        groupCrudController.newGroupAssignationForm(userGroupsForm, result, model);

        // @Then
        assertThat(model.asMap().get("userGroupsForm")).isNotNull();
        assertThat(model.asMap().get("userGroupsForm")).isSameAs(userGroupsForm);
    }

    @Test
    public void testNewGroupAssignationFormReturnsAGroupInTheModel_WhenPostingTheFormForGroupAssignationAndThereIsOneGroup() {
        // @Given
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("aGroup"));
        UserGroupsForm userGroupsForm = new UserGroupsForm();
        BindingResult result = mock(BindingResult.class);

        // @When
        groupCrudController.newGroupAssignationForm(userGroupsForm, result, model);

        // @Then
        assertThat(model.asMap().get("groups")).isNotNull();
        assertThat(model.asMap().get("groups")).isInstanceOf(List.class);
        assertThat((List) model.asMap().get("groups")).isEqualTo(usersService.findAllRoleNames());
    }

    @Test
    public void testNewGroupAssignationFormReturnsTwoGroupsInTheModel_WhenPostingTheFormForGroupAssignationAndThereIsTwoGroups() {
        // @Given
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("aGroup", "anotherGroup"));
        UserGroupsForm userGroupsForm = new UserGroupsForm();
        BindingResult result = mock(BindingResult.class);

        // @When
        groupCrudController.newGroupAssignationForm(userGroupsForm, result, model);

        // @Then
        assertThat(model.asMap().get("groups")).isNotNull();
        assertThat(model.asMap().get("groups")).isInstanceOf(List.class);
        assertThat((List) model.asMap().get("groups")).isEqualTo(usersService.findAllRoleNames());
    }

    @Test
    public void testNewGroupAssignationFormCallsUsersServiceAssignGroupsWithDocument10_WhenPostingTheFormForGroupAssignationWithDocument10()
            throws Exception {
        // @Given
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("aGroup", "anotherGroup"));
        UserGroupsForm userGroupsForm = new UserGroupsForm();
        userGroupsForm.setDocument("10");
        BindingResult result = mock(BindingResult.class);

        // @When
        groupCrudController.newGroupAssignationForm(userGroupsForm, result, model);

        // @Then
        verify(usersService).assignGroups(eq("10"), anyList());
    }

    @Test
    public void testNewGroupAssignationFormCallsMessagesHelperErrorWithGroupAssignError_WhenPostingTheFormForGroupAndAssignGroupsThrowsNamingException()
            throws NamingException {
        // @Given
        Model model = new ExtendedModelMap();
        doThrow(new NamingException()).when(usersService).assignGroups(Matchers.<String>any(), Matchers.<List<String>>any());
        UserGroupsForm userGroupsForm = new UserGroupsForm();
        userGroupsForm.setDocument("10");
        BindingResult result = mock(BindingResult.class);

        // @When
        groupCrudController.newGroupAssignationForm(userGroupsForm, result, model);

        // @Then
        verify(messagesHelper).error("security.assign.group.error", model);
    }

    @Test
    public void testNewGroupAssignationFormReturnsNewGroupAssignationView_WhenBindingResultHasErrors() {
        // @Given
        UserGroupsForm form = mock(UserGroupsForm.class);
        BindingResult result = mock(BindingResult.class);
        when(result.hasErrors()).thenReturn(true);
        Model model = mock(Model.class);

        // @When
        String viewName = groupCrudController.newGroupAssignationForm(form, result, model);

        // @Then
        assertThat(viewName).isEqualTo("newGroupAssignationForm");
    }

    @Test
    public void testNewGroupAssignationFormReturnsAUserGrupsFormInTheModel_WhenBindingResultHasErrors() {
        // @Given
        UserGroupsForm form = mock(UserGroupsForm.class);
        BindingResult result = mock(BindingResult.class);
        when(result.hasErrors()).thenReturn(true);
        Model model = new ExtendedModelMap();

        // @When
        groupCrudController.newGroupAssignationForm(form, result, model);

        // @Then
        assertThat(model.asMap().get("userGroupsForm")).isNotNull();
        assertThat(model.asMap().get("userGroupsForm")).isInstanceOf(UserGroupsForm.class);
    }

    @Test
    public void testNewGroupAssignationFormReturnsAGroupInTheModel_WhenRequestingTheFormForGroupAssignationAndThereIsOneGroupAndBindingResultHasErrors() {
        // @Given
        UserGroupsForm form = mock(UserGroupsForm.class);
        BindingResult result = mock(BindingResult.class);
        when(result.hasErrors()).thenReturn(true);
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("aGroup"));

        // @When
        groupCrudController.newGroupAssignationForm(form, result, model);

        // @Then
        assertThat(model.asMap().get("groups")).isNotNull();
        assertThat(model.asMap().get("groups")).isInstanceOf(List.class);
        assertThat((List) model.asMap().get("groups")).isEqualTo(usersService.findAllRoleNames());
    }

    @Test
    public void testNewGroupAssignationFormReturnsTwoGroupsInTheModel_WhenRequestingTheFormForGroupAssignationAndThereIsTwoGroupsAndBindingResultHasErrors() {
        // @Given
        UserGroupsForm form = mock(UserGroupsForm.class);
        BindingResult result = mock(BindingResult.class);
        when(result.hasErrors()).thenReturn(true);
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("aGroup", "anotherGroup"));

        // @When
        groupCrudController.newGroupAssignationForm(form, result, model);

        // @Then
        assertThat(model.asMap().get("groups")).isNotNull();
        assertThat(model.asMap().get("groups")).isInstanceOf(List.class);
        assertThat((List) model.asMap().get("groups")).isEqualTo(usersService.findAllRoleNames());
    }

    @Test
    public void testNewGroupAssignationFormReturnsAssignedGroupsAsEmptyInTheUserGroupsForm_WhenRequestingTheFormForGroupAssignationAndBindingResultHasErrors() {
        // @Given
        UserGroupsForm form = mock(UserGroupsForm.class);
        BindingResult result = mock(BindingResult.class);
        when(result.hasErrors()).thenReturn(true);
        Model model = new ExtendedModelMap();

        // @When
        groupCrudController.newGroupAssignationForm(form, result, model);

        // @Then
        UserGroupsForm userGroupsForm = (UserGroupsForm) model.asMap().get("userGroupsForm");
        assertThat(userGroupsForm.getAssignedGroups()).isEmpty();
    }

}