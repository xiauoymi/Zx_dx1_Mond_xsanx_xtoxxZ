package com.industrysystem.web.controllers;

import org.junit.Before;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 * Date: 3/15/13
 * Time: 12:44 PM
 */
public class HomeController_UT {

    private HomeController homeController;

    @Before
    public void setUp() {
        this.homeController = new HomeController();
    }

    @Test
    public void testHomeReturnsHomeViewName_WhenViewingHome(){
        // @Given a Home controller

        // @When viewing the home
        String viewName = this.homeController.home();

        // @Then home view name is returned
        assertThat(viewName).isEqualTo("home");
    }

    @Test
    public void testSecuredHomeReturnsSecuredHomeViewName_WhenViewingSecuredHome(){
        // @Given a Home controller

        // @When viewing the securedHome
        String viewName = this.homeController.securedHome();

        // @Then securedHome view name is returned
        assertThat(viewName).isEqualTo("securedHome");
    }

    @Test
    public void testSecuredHomeReturnsTermsAndConditionsViewName_WhenViewingTermsAndConditions(){
        // @Given a Home controller

        // @When viewing the termsAndConditions
        String viewName = this.homeController.termsAndConditions();

        // @Then termsAndConditions view name is returned
        assertThat(viewName).isEqualTo("termsAndConditions");
    }

    @Test
    public void testSecuredHomeReturnsAboutUsViewName_WhenViewingAboutUs(){
        // @Given a Home controller

        // @When viewing the aboutUs
        String viewName = this.homeController.aboutUs();

        // @Then aboutUs view name is returned
        assertThat(viewName).isEqualTo("aboutUs");
    }

    @Test
    public void testSecuredHomeReturnsPrivacyPolicyViewName_WhenViewingPrivacyPolicy(){
        // @Given a Home controller

        // @When viewing the privacyPolicy
        String viewName = this.homeController.privacyPolicy();

        // @Then privacyPolicy view name is returned
        assertThat(viewName).isEqualTo("privacyPolicy");
    }
}
