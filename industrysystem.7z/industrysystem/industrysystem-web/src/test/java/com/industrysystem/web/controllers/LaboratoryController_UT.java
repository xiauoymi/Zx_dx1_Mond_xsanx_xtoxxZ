package com.industrysystem.web.controllers;

import com.industrysystem.business.LaboratoryService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

/**
 * User: PMIRIB
 * Date: 21/02/14
 */
@RunWith(MockitoJUnitRunner.class)
public class LaboratoryController_UT {

    @Mock
    private LaboratoryService laboratoryService;

    @InjectMocks
    private LaboratoryController laboratoryController;

    @Test
    public void testPopulateLaboratories(){
        laboratoryController.populateLaboratories();
    }

}
