package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.web.util.ModelMessagesHelper;
import org.fest.assertions.MapAssert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.ldap.userdetails.Person;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;


/**
 * User: PPERA
 * Date: 3/15/13
 * Time: 12:46 PM
 */
public class LoginController_UT {
    private LoginController loginController;
    private ModelMap modelMap;
    private Model model;
    private HttpSession session;
    private ModelMessagesHelper modelMessagesHelper;
    private Authentication authentication;
    private UsersService usersService;

    @Before
    public void setUp() {
        this.loginController = new LoginController();
        this.modelMap = new ModelMap();
        this.model = mock(Model.class);
        this.session = Mockito.mock(HttpSession.class);
        this.modelMessagesHelper = mock(ModelMessagesHelper.class);
        this.usersService = mock(UsersService.class);
        field("messagesHelper").ofType(ModelMessagesHelper.class).in(loginController).set(modelMessagesHelper);
        field("usersService").ofType(UsersService.class).in(loginController).set(this.usersService);
        this.authentication = mock(Authentication.class);
        SecurityContext securityContext = mock(SecurityContext.class);
        Mockito.when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);
    }

    @Test
    public void testShowFormReturnsLoginFormViewName_WhenShowingTheLoginFormAndNoAuthenticated() {
        // @Given
        Mockito.when(authentication.isAuthenticated()).thenReturn(false);
        HttpServletRequest request = new MockHttpServletRequest();

        // @When showing the login form
        String viewName = this.loginController.showForm(this.modelMap, request);

        // @Then the login grower view name is returned
        assertThat(viewName).isEqualTo("logingrower");
    }

    @Test
    public void testShowFormReturnsLoginFormViewName_WhenShowingTheLoginFormAndAnonymusAuthentication() {
        // @Given an anonnymus authentication
        HttpServletRequest request = new MockHttpServletRequest();
        Mockito.when(authentication.isAuthenticated()).thenReturn(true);
        Mockito.when(authentication.getPrincipal()).thenReturn("Anonymusito");

        // @When showing the login form
        String viewName = this.loginController.showForm(this.modelMap, request);

        // @Then the login grower view name is returned
        assertThat(viewName).isEqualTo("logingrower");
    }

    @Test
    public void testShowFormReturnsLoginFormViewName_WhenShowingTheLoginFormAndPrincipalIsNull() {
        // @Given an authenticated user and a null principal
        HttpServletRequest request = new MockHttpServletRequest();
        Mockito.when(authentication.isAuthenticated()).thenReturn(true);
        Mockito.when(authentication.getPrincipal()).thenReturn(null);

        // @When showing the login form
        String viewName = this.loginController.showForm(this.modelMap, request);

        // @Then the login grower view name is returned
        assertThat(viewName).isEqualTo("logingrower");
    }

    @Test
    public void testShowFormReturnsLoginFormViewName_WhenShowingTheLoginFormAndAlreadyAuthenticated() {
        // @Given an authenticated user with a Person principal
        HttpServletRequest request = new MockHttpServletRequest();
        Mockito.when(authentication.isAuthenticated()).thenReturn(true);
        Person personMock = mock(Person.class);
        Mockito.when(authentication.getPrincipal()).thenReturn(personMock);

        // @When showing the login form
        String viewName = this.loginController.showForm(this.modelMap, request);

        // @Then the home view name is returned
        assertThat(viewName).isEqualTo("home");
    }


    @Test
    public void testShowError_WhenErrorOccurs() {
        // @Given
        MockHttpServletRequest request = new MockHttpServletRequest();

        // @When showing the login form
        String viewName = this.loginController.showError(this.modelMap, request);

        assertThat(this.modelMap.containsAttribute("error"));

        // @Then the login form view name is returned
        assertThat(viewName).isEqualTo("logingrower");
    }

    @Test
    public void testChangePasswordSuccess_WhenSessionNotNull() {

        String viewName = this.loginController.changePasswordSuccess(model, session);
        Mockito.verify(modelMessagesHelper, times(1)).success("login.change_password.success", model);
        assertThat(viewName).isEqualTo("home");
        Mockito.verify(session, Mockito.times(1)).invalidate();
    }


    @Test
    public void testChangePasswordSuccess_WhenSessionNull() {

        String viewName = this.loginController.changePasswordSuccess(model, null);
        assertThat(viewName).isEqualTo("home");
    }

    @Test
    public void testCsrfError() {

        String viewName = this.loginController.csrfError(modelMap);
        assertThat(modelMap.get("csrfError")).isEqualTo(Boolean.TRUE);
        assertThat(viewName).isEqualTo("logingrower");

    }

    @Test
    public void testSessionExpired() {

        String viewName = this.loginController.sessionExpired(modelMap);
        assertThat(modelMap.get("sessionEnded")).isEqualTo(Boolean.TRUE);
        assertThat(viewName).isEqualTo("home");

    }

    @Test
    public void testShowFormSetShowCaptchaToTrueInTheModel_IfFailedAttemptsCountIs3() {
        // @Given a user that is not authenticated
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRemoteAddr("125.125.196.213");
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getPrincipal()).thenReturn("Anonymusito");
        when(this.usersService.findFailedAttemptsCount(request.getRemoteAddr())).thenReturn(3);

        // @When showing the login form
        this.loginController.showForm(this.modelMap, request);

        // @Then showCaptcha is set to true in the grower
        assertThat(this.modelMap).includes(MapAssert.entry("showCaptcha", true));
    }

    @Test
    public void testShowFormSetShowCaptchaToFalseInTheModel_IfFailedAttemptsCountIs2() {
        // @Given a user that is not authenticated
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setRemoteAddr("222.13.123.125");
        when(authentication.isAuthenticated()).thenReturn(true);
        when(authentication.getPrincipal()).thenReturn("Anonymusito");
        when(this.usersService.findFailedAttemptsCount(request.getRemoteAddr())).thenReturn(2);

        // @When showing the login form
        this.loginController.showForm(this.modelMap, request);

        // @Then showCaptcha is set to true in the grower
        assertThat(this.modelMap).includes(MapAssert.entry("showCaptcha", false));
    }

    @Test
    public void testShowRetailerLoginReturnsShowRetailerLoginViewName_WhenShowingTheRetailerLogin(){
        // @Given a login controller

        // @When showing the retailer login
        String viewName = this.loginController.showRetailerLogin();

        // @Then the retailer login view name is returned
        assertThat(viewName).isEqualTo(LoginController.RETAILER_LOGIN_VIEW);
    }


}
