package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.web.forms.ChangePasswordForm;
import com.industrysystem.web.forms.validators.ChangePasswordFormValidator;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;

import java.security.Principal;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 3/15/13
 * Time: 12:46 PM
 */
public class PasswordHandlingController_UT {

    private static final String OLD_PASSWORD = "OLD_PASSWORD";
    private static final String NEW_PASSWORD = "NEW_PASSWORD";
    private static final String UID = "UID";
    private PasswordHandlingController controller;
    private ModelMap model;
    private ChangePasswordFormValidator changePasswordFormValidator;
    private ChangePasswordForm changePasswordForm;

    private WebDataBinder binder;
    private BindingResult bindingResult;
    private UsersService usersService;


    @Before
    public void setUp() {
        this.controller = new PasswordHandlingController();
        field("changePasswordFormValidator").ofType(ChangePasswordFormValidator.class).in(controller).set(changePasswordFormValidator);
        this.usersService = mock(UsersService.class);
        field("usersService").ofType(UsersService.class).in(controller).set(usersService);

        this.model = new ModelMap();
        this.binder = mock(WebDataBinder.class);
        this.changePasswordForm = mock(ChangePasswordForm.class);
        this.bindingResult = mock(BindingResult.class);
    }

    @Test
    public void testInitBinder() {
        controller.initBinder(binder);
        verify(binder, Mockito.times(1)).setValidator(changePasswordFormValidator);
    }

    @Test
    public void testLandingPage() {
        controller.changePassword(model, new Principal() {
			
			public String getName() {
				return "Pepe";
			}
		});
        assertThat(model.get("changePasswordForm")).isInstanceOf(ChangePasswordForm.class);
    }

    @Test
    public void testChangePasswordWithErrorsInForm() {
        when(bindingResult.hasErrors()).thenReturn(true);
        Model model = mock(Model.class);

        String result = controller.changePassword(changePasswordForm, bindingResult, model);

        verifyZeroInteractions(usersService);
        assertThat(result).isEqualTo("changePassword");

    }

    @Test
    public void testChangePasswordCallsUserService() throws Exception {
        when(bindingResult.hasErrors()).thenReturn(false);
        when(changePasswordForm.getOldPassword()).thenReturn(OLD_PASSWORD);
        when(changePasswordForm.getNewPassword()).thenReturn(NEW_PASSWORD);
        when(changePasswordForm.getConfirmNewPassword()).thenReturn(NEW_PASSWORD);
        SecurityContext securityContext = mock(SecurityContext.class);
        SecurityContextHolder.setContext(securityContext);
        Authentication authentication = mock(Authentication.class);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        when(authentication.getName()).thenReturn(UID);
        Model model = mock(Model.class);

        String result = controller.changePassword(changePasswordForm, bindingResult, model);

        verify(usersService, times(1)).changePassword(UID, OLD_PASSWORD, NEW_PASSWORD);
        assertThat(result).isEqualTo("redirect:/spring/changepasswordsuccess.html");

    }


}
