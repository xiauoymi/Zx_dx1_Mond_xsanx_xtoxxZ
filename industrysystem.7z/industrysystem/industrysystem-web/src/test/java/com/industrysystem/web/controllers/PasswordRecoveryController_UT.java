package com.industrysystem.web.controllers;

import java.util.ArrayList;
import java.util.List;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.entities.ChallengeQuestion;
import com.industrysystem.exceptions.DirectorySearchResultsException;
import com.industrysystem.exceptions.InvalidTokenException;
import com.industrysystem.web.forms.RecoverPasswordForm;
import com.industrysystem.web.forms.validators.RecoverPasswordFormValidator;
import com.industrysystem.web.util.ModelMessagesHelper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.ldap.userdetails.InetOrgPerson;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;

import javax.naming.NamingException;

import static com.google.common.collect.Lists.newArrayList;
import static java.util.Collections.emptyList;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 3/15/13
 * Time: 12:46 PM
 */
public class PasswordRecoveryController_UT {

    private static final String WRONG_CHALLENGE_ANSWER = "b";
	private static final String RIGHT_CHALLENGE_ANSWER = "a";
	private static final String EMAIL_ADDRESS = "email@address";
    private static final String PASSWORD= "password";
    private static final String TOKEN = "token";
    private static final String UID = "uid";
    
	private PasswordRecoveryController controller;
    private Model model;
    private RecoverPasswordFormValidator recoverPasswordFormValidator;
    private RecoverPasswordForm recoverPasswordForm;
    private ModelMessagesHelper modelMessagesHelper;
    
    private WebDataBinder binder;
    private BindingResult bindingResult;
    private UsersService usersService;
    
    private InetOrgPerson person;
    
    private MockHttpSession session;
    
    @Before
    public void setUp() {
        controller = new PasswordRecoveryController();
        field("recoverPasswordFormValidator").ofType(RecoverPasswordFormValidator.class).in(controller).set(recoverPasswordFormValidator);
        usersService = mock(UsersService.class);
        field("usersService").ofType(UsersService.class).in(controller).set(usersService);
        modelMessagesHelper = mock(ModelMessagesHelper.class);
        field("modelMessagesHelper").ofType(ModelMessagesHelper.class).in(controller).set(modelMessagesHelper);
        
        person = mock(InetOrgPerson.class);
        when(person.getUid()).thenReturn(UID);
        when(person.getMail()).thenReturn(EMAIL_ADDRESS);
        model = new ExtendedModelMap();
        binder = mock(WebDataBinder.class);
        recoverPasswordForm = mock(RecoverPasswordForm.class);
        bindingResult = mock(BindingResult.class);
        session = new MockHttpSession();
        
        when(usersService.challengeQuestionRespondedOk(RIGHT_CHALLENGE_ANSWER, RIGHT_CHALLENGE_ANSWER)).thenReturn(Boolean.TRUE);
        when(usersService.challengeQuestionRespondedOk(RIGHT_CHALLENGE_ANSWER, WRONG_CHALLENGE_ANSWER)).thenReturn(Boolean.FALSE);
        
        session.setAttribute("NEEDS_CHALLENGE_QUESTION", Boolean.FALSE);
        session.setAttribute("CHALLENGE_QUESTIONS_LIST", emptyList());
    }

    @Test
    public void testInitBinder() {
        controller.initBinder(binder);
        verify(binder).setValidator(recoverPasswordFormValidator);
    }

    @Test
    public void testLandingPage_WhenValidToken() throws InvalidTokenException, DirectorySearchResultsException {
    	when(usersService.obtainPersonForPasswordResetToken(TOKEN)).thenReturn(person);
    	
    	List<ChallengeQuestion> list = newArrayList(createDummyChallengeQuestion("q", RIGHT_CHALLENGE_ANSWER));
		when(usersService.findDoableChallengeQuestions(EMAIL_ADDRESS)).thenReturn(list);
    	session.setAttribute("CHALLENGE_QUESTIONS_LIST", list);
    	
    	String returned = controller.recoverPassword(model, TOKEN, session);
        
        assertThat(model.asMap().get("recoverPasswordForm")).isInstanceOf(RecoverPasswordForm.class);
        assertThat(returned).isEqualTo(PasswordRecoveryController.RECOVERPASSWORDFORM_VIEW);
    }

    private ChallengeQuestion createDummyChallengeQuestion(String question, String answer) {
		ChallengeQuestion challengeQuestion = new ChallengeQuestion();
		challengeQuestion.setQuestion(question);
		challengeQuestion.setAnswer(answer);
		return challengeQuestion;
	}

	@Test
    public void testLandingPage_WhenInvalidToken() throws InvalidTokenException, DirectorySearchResultsException {
    	when(usersService.obtainPersonForPasswordResetToken(TOKEN)).thenThrow(new InvalidTokenException());
    	
    	String returned = controller.recoverPassword(model, TOKEN, session);
        
    	assertThat(returned).isEqualTo("redirect:/spring/recoverpasswordinvalidtoken.html");
    }

    @Test
    public void testLandingPage_WhenEmailAddressHasProblems() throws InvalidTokenException, DirectorySearchResultsException {
    	when(usersService.obtainPersonForPasswordResetToken(TOKEN)).thenThrow(new DirectorySearchResultsException(0));
    	
    	String returned = controller.recoverPassword(model, TOKEN, session);
        
    	assertThat(returned).isEqualTo("redirect:/spring/recoverpasswordmailerror.html");
    }
    
    @Test
    public void testDoChangePassword_WhenSuccessNotNeedingChallengeQuestion() throws InvalidTokenException,
            DirectorySearchResultsException, NamingException {
    	when(bindingResult.hasErrors()).thenReturn(false);
    	
    	when(recoverPasswordForm.getNewPassword()).thenReturn(PASSWORD);
        when(recoverPasswordForm.getToken()).thenReturn(TOKEN);
        when(usersService.obtainPersonForPasswordResetToken(TOKEN)).thenReturn(person);
    	
        String returned = controller.doChangePassword(model, recoverPasswordForm, bindingResult, session);
        
    	verify(usersService).resetPassword(UID, PASSWORD);
    	assertThat(returned).isEqualTo("redirect:/spring/changepasswordsuccess.html");
    }
    
    @Test
    public void testDoChangePassword_WhenSuccessNeedingChallengeQuestion() throws InvalidTokenException,
            DirectorySearchResultsException, NamingException {
    	session.setAttribute("NEEDS_CHALLENGE_QUESTION", Boolean.TRUE);
    	List<ChallengeQuestion> oneChallengeList = new ArrayList<ChallengeQuestion>();
    	oneChallengeList.add(createDummyChallengeQuestion("q", RIGHT_CHALLENGE_ANSWER));
		session.setAttribute("CHALLENGE_QUESTIONS_LIST", oneChallengeList);
    	
		when(recoverPasswordForm.getChallengeAnswer()).thenReturn(RIGHT_CHALLENGE_ANSWER);
    	when(bindingResult.hasErrors()).thenReturn(false);
    	when(recoverPasswordForm.getNewPassword()).thenReturn(PASSWORD);
        when(recoverPasswordForm.getToken()).thenReturn(TOKEN);
        when(usersService.obtainPersonForPasswordResetToken(TOKEN)).thenReturn(person);
    	
        String returned = controller.doChangePassword(model, recoverPasswordForm, bindingResult, session);
        
    	verify(usersService).resetPassword(UID, PASSWORD);
    	assertThat(returned).isEqualTo("redirect:/spring/changepasswordsuccess.html");
    }
    
    @Test
    public void testDoChangePassword_WhenNoSecurityQuestionsLeftOnBadResponse() throws InvalidTokenException,
            DirectorySearchResultsException, NamingException {
    	session.setAttribute("NEEDS_CHALLENGE_QUESTION", Boolean.TRUE);
    	List<ChallengeQuestion> onlyOneChallengeList = new ArrayList<ChallengeQuestion>();
    	onlyOneChallengeList.add(createDummyChallengeQuestion("q", RIGHT_CHALLENGE_ANSWER));
		session.setAttribute("CHALLENGE_QUESTIONS_LIST", onlyOneChallengeList);
    	
		when(recoverPasswordForm.getChallengeAnswer()).thenReturn(WRONG_CHALLENGE_ANSWER);
    	
    	when(bindingResult.hasErrors()).thenReturn(false);    	
    	
    	when(recoverPasswordForm.getNewPassword()).thenReturn(PASSWORD);
        when(recoverPasswordForm.getToken()).thenReturn(TOKEN);
        when(usersService.obtainPersonForPasswordResetToken(TOKEN)).thenReturn(person);

        String returned = controller.doChangePassword(model, recoverPasswordForm, bindingResult, session);
        
    	verify(usersService, never()).resetPassword(anyString(), anyString());
    	assertThat(returned).isEqualTo("nochallengestoanswer");
    }
    
    @Test
    public void testDoChangePassword_WhenInvalidToken() throws InvalidTokenException, DirectorySearchResultsException, NamingException {
        when(recoverPasswordForm.getNewPassword()).thenReturn(PASSWORD);
        when(recoverPasswordForm.getToken()).thenReturn(TOKEN);
    	when(usersService.obtainPersonForPasswordResetToken(TOKEN)).thenThrow(new InvalidTokenException());    	
    	when(bindingResult.hasErrors()).thenReturn(false);    	
    	
    	String returned = controller.doChangePassword(model, recoverPasswordForm, bindingResult, session);
        
    	verify(usersService, never()).resetPassword(anyString(), anyString());
    	assertThat(returned).isEqualTo("redirect:/spring/recoverpasswordinvalidtoken.html");
    }
    
    @Test
    public void testDoChangePassword_WhenProblemWithEmailAddress() throws InvalidTokenException, DirectorySearchResultsException,
            NamingException {
        when(recoverPasswordForm.getNewPassword()).thenReturn(PASSWORD);
        when(recoverPasswordForm.getToken()).thenReturn(TOKEN);
    	when(usersService.obtainPersonForPasswordResetToken(TOKEN)).thenThrow(new DirectorySearchResultsException(0));    	
    	when(bindingResult.hasErrors()).thenReturn(false);    	
    	
    	String returned = controller.doChangePassword(model, recoverPasswordForm, bindingResult, session);
        
    	verify(usersService, never()).resetPassword(anyString(), anyString());
    	assertThat(returned).isEqualTo("redirect:/spring/recoverpasswordmailerror.html");
    }

    @Test
    public void testDoChangePassword_WhenFormHasErrors() throws InvalidTokenException, DirectorySearchResultsException,
            NamingException {
        when(recoverPasswordForm.getNewPassword()).thenReturn(PASSWORD);
        when(recoverPasswordForm.getToken()).thenReturn(TOKEN);
    	when(usersService.obtainPersonForPasswordResetToken(TOKEN)).thenReturn(person);    	
    	when(bindingResult.hasErrors()).thenReturn(true);    	
    	
    	String returned = controller.doChangePassword(model, recoverPasswordForm, bindingResult, session);
        
    	verify(usersService, never()).resetPassword(anyString(), anyString());
    	assertThat(returned).isEqualTo(PasswordRecoveryController.RECOVERPASSWORDFORM_VIEW);
    }
    
    @Test
    public void testDoChangePassword_WhenErrorChangingPassword() throws InvalidTokenException, DirectorySearchResultsException,
            NamingException {
        when(recoverPasswordForm.getNewPassword()).thenReturn(PASSWORD);
        when(recoverPasswordForm.getToken()).thenReturn(TOKEN);
    	when(usersService.obtainPersonForPasswordResetToken(TOKEN)).thenReturn(person);    	
    	when(bindingResult.hasErrors()).thenReturn(false);
    	doThrow(new NamingException()).when(usersService).resetPassword(UID, PASSWORD);
    	
    	String returned = controller.doChangePassword(model, recoverPasswordForm, bindingResult, session);
    	
    	verify(modelMessagesHelper).error("resetpassword.error.unknown", model);
    	assertThat(returned).isEqualTo(PasswordRecoveryController.RECOVERPASSWORDFORM_VIEW);
    }

}