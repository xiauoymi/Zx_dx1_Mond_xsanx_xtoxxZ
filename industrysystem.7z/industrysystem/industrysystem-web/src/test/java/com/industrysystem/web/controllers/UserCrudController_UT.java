package com.industrysystem.web.controllers;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.security.groups.FunctionalSecurityGroup;
import com.industrysystem.security.groups.SecurityGroup;
import com.industrysystem.web.forms.UserForm;
import com.industrysystem.web.util.ModelMessagesHelper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import javax.naming.NamingException;
import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 30/07/13
 * Time: 16:16
 */
public class UserCrudController_UT {
    private UserCrudController userCrudController;
    private UsersService usersService;
    private ModelMessagesHelper messagesHelper;

    @Before
    public void setUp() {
        userCrudController = new UserCrudController();
        usersService = mock(UsersService.class);
        field("usersService").ofType(UsersService.class).in(userCrudController).set(usersService);
        messagesHelper = mock(ModelMessagesHelper.class);
        field("messagesHelper").ofType(ModelMessagesHelper.class).in(userCrudController).set(messagesHelper);
    }

    @Test
    public void testNewUserFormReturnsUserFormView_WhenAccessingTheUserForm() {
        // @Given a model
        Model model = mock(Model.class);

        // @When accesing the new user form
        String viewName = userCrudController.newUserForm(model);

        // @Then the user form view name is returned
        assertThat(viewName).isEqualTo("newUserForm");
    }

    @Test
    public void testNewUserFormAddsUserFormInTheModel_WhenAccessingTheUserForm() {
        // @Given a model and a userForm
        Model model = new ExtendedModelMap();

        // @When accessing the new user form
        userCrudController.newUserForm(model);

        // @Then a UserForm is returned in the model
        assertThat(model.asMap().get("userForm")).isNotNull();
        assertThat(model.asMap().get("userForm")).isInstanceOf(UserForm.class);
    }

    @Test
    public void testNewUserFormCallsUserServiceFindAllGroups_WhenAccessingTheUserForm() {
        // @Given a model
        Model model = new ExtendedModelMap();

        // @When accessing the new user form
        userCrudController.newUserForm(model);

        // @Then userService.findAllRoleNames is called
        verify(usersService).findAllRoleNames();
    }

    @Test
    public void testNewUserFormReturnsFindAllGroupsResultInTheModel_WhenAccessingTheUserForm() {
        // @Given a model
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("aGroup", "anotherGroup"));

        // @When accessing the new user form
        userCrudController.newUserForm(model);

        // @Then findAllRoleNames results are returned in the model
        assertThat(model.asMap().get("groups")).isNotNull();
        assertThat(model.asMap().get("groups")).isInstanceOf(List.class);
        assertThat((List) model.asMap().get("groups")).isEqualTo(usersService.findAllRoleNames());
    }

    @Test
    public void testNewUserFormReturnsRoleMapWithOneEntry_WhenAccessingTheUserFormAndOneGroupIsFound() {
        // @Given a model
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("role"));
        when(usersService.findAllGroups()).thenReturn(newArrayList((SecurityGroup)new FunctionalSecurityGroup("role", "aGroup")));

        // @When accessing the new user form
        userCrudController.newUserForm(model);

        // @Then findAllRoleNames results are returned in the model
        assertThat(model.asMap().get("userForm")).isNotNull();
        UserForm userForm = (UserForm) model.asMap().get("userForm");
        assertThat(userForm.getRolesByGroupMap()).isNotNull();
        assertThat(userForm.getRolesByGroupMap().get("aGroup")).isNotNull();
        assertThat(userForm.getRolesByGroupMap().get("aGroup").get("role")).isEqualTo(Boolean.FALSE);
    }

    @Test
    public void testNewUserFormReturnsRoleMapWithOneEntryWithTwoChildren_WhenAccessingTheUserFormAndOneGroupWithTwoRolesIsFound() {
        // @Given a model
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("role", "otherRole"));
        when(usersService.findAllGroups()).thenReturn(newArrayList((SecurityGroup)new FunctionalSecurityGroup("role", "aGroup"),
                (SecurityGroup)new FunctionalSecurityGroup("otherRole", "aGroup")));

        // @When accessing the new user form
        userCrudController.newUserForm(model);

        // @Then findAllRoleNames results are returned in the model
        assertThat(model.asMap().get("userForm")).isNotNull();
        UserForm userForm = (UserForm) model.asMap().get("userForm");
        assertThat(userForm.getRolesByGroupMap()).isNotNull();
        assertThat(userForm.getRolesByGroupMap().get("aGroup")).isNotNull();
        assertThat(userForm.getRolesByGroupMap().get("aGroup").get("role")).isEqualTo(Boolean.FALSE);
        assertThat(userForm.getRolesByGroupMap().get("aGroup").get("otherRole")).isEqualTo(Boolean.FALSE);
    }

    @Test
    public void testNewUserFormReturnsRoleMapWithTwoEntries_WhenAccessingTheUserFormAndTwoGroupsWithDifferentRolesAreFound() {
        // @Given a model
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("role", "otherRole"));
        when(usersService.findAllGroups()).thenReturn(newArrayList((SecurityGroup)new FunctionalSecurityGroup("role", "aGroup"),
                (SecurityGroup)new FunctionalSecurityGroup("otherRole", "otherGroup")));

        // @When accessing the new user form
        userCrudController.newUserForm(model);

        // @Then findAllRoleNames results are returned in the model
        assertThat(model.asMap().get("userForm")).isNotNull();
        UserForm userForm = (UserForm) model.asMap().get("userForm");
        assertThat(userForm.getRolesByGroupMap()).isNotNull();
        assertThat(userForm.getRolesByGroupMap().get("aGroup")).isNotNull();
        assertThat(userForm.getRolesByGroupMap().get("aGroup").get("role")).isEqualTo(Boolean.FALSE);
        assertThat(userForm.getRolesByGroupMap().get("otherGroup").get("otherRole")).isEqualTo(Boolean.FALSE);
    }

    @Test
    public void testNewUserFormReturnsNewUserFormViewName_WhenPostingAUserForm() {
        // @Given a user form
        UserForm userForm = new UserForm();
        Model model = new ExtendedModelMap();
        BindingResult result = mock(BindingResult.class);

        // @When posting the user form
        String viewName = userCrudController.newUserForm(userForm, result, model);

        // @Then the new user form view name is returned
        assertThat(viewName).isEqualTo("newUserForm");
    }

    @Test
    public void testNewUserFormCallsUserServiceCreateUserWithUidJohn_WhenPostingAUserFormWithUidJohn() throws Exception {
        // @Given a user form with uid john
        UserForm userForm = new UserForm();
        userForm.setUserName("John");
        Model model = new ExtendedModelMap();
        BindingResult result = mock(BindingResult.class);

        // @When posting the user form
        userCrudController.newUserForm(userForm, result, model);

        // @Then create user is called with uid John
        verify(usersService).createUser(eq("John"), anyString(), anyList(), anyString(), anyString());
    }

    @Test
    public void testNewUserFormCallsUserServiceCreateUserWithUidTony_WhenPostingAUserFormWithUidTony() throws Exception {
        // @Given a user form with uid Tony
        UserForm userForm = new UserForm();
        userForm.setUserName("Tony");
        Model model = new ExtendedModelMap();
        BindingResult result = mock(BindingResult.class);

        // @When posting the user form
        userCrudController.newUserForm(userForm, result, model);

        // @Then create user is called with uid Tony
        verify(usersService).createUser(eq("Tony"), anyString(), anyList(), anyString(), anyString());
    }

    @Test
    public void testNewUserFormCallsUserServiceCreateUserWithPasswordSecret_WhenPostingAUserFormWithPasswordSecret() throws Exception {
        // @Given a user form with password secret
        UserForm userForm = new UserForm();
        userForm.setNewPassword("Secret");
        Model model = new ExtendedModelMap();
        BindingResult result = mock(BindingResult.class);


        // @When posting the user form
        userCrudController.newUserForm(userForm, result, model);

        // @Then create user is called with password secret
        verify(usersService).createUser(anyString(), eq("Secret"), anyList(), anyString(), anyString());
    }

    @Test
    public void testNewUserFormCallsUserServiceCreateUserWithPasswordMistery_WhenPostingAUserFormWithPasswordMistery() throws Exception {
        // @Given a user form with password secret
        UserForm userForm = new UserForm();
        userForm.setNewPassword("Mistery");
        Model model = new ExtendedModelMap();
        BindingResult result = mock(BindingResult.class);

        // @When posting the user form
        userCrudController.newUserForm(userForm, result, model);

        // @Then create user is called with password mistery
        verify(usersService).createUser(anyString(), eq("Mistery"), anyList(), anyString(), anyString());
    }

    @Test
    public void testNewUserFormCallsUserServiceCreateUserWithOneGroupSAJohn_WhenPostingAUserFormWithOneAssignedGroupSAJohn()
            throws Exception {
        // @Given a user form that return one assignedGroup role SA group john
        UserForm userForm = mock(UserForm.class);
        Model model = new ExtendedModelMap();
        FunctionalSecurityGroup securityGroup = new FunctionalSecurityGroup("SA", "John");
        ArrayList<FunctionalSecurityGroup> securityGroups = newArrayList(securityGroup);
        when(userForm.getAssignedGroups()).thenReturn(securityGroups);
        BindingResult result = mock(BindingResult.class);

        // @When posting the user form
        userCrudController.newUserForm(userForm, result, model);

        // @Then create user is called with one group SA John
        verify(usersService).createUser(anyString(), anyString(), eq(securityGroups), anyString(), anyString());
    }

    @Test
    public void testNewUserFormCallsModelMessageHelperErrorWithInputModelAndErrorCreatingUserMessage_WhenCreateUserThrowsNamingException()
            throws Exception {
        // @Given that create user throws a naming exception
        UserForm userForm = mock(UserForm.class);
        Model model = new ExtendedModelMap();
        doThrow(new NamingException()).when(usersService).createUser(anyString(), anyString(), anyList(), anyString(), anyString());
        BindingResult result = mock(BindingResult.class);

        // @When posting a user form
        userCrudController.newUserForm(userForm, result, model);

        // @Then modelMessageHelper.error is called with error creating user message and input model
        verify(messagesHelper).error(userCrudController.ERROR_CREATING_USER, model);
    }

    @Test
    public void testNewUserFormCallsUserServiceFindAllGroups_WhenAccessingTheUserFormAndBindingResultHasErrors() {
        // @Given a model
        UserForm form = mock(UserForm.class);
        BindingResult result = mock(BindingResult.class);
        when(result.hasErrors()).thenReturn(true);
        Model model = new ExtendedModelMap();

        // @When accessing the new user form
        userCrudController.newUserForm(form, result, model);

        // @Then userService.findAllRoleNames is called
        verify(usersService).findAllRoleNames();
    }

    @Test
    public void testNewUserFormReturnsFindAllGroupsResultInTheModel_WhenAccessingTheUserFormAndBindingResultHasErrors() {
        // @Given a model
        UserForm form = mock(UserForm.class);
        BindingResult result = mock(BindingResult.class);
        when(result.hasErrors()).thenReturn(true);
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("aGroup", "anotherGroup"));

        // @When accessing the new user form
        userCrudController.newUserForm(form, result, model);

        // @Then findAllRoleNames results are returned in the model
        assertThat(model.asMap().get("groups")).isNotNull();
        assertThat(model.asMap().get("groups")).isInstanceOf(List.class);
        assertThat((List) model.asMap().get("groups")).isEqualTo(usersService.findAllRoleNames());
    }

    @Test
    public void testNewUserFormReturnsRoleMapWithOneEntry_WhenAccessingTheUserFormAndOneGroupIsFoundAndBindingResultHasErrors() {
        // @Given a model
        UserForm form = new UserForm();
        BindingResult result = mock(BindingResult.class);
        when(result.hasErrors()).thenReturn(true);
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("role"));
        when(usersService.findAllGroups()).thenReturn(newArrayList((SecurityGroup)new FunctionalSecurityGroup("role", "aGroup")));

        // @When accessing the new user form
        userCrudController.newUserForm(form, result, model);

        // @Then findAllRoleNames results are returned in the model
        assertThat(form.getRolesByGroupMap()).isNotNull();
        assertThat(form.getRolesByGroupMap().get("aGroup")).isNotNull();
        assertThat(form.getRolesByGroupMap().get("aGroup").get("role")).isEqualTo(Boolean.FALSE);
    }

    @Test
    public void testNewUserFormReturnsRoleMapWithOneEntryWithTwoChildren_WhenAccessingTheUserFormAndOneGroupWithTwoRolesIsFoundAndBindingResultHasErrors() {
        // @Given a model
        UserForm form = new UserForm();
        BindingResult result = mock(BindingResult.class);
        when(result.hasErrors()).thenReturn(true);
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("role", "otherRole"));
        when(usersService.findAllGroups()).thenReturn(newArrayList((SecurityGroup)new FunctionalSecurityGroup("role", "aGroup"),
                (SecurityGroup)new FunctionalSecurityGroup("otherRole", "aGroup")));

        // @When accessing the new user form
        userCrudController.newUserForm(form, result, model);

        // @Then findAllRoleNames results are returned in the model
        assertThat(form.getRolesByGroupMap()).isNotNull();
        assertThat(form.getRolesByGroupMap().get("aGroup")).isNotNull();
        assertThat(form.getRolesByGroupMap().get("aGroup").get("role")).isEqualTo(Boolean.FALSE);
        assertThat(form.getRolesByGroupMap().get("aGroup").get("otherRole")).isEqualTo(Boolean.FALSE);
    }

    @Test
    public void testNewUserFormReturnsRoleMapWithTwoEntries_WhenAccessingTheUserFormAndTwoGroupsWithDifferentRolesAreFoundAndBindingResultHasErrors() {
        // @Given a model
        UserForm form = new UserForm();
        BindingResult result = mock(BindingResult.class);
        when(result.hasErrors()).thenReturn(true);
        Model model = new ExtendedModelMap();
        when(usersService.findAllRoleNames()).thenReturn(newArrayList("role", "otherRole"));
        when(usersService.findAllGroups()).thenReturn(newArrayList((SecurityGroup)new FunctionalSecurityGroup("role", "aGroup"),
                (SecurityGroup)new FunctionalSecurityGroup("otherRole", "otherGroup")));

        // @When accessing the new user form
        userCrudController.newUserForm(form, result, model);

        // @Then findAllRoleNames results are returned in the model
        assertThat(form.getRolesByGroupMap()).isNotNull();
        assertThat(form.getRolesByGroupMap().get("aGroup")).isNotNull();
        assertThat(form.getRolesByGroupMap().get("aGroup").get("role")).isEqualTo(Boolean.FALSE);
        assertThat(form.getRolesByGroupMap().get("otherGroup").get("otherRole")).isEqualTo(Boolean.FALSE);
    }

}