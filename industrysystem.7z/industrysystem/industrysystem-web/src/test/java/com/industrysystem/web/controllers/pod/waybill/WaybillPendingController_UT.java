package com.industrysystem.web.controllers.pod.waybill;

import com.industrysystem.business.WaybillService;
import com.industrysystem.business.dtos.LoadDetailDTO;
import com.industrysystem.business.dtos.TruckDetailDTO;
import com.industrysystem.business.users.UsersService;
import com.industrysystem.entities.*;
import com.industrysystem.exceptions.BusinessException;
import com.industrysystem.exceptions.PodNotFoundException;
import com.industrysystem.web.dtos.pod.waybill.WaybillPendingDTO;
import org.dozer.DozerBeanMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static com.google.common.collect.Lists.newArrayList;
import static org.fest.assertions.Assertions.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * User: LSCHW1
 */
@RunWith(MockitoJUnitRunner.class)
public class WaybillPendingController_UT {

    @Mock
    private WaybillService waybillService;

    @Mock
    private UsersService usersService;

    @Mock
    private DozerBeanMapper dozerMapper;

    @InjectMocks
    private WaybillPendingController waybillPendingController;

    @Test
    public void getPendingWaybills_ShouldReturnOneWaybill_WhenUserHasOnePendingWaybills() throws BusinessException {
        Waybill waybill = new WaybillBuilderForCoreTests().build();
        when(usersService.findPendingWaybillsFromCurrentUser()).thenReturn(newArrayList(waybill));
        when(waybillService.getHolderName(waybill)).thenReturn("HOLDER NAME");
        when(dozerMapper.map(waybill, WaybillPendingDTO.class)).thenReturn(createWaybillPendingDTO());

        List<WaybillPendingDTO> result=waybillPendingController.getPendingWaybills();

        assertThat(result).hasSize(1);
        WaybillPendingDTO waybillPendingDTO=result.get(0);
        assertThat(waybillPendingDTO.getWaybillNumber()).isEqualTo(waybill.getWaybillNumber().toString());

        TruckLoadDetail truckLoadDetail= (TruckLoadDetail) waybill.getLoadDetails().iterator().next();
        TruckDetailDTO truckDetailDTO=(TruckDetailDTO) waybillPendingDTO.getLoadDetail().get(0);
        assertThat(truckLoadDetail.getCtg()).isEqualTo(truckDetailDTO.getCtg());
        assertThat(truckLoadDetail.getIdentifier()).isEqualTo(truckDetailDTO.getLoadIdentifier());
        assertThat(truckLoadDetail.getWeight()).isEqualTo(truckDetailDTO.getWeight());
        assertThat(truckLoadDetail.getSampleCode()).isEqualTo(truckDetailDTO.getSampleCode());
        assertThat(truckLoadDetail.getDeclarations().iterator().next().getCropTechnology().getTechnology().getCode()).isEqualTo(truckDetailDTO.getDeclaredTechnology());
    }

    @Test
    public void getPendingWaybills_ShouldThrowPodNotFoundException_WhenUserHasNoPendingWaybills() throws PodNotFoundException {
        doThrow(PodNotFoundException.class).when(usersService).findPendingWaybillsFromCurrentUser();

        try {
            waybillPendingController.getPendingWaybills();

            fail();
        } catch (PodNotFoundException e) {
            assertThat(true);
        }
    }

    @Test
    public void storeWeightAndSampleInfo_ShouldCallStoreWeightAndSampleInfoFromService() throws BusinessException {
        WaybillPendingDTO waybillPendingDTO = createWaybillPendingDTO();

        waybillPendingController.storeWeightAndSampleInfo(waybillPendingDTO);

        verify(waybillService).storeWeightAndSampleInfo(WaybillBuilder.WAYBILL_NUMBER, waybillPendingDTO.getQuantitativeLabCode(),
                waybillPendingDTO.getQuantitativeLabCode(), waybillPendingDTO.getLoadDetail());
    }

    private WaybillPendingDTO createWaybillPendingDTO() {
        WaybillPendingDTO waybillPendingDTO = new WaybillPendingDTO();
        waybillPendingDTO.setWaybillNumber(WaybillBuilder.WAYBILL_NUMBER.toString());
        waybillPendingDTO.setQuantitativeLabCode("labCode");

        List<LoadDetailDTO> loadDetailDTOs = newArrayList();
        TruckDetailDTO truckDetailDTO = new TruckDetailDTO(WaybillBuilder.CTG);
        truckDetailDTO.setSampleCode(WaybillBuilder.SAMPLE_CODE);
        truckDetailDTO.setDeclaredTechnology(WaybillBuilder.DECLARED_TECHNOLOGY_CODE);
        truckDetailDTO.setWeight(WaybillBuilder.WEIGHT);

        loadDetailDTOs.add(truckDetailDTO);
        waybillPendingDTO.setLoadDetail(loadDetailDTOs);
        return waybillPendingDTO;
    }

}