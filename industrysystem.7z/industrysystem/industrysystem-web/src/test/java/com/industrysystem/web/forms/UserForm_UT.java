package com.industrysystem.web.forms;

import com.industrysystem.security.groups.FunctionalSecurityGroup;
import org.junit.Test;

import java.util.List;
import java.util.Map;

import static com.google.common.collect.Maps.newHashMap;
import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 * Date: 02/07/13
 * Time: 13:55
 */
public class UserForm_UT {
    @Test
    public void testGetAssignedGroupsReturnsEmptyList_WhenGettingAssignedGroupsAndThereAreNoCuitRows() {
        // @Given an empty map
        UserForm userForm = new UserForm();

        // @When getting the assigned groups
        List<FunctionalSecurityGroup> assignedGroups = userForm.getAssignedGroups();

        // @Then an empty list is returned
        assertThat(assignedGroups).isEmpty();
    }

    @Test
    public void testGetAssignedGroupsReturnsOneGroupNameJohnInRoleServiceAccount_WhenGettingAssignedGroupsAndThereIsOneCuitRowJohnWithOneEntryServiceAccountTrue() {
        // @Given an empty map
        UserForm userForm = new UserForm();
        Map<String, Boolean> map = newHashMap();
        map.put("ServiceAccount", Boolean.TRUE);
        userForm.getRolesByGroupMap().put("John", map);

        // @When getting the assigned groups
        List<FunctionalSecurityGroup> assignedGroups = userForm.getAssignedGroups();

        // @Then ServiceAccount->John group is returned
        assertThat(assignedGroups).onProperty("roleName").containsOnly("ServiceAccount");
        assertThat(assignedGroups).onProperty("groupName").containsOnly("John");
    }

    @Test
    public void testGetAssignedGroupsReturnsOneGroupNameTonyInRoleGrower_WhenGettingAssignedGroupsAndThereIsOneCuitRowTonyWithOneEntryGrowerTrue() {
        // @Given an empty map
        UserForm userForm = new UserForm();
        Map<String, Boolean> map = newHashMap();
        map.put("Grower", Boolean.TRUE);
        userForm.getRolesByGroupMap().put("Tony", map);

        // @When getting the assigned groups
        List<FunctionalSecurityGroup> assignedGroups = userForm.getAssignedGroups();

        // @Then ServiceAccount->John group is returned
        assertThat(assignedGroups).onProperty("roleName").containsOnly("Grower");
        assertThat(assignedGroups).onProperty("groupName").containsOnly("Tony");
    }

    @Test
    public void testGetAssignedGroupsReturnsEmptyList_WhenGettingAssignedGroupsAndThereIsOneCuitRowJohnWithOneEntryServiceAccountFalse() {
        // @Given an empty map
        UserForm userForm = new UserForm();
        Map<String, Boolean> map = newHashMap();
        map.put("ServiceAccount", Boolean.FALSE);
        userForm.getRolesByGroupMap().put("John", map);

        // @When getting the assigned groups
        List<FunctionalSecurityGroup> assignedGroups = userForm.getAssignedGroups();

        // @Then an empty list is returned
        assertThat(assignedGroups).isEmpty();
    }

}