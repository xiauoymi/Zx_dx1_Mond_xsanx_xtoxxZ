package com.industrysystem.web.forms.validators;

import com.industrysystem.web.forms.NewAndConfirmNewPasswordForm;
import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.Errors;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 21/08/13
 * Time: 14:59
 */
public class NewAndConfirmNewPasswordFormValidator_UT {
       private NewAndConfirmNewPasswordFormValidator validator;

    @Before
    public void setUp() {
        this.validator = new NewAndConfirmNewPasswordFormValidator() {
            @Override
            protected void validateSpecific(NewAndConfirmNewPasswordForm target, Errors errors) {
            }

            public boolean supports(Class<?> clazz) {
                return true;
            }
        };
    }

    @Test
    public void testValidatePasswordStrengthAppendsErrorIfRequiredStrengthIs2AndPasswordIsA() {
        // @Given password A
        String password = "A";
        Errors errors = mock(Errors.class);
        field("requiredStrength").ofType(Integer.class).in(this.validator).set(2);

        // @When validating password strength
        this.validator.validatePasswordStrength(password, errors);

        // @Then an error is appended
        verify(errors).rejectValue("newPassword", "changePassword.error.password-strength", "Password is not strong enough");
    }

    @Test
    public void testValidatePasswordStrengthDoesNotAppendErrorIfRequiredStrengthIs2AndPasswordIsABCDEFG() {
        // @Given password A
        String password = "ABCDEFG";
        Errors errors = mock(Errors.class);
        field("requiredStrength").ofType(Integer.class).in(this.validator).set(2);

        // @When validating password strength
        this.validator.validatePasswordStrength(password, errors);

        // @Then an error is appended
        verify(errors, never()).rejectValue("newPassword", "changePassword.error.password-strength", "Password is not strong enough");
    }

    @Test
    public void testValidatePasswordStrengthDoesNotAppendAnError_WhenRequiredStrengthIs6AndPasswordIsABCDEFG$abcdefg1() {
        // @Given password A
        String password = "ABCDEFG$abcdefg1";
        Errors errors = mock(Errors.class);
        field("requiredStrength").ofType(Integer.class).in(this.validator).set(6);

        // @When validating password strength
        this.validator.validatePasswordStrength(password, errors);

        // @Then an error is appended
        verify(errors, never()).rejectValue("newPassword", "changePassword.error.password-strength", "Password is not strong enough");
    }
}
