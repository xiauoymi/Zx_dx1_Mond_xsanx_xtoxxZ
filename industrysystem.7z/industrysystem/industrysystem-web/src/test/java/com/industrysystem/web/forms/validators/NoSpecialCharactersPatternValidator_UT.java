package com.industrysystem.web.forms.validators;

import org.junit.Test;

public class NoSpecialCharactersPatternValidator_UT {

    @Test
    public void testInitialize() {
        new NoSpecialCharactersPatternValidator().initialize(null);
    }

}