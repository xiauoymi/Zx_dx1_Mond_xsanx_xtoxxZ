package com.industrysystem.web.interceptors;

import com.industrysystem.web.security.interceptors.NoChallengesQuestionsWarningInterceptor;
import com.industrysystem.web.util.ModelMessagesHelper;
import com.industrysystem.web.util.ServletHelper;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.Map;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

public class NoChallengesQuestionsWarningInterceptor_UT {

	private final String CONTEXT_URL = "http://example.com/context";
	
	private NoChallengesQuestionsWarningInterceptor interceptor;
	
	private MockHttpServletRequest httpServletRequest;
	private MockHttpServletResponse httpServletResponse;
	private Object handler;
	private ModelAndView modelAndView;
	private HttpSession session;
    private Map<String, Object> modelAsMap;
	private ModelMessagesHelper modelMessagesHelper;
	
	
	@SuppressWarnings("unchecked")
	@Before
	public void setup()
	{
		interceptor = new NoChallengesQuestionsWarningInterceptor();
        ServletHelper servletHelper = mock(ServletHelper.class);
		field("servletHelper").ofType(ServletHelper.class).in(interceptor).set(servletHelper);
		modelMessagesHelper = mock(ModelMessagesHelper.class);
		field("modelMessagesHelper").ofType(ModelMessagesHelper.class).in(interceptor).set(modelMessagesHelper);
		
		httpServletRequest = new MockHttpServletRequest();
		session = mock(HttpSession.class);
		httpServletRequest.setSession(session);
		modelAndView = mock(ModelAndView.class);
		modelAsMap = mock(Map.class);
		when(modelAndView.getModel()).thenReturn(modelAsMap);
		
		when(servletHelper.getRequestURL(httpServletRequest)).thenReturn(new StringBuffer(CONTEXT_URL));
	}
	
	@Test
	public void testPostHandle_WhenShowWarning() throws Exception
	{
		when(session.getAttribute(NoChallengesQuestionsWarningInterceptor.WARN_NO_CHALLENGE_QUESTIONS)).thenReturn(Boolean.TRUE);
		
		interceptor.postHandle(httpServletRequest, httpServletResponse, handler, modelAndView);
		
		verify(modelMessagesHelper).warning("challenge_question.warning.none_present", modelAsMap, CONTEXT_URL + "/spring/secured/challenge/change.html");
	}
	
	@Test
	public void testPostHandle_WhenDontShowWarning() throws Exception
	{
		when(session.getAttribute(NoChallengesQuestionsWarningInterceptor.WARN_NO_CHALLENGE_QUESTIONS)).thenReturn(null);
		
		interceptor.postHandle(httpServletRequest, httpServletResponse, handler, modelAndView);
		
		verify(modelMessagesHelper, never()).warning(anyString(), any(Map.class), anyString());
	}

	
	
}
