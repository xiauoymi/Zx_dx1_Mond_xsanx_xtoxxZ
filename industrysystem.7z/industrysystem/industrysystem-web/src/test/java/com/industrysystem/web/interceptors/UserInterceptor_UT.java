package com.industrysystem.web.interceptors;


import com.industrysystem.web.security.interceptors.UserInterceptor;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.Principal;

import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;
public class UserInterceptor_UT {

	private UserInterceptor userInterceptor;
	private HttpServletRequest httpServletRequest;
	private HttpServletResponse httpServletResponse;
	private Object handler;
	private ModelAndView modelAndView;
	private SecurityContext securityContext;
	private Authentication authentication;
	private Principal principal;
	
	@Before
	public void setup()
	{
		userInterceptor = new UserInterceptor();
		modelAndView = mock(ModelAndView.class);
		securityContext = mock(SecurityContext.class);
		principal = mock(Principal.class);
		authentication = mock(Authentication.class);
		when(authentication.getPrincipal()).thenReturn(principal);
		SecurityContextHolder.setContext(securityContext);
	}
	
	@Test
	public void testPostHandle_WhenNoAuthenticatedUser() throws Exception
	{
		when(securityContext.getAuthentication()).thenReturn(null);
		userInterceptor.postHandle(httpServletRequest, httpServletResponse, handler, modelAndView);
		verify(modelAndView, never()).addObject(anyString(), anyObject());
	}
	
	@Test
	public void testPostHandle_WhenAuthenticatedUser() throws Exception
	{
		when(securityContext.getAuthentication()).thenReturn(authentication);
		userInterceptor.postHandle(httpServletRequest, httpServletResponse, handler, modelAndView);
		verify(modelAndView, times(1)).addObject("user", principal);
	}
	
	
}
