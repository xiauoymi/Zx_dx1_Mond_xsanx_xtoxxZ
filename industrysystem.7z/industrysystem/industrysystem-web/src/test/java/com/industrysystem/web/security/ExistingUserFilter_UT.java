package com.industrysystem.web.security;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.web.security.filters.ExistingUserFilter;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InOrder;
import org.springframework.context.MessageSource;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.BadCredentialsException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Locale;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 6/6/13
 * Time: 3:29 PM
 */
public class ExistingUserFilter_UT {
    private ExistingUserFilter filter;
    private UsersService usersService;
	private MessageSource messages;

    @Before
    public void setUp() {
        this.filter = new ExistingUserFilter();
        this.usersService = mock(UsersService.class);
        this.messages = mock(MessageSource.class);
        field("messages").ofType(MessageSource.class).in(this.filter).set(this.messages);
        field("usersService").ofType(UsersService.class).in(this.filter).set(this.usersService);
    }

    @Test
    public void testDoFilterCallsUserServiceIsLdapUserWithUser1_WhenFilteringRequestWithUser1() throws IOException, ServletException {
        // @Given a request with username "user1"
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        ServletResponse response = new MockHttpServletResponse();
        request.setParameter("j_username", "user1");

        // @When filtering request
        this.filter.doFilter(request, response, chain);

        // @Then user service is called to check whether the user exists
        verify(this.usersService).isExistentUser("user1");
    }

    @Test
    public void testDoFilterCallsUserServiceIsLdapUserWithUser46_WhenFilteringRequestWithUser1() throws IOException, ServletException {
        // @Given a request with username "user46"
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        ServletResponse response = new MockHttpServletResponse();
        request.setParameter("j_username", "user46");

        // @When filtering request
        this.filter.doFilter(request, response, chain);

        // @Then user service is called to check whether the user exists
        verify(this.usersService).isExistentUser("user46");
    }

    @Test
    public void testDoFilterSetsErrorExceptionAndRedirectsToLoginError_WhenUserDoesNotExist() throws IOException, ServletException {
        // @Given a request to login with an unexisting user
        MockHttpServletRequest request = new MockHttpServletRequest();
        HttpSession session = mock(HttpSession.class);
        request.setSession(session);
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        request.setParameter("j_username", "unexistingUser");
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(false);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then response sendRedirect is called to loginError
        InOrder inOrder = inOrder(request.getSession(), response, messages);
        inOrder.verify(this.messages).getMessage(eq("LdapAuthenticationProvider.badCredentials"), eq(new Object[0]), isA(Locale.class));
        inOrder.verify(session).setAttribute(eq("SPRING_SECURITY_LAST_EXCEPTION"), isA(BadCredentialsException.class));
        inOrder.verify(response).sendRedirect("/spring/autherror.html");
    }

    @Test
    public void testDoFilterDoesNotCallSendRedirectToLoginError_WhenUserExistsAndHasRequiredCaptchas() throws IOException, ServletException {
        // @Given a request to login with an existing user
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        request.setParameter("j_username", "existingUser");
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);
        when(this.usersService.hasRequiredCaptchasForAuthentication(anyString(), anyString(), anyString())).thenReturn(true);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then response sendRedirect is never called
        verify(response, never()).sendRedirect(anyString());
    }

    @Test
    public void testDoFilterCallsUserServiceHasRequiredCaptchasWithAddress20_WhenExecutingFilterWithUserJohnInTheRequestAndUserExists() throws IOException, ServletException {
        // @Given an existing user and a request with address 20
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        request.setRemoteAddr("20");
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then usersService.hasRequiredCaptchasForAuthentication is called with the address of the input
        verify(this.usersService).hasRequiredCaptchasForAuthentication(eq("20"), anyString(), anyString());
    }

    @Test
    public void testDoFilterCallsUserServiceHasRequiredCaptchasWithAddress87_WhenExecutingFilterWithUserJohnInTheRequestAndUserExists() throws IOException, ServletException {
        // @Given an existing user and a request with address 87
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        request.setRemoteAddr("87");
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then usersService.hasRequiredCaptchasForAuthentication is called with the address of the input
        verify(this.usersService).hasRequiredCaptchasForAuthentication(eq("87"), anyString(), anyString());
    }

    @Test
    public void testDoFilterCallsUserServiceHasRequiredCaptchasWithChallengeFieldHi_WhenExecutingFilterWithChallengeFieldHiInTheRequestAndUserExists() throws IOException, ServletException {
        // @Given an existing user and a request with challenge field hi
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        request.setParameter("recaptcha_challenge_field", "Hi");
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then usersService.hasRequiredCaptchasForAuthentication is called with the challenge field in the input
        verify(this.usersService).hasRequiredCaptchasForAuthentication(anyString(), eq("Hi"), anyString());
    }

    @Test
    public void testDoFilterCallsUserServiceHasRequiredCaptchasWithChallengeFieldHello_WhenExecutingFilterWithChallengeFieldHiInTheRequestAndUserExists() throws IOException, ServletException {
        // @Given an existing user and a request with challenge field hello
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        request.setParameter("recaptcha_challenge_field", "Hello");
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then usersService.hasRequiredCaptchasForAuthentication is called with the challenge field in the input
        verify(this.usersService).hasRequiredCaptchasForAuthentication(anyString(), eq("Hello"), anyString());
    }

    @Test
    public void testDoFilterCallsUserServiceHasRequiredCaptchasWithResponseFieldHi_WhenExecutingFilterWithChallengeFieldHiInTheRequestAndUserExists() throws IOException, ServletException {
        // @Given an existing user and a request with response field hi
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        request.setParameter("recaptcha_response_field", "Hi");
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then usersService.hasRequiredCaptchasForAuthentication is called with the response field in the input
        verify(this.usersService).hasRequiredCaptchasForAuthentication(anyString(), anyString(), eq("Hi"));
    }

    @Test
    public void testDoFilterCallsUserServiceHasRequiredCaptchasWithResponseFieldHello_WhenExecutingFilterWithChallengeFieldHiInTheRequestAndUserExists() throws IOException, ServletException {
        // @Given an existing user and a request with response field hello
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        request.setParameter("recaptcha_response_field", "Hello");
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then usersService.hasRequiredCaptchasForAuthentication is called with the response field in the input
        verify(this.usersService).hasRequiredCaptchasForAuthentication(anyString(), anyString(), eq("Hello"));
    }

    @Test
    public void testDoFilterSetsErrorMessageAndRedirectsToErrorPage_WhenRequestHasNotTheRequiredCaptchas() throws IOException, ServletException {
        // @Given an existing user and a request without the required captchas
        MockHttpServletRequest request = new MockHttpServletRequest();
        HttpSession session = mock(HttpSession.class);
        request.setSession(session);
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);
        when(this.usersService.hasRequiredCaptchasForAuthentication(anyString(), anyString(), anyString())).thenReturn(false);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then an error message is returned and the request is redirected to the auth error page
        InOrder inOrder = inOrder(request.getSession(), response, messages);
        inOrder.verify(this.messages).getMessage(eq("LdapAuthenticationProvider.badCredentials"), eq(new Object[0]), isA(Locale.class));
        inOrder.verify(session).setAttribute(eq("SPRING_SECURITY_LAST_EXCEPTION"), isA(BadCredentialsException.class));
        inOrder.verify(response).sendRedirect("/spring/autherror.html");
    }

    @Test
    public void testDoFilterRedirectsToErrorPage_WhenRequestHasNotTheRequiredCaptchas() throws IOException, ServletException {
        // @Given an existing user and a request without the required captchas
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);
        when(this.usersService.hasRequiredCaptchasForAuthentication(anyString(), anyString(), anyString())).thenReturn(false);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then request is redirected to the auth error page
        verify(response).sendRedirect("/spring/autherror.html");
    }

    @Test
    public void testDoFilterCallsChainDoFilter_WhenFilteringTheRequestWhenIsExistentUserAndHasRequiredCaptchas() throws IOException, ServletException {
        // @Given a request with and existent user and required captcha
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);
        when(this.usersService.hasRequiredCaptchasForAuthentication(anyString(), anyString(), anyString())).thenReturn(true);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then chain.doFilter is called
        verify(chain).doFilter(request, response);
    }

    @Test
    public void testDoFilterCallsChainDoFilter_WhenFilteringTheRequestWhenIsNotAnExistentUser() throws IOException, ServletException {
        // @Given a request with a non existent user
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(false);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then chain.doFilter is called
        verify(chain).doFilter(request, response);
    }

    @Test
    public void testDoFilterCallsChainDoFilter_WhenFilteringTheRequestOfAnExistentUserThatDoesNotHaveTheRequiredCaptchas() throws IOException, ServletException {
        // @Given a request with an existent user and without required captcha
        MockHttpServletRequest request = new MockHttpServletRequest();
        FilterChain chain = mock(FilterChain.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        when(this.usersService.isExistentUser(request.getParameter("j_username"))).thenReturn(true);
        when(this.usersService.hasRequiredCaptchasForAuthentication(anyString(), anyString(), anyString())).thenReturn(false);

        // @When filtering the request
        this.filter.doFilter(request, response, chain);

        // @Then chain.doFilter is not called
        verify(chain, never()).doFilter(request, response);
    }
}
