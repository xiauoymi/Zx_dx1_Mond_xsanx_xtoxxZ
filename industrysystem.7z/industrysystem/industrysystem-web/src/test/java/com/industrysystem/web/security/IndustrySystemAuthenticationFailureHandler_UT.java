package com.industrysystem.web.security;

import com.industrysystem.business.users.UsersService;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.AuthenticationException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

/**
 * User: PPERA
 * Date: 5/31/13
 * Time: 2:47 PM
 */
public class IndustrySystemAuthenticationFailureHandler_UT {
    private IndustrySystemAuthenticationFailureHandler industrySystemAuthenticationFailureHandler;
    private UsersService usersService;
    private MockHttpServletRequest request;
    private HttpServletResponse response;
    private AuthenticationException authenticationException;

    @Before
    public void setUp() {
        this.industrySystemAuthenticationFailureHandler = new IndustrySystemAuthenticationFailureHandler();
        this.usersService = mock(UsersService.class);
        field("usersService").ofType(UsersService.class).in(this.industrySystemAuthenticationFailureHandler).set(this.usersService);
        this.request = new MockHttpServletRequest();
        this.response = new MockHttpServletResponse();
        this.authenticationException = mock(AuthenticationException.class);
    }

    @Test
    public void testOnAuthenticationFailureCallsFailedAttemptsDaoIncrementFailedAttemptForUser1_WhenAuthenticationFailedForExistentUser1() throws IOException, ServletException {
        // @Given a request to log in with an existent user
        this.request.setParameter("j_username", "user1");

        // @When the authentication fails
        this.industrySystemAuthenticationFailureHandler.onAuthenticationFailure(this.request, this.response, this.authenticationException);

        // @Then failedAttemptsCountDao.incrementFailedAttempt is called
        verify(this.usersService).incrementFailedAttempt(anyString());
    }

    @Test
    public void testOnAuthenticationFailureCallsFailedAttemptsDaoIncrementFailedAttemptForUser24_WhenAuthenticationFailedForExistentUser24() throws IOException, ServletException {
        // @Given a request to log in with an existent user
        this.request.setParameter("j_username", "user24");

        // @When the authentication fails
        this.industrySystemAuthenticationFailureHandler.onAuthenticationFailure(this.request, this.response, this.authenticationException);

        // @Then failedAttemptsCountDao.incrementFailedAttempt is called
        verify(this.usersService).incrementFailedAttempt(anyString());
    }

    @Test
    public void testOnAuthenticationFailureCallsFailedAttemptsDaoIncrementFailedAttemptForRemoteAddressLocalhost_WhenAuthenticationFailedForExistentUserAndRequestWithRemoteAddressLocalhost() throws IOException, ServletException {
        // @Given a request to log in with an existent user
        this.request.setParameter("j_username", "user24");
        this.request.setRemoteAddr("Localhost");

        // @When the authentication fails
        this.industrySystemAuthenticationFailureHandler.onAuthenticationFailure(this.request, this.response, this.authenticationException);

        // @Then failedAttemptsCountDao.incrementFailedAttempt is called with the origin of the request (remote address) and the username
        verify(this.usersService).incrementFailedAttempt(eq(request.getRemoteAddr()));
    }

    @Test
    public void testOnAuthenticationFailureCallsFailedAttemptsDaoIncrementFailedAttemptForRemoteAddressOtherhost_WhenAuthenticationFailedForExistentUserAndRequestWithRemoteAddressOtherhost() throws IOException, ServletException {
        // @Given a request to log in with an existent user
        this.request.setParameter("j_username", "user24");
        this.request.setRemoteAddr("Otherhost");

        // @When the authentication fails
        this.industrySystemAuthenticationFailureHandler.onAuthenticationFailure(this.request, this.response, this.authenticationException);

        // @Then failedAttemptsCountDao.incrementFailedAttempt is called with the origin of the request (remote address) and the username
        verify(this.usersService).incrementFailedAttempt(eq(request.getRemoteAddr()));
    }
}
