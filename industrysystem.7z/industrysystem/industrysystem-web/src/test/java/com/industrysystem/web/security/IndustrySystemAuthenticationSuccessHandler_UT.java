package com.industrysystem.web.security;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.entities.ChallengeQuestion;
import com.industrysystem.web.security.interceptors.NoChallengesQuestionsWarningInterceptor;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.ldap.userdetails.InetOrgPerson;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;

import static com.google.common.collect.Lists.newArrayList;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 29/07/13
 * Time: 10:52
 */
public class IndustrySystemAuthenticationSuccessHandler_UT {

	private static final String EMAIL = "email@address";
	private IndustrySystemAuthenticationSuccessHandler handler;
    private UsersService usersService;
    private Authentication authentication;
    private MockHttpServletRequest request;
    
    @Before
    public void setUp(){
        usersService = mock(UsersService.class);
        handler = new IndustrySystemAuthenticationSuccessHandler();
        authentication = mock(Authentication.class);
        InetOrgPerson user = mock(InetOrgPerson.class);
        field("usersService").ofType(UsersService.class).in(handler).set(usersService);
        when(authentication.getPrincipal()).thenReturn(user);
        when(user.getMail()).thenReturn(EMAIL);
        request = new MockHttpServletRequest();
    }

    @Test
    public void testOnAuthenticationSuccessCallsUsersServiceCleanFailedAuthenticationAttemptsCountWithAddress20_WhenAuthenticationWasASuccess()
            throws IOException, ServletException {
        // @Given a remote address in the request
        
        request.setRemoteAddr("20");
        HttpServletResponse response = new MockHttpServletResponse();
        
        // @When authenticating successfully
        handler.onAuthenticationSuccess(request, response, authentication);

        // @Then clean count is called for remote address
        verify(usersService).cleanFailedAuthenticationAttemptsCount(request.getRemoteAddr());
    }
    
    @Test
    public void testOnAuthenticationSuccessCallsResetChallengeAttempts() throws IOException, ServletException {
        request.setRemoteAddr("20");
        HttpServletResponse response = new MockHttpServletResponse();
         

        handler.onAuthenticationSuccess(request, response, authentication);

        verify(usersService).resetRemainingChallengeQuestionsAttempts(EMAIL);
    }
    
    @Test
    public void testOnExistingChallengeQuestionsNoSetChallengeQuestionsWarningInSession() throws IOException, ServletException {
        request.setRemoteAddr("20");
        HttpServletResponse response = new MockHttpServletResponse();
        
        HttpSession session = mock(HttpSession.class);
		request.setSession(session);
        when(usersService.findChallengeQuestions(EMAIL)).thenReturn(newArrayList(new ChallengeQuestion()));
        
        handler.onAuthenticationSuccess(request, response, authentication);

        verify(session, never()).setAttribute(eq(NoChallengesQuestionsWarningInterceptor.WARN_NO_CHALLENGE_QUESTIONS), anyObject());
    }
    
    @Test
    public void testOnNotExistingChallengeQuestionsSetChallengeQuestionsWarningInSession() throws IOException, ServletException {
        request.setRemoteAddr("20");
        HttpServletResponse response = new MockHttpServletResponse();
        
        HttpSession session = mock(HttpSession.class);
		request.setSession(session);
		when(usersService.findChallengeQuestions(EMAIL)).thenReturn(new ArrayList<ChallengeQuestion>());
        
        handler.onAuthenticationSuccess(request, response, authentication);

        verify(session).setAttribute(NoChallengesQuestionsWarningInterceptor.WARN_NO_CHALLENGE_QUESTIONS, Boolean.TRUE);
    }

    @Test
    public void testOnAuthenticationSuccessCallsUsersServiceCleanFailedAuthenticationAttemptsCountWithAddress151_WhenAuthenticationWasASuccess()
            throws IOException, ServletException {
        // @Given a remote address in the request
        request.setRemoteAddr("151");
        HttpServletResponse response = new MockHttpServletResponse();
        
        // @When authenticating successfully
        handler.onAuthenticationSuccess(request, response, authentication);

        // @Then clean count is called for remote address
        verify(usersService).cleanFailedAuthenticationAttemptsCount(request.getRemoteAddr());
    }

}