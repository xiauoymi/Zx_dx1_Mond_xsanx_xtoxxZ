package com.industrysystem.web.security.filters;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import javax.servlet.*;
import javax.servlet.http.HttpServletResponse;

import static com.industrysystem.web.security.filters.FrameOptionsFilter.Mode;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class FrameOptionsFilter_UT {

    @Mock private FilterConfig filterConfig;
    private FrameOptionsFilter filter;

    @Before
    public void setUp() {
        filter = new FrameOptionsFilter();
    }

    @Test
    public void testModeFromValueReturnsNullWhenValueIsInvalid() {
        Mode mode = Mode.fromValue("abc");

        assertNull(mode);
    }

    @Test
    public void testModeFromValueReturnsMode() {
        Mode mode = Mode.fromValue("deny");

        assertEquals(Mode.DENY, mode);
    }

    @Test
    public void testInitUsesDefault() throws Exception {
        filter.init(filterConfig);

        assertEquals("SAMEORIGIN", filter.getFrameOptionsValue());
    }

    @Test
    public void testInitUsesConfiguredModeAndUrl() throws Exception {
        when(filterConfig.getInitParameter("mode")).thenReturn("allow-from");
        when(filterConfig.getInitParameter("allowFromUrl")).thenReturn("http://www.abc.com");

        filter.init(filterConfig);

        assertEquals("ALLOW-FROM http://www.abc.com", filter.getFrameOptionsValue());
    }

    @Test(expected=ServletException.class)
    public void testInitThrowsServletExceptionWhenModeIsInvalid() throws Exception {
        when(filterConfig.getInitParameter("mode")).thenReturn("abc");

        filter.init(filterConfig);
    }

    @Test
    public void testDoFilterAddsHeaderAndContinuesChain() throws Exception {
        when(filterConfig.getInitParameter("mode")).thenReturn("deny");
        ServletRequest request = mock(ServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        FilterChain chain = mock(FilterChain.class);

        filter.init(filterConfig);
        filter.doFilter(request, response, chain);

        verify(response).addHeader("X-Frame-Options", "DENY");
        verify(chain).doFilter(request, response);
    }

    @Test
    public void testDestroy() {
        filter.destroy();
    }

}