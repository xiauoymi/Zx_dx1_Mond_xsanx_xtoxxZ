package com.industrysystem.web.security.filters;

import org.junit.Test;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.mockito.Mockito.*;

/**
 * User: PPERA
 * Date: 22/10/13
 * Time: 09:08
 */
public class MDCFilter_UT {
    @Test
    public void testDoFilterCallsChainDoFilterWithInputRequestAndResponse_WhenExecuttingTheFilter() throws IOException, ServletException {
        // @Given a chain, a request and a response
        MDCFilter mdcFilter = new MDCFilter();
        HttpServletRequest request = mock(HttpServletRequest.class);
        HttpServletResponse response = mock(HttpServletResponse.class);
        FilterChain chain = mock(FilterChain.class);
        when(request.getRemoteAddr()).thenReturn("127");

        // @When executing filter
        mdcFilter.doFilter(request, response, chain);

        // @Then chain.doFilter is called with input request and response
        verify(chain).doFilter(request, response);
    }
}
