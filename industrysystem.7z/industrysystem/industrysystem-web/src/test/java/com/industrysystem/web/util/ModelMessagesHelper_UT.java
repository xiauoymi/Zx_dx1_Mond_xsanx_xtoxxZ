package com.industrysystem.web.util;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.InOrder;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.ui.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class ModelMessagesHelper_UT {
	
	private static final String SUCCESS_MESSAGES = "successMessages";
    private static final String INFO_MESSAGES = "infoMessages";
    private static final String WARNING_MESSAGES = "warningMessages";
    private static final String ERROR_MESSAGES = "errorMessages";
    
	
    private static final String RESOLVED_MESSAGE = "Resolved Message";
	private static final String MESSAGE_CODE = "message.code";
	private static final String UNRESOLVABLE_MESSAGE_CODE = "unresolvable.message.code";
	private static final String[] ARGUMENTS = new String[]{"an argument", "another argument"};
	private ModelMessagesHelper helper;
	private Map<String, Object> modelAsMap;
	private List<String> messagesForKey;
	private Model model;
	private MessageSource messageSource;
	private static Locale locale = Locale.TAIWAN;
	
	@BeforeClass
	public static void setupLocale()
	{
		LocaleContextHolder.setLocale(locale);
	}
	
	@SuppressWarnings("unchecked")
	@Before
	public void setup()
	{
		helper = new ModelMessagesHelper();
		messageSource = mock(MessageSource.class);
		field("messageSource").ofType(MessageSource.class).in(helper).set(messageSource);
		model = mock(Model.class);
		modelAsMap = mock(Map.class);
		when(model.asMap()).thenReturn(modelAsMap);
		messagesForKey = mock(List.class);
		when(modelAsMap.get(any(String.class))).thenReturn(messagesForKey);
		when(messageSource.getMessage(MESSAGE_CODE, ARGUMENTS, locale)).thenReturn(RESOLVED_MESSAGE);
		when(messageSource.getMessage(UNRESOLVABLE_MESSAGE_CODE, ARGUMENTS, locale)).thenThrow(new NoSuchMessageException(UNRESOLVABLE_MESSAGE_CODE));
		
	}
	
	@Test
	public void testErrorKeyIsCreated()
	{
		prepareKeyCreatedCall(ERROR_MESSAGES);
		helper.error(MESSAGE_CODE, model, ARGUMENTS);
		verifyKeyCreatedOrder(ERROR_MESSAGES);
	}

	
	@Test
	public void testInfoKeyIsCreated()
	{
		prepareKeyCreatedCall(INFO_MESSAGES);
		helper.info(MESSAGE_CODE, model, ARGUMENTS);
		verifyKeyCreatedOrder(INFO_MESSAGES);
	}
	
	@Test
	public void testWarningKeyIsCreated()
	{
		prepareKeyCreatedCall(WARNING_MESSAGES);
		helper.warning(MESSAGE_CODE, model, ARGUMENTS);
		verifyKeyCreatedOrder(WARNING_MESSAGES);
	}
	
	@Test
	public void testWarningKeyIsCreatedUsingMap()
	{
		prepareKeyCreatedCall(WARNING_MESSAGES);
		helper.warning(MESSAGE_CODE, modelAsMap, ARGUMENTS);
		verifyKeyCreatedOrderUsingMap(WARNING_MESSAGES);
	}
	
	@Test
	public void testSuccessKeyIsCreated()
	{
		prepareKeyCreatedCall(SUCCESS_MESSAGES);
		helper.success(MESSAGE_CODE, model, ARGUMENTS);
		verifyKeyCreatedOrder(SUCCESS_MESSAGES);
	}
	
	private void prepareKeyCreatedCall(String key) {
		when(modelAsMap.containsKey(key)).thenReturn(false);
		when(modelAsMap.get(key)).thenReturn(messagesForKey);
	}
	private void verifyKeyCreatedOrder(String key) {
		
		InOrder inOrder = inOrder(modelAsMap, model, messagesForKey, messageSource);
		inOrder.verify(model).asMap();
		inOrder.verify(modelAsMap).containsKey(key);
		inOrder.verify(modelAsMap).put(eq(key), eq(new ArrayList<String>()));
		inOrder.verify(modelAsMap).get(key);
		inOrder.verify(messageSource).getMessage(MESSAGE_CODE, ARGUMENTS, locale);
		inOrder.verify(messagesForKey).add(RESOLVED_MESSAGE);
	}
	
	private void verifyKeyCreatedOrderUsingMap(String key) {
		
		InOrder inOrder = inOrder(modelAsMap, messagesForKey, messageSource);
		inOrder.verify(modelAsMap).containsKey(key);
		inOrder.verify(modelAsMap).put(eq(key), eq(new ArrayList<String>()));
		inOrder.verify(modelAsMap).get(key);
		inOrder.verify(messageSource).getMessage(MESSAGE_CODE, ARGUMENTS, locale);
		inOrder.verify(messagesForKey).add(RESOLVED_MESSAGE);
	}

	
	@Test
	public void testErrorKeyExistedButErrorCodeDoesntExist()
	{
		InOrder inOrder = inOrder(modelAsMap, messagesForKey, messageSource);
		when(modelAsMap.containsKey(ERROR_MESSAGES)).thenReturn(true);
		when(modelAsMap.get(ERROR_MESSAGES)).thenReturn(messagesForKey);
		
		helper.error(MESSAGE_CODE, model , ARGUMENTS);
		
		inOrder.verify(modelAsMap).containsKey(ERROR_MESSAGES);
		inOrder.verify(modelAsMap).get(ERROR_MESSAGES);
		inOrder.verify(messageSource).getMessage(MESSAGE_CODE, ARGUMENTS, locale);
		inOrder.verify(messagesForKey).add(RESOLVED_MESSAGE);
		
		verify(model, never()).addAttribute(eq(ERROR_MESSAGES), eq(new ArrayList<String>()));
		
	}
	
	@Test
	public void testErrorKeyExisted()
	{
		InOrder inOrder = inOrder(modelAsMap, messagesForKey, messageSource);
		when(modelAsMap.containsKey(ERROR_MESSAGES)).thenReturn(true);
		when(modelAsMap.get(ERROR_MESSAGES)).thenReturn(messagesForKey);
		
		helper.error(UNRESOLVABLE_MESSAGE_CODE, model , ARGUMENTS);
		
		inOrder.verify(modelAsMap).containsKey(ERROR_MESSAGES);
		inOrder.verify(modelAsMap).get(ERROR_MESSAGES);
		inOrder.verify(messageSource).getMessage(UNRESOLVABLE_MESSAGE_CODE, ARGUMENTS, locale);
		inOrder.verify(messagesForKey).add("${" + UNRESOLVABLE_MESSAGE_CODE+ "}");
		
		verify(model, never()).addAttribute(eq(ERROR_MESSAGES), eq(new ArrayList<String>()));
	}
}
