package com.industrysystem.web.validators;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.web.forms.ChangePasswordForm;
import com.industrysystem.web.forms.validators.ChangePasswordFormValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class ChangePasswordFormValidator_UT {

    private static final String VALID_NEW_PASSWORD = "VALID_NEW_PASSWORD";
    private static final String INVALID_OLD_PASSWORD = "INVALID_OLD_PASSWORD";
    private static final String VALID_OLD_PASSWORD = "VALID_OLD_PASSWORD";
    private static final String USERNAME = "USERNAME";
    private static final String INVALID_PASSWORD_CONFIRMATION = "INVALID_PASSWORD_CONFIRMATION";
    private ChangePasswordFormValidator validator;
    private ChangePasswordForm form;
    private UsersService usersService;
    private Errors errors;

    @Before
    public void setup() {
        validator = new ChangePasswordFormValidator();

        form = mock(ChangePasswordForm.class);
        errors = new BeanPropertyBindingResult(form, "form");

        usersService = mock(UsersService.class);
        when(usersService.isPasswordValid(USERNAME, VALID_OLD_PASSWORD)).thenReturn(true);
        when(usersService.isPasswordValid(USERNAME, INVALID_OLD_PASSWORD)).thenReturn(false);
        field("usersService").ofType(UsersService.class).in(validator).set(usersService);

        SecurityContext securityContext = mock(SecurityContext.class);
        SecurityContextHolder.setContext(securityContext);
        Authentication authentication = mock(Authentication.class);
        when(authentication.getName()).thenReturn(USERNAME);
        when(form.getUserName()).thenReturn(USERNAME);
        when(securityContext.getAuthentication()).thenReturn(authentication);
        field("requiredStrength").ofType(Integer.class).in(this.validator).set(0);

    }

    @Test
    public void testSupportedClass() {
        assertThat(validator.supports(ChangePasswordForm.class)).isTrue();
    }

    @Test
    public void testUnsupportedClass() {
        assertThat(validator.supports(String.class)).isFalse();
    }

    @Test
    public void testValidForm() {
        when(form.getOldPassword()).thenReturn(VALID_OLD_PASSWORD);
        when(form.getNewPassword()).thenReturn(VALID_NEW_PASSWORD);
        when(form.getConfirmNewPassword()).thenReturn(VALID_NEW_PASSWORD);
        validator.validate(form, errors);
        assertThat(errors.getErrorCount()).isEqualTo(0);
    }


    @Test
    public void testBlankPasswords() {
        when(usersService.isPasswordValid(USERNAME, "")).thenReturn(true);
        when(form.getOldPassword()).thenReturn("");
        when(form.getNewPassword()).thenReturn("");
        when(form.getConfirmNewPassword()).thenReturn("");
        validator.validate(form, errors);
        assertThat(errors.getFieldError("oldPassword")).isNotNull();
        assertThat(errors.getFieldError("newPassword")).isNotNull();
        assertThat(errors.getFieldError("confirmNewPassword")).isNotNull();
        assertThat(errors.getErrorCount()).isEqualTo(3);
    }

    @Test
    public void testInvalidCurrentPassword() {
        when(form.getOldPassword()).thenReturn(INVALID_OLD_PASSWORD);
        when(form.getNewPassword()).thenReturn(VALID_NEW_PASSWORD);
        when(form.getConfirmNewPassword()).thenReturn(VALID_NEW_PASSWORD);
        validator.validate(form, errors);
        assertThat(errors.getFieldError("oldPassword")).isNotNull();
        assertThat(errors.getErrorCount()).isEqualTo(1);
    }

    @Test
    public void testMismatchNewPassword() {
        when(form.getOldPassword()).thenReturn(VALID_OLD_PASSWORD);
        when(form.getNewPassword()).thenReturn(VALID_NEW_PASSWORD);
        when(form.getConfirmNewPassword()).thenReturn(INVALID_PASSWORD_CONFIRMATION);
        validator.validate(form, errors);
        assertThat(errors.getFieldError("confirmNewPassword")).isNotNull();
        assertThat(errors.getErrorCount()).isEqualTo(1);
    }

    @Test
    public void testPasswordIncludesUserName() {
        when(form.getOldPassword()).thenReturn(VALID_OLD_PASSWORD);
        String newPassword = "hola" + USERNAME + "hola";
        when(form.getNewPassword()).thenReturn(newPassword);
        when(form.getConfirmNewPassword()).thenReturn(newPassword);
        validator.validate(form, errors);
        assertThat(errors.getFieldError("newPassword")).isNotNull();
        assertThat(errors.getErrorCount()).isEqualTo(1);
    }

    @Test
    public void testUserNameIncludesPassword() {
        when(form.getOldPassword()).thenReturn(VALID_OLD_PASSWORD);
        String newPassword = USERNAME.substring(1, 3);
        when(form.getNewPassword()).thenReturn(newPassword);
        when(form.getConfirmNewPassword()).thenReturn(newPassword);
        validator.validate(form, errors);
        assertThat(errors.getFieldError("newPassword")).isNotNull();
        assertThat(errors.getErrorCount()).isEqualTo(1);
    }

}
