package com.industrysystem.web.validators;

import com.industrysystem.business.users.UsersService;
import com.industrysystem.exceptions.DirectorySearchResultsException;
import com.industrysystem.web.forms.ForgotPasswordForm;
import com.industrysystem.web.forms.validators.ForgotPasswordFormValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.ldap.userdetails.InetOrgPerson;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;


public class ForgotPasswordFormValidator_UT {

    private static final String VALID_EMAIL_ADDRESS = "valid_email_address@valid.com";
    private ForgotPasswordFormValidator validator;
    private ForgotPasswordForm form;
    private UsersService usersService;
    private Errors errors;
    private MockHttpServletRequest request;

    @Before
    public void setup() throws DirectorySearchResultsException {
        validator = new ForgotPasswordFormValidator();

        form = new ForgotPasswordForm();
        errors = new BeanPropertyBindingResult(form, "form");

        usersService = mock(UsersService.class);
        field("usersService").ofType(UsersService.class).in(validator).set(usersService);

        InetOrgPerson person = mock(InetOrgPerson.class);
        when(usersService.findPersonWithEmailAddress(VALID_EMAIL_ADDRESS)).thenReturn(person);
        ThreadLocal<ServletRequestAttributes> threadLocal = mock(ThreadLocal.class);
        request = new MockHttpServletRequest();
        ServletRequestAttributes servletRequestAttributes = new ServletRequestAttributes(request);
        when(threadLocal.get()).thenReturn(servletRequestAttributes);
        RequestContextHolder.setRequestAttributes(servletRequestAttributes);
        request.setRemoteAddr("");
        when(this.usersService.hasRequiredCaptchasForRecoverPassword(anyString(), anyString(), anyString())).thenReturn(true);
    }

    @Test
    public void testSupportedClass() {
        assertThat(validator.supports(ForgotPasswordForm.class)).isTrue();
    }

    @Test
    public void testUnsupportedClass() {
        assertThat(validator.supports(String.class)).isFalse();
    }

    @Test
    public void testBlankEmailAddress() {
        form.setEmailAddress(null);
        validator.validate(form, errors);
        assertThat(errors.getAllErrors().size()).isEqualTo(1);
        assertThat(errors.getAllErrors().iterator().next().getCode()).isEqualTo("forgotPassword.error.emailAddress.empty");
    }

    @Test
    public void testMalformedEmailAddress() {
        form.setEmailAddress("not_an_email_address");
        validator.validate(form, errors);
        assertThat(errors.getAllErrors().size()).isEqualTo(1);
        assertThat(errors.getAllErrors().iterator().next().getCode()).isEqualTo("forgot_password.error.malformedAddress");
    }

    @Test
    public void testValidAndNotNotFoundEmailAddress() throws DirectorySearchResultsException {
        form.setEmailAddress(VALID_EMAIL_ADDRESS);
        when(usersService.findPersonWithEmailAddress(VALID_EMAIL_ADDRESS)).thenThrow(new DirectorySearchResultsException(0));

        validator.validate(form, errors);

        assertThat(errors.getAllErrors().size()).isEqualTo(1);
        assertThat(errors.getAllErrors().iterator().next().getCode()).isEqualTo("forgot_password.error.inexistingAddress");
    }

    @Test
    public void testValidAndTooManyMatchesEmailAddress() throws DirectorySearchResultsException {
        form.setEmailAddress(VALID_EMAIL_ADDRESS);
        when(usersService.findPersonWithEmailAddress(VALID_EMAIL_ADDRESS)).thenThrow(new DirectorySearchResultsException(50));

        validator.validate(form, errors);

        assertThat(errors.getAllErrors()).hasSize(1);
        assertThat(errors.getAllErrors()).onProperty("code").contains("forgot_password.error.tooManyPeopleForAddress");
    }

    @Test
    public void testValidAndEmailAddressFound() throws DirectorySearchResultsException {
        form.setEmailAddress(VALID_EMAIL_ADDRESS);
        InetOrgPerson person = mock(InetOrgPerson.class);
        when(usersService.findPersonWithEmailAddress(VALID_EMAIL_ADDRESS)).thenReturn(person);

        validator.validate(form, errors);

        assertThat(errors.getAllErrors()).isEmpty();
    }


    @Test
    public void testValidateChecksCaptchaWithRemoteAddress123123123123_WhenValidatingARecoveryPasswordFormFromAddress123123123123() throws DirectorySearchResultsException {
        // @Given a form and a request context with the address 123.123.123.123
        String remoteAddr = "123.123.123.123";
        request.setRemoteAddr(remoteAddr);

        // @When sending the mail
        this.validator.validate(form, errors);

        // @Then hasRequiredCaptchasForRecoverPassword is called for the given address
        verify(this.usersService).hasRequiredCaptchasForRecoverPassword(eq(remoteAddr), anyString(), anyString());
    }

    @Test
    public void testValidateChecksCaptchaWithRemoteAddress456456456456_WhenValidatingARecoveryPasswordFormFromAddress456456456456() throws DirectorySearchResultsException {
        // @Given a form and a request context with the address 456.456.456.456
        String remoteAddr = "456.456.456.456";
        request.setRemoteAddr(remoteAddr);

        // @When sending the mail
        this.validator.validate(form, errors);

        // @Then hasRequiredCaptchasForRecoverPassword is called for the given address
        verify(this.usersService).hasRequiredCaptchasForRecoverPassword(eq(remoteAddr), anyString(), anyString());
    }

    @Test
    public void testValidateChecksCaptchaWithChallengeField123_WhenValidatingARecoveryPasswordFormWithChallengeField123() throws DirectorySearchResultsException {
        // @Given a form and a request context with the challenge field 123
        String remoteAddr = "456.456.456.456";
        request.setRemoteAddr(remoteAddr);
        String recaptchaChallengeField = "123";
        form.setRecaptcha_challenge_field(recaptchaChallengeField);

        // @When sending the mail
        this.validator.validate(form, errors);

        // @Then hasRequiredCaptchasForRecoverPassword is called for the given challenge field
        verify(this.usersService).hasRequiredCaptchasForRecoverPassword(anyString(), eq(recaptchaChallengeField), anyString());
    }

    @Test
    public void testValidateChecksCaptchaWithChallengeField789_WhenValidatingARecoveryPasswordFormWithChallengeField789() throws DirectorySearchResultsException {
        // @Given a form and a request context with the challenge field 789
        String remoteAddr = "456.456.456.456";
        request.setRemoteAddr(remoteAddr);
        String recaptchaChallengeField = "789";
        form.setRecaptcha_challenge_field(recaptchaChallengeField);

        // @When sending the mail
        this.validator.validate(form, errors);

        // @Then hasRequiredCaptchasForRecoverPassword is called for the given challenge field
        verify(this.usersService).hasRequiredCaptchasForRecoverPassword(anyString(), eq(recaptchaChallengeField), anyString());
    }

    @Test
    public void testValidateChecksCaptchaWithResponseFieldASD_WhenValidatingARecoveryPasswordFormWithResponseFieldASD() throws DirectorySearchResultsException {
        // @Given a form and a request context with the response field ASD
        String remoteAddr = "456.456.456.456";
        request.setRemoteAddr(remoteAddr);
        String recaptchaChallengeField = "789";
        form.setRecaptcha_challenge_field(recaptchaChallengeField);
        String responseField = "ASD";
        form.setRecaptcha_response_field(responseField);

        // @When sending the mail
        this.validator.validate(form, errors);

        // @Then hasRequiredCaptchasForRecoverPassword is called for the given challenge response
        verify(this.usersService).hasRequiredCaptchasForRecoverPassword(anyString(), anyString(), eq(responseField));
    }

    @Test
    public void testValidateChecksCaptchaWithResponseFieldZXC_WhenValidatingARecoveryPasswordFormWithResponseFieldZXC() throws DirectorySearchResultsException {
        // @Given a form and a request context with the response field ZXC
        String remoteAddr = "456.456.456.456";
        request.setRemoteAddr(remoteAddr);
        String recaptchaChallengeField = "789";
        form.setRecaptcha_challenge_field(recaptchaChallengeField);
        String responseField = "ZXC";
        form.setRecaptcha_response_field(responseField);

        // @When sending the mail
        this.validator.validate(form, errors);

        // @Then hasRequiredCaptchasForRecoverPassword is called for the given challenge response
        verify(this.usersService).hasRequiredCaptchasForRecoverPassword(anyString(), anyString(), eq(responseField));
    }

    @Test
    public void testValidateReturnsAnErrorWhenRequiredCaptchaIsMissing_WhenValidatingARecoveryPasswordFormWithoutTheRequiredCaptcha() throws DirectorySearchResultsException {
        // @Given a request to send a password recovery mail that does not have the required captchas
        String remoteAddr = "456.456.456.456";
        request.setRemoteAddr(remoteAddr);
        String recaptchaChallengeField = "789";
        form.setRecaptcha_challenge_field(recaptchaChallengeField);
        String responseField = "ZXC";
        form.setRecaptcha_response_field(responseField);
        form.setEmailAddress(VALID_EMAIL_ADDRESS);
        when(this.usersService.hasRequiredCaptchasForRecoverPassword(anyString(), anyString(), anyString())).thenReturn(false);

        // @When sending the mail
        this.validator.validate(form, errors);

        // @Then an error is returned for the response field
        assertThat(errors.getAllErrors()).hasSize(1);
        assertThat(errors.getFieldError("recaptcha_response_field")).isNotNull();
        assertThat(errors.getFieldError("recaptcha_response_field").getCode()).isEqualTo("forgot_password.error.invalid-captcha");
    }

    @Test
    public void testValidateReturnsNoErrorWhenRequiredCaptchaIsPresent_WhenValidatingARecoveryPasswordFormWithTheRequiredCaptchaAndValidEmail() throws DirectorySearchResultsException {
        // @Given a request to send a password recovery mail that has the required captchas
        String remoteAddr = "456.456.456.456";
        request.setRemoteAddr(remoteAddr);
        String recaptchaChallengeField = "789";
        form.setRecaptcha_challenge_field(recaptchaChallengeField);
        String responseField = "ZXC";
        form.setRecaptcha_response_field(responseField);
        form.setEmailAddress(VALID_EMAIL_ADDRESS);
        when(this.usersService.hasRequiredCaptchasForRecoverPassword(anyString(), anyString(), anyString())).thenReturn(true);

        // @When sending the mail
        this.validator.validate(form, errors);

        // @Then no error is returned
        assertThat(errors.getAllErrors()).hasSize(0);
        assertThat(errors.getFieldError("recaptchaResponseField")).isNull();
    }

    @Test
    public void testValidateDoesNotCallUserServiceFindUserByEmailWhenRequiredCaptchaIsNotPresent_WhenValidatingARecoveryPasswordFormWithoutTheRequiredCaptcha() throws DirectorySearchResultsException {
        // @Given a request to send a password recovery mail that does not have the required captchas
        String remoteAddr = "456.456.456.456";
        request.setRemoteAddr(remoteAddr);
        String recaptchaChallengeField = "789";
        form.setRecaptcha_challenge_field(recaptchaChallengeField);
        String responseField = "ZXC";
        form.setRecaptcha_response_field(responseField);
        form.setEmailAddress(VALID_EMAIL_ADDRESS);
        when(this.usersService.hasRequiredCaptchasForRecoverPassword(anyString(), anyString(), anyString())).thenReturn(false);

        // @When sending the mail
        this.validator.validate(form, errors);

        // @Then the existing mail verification is not needed
        verify(this.usersService, never()).findPersonWithEmailAddress(anyString());
    }
}
