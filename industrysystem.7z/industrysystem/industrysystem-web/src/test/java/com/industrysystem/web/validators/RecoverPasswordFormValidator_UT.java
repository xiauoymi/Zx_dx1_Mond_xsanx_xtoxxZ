package com.industrysystem.web.validators;

import com.industrysystem.web.forms.RecoverPasswordForm;
import com.industrysystem.web.forms.validators.RecoverPasswordFormValidator;
import org.junit.Before;
import org.junit.Test;

import static org.fest.assertions.Assertions.assertThat;

public class RecoverPasswordFormValidator_UT {

	private RecoverPasswordFormValidator validator;
		
	@Before
	public void setup()
	{
		validator = new RecoverPasswordFormValidator();
	}

	@Test
	public void testSupportedClass()
	{
		assertThat(validator.supports(RecoverPasswordForm.class)).isTrue();
	}
	
	@Test
	public void testUnsupportedClass()
	{
		assertThat(validator.supports(String.class)).isFalse();
	}

		
}
