package com.industrysystem.web.validators;

import com.industrysystem.web.forms.ChangePasswordForm;
import com.industrysystem.web.forms.UserForm;
import com.industrysystem.web.forms.validators.UserFormValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import java.util.HashMap;
import java.util.Map;

import static com.google.common.collect.Maps.newHashMap;
import static org.fest.assertions.Assertions.assertThat;
import static org.fest.reflect.core.Reflection.field;

/**
 * User: PPERA
 * Date: 03/07/13
 * Time: 15:23
 */
public class UserFormValidator_UT {

    private UserFormValidator userFormValidator;
    private Errors errors;
    private UserForm userForm;

    @Before
    public void setUp() {
        userFormValidator = new UserFormValidator();
        userForm = new UserForm();
        errors = new BeanPropertyBindingResult(userForm, "form");
        field("requiredStrength").ofType(Integer.class).in(userFormValidator).set(0);
    }

    @Test
    public void testValidateAddsEmptyConfirmPasswordError_WhenValidatingFormWithNullConfirmPassword() {
        // @Given a form with no password and an errors object
        // @When validating it
        userFormValidator.validate(userForm, errors);

        // @Then empty password error is added to the errors
        assertThat(errors.getFieldError("confirmNewPassword")).isNotNull();
        assertThat(errors.getFieldError("confirmNewPassword").getCode()).isEqualTo("changePassword.error.confirmNewPassword.empty");
    }

    @Test
    public void testValidateAddsEmptyConfirmPasswordError_WhenValidatingFormWithEmptyConfirmPassword() {
        // @Given a form with no password and an errors object
        userForm.setConfirmNewPassword("");

        // @When validating it
        userFormValidator.validate(userForm, errors);

        // @Then empty password error is added to the errors
        assertThat(errors.getFieldError("confirmNewPassword")).isNotNull();
        assertThat(errors.getFieldError("confirmNewPassword").getCode()).isEqualTo("changePassword.error.confirmNewPassword.empty");
    }

    @Test
    public void testValidateAddsPasswordMismatchError_WhenPasswordIsSecretAndConfirmIsSomethingElse() {
        // @Given a form with password secret and confirm password something else
        userForm.setNewPassword("secret");
        userForm.setConfirmNewPassword("somethingElse");

        // @When validating the form
        userFormValidator.validate(userForm, errors);

        // @Then mismatch password error is in error
        assertThat(errors.getFieldError("confirmNewPassword")).isNotNull();
        assertThat(errors.getFieldError("confirmNewPassword").getCode()).isEqualTo("changePassword.error.mismatch");
    }

    @Test
    public void testValidateDoesNotAddPasswordMismatchError_WhenPasswordIsSecretAndConfirmIsSecret() {
        // @Given a form with password secret and confirm password something else
        userForm.setNewPassword("secret");
        userForm.setConfirmNewPassword("secret");

        // @When validating the form
        userFormValidator.validate(userForm, errors);

        // @Then mismatch password error is in error
        assertThat(errors.getFieldError("confirmPassword")).isNull();
    }

    @Test
    public void testSupportsReturnsTrue_WhenAskingValidatorIfSupportsUserForm() {
        // @Given a userFormValidator
        // @When asking the validator if it supports UserForm type
        boolean result = userFormValidator.supports(UserForm.class);

        // @Then it returns true
        assertThat(result).isTrue();
    }

    @Test
    public void testSupportsReturnsFalse_WhenAskingValidatorIfSupportsOtherForm() {// How do I do this? Passing every single form?
        // @Given a userFormValidator
        // @When asking the validator if it supports UserForm type
        boolean result = userFormValidator.supports(ChangePasswordForm.class);

        // @Then it returns true
        assertThat(result).isFalse();
    }

    @Test
    public void testValidateAddsEmptyUid_WhenValidatingAFormWithEmptyUid() {
        // @Given a form with a malformed e-mail
        // @When validating the form
        userFormValidator.validate(userForm, errors);

        // @Then mismatch password error is in error
        assertThat(errors.getFieldError("userName")).isNotNull();
        assertThat(errors.getFieldError("userName").getCode()).isEqualTo("userForm.error.userName.empty");
    }

    @Test
    public void testValidateAddsEmptySn_WhenValidatingAFormWithEmptySn() {
        // @Given a form with a malformed e-mail
        // @When validating the form
        userFormValidator.validate(userForm, errors);

        // @Then mismatch password error is in error
        assertThat(errors.getFieldError("sn")).isNotNull();
        assertThat(errors.getFieldError("sn").getCode()).isEqualTo("userForm.error.sn.empty");
    }

    @Test
    public void testValidateAddsPatternError_WhenValidatingAFormWithAUidWithInvalidCharacters() {
        // @Given a form with a malformed e-mail
        userForm.setUserName("&");

        // @When validating the form
        userFormValidator.validate(userForm, errors);

        // @Then mismatch password error is in error
        assertThat(errors.getFieldError("userName")).isNotNull();
        assertThat(errors.getFieldError("userName").getCode()).isEqualTo("userForm.error.userName.invalid");
    }

    @Test
    public void testValidateAddsPatternError_WhenValidatingAFormWithAsnWithInvalidCharacters() {
        // @Given a form with a malformed e-mail
        userForm.setSn("&");

        // @When validating the form
        userFormValidator.validate(userForm, errors);

        // @Then mismatch password error is in error
        assertThat(errors.getFieldError("sn")).isNotNull();
        assertThat(errors.getFieldError("sn").getCode()).isEqualTo("userForm.error.sn.invalid");
    }

    @Test
    public void testValidateAddsEmptyRolesByGroupError_WhenValidatingAFormWithEmptyRolesByGroupMap() {
        // @Given a form with a malformed e-mail
        // @When validating the form
        userFormValidator.validate(userForm, errors);

        // @Then mismatch password error is in error
        assertThat(errors.getFieldError("rolesByGroupMap")).isNotNull();
        assertThat(errors.getFieldError("rolesByGroupMap").getCode()).isEqualTo("userForm.error.rolesByGroupMap.empty");
    }

    @Test
    public void testValidateAddsEmailMalformedError_WhenValidatingAFormWithAMalformedEmail() {
        // @Given a form with a malformed e-mail
        Map<String, Map<String, Boolean>> rolesByGroupMap = newHashMap();
        rolesByGroupMap.put("something", new HashMap<String, Boolean>());
        userForm.setRolesByGroupMap(rolesByGroupMap);
        userForm.setMail("secretlalal.com");

        // @When validating the form
        userFormValidator.validate(userForm, errors);

        // @Then mismatch password error is in error
        assertThat(errors.getFieldError("mail")).isNotNull();
        assertThat(errors.getFieldError("mail").getCode()).isEqualTo("userForm.error.malformedAddress");
    }

    @Test
    public void testValidateDoesNotAddEmailMalformedError_WhenValidatingAFormWithAWellformedEmail() {
        // @Given a form with a wellformed e-mail
        userForm.setMail("secret@lalal.com");

        // @When validating the form
        userFormValidator.validate(userForm, errors);

        // @Then mismatch password error is not in error
        assertThat(errors.getFieldError("mail")).isNull();
    }

}