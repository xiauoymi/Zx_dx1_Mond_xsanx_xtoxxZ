package com.industrysystem.web.validators;

import com.industrysystem.web.forms.ChangePasswordForm;
import com.industrysystem.web.forms.UserGroupsForm;
import com.industrysystem.web.forms.validators.UserGroupsFormValidator;
import org.junit.Before;
import org.junit.Test;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;

import static org.fest.assertions.Assertions.assertThat;

/**
 * User: PPERA
 * Date: 30/07/13
 * Time: 17:49
 */
public class UserGroupsFormValidator_UT {

    private UserGroupsFormValidator userGroupsFormValidator;
    private Errors errors;
    private UserGroupsForm userGroupsForm;

    @Before
    public void setUp() {
        this.userGroupsFormValidator = new UserGroupsFormValidator();
        this.userGroupsForm = new UserGroupsForm();
        this.errors = new BeanPropertyBindingResult(this.userGroupsForm, "form");
    }

    @Test
    public void testValidateAddsEmptyDocumentError_WhenValidatingFormWithNullDocument() {
        // @Given a form with no document and an errors object

        // @When validating it
        this.userGroupsFormValidator.validate(userGroupsForm, this.errors);

        // @Then empty document error is added to the errors
        assertThat(this.errors.getFieldError("document")).isNotNull();
        assertThat(this.errors.getFieldError("document").getCode()).isEqualTo("userGroupsForm.error.document.empty");
    }

    @Test
    public void testValidateAddsEmptyDocumentError_WhenValidatingFormWithEmptyDocument() {
        // @Given a form with no document and an errors object
        this.userGroupsForm.setDocument("");

        // @When validating it
        this.userGroupsFormValidator.validate(userGroupsForm, this.errors);

        // @Then empty document error is added to the errors
        assertThat(this.errors.getFieldError("document")).isNotNull();
        assertThat(this.errors.getFieldError("document").getCode()).isEqualTo("userGroupsForm.error.document.empty");
    }

    @Test
    public void testSupportsReturnsTrue_WhenAskingValidatorIfSupportsUserGroupsForm() {
        // @Given a userGroupsFormValidator

        // @When asking the validator if it supports UserGroupsForm type
        boolean result = this.userGroupsFormValidator.supports(UserGroupsForm.class);

        // @Then it returns true
        assertThat(result).isTrue();
    }

    @Test
    public void testSupportsReturnsFalse_WhenAskingValidatorIfSupportsOtherForm() {// How do I do this? Passing every single form?
        // @Given a userGroupsFormValidator

        // @When asking the validator if it supports UserForm type
        boolean result = this.userGroupsFormValidator.supports(ChangePasswordForm.class);

        // @Then it returns true
        assertThat(result).isFalse();
    }

    @Test
    public void testValidateAddsPatternError_WhenValidatingAFormWithAUidWithInvalidCharacters() {
        // @Given a form with a malformed e-mail
        this.userGroupsForm.setDocument("&");

        // @When validating the form
        this.userGroupsFormValidator.validate(this.userGroupsForm, this.errors);

        // @Then mismatch document error is in error
        assertThat(this.errors.getFieldError("document")).isNotNull();
        assertThat(this.errors.getFieldError("document").getCode()).isEqualTo("userForm.error.document.invalid");
    }

    @Test
    public void testValidateAddsEmptyRolesByGroupError_WhenValidatingAFormWithEmptyRolesByGroupMap() {
        // @Given a form with empty assignedGroups

        // @When validating the form
        this.userGroupsFormValidator.validate(this.userGroupsForm, this.errors);

        // @Then empty assignedGroups error
        assertThat(this.errors.getFieldError("assignedGroups")).isNotNull();
        assertThat(this.errors.getFieldError("assignedGroups").getCode()).isEqualTo("userForm.error.assignedGroups.empty");
    }
}
