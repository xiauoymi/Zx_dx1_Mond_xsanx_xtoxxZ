package com.monsanto.jira;

public class MyPlugin
{
}
