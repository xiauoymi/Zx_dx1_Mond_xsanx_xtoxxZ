package com.monsanto.jira;

import com.monsanto.teamtrack.aewebservices.domain.axis.*;
import org.springframework.beans.factory.annotation.Required;

import javax.swing.table.TableStringConverter;
import javax.xml.rpc.ServiceException;
import java.math.BigInteger;
import java.rmi.RemoteException;

/**
 * Created by IntelliJ IDEA.
 * User: VVPRAS
 * Date: 2/5/13
 * Time: 5:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class TeamTrackItemProvider {

    private Auth auth;
    private Aewebservices71_ServiceLocator locator;

    @Required
    public void setAuth(Auth auth) {
        this.auth = auth;
    }

    @Required
    public void setLocator(Aewebservices71_ServiceLocator locator) {
        this.locator = locator;
    }

    public TTItem getItem(String issueId) throws ServiceException, RemoteException {
        TTItem item = null;
        TTItem items[] = null;
        if (issueId != null) {
            Aewebservices71PortType port = locator.getaewebservices71();
            item = port.getItem(auth, issueId, null);
        }
        return item;
    }

    public TTItem getItemByPCR(String pcrNumber) throws ServiceException, RemoteException {
        System.out.println("TTItemProvider");
        TTItem items[] = null;
        if (pcrNumber != null) {
            Aewebservices71PortType port = locator.getaewebservices71();
            String issueId = pcrNumber.toUpperCase().startsWith("PCR") ? pcrNumber.substring(3) : pcrNumber;
            System.out.println("issueId : " + issueId);
            try {
                items = port.getItemsByQuery(auth, new BigInteger("1004"), "TS_ISSUEID=" + issueId, "TS_ISSUEID", new BigInteger("1"), null);
            } catch (Exception e) {
                System.out.println("Entered");
                e.printStackTrace();
            }
        }
        return items[0];
    }
}
