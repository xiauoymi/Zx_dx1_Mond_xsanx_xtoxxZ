package com.monsanto.jira;

import com.monsanto.jira.issueimport.TeamTrackRepresentation;
import com.monsanto.teamtrack.aewebservices.domain.axis.Auth;
import com.monsanto.teamtrack.aewebservices.domain.axis.NameValue;
import com.monsanto.teamtrack.aewebservices.domain.axis.TTItem;
import org.springframework.beans.factory.annotation.Required;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TeamTrackReportParser {
    private static final String TT_ISSUE_URL = "http://w3.teamtrack.monsanto.com/tmtrack/";

    private static final Pattern listRowPattern = Pattern.compile("(<tr class=\"listrow\">)(.*?)(</DL>)");
    private static final Pattern issuePattern = Pattern.compile("<DT>.*</DT><DD><A HREF=\"(.*?)\".*?title=\"(.*?)\">(.*?)<");
    private static final Pattern descriptionPattern = Pattern.compile("<DT>Description</DT><DD>(.*?)</DD>");
    private static Pattern recordId = Pattern.compile(".*?RecordId=([0-9]*).*?TableId=([0-9]*)");
    private static final Pattern statePattern = Pattern.compile("<DT>State</DT><DD>(.*?)</DD>");
    private static final Pattern estDevHrsPattern = Pattern.compile("<DT>Est Developer Hours</DT><DD>(.*?)</DD>");
    private static final Pattern prdReleaseDatePattern = Pattern.compile("<DT>Production Release Date</DT><DD>(.*?)</DD>");

    private TeamTrackItemProvider teamTrackItemProvider;

    @Required
    public void setTeamTrackItemProvider(TeamTrackItemProvider teamTrackItemProvider) {
        this.teamTrackItemProvider = teamTrackItemProvider;
    }

    public List<TeamTrackRepresentation> parseTeamTracks(String reportContent) throws Exception {
        ArrayList<TeamTrackRepresentation> teamtracks = new ArrayList<TeamTrackRepresentation>();
        TTItem ttItem = null;
        NameValue[] namevalueList = null;

        Matcher rowMatcher = listRowPattern.matcher(reportContent);
        while (rowMatcher.find()) {
            String row = rowMatcher.group(2);
            Matcher issueMatcher = issuePattern.matcher(row);
            issueMatcher.find();
            String url = TT_ISSUE_URL + issueMatcher.group(1);
            String title = issueMatcher.group(2);
            String name = issueMatcher.group(3);
            Matcher matcher = recordId.matcher(url);
            matcher.find();
            String recordId = matcher.group(1);
            String tableId = matcher.group(2);

            //Description
            Matcher descriptionMatcher = descriptionPattern.matcher(row);
            String description = null;
            try {
                descriptionMatcher.find();
                description = descriptionMatcher.group(1).replace("<BR>", "\r\n");
                //System.out.println("description : " + description);
            } catch (Exception e) {
                description = "";
            }

            //State
            Matcher stateMatcher = statePattern.matcher(row);
            String statusDesc = null;
            try {
                stateMatcher.find();
                statusDesc = stateMatcher.group(1).replace("<BR>", "\r\n");
                //System.out.println("statusDesc : " + statusDesc);
            } catch (Exception e) {
                statusDesc = "";
            }

            //Est Dev Hrs
            Matcher estHrsMatcher = estDevHrsPattern.matcher(row);
            String estDevHrs = null;
            try {
                estHrsMatcher.find();
                estDevHrs = estHrsMatcher.group(1).replace("<BR>", "\r\n");
                if ("&nbsp;".equalsIgnoreCase(estDevHrs))
                    estDevHrs = "";
                //System.out.println("estDevHrs : " + estDevHrs);
            } catch (Exception e) {
                estDevHrs = "";
            }

            //Prod Release Date
            Matcher releaseDtMatcher = prdReleaseDatePattern.matcher(row);
            String prodReleaseDate = null;
            try {
                releaseDtMatcher.find();
                prodReleaseDate = releaseDtMatcher.group(1).replace("<BR>", "\r\n");

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MMM/yy");
                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

                if ("&nbsp;".equalsIgnoreCase(prodReleaseDate))
                    prodReleaseDate = "";
                else {
                    Date convertedDate = dateFormat.parse(prodReleaseDate);
                    prodReleaseDate = simpleDateFormat.format(convertedDate);
                }

            } catch (Exception e) {
                prodReleaseDate = "";
            }
            System.out.println("prodReleaseDate : " + prodReleaseDate);

            String actDevHrs = "";

            teamtracks.add(new TeamTrackRepresentation(tableId + ":" + recordId, name, title, url, description, estDevHrs, actDevHrs, prodReleaseDate, statusDesc));
        }
        return teamtracks;
    }

    public static void main(String[] args) throws Exception {
        TeamTrackReportReader reader = new TeamTrackReportReader();
        //String reportContent = reader.readReport("21903");
        String reportContent = reader.readReport("20600");
        System.out.println(reportContent);
        TeamTrackReportParser parser = new TeamTrackReportParser();
        parser.parseTeamTracks(reportContent);
    }
}
