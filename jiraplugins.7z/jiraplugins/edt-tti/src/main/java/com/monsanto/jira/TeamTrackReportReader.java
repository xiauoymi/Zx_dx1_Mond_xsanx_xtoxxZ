package com.monsanto.jira;

import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthSchemeRegistry;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.NTCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.params.ClientPNames;
import org.apache.http.client.protocol.ClientContext;
import org.apache.http.impl.auth.NTLMSchemeFactory;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class TeamTrackReportReader {
    private static final String TT_URL = "http://w3.teamtrack.monsanto.com/tmtrack/tmtrack.dll?ReportPage&Template=reports%2Flist&recno=-1&ReportId=";

    private static final String username = "NA1000APP-JIRA";
    private static final String password = "F3Bu@y1";
    private static final String workstation = "stlucrsdev02";
    private static final String domain = "NORTH_AMERICA";

    public String readReport(String reportId) throws IOException {
        DefaultHttpClient httpClient = new DefaultHttpClient();
        AuthSchemeRegistry authSchemeRegistry = httpClient.getAuthSchemes();
        for (String scheme : authSchemeRegistry.getSchemeNames()) {
            authSchemeRegistry.unregister(scheme);
        }
        authSchemeRegistry.register("ntlm", new NTLMSchemeFactory());
        HttpContext httpContext = new BasicHttpContext();
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(new AuthScope(AuthScope.ANY), new NTCredentials(username, password, workstation, domain));
        httpContext.setAttribute(ClientContext.CREDS_PROVIDER, credentialsProvider);
        httpContext.setAttribute(ClientPNames.HANDLE_AUTHENTICATION, true);
        HttpGet httpGet = new HttpGet(TT_URL + reportId);

        HttpResponse response = httpClient.execute(httpGet, httpContext);
        int code = response.getStatusLine().getStatusCode();
        if (code != 200) {
            throw new RuntimeException("Could not connect to TeamTrack, code " + code + " (" + response.getStatusLine().getReasonPhrase() + ")");
        }
        StringBuilder sb = new StringBuilder();
        BufferedReader in = new BufferedReader(new InputStreamReader(
                response.getEntity().getContent()));
        String inputLine;
        while ((inputLine = in.readLine()) != null)
            sb.append(inputLine);
        in.close();
        return sb.toString();
    }

    public static void main(String[] args)throws Exception{
        TeamTrackReportReader reader = new TeamTrackReportReader();
        String reportContent = reader.readReport("21903");
        System.out.println(reportContent);
        /*TeamTrackReportParser  parser = new TeamTrackReportParser();
        parser.parseTeamTracks(reportContent);*/
    }
}
