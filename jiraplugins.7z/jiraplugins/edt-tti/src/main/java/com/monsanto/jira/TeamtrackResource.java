package com.monsanto.jira;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.jira.ComponentManager;
import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.bc.issue.search.SearchService;
import com.atlassian.jira.bc.project.ProjectService;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueInputParameters;
import com.atlassian.jira.issue.IssueInputParametersImpl;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.issue.search.SearchException;
import com.atlassian.jira.jql.builder.JqlClauseBuilder;
import com.atlassian.jira.jql.builder.JqlQueryBuilder;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.web.bean.PagerFilter;
import com.atlassian.plugins.rest.common.security.AnonymousAllowed;
import com.atlassian.sal.api.user.UserManager;
import com.monsanto.jira.issueimport.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.*;

@Path("/teamtrack")
public class TeamtrackResource {
    public static final String TEAM_TRACK_ITEM_ID = "TeamTrack Item ID";
    private IssueService issueService;
    private ProjectService projectService;
    private SearchService searchService;
    private UserManager userManager;
    private com.atlassian.jira.user.util.UserManager jiraUserManager;
    private TeamTrackReportParser teamTrackReportParser;
    private TeamTrackReportReader teamTrackReportReader;
    private static final List<String> IGNORE_STATUS;

    static {
        IGNORE_STATUS = Arrays.asList("Open", "In Progress", "Reopened");
    }

    public TeamtrackResource(IssueService issueService, ProjectService projectService,
                             SearchService searchService, UserManager userManager,
                             com.atlassian.jira.user.util.UserManager jiraUserManager,
                             TeamTrackReportParser teamTrackReportParser,
                             TeamTrackReportReader teamTrackReportReader) {

        this.issueService = issueService;
        this.projectService = projectService;
        this.searchService = searchService;
        this.userManager = userManager;
        this.jiraUserManager = jiraUserManager;
        this.teamTrackReportParser = teamTrackReportParser;
        this.teamTrackReportReader = teamTrackReportReader;
    }

    @GET
    @AnonymousAllowed
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response getTeamtracksToImport(@Context HttpServletRequest request, @QueryParam(value = "reportId") String reportId,
                                          @QueryParam(value = "projectId") Long projectId) {
        List<TeamTrackRepresentation> teamtracks = new ArrayList<TeamTrackRepresentation>();
        String message = null;
        try {
            User currentUser = getCurrentUser(request);
            String reportContent = teamTrackReportReader.readReport(reportId);
            teamtracks = teamTrackReportParser.parseTeamTracks(reportContent);
            Iterator<TeamTrackRepresentation> iterator = teamtracks.iterator();
            while (iterator.hasNext()) {
                TeamTrackRepresentation teamTrack = iterator.next();
                List<Issue> matchingIssuesInJira = findMatchingIssuesInJira(currentUser, teamTrack.getName(), projectId);
                String jiraStatus = getIssueJiraStatus(matchingIssuesInJira);
                teamTrack.setJiraKey(getIssueJiraKey(matchingIssuesInJira));
                teamTrack.setJiraStatus(jiraStatus);
                if (IGNORE_STATUS.contains(jiraStatus)) {
                    iterator.remove();
                }
            }
        } catch (Exception ex) {
            message = ex.getMessage();
        }
        return Response.ok(new TeamTracksRepresentation(teamtracks, message)).build();
    }

    @POST
    @AnonymousAllowed
    @Consumes({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    @Produces({MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML})
    public Response importTeamtracks(@Context HttpServletRequest req, @QueryParam(value = "projectId") Long projectId, @QueryParam(value = "componentId") Long componentId,
                                     @QueryParam(value = "versionId") Long versionId,
                                     @QueryParam(value = "issueTypeId") String issueTypeId, TeamTracksRepresentation obj) {
        try {
            User user = getCurrentUser(req);
            checkNoDuplicates(projectId, obj, user);
            for (TeamTrackRepresentation teamTrackRepresentation : obj.teamtracks) {
                IssueInputParameters issueInputParameters = new IssueInputParametersImpl();
                issueInputParameters.setSummary(teamTrackRepresentation.getName() + " - " + teamTrackRepresentation.getTitle());
                issueInputParameters.setDescription(teamTrackRepresentation.getDescription() + "\r\n\r\n" + teamTrackRepresentation.getUrl());
                issueInputParameters.setProjectId(projectId);

                if(!(null == teamTrackRepresentation.getEstDevHrs() || "".equals(teamTrackRepresentation.getEstDevHrs())))
                    issueInputParameters.setOriginalEstimate((new Double(teamTrackRepresentation.getEstDevHrs())).longValue());
                //issueInputParameters.setTimeSpent(new Long(teamTrackRepresentation.getActDevHrs()));
                if(!(null == teamTrackRepresentation.getProdReleaseDate() || "".equals(teamTrackRepresentation.getProdReleaseDate())))
                    issueInputParameters.setDueDate(teamTrackRepresentation.getProdReleaseDate());

                issueInputParameters.setStatusId(teamTrackRepresentation.getStatusDesc());

                CustomFieldManager customFieldManager = ComponentManager.getInstance().getCustomFieldManager();
                CustomField customField = customFieldManager.getCustomFieldObjectByName(TEAM_TRACK_ITEM_ID);
                if (customField != null) {
                    issueInputParameters.addCustomFieldValue(customField.getIdAsLong(), teamTrackRepresentation.getItemId());
                }
                if (!ComponentRepresentation.blankComponent.getId().equals(componentId)) {
                    issueInputParameters.setComponentIds(componentId);
                }
                if (!VersionRepresentation.blankVersion.getId().equals(versionId)) {
                    issueInputParameters.setAffectedVersionIds(versionId);
                    issueInputParameters.setFixVersionIds(versionId);
                }
                Project project = projectService.getProjectById(user, projectId).getProject();
                issueInputParameters.setPriorityId("3");
                issueInputParameters.setReporterId(project.getLeadUser().getName());
                issueInputParameters.setIssueTypeId(issueTypeId);
                IssueService.CreateValidationResult result = issueService.validateCreate(user, issueInputParameters);
                if (result.getErrorCollection().hasAnyErrors()) {
                    Map<String, String> errors = result.getErrorCollection().getErrors();
                    StringBuilder sb = new StringBuilder();
                    for (Map.Entry<String, String> entrySet : errors.entrySet()) {
                        sb.append(entrySet.getKey()).append(": ").append(entrySet.getValue());
                    }
                    return Response.ok(new MessageRepresentation(sb.toString())).build();
                }
                issueService.create(user, result);
            }
            return Response.ok(new MessageRepresentation(obj.teamtracks.size() + " TeamTracks successfully imported.")).build();
        } catch (Exception ex) {
            //return Response.ok(new MessageRepresentation(ex.getMessage())).build();
            return Response.ok(new MessageRepresentation(ex.getMessage()+" : "+ex.getCause())).build();
        }
    }

    private void checkNoDuplicates(Long projectId, TeamTracksRepresentation obj, User currentUser) throws SearchException {
        for (TeamTrackRepresentation teamTrackRepresentation : obj.teamtracks) {
            if (findMatchingIssuesInJira(currentUser, teamTrackRepresentation.getName(), projectId).size() > 0) {
                throw new RuntimeException(teamTrackRepresentation.getName() + " was already found in the project and cannot be re-imported.  Your browser might have the gadget cached, you may be using multiple browser windows, or maybe someone already imported the issue.  Please refresh your gadget manually (upper right hand corner of the gadget).");
            }
        }
    }

    private String getIssueJiraStatus(List<Issue> matchingIssuesInJira) {
        if (matchingIssuesInJira.size() > 0) {
            return matchingIssuesInJira.get(0).getStatusObject().getName();
        }
        return "New";
    }

    private String getIssueJiraKey(List<Issue> matchingIssuesInJira) {
        if (matchingIssuesInJira.size() > 0) {
            return matchingIssuesInJira.get(0).getKey();
        }
        return "";
    }

    private List<Issue> findMatchingIssuesInJira(User user, String name, Long projectId) throws SearchException {
        JqlClauseBuilder jqlClauseBuilder = JqlQueryBuilder.newClauseBuilder();
        com.atlassian.query.Query query = jqlClauseBuilder.summary(name).and().project(projectId).buildQuery();
        PagerFilter pagerFilter = PagerFilter.getUnlimitedFilter();
        return searchService.search(user, query, pagerFilter).getIssues();
    }

    private User getCurrentUser(HttpServletRequest req) {
        return jiraUserManager.getUserObject(userManager.getRemoteUsername(req));
    }
}
