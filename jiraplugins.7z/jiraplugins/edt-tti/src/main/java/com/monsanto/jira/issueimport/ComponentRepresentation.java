package com.monsanto.jira.issueimport;

import com.atlassian.jira.bc.project.component.ProjectComponent;
import net.jcip.annotations.Immutable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Immutable
@SuppressWarnings("UnusedDeclaration")
@XmlRootElement
public class ComponentRepresentation {
    @XmlElement
    private Long id;

    @XmlElement
    private String name;

    public static final ComponentRepresentation blankComponent;

    static {
        blankComponent = new ComponentRepresentation();
        blankComponent.name = " - None - ";
        blankComponent.id = -1l;
    }

    public ComponentRepresentation() {
    }

    public ComponentRepresentation(ProjectComponent projectComponent) {
        this.id = projectComponent.getId();
        this.name = projectComponent.getName();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
