package com.monsanto.jira.issueimport;

import net.jcip.annotations.Immutable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Collection;
import java.util.HashSet;

@Immutable
@SuppressWarnings("UnusedDeclaration")
@XmlRootElement
public class ComponentsRepresentation {
    @XmlElement
    private Collection<ComponentRepresentation> components;

    private ComponentsRepresentation() {
        components = null;
    }

    public ComponentsRepresentation(Iterable<ComponentRepresentation> components) {
        this.components = new HashSet<ComponentRepresentation>();
        for (ComponentRepresentation component : components) {
            this.components.add(component);
        }
    }
}
