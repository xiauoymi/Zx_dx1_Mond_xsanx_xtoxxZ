package com.monsanto.jira.issueimport;

import com.atlassian.jira.bc.project.component.ProjectComponent;
import net.jcip.annotations.Immutable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Immutable
@SuppressWarnings("UnusedDeclaration")
@XmlRootElement
public class IssueTypeRepresentation {
    @XmlElement
    private String id;

    @XmlElement
    private String name;

    public IssueTypeRepresentation() {
    }

    public IssueTypeRepresentation(String id, String name) {
        this.id = id;
        this.name = name;
    }
}
