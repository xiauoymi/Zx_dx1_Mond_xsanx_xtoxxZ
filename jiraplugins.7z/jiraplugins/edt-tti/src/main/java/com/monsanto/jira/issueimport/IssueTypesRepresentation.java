package com.monsanto.jira.issueimport;

import net.jcip.annotations.Immutable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Collection;

@Immutable
@SuppressWarnings("UnusedDeclaration")
@XmlRootElement
public class IssueTypesRepresentation {
    @XmlElement
    private Collection<IssueTypeRepresentation> issueTypes;

    public IssueTypesRepresentation() {
    }

    public IssueTypesRepresentation(Collection<IssueTypeRepresentation> issueTypes) {
        this.issueTypes = issueTypes;
    }
}
