package com.monsanto.jira.issueimport;

import net.jcip.annotations.Immutable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@Immutable
@SuppressWarnings("UnusedDeclaration")
@XmlRootElement
public class MessageRepresentation {
    @XmlElement
    private String message;

    public MessageRepresentation(){}

    public MessageRepresentation(String message){
        this.message = message;
    }
}
