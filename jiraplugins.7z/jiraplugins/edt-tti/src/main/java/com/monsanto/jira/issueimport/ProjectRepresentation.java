package com.monsanto.jira.issueimport;

import com.atlassian.jira.bc.project.component.ProjectComponent;
import com.atlassian.jira.issue.issuetype.IssueType;
import com.atlassian.jira.project.Project;
import com.atlassian.jira.project.version.Version;
import net.jcip.annotations.Immutable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.ArrayList;
import java.util.Collection;

/**
 * JAXB representation of a project's information. This can be marshalled as
 * either JSON or XML, depending on what the client asks for.
 */
@Immutable
@SuppressWarnings("UnusedDeclaration")
@XmlRootElement
public class ProjectRepresentation {
    @XmlElement
    private Long id;

    @XmlElement
    private String key;

    @XmlElement
    private String name;

    @XmlElement
    private String projectUrl;

    @XmlElement
    private String projectLead;

    @XmlElement
    private String description;

    @XmlElement
    private VersionsRepresentation versionData;

    @XmlElement
    private ComponentsRepresentation componentData;

    @XmlElement
    private IssueTypesRepresentation issueTypeData;

    // This private constructor isn't used by any code, but JAXB requires any
    // representation class to have a no-args constructor.
    private ProjectRepresentation() {
    }

    /**
     * Initializes the representation's values to those in the specified
     * {@code Project}.
     *
     * @param project the project to use for initialization
     */
    public ProjectRepresentation(Project project) {
        this.id = project.getId();
        this.key = project.getKey();
        this.name = project.getName();
        this.projectUrl = project.getUrl();
        this.projectLead = project.getLeadUser().getDisplayName();
        this.description = project.getDescription();

        setComponents(project);
        setVersions(project);
        setIssueTypes(project);
    }

    private void setIssueTypes(Project project) {
        Collection<IssueTypeRepresentation> issueTypes = new ArrayList<IssueTypeRepresentation>();
        for (IssueType issueType : project.getIssueTypes()) {
            issueTypes.add(new IssueTypeRepresentation(issueType.getId(), issueType.getName()));
        }
        this.issueTypeData = new IssueTypesRepresentation(issueTypes);
    }

    private void setVersions(Project project) {
        Collection<VersionRepresentation> versions = new ArrayList<VersionRepresentation>();
        versions.add(VersionRepresentation.blankVersion);
        for (Version version : project.getVersions()) {
            if (!version.isReleased()) {
                versions.add(new VersionRepresentation(version));
            }
        }
        this.versionData = new VersionsRepresentation(versions);
    }

    private void setComponents(Project project) {
        Collection<ComponentRepresentation> components = new ArrayList<ComponentRepresentation>();
        components.add(ComponentRepresentation.blankComponent);
        for (ProjectComponent c : project.getProjectComponents()) {
            components.add(new ComponentRepresentation(c));
        }
        this.componentData = new ComponentsRepresentation(components);
    }

}
