package com.monsanto.jira.issueimport;

import javax.xml.bind.annotation.XmlElement;

public class TeamTrackRepresentation {
    @XmlElement
    private String itemId;

    @XmlElement
    private String name;

    @XmlElement
    private String jiraKey;

    @XmlElement
    public String title;

    @XmlElement
    private String url;

    @XmlElement
    private String description;

    @XmlElement
    private String jiraStatus;

    public String getEstDevHrs() {
        return estDevHrs;
    }

    public void setEstDevHrs(String estDevHrs) {
        this.estDevHrs = estDevHrs;
    }

    public String getActDevHrs() {
        return actDevHrs;
    }

    public void setActDevHrs(String actDevHrs) {
        this.actDevHrs = actDevHrs;
    }

    @XmlElement
    private String estDevHrs;

    @XmlElement
    private String actDevHrs;

    public String getProdReleaseDate() {
        return prodReleaseDate;
    }

    public void setProdReleaseDate(String prodReleaseDate) {
        this.prodReleaseDate = prodReleaseDate;
    }

    public String getStatusDesc() {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    @XmlElement
    private String prodReleaseDate;

    @XmlElement
    private String statusDesc;

    public TeamTrackRepresentation() {
    }

    public TeamTrackRepresentation(String itemId, String name, String title, String url, String description, String estDevHrs, String actDevHrs, String prodReleaseDate, String statusDesc) {
        this.itemId = itemId;
        this.name = name;
        this.title = title;
        this.url = url;
        this.description = description;
        this.estDevHrs = estDevHrs;
        this.actDevHrs = actDevHrs;
        this.prodReleaseDate = prodReleaseDate;
        this.statusDesc = statusDesc;
    }

    public String getName() {
        return name;
    }

    public String getTitle() {
        return title;
    }

    public String getUrl() {
        return url;
    }

    public String getDescription() {
        return description;
    }

    public void setJiraStatus(String jiraStatus) {
        this.jiraStatus = jiraStatus;
    }

    public void setJiraKey(String jiraKey) {
        this.jiraKey = jiraKey;
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId;
    }
}
