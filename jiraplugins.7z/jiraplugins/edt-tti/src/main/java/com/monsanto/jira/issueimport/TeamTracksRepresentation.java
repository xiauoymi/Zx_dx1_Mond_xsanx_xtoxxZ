package com.monsanto.jira.issueimport;

import net.jcip.annotations.Immutable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Collection;

@Immutable
@SuppressWarnings("UnusedDeclaration")
@XmlRootElement
public class TeamTracksRepresentation {
    @XmlElement
    public Collection<TeamTrackRepresentation> teamtracks;

    @XmlElement
    public String message;

    public TeamTracksRepresentation(){}

    public TeamTracksRepresentation(Collection<TeamTrackRepresentation> teamTrackRepresentations, String message){
        this.teamtracks = teamTrackRepresentations;
        this.message = message;
    }
}
