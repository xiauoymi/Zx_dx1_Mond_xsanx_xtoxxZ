package com.monsanto.jira.issueimport;


import com.atlassian.jira.project.version.Version;
import net.jcip.annotations.Immutable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Date;

@Immutable
@SuppressWarnings("UnusedDeclaration")
@XmlRootElement
public class VersionRepresentation {
    @XmlElement
    private Long id;

    @XmlElement
    private String name;

    @XmlElement
    private Date releaseDate;

    public static final VersionRepresentation blankVersion;

    static {
        blankVersion = new VersionRepresentation();
        blankVersion.name = " - None - ";
        blankVersion.id = -1l;
    }

    public VersionRepresentation() {
    }

    public VersionRepresentation(Version projectComponent) {
        this.id = projectComponent.getId();
        this.name = projectComponent.getName();
        this.releaseDate = projectComponent.getReleaseDate();
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }
}
