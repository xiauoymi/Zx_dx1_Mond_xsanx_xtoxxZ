package com.monsanto.jira.issueimport;

import net.jcip.annotations.Immutable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.Collection;
import java.util.HashSet;

@Immutable
@SuppressWarnings("UnusedDeclaration")
@XmlRootElement
public class VersionsRepresentation {
    @XmlElement
    private Collection<VersionRepresentation> versions;

    private VersionsRepresentation() {
        versions = null;
    }

    public VersionsRepresentation(Iterable<VersionRepresentation> versions) {
        this.versions = new HashSet<VersionRepresentation>();
        for (VersionRepresentation version : versions) {
            this.versions.add(version);
        }
    }
}
