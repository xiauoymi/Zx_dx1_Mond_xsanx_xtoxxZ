
package com.monsanto.teamtrack.aewebservices.domain.axis;

public interface Aewebservices71PortType extends java.rmi.Remote {

    /**
     * Logout the current active session.
     */
    public void logout(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets the server version.
     */
    public java.lang.String getVersion() throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available applications.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.ApplicationData[] getApplications(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available solutions.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.SolutionData[] getSolutions(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available solutions.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.SolutionWithUniqueName[] getSolutionsWithUniqueName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available tables, optionally filtered by solution
     * and/or table type.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TableData[] getTables(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.math.BigInteger solutionID, com.monsanto.teamtrack.aewebservices.domain.axis.TableType tableType) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available tables, optionally filtered by solution
     * name and/or table type.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TableData[] getTablesWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String solutionName, com.monsanto.teamtrack.aewebservices.domain.axis.TableType tableType) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets a filtered list of reports.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.GetReportsResult getReports(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, com.monsanto.teamtrack.aewebservices.domain.axis.QueryRange queryRange, com.monsanto.teamtrack.aewebservices.domain.axis.ReportsFilter reportsFilter) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Runs a specified report.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.RunReportResult runReport(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, com.monsanto.teamtrack.aewebservices.domain.axis.QueryRange queryRange, java.lang.String reportUUID, java.lang.String reportName, java.math.BigInteger reportID, java.math.BigInteger solutionID, java.lang.String solutionName, java.math.BigInteger projectID, java.lang.String projectName, java.lang.String projectUUID, java.math.BigInteger tableID, java.lang.String tableName, com.monsanto.teamtrack.aewebservices.domain.axis.ReportCategory reportCategory, com.monsanto.teamtrack.aewebservices.domain.axis.ReportAccessLevel reportAccessLevel) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates a project.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.ProjectGeneralData createProject(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String projectName, java.lang.String parentProject, java.lang.String workflow, java.lang.Boolean useParentProjectWorkflow, java.lang.Boolean allowSubmit, java.lang.Boolean useParentSequenceNumbers, java.math.BigInteger lastItemSequenceNumber, java.math.BigInteger zeroFillTo, java.lang.Boolean allowAnonymousSubmit, java.lang.String altName, java.lang.String description) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available projects available for submitting
     * new items, optionally filtered by table id.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.ProjectData[] getSubmitProjects(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.math.BigInteger tableID) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available projects available for submitting
     * new items, optionally filtered by table db name.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.ProjectData[] getSubmitProjectsWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String tableDBName) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates a new item, given a project id and item data.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem createPrimaryItem(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.math.BigInteger projectID, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem item, java.math.BigInteger submitTransID, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates a new item, given a project name (fully qualified)
     * and item data.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem createPrimaryItemWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String fullyQualifiedProjectName, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem item, java.lang.String submitTransName, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates a new item, given a table id and item data.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem createAuxItem(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.math.BigInteger tableID, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem item, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates a new item, given a table database name and item data.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem createAuxItemWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String tableDBName, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem item, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates a several new primary items, given a project id and
     * a list of item data.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] createPrimaryItems(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.math.BigInteger projectID, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] itemList, java.math.BigInteger submitTransID, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates a several new primary items, given a project fully
     * qualified name and a list of item data.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] createPrimaryItemsWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String fullyQualifiedProjectName, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] itemList, java.lang.String submitTransName, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates several new primary items, given a project fully qualified
     * name and a list of item data.  Failures are interleaved with successfully
     * created items.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItemHolder[] createPrimaryItemsExtended(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String fullyQualifiedProjectName, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] itemList, java.lang.String submitTransName, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates a several new aux items, given a table id and a list
     * of item data.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] createAuxItems(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.math.BigInteger tableID, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] itemList, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates a several new aux items, given a table db name and
     * a list of item data.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] createAuxItemsWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String tableDBName, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] itemList, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Creates a new attachment, given item id of the item to which
     * it is to be attached, and the file attachment contents.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachment createFileAttachment(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String itemID, com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachmentContents attachmentContents) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Return an XML file (in OPC format), given an optional application
     * ID and 0 or more auxiliary table IDs.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.FileContents export(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String applicationID, com.monsanto.teamtrack.aewebservices.domain.axis.FileContents xmlExportOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Generates and returns a new UUID.
     */
    public java.lang.String generateUUID(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets an existing item, given a table id and internal item id.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem getItem(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String itemID, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets a list of existing items, given a table id and a list
     * of item ids.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] getItems(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String[] itemIdList, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets a list of existing items, given a table id, a query where
     * clause, an order by clause (optional) and a maximum return list size.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] getItemsByQuery(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.math.BigInteger tableID, java.lang.String queryWhereClause, java.lang.String orderByClause, java.math.BigInteger maxReturnSize, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets a list of existing items, given a table db name, a query
     * where clause, an order by clause (optional) and a maximum return list
     * size.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] getItemsByQueryWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String tableDBName, java.lang.String queryWhereClause, java.lang.String orderByClause, java.math.BigInteger maxReturnSize, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets an existing file attachment, given an item id and attachment
     * id.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachmentContents getFileAttachment(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String itemID, java.math.BigInteger attachmentID) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Import an application from an attached zip file containing
     * source XML.
     */
    public java.lang.String _import(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, com.monsanto.teamtrack.aewebservices.domain.axis.FileContents xmlInFile, java.lang.String adminRepositoryID, java.lang.String importResponseEndPoint, java.lang.String importResponseID, com.monsanto.teamtrack.aewebservices.domain.axis.FileContents xmlImportOptions, boolean validateOnly) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Returns status of a specified Import.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.ImportCurrentStatus importStatus(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String importUUID) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Updates an existing item, given the item with the item id filled
     * in, plus any data to update, and transition id to use a non-default
     * transition.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem updateItem(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem item, java.math.BigInteger transitionId, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Updates an existing item, given the item with the item id filled
     * in, plus any data to update, and transition name.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem updateItemWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem item, java.lang.String transitionName, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Updates several existing items, given an item list and optionally
     * a transition id.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] updateItems(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] itemList, java.math.BigInteger transitionId, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Updates several existing items, given an item list and optionally
     * a transition name.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] updateItemsWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] itemList, java.lang.String transitionName, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Updates several existing items, given an item list and optionally
     * a transition name.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TTItemHolder[] updateItemsExtended(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, com.monsanto.teamtrack.aewebservices.domain.axis.TTItem[] itemList, java.lang.String transitionName, java.lang.String responseOptions) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Return available transitions, given an item id and attribute
     * name (may be null or empty).
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Transition[] getAvailableTransitions(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String itemID, java.lang.String attributeName) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Return available transitions, given an item id and attribute
     * name (may be null or empty).
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Transition[] getAvailableTransitionsWithStateIDs(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String itemID, java.lang.String attributeName) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Service definition of function ae__GetAvailableQuickTransitions
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Transition[] getAvailableQuickTransitions(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String itemID, java.lang.String attributeName) throws java.rmi.RemoteException;

    /**
     * Return available Submit transitions, given an item id and attribute
     * name (may be null or empty).
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Transition[] getAvailableSubmitTransitions(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.math.BigInteger projectId, java.lang.String attributeName) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Return available Submit transitions, given an fully qualified
     * project name and attribute name (may be null or empty).
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Transition[] getAvailableSubmitTransitionsWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String fullyQualifiedProjectName, java.lang.String attributeName) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Updates an existing attachment, given item id, and the file
     * attachment contents.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachment updateFileAttachment(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String itemID, com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachmentContents attachmentContents) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Deletes an item, given a table id and item id.
     */
    public void deleteItem(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String sItemID) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Deletes several items, given a table id and a list of item
     * ids.
     */
    public void deleteItems(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String[] itemIdList) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Deletes one or more items, given a table id and a query where
     * clause.
     */
    public void deleteItemsByQuery(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.math.BigInteger tableID, java.lang.String queryWhereClause) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Deletes one or more items, given a table db name and a query
     * where clause.
     */
    public void deleteItemsByQueryWithName(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String tableDBName, java.lang.String queryWhereClause) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Deletes an existing attachment, which may be a note, item link,
     * URL attachment or file attachment, given an attachment id.
     */
    public void deleteAttachment(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.math.BigInteger attachmentID) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Delete a mashup.
     */
    public void deleteMashup(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String sMashupName) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Checks for the specified privilege by name.
     */
    public boolean hasUserPrivilege(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String privilegeName, java.lang.String objectId, java.lang.String loginId) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Returns a list of privileges that the specified user has.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Privilege[] getUserPrivileges(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String privilegeType, java.lang.String objectId, java.lang.String loginId) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Returns user information for the specified user.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.User getUser(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String userId) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Returns user information with date and time preferences for
     * the specified user.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.UserWithPreferences getUserWithPreferences(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String userId) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Returns user information with date and time preferences, phone
     * number and locale for the specified user.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.UserExtended getUserExtended(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String userId) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Determine if the specified user is valid.
     */
    public boolean isUserValid(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String loginId) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Returns note logger information.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.NoteLoggerInfo getNoteLoggerInfo(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;

    /**
     * Gets the state change history of an existing item, given a
     * table id and internal item id.
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.GetStateChangeHistoryResult getStateChangeHistory(com.monsanto.teamtrack.aewebservices.domain.axis.Auth auth, java.lang.String itemID, com.monsanto.teamtrack.aewebservices.domain.axis.QueryRange queryRange) throws java.rmi.RemoteException, com.monsanto.teamtrack.aewebservices.domain.axis.AEWebservicesFaultFault;
}
