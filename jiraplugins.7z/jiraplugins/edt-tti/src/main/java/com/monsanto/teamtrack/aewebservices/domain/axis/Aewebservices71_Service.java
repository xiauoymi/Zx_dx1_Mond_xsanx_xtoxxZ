
package com.monsanto.teamtrack.aewebservices.domain.axis;

public interface Aewebservices71_Service extends javax.xml.rpc.Service {

/**
 * gSOAP 2.7.17 generated service definition
 */
    public java.lang.String getaewebservices71Address();

    public com.monsanto.teamtrack.aewebservices.domain.axis.Aewebservices71PortType getaewebservices71() throws javax.xml.rpc.ServiceException;

    public com.monsanto.teamtrack.aewebservices.domain.axis.Aewebservices71PortType getaewebservices71(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
