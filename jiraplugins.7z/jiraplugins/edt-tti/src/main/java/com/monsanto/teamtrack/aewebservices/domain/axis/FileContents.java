
package com.monsanto.teamtrack.aewebservices.domain.axis;

public class FileContents  implements java.io.Serializable {
    private long checksum;

    private byte[] encodedContents;

    public FileContents() {
    }

    public FileContents(
           long checksum,
           byte[] encodedContents) {
           this.checksum = checksum;
           this.encodedContents = encodedContents;
    }


    /**
     * Gets the checksum value for this FileContents.
     * 
     * @return checksum
     */
    public long getChecksum() {
        return checksum;
    }


    /**
     * Sets the checksum value for this FileContents.
     * 
     * @param checksum
     */
    public void setChecksum(long checksum) {
        this.checksum = checksum;
    }


    /**
     * Gets the encodedContents value for this FileContents.
     * 
     * @return encodedContents
     */
    public byte[] getEncodedContents() {
        return encodedContents;
    }


    /**
     * Sets the encodedContents value for this FileContents.
     * 
     * @param encodedContents
     */
    public void setEncodedContents(byte[] encodedContents) {
        this.encodedContents = encodedContents;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FileContents)) return false;
        FileContents other = (FileContents) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.checksum == other.getChecksum() &&
            ((this.encodedContents==null && other.getEncodedContents()==null) || 
             (this.encodedContents!=null &&
              java.util.Arrays.equals(this.encodedContents, other.getEncodedContents())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getChecksum()).hashCode();
        if (getEncodedContents() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEncodedContents());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEncodedContents(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FileContents.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "FileContents"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checksum");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "checksum"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("encodedContents");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "encodedContents"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "base64Binary"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
