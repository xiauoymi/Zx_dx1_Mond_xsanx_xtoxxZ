
package com.monsanto.teamtrack.aewebservices.domain.axis;

public class ImportCurrentStatus  implements java.io.Serializable {
    private com.monsanto.teamtrack.aewebservices.domain.axis.ImportCurrentOverallStatus importStatus;

    private long percentageComplete;

    private java.lang.String currentStep;

    public ImportCurrentStatus() {
    }

    public ImportCurrentStatus(
           com.monsanto.teamtrack.aewebservices.domain.axis.ImportCurrentOverallStatus importStatus,
           long percentageComplete,
           java.lang.String currentStep) {
           this.importStatus = importStatus;
           this.percentageComplete = percentageComplete;
           this.currentStep = currentStep;
    }


    /**
     * Gets the importStatus value for this ImportCurrentStatus.
     * 
     * @return importStatus
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.ImportCurrentOverallStatus getImportStatus() {
        return importStatus;
    }


    /**
     * Sets the importStatus value for this ImportCurrentStatus.
     * 
     * @param importStatus
     */
    public void setImportStatus(com.monsanto.teamtrack.aewebservices.domain.axis.ImportCurrentOverallStatus importStatus) {
        this.importStatus = importStatus;
    }


    /**
     * Gets the percentageComplete value for this ImportCurrentStatus.
     * 
     * @return percentageComplete
     */
    public long getPercentageComplete() {
        return percentageComplete;
    }


    /**
     * Sets the percentageComplete value for this ImportCurrentStatus.
     * 
     * @param percentageComplete
     */
    public void setPercentageComplete(long percentageComplete) {
        this.percentageComplete = percentageComplete;
    }


    /**
     * Gets the currentStep value for this ImportCurrentStatus.
     * 
     * @return currentStep
     */
    public java.lang.String getCurrentStep() {
        return currentStep;
    }


    /**
     * Sets the currentStep value for this ImportCurrentStatus.
     * 
     * @param currentStep
     */
    public void setCurrentStep(java.lang.String currentStep) {
        this.currentStep = currentStep;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ImportCurrentStatus)) return false;
        ImportCurrentStatus other = (ImportCurrentStatus) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.importStatus==null && other.getImportStatus()==null) || 
             (this.importStatus!=null &&
              this.importStatus.equals(other.getImportStatus()))) &&
            this.percentageComplete == other.getPercentageComplete() &&
            ((this.currentStep==null && other.getCurrentStep()==null) || 
             (this.currentStep!=null &&
              this.currentStep.equals(other.getCurrentStep())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getImportStatus() != null) {
            _hashCode += getImportStatus().hashCode();
        }
        _hashCode += new Long(getPercentageComplete()).hashCode();
        if (getCurrentStep() != null) {
            _hashCode += getCurrentStep().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ImportCurrentStatus.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ImportCurrentStatus"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("importStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "importStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ImportCurrentOverallStatus"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentageComplete");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "percentageComplete"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currentStep");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "currentStep"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
