
package com.monsanto.teamtrack.aewebservices.domain.axis;

public class NameValue  implements java.io.Serializable {
    private java.lang.String name;

    private java.math.BigInteger id;

    private java.lang.String uuid;

    private com.monsanto.teamtrack.aewebservices.domain.axis.SetValueBy setValueBy;

    private com.monsanto.teamtrack.aewebservices.domain.axis.SetValueMethod setValueMethod;

    private com.monsanto.teamtrack.aewebservices.domain.axis.Value value;

    private com.monsanto.teamtrack.aewebservices.domain.axis.Value[] values;

    public NameValue() {
    }

    public NameValue(
           java.lang.String name,
           java.math.BigInteger id,
           java.lang.String uuid,
           com.monsanto.teamtrack.aewebservices.domain.axis.SetValueBy setValueBy,
           com.monsanto.teamtrack.aewebservices.domain.axis.SetValueMethod setValueMethod,
           com.monsanto.teamtrack.aewebservices.domain.axis.Value value,
           com.monsanto.teamtrack.aewebservices.domain.axis.Value[] values) {
           this.name = name;
           this.id = id;
           this.uuid = uuid;
           this.setValueBy = setValueBy;
           this.setValueMethod = setValueMethod;
           this.value = value;
           this.values = values;
    }


    /**
     * Gets the name value for this NameValue.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this NameValue.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the id value for this NameValue.
     * 
     * @return id
     */
    public java.math.BigInteger getId() {
        return id;
    }


    /**
     * Sets the id value for this NameValue.
     * 
     * @param id
     */
    public void setId(java.math.BigInteger id) {
        this.id = id;
    }


    /**
     * Gets the uuid value for this NameValue.
     * 
     * @return uuid
     */
    public java.lang.String getUuid() {
        return uuid;
    }


    /**
     * Sets the uuid value for this NameValue.
     * 
     * @param uuid
     */
    public void setUuid(java.lang.String uuid) {
        this.uuid = uuid;
    }


    /**
     * Gets the setValueBy value for this NameValue.
     * 
     * @return setValueBy
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.SetValueBy getSetValueBy() {
        return setValueBy;
    }


    /**
     * Sets the setValueBy value for this NameValue.
     * 
     * @param setValueBy
     */
    public void setSetValueBy(com.monsanto.teamtrack.aewebservices.domain.axis.SetValueBy setValueBy) {
        this.setValueBy = setValueBy;
    }


    /**
     * Gets the setValueMethod value for this NameValue.
     * 
     * @return setValueMethod
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.SetValueMethod getSetValueMethod() {
        return setValueMethod;
    }


    /**
     * Sets the setValueMethod value for this NameValue.
     * 
     * @param setValueMethod
     */
    public void setSetValueMethod(com.monsanto.teamtrack.aewebservices.domain.axis.SetValueMethod setValueMethod) {
        this.setValueMethod = setValueMethod;
    }


    /**
     * Gets the value value for this NameValue.
     * 
     * @return value
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Value getValue() {
        return value;
    }


    /**
     * Sets the value value for this NameValue.
     * 
     * @param value
     */
    public void setValue(com.monsanto.teamtrack.aewebservices.domain.axis.Value value) {
        this.value = value;
    }


    /**
     * Gets the values value for this NameValue.
     * 
     * @return values
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Value[] getValues() {
        return values;
    }


    /**
     * Sets the values value for this NameValue.
     * 
     * @param values
     */
    public void setValues(com.monsanto.teamtrack.aewebservices.domain.axis.Value[] values) {
        this.values = values;
    }

    public com.monsanto.teamtrack.aewebservices.domain.axis.Value getValues(int i) {
        return this.values[i];
    }

    public void setValues(int i, com.monsanto.teamtrack.aewebservices.domain.axis.Value _value) {
        this.values[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NameValue)) return false;
        NameValue other = (NameValue) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.uuid==null && other.getUuid()==null) || 
             (this.uuid!=null &&
              this.uuid.equals(other.getUuid()))) &&
            ((this.setValueBy==null && other.getSetValueBy()==null) || 
             (this.setValueBy!=null &&
              this.setValueBy.equals(other.getSetValueBy()))) &&
            ((this.setValueMethod==null && other.getSetValueMethod()==null) || 
             (this.setValueMethod!=null &&
              this.setValueMethod.equals(other.getSetValueMethod()))) &&
            ((this.value==null && other.getValue()==null) || 
             (this.value!=null &&
              this.value.equals(other.getValue()))) &&
            ((this.values==null && other.getValues()==null) || 
             (this.values!=null &&
              java.util.Arrays.equals(this.values, other.getValues())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getUuid() != null) {
            _hashCode += getUuid().hashCode();
        }
        if (getSetValueBy() != null) {
            _hashCode += getSetValueBy().hashCode();
        }
        if (getSetValueMethod() != null) {
            _hashCode += getSetValueMethod().hashCode();
        }
        if (getValue() != null) {
            _hashCode += getValue().hashCode();
        }
        if (getValues() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getValues());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getValues(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NameValue.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "NameValue"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uuid");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "uuid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("setValueBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "setValueBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Set-Value-By"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("setValueMethod");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "setValueMethod"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Set-Value-Method"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "value"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Value"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("values");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "values"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Value"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
