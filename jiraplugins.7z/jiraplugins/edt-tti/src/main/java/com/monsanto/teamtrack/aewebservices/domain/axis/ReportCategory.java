
package com.monsanto.teamtrack.aewebservices.domain.axis;

public class ReportCategory implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected ReportCategory(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _ALL = "ALL";
    public static final java.lang.String _APPLICATION = "APPLICATION";
    public static final java.lang.String _BUILTIN = "BUILTIN";
    public static final java.lang.String _MY = "MY";
    public static final java.lang.String _QUICKLINKS = "QUICKLINKS";
    public static final java.lang.String _USERREPORTS = "USERREPORTS";
    public static final ReportCategory ALL = new ReportCategory(_ALL);
    public static final ReportCategory APPLICATION = new ReportCategory(_APPLICATION);
    public static final ReportCategory BUILTIN = new ReportCategory(_BUILTIN);
    public static final ReportCategory MY = new ReportCategory(_MY);
    public static final ReportCategory QUICKLINKS = new ReportCategory(_QUICKLINKS);
    public static final ReportCategory USERREPORTS = new ReportCategory(_USERREPORTS);
    public java.lang.String getValue() { return _value_;}
    public static ReportCategory fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        ReportCategory enumeration = (ReportCategory)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static ReportCategory fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ReportCategory.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ReportCategory"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
