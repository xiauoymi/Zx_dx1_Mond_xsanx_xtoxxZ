
package com.monsanto.teamtrack.aewebservices.domain.axis;

public class ReportInfo  implements java.io.Serializable {
    private java.math.BigInteger reportID;

    private java.lang.String reportUUID;

    private java.lang.String reportName;

    private java.lang.String reportURL;

    private com.monsanto.teamtrack.aewebservices.domain.axis.ReportType reportType;

    private com.monsanto.teamtrack.aewebservices.domain.axis.ReportCategory reportCategory;

    private com.monsanto.teamtrack.aewebservices.domain.axis.ReportAccessLevel reportAccessLevel;

    private java.math.BigInteger solutionID;

    private java.lang.String solutionName;

    private java.math.BigInteger tableID;

    private java.math.BigInteger projectID;

    private java.lang.String projectName;

    private java.lang.String projectUUID;

    private java.lang.String createdBy;

    private java.util.Calendar createDate;

    private java.lang.String modifiedBy;

    private java.util.Calendar modifiedDate;

    private java.util.Calendar execDate;

    private boolean isQueryAtRuntime;

    public ReportInfo() {
    }

    public ReportInfo(
           java.math.BigInteger reportID,
           java.lang.String reportUUID,
           java.lang.String reportName,
           java.lang.String reportURL,
           com.monsanto.teamtrack.aewebservices.domain.axis.ReportType reportType,
           com.monsanto.teamtrack.aewebservices.domain.axis.ReportCategory reportCategory,
           com.monsanto.teamtrack.aewebservices.domain.axis.ReportAccessLevel reportAccessLevel,
           java.math.BigInteger solutionID,
           java.lang.String solutionName,
           java.math.BigInteger tableID,
           java.math.BigInteger projectID,
           java.lang.String projectName,
           java.lang.String projectUUID,
           java.lang.String createdBy,
           java.util.Calendar createDate,
           java.lang.String modifiedBy,
           java.util.Calendar modifiedDate,
           java.util.Calendar execDate,
           boolean isQueryAtRuntime) {
           this.reportID = reportID;
           this.reportUUID = reportUUID;
           this.reportName = reportName;
           this.reportURL = reportURL;
           this.reportType = reportType;
           this.reportCategory = reportCategory;
           this.reportAccessLevel = reportAccessLevel;
           this.solutionID = solutionID;
           this.solutionName = solutionName;
           this.tableID = tableID;
           this.projectID = projectID;
           this.projectName = projectName;
           this.projectUUID = projectUUID;
           this.createdBy = createdBy;
           this.createDate = createDate;
           this.modifiedBy = modifiedBy;
           this.modifiedDate = modifiedDate;
           this.execDate = execDate;
           this.isQueryAtRuntime = isQueryAtRuntime;
    }


    /**
     * Gets the reportID value for this ReportInfo.
     * 
     * @return reportID
     */
    public java.math.BigInteger getReportID() {
        return reportID;
    }


    /**
     * Sets the reportID value for this ReportInfo.
     * 
     * @param reportID
     */
    public void setReportID(java.math.BigInteger reportID) {
        this.reportID = reportID;
    }


    /**
     * Gets the reportUUID value for this ReportInfo.
     * 
     * @return reportUUID
     */
    public java.lang.String getReportUUID() {
        return reportUUID;
    }


    /**
     * Sets the reportUUID value for this ReportInfo.
     * 
     * @param reportUUID
     */
    public void setReportUUID(java.lang.String reportUUID) {
        this.reportUUID = reportUUID;
    }


    /**
     * Gets the reportName value for this ReportInfo.
     * 
     * @return reportName
     */
    public java.lang.String getReportName() {
        return reportName;
    }


    /**
     * Sets the reportName value for this ReportInfo.
     * 
     * @param reportName
     */
    public void setReportName(java.lang.String reportName) {
        this.reportName = reportName;
    }


    /**
     * Gets the reportURL value for this ReportInfo.
     * 
     * @return reportURL
     */
    public java.lang.String getReportURL() {
        return reportURL;
    }


    /**
     * Sets the reportURL value for this ReportInfo.
     * 
     * @param reportURL
     */
    public void setReportURL(java.lang.String reportURL) {
        this.reportURL = reportURL;
    }


    /**
     * Gets the reportType value for this ReportInfo.
     * 
     * @return reportType
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.ReportType getReportType() {
        return reportType;
    }


    /**
     * Sets the reportType value for this ReportInfo.
     * 
     * @param reportType
     */
    public void setReportType(com.monsanto.teamtrack.aewebservices.domain.axis.ReportType reportType) {
        this.reportType = reportType;
    }


    /**
     * Gets the reportCategory value for this ReportInfo.
     * 
     * @return reportCategory
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.ReportCategory getReportCategory() {
        return reportCategory;
    }


    /**
     * Sets the reportCategory value for this ReportInfo.
     * 
     * @param reportCategory
     */
    public void setReportCategory(com.monsanto.teamtrack.aewebservices.domain.axis.ReportCategory reportCategory) {
        this.reportCategory = reportCategory;
    }


    /**
     * Gets the reportAccessLevel value for this ReportInfo.
     * 
     * @return reportAccessLevel
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.ReportAccessLevel getReportAccessLevel() {
        return reportAccessLevel;
    }


    /**
     * Sets the reportAccessLevel value for this ReportInfo.
     * 
     * @param reportAccessLevel
     */
    public void setReportAccessLevel(com.monsanto.teamtrack.aewebservices.domain.axis.ReportAccessLevel reportAccessLevel) {
        this.reportAccessLevel = reportAccessLevel;
    }


    /**
     * Gets the solutionID value for this ReportInfo.
     * 
     * @return solutionID
     */
    public java.math.BigInteger getSolutionID() {
        return solutionID;
    }


    /**
     * Sets the solutionID value for this ReportInfo.
     * 
     * @param solutionID
     */
    public void setSolutionID(java.math.BigInteger solutionID) {
        this.solutionID = solutionID;
    }


    /**
     * Gets the solutionName value for this ReportInfo.
     * 
     * @return solutionName
     */
    public java.lang.String getSolutionName() {
        return solutionName;
    }


    /**
     * Sets the solutionName value for this ReportInfo.
     * 
     * @param solutionName
     */
    public void setSolutionName(java.lang.String solutionName) {
        this.solutionName = solutionName;
    }


    /**
     * Gets the tableID value for this ReportInfo.
     * 
     * @return tableID
     */
    public java.math.BigInteger getTableID() {
        return tableID;
    }


    /**
     * Sets the tableID value for this ReportInfo.
     * 
     * @param tableID
     */
    public void setTableID(java.math.BigInteger tableID) {
        this.tableID = tableID;
    }


    /**
     * Gets the projectID value for this ReportInfo.
     * 
     * @return projectID
     */
    public java.math.BigInteger getProjectID() {
        return projectID;
    }


    /**
     * Sets the projectID value for this ReportInfo.
     * 
     * @param projectID
     */
    public void setProjectID(java.math.BigInteger projectID) {
        this.projectID = projectID;
    }


    /**
     * Gets the projectName value for this ReportInfo.
     * 
     * @return projectName
     */
    public java.lang.String getProjectName() {
        return projectName;
    }


    /**
     * Sets the projectName value for this ReportInfo.
     * 
     * @param projectName
     */
    public void setProjectName(java.lang.String projectName) {
        this.projectName = projectName;
    }


    /**
     * Gets the projectUUID value for this ReportInfo.
     * 
     * @return projectUUID
     */
    public java.lang.String getProjectUUID() {
        return projectUUID;
    }


    /**
     * Sets the projectUUID value for this ReportInfo.
     * 
     * @param projectUUID
     */
    public void setProjectUUID(java.lang.String projectUUID) {
        this.projectUUID = projectUUID;
    }


    /**
     * Gets the createdBy value for this ReportInfo.
     * 
     * @return createdBy
     */
    public java.lang.String getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this ReportInfo.
     * 
     * @param createdBy
     */
    public void setCreatedBy(java.lang.String createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createDate value for this ReportInfo.
     * 
     * @return createDate
     */
    public java.util.Calendar getCreateDate() {
        return createDate;
    }


    /**
     * Sets the createDate value for this ReportInfo.
     * 
     * @param createDate
     */
    public void setCreateDate(java.util.Calendar createDate) {
        this.createDate = createDate;
    }


    /**
     * Gets the modifiedBy value for this ReportInfo.
     * 
     * @return modifiedBy
     */
    public java.lang.String getModifiedBy() {
        return modifiedBy;
    }


    /**
     * Sets the modifiedBy value for this ReportInfo.
     * 
     * @param modifiedBy
     */
    public void setModifiedBy(java.lang.String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }


    /**
     * Gets the modifiedDate value for this ReportInfo.
     * 
     * @return modifiedDate
     */
    public java.util.Calendar getModifiedDate() {
        return modifiedDate;
    }


    /**
     * Sets the modifiedDate value for this ReportInfo.
     * 
     * @param modifiedDate
     */
    public void setModifiedDate(java.util.Calendar modifiedDate) {
        this.modifiedDate = modifiedDate;
    }


    /**
     * Gets the execDate value for this ReportInfo.
     * 
     * @return execDate
     */
    public java.util.Calendar getExecDate() {
        return execDate;
    }


    /**
     * Sets the execDate value for this ReportInfo.
     * 
     * @param execDate
     */
    public void setExecDate(java.util.Calendar execDate) {
        this.execDate = execDate;
    }


    /**
     * Gets the isQueryAtRuntime value for this ReportInfo.
     * 
     * @return isQueryAtRuntime
     */
    public boolean isIsQueryAtRuntime() {
        return isQueryAtRuntime;
    }


    /**
     * Sets the isQueryAtRuntime value for this ReportInfo.
     * 
     * @param isQueryAtRuntime
     */
    public void setIsQueryAtRuntime(boolean isQueryAtRuntime) {
        this.isQueryAtRuntime = isQueryAtRuntime;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ReportInfo)) return false;
        ReportInfo other = (ReportInfo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.reportID==null && other.getReportID()==null) || 
             (this.reportID!=null &&
              this.reportID.equals(other.getReportID()))) &&
            ((this.reportUUID==null && other.getReportUUID()==null) || 
             (this.reportUUID!=null &&
              this.reportUUID.equals(other.getReportUUID()))) &&
            ((this.reportName==null && other.getReportName()==null) || 
             (this.reportName!=null &&
              this.reportName.equals(other.getReportName()))) &&
            ((this.reportURL==null && other.getReportURL()==null) || 
             (this.reportURL!=null &&
              this.reportURL.equals(other.getReportURL()))) &&
            ((this.reportType==null && other.getReportType()==null) || 
             (this.reportType!=null &&
              this.reportType.equals(other.getReportType()))) &&
            ((this.reportCategory==null && other.getReportCategory()==null) || 
             (this.reportCategory!=null &&
              this.reportCategory.equals(other.getReportCategory()))) &&
            ((this.reportAccessLevel==null && other.getReportAccessLevel()==null) || 
             (this.reportAccessLevel!=null &&
              this.reportAccessLevel.equals(other.getReportAccessLevel()))) &&
            ((this.solutionID==null && other.getSolutionID()==null) || 
             (this.solutionID!=null &&
              this.solutionID.equals(other.getSolutionID()))) &&
            ((this.solutionName==null && other.getSolutionName()==null) || 
             (this.solutionName!=null &&
              this.solutionName.equals(other.getSolutionName()))) &&
            ((this.tableID==null && other.getTableID()==null) || 
             (this.tableID!=null &&
              this.tableID.equals(other.getTableID()))) &&
            ((this.projectID==null && other.getProjectID()==null) || 
             (this.projectID!=null &&
              this.projectID.equals(other.getProjectID()))) &&
            ((this.projectName==null && other.getProjectName()==null) || 
             (this.projectName!=null &&
              this.projectName.equals(other.getProjectName()))) &&
            ((this.projectUUID==null && other.getProjectUUID()==null) || 
             (this.projectUUID!=null &&
              this.projectUUID.equals(other.getProjectUUID()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createDate==null && other.getCreateDate()==null) || 
             (this.createDate!=null &&
              this.createDate.equals(other.getCreateDate()))) &&
            ((this.modifiedBy==null && other.getModifiedBy()==null) || 
             (this.modifiedBy!=null &&
              this.modifiedBy.equals(other.getModifiedBy()))) &&
            ((this.modifiedDate==null && other.getModifiedDate()==null) || 
             (this.modifiedDate!=null &&
              this.modifiedDate.equals(other.getModifiedDate()))) &&
            ((this.execDate==null && other.getExecDate()==null) || 
             (this.execDate!=null &&
              this.execDate.equals(other.getExecDate()))) &&
            this.isQueryAtRuntime == other.isIsQueryAtRuntime();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getReportID() != null) {
            _hashCode += getReportID().hashCode();
        }
        if (getReportUUID() != null) {
            _hashCode += getReportUUID().hashCode();
        }
        if (getReportName() != null) {
            _hashCode += getReportName().hashCode();
        }
        if (getReportURL() != null) {
            _hashCode += getReportURL().hashCode();
        }
        if (getReportType() != null) {
            _hashCode += getReportType().hashCode();
        }
        if (getReportCategory() != null) {
            _hashCode += getReportCategory().hashCode();
        }
        if (getReportAccessLevel() != null) {
            _hashCode += getReportAccessLevel().hashCode();
        }
        if (getSolutionID() != null) {
            _hashCode += getSolutionID().hashCode();
        }
        if (getSolutionName() != null) {
            _hashCode += getSolutionName().hashCode();
        }
        if (getTableID() != null) {
            _hashCode += getTableID().hashCode();
        }
        if (getProjectID() != null) {
            _hashCode += getProjectID().hashCode();
        }
        if (getProjectName() != null) {
            _hashCode += getProjectName().hashCode();
        }
        if (getProjectUUID() != null) {
            _hashCode += getProjectUUID().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreateDate() != null) {
            _hashCode += getCreateDate().hashCode();
        }
        if (getModifiedBy() != null) {
            _hashCode += getModifiedBy().hashCode();
        }
        if (getModifiedDate() != null) {
            _hashCode += getModifiedDate().hashCode();
        }
        if (getExecDate() != null) {
            _hashCode += getExecDate().hashCode();
        }
        _hashCode += (isIsQueryAtRuntime() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ReportInfo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ReportInfo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportURL");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportURL"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ReportType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportCategory");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportCategory"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ReportCategory"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportAccessLevel");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportAccessLevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ReportAccessLevel"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solutionID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "solutionID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solutionName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "solutionName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tableID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "tableID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "createdBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "createDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "modifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "modifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("execDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "execDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isQueryAtRuntime");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "isQueryAtRuntime"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
