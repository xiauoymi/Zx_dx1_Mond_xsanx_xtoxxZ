
package com.monsanto.teamtrack.aewebservices.domain.axis;

public class SolutionType implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected SolutionType(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _value1 = "TEAMTRACK-SOLUTION";
    public static final java.lang.String _value2 = "USER-SOLUTION";
    public static final java.lang.String _value3 = "THIRDPARTY-SOLUTION";
    public static final SolutionType value1 = new SolutionType(_value1);
    public static final SolutionType value2 = new SolutionType(_value2);
    public static final SolutionType value3 = new SolutionType(_value3);
    public java.lang.String getValue() { return _value_;}
    public static SolutionType fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        SolutionType enumeration = (SolutionType)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static SolutionType fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SolutionType.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Solution-Type"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
