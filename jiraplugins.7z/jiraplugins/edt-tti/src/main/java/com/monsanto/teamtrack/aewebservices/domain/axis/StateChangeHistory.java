
package com.monsanto.teamtrack.aewebservices.domain.axis;

public class StateChangeHistory  implements java.io.Serializable {
    private java.math.BigInteger newStateID;

    private java.lang.String newStateName;

    private java.math.BigInteger transitionID;

    private java.lang.String transitionName;

    private java.util.Calendar time;

    private java.math.BigInteger userID;

    private java.lang.String userName;

    private java.math.BigInteger ownerID;

    private java.lang.String ownerName;

    public StateChangeHistory() {
    }

    public StateChangeHistory(
           java.math.BigInteger newStateID,
           java.lang.String newStateName,
           java.math.BigInteger transitionID,
           java.lang.String transitionName,
           java.util.Calendar time,
           java.math.BigInteger userID,
           java.lang.String userName,
           java.math.BigInteger ownerID,
           java.lang.String ownerName) {
           this.newStateID = newStateID;
           this.newStateName = newStateName;
           this.transitionID = transitionID;
           this.transitionName = transitionName;
           this.time = time;
           this.userID = userID;
           this.userName = userName;
           this.ownerID = ownerID;
           this.ownerName = ownerName;
    }


    /**
     * Gets the newStateID value for this StateChangeHistory.
     * 
     * @return newStateID
     */
    public java.math.BigInteger getNewStateID() {
        return newStateID;
    }


    /**
     * Sets the newStateID value for this StateChangeHistory.
     * 
     * @param newStateID
     */
    public void setNewStateID(java.math.BigInteger newStateID) {
        this.newStateID = newStateID;
    }


    /**
     * Gets the newStateName value for this StateChangeHistory.
     * 
     * @return newStateName
     */
    public java.lang.String getNewStateName() {
        return newStateName;
    }


    /**
     * Sets the newStateName value for this StateChangeHistory.
     * 
     * @param newStateName
     */
    public void setNewStateName(java.lang.String newStateName) {
        this.newStateName = newStateName;
    }


    /**
     * Gets the transitionID value for this StateChangeHistory.
     * 
     * @return transitionID
     */
    public java.math.BigInteger getTransitionID() {
        return transitionID;
    }


    /**
     * Sets the transitionID value for this StateChangeHistory.
     * 
     * @param transitionID
     */
    public void setTransitionID(java.math.BigInteger transitionID) {
        this.transitionID = transitionID;
    }


    /**
     * Gets the transitionName value for this StateChangeHistory.
     * 
     * @return transitionName
     */
    public java.lang.String getTransitionName() {
        return transitionName;
    }


    /**
     * Sets the transitionName value for this StateChangeHistory.
     * 
     * @param transitionName
     */
    public void setTransitionName(java.lang.String transitionName) {
        this.transitionName = transitionName;
    }


    /**
     * Gets the time value for this StateChangeHistory.
     * 
     * @return time
     */
    public java.util.Calendar getTime() {
        return time;
    }


    /**
     * Sets the time value for this StateChangeHistory.
     * 
     * @param time
     */
    public void setTime(java.util.Calendar time) {
        this.time = time;
    }


    /**
     * Gets the userID value for this StateChangeHistory.
     * 
     * @return userID
     */
    public java.math.BigInteger getUserID() {
        return userID;
    }


    /**
     * Sets the userID value for this StateChangeHistory.
     * 
     * @param userID
     */
    public void setUserID(java.math.BigInteger userID) {
        this.userID = userID;
    }


    /**
     * Gets the userName value for this StateChangeHistory.
     * 
     * @return userName
     */
    public java.lang.String getUserName() {
        return userName;
    }


    /**
     * Sets the userName value for this StateChangeHistory.
     * 
     * @param userName
     */
    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }


    /**
     * Gets the ownerID value for this StateChangeHistory.
     * 
     * @return ownerID
     */
    public java.math.BigInteger getOwnerID() {
        return ownerID;
    }


    /**
     * Sets the ownerID value for this StateChangeHistory.
     * 
     * @param ownerID
     */
    public void setOwnerID(java.math.BigInteger ownerID) {
        this.ownerID = ownerID;
    }


    /**
     * Gets the ownerName value for this StateChangeHistory.
     * 
     * @return ownerName
     */
    public java.lang.String getOwnerName() {
        return ownerName;
    }


    /**
     * Sets the ownerName value for this StateChangeHistory.
     * 
     * @param ownerName
     */
    public void setOwnerName(java.lang.String ownerName) {
        this.ownerName = ownerName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof StateChangeHistory)) return false;
        StateChangeHistory other = (StateChangeHistory) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.newStateID==null && other.getNewStateID()==null) || 
             (this.newStateID!=null &&
              this.newStateID.equals(other.getNewStateID()))) &&
            ((this.newStateName==null && other.getNewStateName()==null) || 
             (this.newStateName!=null &&
              this.newStateName.equals(other.getNewStateName()))) &&
            ((this.transitionID==null && other.getTransitionID()==null) || 
             (this.transitionID!=null &&
              this.transitionID.equals(other.getTransitionID()))) &&
            ((this.transitionName==null && other.getTransitionName()==null) || 
             (this.transitionName!=null &&
              this.transitionName.equals(other.getTransitionName()))) &&
            ((this.time==null && other.getTime()==null) || 
             (this.time!=null &&
              this.time.equals(other.getTime()))) &&
            ((this.userID==null && other.getUserID()==null) || 
             (this.userID!=null &&
              this.userID.equals(other.getUserID()))) &&
            ((this.userName==null && other.getUserName()==null) || 
             (this.userName!=null &&
              this.userName.equals(other.getUserName()))) &&
            ((this.ownerID==null && other.getOwnerID()==null) || 
             (this.ownerID!=null &&
              this.ownerID.equals(other.getOwnerID()))) &&
            ((this.ownerName==null && other.getOwnerName()==null) || 
             (this.ownerName!=null &&
              this.ownerName.equals(other.getOwnerName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNewStateID() != null) {
            _hashCode += getNewStateID().hashCode();
        }
        if (getNewStateName() != null) {
            _hashCode += getNewStateName().hashCode();
        }
        if (getTransitionID() != null) {
            _hashCode += getTransitionID().hashCode();
        }
        if (getTransitionName() != null) {
            _hashCode += getTransitionName().hashCode();
        }
        if (getTime() != null) {
            _hashCode += getTime().hashCode();
        }
        if (getUserID() != null) {
            _hashCode += getUserID().hashCode();
        }
        if (getUserName() != null) {
            _hashCode += getUserName().hashCode();
        }
        if (getOwnerID() != null) {
            _hashCode += getOwnerID().hashCode();
        }
        if (getOwnerName() != null) {
            _hashCode += getOwnerName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(StateChangeHistory.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "StateChangeHistory"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("newStateID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "newStateID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("newStateName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "newStateName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transitionID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "transitionID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transitionName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "transitionName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("time");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "time"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "userID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "userName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "ownerID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ownerName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "ownerName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
