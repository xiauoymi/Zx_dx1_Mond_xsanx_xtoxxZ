
package com.monsanto.teamtrack.aewebservices.domain.axis;

public class TTItem  implements java.io.Serializable {
    private com.monsanto.teamtrack.aewebservices.domain.axis.Item genericItem;

    private java.lang.String itemType;

    private java.lang.String classification;

    private java.lang.String classificationUUID;

    private java.lang.String title;

    private java.lang.String description;

    private java.lang.String createdBy;

    private java.util.Calendar createDate;

    private java.lang.String modifiedBy;

    private java.util.Calendar modifiedDate;

    private java.lang.String activeInactive;

    private java.lang.String state;

    private java.lang.String owner;

    private java.lang.String url;

    private com.monsanto.teamtrack.aewebservices.domain.axis.NameValue[] extendedFieldList;

    private com.monsanto.teamtrack.aewebservices.domain.axis.Note[] noteList;

    private com.monsanto.teamtrack.aewebservices.domain.axis.ItemLink[] itemLinkList;

    private com.monsanto.teamtrack.aewebservices.domain.axis.URLAttachment[] urlAttachmentList;

    private com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachment[] fileAttachmentList;

    public TTItem() {
    }

    public TTItem(
           com.monsanto.teamtrack.aewebservices.domain.axis.Item genericItem,
           java.lang.String itemType,
           java.lang.String classification,
           java.lang.String classificationUUID,
           java.lang.String title,
           java.lang.String description,
           java.lang.String createdBy,
           java.util.Calendar createDate,
           java.lang.String modifiedBy,
           java.util.Calendar modifiedDate,
           java.lang.String activeInactive,
           java.lang.String state,
           java.lang.String owner,
           java.lang.String url,
           com.monsanto.teamtrack.aewebservices.domain.axis.NameValue[] extendedFieldList,
           com.monsanto.teamtrack.aewebservices.domain.axis.Note[] noteList,
           com.monsanto.teamtrack.aewebservices.domain.axis.ItemLink[] itemLinkList,
           com.monsanto.teamtrack.aewebservices.domain.axis.URLAttachment[] urlAttachmentList,
           com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachment[] fileAttachmentList) {
           this.genericItem = genericItem;
           this.itemType = itemType;
           this.classification = classification;
           this.classificationUUID = classificationUUID;
           this.title = title;
           this.description = description;
           this.createdBy = createdBy;
           this.createDate = createDate;
           this.modifiedBy = modifiedBy;
           this.modifiedDate = modifiedDate;
           this.activeInactive = activeInactive;
           this.state = state;
           this.owner = owner;
           this.url = url;
           this.extendedFieldList = extendedFieldList;
           this.noteList = noteList;
           this.itemLinkList = itemLinkList;
           this.urlAttachmentList = urlAttachmentList;
           this.fileAttachmentList = fileAttachmentList;
    }


    /**
     * Gets the genericItem value for this TTItem.
     * 
     * @return genericItem
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Item getGenericItem() {
        return genericItem;
    }


    /**
     * Sets the genericItem value for this TTItem.
     * 
     * @param genericItem
     */
    public void setGenericItem(com.monsanto.teamtrack.aewebservices.domain.axis.Item genericItem) {
        this.genericItem = genericItem;
    }


    /**
     * Gets the itemType value for this TTItem.
     * 
     * @return itemType
     */
    public java.lang.String getItemType() {
        return itemType;
    }


    /**
     * Sets the itemType value for this TTItem.
     * 
     * @param itemType
     */
    public void setItemType(java.lang.String itemType) {
        this.itemType = itemType;
    }


    /**
     * Gets the classification value for this TTItem.
     * 
     * @return classification
     */
    public java.lang.String getClassification() {
        return classification;
    }


    /**
     * Sets the classification value for this TTItem.
     * 
     * @param classification
     */
    public void setClassification(java.lang.String classification) {
        this.classification = classification;
    }


    /**
     * Gets the classificationUUID value for this TTItem.
     * 
     * @return classificationUUID
     */
    public java.lang.String getClassificationUUID() {
        return classificationUUID;
    }


    /**
     * Sets the classificationUUID value for this TTItem.
     * 
     * @param classificationUUID
     */
    public void setClassificationUUID(java.lang.String classificationUUID) {
        this.classificationUUID = classificationUUID;
    }


    /**
     * Gets the title value for this TTItem.
     * 
     * @return title
     */
    public java.lang.String getTitle() {
        return title;
    }


    /**
     * Sets the title value for this TTItem.
     * 
     * @param title
     */
    public void setTitle(java.lang.String title) {
        this.title = title;
    }


    /**
     * Gets the description value for this TTItem.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this TTItem.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the createdBy value for this TTItem.
     * 
     * @return createdBy
     */
    public java.lang.String getCreatedBy() {
        return createdBy;
    }


    /**
     * Sets the createdBy value for this TTItem.
     * 
     * @param createdBy
     */
    public void setCreatedBy(java.lang.String createdBy) {
        this.createdBy = createdBy;
    }


    /**
     * Gets the createDate value for this TTItem.
     * 
     * @return createDate
     */
    public java.util.Calendar getCreateDate() {
        return createDate;
    }


    /**
     * Sets the createDate value for this TTItem.
     * 
     * @param createDate
     */
    public void setCreateDate(java.util.Calendar createDate) {
        this.createDate = createDate;
    }


    /**
     * Gets the modifiedBy value for this TTItem.
     * 
     * @return modifiedBy
     */
    public java.lang.String getModifiedBy() {
        return modifiedBy;
    }


    /**
     * Sets the modifiedBy value for this TTItem.
     * 
     * @param modifiedBy
     */
    public void setModifiedBy(java.lang.String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }


    /**
     * Gets the modifiedDate value for this TTItem.
     * 
     * @return modifiedDate
     */
    public java.util.Calendar getModifiedDate() {
        return modifiedDate;
    }


    /**
     * Sets the modifiedDate value for this TTItem.
     * 
     * @param modifiedDate
     */
    public void setModifiedDate(java.util.Calendar modifiedDate) {
        this.modifiedDate = modifiedDate;
    }


    /**
     * Gets the activeInactive value for this TTItem.
     * 
     * @return activeInactive
     */
    public java.lang.String getActiveInactive() {
        return activeInactive;
    }


    /**
     * Sets the activeInactive value for this TTItem.
     * 
     * @param activeInactive
     */
    public void setActiveInactive(java.lang.String activeInactive) {
        this.activeInactive = activeInactive;
    }


    /**
     * Gets the state value for this TTItem.
     * 
     * @return state
     */
    public java.lang.String getState() {
        return state;
    }


    /**
     * Sets the state value for this TTItem.
     * 
     * @param state
     */
    public void setState(java.lang.String state) {
        this.state = state;
    }


    /**
     * Gets the owner value for this TTItem.
     * 
     * @return owner
     */
    public java.lang.String getOwner() {
        return owner;
    }


    /**
     * Sets the owner value for this TTItem.
     * 
     * @param owner
     */
    public void setOwner(java.lang.String owner) {
        this.owner = owner;
    }


    /**
     * Gets the url value for this TTItem.
     * 
     * @return url
     */
    public java.lang.String getUrl() {
        return url;
    }


    /**
     * Sets the url value for this TTItem.
     * 
     * @param url
     */
    public void setUrl(java.lang.String url) {
        this.url = url;
    }


    /**
     * Gets the extendedFieldList value for this TTItem.
     * 
     * @return extendedFieldList
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.NameValue[] getExtendedFieldList() {
        return extendedFieldList;
    }


    /**
     * Sets the extendedFieldList value for this TTItem.
     * 
     * @param extendedFieldList
     */
    public void setExtendedFieldList(com.monsanto.teamtrack.aewebservices.domain.axis.NameValue[] extendedFieldList) {
        this.extendedFieldList = extendedFieldList;
    }

    public com.monsanto.teamtrack.aewebservices.domain.axis.NameValue getExtendedFieldList(int i) {
        return this.extendedFieldList[i];
    }

    public void setExtendedFieldList(int i, com.monsanto.teamtrack.aewebservices.domain.axis.NameValue _value) {
        this.extendedFieldList[i] = _value;
    }


    /**
     * Gets the noteList value for this TTItem.
     * 
     * @return noteList
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Note[] getNoteList() {
        return noteList;
    }


    /**
     * Sets the noteList value for this TTItem.
     * 
     * @param noteList
     */
    public void setNoteList(com.monsanto.teamtrack.aewebservices.domain.axis.Note[] noteList) {
        this.noteList = noteList;
    }

    public com.monsanto.teamtrack.aewebservices.domain.axis.Note getNoteList(int i) {
        return this.noteList[i];
    }

    public void setNoteList(int i, com.monsanto.teamtrack.aewebservices.domain.axis.Note _value) {
        this.noteList[i] = _value;
    }


    /**
     * Gets the itemLinkList value for this TTItem.
     * 
     * @return itemLinkList
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.ItemLink[] getItemLinkList() {
        return itemLinkList;
    }


    /**
     * Sets the itemLinkList value for this TTItem.
     * 
     * @param itemLinkList
     */
    public void setItemLinkList(com.monsanto.teamtrack.aewebservices.domain.axis.ItemLink[] itemLinkList) {
        this.itemLinkList = itemLinkList;
    }

    public com.monsanto.teamtrack.aewebservices.domain.axis.ItemLink getItemLinkList(int i) {
        return this.itemLinkList[i];
    }

    public void setItemLinkList(int i, com.monsanto.teamtrack.aewebservices.domain.axis.ItemLink _value) {
        this.itemLinkList[i] = _value;
    }


    /**
     * Gets the urlAttachmentList value for this TTItem.
     * 
     * @return urlAttachmentList
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.URLAttachment[] getUrlAttachmentList() {
        return urlAttachmentList;
    }


    /**
     * Sets the urlAttachmentList value for this TTItem.
     * 
     * @param urlAttachmentList
     */
    public void setUrlAttachmentList(com.monsanto.teamtrack.aewebservices.domain.axis.URLAttachment[] urlAttachmentList) {
        this.urlAttachmentList = urlAttachmentList;
    }

    public com.monsanto.teamtrack.aewebservices.domain.axis.URLAttachment getUrlAttachmentList(int i) {
        return this.urlAttachmentList[i];
    }

    public void setUrlAttachmentList(int i, com.monsanto.teamtrack.aewebservices.domain.axis.URLAttachment _value) {
        this.urlAttachmentList[i] = _value;
    }


    /**
     * Gets the fileAttachmentList value for this TTItem.
     * 
     * @return fileAttachmentList
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachment[] getFileAttachmentList() {
        return fileAttachmentList;
    }


    /**
     * Sets the fileAttachmentList value for this TTItem.
     * 
     * @param fileAttachmentList
     */
    public void setFileAttachmentList(com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachment[] fileAttachmentList) {
        this.fileAttachmentList = fileAttachmentList;
    }

    public com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachment getFileAttachmentList(int i) {
        return this.fileAttachmentList[i];
    }

    public void setFileAttachmentList(int i, com.monsanto.teamtrack.aewebservices.domain.axis.FileAttachment _value) {
        this.fileAttachmentList[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TTItem)) return false;
        TTItem other = (TTItem) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.genericItem==null && other.getGenericItem()==null) || 
             (this.genericItem!=null &&
              this.genericItem.equals(other.getGenericItem()))) &&
            ((this.itemType==null && other.getItemType()==null) || 
             (this.itemType!=null &&
              this.itemType.equals(other.getItemType()))) &&
            ((this.classification==null && other.getClassification()==null) || 
             (this.classification!=null &&
              this.classification.equals(other.getClassification()))) &&
            ((this.classificationUUID==null && other.getClassificationUUID()==null) || 
             (this.classificationUUID!=null &&
              this.classificationUUID.equals(other.getClassificationUUID()))) &&
            ((this.title==null && other.getTitle()==null) || 
             (this.title!=null &&
              this.title.equals(other.getTitle()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.createdBy==null && other.getCreatedBy()==null) || 
             (this.createdBy!=null &&
              this.createdBy.equals(other.getCreatedBy()))) &&
            ((this.createDate==null && other.getCreateDate()==null) || 
             (this.createDate!=null &&
              this.createDate.equals(other.getCreateDate()))) &&
            ((this.modifiedBy==null && other.getModifiedBy()==null) || 
             (this.modifiedBy!=null &&
              this.modifiedBy.equals(other.getModifiedBy()))) &&
            ((this.modifiedDate==null && other.getModifiedDate()==null) || 
             (this.modifiedDate!=null &&
              this.modifiedDate.equals(other.getModifiedDate()))) &&
            ((this.activeInactive==null && other.getActiveInactive()==null) || 
             (this.activeInactive!=null &&
              this.activeInactive.equals(other.getActiveInactive()))) &&
            ((this.state==null && other.getState()==null) || 
             (this.state!=null &&
              this.state.equals(other.getState()))) &&
            ((this.owner==null && other.getOwner()==null) || 
             (this.owner!=null &&
              this.owner.equals(other.getOwner()))) &&
            ((this.url==null && other.getUrl()==null) || 
             (this.url!=null &&
              this.url.equals(other.getUrl()))) &&
            ((this.extendedFieldList==null && other.getExtendedFieldList()==null) || 
             (this.extendedFieldList!=null &&
              java.util.Arrays.equals(this.extendedFieldList, other.getExtendedFieldList()))) &&
            ((this.noteList==null && other.getNoteList()==null) || 
             (this.noteList!=null &&
              java.util.Arrays.equals(this.noteList, other.getNoteList()))) &&
            ((this.itemLinkList==null && other.getItemLinkList()==null) || 
             (this.itemLinkList!=null &&
              java.util.Arrays.equals(this.itemLinkList, other.getItemLinkList()))) &&
            ((this.urlAttachmentList==null && other.getUrlAttachmentList()==null) || 
             (this.urlAttachmentList!=null &&
              java.util.Arrays.equals(this.urlAttachmentList, other.getUrlAttachmentList()))) &&
            ((this.fileAttachmentList==null && other.getFileAttachmentList()==null) || 
             (this.fileAttachmentList!=null &&
              java.util.Arrays.equals(this.fileAttachmentList, other.getFileAttachmentList())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getGenericItem() != null) {
            _hashCode += getGenericItem().hashCode();
        }
        if (getItemType() != null) {
            _hashCode += getItemType().hashCode();
        }
        if (getClassification() != null) {
            _hashCode += getClassification().hashCode();
        }
        if (getClassificationUUID() != null) {
            _hashCode += getClassificationUUID().hashCode();
        }
        if (getTitle() != null) {
            _hashCode += getTitle().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getCreatedBy() != null) {
            _hashCode += getCreatedBy().hashCode();
        }
        if (getCreateDate() != null) {
            _hashCode += getCreateDate().hashCode();
        }
        if (getModifiedBy() != null) {
            _hashCode += getModifiedBy().hashCode();
        }
        if (getModifiedDate() != null) {
            _hashCode += getModifiedDate().hashCode();
        }
        if (getActiveInactive() != null) {
            _hashCode += getActiveInactive().hashCode();
        }
        if (getState() != null) {
            _hashCode += getState().hashCode();
        }
        if (getOwner() != null) {
            _hashCode += getOwner().hashCode();
        }
        if (getUrl() != null) {
            _hashCode += getUrl().hashCode();
        }
        if (getExtendedFieldList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getExtendedFieldList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getExtendedFieldList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNoteList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNoteList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNoteList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getItemLinkList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getItemLinkList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getItemLinkList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getUrlAttachmentList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getUrlAttachmentList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getUrlAttachmentList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getFileAttachmentList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getFileAttachmentList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getFileAttachmentList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TTItem.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("genericItem");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "genericItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Item"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("itemType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "itemType"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("classification");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "classification"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("classificationUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "classificationUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("title");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "title"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "createdBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "createDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "modifiedBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("modifiedDate");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "modifiedDate"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activeInactive");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "activeInactive"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("state");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "state"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("owner");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "owner"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("url");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "url"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("extendedFieldList");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "extendedFieldList"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "NameValue"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noteList");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "noteList"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Note"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("itemLinkList");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "itemLinkList"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ItemLink"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("urlAttachmentList");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "urlAttachmentList"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "URLAttachment"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fileAttachmentList");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "fileAttachmentList"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "FileAttachment"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
