
package com.monsanto.teamtrack.aewebservices.domain.axis;

public class TableData  implements java.io.Serializable {
    private java.math.BigInteger tableID;

    private java.lang.String tableUUID;

    private java.math.BigInteger solutionID;

    private com.monsanto.teamtrack.aewebservices.domain.axis.TableType type;

    private java.lang.String name;

    private java.lang.String displayName;

    private java.lang.String description;

    private com.monsanto.teamtrack.aewebservices.domain.axis.Field[] fieldList;

    public TableData() {
    }

    public TableData(
           java.math.BigInteger tableID,
           java.lang.String tableUUID,
           java.math.BigInteger solutionID,
           com.monsanto.teamtrack.aewebservices.domain.axis.TableType type,
           java.lang.String name,
           java.lang.String displayName,
           java.lang.String description,
           com.monsanto.teamtrack.aewebservices.domain.axis.Field[] fieldList) {
           this.tableID = tableID;
           this.tableUUID = tableUUID;
           this.solutionID = solutionID;
           this.type = type;
           this.name = name;
           this.displayName = displayName;
           this.description = description;
           this.fieldList = fieldList;
    }


    /**
     * Gets the tableID value for this TableData.
     * 
     * @return tableID
     */
    public java.math.BigInteger getTableID() {
        return tableID;
    }


    /**
     * Sets the tableID value for this TableData.
     * 
     * @param tableID
     */
    public void setTableID(java.math.BigInteger tableID) {
        this.tableID = tableID;
    }


    /**
     * Gets the tableUUID value for this TableData.
     * 
     * @return tableUUID
     */
    public java.lang.String getTableUUID() {
        return tableUUID;
    }


    /**
     * Sets the tableUUID value for this TableData.
     * 
     * @param tableUUID
     */
    public void setTableUUID(java.lang.String tableUUID) {
        this.tableUUID = tableUUID;
    }


    /**
     * Gets the solutionID value for this TableData.
     * 
     * @return solutionID
     */
    public java.math.BigInteger getSolutionID() {
        return solutionID;
    }


    /**
     * Sets the solutionID value for this TableData.
     * 
     * @param solutionID
     */
    public void setSolutionID(java.math.BigInteger solutionID) {
        this.solutionID = solutionID;
    }


    /**
     * Gets the type value for this TableData.
     * 
     * @return type
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.TableType getType() {
        return type;
    }


    /**
     * Sets the type value for this TableData.
     * 
     * @param type
     */
    public void setType(com.monsanto.teamtrack.aewebservices.domain.axis.TableType type) {
        this.type = type;
    }


    /**
     * Gets the name value for this TableData.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this TableData.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the displayName value for this TableData.
     * 
     * @return displayName
     */
    public java.lang.String getDisplayName() {
        return displayName;
    }


    /**
     * Sets the displayName value for this TableData.
     * 
     * @param displayName
     */
    public void setDisplayName(java.lang.String displayName) {
        this.displayName = displayName;
    }


    /**
     * Gets the description value for this TableData.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this TableData.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the fieldList value for this TableData.
     * 
     * @return fieldList
     */
    public com.monsanto.teamtrack.aewebservices.domain.axis.Field[] getFieldList() {
        return fieldList;
    }


    /**
     * Sets the fieldList value for this TableData.
     * 
     * @param fieldList
     */
    public void setFieldList(com.monsanto.teamtrack.aewebservices.domain.axis.Field[] fieldList) {
        this.fieldList = fieldList;
    }

    public com.monsanto.teamtrack.aewebservices.domain.axis.Field getFieldList(int i) {
        return this.fieldList[i];
    }

    public void setFieldList(int i, com.monsanto.teamtrack.aewebservices.domain.axis.Field _value) {
        this.fieldList[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TableData)) return false;
        TableData other = (TableData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.tableID==null && other.getTableID()==null) || 
             (this.tableID!=null &&
              this.tableID.equals(other.getTableID()))) &&
            ((this.tableUUID==null && other.getTableUUID()==null) || 
             (this.tableUUID!=null &&
              this.tableUUID.equals(other.getTableUUID()))) &&
            ((this.solutionID==null && other.getSolutionID()==null) || 
             (this.solutionID!=null &&
              this.solutionID.equals(other.getSolutionID()))) &&
            ((this.type==null && other.getType()==null) || 
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.displayName==null && other.getDisplayName()==null) || 
             (this.displayName!=null &&
              this.displayName.equals(other.getDisplayName()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.fieldList==null && other.getFieldList()==null) || 
             (this.fieldList!=null &&
              java.util.Arrays.equals(this.fieldList, other.getFieldList())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTableID() != null) {
            _hashCode += getTableID().hashCode();
        }
        if (getTableUUID() != null) {
            _hashCode += getTableUUID().hashCode();
        }
        if (getSolutionID() != null) {
            _hashCode += getSolutionID().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getDisplayName() != null) {
            _hashCode += getDisplayName().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getFieldList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getFieldList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getFieldList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TableData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "TableData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tableID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "tableID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tableUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "tableUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solutionID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "solutionID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Table-Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("displayName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "displayName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fieldList");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "fieldList"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Field"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
