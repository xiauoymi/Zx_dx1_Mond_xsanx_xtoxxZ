
package com.monsanto.teamtrack.aewebservices.domain.axis;

public class User  implements java.io.Serializable {
    private java.lang.String userId;

    private java.lang.String userName;

    private java.math.BigInteger id;

    private java.lang.String uuid;

    private java.lang.String email;

    private java.lang.String emailCC;

    private java.lang.String timezone;

    private java.math.BigInteger offsetFromGMT;

    private java.math.BigInteger dstSavings;

    private java.lang.String namespaceName;

    public User() {
    }

    public User(
           java.lang.String userId,
           java.lang.String userName,
           java.math.BigInteger id,
           java.lang.String uuid,
           java.lang.String email,
           java.lang.String emailCC,
           java.lang.String timezone,
           java.math.BigInteger offsetFromGMT,
           java.math.BigInteger dstSavings,
           java.lang.String namespaceName) {
           this.userId = userId;
           this.userName = userName;
           this.id = id;
           this.uuid = uuid;
           this.email = email;
           this.emailCC = emailCC;
           this.timezone = timezone;
           this.offsetFromGMT = offsetFromGMT;
           this.dstSavings = dstSavings;
           this.namespaceName = namespaceName;
    }


    /**
     * Gets the userId value for this User.
     * 
     * @return userId
     */
    public java.lang.String getUserId() {
        return userId;
    }


    /**
     * Sets the userId value for this User.
     * 
     * @param userId
     */
    public void setUserId(java.lang.String userId) {
        this.userId = userId;
    }


    /**
     * Gets the userName value for this User.
     * 
     * @return userName
     */
    public java.lang.String getUserName() {
        return userName;
    }


    /**
     * Sets the userName value for this User.
     * 
     * @param userName
     */
    public void setUserName(java.lang.String userName) {
        this.userName = userName;
    }


    /**
     * Gets the id value for this User.
     * 
     * @return id
     */
    public java.math.BigInteger getId() {
        return id;
    }


    /**
     * Sets the id value for this User.
     * 
     * @param id
     */
    public void setId(java.math.BigInteger id) {
        this.id = id;
    }


    /**
     * Gets the uuid value for this User.
     * 
     * @return uuid
     */
    public java.lang.String getUuid() {
        return uuid;
    }


    /**
     * Sets the uuid value for this User.
     * 
     * @param uuid
     */
    public void setUuid(java.lang.String uuid) {
        this.uuid = uuid;
    }


    /**
     * Gets the email value for this User.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this User.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the emailCC value for this User.
     * 
     * @return emailCC
     */
    public java.lang.String getEmailCC() {
        return emailCC;
    }


    /**
     * Sets the emailCC value for this User.
     * 
     * @param emailCC
     */
    public void setEmailCC(java.lang.String emailCC) {
        this.emailCC = emailCC;
    }


    /**
     * Gets the timezone value for this User.
     * 
     * @return timezone
     */
    public java.lang.String getTimezone() {
        return timezone;
    }


    /**
     * Sets the timezone value for this User.
     * 
     * @param timezone
     */
    public void setTimezone(java.lang.String timezone) {
        this.timezone = timezone;
    }


    /**
     * Gets the offsetFromGMT value for this User.
     * 
     * @return offsetFromGMT
     */
    public java.math.BigInteger getOffsetFromGMT() {
        return offsetFromGMT;
    }


    /**
     * Sets the offsetFromGMT value for this User.
     * 
     * @param offsetFromGMT
     */
    public void setOffsetFromGMT(java.math.BigInteger offsetFromGMT) {
        this.offsetFromGMT = offsetFromGMT;
    }


    /**
     * Gets the dstSavings value for this User.
     * 
     * @return dstSavings
     */
    public java.math.BigInteger getDstSavings() {
        return dstSavings;
    }


    /**
     * Sets the dstSavings value for this User.
     * 
     * @param dstSavings
     */
    public void setDstSavings(java.math.BigInteger dstSavings) {
        this.dstSavings = dstSavings;
    }


    /**
     * Gets the namespaceName value for this User.
     * 
     * @return namespaceName
     */
    public java.lang.String getNamespaceName() {
        return namespaceName;
    }


    /**
     * Sets the namespaceName value for this User.
     * 
     * @param namespaceName
     */
    public void setNamespaceName(java.lang.String namespaceName) {
        this.namespaceName = namespaceName;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof User)) return false;
        User other = (User) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.userId==null && other.getUserId()==null) || 
             (this.userId!=null &&
              this.userId.equals(other.getUserId()))) &&
            ((this.userName==null && other.getUserName()==null) || 
             (this.userName!=null &&
              this.userName.equals(other.getUserName()))) &&
            ((this.id==null && other.getId()==null) || 
             (this.id!=null &&
              this.id.equals(other.getId()))) &&
            ((this.uuid==null && other.getUuid()==null) || 
             (this.uuid!=null &&
              this.uuid.equals(other.getUuid()))) &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.emailCC==null && other.getEmailCC()==null) || 
             (this.emailCC!=null &&
              this.emailCC.equals(other.getEmailCC()))) &&
            ((this.timezone==null && other.getTimezone()==null) || 
             (this.timezone!=null &&
              this.timezone.equals(other.getTimezone()))) &&
            ((this.offsetFromGMT==null && other.getOffsetFromGMT()==null) || 
             (this.offsetFromGMT!=null &&
              this.offsetFromGMT.equals(other.getOffsetFromGMT()))) &&
            ((this.dstSavings==null && other.getDstSavings()==null) || 
             (this.dstSavings!=null &&
              this.dstSavings.equals(other.getDstSavings()))) &&
            ((this.namespaceName==null && other.getNamespaceName()==null) || 
             (this.namespaceName!=null &&
              this.namespaceName.equals(other.getNamespaceName())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUserId() != null) {
            _hashCode += getUserId().hashCode();
        }
        if (getUserName() != null) {
            _hashCode += getUserName().hashCode();
        }
        if (getId() != null) {
            _hashCode += getId().hashCode();
        }
        if (getUuid() != null) {
            _hashCode += getUuid().hashCode();
        }
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getEmailCC() != null) {
            _hashCode += getEmailCC().hashCode();
        }
        if (getTimezone() != null) {
            _hashCode += getTimezone().hashCode();
        }
        if (getOffsetFromGMT() != null) {
            _hashCode += getOffsetFromGMT().hashCode();
        }
        if (getDstSavings() != null) {
            _hashCode += getDstSavings().hashCode();
        }
        if (getNamespaceName() != null) {
            _hashCode += getNamespaceName().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(User.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "User"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userId");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "userId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("userName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "userName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uuid");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "uuid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailCC");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "emailCC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timezone");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "timezone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("offsetFromGMT");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "offsetFromGMT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dstSavings");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "dstSavings"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("namespaceName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "namespaceName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
