function getConfigDescriptor(args, gadget) {
    return {
        fields:[
            AJS.gadget.fields.nowConfigured(),
            {
                id: "title",
                userpref: "title",
                label: "Title:",
                description: "Title of the gadget as it will appear on your dashboard.",
                type: "text",
                value: gadget.getPref("title"),
                required: true
            }

            ,{
                id: "reportId",
                userpref: "reportId",
                label: "Report ID:",
                description: "The ID of the Teamtrack report, visible at the end of the report URL.  You have to copy the report URL from Teamtrack since it is usually hidden.  Read the wiki for report requirements.",
                type: "text",
                value: gadget.getPref("reportId"),
                required: true
            }

            ,{
                id: "myProjectDiv",
                label: "Project:",
                type: "callbackBuilder",
                callback: function(parentDiv) {
                    parentDiv.append(AJS.$("<div/>").html(function() {
                        var options = getProjects(args, gadget);
                        refreshSelectDiv(options, gadget.getPref("projectId"), AJS.$("#myProjectDiv"), "projectId");
                    }));
                    parentDiv.parent().append(AJS.$("<div class=\"description\"/>").html("New issues will be created in this project.  If the issue on the Teamtrack report already exists in this project it won't be imported again."));
                }
            }

            ,{
                id: "myComponentDiv",
                label: "Component:",
                type: "callbackBuilder",
                callback: function(parentDiv) {
                    var cb = function() {
                        var options = getComponents(getCurrentProject(args, gadget));
                        refreshSelectDiv(options, gadget.getPref("componentId"), AJS.$("#myComponentDiv"), "componentId");
                    };
                    parentDiv.append(AJS.$("<div/>").html(cb));
                    AJS.$("#myProjectDiv").change(cb);
                    parentDiv.parent().append(AJS.$("<div class=\"description\"/>").html("New issues will be created using this project component.  Project components are a good way to break up your project into logical pieces."));
                }
            }

            ,{
                id: "myVersionDiv",
                label: "Version:",
                type: "callbackBuilder",
                callback: function(parentDiv) {
                    var cb = function() {
                        var options = getVersions(getCurrentProject(args, gadget));
                        refreshSelectDiv(options, gadget.getPref("versionId"), AJS.$("#myVersionDiv"), "versionId");
                    };
                    parentDiv.append(AJS.$("<div/>").html(cb));
                    AJS.$("#myProjectDiv").change(cb);
                    parentDiv.parent().append(AJS.$("<div class=\"description\"/>").html("New issues will be created using this project version."));
                }
            }

            ,{
                id: "myIssueTypeDiv",
                label: "Issue Type:",
                type: "callbackBuilder",
                callback: function(parentDiv) {
                    var cb = function() {
                        var options = getIssueTypes(getCurrentProject(args, gadget));
                        refreshSelectDiv(options, gadget.getPref("issueTypeId"), AJS.$("#myIssueTypeDiv"), "issueTypeId");
                    };
                    parentDiv.append(AJS.$("<div/>").html(cb));
                    AJS.$("#myProjectDiv").change(cb);
                    parentDiv.parent().append(AJS.$("<div class=\"description\"/>").html("New issues will be created as this type."));
                }
            }

            ,{
                id: "showCompletedIssuesDiv",
                label: "Flag Completed:",
                type: "callbackBuilder",
                callback: function(parentDiv) {
                    var cb = function() {
                        var selected = gadget.getPref("showCompletedIssues");
                        var input = jQuery('<input type="checkbox" name="showCompletedIssues"/>');
                        if(selected == "on"){
                            input = jQuery('<input type="checkbox" name="showCompletedIssues" checked/>');
                        }
                        parentDiv.html(input);
                    };
                    parentDiv.append(AJS.$("<div/>").html(cb));
                    parentDiv.parent().append(AJS.$("<div class=\"description\"/>").html("Flag issues that are on your Teamtrack report but are completed in Jira.  This helps you know when to complete Teamtracks."));
                }
            }
        ]
    };
}

function refreshSelectDiv(options, selectedOptionId, parentDiv, selectName) {
    var html = AJS.$("<select>").attr({name: selectName});
    options.sort(sortOption);
    for (var i = 0; i < options.length; i++) {
        var option = options[i];
        if (selectedOptionId == option["value"]) {
            html.append(AJS.$("<option/>").attr({value: option["value"], selected: "selected"}).append(option["label"]));
        }
        else {
            html.append(AJS.$("<option/>").attr({value: option["value"]}).append(option["label"]));
        }
    }
    parentDiv.html(html);
}

function sortOption(a, b) {
    return (b['label'] < a['label']) - (a['label'] < b['label']);
}

function getCurrentProject(args, gadget) {
    var currentProject = getSelectedProject(args);
    if (currentProject == null) {
        currentProject = getProjectById(args, gadget.getPref("projectId"));
    }
    return currentProject;
}

function getSelectedProject(args) {
    return getProjectById(args, AJS.$("#myProjectDiv option:selected").attr("value"))
}

function getProjectById(args, id) {
    for (projectIndex in args["projectData"]["projects"]) {
        var project = args["projectData"]["projects"][projectIndex];
        if (project["id"].toString() == id) {
            return project;
        }
    }
}

function getProjects(args, gadget) {
    var projects = [];
    for (projectIndex in args["projectData"]["projects"]) {
        var project = args["projectData"]["projects"][projectIndex];
        projects[projects.length] = {label: project["name"], value: project["id"].toString()};
    }
    return projects;
}

function getVersions(currentProject) {
    var versions = [];
    if (currentProject != null) {
        for (versionIndex in currentProject["versionData"]["versions"]) {
            var version = currentProject["versionData"]["versions"][versionIndex];
            versions[versions.length] = {label: version["name"], value: version["id"].toString()};
        }
    }
    return versions;
}

function getIssueTypes(currentProject) {
    var issueTypes = [];
    if (currentProject != null) {
        for (issueTypeIndex in currentProject["issueTypeData"]["issueTypes"]) {
            var issueType = currentProject["issueTypeData"]["issueTypes"][issueTypeIndex];
            issueTypes[issueTypes.length] = {label: issueType["name"], value: issueType["id"].toString()};
        }
    }
    return issueTypes;
}

function getComponents(currentProject) {
    var components = [];
    if (currentProject != null) {
        for (componentIndex in currentProject["componentData"]["components"]) {
            var component = currentProject["componentData"]["components"][componentIndex];
            components[components.length] = {label: component["name"], value: component["id"].toString()};
        }
    }
    return components;
}

function setTitle(gadget) {
    var title = gadget.getPref("title");
    if (title != null) {
        gadgets.window.setTitle(gadget.getPref("title"));
    }
    else {
        gadgets.window.setTitle(gadget.getPref("EDT - TT Issue Import"));
    }
}
