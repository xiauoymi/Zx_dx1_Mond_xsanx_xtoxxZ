function render(gadget, args) {
    var content = jQuery("<div/>");
    var numTeamTracks = getNumTeamtracksToImport(args, gadget);
    appendHeader(content, gadget, args, numTeamTracks);
    appendDetails(content, gadget, args, numTeamTracks);
    gadget.getView().html(content);
}

function appendDetails(content, gadget, args, numTeamTracks) {
    var detailsDiv = jQuery('<table/>');
    var alternate = true;
    if (args["teamtrackData"]["teamtracks"].length > 0) {
        addCheckAllButton(detailsDiv, numTeamTracks);
        var showStatus = shouldShowStatusColumn(args, gadget);
        var i = 0;
        for (teamtrackIndex in args["teamtrackData"]["teamtracks"]) {
            var teamtrack = args["teamtrackData"]["teamtracks"][teamtrackIndex];
            var completed = teamtrack['jiraStatus'] == "Closed" || teamtrack['jiraStatus'] == 'Resolved';
            if (!completed || gadget.getPref('showCompletedIssues') == "on") {
                alternate = !alternate;
                var row = jQuery('<tr/>');
                if (alternate) {
                    row = jQuery('<tr class="alt"/>');
                }
                appendCheckboxOrWarning(completed, row, teamtrack);
                /*if (showStatus) {
                    row.append(jQuery('<td/>').append(teamtrack['jiraStatus']));
                }*/
                row.append(jQuery('<td/>').append(teamtrack['jiraStatus']));
                row.append(jQuery('<td/>').append('<a target="new" href=' + teamtrack['url'] + '>' + teamtrack['name'] + '</a>'));
                row.append(jQuery('<td/>').append(teamtrack['title']));
                row.append(jQuery('<td/>').append(teamtrack['prodReleaseDate']));
                row.append(jQuery('<td/>').append(teamtrack['statusDesc']));

                detailsDiv.append(row);
            }
        }
        content.append(detailsDiv);
    }
}
function appendHeader(content, gadget, args, numTeamTracks) {
    var header = jQuery('<table id="header"/>');
    var row = jQuery('<tr/>');

    var messageTd = jQuery('<td/>');
    var buttonTd = jQuery('<td/>');
    var linkTd = jQuery('<td/>');
    linkTd.append("<a href='http://stlwtpswikprd01/architecture/index.php/Issue_Import'>Wiki</a>")

    if (args["teamtrackData"]["message"]) {
        messageTd.append(args["teamtrackData"]["message"]);
    }
    else {
        if (numTeamTracks == 0) {
            messageTd.append('There are <span class="bold">no</span> new TeamTracks to import.');
        }
        else if (numTeamTracks == 1) {
            messageTd.append('There is <span class="bold">one</span> TeamTrack ready to be imported.');
        }
        else {
            messageTd.append('There are <span class="bold">' + numTeamTracks + '</span> TeamTracks ready to be imported.');
        }
        if (numTeamTracks > 0) {
            buttonTd.append(getButton(gadget, args, content));
        }
    }
    row.append(messageTd);
    row.append(buttonTd);
    row.append(linkTd);
    header.append(row);
    content.append(header);
}
function getButton(gadget, args, content) {
    var button = jQuery("<button/>");
    button.append("Import");

    button.click(function() {
        var teamtracksToSubmit = [];
        var teamtrackData = {teamtracks: []};

        jQuery(args["teamtrackData"]["teamtracks"]).each(function() {
            var attributeSel = '[tt = "' + this.name + '"]';
            if (attributeSel && jQuery('input' + attributeSel).is(':checked')) {
                teamtracksToSubmit[teamtracksToSubmit.length] = this;
            }
        });
        teamtrackData.teamtracks = teamtracksToSubmit;

        if (teamtracksToSubmit.length > 0) {
            jQuery.ajax({
                type: 'POST',
                contentType: 'application/json',
                url: '/rest/edt-tti-gadget/1.0/teamtrack.json?projectId=' + gadget.getPref('projectId') + '&componentId=' + gadget.getPref("componentId") + '&versionId=' + gadget.getPref("versionId") + '&issueTypeId=' + gadget.getPref("issueTypeId"),
                dataType: "json",
                data: JSON.stringify(teamtrackData),
                success: function(data, status, jqxhr) {
                    content.html('<div id="header-div">' + data['message'] + '</div>');
                    gadgets.window.adjustHeight();
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    alert('Error importing Teamtracks: ' + errorThrown);
                }
            });
        }
        else {
            content.html("<div id='header-div'>You've avoided importing any issues!  Yay!</div>");
            gadgets.window.adjustHeight();
        }
    });
    return button;
}


function shouldShowStatusColumn(args, gadget) {
    var showStatus = false;
    for (teamtrackIndex in args["teamtrackData"]["teamtracks"]) {
        showStatus |= args["teamtrackData"]["teamtracks"][teamtrackIndex]["jiraStatus"] != "New";
    }
    showStatus &= gadget.getPref('showCompletedIssues') == "on";
    return showStatus;
}

function getNumTeamtracksToImport(args, gadget) {
    var numTeamTracks = 0;
    for (teamtrackIndex in args["teamtrackData"]["teamtracks"]) {
        if (args["teamtrackData"]["teamtracks"][teamtrackIndex]["jiraStatus"] == "New") {
            numTeamTracks ++;
        }
    }
    return numTeamTracks;
}

function addCheckAllButton(detailsDiv, numTeamTracks) {
    if (numTeamTracks > 1) {
        var checkAll = jQuery('<input type="checkbox" name="import" checked/>');
        checkAll.click(function() {
            var doCheckAll = this.checked;
            jQuery(':checkbox').each(function() {
                this.checked = doCheckAll;
            });
        });
        detailsDiv.append(jQuery('<tr class="alt"/>').append(jQuery('<td colspan="10"/>').append(checkAll)));
    }
}

function appendCheckboxOrWarning(completed, row, teamtrack) {
    if (!completed) {
        row.append(jQuery('<td class="checkbox">').append(jQuery('<input type="checkbox" name="import" checked/>').attr({tt: teamtrack['name']})));
    }
    else {
        var td = jQuery('<td>');
        var url = "../../../browse/" + teamtrack["jiraKey"];
        var a = jQuery('<a class="warning" title="This needs to be resolved in TeamTrack" target="new">&nbsp;&nbsp;&nbsp;</a>');
        a.attr({href: url});
        td.append(a);
        row.append(td);
    }
}