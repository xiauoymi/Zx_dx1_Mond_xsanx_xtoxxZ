package com.monsanto.jira;

import org.junit.Test;

public class MyPluginTest
{
    @Test
    public void testSomething()
    {
    }
}
