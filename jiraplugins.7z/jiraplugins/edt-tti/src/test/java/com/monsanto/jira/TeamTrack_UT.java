package com.monsanto.jira;

import com.monsanto.teamtrack.aewebservices.domain.axis.Aewebservices71_ServiceLocator;
import com.monsanto.teamtrack.aewebservices.domain.axis.Auth;
import com.monsanto.teamtrack.aewebservices.domain.axis.NameValue;
import com.monsanto.teamtrack.aewebservices.domain.axis.TTItem;
import org.junit.Test;

import javax.xml.rpc.ServiceException;
import java.rmi.RemoteException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TeamTrack_UT {
    @Test
    public void callTeamTrack() throws RemoteException, ServiceException {
        TeamTrackItemProvider teamTrackStatusProvider = new TeamTrackItemProvider();
        Auth auth = new Auth();
        auth.setUserId("NA1000APP-JIRA");
        auth.setPassword("F3Bu@y1");
        teamTrackStatusProvider.setAuth(auth);
        teamTrackStatusProvider.setLocator(new Aewebservices71_ServiceLocator());

        // 79471
        TTItem item = teamTrackStatusProvider.getItem("1004:82622");
        System.out.println("Description : " + item.getDescription());

        System.out.println("Created by : " + item.getCreatedBy());
        System.out.println("Title : " + item.getTitle());
        System.out.println("Item Name: " + item.getGenericItem().getItemName());
        System.out.println("Item UUId: " + item.getGenericItem().getItemID());
        System.out.println("URL : " + item.getUrl());
        NameValue[] namevalueList = item.getExtendedFieldList();
        for (int i = 0; i < namevalueList.length; i++) {
            try {
                System.out.println(namevalueList[i].getName() + " : " + namevalueList[i].getValue().getDisplayValue());
                String estDevHrs = "";
                String prodReleaseDate = "";
                String actDevHrs = "";
                String statusDesc = "";
                if ("EST_ABAP_HOURS".equalsIgnoreCase(namevalueList[i].getName())) {
                    estDevHrs = namevalueList[i].getValue().getDisplayValue();
                    System.out.println("estDevHrs : " + estDevHrs);
                }

                if ("ACTUAL_DEVELOPMENT_EFFORT".equalsIgnoreCase(namevalueList[i].getName())) {
                    actDevHrs = namevalueList[i].getValue().getDisplayValue();
                    System.out.println("actDevHrs : " + actDevHrs);
                }

                if ("PRODUCTION_RELEASE_DATE".equalsIgnoreCase(namevalueList[i].getName())) {
                    prodReleaseDate = namevalueList[i].getValue().getDisplayValue();

                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MMM/yy");
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
                    Date convertedDate = dateFormat.parse(prodReleaseDate);
                    prodReleaseDate = simpleDateFormat.format(convertedDate);
                    System.out.println("prodReleaseDate : "+simpleDateFormat.format(convertedDate));
                }
                if ("STATUS_DESCRIPTION".equalsIgnoreCase(namevalueList[i].getName())){
                    statusDesc = namevalueList[i].getValue().getDisplayValue();
                    System.out.println("statusDesc : "+statusDesc);
                }

            } catch (Exception e) {
                System.out.println(e.getMessage());
            }

        }

        // ESTIMATED_EFFORT  EST_PORTAL_DEVELOPER_HOURS ESTIMATED_HOURS_FOR_COMPLE ESTIMATED_HOURS_FO, EST_ABAP_HOURS

        //ACTUAL_DEVELOPMENT_EFFORT ACTUAL_EFFORT_HOURS

        //REQUIRED_DATE -  Production Release Date

        try {

            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MMM/yy");
            SimpleDateFormat dateFormat = new SimpleDateFormat("mm/dd/yyyy");
            Date convertedDate = dateFormat.parse("03/19/2013");
            System.out.println(simpleDateFormat.format(convertedDate));


        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


    }
}
