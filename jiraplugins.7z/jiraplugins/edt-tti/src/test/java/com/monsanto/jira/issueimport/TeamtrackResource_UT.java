package com.monsanto.jira.issueimport;

import com.atlassian.crowd.embedded.api.User;
import com.atlassian.sal.api.user.UserManager;
import com.monsanto.jira.TeamTrackReportParser;
import com.monsanto.jira.TeamTrackReportReader;
import com.monsanto.jira.TeamtrackResource;
import org.junit.Test;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Response;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class TeamtrackResource_UT {
    @Test
    public void test() {
        HttpServletRequest request = mock(HttpServletRequest.class);
        UserManager userManager = mock(UserManager.class);
        User user = mock(User.class);

        com.atlassian.jira.user.util.UserManager jiraUserManager = mock(com.atlassian.jira.user.util.UserManager.class);
        when(userManager.getRemoteUsername(request)).thenReturn("cjcoff");
        when(jiraUserManager.getUserObject("cjcoff")).thenReturn(user);

        TeamtrackResource teamtrackResource = new TeamtrackResource(null, null, null, userManager, jiraUserManager, new TeamTrackReportParser(), new TeamTrackReportReader());
        Response teamtracksToImport = teamtrackResource.getTeamtracksToImport(request, "20600", null);
    }
}
