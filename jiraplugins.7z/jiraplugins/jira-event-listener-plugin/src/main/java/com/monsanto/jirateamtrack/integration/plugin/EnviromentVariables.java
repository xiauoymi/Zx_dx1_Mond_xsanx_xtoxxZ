package com.monsanto.jirateamtrack.integration.plugin;

/**
 * Created by NREIN1 on 8/6/2014.
 */
public class EnviromentVariables {
    public static final String PASSWORD = "";
    public static final String  USERNAME = "";

}
