package com.monsanto.jirateamtrack.integration.plugin;


import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.fields.CustomField;
import com.atlassian.jira.util.collect.MapBuilder;
import com.atlassian.event.api.EventListener;


import com.atlassian.event.api.EventPublisher;
import com.atlassian.jira.event.issue.IssueEvent;
import com.atlassian.jira.event.type.EventType;
import com.atlassian.jira.issue.Issue;

import com.atlassian.jira.workflow.JiraWorkflow;
import com.atlassian.jira.workflow.WorkflowManager;
import org.ofbiz.core.entity.GenericEntityException;
import org.ofbiz.core.entity.GenericValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import sbm.Status;

import java.util.List;

/**
 * Created by NREIN1 on 7/17/2014.
 */
public class IssueEventListener implements InitializingBean, DisposableBean {


    //Specific fields that change that will need to be logged with the generic event listener.

    private final String ORIGINAL_ESTIMATE_UPDATED= "timeoriginalestimate";
    private final String FROM_READY_TO_WORK = "Selected for Development";
    private final String MOVE_TO_IN_WORK = "In Progress";
    private final String FROM_TECH_LEAD_APPROVED = "Tech Lead Approved";
    private final String MOVE_TO_TESTING = "Testing";
    private final String WORK_FLOW_NAME = "Enterprise Services Workflow V2";
    private final String STATUS = "status";


    private static final Logger log = LoggerFactory.getLogger(IssueEventListener.class);


    //private final TeamTrackConversion teamTrackConversion = new TeamTrackConversion();


    private final EventPublisher eventPublisher;
    private final WorkflowManager workflowManager;


    /**
     * Constructor.
     *
     * @param eventPublisher injected {@code EventPublisher} implementation.
     */
    public IssueEventListener(EventPublisher eventPublisher, WorkflowManager workflowManager) {
        this.eventPublisher = eventPublisher;
        this.workflowManager = workflowManager;

    }

    /**
     * Called when the plugin has been enabled.
     *
     * @throws Exception
     */
    @Override
    public void afterPropertiesSet() throws Exception {
        // register ourselves with the EventPublisher
        eventPublisher.register(this);
    }

    /**
     * Called when the plugin is being disabled or removed.
     *
     * @throws Exception
     */
    @Override
    public void destroy() throws Exception {
        // unregister ourselves with the EventPublisher
        eventPublisher.unregister(this);
    }

    /**
     * Receives any {@code IssueEvent}s sent by JIRA.
     *
     * @param issueEvent the IssueEvent passed to us
     */
    @EventListener
    public void onIssueEvent(IssueEvent issueEvent) {
        Long eventTypeId = issueEvent.getEventTypeId();
        Issue issue = issueEvent.getIssue();
        JiraWorkflow workflow = workflowManager.getWorkflow(issue);
        log.info("This is the Issues Workflow: {}", workflow.getName());
        System.out.println("This is the Issues Workflow: "+ workflow.getName());

        if (eventTypeId.equals(EventType.ISSUE_CREATED_ID)) {
            log.info("Issue {} has been CREATED.", issue.getKey());
            log.info("Issues project is {}, its estimate is {}", issue.getProjectId(), issue.getOriginalEstimate());
            log.info("Issue's assigned too {}. All of this was done at {}", issue.getAssignee(), issue.getCreated());

            System.out.println("Issue "+ issue.getKey() + " has been CREATED.");
            System.out.println("The Issues Project is: "+ issue.getProjectId()+" and its Estimate is: "+ issue.getOriginalEstimate());
            System.out.println("The Issue is assigned to: "+ issue.getAssignee()+ " at "+ issue.getCreated());
            System.out.println("The TeamTrackID for this Jira issue is: "+ findTeamTrackIdCustomField(issue));



        }

        if(workflow.getName().equals(WORK_FLOW_NAME)){

            if (eventTypeId.equals(EventType.ISSUE_GENERICEVENT_ID) || eventTypeId.equals(EventType.ISSUE_UPDATED_ID)){
                log.info("~~~~Issue {} had a GENERIC EVENT/UPDATE EVENT happened at {}~~~~~", issue.getKey(), issue.getUpdated());
                System.out.println("~~~~Issue: "+ issue.getKey() + " had a GENERIC EVENT/UPDATE EVENT happened at: "+issue.getUpdated()+" ~~~~~");
                processChanges(issueEvent);

            }
            else if (eventTypeId.equals(EventType.ISSUE_WORKLOGGED_ID)){
//            TODO: Check to see if this is a viable option to push to TeamTrack
              log.info("Issue {} has WORK_LOGGED with {} seconds spent.", issue.getKey(), issueEvent.getWorklog().getTimeSpent());

            }
            else if (eventTypeId.equals(EventType.ISSUE_ASSIGNED_ID)) {
//            TODO: Low PRIORITY, if a issue get an assigned developer, update that in TeamTrack too.
              log.info("Issue {} has been ASSIGNED to {}.", issue.getKey(), issue.getAssigneeUser());

            }

        } else {
            log.info("This was ~not~ Enterprise Services Workflow V2! Ignoring TeamTrack Integration Actions");
            System.out.println("This was ~not~ Enterprise Services Workflow V2! Ignoring TeamTrack Integration Actions");
        }
    }
    //Will search for changes in a Generic Event or Update Event
    private void processChanges(IssueEvent issueEvent) {

        List<GenericValue> changeItems = null;
        Issue issue = issueEvent.getIssue();
        try {
            changeItems = issueEvent.getChangeLog().internalDelegator.findByAnd("ChangeItem", MapBuilder.build("group",  issueEvent.getChangeLog().get("id")));
        } catch (GenericEntityException e) {
            System.out.println(e.getMessage());
        }

        log.info("number of changes: {}", changeItems.size());
        for(GenericValue changeTemp:changeItems){
            String field = changeTemp.getString("field");
            String oldValue = changeTemp.getString("oldstring");
            String newValue = changeTemp.getString("newstring");
            String changeLog = "Issue "+ issue.getKey() + " field: " + field + " has been updated from " + oldValue  + " to " + newValue;
            log.info(changeLog);
            System.out.println(changeLog);
            if (field.equals(ORIGINAL_ESTIMATE_UPDATED)) {
               updateTeamtrackOriginalEstimation(issue);
            } else if (field.equals(STATUS)) {
               updateTeamtrackStatus(oldValue, newValue, issue);

            }
        }
    }


    private void updateTeamtrackStatus(String oldValue, String newValue, Issue issue){
        if (oldValue.equals(FROM_READY_TO_WORK) && newValue.equals(MOVE_TO_IN_WORK)) {
            log.info("!!!!!!!!!!!!!STATUS CHANGED FROM 'READY FOR DEVELOPMENT' to 'IN WORK'!!!!!!!!!!!!!");
            System.out.println("!!!!!!!!!!!!!STATUS CHANGED FROM 'READY FOR DEVELOPMENT' to 'IN WORK'!!!!!!!!!!!!!");
            TeamTrackItemChanger.CreateWithEnvironmentAuth().changeStatus(findTeamTrackIdCustomField(issue),null);


        } else if (oldValue.equals(FROM_TECH_LEAD_APPROVED) && newValue.equals(MOVE_TO_TESTING)) {
            log.info("************STATUS CHANGED FROM 'TECH LEAD APPROVED' to 'IN TEST'************");
            System.out.println("************STATUS CHANGED FROM 'TECH LEAD APPROVED' to 'IN TEST'************");
        }
    }


    private void updateTeamtrackOriginalEstimation(Issue issue){
        double originalEstimate = issue.getOriginalEstimate();
        log.info("~~~~~~~~~THE UPDATE WAS FOR TIME ESTIMATE! THROW IT TO TEAMTRACK!~~~~~~~~~ {}", issue.getOriginalEstimate());
        System.out.println("~~~~~~~~~THE UPDATE WAS FOR TIME ESTIMATE! THROW IT TO TEAMTRACK!~~~~~~~~~");
        log.info("The Original Estimate Is: {}.", originalEstimate);
        System.out.println("The Original Estimate Is:"+ originalEstimate);

    }

    private String findTeamTrackIdCustomField(Issue jiraIssue){
        CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager();
        CustomField customField = customFieldManager.getCustomFieldObjectByName("TeamTrack Item ID");
        Object teamTrackItemId = jiraIssue.getCustomFieldValue(customField);
        return teamTrackItemId.toString();
    }
}

