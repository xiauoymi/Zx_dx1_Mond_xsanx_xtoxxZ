package integration;

import sbm.*;

import javax.xml.bind.JAXBElement;

/**
 * Created by CGSHAF on 8/7/2014.
 */
abstract class TeamTrackCommunicationHandler {

    private ObjectFactory objectFactory;
    private Sbmappservices72PortType teamTrackInterface;
    private Auth auth;

    protected TeamTrackCommunicationHandler(){
        this.objectFactory = new ObjectFactory();
        this.teamTrackInterface = getService();
        this.auth = createAuth(EnviromentVariables.USERNAME,EnviromentVariables.PASSWORD);
    }
    protected TeamTrackCommunicationHandler(String username, String password){
        this.objectFactory = new ObjectFactory();
        this.teamTrackInterface = getService();
        this.auth = createAuth(username,password);
    }

    private Sbmappservices72PortType getService(){
        Sbmappservices72 sbmappservices72 = new Sbmappservices72();
        Sbmappservices72PortType port = sbmappservices72.getSbmappservices72();
        return  port;
    }

    private Auth createAuth(String username, String password){
        ObjectFactory objectFactory = new ObjectFactory();
        JAXBElement<String> user = objectFactory.createAuthUserId(username);
        JAXBElement<String> pass = objectFactory.createAuthPassword(password);
        Auth auth = new Auth();
        auth.setUserId(user);
        auth.setPassword(pass);

        return auth;
    }

    protected ItemIdentifier createTeamTrackItemIdentifier(String tableIdItemId){
        ItemIdentifier identifier = new ItemIdentifier();
        JAXBElement<String> itemTableIdItemId = this.getObjectFactory().createItemIdentifierTableIdItemId(tableIdItemId);
        identifier.setTableIdItemId(itemTableIdItemId);
        return identifier;
    }
    protected ObjectFactory getObjectFactory() {
        return objectFactory;
    }
    protected Sbmappservices72PortType getTeamTrackInterface() {
        return teamTrackInterface;
    }
    protected Auth getAuth() {
        return auth;
    }

}
