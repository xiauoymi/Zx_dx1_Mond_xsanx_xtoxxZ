package com.monsanto.jirateamtrack.integration.plugin;

import com.atlassian.jira.issue.Issue;
import sbm.*;

import javax.swing.*;
import javax.xml.bind.JAXBElement;

/**
 * Created by NREIN1 on 7/21/2014.
 */
public class TeamTrackConversion {


    private Sbmappservices72PortType getService(){
        Sbmappservices72 sbmappservices72 = new Sbmappservices72();
        Sbmappservices72PortType port = sbmappservices72.getSbmappservices72();
        return  port;
    }

    private Auth createAuth(){
        ObjectFactory objectFactory = new ObjectFactory();
        JAXBElement<String> username = objectFactory.createAuthUserId(EnviromentVariables.USERNAME);
        JAXBElement<String> password = objectFactory.createAuthPassword(EnviromentVariables.PASSWORD);
        Auth auth = new Auth();
        auth.setUserId(username);
        auth.setPassword(password);

        return auth;
    }
    private TTItem getItem(Sbmappservices72PortType port, Auth auth, String tableIdItemId){

        ItemIdentifier issueId = new ItemIdentifier();
        issueId.setTableIdItemId(new ObjectFactory().createItemIdentifierTableIdItemId(tableIdItemId));
        TTItemHolder item = null;

        if (issueId != null) {
            try {

                item = port.getItem(auth, issueId, null);
            }catch (AEWebservicesFaultFault e){
                e.printStackTrace();
                return null;
            }
            if(item != null) {
                System.out.println(item);
                return item.getItem().getValue();
            }
        }
        return null;

    }
    public void setToInDevelopment(Issue jiraIssue){
        jiraIssue.getKey();
        TTItem ttItem = this.getItem(this.getService(),this.createAuth(),"1004:66914");

        TransitionIdentifier transitionIdentifier = null;
        transitionIdentifier = new ObjectFactory().createTransitionIdentifier();
        //transitionIdentifier.set
        try {
            this.getService().transitionItem(this.createAuth(), ttItem, transitionIdentifier, true, null);

        }catch (AEWebservicesFaultFault e){
            e.printStackTrace();
        }

        //getService().getItem(createAuth());

    }
    public void setToResolved(Issue jiraIssue){

        jiraIssue.getKey();
    }

    public void addTimeLogged(Issue jiraIssue, Long addTime){
        jiraIssue.getKey();
        jiraIssue.getTimeSpent();//This returns time spend in seconds

    }




}
