package integration;

import sbm.Status;
import sbm.TTItem;

/**
 * Created by CGSHAF on 8/7/2014.
 */
public final class TeamTrackItemChanger extends TeamTrackCommunicationHandler {

    private TeamTrackItemChanger(){
        super();
    }
    private TeamTrackItemChanger(String username, String password){
        super(username, password);
    }

    public static TeamTrackCommunicationHandler CreateWithEnvironmentAuth(){
        return new TeamTrackItemChanger();
    }
    public static TeamTrackCommunicationHandler CreateWithCustomAuth(String username, String password){
        return new TeamTrackItemChanger(username, password);
    }

    public void changeStatus(String itemTableIdItemId, Status status){
        TTItem item = TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem(itemTableIdItemId);
        // TODO add logic to change status
    }
}
