package integration;

import sbm.*;

import java.util.List;

/**
 * Created by CGSHAF on 8/7/2014.
 */
public final class TeamTrackRetriever extends TeamTrackCommunicationHandler {

    private TeamTrackRetriever(){
        super();
    }
    private TeamTrackRetriever(String username, String password){
        super(username, password);
    }

    public static TeamTrackRetriever CreateWithEnviromentAuth(){
        return new TeamTrackRetriever();
    }
    public static TeamTrackRetriever CreateWithCustomAuth(String username, String password){
        return new TeamTrackRetriever(username, password);
    }

    public TTItem retrieveItem(String itemTableIdItemId){
        try {
            return this.getTeamTrackInterface().getItem(this.getAuth(), this.createTeamTrackItemIdentifier(itemTableIdItemId), null).getItem().getValue();
        }catch (AEWebservicesFaultFault e){
            e.printStackTrace();
        }
        return null;
    }
    public List<Transition> retrieveListOfAvailableTransitions(String itemTableIdItemId){
        try {
            return this.getTeamTrackInterface().getAvailableTransitions(this.getAuth(), this.createTeamTrackItemIdentifier(itemTableIdItemId), null, null, null);
        }catch (AEWebservicesFaultFault e){
            e.printStackTrace();
        }
        return null;
    }

    public List<TableData> retrieveListOfTables(){
        try {
            return this.getTeamTrackInterface().getTables(this.getAuth(), null, null, null);
        }catch (AEWebservicesFaultFault e){
            e.printStackTrace();
        }
        return null;
    }



}
