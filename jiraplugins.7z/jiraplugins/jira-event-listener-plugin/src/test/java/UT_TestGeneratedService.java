import com.monsanto.jirateamtrack.integration.plugin.EnviromentVariables;
import org.junit.Test;
import static org.junit.Assert.*;
import sbm.*;

import javax.xml.bind.JAXBElement;
import java.util.ArrayDeque;
import java.util.ArrayList;


/**
 * Created by CGSHAF on 7/17/2014.
 */
public class UT_TestGeneratedService {


    //("AP8037APP-EDTJIRA")
    //("Mhng$294")
    @Test
    public void testIsUserSet(){

        assertFalse("".equals(EnviromentVariables.PASSWORD) || "".equals(EnviromentVariables.USERNAME));
    }
    @Test
    public void testGetItem(){
        assertTrue(canGetItemIdentifier(getService(),createAuth()));
    }
    @Test
    public void testGetVersion(){

        try {
            System.out.println(getService().getVersion());
        }catch(AEWebservicesFaultFault e){
            e.printStackTrace();
            assert false;
        }
        assert true;
    }
    @Test
    public void testValidUser(){
        try {
            ObjectFactory objectFactory = new ObjectFactory();
            UserIdentifier userIdentifier = new UserIdentifier();
            JAXBElement<String> userId = objectFactory.createUserIdentifierLoginId(EnviromentVariables.USERNAME);
            userIdentifier.setLoginId(userId);
            assertTrue(getService().isUserValid(createAuth(),userIdentifier,null));
        }catch(AEWebservicesFaultFault e){
            e.printStackTrace();
            assert false;
        }
        assert true;

    }
    @Test
    public void testInvalidUser(){
        try {
            ObjectFactory objectFactory = new ObjectFactory();
            UserIdentifier userIdentifier = new UserIdentifier();
            JAXBElement<String> userId= objectFactory.createUserIdentifierLoginId("Strawberry Shortcake");
            userIdentifier.setLoginId(userId);
            assertFalse(getService().isUserValid(createAuth(),userIdentifier,null));
        }catch(AEWebservicesFaultFault e){
            e.printStackTrace();
        }

    }
    @Test
    public void testCanChangeItem(){
        assert false;
    }

    @Test
    public void testGetListOfAvailableTransitions(){
        ItemIdentifier issueId = new ItemIdentifier();
        issueId.setTableIdItemId(new ObjectFactory().createItemIdentifierTableIdItemId("1004:66914"));

        try {
            for(Transition transition : getService().getAvailableTransitions(createAuth(), issueId, GetTransitionOptions.TRANSITIONS_ALL, null, null) ){
                System.out.println("id:"+transition.getTransition().getValue().getInternalName().getValue());
            }

        }catch (AEWebservicesFaultFault e){
            e.printStackTrace();
        }

    }
    public static Sbmappservices72PortType getService(){
        Sbmappservices72 sbmappservices72 = new Sbmappservices72();
        Sbmappservices72PortType port = sbmappservices72.getSbmappservices72();
        return  port;
    }

    public static Auth createAuth(){
        ObjectFactory objectFactory = new ObjectFactory();
        JAXBElement<String> username = objectFactory.createAuthUserId(EnviromentVariables.USERNAME);
        JAXBElement<String> password = objectFactory.createAuthPassword(EnviromentVariables.PASSWORD);
        Auth auth = new Auth();
        auth.setUserId(username);
        auth.setPassword(password);

        return auth;
    }

    public static boolean canChangeItem(){
        try{
            ItemIdentifier issueId = new ItemIdentifier();
            issueId.setTableIdItemId(new ObjectFactory().createItemIdentifierTableIdItemId("1004:66914"));
            TTItemHolder item = getService().getItem(createAuth(),issueId,null);
        }catch (AEWebservicesFaultFault e){
            e.printStackTrace();
        }
        return true;
    }
    public static boolean canGetItemIdentifier(Sbmappservices72PortType port, Auth auth){

        ItemIdentifier issueId = new ItemIdentifier();
        issueId.setTableIdItemId(new ObjectFactory().createItemIdentifierTableIdItemId("1004:66914"));
        TTItemHolder item = null;

        if (issueId != null) {
            try {

                 item = port.getItem(auth, issueId, null);
            }catch (AEWebservicesFaultFault e){
                e.printStackTrace();
                return false;
            }
            if(item != null) {
                System.out.println(item);
                return true;
            }
        }
        return false;

    }

}
