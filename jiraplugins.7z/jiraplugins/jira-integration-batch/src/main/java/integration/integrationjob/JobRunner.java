package integration.integrationjob;

import integration.integrationjob.job.IntegrationJob;
import integration.integrationjob.util.CommandLineResolver;
import integration.integrationjob.job.jobs.CheckStateSynchronizationBetweenJiraAndTeamTrack;
import integration.integrationjob.job.jobs.DeleteOldWorklogs;
import integration.integrationjob.job.jobs.ResolveStatesInJiraFromTeamTrack;
import integration.integrationjob.util.TeamTrackToJiraIssueStateResolver;
import integration.jira.JiraCommunicationHandler;
import org.apache.commons.cli.*;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.text.*;
import java.util.*;

/**
 * Created by CGSHAF on 8/19/2014.
 */
public class JobRunner {

    private Logger logger = Logger.getLogger(getClass());
    private TeamTrackToJiraIssueStateResolver teamTrackToJiraIssueStateResolver = new TeamTrackToJiraIssueStateResolver();

    public static void main(String args[]){
        configLogs();
        CommandLine command = CommandLineResolver.parseArgs(args);
        CommandLineResolver.resolveJobVariables(command);
        System.out.println("STARTING JOB ON : "+JobVariables.getEnvironmentLevel());
        JobRunner jobRunner = new JobRunner();

        jobRunner.runJobs(command);
        System.out.println("JOB END");
    }


//    public static void main(String args[]){
//        JobVariables.setEnvironmentLevel("TEST");
//        configLogs();
//        JobRunner jobRunner = new JobRunner();
//        JiraCommunicationHandler jiraCommunicationHandler = new JiraCommunicationHandler();
//        jobRunner.checkSynchronization(jiraCommunicationHandler);
//        //jobRunner.deleteWorkLogs(jiraCommunicationHandler);
//    }

    public static void configLogs(){
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        FileAppender fileAppender = new FileAppender();
        try {
            fileAppender.setFile("logs/"+dateFormat.format(new Date())+"-integration.log", true, true, 1024);
            fileAppender.setLayout(new org.apache.log4j.PatternLayout());
            fileAppender.setImmediateFlush(true);
            fileAppender.setThreshold(Level.ALL);
        }catch (IOException e){
            e.printStackTrace();
        }
        org.apache.log4j.BasicConfigurator.configure(fileAppender);
    }

    public void runJobs(CommandLine cmd){
        JiraCommunicationHandler jiraCommunicationHandler = new JiraCommunicationHandler();
        List<IntegrationJob> integrationJobs = new ArrayList<IntegrationJob>();
        logger.info("LOGGING STARTED : " + new Date());
        teamTrackToJiraIssueStateResolver.init();
        if(cmd == null){
            integrationJobs.add(new ResolveStatesInJiraFromTeamTrack(jiraCommunicationHandler, teamTrackToJiraIssueStateResolver));            IntegrationJob resolveJob = new ResolveStatesInJiraFromTeamTrack(jiraCommunicationHandler, teamTrackToJiraIssueStateResolver);
            integrationJobs.add(new CheckStateSynchronizationBetweenJiraAndTeamTrack(jiraCommunicationHandler));
            integrationJobs.add(new DeleteOldWorklogs(jiraCommunicationHandler));

            runIntegrationJobs(integrationJobs);
            return;
        }

        if (cmd.hasOption("r")){
            integrationJobs.add(new ResolveStatesInJiraFromTeamTrack(jiraCommunicationHandler, teamTrackToJiraIssueStateResolver));
        }
        else if(cmd.hasOption("c")){
            integrationJobs.add(new CheckStateSynchronizationBetweenJiraAndTeamTrack(jiraCommunicationHandler));
        }
        else if(cmd.hasOption("d")){
            integrationJobs.add(new DeleteOldWorklogs(jiraCommunicationHandler));
        }
        runIntegrationJobs(integrationJobs);


    }
    private void runIntegrationJobs(List<IntegrationJob> integrationJobs){
        for(IntegrationJob integrationJob: integrationJobs){
            integrationJob.runJob();
        }
    }











}
