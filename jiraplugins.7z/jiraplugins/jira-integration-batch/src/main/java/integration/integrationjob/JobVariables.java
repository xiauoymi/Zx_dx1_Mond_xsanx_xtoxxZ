package integration.integrationjob;

import org.apache.log4j.Logger;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.Set;

/**
 * Created by CGSHAF on 8/6/2014.
 */
public class JobVariables {
    private static Logger logger = Logger.getLogger(JobVariables.class);
    private static String propertiesFileName = "integration.properties";
    private static JobVariables instance;
    private static String environmentLevel;
    private static Boolean isExternalProperty;
    private String jiraUsername;
    private String jiraPassword;
    private String jiraUrl;
    private String jiraTeamTrackIdFieldName;
    private List<String> jiraListOfProjectCategories;

    private JobVariables(String jiraUsername, String jiraPassword, String jiraUrl, List<String> jiraProjectCategories, String jiraTeamTrackIdFieldName){
        this.jiraUsername = jiraUsername;
        this.jiraPassword = jiraPassword;
        this.jiraUrl = jiraUrl;
        this.jiraListOfProjectCategories = jiraProjectCategories;
        this.jiraTeamTrackIdFieldName = jiraTeamTrackIdFieldName;
    }

    private static JobVariables getInstance(){
        if(instance != null){
            return instance;
        }else{
            instance = buildEnvironmentVariables();
            if(instance == null){
                logger.error("Error loading property file "+ environmentLevel + "/"+ propertiesFileName + "\nWas Environment Level set ?\nTERMINATING JOB");
                System.exit(0);
            }
        }
        return instance;
    }

   private static JobVariables buildEnvironmentVariables(){
        try {
            InputStream inputStream;

            if(isExternalProperty){
                inputStream = new FileInputStream(propertiesFileName);
            }else {
                inputStream = JobVariables.class.getClassLoader().getResourceAsStream(environmentLevel + "/" + propertiesFileName);
            }

            if (inputStream == null) {
                throw new FileNotFoundException();
            }else{
                Properties properties = new Properties();
                properties.load(inputStream);
                Set<String> jiraProperties = properties.stringPropertyNames();
                if(!jiraProperties.containsAll(Arrays.asList("jira.username","jira.password",
                        "jira.url","jira.projectCategories","jira.teamTrackIdFieldName"))){
                    logger.error("Error loading property file "+ environmentLevel + "/"+ propertiesFileName + "\nAre all the properties present?\nTERMINATING JOB");
                    System.exit(0);

                }
                return new JobVariables(
                    properties.getProperty("jira.username"),
                    properties.getProperty("jira.password"),
                    properties.getProperty("jira.url"),
                    Arrays.asList(properties.getProperty("jira.projectCategories").split(",")),
                    properties.getProperty("jira.teamTrackIdFieldName")
                );
            }
        }catch (FileNotFoundException e){
            logger.error("property file " + propertiesFileName + " not found in the classpath");
        }catch (IOException e){
            logger.error("Error loading property file : " + propertiesFileName);
        }
        return null;
    }

    public static String getJiraTeamTrackIdFieldName() {
        return getInstance().jiraTeamTrackIdFieldName;
    }

    public static String getJiraUsername() {
        return getInstance().jiraUsername;
    }

    public static String getJiraPassword() {
        return getInstance().jiraPassword;
    }

    public static String getJiraUrl() {
        return getInstance().jiraUrl;
    }

    public static List<String> getJiraProjectCategories(){
        return getInstance().jiraListOfProjectCategories;
    }

    public static String getEnvironmentLevel() {
        return environmentLevel;
    }

    public static void setEnvironmentLevel(String environmentLevel) {
        JobVariables.environmentLevel = environmentLevel;
    }

    public static void setPropertiesFileName(String filename){
        propertiesFileName = filename;
    }

    public static void setIsExternalProperty(boolean isEx){
       isExternalProperty = isEx;
    }

    public static String getPropertiesFileName() {
        return propertiesFileName;
    }

    public static void setJiraUsername(String jiraUsername) {
        getInstance().jiraUsername = jiraUsername;
    }

    public static void setJiraPassword(String jiraPassword) {
        getInstance().jiraPassword = jiraPassword;
    }

    public static void setJiraUrl(String jiraUrl) {
        getInstance().jiraUrl = jiraUrl;
    }

    public static void setJiraTeamTrackIdFieldName(String jiraTeamTrackIdFieldName) {
        getInstance().jiraTeamTrackIdFieldName =jiraTeamTrackIdFieldName;
    }

}
