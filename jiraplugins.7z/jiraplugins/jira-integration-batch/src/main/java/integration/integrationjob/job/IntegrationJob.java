package integration.integrationjob.job;

/**
 * Created by cgshaf on 2/13/15.
 */
public interface IntegrationJob {

    public void runJob();
}
