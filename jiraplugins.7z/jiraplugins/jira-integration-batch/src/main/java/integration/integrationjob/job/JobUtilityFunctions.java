package integration.integrationjob.job;

import integration.integrationjob.report.JobReport;
import integration.jira.pojo.JiraIssue;
import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.List;


/**
 * Created by cgshaf on 2/13/15.
 */

public class JobUtilityFunctions {

    private static Logger logger = Logger.getLogger(JobUtilityFunctions.class);

    public static HashMap<String,String> getMapOfTeamTrackTableIdItemIds(List<JiraIssue> listOfItems){
        int itemIdFailureCount = 0;
        HashMap<String,String> mapOfTeamTrackIdsToJiraIds = new HashMap<String,String>();
        for(JiraIssue jiraIssue : listOfItems){
            if (jiraIssue.getTeamTrackTableIdItemId().contains(":")) {
                mapOfTeamTrackIdsToJiraIds.put(jiraIssue.getTeamTrackTableIdItemId(), jiraIssue.getJiraIssueId());
            }else if(jiraIssue.getTeamTrackTableIdItemId().equals("NONE")){
                itemIdFailureCount++;
            }else {
                logger.warn("FORMAT ERROR : Invalid TeamTrack id(\"" + jiraIssue.getTeamTrackTableIdItemId() + "\") format for Jira task : " + jiraIssue.getJiraIssueId());
                JobReport.addJiraFormateErrorReport(jiraIssue);
                itemIdFailureCount++;
            }
        }
        logger.warn("TeamTrack tableIdItemId missing for "+itemIdFailureCount+" out of "+listOfItems.size()+" items");
        return mapOfTeamTrackIdsToJiraIds;
    }
}
