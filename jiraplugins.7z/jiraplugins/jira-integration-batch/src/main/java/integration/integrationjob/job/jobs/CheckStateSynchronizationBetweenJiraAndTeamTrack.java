package integration.integrationjob.job.jobs;

import integration.integrationjob.job.JobUtilityFunctions;
import integration.integrationjob.report.JobReport;
import integration.integrationjob.JobVariables;
import integration.integrationjob.util.EmailHandler;
import integration.jira.pojo.JiraSearchQuery;
import integration.jira.pojo.JiraIssue;
import com.sun.xml.internal.ws.client.ClientTransportException;
import integration.integrationjob.job.IntegrationJob;
import integration.jira.JiraCommunicationHandler;
import integration.teamtrack.TeamTrackRetriever;
import org.apache.log4j.Logger;
import sbm.TTItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by cgshaf on 2/13/15. original author YZHAN4.
 */
public class CheckStateSynchronizationBetweenJiraAndTeamTrack implements IntegrationJob {

    private static final String jiraReadyToWorkId = "10014";
    //private static final String jiraReadyToWorkId = "3";

    private static final String jiraInTestId = "10000";
    //private static final String jiraInTestId = "26";

    private static final String ttInDevelopmentId = "957";
    //private static final String ttInDevelopmentId = "303";

    private static final String ttReadyForItId = "966";


    private Logger logger = Logger.getLogger(CheckStateSynchronizationBetweenJiraAndTeamTrack.class);
    private JiraCommunicationHandler jiraCommunicationHandler;

    public CheckStateSynchronizationBetweenJiraAndTeamTrack(JiraCommunicationHandler jiraCommunicationHandler) {

    }

    @Override
    public void runJob() {

        JiraSearchQuery jiraSearchQuery = new JiraSearchQuery("category+IN+("+ JobVariables.getJiraProjectCategories().toString().replace("[","").replace("]","").replace(" ","")+")+AND+status+NOT+IN+(6)",0,1000);
        //SearchQuery searchQuery = new SearchQuery("issue+IN(MPM-188)",0,1000);
        logger.info("Project categories being processed: " + JobVariables.getJiraProjectCategories());
        HashMap<String,JiraIssue> mapOfJiraIssues = jiraCommunicationHandler.retrieveIssues(jiraSearchQuery);
        HashMap<String,String> teamTrackItemIdMap = JobUtilityFunctions.getMapOfTeamTrackTableIdItemIds(new ArrayList<JiraIssue>(mapOfJiraIssues.values()));
        try{
            List<TTItem> listOfTeamTrackItems = TeamTrackRetriever.CreateWithEnviromentAuth().getItems(new ArrayList<String>(teamTrackItemIdMap.keySet()),50);
            if(!listOfTeamTrackItems.isEmpty()) {
                for (TTItem item : listOfTeamTrackItems) {
                    JiraIssue jira = mapOfJiraIssues.get(teamTrackItemIdMap.get(item.getId().getValue().getTableIdItemId().getValue()));
                    String jiraState = jira.getStateId();
                    String ttState = item.getState().getValue().getId().toString();
                    logger.info("Starting to check states, Jira state name: " + jira.getStateName()
                            + ", Jira issue state id: " + jiraState + ", Teamtrack item state name: "
                            + item.getState().getValue() +", Teamtrack item state id: " + ttState);
                    if(!checkStateMatch(jiraState, ttState)){
                        JobReport.addTransitionFailureReport(jira, item, "Status out of sync");

                    }
                    // The fail message in the customfield may be different
                    if(jira.getCustomfieldVal().equals("fail")){
                        JobReport.addTransitionFailureReport(jira, item, "Plugin failed to update Jira");

                    }
                }
                EmailHandler.sendUpdateEmail(JobReport.generateHtmlReport());
                JobReport.writeJsonReport();
            }else{
                logger.warn("No items retrieved from Team Track");
            }
        }catch (ClientTransportException e){
            logger.error("Unable to authenticate to Team Track");
        }

    }

    private boolean checkStateMatch(String jiraState, String ttState){

        if(jiraState.equals(jiraReadyToWorkId) && !ttState.equals(ttInDevelopmentId)){
            return false;
        }
        if(jiraState.equals(jiraInTestId) && !ttState.equals(ttReadyForItId)){
            return false;
        }
        return true;
    }

}
