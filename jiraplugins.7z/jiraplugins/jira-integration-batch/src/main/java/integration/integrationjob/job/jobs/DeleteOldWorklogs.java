package integration.integrationjob.job.jobs;

import integration.jira.pojo.JiraSearchQuery;
import integration.jira.pojo.JiraIssue;
import integration.jira.pojo.JiraWorkLog;
import com.sun.xml.messaging.saaj.util.Base64;
import integration.jira.JiraCommunicationHandler;
import integration.integrationjob.JobVariables;
import integration.integrationjob.job.IntegrationJob;
import org.apache.log4j.Logger;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * Created by cgshaf on 2/13/15. original author YZHAN4.
 */
public class DeleteOldWorklogs implements IntegrationJob {

    private Logger logger = Logger.getLogger(DeleteOldWorklogs.class);
    private JiraCommunicationHandler jiraCommunicationHandler;
    private final String JIRA_API_LOCATION = JobVariables.getJiraUrl()+"/rest/api/latest";
    public DeleteOldWorklogs(JiraCommunicationHandler jiraCommunicationHandler) {
        this.jiraCommunicationHandler = jiraCommunicationHandler;
    }

    @Override
    public void runJob() {
        //SearchQuery searchQuery = new SearchQuery("project+IN+(EDTADMIN)+AND+issue+IN(EDTADMIN-2,EDTADMIN-3)",0,1000);
        JiraSearchQuery jiraSearchQuery = new JiraSearchQuery("project+IN+(MPM)+AND+issue+IN(MPM-193)",0,1000);
        HashMap<String,JiraIssue> mapOfJiraIssues = jiraCommunicationHandler.retrieveIssues(jiraSearchQuery);
        logger.info("Starting to delete worklogs, number of issues get: " + mapOfJiraIssues.values().size());
        for (JiraIssue jiraIssue : mapOfJiraIssues.values() ) {
            List<JiraWorkLog> worklogs = jiraIssue.getWorklogs();
            logger.info("number of worklogs: " + worklogs.size());
            String issueId = jiraIssue.getJiraIssueId();
            for (JiraWorkLog workLog : worklogs) {
                String time = workLog.getTime();
                String workLogId = workLog.getId();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");

                Date currentTime = new Date();
                try {
                    Date parsedDate = dateFormat.parse(time);
                    long daysDiff = (currentTime.getTime() - parsedDate.getTime()) / (24 * 60 * 60 * 1000);
                    if (daysDiff > 90) {
                        String b64usernamePassword = new String(Base64.encode((JobVariables.getJiraUsername() + ":" + JobVariables.getJiraPassword()).getBytes()));
                        String requestUrl = JIRA_API_LOCATION + "/issue/" + issueId + "/worklog/" + workLogId;
                        Client client = ClientBuilder.newClient();
                        System.out.println(client.target(requestUrl).request().header("Authorization", "Basic " + b64usernamePassword).delete());
                    }
                } catch (java.text.ParseException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
