package integration.integrationjob.job.jobs;

import integration.integrationjob.job.JobUtilityFunctions;
import integration.integrationjob.report.JobReport;
import integration.integrationjob.JobVariables;
import integration.integrationjob.util.EmailHandler;
import integration.integrationjob.util.TeamTrackToJiraIssueStateResolver;
import integration.jira.pojo.JiraSearchQuery;
import integration.jira.pojo.JiraIssue;
import com.sun.xml.internal.ws.client.ClientTransportException;
import integration.integrationjob.job.IntegrationJob;
import integration.jira.JiraCommunicationHandler;
import integration.teamtrack.TeamTrackRetriever;
import org.apache.log4j.Logger;
import sbm.TTItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * Created by cgshaf on 2/13/15.
 */
public class ResolveStatesInJiraFromTeamTrack implements IntegrationJob {


    private Logger logger = Logger.getLogger(ResolveStatesInJiraFromTeamTrack.class);
    private JiraCommunicationHandler jiraCommunicationHandler;
    private TeamTrackToJiraIssueStateResolver teamTrackToJiraIssueStateResolver;

    public ResolveStatesInJiraFromTeamTrack(JiraCommunicationHandler jiraCommunicationHandler,
                                            TeamTrackToJiraIssueStateResolver teamTrackToJiraIssueStateResolver) {
        this.jiraCommunicationHandler = jiraCommunicationHandler;
        this.teamTrackToJiraIssueStateResolver = teamTrackToJiraIssueStateResolver;

    }

    @Override
    public void runJob() {
        JiraSearchQuery jiraSearchQuery = new JiraSearchQuery("category+IN+("+ JobVariables.getJiraProjectCategories().toString().replace("[","").replace("]","").replace(" ","")+")+AND+status+NOT+IN+(6)",0,1000);
        logger.info("Project categories being processed: " + JobVariables.getJiraProjectCategories());
        HashMap<String,JiraIssue> mapOfJiraIssues = jiraCommunicationHandler.retrieveIssues(jiraSearchQuery);
        HashMap<String,String> teamTrackItemIdMap = JobUtilityFunctions.getMapOfTeamTrackTableIdItemIds(new ArrayList<JiraIssue>(mapOfJiraIssues.values()));
        try{
            List<TTItem> listOfTeamTrackItems = TeamTrackRetriever.CreateWithEnviromentAuth().getItems(new ArrayList<String>(teamTrackItemIdMap.keySet()),50);
            if(!listOfTeamTrackItems.isEmpty()) {
                for (TTItem item : listOfTeamTrackItems) {
                    teamTrackToJiraIssueStateResolver.resolveState(mapOfJiraIssues.get(teamTrackItemIdMap.get(item.getId().getValue().getTableIdItemId().getValue())), item);
                    if(item.getState().getValue().getDisplayName().getValue().equals("Closed")){
                        JiraIssue jiraIssue = mapOfJiraIssues.get(teamTrackItemIdMap.get(item.getId().getValue().getTableIdItemId().getValue()));
                        if(jiraIssue != null) {
                            JobReport.addTeamTrackIsClosedButNotJiraReport(jiraIssue, item);
                        }
                    }
                }
                EmailHandler.sendUpdateEmail(JobReport.generateHtmlReport());
                JobReport.writeJsonReport();
            }else{
                logger.warn("No items retrieved from Team Track");
            }
        }catch (ClientTransportException e){
            logger.error("Unable to authenticate to Team Track");
        }
    }


}
