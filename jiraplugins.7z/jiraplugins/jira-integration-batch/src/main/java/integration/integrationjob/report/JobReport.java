package integration.integrationjob.report;

import integration.integrationjob.JobVariables;
import integration.jira.pojo.JiraIssue;
import com.google.gson.Gson;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.apache.log4j.Logger;
import org.jvnet.hk2.component.MultiMap;
import sbm.TTItem;

import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by CGSHAF on 9/17/2014.
 */
public class JobReport {

    private static Logger logger = Logger.getLogger(JobReport.class);
    private static Configuration configuration = new Configuration();
    private static MultiMap<String, String> reportMap = new MultiMap<String, String>();
    private static HashMap<String, Reporter> reporterHashMap = new HashMap<String, Reporter>();
    private static Date jobStart = new Date();
    private static Gson gson = new Gson();
    public static void addLineToReportMessage(String reportSubject,String line){
       reportMap.add(reportSubject,line);
    }
    public static void addReportCategoryMessageForReporter(String reporter, String category, HashMap<String,String> entry, String key){
        if(reporterHashMap.containsKey(reporter)){
            reporterHashMap.get(reporter).addReport(category,entry,key);
        }else {
            Reporter newReporter = new Reporter(reporter);
            newReporter.addReport(category,entry,key);
            reporterHashMap.put(reporter,newReporter);
        }
    }
    public static void addJiraFormateErrorReport(JiraIssue jiraIssue){
        HashMap<String, String> fieldMap = new HashMap<String, String>();
        fieldMap.put("Invalid Team Track ID",jiraIssue.getTeamTrackTableIdItemId());
        fieldMap.putAll(getJiraIssueFields(jiraIssue));
        addReportCategoryMessageForReporter(jiraIssue.getProjectName(), "FORMAT ERRORS", fieldMap,jiraIssue.getKey());
    }
    public static void addTeamTrackIsClosedButNotJiraReport(JiraIssue jiraIssue, TTItem item){
        HashMap<String, String> fieldMap = new HashMap<String, String>();
        fieldMap.put("Jira Status",jiraIssue.getStateName());
        fieldMap.put("Team Track Status",item.getState().getValue().getDisplayName().getValue());
        fieldMap.putAll(getJiraIssueFields(jiraIssue));
        JobReport.addReportCategoryMessageForReporter(jiraIssue.getProjectName(), "ISSUE IS CLOSED IN TEAMTRACK BUT NOT IN JIRA", fieldMap,jiraIssue.getKey());
    }
    public static void addTransitionSuccessReport(JiraIssue jiraIssue, JiraIssue resolvedIssue, TTItem item){
        HashMap<String, String> fieldMap = new HashMap<String, String>();
        fieldMap.put("Old Status",jiraIssue.getStateName());
        fieldMap.put("New Status",resolvedIssue.getStateName());
        fieldMap.putAll(getJiraIssueFields(jiraIssue));
        JobReport.addReportCategoryMessageForReporter(jiraIssue.getProjectName(),"TRANSFORMED JIRA ISSUES",fieldMap,jiraIssue.getKey());
    }
    public static void addTransitionFailureReport(JiraIssue jiraIssue, TTItem item, String error){
        HashMap<String, String> fieldMap = new HashMap<String, String>();
        fieldMap.put("Jira Status",jiraIssue.getStateName());
        fieldMap.put("Team Track Status",item.getState().getValue().getDisplayName().getValue());
        if("{}".equals(error)){
            error = "State requirements not met";
        }
        fieldMap.put("Error",error);
        fieldMap.putAll(getJiraIssueFields(jiraIssue));
        JobReport.addReportCategoryMessageForReporter(jiraIssue.getProjectName(), "FAILED TO RESOLVE JIRA ISSUES", fieldMap,jiraIssue.getKey());
    }

    private static HashMap<String,String> getJiraIssueFields(JiraIssue jiraIssue){
        HashMap<String, String> fieldMap = new HashMap<String, String>();
        fieldMap.put("Issue Summary",jiraIssue.getSummary());
        fieldMap.put("Issue Id",JobReport.createLink(jiraIssue.getKey(), JobVariables.getJiraUrl()+"/browse/"+jiraIssue.getKey()));
        return fieldMap;
    }


    public static String createLink(String text, String url){
        return "<a href="+url+">"+text+"</a>";
    }


    public static void writeJsonReport(){
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        File file = new File("jira_integration_reports/"+dateFormat.format(new Date())+"/integrationreport_udate_"+System.currentTimeMillis()+".json");
        file.getParentFile().mkdirs();
        try {
            logger.info("WRITING JSON REPORT TO "+file.getAbsolutePath());
            PrintWriter writer = new PrintWriter(file);
            writer.println(gson.toJson(reporterHashMap.values()));
            writer.close();
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }

    }


    public static String generateHtmlReport(){
        try {
            Writer output = new StringWriter();
            Map<String, Object> freemakerTemplateMap = new HashMap<String, Object>();
            freemakerTemplateMap.put("ListOfReporters",reporterHashMap.values());
            DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            freemakerTemplateMap.put("starttime",dateFormat.format(jobStart));
            freemakerTemplateMap.put("endtime",dateFormat.format(new Date()));
            freemakerTemplateMap.put("instance",JobVariables.getEnvironmentLevel());
            freemakerTemplateMap.put("basejiraurl",JobVariables.getJiraUrl());

            configuration.setClassForTemplateLoading(JobReport.class,"/EmailTemplates");
            Template template = configuration.getTemplate("report.ftl");
            template.process(freemakerTemplateMap,output);
            return output.toString();
        }catch (IOException e){
            e.printStackTrace();
        }catch (TemplateException e){
            e.printStackTrace();
        }
        return "";

    }


}
