package integration.integrationjob.report;

import java.util.*;

/**
 * Created by CGSHAF on 9/22/2014.
 */
public class ReportCategory {
    String categoryName;
    List<HashMap<String,String>> categoryFieldToValue;
    List<String> listOfFields;
    List<String> listOfIssueKeys;
    String sortField;
    public ReportCategory(String categoryName) {
        this.categoryName = categoryName;
        this.categoryFieldToValue = new ArrayList<HashMap<String, String>>();
        this.listOfFields = new ArrayList<String>();
        this.listOfIssueKeys = new ArrayList<String>();
    }

    public List<String> getListOfFields() {
        return listOfFields;
    }

    public List<HashMap<String, String>> getCategoryFieldToValue() {
        if(this.listOfFields.contains(sortField)) {
            Collections.sort(categoryFieldToValue, new IssueIdComparator(sortField));
        }
        return categoryFieldToValue;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public List<String> getListOfIssueKeys() {
        return listOfIssueKeys;
    }

    public void addCategoryFieldValue(HashMap<String,String> fieldValues,String key){
        for(String fieldName : fieldValues.keySet()){
            if(!listOfFields.contains(fieldName)){
                listOfFields.add(fieldName);
            }
        }
        this.listOfIssueKeys.add(key);
        categoryFieldToValue.add(fieldValues);
    }

    public void setSortField(String sortField) {
        this.sortField = sortField;
    }

    @Override
    public String toString() {
        return listOfFields+ "," +categoryFieldToValue;
    }

    class IssueIdComparator implements Comparator<Map<String, String>>{
        private final String key;
        public IssueIdComparator(String key){
            this.key = key;
        }
        public int compare(Map<String, String> first, Map<String, String> second){
            return first.get(key).compareTo(second.get(key));
        }
    }
}
