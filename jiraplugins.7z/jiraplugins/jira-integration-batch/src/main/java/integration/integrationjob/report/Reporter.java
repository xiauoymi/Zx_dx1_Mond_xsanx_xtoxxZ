package integration.integrationjob.report;

import java.util.HashMap;

/**
 * Created by CGSHAF on 9/22/2014.
 */
public class Reporter {
    String reporter;
    HashMap<String, ReportCategory> reportCategoryHashMap;

    public Reporter(String reporter) {
        this.reporter = reporter;
        this.reportCategoryHashMap = new HashMap<String, ReportCategory>();
    }

    public String getReporter() {
        return reporter;
    }

    public void setReporter(String reporter) {
        this.reporter = reporter;
    }

    public HashMap<String, ReportCategory> getReportCategoryHashMap() {
        return reportCategoryHashMap;
    }

    public void addReport(String category, HashMap<String,String> fields, String key){
        if(this.reportCategoryHashMap.containsKey(category)){
            this.reportCategoryHashMap.get(category).addCategoryFieldValue(fields,key);
        }else{
            ReportCategory reportCategory = new ReportCategory(category);
            reportCategory.setSortField("Issue Id");
            reportCategory.addCategoryFieldValue(fields,key);
            this.reportCategoryHashMap.put(category, reportCategory);
        }
    }

    @Override
    public String toString() {
        return reportCategoryHashMap.toString();
    }
}
