package integration.integrationjob.util;

import integration.integrationjob.JobVariables;
import org.apache.commons.cli.*;

import java.util.Properties;
import java.util.Set;

/**
 * Created by YZHAN4 on 2/3/2015.
 */
public class CommandLineResolver {

    public static void resolveJobVariables(CommandLine cmd)  {
        String filePath;
        if(cmd != null && cmd.hasOption("f")) {
            filePath = cmd.getOptionValue("f");
            JobVariables.setPropertiesFileName(filePath);
            JobVariables.setIsExternalProperty(true);
        }
        else {
            JobVariables.setEnvironmentLevel("PROD");
        }
        Properties properties = cmd.getOptionProperties("D");
        Set<String> keys = properties.stringPropertyNames();

        for(String k : keys){
            String value = properties.getProperty(k);

            if(k.equals("jira.username")){
                JobVariables.setJiraUsername(value);
            }
            if(k.equals("jira.password")){
                JobVariables.setJiraPassword(value);
            }
            if(k.equals("jira.url")){
                JobVariables.setJiraUrl(value);
            }
            if(k.equals("jiraTeamTrackIdFieldName")){
                JobVariables.setJiraTeamTrackIdFieldName(value);
            }

        }
    }

    public static CommandLine parseArgs(String[] args){
        CommandLine cmd = null;
        Options options = new Options();

        Option property = OptionBuilder.withArgName("property=value").hasArgs(2).withValueSeparator().withDescription("use value for a given property").create("D");
        options.addOption("r", false, "Resolve states in Jira from Teamtrack");
        options.addOption("c", false, "Check if issues and items match correctly");
        options.addOption("d", false, "Delete outdated worklogs");
        options.addOption("f", true, "Property file path");
        options.addOption(property);

        CommandLineParser parser = new BasicParser();
        try {
            cmd = parser.parse(options, args);
        }catch(ParseException e){
            e.printStackTrace();
        }
        return cmd;
    }




}
