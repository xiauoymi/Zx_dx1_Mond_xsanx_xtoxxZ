package integration.integrationjob.util;


import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

/**
 * Created by CGSHAF on 9/17/2014.
 */
public class EmailHandler {

    private static final String EMAIL_HOST = "mail.monsanto.com";

    EmailHandler(){
    }
    private Session createMailSession(){
        Properties properties = System.getProperties();
        properties.setProperty("mail.smtp.host",EMAIL_HOST);
        return Session.getDefaultInstance(properties);
    }
    public static boolean sendUpdateEmail(String emailBody){
        EmailHandler emailHandler = new EmailHandler();
        return emailHandler.sendEmail("JIRA.INTEGRATION@noreply.monsanto.com","christopher.gregory.shafer@monsanto.com","Jira Integration Job Status",emailBody);
    }
    public static boolean sendUpdateEmail(String recipient, String emailBody){
        EmailHandler emailHandler = new EmailHandler();
        return emailHandler.sendEmail("JIRA.INTEGRATION@noreply.monsanto.com",recipient,"Jira Integration Job Status",emailBody);
    }
    private boolean sendEmail(String fromHeader, String recipientHeader, String subjectHeader, String messageBodyText){
        MimeMessage emailMessage = new MimeMessage(createMailSession());
        try {
            emailMessage.setFrom(new InternetAddress(fromHeader));
            emailMessage.setRecipient(Message.RecipientType.TO,new InternetAddress(recipientHeader));
            emailMessage.setSubject(subjectHeader);
            emailMessage.setText(messageBodyText,"utf-8","html");
            Transport.send(emailMessage);
        }catch (AddressException e){
            e.printStackTrace();
            return false;
        }catch (MessagingException e){
            e.printStackTrace();
            return false;
        }
        return true;
    }


}
