package integration.integrationjob.util;

import java.util.List;

/**
 * Created by CGSHAF on 9/25/2014.
 */
public class StateResolver {
    private List<String> listOfTransitions;
    private String destinationStatus;

    public StateResolver() {
    }

    public StateResolver(List<String> listOfTransitions, String destinationStatus) {
        this.listOfTransitions = listOfTransitions;
        this.destinationStatus = destinationStatus;
    }

    public List<String> getListOfTransitions() {
        return listOfTransitions;
    }

    public void setListOfTransitions(List<String> listOfTransitions) {
        this.listOfTransitions = listOfTransitions;
    }

    public String getDestinationStatus() {
        return destinationStatus;
    }

    public void setDestinationStatus(String destinationStatus) {
        this.destinationStatus = destinationStatus;
    }
}
