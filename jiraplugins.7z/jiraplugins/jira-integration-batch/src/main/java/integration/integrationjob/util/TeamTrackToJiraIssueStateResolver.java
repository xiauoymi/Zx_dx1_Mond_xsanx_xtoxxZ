package integration.integrationjob.util;

import integration.integrationjob.report.JobReport;
import integration.integrationjob.JobVariables;
import integration.jira.pojo.JiraIssue;
import integration.jira.JiraCommunicationHandler;
import org.apache.log4j.Logger;
import sbm.TTItem;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * Created by CGSHAF on 8/21/2014.
 */
public class TeamTrackToJiraIssueStateResolver {

    private Logger logger = Logger.getLogger(getClass());
    private static final String transformsFileName = "issueTransforms.states";
    private HashMap<String, StateResolver> teamTrackTOJiraStateResolverMap;
    private JiraCommunicationHandler jiraCommunicationHandler = new JiraCommunicationHandler();

    public TeamTrackToJiraIssueStateResolver(){
        this.teamTrackTOJiraStateResolverMap = new HashMap<String, StateResolver>();
    }

    public void init(){
        readStateTransitionsFromFile();
    }

    private void readStateTransitionsFromFile(){
        try{
            BufferedReader reader = new BufferedReader(new InputStreamReader(ClassLoader.getSystemResourceAsStream(JobVariables.getEnvironmentLevel()+"/"+transformsFileName)));
            String line;
            while ((line = reader.readLine()) != null) {
                if(!line.startsWith("//")) {
                    addStateTransition(line);
                }
            }
        }catch (FileNotFoundException e){
            logger.error("state file "+JobVariables.getEnvironmentLevel()+"/"+transformsFileName+" not found");
        }catch (IOException e){
            logger.error("Error loading property file " + transformsFileName);
        }
    }

    public void resolveState(JiraIssue jiraIssue, TTItem item){
        logger.info("Checking : " + item.getId().getValue().getTableIdItemId().getValue() + " | " + item.getId().getValue().getDisplayName().getValue()
                + " / ttstate : "+item.getState().getValue().getDisplayName().getValue()+"  "+item.getState().getValue().getId()
                +"/  JIRA ID : " + jiraIssue.getJiraIssueId()
                +"/ issue state : "+jiraIssue.getStateName() + " stateid: " + jiraIssue.getStateId());
        StateResolver stateResolver = this.teamTrackTOJiraStateResolverMap.get(item.getState().getValue().getId().toString());
        if (stateResolver != null) {
            if(stateResolver.getListOfTransitions() != null && !jiraIssue.getStateId().equals(stateResolver.getDestinationStatus())) {
                logger.info("STARTING state transform for team track state : " + item.getState().getValue().getDisplayName().getValue() + " | stateid : " + item.getState().getValue().getId().toString());
                String errors = "{}";
                for (String jiraTransition : stateResolver.getListOfTransitions()) {
                     errors = jiraCommunicationHandler.performTransition(jiraIssue.getJiraIssueId(),jiraTransition);
                }
                JiraIssue resolvedIssue = jiraCommunicationHandler.getIssue(jiraIssue.getJiraIssueId());
                if (resolvedIssue == null) {
                    return;
                }
                if (!resolvedIssue.getStateId().equals(jiraIssue.getStateId())) {
                    JobReport.addTransitionSuccessReport(jiraIssue, resolvedIssue, item);
                } else {
                    JobReport.addTransitionFailureReport(jiraIssue, item, errors);
                }
            }
        }
    }

    private void addStateTransition(String stateTransition){
        List<String> listOfTriggerStates = Arrays.asList(stateTransition.substring(stateTransition.indexOf('{')+1,stateTransition.lastIndexOf('}')).split(","));
        String transitionState = stateTransition.split("->")[1];
        List<String> transitionLine = Arrays.asList(transitionState.substring(transitionState.indexOf('[') + 1, transitionState.lastIndexOf(']')).split(","));
        String destinationStatus = transitionState.substring(transitionState.indexOf('(') + 1, transitionState.lastIndexOf(')'));
        for(String trigger : listOfTriggerStates){
            this.teamTrackTOJiraStateResolverMap.put(trigger, new StateResolver(transitionLine, destinationStatus));
        }
    }

}
