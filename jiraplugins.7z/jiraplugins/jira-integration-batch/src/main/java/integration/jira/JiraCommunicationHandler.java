package integration.jira;

import integration.jira.pojo.JiraSearchQuery;
import integration.jira.pojo.JiraIssue;
import integration.jira.pojo.JiraWorkLog;
import com.google.gson.*;
import com.sun.xml.messaging.saaj.util.Base64;
import integration.integrationjob.JobVariables;
import org.apache.log4j.Logger;

import javax.ws.rs.ProcessingException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * Created by CGSHAF on 8/18/2014.
 */
public class JiraCommunicationHandler {
    private Client client;
    private Gson gson = new Gson();
    private JsonParser jsonParser = new JsonParser();
    private Logger logger = Logger.getLogger(getClass());
    private final int JIRA_MAX_RETURN_SIZE = 1000;
    private final String JIRA_API_LOCATION = JobVariables.getJiraUrl()+"/rest/api/latest";

    public JiraCommunicationHandler(){
        this.client = ClientBuilder.newClient();
    }

    public JiraIssue getIssue(String issueId){
        String target = JIRA_API_LOCATION + "/issue/" + issueId;
        try {
            return JiraIssue.buildJiraIssueFromJsonObject(jsonParser.parse(client.target(target).request(MediaType.APPLICATION_JSON_TYPE).get(String.class)).getAsJsonObject());
        }catch (ProcessingException e){
            logger.error("Failure to retrieve issue: "+issueId);
        }
        return null;
    }

    public String getTransitions(String issueId){
        //TODO
        String target = JIRA_API_LOCATION + "/issue/" + issueId + "/transitions";
        return client.target(target).request(MediaType.APPLICATION_JSON_TYPE).get(String.class);
    }

    public void addWorkLog(){
        String target = JIRA_API_LOCATION + "/issue/" + "MPM-2299" + "/worklog";

       // int transitionResult = client.target(target).request(MediaType.APPLICATION_JSON).post(Entity.entity(gson.toJson(requestObject), MediaType.APPLICATION_JSON)).getStatus();
    }

    public HashMap<String, JiraIssue> retrieveIssues(JiraSearchQuery jiraSearchQuery) {
        HashMap<String, JiraIssue> mapOfJiraIssues = new HashMap<String, JiraIssue>();
        String target = JIRA_API_LOCATION + "/search" + jiraSearchQuery.toString();
        logger.info("Hitting Jira with request : "+target);
        String resultString = client.target(target).request(MediaType.APPLICATION_JSON_TYPE).get(String.class);
        JsonObject searchResult = jsonParser.parse(resultString).getAsJsonObject();

        for(JsonElement jsonElement : searchResult.getAsJsonArray("issues")) {
            JiraIssue issue = JiraIssue.buildJiraIssueFromJsonObject(jsonParser.parse(jsonElement.toString()).getAsJsonObject());
            mapOfJiraIssues.put(issue.getJiraIssueId(), issue);
        }

        if(mapOfJiraIssues.size() >= jiraSearchQuery.getMaxResults()){
            jiraSearchQuery.increaseStartAt(JIRA_MAX_RETURN_SIZE);
            logger.info("Stepping up query by "+JIRA_MAX_RETURN_SIZE+" - obtained :"+ jiraSearchQuery.getStartAt());
            mapOfJiraIssues.putAll(retrieveIssues(jiraSearchQuery));
        }

        return mapOfJiraIssues;
    }

    private List<JiraWorkLog> retrieveWorkLogs(JiraIssue jiraIssue){

        //TODO retrieve jira worklogs for an issue
        ArrayList<JiraWorkLog> jiraWorkLogs = new ArrayList<JiraWorkLog>();
        JsonObject itemFields = new JsonObject();
        if(itemFields.has("worklog") && !itemFields.get("worklog").isJsonNull()){
            JsonObject worklog = itemFields.getAsJsonObject("worklog");
            JsonArray worklogs = worklog.getAsJsonArray("worklogs");

            for(JsonElement worklogElement : worklogs){
                if(worklogElement.isJsonObject()){
                    jiraWorkLogs.add(JiraWorkLog.buildJiraWorkLogFromJsonObject(worklogElement.getAsJsonObject()));
                }
            }
        }
        return jiraWorkLogs;
    }

    public void setDeveloperToDefaultIfOneIsntSet(String issueId, JiraIssue jiraIssue){
        try {
            if (jiraIssue.getDeveloperAssignee().equals("NONE")) {
                logger.warn("No developer for task " + issueId + ", setting default developer | STATUS CODE : " + setDeveloper(issueId, "-1"));
            }
        }catch (ProcessingException e){
            e.printStackTrace();
        }
    }

    public int setDeveloper(String issueId, String developer){
        //TODO
        String target = JIRA_API_LOCATION + "/issue/" + issueId + "/assignee";
        JsonObject requestObject = new JsonObject();
        requestObject.addProperty("name", developer);
        return client.target(target).request(MediaType.APPLICATION_JSON).put(Entity.entity(gson.toJson(requestObject), MediaType.APPLICATION_JSON)).getStatus();

    }

    public String runTransition(String target, String b64usernamePassword, String issueId, String transitionId, JsonObject requestObject){
        Response response = client.target(target).request(MediaType.APPLICATION_JSON).post(Entity.entity(gson.toJson(requestObject), MediaType.APPLICATION_JSON));

        int transitionResult = response.getStatus();
        logger.info("Performed Transition on JIRAID: " + issueId + "  => " + transitionId + " RESULT : " + transitionResult);

        if(transitionResult == 401 || transitionResult == 403){
            response = client.target(target).request(MediaType.APPLICATION_JSON).header("Authorization", "Basic " + b64usernamePassword).post(Entity.entity(gson.toJson(requestObject), MediaType.APPLICATION_JSON));
            transitionResult = response.getStatus();
            logger.info("Performed Transition with Auth on JIRAID: " + issueId + "  => " + transitionId + " RESULT : " + transitionResult);
        }

        JsonElement responseElement = jsonParser.parse(response.readEntity(String.class));
        if (responseElement.isJsonObject()) {
            JsonObject jsonResponse = responseElement.getAsJsonObject();
            if (jsonResponse.has("errors")) {
                return jsonResponse.get("errors").toString();
            }
        }
        return "NONE RECEIVED";
    }

    public String performTransition(String issueId, String transitionId) {
        //TODO
        String target = JIRA_API_LOCATION + "/issue/" + issueId + "/transitions";
        JsonObject requestObject = new JsonObject();
        JsonObject transitionObject = new JsonObject();
        transitionObject.addProperty("id",transitionId);
        requestObject.add("transition", transitionObject);
        //TODO
        String b64usernamePassword = new String(Base64.encode((JobVariables.getJiraUsername() + ":" + JobVariables.getJiraPassword()).getBytes()));
        try {
            runTransition(target, b64usernamePassword, issueId, transitionId, requestObject);
        }catch (JsonSyntaxException e){
            logger.error("Json Format exception for : " + transitionId + " on Jira Task : " + issueId);
        }catch (ProcessingException e) {
            logger.error("Connection Timed out performing jira transition: " + transitionId + " on Jira Task : " + issueId);
        }
        return "NONE RECEIVED";
    }






}
