package integration.jira.pojo;

import com.google.gson.JsonObject;
import integration.integrationjob.JobVariables;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by CGSHAF on 9/12/2014.
 */
public class JiraIssue {
    private String stateId;
    private String stateName;
    private int esitmatedDeveloperHours;
    private String developerAssignee;
    private String teamTrackTableIdItemId;
    private String jiraIssueId;
    private String key;
    private String reporter;
    private String reporterEmail;
    private String summary;
    private String projectName;
    private String customfieldVal;
    private List<JiraWorkLog> worklogs;



    public JiraIssue(){
        this.stateId = "NONE";
        this.esitmatedDeveloperHours = 0;
        this.developerAssignee = "NONE";
        this.teamTrackTableIdItemId = "NONE";
        this.reporterEmail = "UNKNOWN";
        this.stateName = "UNKNOWN";
        this.summary = "UNKNOWN";
        this.customfieldVal = "UNKNOWN";
        this.worklogs = new ArrayList<JiraWorkLog>();

    }

    public JiraIssue(String stateId, int esitmatedDeveloperHours, String developerAssignee, String teamTrackTableIdItemId, String jiraIssueId, String customfieldVal, ArrayList<JiraWorkLog> worklogs) {
        this.stateId = stateId;
        this.esitmatedDeveloperHours = esitmatedDeveloperHours;
        this.developerAssignee = developerAssignee;
        this.teamTrackTableIdItemId = teamTrackTableIdItemId;
        this.jiraIssueId = jiraIssueId;
        this.customfieldVal = customfieldVal;
        this.worklogs = worklogs;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getReporterEmail() {
        return reporterEmail;
    }

    public void setReporterEmail(String reporterEmail) {
        this.reporterEmail = reporterEmail;
    }

    public String getReporter() {
        return reporter;
    }

    public void setReporter(String reporter) {
        this.reporter = reporter;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getStateId() {
        return stateId;
    }

    public void setStateId(String stateId) {
        this.stateId = stateId;
    }

    public int getEsitmatedDeveloperHours() {
        return esitmatedDeveloperHours;
    }

    public void setEsitmatedDeveloperHours(int esitmatedDeveloperHours) {
        this.esitmatedDeveloperHours = esitmatedDeveloperHours;
    }

    public String getDeveloperAssignee() {
        return developerAssignee;
    }

    public void setDeveloperAssignee(String developerAssignee) {
        this.developerAssignee = developerAssignee;
    }

    public String getTeamTrackTableIdItemId() {
        return teamTrackTableIdItemId;
    }

    public void setTeamTrackTableIdItemId(String teamTrackTableIdItemId) {
        this.teamTrackTableIdItemId = teamTrackTableIdItemId;
    }


    public String getCustomfieldVal() {
        return customfieldVal;
    }

    public void setCustomfieldVal(String customfieldVal) {
        this.customfieldVal = customfieldVal;
    }


    public String getJiraIssueId() {
        return jiraIssueId;
    }

    public void setJiraIssueId(String jiraIssueId) {
        this.jiraIssueId = jiraIssueId;
    }

    public List<JiraWorkLog> getWorklogs() {
        return worklogs;
    }

    public void setWorklogs(ArrayList<JiraWorkLog> worklogs) {
        this.worklogs = worklogs;
    }

    @Override
    public String toString() {
        return "ISSUE ID : "+this.getJiraIssueId()+
                "\nESTIMATE DEVELOPER HOURS : "+this.esitmatedDeveloperHours +
                "\nASSIGNEE : "+this.developerAssignee +
                "\nTEAMTRACK TABLE ID ITEM ID : "+this.teamTrackTableIdItemId +
                "\nSTATE ID : "+this.stateId;
    }

    public static JiraIssue buildJiraIssueFromJsonObject(JsonObject jsonIssue){
        JiraIssue jiraIssue = new JiraIssue();
        JsonObject itemFields = jsonIssue.getAsJsonObject("fields");
        jiraIssue.setJiraIssueId(jsonIssue.get("id").getAsString());
        jiraIssue.setKey(jsonIssue.get("key").getAsString());
        if(itemFields != null) {

            //Should change it to the real field name later
            if(itemFields.has("PostFunctionEval") && !itemFields.get("PostFunctionEval").isJsonNull()){
                jiraIssue.setCustomfieldVal(itemFields.get("PostFunctionEval").getAsString());
            }
            if(itemFields.has("summary") && !itemFields.get("summary").isJsonNull()){
                jiraIssue.setSummary(itemFields.get("summary").getAsString());
            }
            if(itemFields.has("assignee") && !itemFields.get("assignee").isJsonNull()){
                jiraIssue.setDeveloperAssignee(itemFields.get("assignee").getAsJsonObject().get("name").getAsString());
            }
            // The above custom field should be like this
            //TODO
            if (itemFields.has(JobVariables.getJiraTeamTrackIdFieldName()) && !itemFields.get(JobVariables.getJiraTeamTrackIdFieldName()).isJsonNull()) {
                jiraIssue.setTeamTrackTableIdItemId(itemFields.get(JobVariables.getJiraTeamTrackIdFieldName()).getAsString());
            }
            if(itemFields.has("status") && !itemFields.get("status").isJsonNull()){
                jiraIssue.setStateId(itemFields.get("status").getAsJsonObject().get("id").getAsString());
                jiraIssue.setStateName(itemFields.get("status").getAsJsonObject().get("name").getAsString());
            }
            if(itemFields.has("project") && !itemFields.get("project").isJsonNull()){
                jiraIssue.setProjectName(itemFields.get("project").getAsJsonObject().get("name").getAsString());
            }
            if(itemFields.has("timeoriginalestimate") && !itemFields.get("timeoriginalestimate").isJsonNull()){
                jiraIssue.setEsitmatedDeveloperHours(itemFields.get("timeoriginalestimate").getAsInt()/3600);
            }
            if(itemFields.has("reporter") && !itemFields.get("reporter").isJsonNull()){
                jiraIssue.setReporter(itemFields.get("reporter").getAsJsonObject().get("name").getAsString());
                jiraIssue.setReporterEmail(itemFields.get("reporter").getAsJsonObject().get("emailAddress").getAsString());
            }
        }
        return jiraIssue;
    }

}
