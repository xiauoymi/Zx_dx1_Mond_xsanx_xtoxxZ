package integration.jira.pojo;

import java.util.ArrayList;

/**
 * Created by CGSHAF on 8/20/2014.
 */
public class JiraSearchQuery {

    private String jql;
    private int startAt;
    private int maxResults;
    private boolean validateQuery;
    private ArrayList<String> fields;
    private String expand;

    public JiraSearchQuery(String jql, int startAt, int maxResults){
        this.jql = jql;
        this.startAt = startAt;
        this.maxResults = maxResults;
    }
    @Override
    public String toString(){
        return "?jql="+this.jql+"&maxResults="+maxResults+"&startAt="+startAt;
    }

    public void setJql(String jql) {
        this.jql = jql;
    }

    public void setStartAt(int startAt) {
        this.startAt = startAt;
    }

    public void increaseStartAt(int ammount){
        this.startAt += ammount;
    }

    public void setMaxResults(int maxResults) {
        this.maxResults = maxResults;
    }

    public void setValidateQuery(boolean validateQuery) {
        this.validateQuery = validateQuery;
    }

    public void setFields(ArrayList<String> fields) {
        this.fields = fields;
    }

    public void setExpand(String expand) {
        this.expand = expand;
    }

    public int getMaxResults() {
        return maxResults;
    }

    public int getStartAt() {
        return this.startAt;
    }


}
