package integration.jira.pojo;

import com.google.gson.JsonObject;

/**
 * Created by YZHAN4 on 2/4/2015.
 */
public class JiraWorkLog {
    private String time;
    private String id;


    public JiraWorkLog(){
        this.time = "UNKNOWN";
        this.id = "UNKNOWN";
    }
    public JiraWorkLog(String time, String id){
        this.time = time;
        this.id = id;
    }


    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public static JiraWorkLog buildJiraWorkLogFromJsonObject(JsonObject jsonWorklog){
        //TODO
        return new JiraWorkLog();
    }

}
