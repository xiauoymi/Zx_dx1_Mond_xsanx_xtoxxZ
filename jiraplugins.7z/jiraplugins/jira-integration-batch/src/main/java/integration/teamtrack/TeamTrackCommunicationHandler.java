package integration.teamtrack;

import integration.integrationjob.JobVariables;
import sbm.*;

/**
 * Created by CGSHAF on 8/7/2014.
 */
abstract class TeamTrackCommunicationHandler {

    private ObjectFactory objectFactory;
    private Sbmappservices72PortType teamTrackInterface;
    private Auth auth;

    protected TeamTrackCommunicationHandler(){
        this.objectFactory = new ObjectFactory();
        this.teamTrackInterface = getService();
        this.auth = createAuth(JobVariables.getJiraUsername(), JobVariables.getJiraPassword());
    }

    protected TeamTrackCommunicationHandler(String username, String password){
        this.objectFactory = new ObjectFactory();
        this.teamTrackInterface = getService();
        this.auth = createAuth(username,password);
    }

    private Sbmappservices72PortType getService(){
        Sbmappservices72 sbmappservices72 = new Sbmappservices72();
        Sbmappservices72PortType port = sbmappservices72.getSbmappservices72();
        return  port;
    }

    private Auth createAuth(String username, String password){
        Auth auth = new Auth();
        auth.setUserId(objectFactory.createAuthUserId(username));
        auth.setPassword(objectFactory.createAuthPassword(password));
        return auth;
    }

    protected ItemIdentifier createTeamTrackItemIdentifier(String tableIdItemId){
        ItemIdentifier identifier = new ItemIdentifier();
        identifier.setTableIdItemId(objectFactory.createItemIdentifierTableIdItemId(tableIdItemId));
        return identifier;
    }

    protected ObjectFactory getObjectFactory() {
        return objectFactory;
    }

    protected Sbmappservices72PortType getTeamTrackInterface() {
        return teamTrackInterface;
    }

    protected Auth getAuth() {
        return auth;
    }

}
