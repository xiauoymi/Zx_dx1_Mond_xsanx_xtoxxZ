package integration.teamtrack;

import org.apache.log4j.Logger;
import sbm.AEWebservicesFaultFault;
import sbm.StateIdentifier;
import sbm.TTItem;
import sbm.TransitionIdentifier;

import java.math.BigInteger;

/**
 * Created by CGSHAF on 8/7/2014.
 */
public final class TeamTrackItemChanger extends TeamTrackCommunicationHandler {

    private Logger logger = Logger.getLogger(getClass());
    private TeamTrackItemChanger(){
        super();
    }
    private TeamTrackItemChanger(String username, String password){
        super(username, password);
    }

    public static TeamTrackItemChanger CreateWithEnvironmentAuth(){
        return new TeamTrackItemChanger();
    }

    public static TeamTrackItemChanger CreateWithCustomAuth(String username, String password){
        return new TeamTrackItemChanger(username, password);
    }

    public TTItem changeStatus(String itemTableIdItemId, String transitionId, boolean breakLock) throws AEWebservicesFaultFault{
        TransitionIdentifier transitionIdentifier = new TransitionIdentifier();
        StateIdentifier stateIdentifier = new StateIdentifier();
        TTItem item = TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem(itemTableIdItemId);

        logger.info("Begin state for "+itemTableIdItemId+" : " + item.getState().getValue().getInternalName().getValue());
        stateIdentifier.setId(new BigInteger(transitionId));
        item.setState(getObjectFactory().createStateChangeHistoryNewState(stateIdentifier));
        transitionIdentifier.setId(new BigInteger(transitionId));
        TTItem ttItem = this.getTeamTrackInterface().transitionItem(getAuth(), item, transitionIdentifier, breakLock, null).getItem().getValue();
        logger.info("End state for "+itemTableIdItemId+" : " + ttItem.getState().getValue().getInternalName().getValue());
        return ttItem;
    }
}

