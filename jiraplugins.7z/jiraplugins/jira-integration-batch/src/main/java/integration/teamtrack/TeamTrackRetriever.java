package integration.teamtrack;

import org.apache.log4j.Logger;
import sbm.*;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Created by CGSHAF on 8/7/2014.
 */
public final class TeamTrackRetriever extends TeamTrackCommunicationHandler {

    private Logger logger = Logger.getLogger(getClass());
    private TeamTrackRetriever(){
        super();
    }
    private TeamTrackRetriever(String username, String password){
        super(username, password);
    }

    public static TeamTrackRetriever CreateWithEnviromentAuth(){
        return new TeamTrackRetriever();
    }

    public static TeamTrackRetriever CreateWithCustomAuth(String username, String password){
        return new TeamTrackRetriever(username, password);
    }



    // This sort of checks the validity of password and username?
    // TODO
    public TTItem retrieveItem(String itemTableIdItemId){
        try {
            TTItemHolder itemHolder = this.getTeamTrackInterface().getItem(this.getAuth(), this.createTeamTrackItemIdentifier(itemTableIdItemId), null);
            if(itemHolder != null) {
                return itemHolder.getItem().getValue();
            }
        }catch (AEWebservicesFaultFault e){
            logger.error("Error retrieving item by ItemIdTableId : "+itemTableIdItemId,e);
        }
        return null;
    }


    public List<Transition> retrieveListOfAvailableTransitions(String itemTableIdItemId){
        try {

            return this.getTeamTrackInterface().getAvailableTransitions(this.getAuth(), this.createTeamTrackItemIdentifier(itemTableIdItemId), GetTransitionOptions.TRANSITIONS_ALL, null, null);
        }catch (AEWebservicesFaultFault e){
            logger.error("Error retrieving transitions for : "+itemTableIdItemId,e);
        }
        return null;
    }

    public List<TTItem> getItemsByQuerryTable(String tableId){
        TableIdentifier tableIdentifier = this.getObjectFactory().createTableIdentifier();
        tableIdentifier.setId(new BigInteger(tableId));
        try {
            return this.getTeamTrackInterface().getItemsByQuery(this.getAuth(),
                    tableIdentifier,
                    "","",new BigInteger("0"), new BigInteger("5000"), null).getItem();
        }catch (AEWebservicesFaultFault e){
            logger.error("Error retrieving items from table : "+tableId,e);
        }
        return null;
    }

    public List<TTItem> getItems(List<String> listOfItemIds, int blockSize){
        List<ItemIdentifier> listOfItemIdentifiers = new ArrayList<ItemIdentifier>();
        List<TTItem> listOfTeamTrackItems = new ArrayList<TTItem>();
        if(listOfItemIds.isEmpty()){
            return new ArrayList<TTItem>();
        }
        Iterator<String> iterator = listOfItemIds.iterator();
        while(iterator.hasNext() && listOfItemIdentifiers.size()<blockSize){
            listOfItemIdentifiers.add(createTeamTrackItemIdentifier(iterator.next()));
            iterator.remove();
        }
        try {
            int nullCounter = 0;
            logger.info("Querying SBM with "+listOfItemIdentifiers.size()+" items");
            List<TTItemHolder> listOfItemHolder = this.getTeamTrackInterface().getItems(getAuth(),listOfItemIdentifiers,null);
            for(TTItemHolder itemHolder : listOfItemHolder){
                if(itemHolder.getItem() != null) {
                    listOfTeamTrackItems.add(itemHolder.getItem().getValue());
                }else{
                    nullCounter ++;
                }
            }
            logger.warn("POSSIBLE INVALID ID (likely that id is not in system) FOR : "+nullCounter+" of "+listOfItemHolder.size()+" , ITEMS");
            List<TTItem> recursiveList = getItems(listOfItemIds,blockSize);
            if(recursiveList != null){
                listOfTeamTrackItems.addAll(recursiveList);
            }
            return listOfTeamTrackItems;
        }catch (AEWebservicesFaultFault e) {
            logger.error("Error retriving items : "+listOfItemIds,e);
        }
        return new ArrayList<TTItem>();
    }


}
