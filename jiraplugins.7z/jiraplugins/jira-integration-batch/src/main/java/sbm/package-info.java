@javax.xml.bind.annotation.XmlSchema(namespace = "urn:sbmappservices72", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package sbm;
