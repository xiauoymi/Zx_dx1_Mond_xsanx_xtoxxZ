package integration;


import integration.integrationjob.JobVariables;
import integration.integrationjob.util.CommandLineResolver;
import org.apache.commons.cli.CommandLine;
import org.junit.Before;
import org.junit.Test;
import org.mockito.*;
import java.util.Properties;
import static org.junit.Assert.*;


/**
 * Created by YZHAN4 on 2/2/2015.
 */
public class UT_CommandLineResolver {

    private CommandLine cmd;
    private Properties properties;

    @Before
    public void doSetUp(){
        cmd = Mockito.mock(CommandLine.class);
        properties = Mockito.mock(Properties.class);
    }


    @Test
    public void testResolveJobVariables(){

        Mockito.when(cmd.hasOption("f")).thenReturn(true);
        Mockito.when(cmd.getOptionValue("f")).thenReturn("Test");
        Mockito.when(cmd.getOptionProperties("D")).thenReturn(properties);
        CommandLineResolver.resolveJobVariables(cmd);
        assertTrue(JobVariables.getPropertiesFileName().equals("Test"));

    }


}
