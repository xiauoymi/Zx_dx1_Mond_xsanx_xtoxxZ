package integration;

import integration.integrationjob.util.EmailHandler;
import org.junit.Test;
import static org.junit.Assert.*;
/**
 * Created by CGSHAF on 9/17/2014.
 */
public class UT_EmailHandler {

    @Test
    public void testEmail(){
        assertTrue(EmailHandler.sendUpdateEmail("this is a test","test"));
    }
}
