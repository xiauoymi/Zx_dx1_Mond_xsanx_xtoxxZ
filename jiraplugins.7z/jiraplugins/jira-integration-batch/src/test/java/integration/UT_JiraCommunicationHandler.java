package integration;

import integration.integrationjob.JobVariables;
import integration.jira.pojo.JiraIssue;
import com.google.gson.*;
import integration.jira.JiraCommunicationHandler;
import org.junit.Test;

import static org.junit.Assert.*;
/**
 * Created by CGSHAF on 8/18/2014.
 */
public class UT_JiraCommunicationHandler {

    Gson gson = new Gson();
    @Test
    public void testGetIssue(){
        JiraCommunicationHandler jiraCommunicationHandler = new JiraCommunicationHandler();
        JiraIssue issue = jiraCommunicationHandler.getIssue("MPM-202");
        assertTrue(issue.getKey().equals("MPM-202"));
    }
    @Test
    public void testGetTransitions(){
        JiraCommunicationHandler jiraCommunicationHandler = new JiraCommunicationHandler();
        String requestOutput = jiraCommunicationHandler.getTransitions("MPM-202");
        JsonObject transition = new JsonParser().parse(requestOutput).getAsJsonObject();
        assertNotNull(transition);
    }
    @Test
    public void testPerformTransition(){
        JiraCommunicationHandler jiraCommunicationHandler = new JiraCommunicationHandler();
            String response = jiraCommunicationHandler.performTransition("MPM-202", "731");
            assertFalse(response.equals(""));
            assertFalse(true);


    }
    @Test
    public void testLoadProperties(){
        assertNotNull(JobVariables.getJiraUrl());
    }
}
