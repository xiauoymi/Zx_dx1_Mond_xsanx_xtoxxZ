package integration;

/**
 * Created by YZHAN4 on 2/3/2015.
 */

import integration.integrationjob.JobRunner;
import integration.jira.pojo.JiraSearchQuery;
import integration.jira.pojo.JiraIssue;
import integration.jira.pojo.JiraWorkLog;
import integration.jira.JiraCommunicationHandler;
import integration.teamtrack.TeamTrackRetriever;
import org.apache.commons.cli.CommandLine;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.*;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import sbm.TTItem;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@RunWith(PowerMockRunner.class)
@PrepareForTest(TeamTrackRetriever.class)
public class UT_JobRunner {

    private CommandLine cmd;
    private JiraCommunicationHandler comHandler;
    private TTItem item;
    private List<TTItem> listOfTeamTrackItems;
    private TeamTrackRetriever retriever;


    @Before
    public void doSetUp(){
        cmd = Mockito.mock(CommandLine.class);
        Mockito.when(cmd.hasOption("r")).thenReturn(false);
        Mockito.when(cmd.hasOption("c")).thenReturn(false);

        comHandler = Mockito.mock(JiraCommunicationHandler.class);
        ArrayList<JiraWorkLog> workLogs = new ArrayList<JiraWorkLog>();
        JiraWorkLog workLog = new JiraWorkLog("2015-01-15T16:53:23.000-0600", "1234");
        workLogs.add(workLog);
        JiraIssue issue = new JiraIssue("1234", 8, "Hao", "1234", "1234", "success", workLogs);
        HashMap<String, JiraIssue> mapOfJiraIssue = new HashMap<String, JiraIssue>();
        mapOfJiraIssue.put("1234", issue);
        Mockito.when(comHandler.retrieveIssues(Mockito.any(JiraSearchQuery.class))).thenReturn(mapOfJiraIssue);

        item = Mockito.mock(TTItem.class);
        listOfTeamTrackItems = new ArrayList<TTItem>();
        listOfTeamTrackItems.add(item);


        retriever = PowerMockito.mock(TeamTrackRetriever.class);
        Mockito.when(retriever.getItems(Mockito.any(List.class), Mockito.any(Integer.class))).thenReturn(listOfTeamTrackItems);
        Mockito.when(TeamTrackRetriever.CreateWithEnviromentAuth()).thenReturn(retriever);

    }


    @Test
    public void testRunJobs(){

        JobRunner runner = new JobRunner();
        runner.runJobs(cmd);

    }



}


