package integration;

import integration.integrationjob.JobVariables;
import org.junit.Test;
import sbm.*;

import javax.xml.bind.JAXBElement;

import static org.junit.Assert.*;


/**
 * Created by CGSHAF on 7/17/2014.
 */
public class UT_TestTeamTrackCommunication {

    @Test
    public void testIsUserSet(){

        assertFalse("".equals(JobVariables.getJiraPassword()) || "".equals(JobVariables.getJiraUsername()));
    }
    @Test
    public void testGetItem(){
        assertTrue(canGetItemIdentifier(getService(),createAuth()));
    }

    @Test
    public void testGetVersion(){

        try {
            assertFalse("".equals(getService().getVersion()));
        }catch(AEWebservicesFaultFault e){
            e.printStackTrace();
            assert false;
        }
        assert true;
    }
    @Test
    public void testValidUser(){
        try {
            ObjectFactory objectFactory = new ObjectFactory();
            UserIdentifier userIdentifier = new UserIdentifier();
            JAXBElement<String> userId = objectFactory.createUserIdentifierLoginId("NA1000APP-EDT-JIRA");
            userIdentifier.setLoginId(userId);
            assertTrue(getService().isUserValid(createAuth(),userIdentifier,null));
        }catch(AEWebservicesFaultFault e){
            e.printStackTrace();
            assert false;
        }
        assert true;

    }
    @Test
    public void testInvalidUser(){
        try {
            ObjectFactory objectFactory = new ObjectFactory();
            UserIdentifier userIdentifier = new UserIdentifier();
            JAXBElement<String> userId= objectFactory.createUserIdentifierLoginId("Strawberry Shortcake");
            userIdentifier.setLoginId(userId);
            assertFalse(getService().isUserValid(createAuth(), userIdentifier, null));
        }catch(AEWebservicesFaultFault e){
            e.printStackTrace();
        }

    }

    public static Sbmappservices72PortType getService(){
        Sbmappservices72 sbmappservices72 = new Sbmappservices72();
        Sbmappservices72PortType port = sbmappservices72.getSbmappservices72();
        return  port;
    }

    public static Auth createAuth(){
        ObjectFactory objectFactory = new ObjectFactory();
        JAXBElement<String> username = objectFactory.createAuthUserId(JobVariables.getJiraUsername());
        JAXBElement<String> password = objectFactory.createAuthPassword(JobVariables.getJiraPassword());
        Auth auth = new Auth();
        auth.setUserId(username);
        auth.setPassword(password);

        return auth;
    }

    public static boolean canGetItemIdentifier(Sbmappservices72PortType port, Auth auth){

        ItemIdentifier issueId = new ItemIdentifier();
        issueId.setIssueId(new ObjectFactory().createItemIdentifierIssueId("1004:69771"));
        TTItemHolder item = null;
        if (issueId != null) {
            try {

                 item = port.getItem(auth, issueId, null);
                System.out.println(item);
            }catch (AEWebservicesFaultFault e){
                e.printStackTrace();
                return false;
            }
            if(item != null) {
                System.out.println(item);
                return true;
            }
        }
        return false;

    }

}
