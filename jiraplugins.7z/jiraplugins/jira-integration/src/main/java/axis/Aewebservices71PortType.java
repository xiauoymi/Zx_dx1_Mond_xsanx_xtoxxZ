
package axis;

public interface Aewebservices71PortType extends java.rmi.Remote {

    /**
     * Logout the current active session.
     */
    public void logout(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets the server version.
     */
    public java.lang.String getVersion() throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available applications.
     */
    public axis.ApplicationData[] getApplications(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available solutions.
     */
    public axis.SolutionData[] getSolutions(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available solutions.
     */
    public axis.SolutionWithUniqueName[] getSolutionsWithUniqueName(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available tables, optionally filtered by solution
     * and/or table type.
     */
    public axis.TableData[] getTables(axis.Auth auth, java.math.BigInteger solutionID, axis.TableType tableType) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available tables, optionally filtered by solution
     * name and/or table type.
     */
    public axis.TableData[] getTablesWithName(axis.Auth auth, java.lang.String solutionName, axis.TableType tableType) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets a filtered list of reports.
     */
    public axis.GetReportsResult getReports(axis.Auth auth, axis.QueryRange queryRange, axis.ReportsFilter reportsFilter) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Runs a specified report.
     */
    public axis.RunReportResult runReport(axis.Auth auth, axis.QueryRange queryRange, java.lang.String reportUUID, java.lang.String reportName, java.math.BigInteger reportID, java.math.BigInteger solutionID, java.lang.String solutionName, java.math.BigInteger projectID, java.lang.String projectName, java.lang.String projectUUID, java.math.BigInteger tableID, java.lang.String tableName, axis.ReportCategory reportCategory, axis.ReportAccessLevel reportAccessLevel) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates a project.
     */
    public axis.ProjectGeneralData createProject(axis.Auth auth, java.lang.String projectName, java.lang.String parentProject, java.lang.String workflow, java.lang.Boolean useParentProjectWorkflow, java.lang.Boolean allowSubmit, java.lang.Boolean useParentSequenceNumbers, java.math.BigInteger lastItemSequenceNumber, java.math.BigInteger zeroFillTo, java.lang.Boolean allowAnonymousSubmit, java.lang.String altName, java.lang.String description) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available projects available for submitting
     * new items, optionally filtered by table id.
     */
    public axis.ProjectData[] getSubmitProjects(axis.Auth auth, java.math.BigInteger tableID) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets the list of available projects available for submitting
     * new items, optionally filtered by table db name.
     */
    public axis.ProjectData[] getSubmitProjectsWithName(axis.Auth auth, java.lang.String tableDBName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates a new item, given a project id and item data.
     */
    public axis.TTItem createPrimaryItem(axis.Auth auth, java.math.BigInteger projectID, axis.TTItem item, java.math.BigInteger submitTransID, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates a new item, given a project name (fully qualified)
     * and item data.
     */
    public axis.TTItem createPrimaryItemWithName(axis.Auth auth, java.lang.String fullyQualifiedProjectName, axis.TTItem item, java.lang.String submitTransName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates a new item, given a table id and item data.
     */
    public axis.TTItem createAuxItem(axis.Auth auth, java.math.BigInteger tableID, axis.TTItem item, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates a new item, given a table database name and item data.
     */
    public axis.TTItem createAuxItemWithName(axis.Auth auth, java.lang.String tableDBName, axis.TTItem item, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates a several new primary items, given a project id and
     * a list of item data.
     */
    public axis.TTItem[] createPrimaryItems(axis.Auth auth, java.math.BigInteger projectID, axis.TTItem[] itemList, java.math.BigInteger submitTransID, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates a several new primary items, given a project fully
     * qualified name and a list of item data.
     */
    public axis.TTItem[] createPrimaryItemsWithName(axis.Auth auth, java.lang.String fullyQualifiedProjectName, axis.TTItem[] itemList, java.lang.String submitTransName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates several new primary items, given a project fully qualified
     * name and a list of item data.  Failures are interleaved with successfully
     * created items.
     */
    public axis.TTItemHolder[] createPrimaryItemsExtended(axis.Auth auth, java.lang.String fullyQualifiedProjectName, axis.TTItem[] itemList, java.lang.String submitTransName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates a several new aux items, given a table id and a list
     * of item data.
     */
    public axis.TTItem[] createAuxItems(axis.Auth auth, java.math.BigInteger tableID, axis.TTItem[] itemList, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates a several new aux items, given a table db name and
     * a list of item data.
     */
    public axis.TTItem[] createAuxItemsWithName(axis.Auth auth, java.lang.String tableDBName, axis.TTItem[] itemList, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Creates a new attachment, given item id of the item to which
     * it is to be attached, and the file attachment contents.
     */
    public axis.FileAttachment createFileAttachment(axis.Auth auth, java.lang.String itemID, axis.FileAttachmentContents attachmentContents) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Return an XML file (in OPC format), given an optional application
     * ID and 0 or more auxiliary table IDs.
     */
    public axis.FileContents export(axis.Auth auth, java.lang.String applicationID, axis.FileContents xmlExportOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Generates and returns a new UUID.
     */
    public java.lang.String generateUUID(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets an existing item, given a table id and internal item id.
     */
    public axis.TTItem getItem(axis.Auth auth, java.lang.String itemID, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets a list of existing items, given a table id and a list
     * of item ids.
     */
    public axis.TTItem[] getItems(axis.Auth auth, java.lang.String[] itemIdList, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets a list of existing items, given a table id, a query where
     * clause, an order by clause (optional) and a maximum return list size.
     */
    public axis.TTItem[] getItemsByQuery(axis.Auth auth, java.math.BigInteger tableID, java.lang.String queryWhereClause, java.lang.String orderByClause, java.math.BigInteger maxReturnSize, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets a list of existing items, given a table db name, a query
     * where clause, an order by clause (optional) and a maximum return list
     * size.
     */
    public axis.TTItem[] getItemsByQueryWithName(axis.Auth auth, java.lang.String tableDBName, java.lang.String queryWhereClause, java.lang.String orderByClause, java.math.BigInteger maxReturnSize, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets an existing file attachment, given an item id and attachment
     * id.
     */
    public axis.FileAttachmentContents getFileAttachment(axis.Auth auth, java.lang.String itemID, java.math.BigInteger attachmentID) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Import an application from an attached zip file containing
     * source XML.
     */
    public java.lang.String _import(axis.Auth auth, axis.FileContents xmlInFile, java.lang.String adminRepositoryID, java.lang.String importResponseEndPoint, java.lang.String importResponseID, axis.FileContents xmlImportOptions, boolean validateOnly) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Returns status of a specified Import.
     */
    public axis.ImportCurrentStatus importStatus(axis.Auth auth, java.lang.String importUUID) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Updates an existing item, given the item with the item id filled
     * in, plus any data to update, and transition id to use a non-default
     * transition.
     */
    public axis.TTItem updateItem(axis.Auth auth, axis.TTItem item, java.math.BigInteger transitionId, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Updates an existing item, given the item with the item id filled
     * in, plus any data to update, and transition name.
     */
    public axis.TTItem updateItemWithName(axis.Auth auth, axis.TTItem item, java.lang.String transitionName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Updates several existing items, given an item list and optionally
     * a transition id.
     */
    public axis.TTItem[] updateItems(axis.Auth auth, axis.TTItem[] itemList, java.math.BigInteger transitionId, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Updates several existing items, given an item list and optionally
     * a transition name.
     */
    public axis.TTItem[] updateItemsWithName(axis.Auth auth, axis.TTItem[] itemList, java.lang.String transitionName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Updates several existing items, given an item list and optionally
     * a transition name.
     */
    public axis.TTItemHolder[] updateItemsExtended(axis.Auth auth, axis.TTItem[] itemList, java.lang.String transitionName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Return available transitions, given an item id and attribute
     * name (may be null or empty).
     */
    public axis.Transition[] getAvailableTransitions(axis.Auth auth, java.lang.String itemID, java.lang.String attributeName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Return available transitions, given an item id and attribute
     * name (may be null or empty).
     */
    public axis.Transition[] getAvailableTransitionsWithStateIDs(axis.Auth auth, java.lang.String itemID, java.lang.String attributeName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Service definition of function ae__GetAvailableQuickTransitions
     */
    public axis.Transition[] getAvailableQuickTransitions(axis.Auth auth, java.lang.String itemID, java.lang.String attributeName) throws java.rmi.RemoteException;

    /**
     * Return available Submit transitions, given an item id and attribute
     * name (may be null or empty).
     */
    public axis.Transition[] getAvailableSubmitTransitions(axis.Auth auth, java.math.BigInteger projectId, java.lang.String attributeName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Return available Submit transitions, given an fully qualified
     * project name and attribute name (may be null or empty).
     */
    public axis.Transition[] getAvailableSubmitTransitionsWithName(axis.Auth auth, java.lang.String fullyQualifiedProjectName, java.lang.String attributeName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Updates an existing attachment, given item id, and the file
     * attachment contents.
     */
    public axis.FileAttachment updateFileAttachment(axis.Auth auth, java.lang.String itemID, axis.FileAttachmentContents attachmentContents) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Deletes an item, given a table id and item id.
     */
    public void deleteItem(axis.Auth auth, java.lang.String sItemID) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Deletes several items, given a table id and a list of item
     * ids.
     */
    public void deleteItems(axis.Auth auth, java.lang.String[] itemIdList) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Deletes one or more items, given a table id and a query where
     * clause.
     */
    public void deleteItemsByQuery(axis.Auth auth, java.math.BigInteger tableID, java.lang.String queryWhereClause) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Deletes one or more items, given a table db name and a query
     * where clause.
     */
    public void deleteItemsByQueryWithName(axis.Auth auth, java.lang.String tableDBName, java.lang.String queryWhereClause) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Deletes an existing attachment, which may be a note, item link,
     * URL attachment or file attachment, given an attachment id.
     */
    public void deleteAttachment(axis.Auth auth, java.math.BigInteger attachmentID) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Delete a mashup.
     */
    public void deleteMashup(axis.Auth auth, java.lang.String sMashupName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Checks for the specified privilege by name.
     */
    public boolean hasUserPrivilege(axis.Auth auth, java.lang.String privilegeName, java.lang.String objectId, java.lang.String loginId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Returns a list of privileges that the specified user has.
     */
    public axis.Privilege[] getUserPrivileges(axis.Auth auth, java.lang.String privilegeType, java.lang.String objectId, java.lang.String loginId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Returns user information for the specified user.
     */
    public axis.User getUser(axis.Auth auth, java.lang.String userId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Returns user information with date and time preferences for
     * the specified user.
     */
    public axis.UserWithPreferences getUserWithPreferences(axis.Auth auth, java.lang.String userId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Returns user information with date and time preferences, phone
     * number and locale for the specified user.
     */
    public axis.UserExtended getUserExtended(axis.Auth auth, java.lang.String userId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Determine if the specified user is valid.
     */
    public boolean isUserValid(axis.Auth auth, java.lang.String loginId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Returns note logger information.
     */
    public axis.NoteLoggerInfo getNoteLoggerInfo(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;

    /**
     * Gets the state change history of an existing item, given a
     * table id and internal item id.
     */
    public axis.GetStateChangeHistoryResult getStateChangeHistory(axis.Auth auth, java.lang.String itemID, axis.QueryRange queryRange) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault;
}
