
package axis;

public class Aewebservices71_BindingStub extends org.apache.axis.client.Stub implements axis.Aewebservices71PortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[56];
        _initOperationDesc1();
        _initOperationDesc2();
        _initOperationDesc3();
        _initOperationDesc4();
        _initOperationDesc5();
        _initOperationDesc6();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("Logout");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), 
                      false
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetVersion");
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetApplications");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "ApplicationData"));
        oper.setReturnClass(axis.ApplicationData[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetSolutions");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "SolutionData"));
        oper.setReturnClass(axis.SolutionData[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetSolutionsWithUniqueName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "SolutionWithUniqueName"));
        oper.setReturnClass(axis.SolutionWithUniqueName[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetTables");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "solutionID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Table-Type"), axis.TableType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TableData"));
        oper.setReturnClass(axis.TableData[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetTablesWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "solutionName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Table-Type"), axis.TableType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TableData"));
        oper.setReturnClass(axis.TableData[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetReports");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "queryRange"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "QueryRange"), axis.QueryRange.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "reportsFilter"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "ReportsFilter"), axis.ReportsFilter.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "GetReportsResult"));
        oper.setReturnClass(axis.GetReportsResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("RunReport");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "queryRange"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "QueryRange"), axis.QueryRange.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "reportUUID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "reportName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "reportID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "solutionID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "solutionName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "projectID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "projectName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "projectUUID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "reportCategory"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "ReportCategory"), axis.ReportCategory.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "reportAccessLevel"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "ReportAccessLevel"), axis.ReportAccessLevel.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "RunReportResult"));
        oper.setReturnClass(axis.RunReportResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateProject");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "projectName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "parentProject"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "workflow"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "useParentProjectWorkflow"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), java.lang.Boolean.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "allowSubmit"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), java.lang.Boolean.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "useParentSequenceNumbers"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), java.lang.Boolean.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "lastItemSequenceNumber"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "zeroFillTo"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "allowAnonymousSubmit"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), java.lang.Boolean.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "altName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "description"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "ProjectGeneralData"));
        oper.setReturnClass(axis.ProjectGeneralData.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetSubmitProjects");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "ProjectData"));
        oper.setReturnClass(axis.ProjectData[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetSubmitProjectsWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableDBName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "ProjectData"));
        oper.setReturnClass(axis.ProjectData[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreatePrimaryItem");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "projectID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "item"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "submitTransID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreatePrimaryItemWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "fullyQualifiedProjectName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "item"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "submitTransName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateAuxItem");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "item"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateAuxItemWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableDBName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "item"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreatePrimaryItems");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "projectID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "submitTransID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreatePrimaryItemsWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "fullyQualifiedProjectName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "submitTransName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[17] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreatePrimaryItemsExtended");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "fullyQualifiedProjectName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "submitTransName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItemHolder"));
        oper.setReturnClass(axis.TTItemHolder[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[18] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateAuxItems");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[19] = oper;

    }

    private static void _initOperationDesc3(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateAuxItemsWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableDBName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[20] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("CreateFileAttachment");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "attachmentContents"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "FileAttachmentContents"), axis.FileAttachmentContents.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "FileAttachment"));
        oper.setReturnClass(axis.FileAttachment.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[21] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("Export");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "applicationID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "xmlExportOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "FileContents"), axis.FileContents.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "FileContents"));
        oper.setReturnClass(axis.FileContents.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[22] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GenerateUUID");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[23] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetItem");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[24] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetItems");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemIdList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[25] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetItemsByQuery");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "queryWhereClause"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "orderByClause"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "maxReturnSize"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[26] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetItemsByQueryWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableDBName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "queryWhereClause"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "orderByClause"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "maxReturnSize"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[27] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetFileAttachment");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "attachmentID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "FileAttachmentContents"));
        oper.setReturnClass(axis.FileAttachmentContents.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[28] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("Import");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "xmlInFile"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "FileContents"), axis.FileContents.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "adminRepositoryID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "importResponseEndPoint"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "importResponseID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "xmlImportOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "FileContents"), axis.FileContents.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "validateOnly"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"), boolean.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        oper.setReturnClass(java.lang.String.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[29] = oper;

    }

    private static void _initOperationDesc4(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ImportStatus");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "importUUID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "ImportCurrentStatus"));
        oper.setReturnClass(axis.ImportCurrentStatus.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[30] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateItem");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "item"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "transitionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[31] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateItemWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "item"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "transitionName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[32] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateItems");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "transitionId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[33] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateItemsWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "transitionName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"));
        oper.setReturnClass(axis.TTItem[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[34] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateItemsExtended");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "TTItem"), axis.TTItem[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "transitionName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "responseOptions"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "TTItemHolder"));
        oper.setReturnClass(axis.TTItemHolder[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[35] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetAvailableTransitions");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "attributeName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "Transition"));
        oper.setReturnClass(axis.Transition[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[36] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetAvailableTransitionsWithStateIDs");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "attributeName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "Transition"));
        oper.setReturnClass(axis.Transition[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[37] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetAvailableQuickTransitions");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "attributeName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "Transition"));
        oper.setReturnClass(axis.Transition[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[38] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetAvailableSubmitTransitions");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "projectId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "attributeName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "Transition"));
        oper.setReturnClass(axis.Transition[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[39] = oper;

    }

    private static void _initOperationDesc5(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetAvailableSubmitTransitionsWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "fullyQualifiedProjectName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "attributeName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "Transition"));
        oper.setReturnClass(axis.Transition[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[40] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("UpdateFileAttachment");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "attachmentContents"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "FileAttachmentContents"), axis.FileAttachmentContents.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "FileAttachment"));
        oper.setReturnClass(axis.FileAttachment.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[41] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteItem");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "sItemID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[42] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteItems");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemIdList"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String[].class, false, false);
        param.setOmittable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[43] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteItemsByQuery");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "queryWhereClause"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[44] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteItemsByQueryWithName");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "tableDBName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "queryWhereClause"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[45] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteAttachment");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "attachmentID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"), java.math.BigInteger.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[46] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("DeleteMashup");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "sMashupName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(org.apache.axis.encoding.XMLType.AXIS_VOID);
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[47] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("HasUserPrivilege");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "privilegeName"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "objectId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "loginId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        oper.setReturnClass(boolean.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[48] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetUserPrivileges");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "privilegeType"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "objectId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "loginId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "Privilege"));
        oper.setReturnClass(axis.Privilege[].class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[49] = oper;

    }

    private static void _initOperationDesc6(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetUser");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "userId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "User"));
        oper.setReturnClass(axis.User.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[50] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetUserWithPreferences");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "userId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "UserWithPreferences"));
        oper.setReturnClass(axis.UserWithPreferences.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[51] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetUserExtended");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "userId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "UserExtended"));
        oper.setReturnClass(axis.UserExtended.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[52] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("IsUserValid");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "loginId"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        oper.setReturnClass(boolean.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[53] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetNoteLoggerInfo");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "NoteLoggerInfo"));
        oper.setReturnClass(axis.NoteLoggerInfo.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[54] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("GetStateChangeHistory");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "auth"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "Auth"), axis.Auth.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "itemID"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("urn:aewebservices71", "queryRange"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("urn:aewebservices71", "QueryRange"), axis.QueryRange.class, false, false);
        param.setOmittable(true);
        param.setNillable(true);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("urn:aewebservices71", "GetStateChangeHistoryResult"));
        oper.setReturnClass(axis.GetStateChangeHistoryResult.class);
        oper.setReturnQName(new javax.xml.namespace.QName("urn:aewebservices71", "return"));
        oper.setStyle(org.apache.axis.constants.Style.WRAPPED);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("urn:aewebservices71", "AEWebservicesFault"),
                      "axis.AEWebservicesFaultFault",
                      new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"),
                      false
                     ));
        _operations[55] = oper;

    }

    public Aewebservices71_BindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public Aewebservices71_BindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public Aewebservices71_BindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.1");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ApplicationData");
            cachedSerQNames.add(qName);
            cls = axis.ApplicationData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Attachment-Access-Type");
            cachedSerQNames.add(qName);
            cls = axis.AttachmentAccessType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Auth");
            cachedSerQNames.add(qName);
            cls = axis.Auth.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "DatePreference");
            cachedSerQNames.add(qName);
            cls = axis.DatePreference.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ExtraValue");
            cachedSerQNames.add(qName);
            cls = axis.ExtraValue.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Field");
            cachedSerQNames.add(qName);
            cls = axis.Field.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Field-Type");
            cachedSerQNames.add(qName);
            cls = axis.FieldType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "FileAttachment");
            cachedSerQNames.add(qName);
            cls = axis.FileAttachment.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "FileAttachmentContents");
            cachedSerQNames.add(qName);
            cls = axis.FileAttachmentContents.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "FileContents");
            cachedSerQNames.add(qName);
            cls = axis.FileContents.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "GetReportsResult");
            cachedSerQNames.add(qName);
            cls = axis.GetReportsResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "GetStateChangeHistoryResult");
            cachedSerQNames.add(qName);
            cls = axis.GetStateChangeHistoryResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ImportCurrentOverallStatus");
            cachedSerQNames.add(qName);
            cls = axis.ImportCurrentOverallStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ImportCurrentStatus");
            cachedSerQNames.add(qName);
            cls = axis.ImportCurrentStatus.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Item");
            cachedSerQNames.add(qName);
            cls = axis.Item.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ItemLink");
            cachedSerQNames.add(qName);
            cls = axis.ItemLink.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ItemLink-Type");
            cachedSerQNames.add(qName);
            cls = axis.ItemLinkType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "NameValue");
            cachedSerQNames.add(qName);
            cls = axis.NameValue.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Note");
            cachedSerQNames.add(qName);
            cls = axis.Note.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "NoteLoggerInfo");
            cachedSerQNames.add(qName);
            cls = axis.NoteLoggerInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "OrderBy");
            cachedSerQNames.add(qName);
            cls = axis.OrderBy.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Privilege");
            cachedSerQNames.add(qName);
            cls = axis.Privilege.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ProjectData");
            cachedSerQNames.add(qName);
            cls = axis.ProjectData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ProjectGeneralData");
            cachedSerQNames.add(qName);
            cls = axis.ProjectGeneralData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "QueryRange");
            cachedSerQNames.add(qName);
            cls = axis.QueryRange.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ReportAccessLevel");
            cachedSerQNames.add(qName);
            cls = axis.ReportAccessLevel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ReportCategory");
            cachedSerQNames.add(qName);
            cls = axis.ReportCategory.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ReportDefinition");
            cachedSerQNames.add(qName);
            cls = axis.ReportDefinition.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ReportInfo");
            cachedSerQNames.add(qName);
            cls = axis.ReportInfo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ReportResult");
            cachedSerQNames.add(qName);
            cls = axis.ReportResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ReportsFilter");
            cachedSerQNames.add(qName);
            cls = axis.ReportsFilter.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "ReportType");
            cachedSerQNames.add(qName);
            cls = axis.ReportType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "RunReportResult");
            cachedSerQNames.add(qName);
            cls = axis.RunReportResult.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Set-Value-By");
            cachedSerQNames.add(qName);
            cls = axis.SetValueBy.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Set-Value-Method");
            cachedSerQNames.add(qName);
            cls = axis.SetValueMethod.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Solution-Type");
            cachedSerQNames.add(qName);
            cls = axis.SolutionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "SolutionData");
            cachedSerQNames.add(qName);
            cls = axis.SolutionData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "SolutionWithUniqueName");
            cachedSerQNames.add(qName);
            cls = axis.SolutionWithUniqueName.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "StateChangeHistory");
            cachedSerQNames.add(qName);
            cls = axis.StateChangeHistory.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Table-Type");
            cachedSerQNames.add(qName);
            cls = axis.TableType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "TableData");
            cachedSerQNames.add(qName);
            cls = axis.TableData.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "TimePreference");
            cachedSerQNames.add(qName);
            cls = axis.TimePreference.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Transition");
            cachedSerQNames.add(qName);
            cls = axis.Transition.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Transition-Type");
            cachedSerQNames.add(qName);
            cls = axis.TransitionType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "TTItem");
            cachedSerQNames.add(qName);
            cls = axis.TTItem.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "TTItemHolder");
            cachedSerQNames.add(qName);
            cls = axis.TTItemHolder.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "URLAttachment");
            cachedSerQNames.add(qName);
            cls = axis.URLAttachment.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "User");
            cachedSerQNames.add(qName);
            cls = axis.User.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "UserExtended");
            cachedSerQNames.add(qName);
            cls = axis.UserExtended.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "UserWithPreferences");
            cachedSerQNames.add(qName);
            cls = axis.UserWithPreferences.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("urn:aewebservices71", "Value");
            cachedSerQNames.add(qName);
            cls = axis.Value.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public void logout(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "Logout"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public java.lang.String getVersion() throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetVersion"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.ApplicationData[] getApplications(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetApplications"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.ApplicationData[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.ApplicationData[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.ApplicationData[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.SolutionData[] getSolutions(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetSolutions"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.SolutionData[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.SolutionData[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.SolutionData[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.SolutionWithUniqueName[] getSolutionsWithUniqueName(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetSolutionsWithUniqueName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.SolutionWithUniqueName[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.SolutionWithUniqueName[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.SolutionWithUniqueName[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TableData[] getTables(axis.Auth auth, java.math.BigInteger solutionID, axis.TableType tableType) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetTables"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, solutionID, tableType});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TableData[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TableData[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TableData[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TableData[] getTablesWithName(axis.Auth auth, java.lang.String solutionName, axis.TableType tableType) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetTablesWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, solutionName, tableType});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TableData[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TableData[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TableData[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.GetReportsResult getReports(axis.Auth auth, axis.QueryRange queryRange, axis.ReportsFilter reportsFilter) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetReports"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, queryRange, reportsFilter});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.GetReportsResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.GetReportsResult) org.apache.axis.utils.JavaUtils.convert(_resp, axis.GetReportsResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.RunReportResult runReport(axis.Auth auth, axis.QueryRange queryRange, java.lang.String reportUUID, java.lang.String reportName, java.math.BigInteger reportID, java.math.BigInteger solutionID, java.lang.String solutionName, java.math.BigInteger projectID, java.lang.String projectName, java.lang.String projectUUID, java.math.BigInteger tableID, java.lang.String tableName, axis.ReportCategory reportCategory, axis.ReportAccessLevel reportAccessLevel) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "RunReport"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, queryRange, reportUUID, reportName, reportID, solutionID, solutionName, projectID, projectName, projectUUID, tableID, tableName, reportCategory, reportAccessLevel});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.RunReportResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.RunReportResult) org.apache.axis.utils.JavaUtils.convert(_resp, axis.RunReportResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.ProjectGeneralData createProject(axis.Auth auth, java.lang.String projectName, java.lang.String parentProject, java.lang.String workflow, java.lang.Boolean useParentProjectWorkflow, java.lang.Boolean allowSubmit, java.lang.Boolean useParentSequenceNumbers, java.math.BigInteger lastItemSequenceNumber, java.math.BigInteger zeroFillTo, java.lang.Boolean allowAnonymousSubmit, java.lang.String altName, java.lang.String description) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreateProject"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, projectName, parentProject, workflow, useParentProjectWorkflow, allowSubmit, useParentSequenceNumbers, lastItemSequenceNumber, zeroFillTo, allowAnonymousSubmit, altName, description});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.ProjectGeneralData) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.ProjectGeneralData) org.apache.axis.utils.JavaUtils.convert(_resp, axis.ProjectGeneralData.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.ProjectData[] getSubmitProjects(axis.Auth auth, java.math.BigInteger tableID) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetSubmitProjects"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, tableID});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.ProjectData[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.ProjectData[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.ProjectData[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.ProjectData[] getSubmitProjectsWithName(axis.Auth auth, java.lang.String tableDBName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetSubmitProjectsWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, tableDBName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.ProjectData[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.ProjectData[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.ProjectData[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem createPrimaryItem(axis.Auth auth, java.math.BigInteger projectID, axis.TTItem item, java.math.BigInteger submitTransID, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreatePrimaryItem"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, projectID, item, submitTransID, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem createPrimaryItemWithName(axis.Auth auth, java.lang.String fullyQualifiedProjectName, axis.TTItem item, java.lang.String submitTransName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreatePrimaryItemWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, fullyQualifiedProjectName, item, submitTransName, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem createAuxItem(axis.Auth auth, java.math.BigInteger tableID, axis.TTItem item, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreateAuxItem"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, tableID, item, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem createAuxItemWithName(axis.Auth auth, java.lang.String tableDBName, axis.TTItem item, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreateAuxItemWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, tableDBName, item, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem[] createPrimaryItems(axis.Auth auth, java.math.BigInteger projectID, axis.TTItem[] itemList, java.math.BigInteger submitTransID, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreatePrimaryItems"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, projectID, itemList, submitTransID, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem[] createPrimaryItemsWithName(axis.Auth auth, java.lang.String fullyQualifiedProjectName, axis.TTItem[] itemList, java.lang.String submitTransName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreatePrimaryItemsWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, fullyQualifiedProjectName, itemList, submitTransName, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItemHolder[] createPrimaryItemsExtended(axis.Auth auth, java.lang.String fullyQualifiedProjectName, axis.TTItem[] itemList, java.lang.String submitTransName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[18]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreatePrimaryItemsExtended"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, fullyQualifiedProjectName, itemList, submitTransName, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItemHolder[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItemHolder[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItemHolder[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem[] createAuxItems(axis.Auth auth, java.math.BigInteger tableID, axis.TTItem[] itemList, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[19]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreateAuxItems"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, tableID, itemList, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem[] createAuxItemsWithName(axis.Auth auth, java.lang.String tableDBName, axis.TTItem[] itemList, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[20]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreateAuxItemsWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, tableDBName, itemList, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.FileAttachment createFileAttachment(axis.Auth auth, java.lang.String itemID, axis.FileAttachmentContents attachmentContents) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[21]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "CreateFileAttachment"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemID, attachmentContents});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.FileAttachment) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.FileAttachment) org.apache.axis.utils.JavaUtils.convert(_resp, axis.FileAttachment.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.FileContents export(axis.Auth auth, java.lang.String applicationID, axis.FileContents xmlExportOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[22]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "Export"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, applicationID, xmlExportOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.FileContents) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.FileContents) org.apache.axis.utils.JavaUtils.convert(_resp, axis.FileContents.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public java.lang.String generateUUID(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[23]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GenerateUUID"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem getItem(axis.Auth auth, java.lang.String itemID, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[24]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetItem"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemID, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem[] getItems(axis.Auth auth, java.lang.String[] itemIdList, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[25]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetItems"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemIdList, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem[] getItemsByQuery(axis.Auth auth, java.math.BigInteger tableID, java.lang.String queryWhereClause, java.lang.String orderByClause, java.math.BigInteger maxReturnSize, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[26]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetItemsByQuery"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, tableID, queryWhereClause, orderByClause, maxReturnSize, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem[] getItemsByQueryWithName(axis.Auth auth, java.lang.String tableDBName, java.lang.String queryWhereClause, java.lang.String orderByClause, java.math.BigInteger maxReturnSize, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[27]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetItemsByQueryWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, tableDBName, queryWhereClause, orderByClause, maxReturnSize, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.FileAttachmentContents getFileAttachment(axis.Auth auth, java.lang.String itemID, java.math.BigInteger attachmentID) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[28]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetFileAttachment"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemID, attachmentID});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.FileAttachmentContents) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.FileAttachmentContents) org.apache.axis.utils.JavaUtils.convert(_resp, axis.FileAttachmentContents.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public java.lang.String _import(axis.Auth auth, axis.FileContents xmlInFile, java.lang.String adminRepositoryID, java.lang.String importResponseEndPoint, java.lang.String importResponseID, axis.FileContents xmlImportOptions, boolean validateOnly) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[29]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "Import"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, xmlInFile, adminRepositoryID, importResponseEndPoint, importResponseID, xmlImportOptions, new java.lang.Boolean(validateOnly)});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (java.lang.String) _resp;
            } catch (java.lang.Exception _exception) {
                return (java.lang.String) org.apache.axis.utils.JavaUtils.convert(_resp, java.lang.String.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.ImportCurrentStatus importStatus(axis.Auth auth, java.lang.String importUUID) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[30]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "ImportStatus"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, importUUID});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.ImportCurrentStatus) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.ImportCurrentStatus) org.apache.axis.utils.JavaUtils.convert(_resp, axis.ImportCurrentStatus.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem updateItem(axis.Auth auth, axis.TTItem item, java.math.BigInteger transitionId, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[31]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "UpdateItem"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, item, transitionId, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem updateItemWithName(axis.Auth auth, axis.TTItem item, java.lang.String transitionName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[32]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "UpdateItemWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, item, transitionName, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem[] updateItems(axis.Auth auth, axis.TTItem[] itemList, java.math.BigInteger transitionId, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[33]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "UpdateItems"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemList, transitionId, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItem[] updateItemsWithName(axis.Auth auth, axis.TTItem[] itemList, java.lang.String transitionName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[34]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "UpdateItemsWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemList, transitionName, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItem[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItem[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItem[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.TTItemHolder[] updateItemsExtended(axis.Auth auth, axis.TTItem[] itemList, java.lang.String transitionName, java.lang.String responseOptions) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[35]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "UpdateItemsExtended"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemList, transitionName, responseOptions});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.TTItemHolder[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.TTItemHolder[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.TTItemHolder[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.Transition[] getAvailableTransitions(axis.Auth auth, java.lang.String itemID, java.lang.String attributeName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[36]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetAvailableTransitions"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemID, attributeName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.Transition[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.Transition[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.Transition[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.Transition[] getAvailableTransitionsWithStateIDs(axis.Auth auth, java.lang.String itemID, java.lang.String attributeName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[37]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetAvailableTransitionsWithStateIDs"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemID, attributeName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.Transition[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.Transition[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.Transition[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.Transition[] getAvailableQuickTransitions(axis.Auth auth, java.lang.String itemID, java.lang.String attributeName) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[38]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetAvailableQuickTransitions"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemID, attributeName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.Transition[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.Transition[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.Transition[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public axis.Transition[] getAvailableSubmitTransitions(axis.Auth auth, java.math.BigInteger projectId, java.lang.String attributeName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[39]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetAvailableSubmitTransitions"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, projectId, attributeName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.Transition[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.Transition[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.Transition[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.Transition[] getAvailableSubmitTransitionsWithName(axis.Auth auth, java.lang.String fullyQualifiedProjectName, java.lang.String attributeName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[40]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetAvailableSubmitTransitionsWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, fullyQualifiedProjectName, attributeName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.Transition[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.Transition[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.Transition[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.FileAttachment updateFileAttachment(axis.Auth auth, java.lang.String itemID, axis.FileAttachmentContents attachmentContents) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[41]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "UpdateFileAttachment"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemID, attachmentContents});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.FileAttachment) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.FileAttachment) org.apache.axis.utils.JavaUtils.convert(_resp, axis.FileAttachment.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void deleteItem(axis.Auth auth, java.lang.String sItemID) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[42]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "DeleteItem"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, sItemID});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void deleteItems(axis.Auth auth, java.lang.String[] itemIdList) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[43]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "DeleteItems"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemIdList});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void deleteItemsByQuery(axis.Auth auth, java.math.BigInteger tableID, java.lang.String queryWhereClause) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[44]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "DeleteItemsByQuery"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, tableID, queryWhereClause});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void deleteItemsByQueryWithName(axis.Auth auth, java.lang.String tableDBName, java.lang.String queryWhereClause) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[45]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "DeleteItemsByQueryWithName"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, tableDBName, queryWhereClause});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void deleteAttachment(axis.Auth auth, java.math.BigInteger attachmentID) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[46]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "DeleteAttachment"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, attachmentID});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public void deleteMashup(axis.Auth auth, java.lang.String sMashupName) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[47]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "DeleteMashup"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, sMashupName});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        extractAttachments(_call);
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public boolean hasUserPrivilege(axis.Auth auth, java.lang.String privilegeName, java.lang.String objectId, java.lang.String loginId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[48]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "HasUserPrivilege"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, privilegeName, objectId, loginId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Boolean) _resp).booleanValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_resp, boolean.class)).booleanValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.Privilege[] getUserPrivileges(axis.Auth auth, java.lang.String privilegeType, java.lang.String objectId, java.lang.String loginId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[49]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetUserPrivileges"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, privilegeType, objectId, loginId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.Privilege[]) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.Privilege[]) org.apache.axis.utils.JavaUtils.convert(_resp, axis.Privilege[].class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.User getUser(axis.Auth auth, java.lang.String userId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[50]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetUser"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, userId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.User) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.User) org.apache.axis.utils.JavaUtils.convert(_resp, axis.User.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.UserWithPreferences getUserWithPreferences(axis.Auth auth, java.lang.String userId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[51]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetUserWithPreferences"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, userId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.UserWithPreferences) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.UserWithPreferences) org.apache.axis.utils.JavaUtils.convert(_resp, axis.UserWithPreferences.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.UserExtended getUserExtended(axis.Auth auth, java.lang.String userId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[52]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetUserExtended"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, userId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.UserExtended) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.UserExtended) org.apache.axis.utils.JavaUtils.convert(_resp, axis.UserExtended.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public boolean isUserValid(axis.Auth auth, java.lang.String loginId) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[53]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "IsUserValid"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, loginId});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return ((java.lang.Boolean) _resp).booleanValue();
            } catch (java.lang.Exception _exception) {
                return ((java.lang.Boolean) org.apache.axis.utils.JavaUtils.convert(_resp, boolean.class)).booleanValue();
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.NoteLoggerInfo getNoteLoggerInfo(axis.Auth auth) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[54]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetNoteLoggerInfo"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.NoteLoggerInfo) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.NoteLoggerInfo) org.apache.axis.utils.JavaUtils.convert(_resp, axis.NoteLoggerInfo.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public axis.GetStateChangeHistoryResult getStateChangeHistory(axis.Auth auth, java.lang.String itemID, axis.QueryRange queryRange) throws java.rmi.RemoteException, axis.AEWebservicesFaultFault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[55]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("urn:aewebservices71", "GetStateChangeHistory"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {auth, itemID, queryRange});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (axis.GetStateChangeHistoryResult) _resp;
            } catch (java.lang.Exception _exception) {
                return (axis.GetStateChangeHistoryResult) org.apache.axis.utils.JavaUtils.convert(_resp, axis.GetStateChangeHistoryResult.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof axis.AEWebservicesFaultFault) {
              throw (axis.AEWebservicesFaultFault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
