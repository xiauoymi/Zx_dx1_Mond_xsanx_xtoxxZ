
package axis;

public class ApplicationData  implements java.io.Serializable {
    private java.math.BigInteger applicationID;

    private java.lang.String applicationUUID;

    private java.lang.String name;

    private java.lang.String description;

    private java.lang.String appDefUUID;

    private java.lang.String revision;

    public ApplicationData() {
    }

    public ApplicationData(
           java.math.BigInteger applicationID,
           java.lang.String applicationUUID,
           java.lang.String name,
           java.lang.String description,
           java.lang.String appDefUUID,
           java.lang.String revision) {
           this.applicationID = applicationID;
           this.applicationUUID = applicationUUID;
           this.name = name;
           this.description = description;
           this.appDefUUID = appDefUUID;
           this.revision = revision;
    }


    /**
     * Gets the applicationID value for this ApplicationData.
     *
     * @return applicationID
     */
    public java.math.BigInteger getApplicationID() {
        return applicationID;
    }


    /**
     * Sets the applicationID value for this ApplicationData.
     *
     * @param applicationID
     */
    public void setApplicationID(java.math.BigInteger applicationID) {
        this.applicationID = applicationID;
    }


    /**
     * Gets the applicationUUID value for this ApplicationData.
     *
     * @return applicationUUID
     */
    public java.lang.String getApplicationUUID() {
        return applicationUUID;
    }


    /**
     * Sets the applicationUUID value for this ApplicationData.
     *
     * @param applicationUUID
     */
    public void setApplicationUUID(java.lang.String applicationUUID) {
        this.applicationUUID = applicationUUID;
    }


    /**
     * Gets the name value for this ApplicationData.
     *
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this ApplicationData.
     *
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the description value for this ApplicationData.
     *
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this ApplicationData.
     *
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the appDefUUID value for this ApplicationData.
     *
     * @return appDefUUID
     */
    public java.lang.String getAppDefUUID() {
        return appDefUUID;
    }


    /**
     * Sets the appDefUUID value for this ApplicationData.
     *
     * @param appDefUUID
     */
    public void setAppDefUUID(java.lang.String appDefUUID) {
        this.appDefUUID = appDefUUID;
    }


    /**
     * Gets the revision value for this ApplicationData.
     *
     * @return revision
     */
    public java.lang.String getRevision() {
        return revision;
    }


    /**
     * Sets the revision value for this ApplicationData.
     *
     * @param revision
     */
    public void setRevision(java.lang.String revision) {
        this.revision = revision;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ApplicationData)) return false;
        ApplicationData other = (ApplicationData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.applicationID==null && other.getApplicationID()==null) ||
             (this.applicationID!=null &&
              this.applicationID.equals(other.getApplicationID()))) &&
            ((this.applicationUUID==null && other.getApplicationUUID()==null) ||
             (this.applicationUUID!=null &&
              this.applicationUUID.equals(other.getApplicationUUID()))) &&
            ((this.name==null && other.getName()==null) ||
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.description==null && other.getDescription()==null) ||
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.appDefUUID==null && other.getAppDefUUID()==null) ||
             (this.appDefUUID!=null &&
              this.appDefUUID.equals(other.getAppDefUUID()))) &&
            ((this.revision==null && other.getRevision()==null) ||
             (this.revision!=null &&
              this.revision.equals(other.getRevision())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getApplicationID() != null) {
            _hashCode += getApplicationID().hashCode();
        }
        if (getApplicationUUID() != null) {
            _hashCode += getApplicationUUID().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getAppDefUUID() != null) {
            _hashCode += getAppDefUUID().hashCode();
        }
        if (getRevision() != null) {
            _hashCode += getRevision().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ApplicationData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ApplicationData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("applicationID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "applicationID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("applicationUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "applicationUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("appDefUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "appDefUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("revision");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "revision"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
