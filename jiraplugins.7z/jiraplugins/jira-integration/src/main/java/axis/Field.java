
package axis;

public class Field  implements java.io.Serializable {
    private java.math.BigInteger fieldID;

    private java.lang.String fieldUUID;

    private java.lang.String name;

    private java.lang.String displayName;

    private axis.FieldType fieldType;

    public Field() {
    }

    public Field(
           java.math.BigInteger fieldID,
           java.lang.String fieldUUID,
           java.lang.String name,
           java.lang.String displayName,
           axis.FieldType fieldType) {
           this.fieldID = fieldID;
           this.fieldUUID = fieldUUID;
           this.name = name;
           this.displayName = displayName;
           this.fieldType = fieldType;
    }


    /**
     * Gets the fieldID value for this Field.
     *
     * @return fieldID
     */
    public java.math.BigInteger getFieldID() {
        return fieldID;
    }


    /**
     * Sets the fieldID value for this Field.
     *
     * @param fieldID
     */
    public void setFieldID(java.math.BigInteger fieldID) {
        this.fieldID = fieldID;
    }


    /**
     * Gets the fieldUUID value for this Field.
     *
     * @return fieldUUID
     */
    public java.lang.String getFieldUUID() {
        return fieldUUID;
    }


    /**
     * Sets the fieldUUID value for this Field.
     *
     * @param fieldUUID
     */
    public void setFieldUUID(java.lang.String fieldUUID) {
        this.fieldUUID = fieldUUID;
    }


    /**
     * Gets the name value for this Field.
     *
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Field.
     *
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the displayName value for this Field.
     *
     * @return displayName
     */
    public java.lang.String getDisplayName() {
        return displayName;
    }


    /**
     * Sets the displayName value for this Field.
     *
     * @param displayName
     */
    public void setDisplayName(java.lang.String displayName) {
        this.displayName = displayName;
    }


    /**
     * Gets the fieldType value for this Field.
     *
     * @return fieldType
     */
    public axis.FieldType getFieldType() {
        return fieldType;
    }


    /**
     * Sets the fieldType value for this Field.
     *
     * @param fieldType
     */
    public void setFieldType(axis.FieldType fieldType) {
        this.fieldType = fieldType;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Field)) return false;
        Field other = (Field) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.fieldID==null && other.getFieldID()==null) ||
             (this.fieldID!=null &&
              this.fieldID.equals(other.getFieldID()))) &&
            ((this.fieldUUID==null && other.getFieldUUID()==null) ||
             (this.fieldUUID!=null &&
              this.fieldUUID.equals(other.getFieldUUID()))) &&
            ((this.name==null && other.getName()==null) ||
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.displayName==null && other.getDisplayName()==null) ||
             (this.displayName!=null &&
              this.displayName.equals(other.getDisplayName()))) &&
            ((this.fieldType==null && other.getFieldType()==null) ||
             (this.fieldType!=null &&
              this.fieldType.equals(other.getFieldType())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFieldID() != null) {
            _hashCode += getFieldID().hashCode();
        }
        if (getFieldUUID() != null) {
            _hashCode += getFieldUUID().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getDisplayName() != null) {
            _hashCode += getDisplayName().hashCode();
        }
        if (getFieldType() != null) {
            _hashCode += getFieldType().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Field.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Field"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fieldID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "fieldID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fieldUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "fieldUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("displayName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "displayName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fieldType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "fieldType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Field-Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
