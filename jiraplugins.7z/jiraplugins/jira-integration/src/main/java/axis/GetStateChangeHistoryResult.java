
package axis;

public class GetStateChangeHistoryResult  implements java.io.Serializable {
    private axis.QueryRange queryRange;

    private axis.StateChangeHistory[] stateChangeHistoryList;

    public GetStateChangeHistoryResult() {
    }

    public GetStateChangeHistoryResult(
           axis.QueryRange queryRange,
           axis.StateChangeHistory[] stateChangeHistoryList) {
           this.queryRange = queryRange;
           this.stateChangeHistoryList = stateChangeHistoryList;
    }


    /**
     * Gets the queryRange value for this GetStateChangeHistoryResult.
     * 
     * @return queryRange
     */
    public axis.QueryRange getQueryRange() {
        return queryRange;
    }


    /**
     * Sets the queryRange value for this GetStateChangeHistoryResult.
     * 
     * @param queryRange
     */
    public void setQueryRange(axis.QueryRange queryRange) {
        this.queryRange = queryRange;
    }


    /**
     * Gets the stateChangeHistoryList value for this GetStateChangeHistoryResult.
     * 
     * @return stateChangeHistoryList
     */
    public axis.StateChangeHistory[] getStateChangeHistoryList() {
        return stateChangeHistoryList;
    }


    /**
     * Sets the stateChangeHistoryList value for this GetStateChangeHistoryResult.
     * 
     * @param stateChangeHistoryList
     */
    public void setStateChangeHistoryList(axis.StateChangeHistory[] stateChangeHistoryList) {
        this.stateChangeHistoryList = stateChangeHistoryList;
    }

    public axis.StateChangeHistory getStateChangeHistoryList(int i) {
        return this.stateChangeHistoryList[i];
    }

    public void setStateChangeHistoryList(int i, axis.StateChangeHistory _value) {
        this.stateChangeHistoryList[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GetStateChangeHistoryResult)) return false;
        GetStateChangeHistoryResult other = (GetStateChangeHistoryResult) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.queryRange==null && other.getQueryRange()==null) ||
             (this.queryRange!=null &&
              this.queryRange.equals(other.getQueryRange()))) &&
            ((this.stateChangeHistoryList==null && other.getStateChangeHistoryList()==null) ||
             (this.stateChangeHistoryList!=null &&
              java.util.Arrays.equals(this.stateChangeHistoryList, other.getStateChangeHistoryList())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQueryRange() != null) {
            _hashCode += getQueryRange().hashCode();
        }
        if (getStateChangeHistoryList() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getStateChangeHistoryList());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getStateChangeHistoryList(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GetStateChangeHistoryResult.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "GetStateChangeHistoryResult"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("queryRange");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "queryRange"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "QueryRange"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("stateChangeHistoryList");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "stateChangeHistoryList"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "StateChangeHistory"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
