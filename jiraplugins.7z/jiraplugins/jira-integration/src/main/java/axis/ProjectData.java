
package axis;

public class ProjectData  implements java.io.Serializable {
    private java.math.BigInteger projectID;

    private java.lang.String projectUUID;

    private java.lang.String name;

    private java.lang.String fullyQualifiedName;

    private java.lang.String description;

    public ProjectData() {
    }

    public ProjectData(
           java.math.BigInteger projectID,
           java.lang.String projectUUID,
           java.lang.String name,
           java.lang.String fullyQualifiedName,
           java.lang.String description) {
           this.projectID = projectID;
           this.projectUUID = projectUUID;
           this.name = name;
           this.fullyQualifiedName = fullyQualifiedName;
           this.description = description;
    }


    /**
     * Gets the projectID value for this ProjectData.
     *
     * @return projectID
     */
    public java.math.BigInteger getProjectID() {
        return projectID;
    }


    /**
     * Sets the projectID value for this ProjectData.
     *
     * @param projectID
     */
    public void setProjectID(java.math.BigInteger projectID) {
        this.projectID = projectID;
    }


    /**
     * Gets the projectUUID value for this ProjectData.
     *
     * @return projectUUID
     */
    public java.lang.String getProjectUUID() {
        return projectUUID;
    }


    /**
     * Sets the projectUUID value for this ProjectData.
     *
     * @param projectUUID
     */
    public void setProjectUUID(java.lang.String projectUUID) {
        this.projectUUID = projectUUID;
    }


    /**
     * Gets the name value for this ProjectData.
     *
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this ProjectData.
     *
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the fullyQualifiedName value for this ProjectData.
     *
     * @return fullyQualifiedName
     */
    public java.lang.String getFullyQualifiedName() {
        return fullyQualifiedName;
    }


    /**
     * Sets the fullyQualifiedName value for this ProjectData.
     *
     * @param fullyQualifiedName
     */
    public void setFullyQualifiedName(java.lang.String fullyQualifiedName) {
        this.fullyQualifiedName = fullyQualifiedName;
    }


    /**
     * Gets the description value for this ProjectData.
     *
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this ProjectData.
     *
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProjectData)) return false;
        ProjectData other = (ProjectData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.projectID==null && other.getProjectID()==null) ||
             (this.projectID!=null &&
              this.projectID.equals(other.getProjectID()))) &&
            ((this.projectUUID==null && other.getProjectUUID()==null) ||
             (this.projectUUID!=null &&
              this.projectUUID.equals(other.getProjectUUID()))) &&
            ((this.name==null && other.getName()==null) ||
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.fullyQualifiedName==null && other.getFullyQualifiedName()==null) ||
             (this.fullyQualifiedName!=null &&
              this.fullyQualifiedName.equals(other.getFullyQualifiedName()))) &&
            ((this.description==null && other.getDescription()==null) ||
             (this.description!=null &&
              this.description.equals(other.getDescription())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProjectID() != null) {
            _hashCode += getProjectID().hashCode();
        }
        if (getProjectUUID() != null) {
            _hashCode += getProjectUUID().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getFullyQualifiedName() != null) {
            _hashCode += getFullyQualifiedName().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProjectData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ProjectData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fullyQualifiedName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "fullyQualifiedName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
