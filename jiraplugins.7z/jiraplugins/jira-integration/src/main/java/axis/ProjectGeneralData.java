
package axis;

public class ProjectGeneralData  implements java.io.Serializable {
    private java.math.BigInteger projectID;

    private java.lang.String projectUUID;

    private java.lang.String projectName;

    private java.lang.String parentProject;

    private java.lang.String workflow;

    private boolean useParentProjectWorkflow;

    private java.math.BigInteger projectSequence;

    private boolean allowSubmit;

    private boolean useParentSequenceNumbers;

    private java.math.BigInteger lastItemSequenceNumber;

    private java.math.BigInteger zeroFillTo;

    private boolean allowAnonymousSubmit;

    private java.lang.String altName;

    private java.lang.String description;

    public ProjectGeneralData() {
    }

    public ProjectGeneralData(
           java.math.BigInteger projectID,
           java.lang.String projectUUID,
           java.lang.String projectName,
           java.lang.String parentProject,
           java.lang.String workflow,
           boolean useParentProjectWorkflow,
           java.math.BigInteger projectSequence,
           boolean allowSubmit,
           boolean useParentSequenceNumbers,
           java.math.BigInteger lastItemSequenceNumber,
           java.math.BigInteger zeroFillTo,
           boolean allowAnonymousSubmit,
           java.lang.String altName,
           java.lang.String description) {
           this.projectID = projectID;
           this.projectUUID = projectUUID;
           this.projectName = projectName;
           this.parentProject = parentProject;
           this.workflow = workflow;
           this.useParentProjectWorkflow = useParentProjectWorkflow;
           this.projectSequence = projectSequence;
           this.allowSubmit = allowSubmit;
           this.useParentSequenceNumbers = useParentSequenceNumbers;
           this.lastItemSequenceNumber = lastItemSequenceNumber;
           this.zeroFillTo = zeroFillTo;
           this.allowAnonymousSubmit = allowAnonymousSubmit;
           this.altName = altName;
           this.description = description;
    }


    /**
     * Gets the projectID value for this ProjectGeneralData.
     *
     * @return projectID
     */
    public java.math.BigInteger getProjectID() {
        return projectID;
    }


    /**
     * Sets the projectID value for this ProjectGeneralData.
     *
     * @param projectID
     */
    public void setProjectID(java.math.BigInteger projectID) {
        this.projectID = projectID;
    }


    /**
     * Gets the projectUUID value for this ProjectGeneralData.
     *
     * @return projectUUID
     */
    public java.lang.String getProjectUUID() {
        return projectUUID;
    }


    /**
     * Sets the projectUUID value for this ProjectGeneralData.
     *
     * @param projectUUID
     */
    public void setProjectUUID(java.lang.String projectUUID) {
        this.projectUUID = projectUUID;
    }


    /**
     * Gets the projectName value for this ProjectGeneralData.
     *
     * @return projectName
     */
    public java.lang.String getProjectName() {
        return projectName;
    }


    /**
     * Sets the projectName value for this ProjectGeneralData.
     *
     * @param projectName
     */
    public void setProjectName(java.lang.String projectName) {
        this.projectName = projectName;
    }


    /**
     * Gets the parentProject value for this ProjectGeneralData.
     *
     * @return parentProject
     */
    public java.lang.String getParentProject() {
        return parentProject;
    }


    /**
     * Sets the parentProject value for this ProjectGeneralData.
     *
     * @param parentProject
     */
    public void setParentProject(java.lang.String parentProject) {
        this.parentProject = parentProject;
    }


    /**
     * Gets the workflow value for this ProjectGeneralData.
     *
     * @return workflow
     */
    public java.lang.String getWorkflow() {
        return workflow;
    }


    /**
     * Sets the workflow value for this ProjectGeneralData.
     *
     * @param workflow
     */
    public void setWorkflow(java.lang.String workflow) {
        this.workflow = workflow;
    }


    /**
     * Gets the useParentProjectWorkflow value for this ProjectGeneralData.
     *
     * @return useParentProjectWorkflow
     */
    public boolean isUseParentProjectWorkflow() {
        return useParentProjectWorkflow;
    }


    /**
     * Sets the useParentProjectWorkflow value for this ProjectGeneralData.
     *
     * @param useParentProjectWorkflow
     */
    public void setUseParentProjectWorkflow(boolean useParentProjectWorkflow) {
        this.useParentProjectWorkflow = useParentProjectWorkflow;
    }


    /**
     * Gets the projectSequence value for this ProjectGeneralData.
     *
     * @return projectSequence
     */
    public java.math.BigInteger getProjectSequence() {
        return projectSequence;
    }


    /**
     * Sets the projectSequence value for this ProjectGeneralData.
     *
     * @param projectSequence
     */
    public void setProjectSequence(java.math.BigInteger projectSequence) {
        this.projectSequence = projectSequence;
    }


    /**
     * Gets the allowSubmit value for this ProjectGeneralData.
     *
     * @return allowSubmit
     */
    public boolean isAllowSubmit() {
        return allowSubmit;
    }


    /**
     * Sets the allowSubmit value for this ProjectGeneralData.
     *
     * @param allowSubmit
     */
    public void setAllowSubmit(boolean allowSubmit) {
        this.allowSubmit = allowSubmit;
    }


    /**
     * Gets the useParentSequenceNumbers value for this ProjectGeneralData.
     *
     * @return useParentSequenceNumbers
     */
    public boolean isUseParentSequenceNumbers() {
        return useParentSequenceNumbers;
    }


    /**
     * Sets the useParentSequenceNumbers value for this ProjectGeneralData.
     *
     * @param useParentSequenceNumbers
     */
    public void setUseParentSequenceNumbers(boolean useParentSequenceNumbers) {
        this.useParentSequenceNumbers = useParentSequenceNumbers;
    }


    /**
     * Gets the lastItemSequenceNumber value for this ProjectGeneralData.
     *
     * @return lastItemSequenceNumber
     */
    public java.math.BigInteger getLastItemSequenceNumber() {
        return lastItemSequenceNumber;
    }


    /**
     * Sets the lastItemSequenceNumber value for this ProjectGeneralData.
     *
     * @param lastItemSequenceNumber
     */
    public void setLastItemSequenceNumber(java.math.BigInteger lastItemSequenceNumber) {
        this.lastItemSequenceNumber = lastItemSequenceNumber;
    }


    /**
     * Gets the zeroFillTo value for this ProjectGeneralData.
     *
     * @return zeroFillTo
     */
    public java.math.BigInteger getZeroFillTo() {
        return zeroFillTo;
    }


    /**
     * Sets the zeroFillTo value for this ProjectGeneralData.
     *
     * @param zeroFillTo
     */
    public void setZeroFillTo(java.math.BigInteger zeroFillTo) {
        this.zeroFillTo = zeroFillTo;
    }


    /**
     * Gets the allowAnonymousSubmit value for this ProjectGeneralData.
     *
     * @return allowAnonymousSubmit
     */
    public boolean isAllowAnonymousSubmit() {
        return allowAnonymousSubmit;
    }


    /**
     * Sets the allowAnonymousSubmit value for this ProjectGeneralData.
     *
     * @param allowAnonymousSubmit
     */
    public void setAllowAnonymousSubmit(boolean allowAnonymousSubmit) {
        this.allowAnonymousSubmit = allowAnonymousSubmit;
    }


    /**
     * Gets the altName value for this ProjectGeneralData.
     *
     * @return altName
     */
    public java.lang.String getAltName() {
        return altName;
    }


    /**
     * Sets the altName value for this ProjectGeneralData.
     *
     * @param altName
     */
    public void setAltName(java.lang.String altName) {
        this.altName = altName;
    }


    /**
     * Gets the description value for this ProjectGeneralData.
     *
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this ProjectGeneralData.
     *
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProjectGeneralData)) return false;
        ProjectGeneralData other = (ProjectGeneralData) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.projectID==null && other.getProjectID()==null) ||
             (this.projectID!=null &&
              this.projectID.equals(other.getProjectID()))) &&
            ((this.projectUUID==null && other.getProjectUUID()==null) ||
             (this.projectUUID!=null &&
              this.projectUUID.equals(other.getProjectUUID()))) &&
            ((this.projectName==null && other.getProjectName()==null) ||
             (this.projectName!=null &&
              this.projectName.equals(other.getProjectName()))) &&
            ((this.parentProject==null && other.getParentProject()==null) ||
             (this.parentProject!=null &&
              this.parentProject.equals(other.getParentProject()))) &&
            ((this.workflow==null && other.getWorkflow()==null) ||
             (this.workflow!=null &&
              this.workflow.equals(other.getWorkflow()))) &&
            this.useParentProjectWorkflow == other.isUseParentProjectWorkflow() &&
            ((this.projectSequence==null && other.getProjectSequence()==null) ||
             (this.projectSequence!=null &&
              this.projectSequence.equals(other.getProjectSequence()))) &&
            this.allowSubmit == other.isAllowSubmit() &&
            this.useParentSequenceNumbers == other.isUseParentSequenceNumbers() &&
            ((this.lastItemSequenceNumber==null && other.getLastItemSequenceNumber()==null) ||
             (this.lastItemSequenceNumber!=null &&
              this.lastItemSequenceNumber.equals(other.getLastItemSequenceNumber()))) &&
            ((this.zeroFillTo==null && other.getZeroFillTo()==null) ||
             (this.zeroFillTo!=null &&
              this.zeroFillTo.equals(other.getZeroFillTo()))) &&
            this.allowAnonymousSubmit == other.isAllowAnonymousSubmit() &&
            ((this.altName==null && other.getAltName()==null) ||
             (this.altName!=null &&
              this.altName.equals(other.getAltName()))) &&
            ((this.description==null && other.getDescription()==null) ||
             (this.description!=null &&
              this.description.equals(other.getDescription())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProjectID() != null) {
            _hashCode += getProjectID().hashCode();
        }
        if (getProjectUUID() != null) {
            _hashCode += getProjectUUID().hashCode();
        }
        if (getProjectName() != null) {
            _hashCode += getProjectName().hashCode();
        }
        if (getParentProject() != null) {
            _hashCode += getParentProject().hashCode();
        }
        if (getWorkflow() != null) {
            _hashCode += getWorkflow().hashCode();
        }
        _hashCode += (isUseParentProjectWorkflow() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getProjectSequence() != null) {
            _hashCode += getProjectSequence().hashCode();
        }
        _hashCode += (isAllowSubmit() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isUseParentSequenceNumbers() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getLastItemSequenceNumber() != null) {
            _hashCode += getLastItemSequenceNumber().hashCode();
        }
        if (getZeroFillTo() != null) {
            _hashCode += getZeroFillTo().hashCode();
        }
        _hashCode += (isAllowAnonymousSubmit() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getAltName() != null) {
            _hashCode += getAltName().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProjectGeneralData.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ProjectGeneralData"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parentProject");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "parentProject"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("workflow");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "workflow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("useParentProjectWorkflow");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "useParentProjectWorkflow"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectSequence");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectSequence"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowSubmit");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "allowSubmit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("useParentSequenceNumbers");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "useParentSequenceNumbers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lastItemSequenceNumber");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "lastItemSequenceNumber"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("zeroFillTo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "zeroFillTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allowAnonymousSubmit");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "allowAnonymousSubmit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("altName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "altName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
