
package axis;

public class ReportDefinition  implements java.io.Serializable {
    private axis.OrderBy orderBy;

    private axis.Field[] columns;

    public ReportDefinition() {
    }

    public ReportDefinition(
           axis.OrderBy orderBy,
           axis.Field[] columns) {
           this.orderBy = orderBy;
           this.columns = columns;
    }


    /**
     * Gets the orderBy value for this ReportDefinition.
     * 
     * @return orderBy
     */
    public axis.OrderBy getOrderBy() {
        return orderBy;
    }


    /**
     * Sets the orderBy value for this ReportDefinition.
     * 
     * @param orderBy
     */
    public void setOrderBy(axis.OrderBy orderBy) {
        this.orderBy = orderBy;
    }


    /**
     * Gets the columns value for this ReportDefinition.
     * 
     * @return columns
     */
    public axis.Field[] getColumns() {
        return columns;
    }


    /**
     * Sets the columns value for this ReportDefinition.
     * 
     * @param columns
     */
    public void setColumns(axis.Field[] columns) {
        this.columns = columns;
    }

    public axis.Field getColumns(int i) {
        return this.columns[i];
    }

    public void setColumns(int i, axis.Field _value) {
        this.columns[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ReportDefinition)) return false;
        ReportDefinition other = (ReportDefinition) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.orderBy==null && other.getOrderBy()==null) ||
             (this.orderBy!=null &&
              this.orderBy.equals(other.getOrderBy()))) &&
            ((this.columns==null && other.getColumns()==null) ||
             (this.columns!=null &&
              java.util.Arrays.equals(this.columns, other.getColumns())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOrderBy() != null) {
            _hashCode += getOrderBy().hashCode();
        }
        if (getColumns() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getColumns());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getColumns(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ReportDefinition.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ReportDefinition"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("orderBy");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "orderBy"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "OrderBy"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("columns");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "columns"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Field"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
