
package axis;

public class ReportsFilter  implements java.io.Serializable {
    private java.math.BigInteger solutionID;

    private java.lang.String solutionName;

    private java.math.BigInteger projectID;

    private java.lang.String projectName;

    private java.lang.String projectUUID;

    private java.math.BigInteger tableID;

    private java.lang.String tableName;

    private java.lang.String authorID;

    private axis.ReportType reportType;

    private axis.ReportCategory reportCategory;

    private axis.ReportAccessLevel reportAccessLevel;

    private java.lang.String reportName;

    private java.lang.Boolean includeSubProjects;

    private java.util.Calendar createdDateFrom;

    private java.util.Calendar createdDateTo;

    public ReportsFilter() {
    }

    public ReportsFilter(
           java.math.BigInteger solutionID,
           java.lang.String solutionName,
           java.math.BigInteger projectID,
           java.lang.String projectName,
           java.lang.String projectUUID,
           java.math.BigInteger tableID,
           java.lang.String tableName,
           java.lang.String authorID,
           axis.ReportType reportType,
           axis.ReportCategory reportCategory,
           axis.ReportAccessLevel reportAccessLevel,
           java.lang.String reportName,
           java.lang.Boolean includeSubProjects,
           java.util.Calendar createdDateFrom,
           java.util.Calendar createdDateTo) {
           this.solutionID = solutionID;
           this.solutionName = solutionName;
           this.projectID = projectID;
           this.projectName = projectName;
           this.projectUUID = projectUUID;
           this.tableID = tableID;
           this.tableName = tableName;
           this.authorID = authorID;
           this.reportType = reportType;
           this.reportCategory = reportCategory;
           this.reportAccessLevel = reportAccessLevel;
           this.reportName = reportName;
           this.includeSubProjects = includeSubProjects;
           this.createdDateFrom = createdDateFrom;
           this.createdDateTo = createdDateTo;
    }


    /**
     * Gets the solutionID value for this ReportsFilter.
     *
     * @return solutionID
     */
    public java.math.BigInteger getSolutionID() {
        return solutionID;
    }


    /**
     * Sets the solutionID value for this ReportsFilter.
     *
     * @param solutionID
     */
    public void setSolutionID(java.math.BigInteger solutionID) {
        this.solutionID = solutionID;
    }


    /**
     * Gets the solutionName value for this ReportsFilter.
     *
     * @return solutionName
     */
    public java.lang.String getSolutionName() {
        return solutionName;
    }


    /**
     * Sets the solutionName value for this ReportsFilter.
     *
     * @param solutionName
     */
    public void setSolutionName(java.lang.String solutionName) {
        this.solutionName = solutionName;
    }


    /**
     * Gets the projectID value for this ReportsFilter.
     *
     * @return projectID
     */
    public java.math.BigInteger getProjectID() {
        return projectID;
    }


    /**
     * Sets the projectID value for this ReportsFilter.
     *
     * @param projectID
     */
    public void setProjectID(java.math.BigInteger projectID) {
        this.projectID = projectID;
    }


    /**
     * Gets the projectName value for this ReportsFilter.
     *
     * @return projectName
     */
    public java.lang.String getProjectName() {
        return projectName;
    }


    /**
     * Sets the projectName value for this ReportsFilter.
     *
     * @param projectName
     */
    public void setProjectName(java.lang.String projectName) {
        this.projectName = projectName;
    }


    /**
     * Gets the projectUUID value for this ReportsFilter.
     *
     * @return projectUUID
     */
    public java.lang.String getProjectUUID() {
        return projectUUID;
    }


    /**
     * Sets the projectUUID value for this ReportsFilter.
     *
     * @param projectUUID
     */
    public void setProjectUUID(java.lang.String projectUUID) {
        this.projectUUID = projectUUID;
    }


    /**
     * Gets the tableID value for this ReportsFilter.
     *
     * @return tableID
     */
    public java.math.BigInteger getTableID() {
        return tableID;
    }


    /**
     * Sets the tableID value for this ReportsFilter.
     *
     * @param tableID
     */
    public void setTableID(java.math.BigInteger tableID) {
        this.tableID = tableID;
    }


    /**
     * Gets the tableName value for this ReportsFilter.
     *
     * @return tableName
     */
    public java.lang.String getTableName() {
        return tableName;
    }


    /**
     * Sets the tableName value for this ReportsFilter.
     *
     * @param tableName
     */
    public void setTableName(java.lang.String tableName) {
        this.tableName = tableName;
    }


    /**
     * Gets the authorID value for this ReportsFilter.
     *
     * @return authorID
     */
    public java.lang.String getAuthorID() {
        return authorID;
    }


    /**
     * Sets the authorID value for this ReportsFilter.
     *
     * @param authorID
     */
    public void setAuthorID(java.lang.String authorID) {
        this.authorID = authorID;
    }


    /**
     * Gets the reportType value for this ReportsFilter.
     *
     * @return reportType
     */
    public axis.ReportType getReportType() {
        return reportType;
    }


    /**
     * Sets the reportType value for this ReportsFilter.
     *
     * @param reportType
     */
    public void setReportType(axis.ReportType reportType) {
        this.reportType = reportType;
    }


    /**
     * Gets the reportCategory value for this ReportsFilter.
     *
     * @return reportCategory
     */
    public axis.ReportCategory getReportCategory() {
        return reportCategory;
    }


    /**
     * Sets the reportCategory value for this ReportsFilter.
     *
     * @param reportCategory
     */
    public void setReportCategory(axis.ReportCategory reportCategory) {
        this.reportCategory = reportCategory;
    }


    /**
     * Gets the reportAccessLevel value for this ReportsFilter.
     *
     * @return reportAccessLevel
     */
    public axis.ReportAccessLevel getReportAccessLevel() {
        return reportAccessLevel;
    }


    /**
     * Sets the reportAccessLevel value for this ReportsFilter.
     *
     * @param reportAccessLevel
     */
    public void setReportAccessLevel(axis.ReportAccessLevel reportAccessLevel) {
        this.reportAccessLevel = reportAccessLevel;
    }


    /**
     * Gets the reportName value for this ReportsFilter.
     *
     * @return reportName
     */
    public java.lang.String getReportName() {
        return reportName;
    }


    /**
     * Sets the reportName value for this ReportsFilter.
     *
     * @param reportName
     */
    public void setReportName(java.lang.String reportName) {
        this.reportName = reportName;
    }


    /**
     * Gets the includeSubProjects value for this ReportsFilter.
     *
     * @return includeSubProjects
     */
    public java.lang.Boolean getIncludeSubProjects() {
        return includeSubProjects;
    }


    /**
     * Sets the includeSubProjects value for this ReportsFilter.
     *
     * @param includeSubProjects
     */
    public void setIncludeSubProjects(java.lang.Boolean includeSubProjects) {
        this.includeSubProjects = includeSubProjects;
    }


    /**
     * Gets the createdDateFrom value for this ReportsFilter.
     *
     * @return createdDateFrom
     */
    public java.util.Calendar getCreatedDateFrom() {
        return createdDateFrom;
    }


    /**
     * Sets the createdDateFrom value for this ReportsFilter.
     *
     * @param createdDateFrom
     */
    public void setCreatedDateFrom(java.util.Calendar createdDateFrom) {
        this.createdDateFrom = createdDateFrom;
    }


    /**
     * Gets the createdDateTo value for this ReportsFilter.
     *
     * @return createdDateTo
     */
    public java.util.Calendar getCreatedDateTo() {
        return createdDateTo;
    }


    /**
     * Sets the createdDateTo value for this ReportsFilter.
     *
     * @param createdDateTo
     */
    public void setCreatedDateTo(java.util.Calendar createdDateTo) {
        this.createdDateTo = createdDateTo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ReportsFilter)) return false;
        ReportsFilter other = (ReportsFilter) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.solutionID==null && other.getSolutionID()==null) ||
             (this.solutionID!=null &&
              this.solutionID.equals(other.getSolutionID()))) &&
            ((this.solutionName==null && other.getSolutionName()==null) ||
             (this.solutionName!=null &&
              this.solutionName.equals(other.getSolutionName()))) &&
            ((this.projectID==null && other.getProjectID()==null) ||
             (this.projectID!=null &&
              this.projectID.equals(other.getProjectID()))) &&
            ((this.projectName==null && other.getProjectName()==null) ||
             (this.projectName!=null &&
              this.projectName.equals(other.getProjectName()))) &&
            ((this.projectUUID==null && other.getProjectUUID()==null) ||
             (this.projectUUID!=null &&
              this.projectUUID.equals(other.getProjectUUID()))) &&
            ((this.tableID==null && other.getTableID()==null) ||
             (this.tableID!=null &&
              this.tableID.equals(other.getTableID()))) &&
            ((this.tableName==null && other.getTableName()==null) ||
             (this.tableName!=null &&
              this.tableName.equals(other.getTableName()))) &&
            ((this.authorID==null && other.getAuthorID()==null) ||
             (this.authorID!=null &&
              this.authorID.equals(other.getAuthorID()))) &&
            ((this.reportType==null && other.getReportType()==null) ||
             (this.reportType!=null &&
              this.reportType.equals(other.getReportType()))) &&
            ((this.reportCategory==null && other.getReportCategory()==null) ||
             (this.reportCategory!=null &&
              this.reportCategory.equals(other.getReportCategory()))) &&
            ((this.reportAccessLevel==null && other.getReportAccessLevel()==null) ||
             (this.reportAccessLevel!=null &&
              this.reportAccessLevel.equals(other.getReportAccessLevel()))) &&
            ((this.reportName==null && other.getReportName()==null) ||
             (this.reportName!=null &&
              this.reportName.equals(other.getReportName()))) &&
            ((this.includeSubProjects==null && other.getIncludeSubProjects()==null) ||
             (this.includeSubProjects!=null &&
              this.includeSubProjects.equals(other.getIncludeSubProjects()))) &&
            ((this.createdDateFrom==null && other.getCreatedDateFrom()==null) ||
             (this.createdDateFrom!=null &&
              this.createdDateFrom.equals(other.getCreatedDateFrom()))) &&
            ((this.createdDateTo==null && other.getCreatedDateTo()==null) ||
             (this.createdDateTo!=null &&
              this.createdDateTo.equals(other.getCreatedDateTo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSolutionID() != null) {
            _hashCode += getSolutionID().hashCode();
        }
        if (getSolutionName() != null) {
            _hashCode += getSolutionName().hashCode();
        }
        if (getProjectID() != null) {
            _hashCode += getProjectID().hashCode();
        }
        if (getProjectName() != null) {
            _hashCode += getProjectName().hashCode();
        }
        if (getProjectUUID() != null) {
            _hashCode += getProjectUUID().hashCode();
        }
        if (getTableID() != null) {
            _hashCode += getTableID().hashCode();
        }
        if (getTableName() != null) {
            _hashCode += getTableName().hashCode();
        }
        if (getAuthorID() != null) {
            _hashCode += getAuthorID().hashCode();
        }
        if (getReportType() != null) {
            _hashCode += getReportType().hashCode();
        }
        if (getReportCategory() != null) {
            _hashCode += getReportCategory().hashCode();
        }
        if (getReportAccessLevel() != null) {
            _hashCode += getReportAccessLevel().hashCode();
        }
        if (getReportName() != null) {
            _hashCode += getReportName().hashCode();
        }
        if (getIncludeSubProjects() != null) {
            _hashCode += getIncludeSubProjects().hashCode();
        }
        if (getCreatedDateFrom() != null) {
            _hashCode += getCreatedDateFrom().hashCode();
        }
        if (getCreatedDateTo() != null) {
            _hashCode += getCreatedDateTo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ReportsFilter.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ReportsFilter"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solutionID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "solutionID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solutionName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "solutionName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("projectUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "projectUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tableID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "tableID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tableName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "tableName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("authorID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "authorID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportType");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportType"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ReportType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportCategory");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportCategory"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ReportCategory"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportAccessLevel");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportAccessLevel"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ReportAccessLevel"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reportName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "reportName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("includeSubProjects");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "includeSubProjects"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDateFrom");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "createdDateFrom"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("createdDateTo");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "createdDateTo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
