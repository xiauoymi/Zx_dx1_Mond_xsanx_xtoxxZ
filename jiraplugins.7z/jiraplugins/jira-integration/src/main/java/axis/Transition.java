
package axis;

public class Transition  implements java.io.Serializable {
    private java.math.BigInteger transitionID;

    private java.lang.String transitionUUID;

    private java.lang.String name;

    private java.lang.String fromState;

    private java.math.BigInteger fromStateID;

    private java.lang.String fromStateUUID;

    private java.lang.String toState;

    private java.math.BigInteger toStateID;

    private java.lang.String toStateUUID;

    private axis.TransitionType type;

    private java.lang.String fullyQualifiedPostIssueProjectName;

    private java.lang.String[] transitionAttributes;

    public Transition() {
    }

    public Transition(
           java.math.BigInteger transitionID,
           java.lang.String transitionUUID,
           java.lang.String name,
           java.lang.String fromState,
           java.math.BigInteger fromStateID,
           java.lang.String fromStateUUID,
           java.lang.String toState,
           java.math.BigInteger toStateID,
           java.lang.String toStateUUID,
           axis.TransitionType type,
           java.lang.String fullyQualifiedPostIssueProjectName,
           java.lang.String[] transitionAttributes) {
           this.transitionID = transitionID;
           this.transitionUUID = transitionUUID;
           this.name = name;
           this.fromState = fromState;
           this.fromStateID = fromStateID;
           this.fromStateUUID = fromStateUUID;
           this.toState = toState;
           this.toStateID = toStateID;
           this.toStateUUID = toStateUUID;
           this.type = type;
           this.fullyQualifiedPostIssueProjectName = fullyQualifiedPostIssueProjectName;
           this.transitionAttributes = transitionAttributes;
    }


    /**
     * Gets the transitionID value for this Transition.
     *
     * @return transitionID
     */
    public java.math.BigInteger getTransitionID() {
        return transitionID;
    }


    /**
     * Sets the transitionID value for this Transition.
     *
     * @param transitionID
     */
    public void setTransitionID(java.math.BigInteger transitionID) {
        this.transitionID = transitionID;
    }


    /**
     * Gets the transitionUUID value for this Transition.
     *
     * @return transitionUUID
     */
    public java.lang.String getTransitionUUID() {
        return transitionUUID;
    }


    /**
     * Sets the transitionUUID value for this Transition.
     *
     * @param transitionUUID
     */
    public void setTransitionUUID(java.lang.String transitionUUID) {
        this.transitionUUID = transitionUUID;
    }


    /**
     * Gets the name value for this Transition.
     *
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Transition.
     *
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the fromState value for this Transition.
     *
     * @return fromState
     */
    public java.lang.String getFromState() {
        return fromState;
    }


    /**
     * Sets the fromState value for this Transition.
     *
     * @param fromState
     */
    public void setFromState(java.lang.String fromState) {
        this.fromState = fromState;
    }


    /**
     * Gets the fromStateID value for this Transition.
     *
     * @return fromStateID
     */
    public java.math.BigInteger getFromStateID() {
        return fromStateID;
    }


    /**
     * Sets the fromStateID value for this Transition.
     *
     * @param fromStateID
     */
    public void setFromStateID(java.math.BigInteger fromStateID) {
        this.fromStateID = fromStateID;
    }


    /**
     * Gets the fromStateUUID value for this Transition.
     *
     * @return fromStateUUID
     */
    public java.lang.String getFromStateUUID() {
        return fromStateUUID;
    }


    /**
     * Sets the fromStateUUID value for this Transition.
     *
     * @param fromStateUUID
     */
    public void setFromStateUUID(java.lang.String fromStateUUID) {
        this.fromStateUUID = fromStateUUID;
    }


    /**
     * Gets the toState value for this Transition.
     *
     * @return toState
     */
    public java.lang.String getToState() {
        return toState;
    }


    /**
     * Sets the toState value for this Transition.
     *
     * @param toState
     */
    public void setToState(java.lang.String toState) {
        this.toState = toState;
    }


    /**
     * Gets the toStateID value for this Transition.
     *
     * @return toStateID
     */
    public java.math.BigInteger getToStateID() {
        return toStateID;
    }


    /**
     * Sets the toStateID value for this Transition.
     *
     * @param toStateID
     */
    public void setToStateID(java.math.BigInteger toStateID) {
        this.toStateID = toStateID;
    }


    /**
     * Gets the toStateUUID value for this Transition.
     *
     * @return toStateUUID
     */
    public java.lang.String getToStateUUID() {
        return toStateUUID;
    }


    /**
     * Sets the toStateUUID value for this Transition.
     *
     * @param toStateUUID
     */
    public void setToStateUUID(java.lang.String toStateUUID) {
        this.toStateUUID = toStateUUID;
    }


    /**
     * Gets the type value for this Transition.
     *
     * @return type
     */
    public axis.TransitionType getType() {
        return type;
    }


    /**
     * Sets the type value for this Transition.
     *
     * @param type
     */
    public void setType(axis.TransitionType type) {
        this.type = type;
    }


    /**
     * Gets the fullyQualifiedPostIssueProjectName value for this Transition.
     *
     * @return fullyQualifiedPostIssueProjectName
     */
    public java.lang.String getFullyQualifiedPostIssueProjectName() {
        return fullyQualifiedPostIssueProjectName;
    }


    /**
     * Sets the fullyQualifiedPostIssueProjectName value for this Transition.
     *
     * @param fullyQualifiedPostIssueProjectName
     */
    public void setFullyQualifiedPostIssueProjectName(java.lang.String fullyQualifiedPostIssueProjectName) {
        this.fullyQualifiedPostIssueProjectName = fullyQualifiedPostIssueProjectName;
    }


    /**
     * Gets the transitionAttributes value for this Transition.
     *
     * @return transitionAttributes
     */
    public java.lang.String[] getTransitionAttributes() {
        return transitionAttributes;
    }


    /**
     * Sets the transitionAttributes value for this Transition.
     *
     * @param transitionAttributes
     */
    public void setTransitionAttributes(java.lang.String[] transitionAttributes) {
        this.transitionAttributes = transitionAttributes;
    }

    public java.lang.String getTransitionAttributes(int i) {
        return this.transitionAttributes[i];
    }

    public void setTransitionAttributes(int i, java.lang.String _value) {
        this.transitionAttributes[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Transition)) return false;
        Transition other = (Transition) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.transitionID==null && other.getTransitionID()==null) ||
             (this.transitionID!=null &&
              this.transitionID.equals(other.getTransitionID()))) &&
            ((this.transitionUUID==null && other.getTransitionUUID()==null) ||
             (this.transitionUUID!=null &&
              this.transitionUUID.equals(other.getTransitionUUID()))) &&
            ((this.name==null && other.getName()==null) ||
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.fromState==null && other.getFromState()==null) ||
             (this.fromState!=null &&
              this.fromState.equals(other.getFromState()))) &&
            ((this.fromStateID==null && other.getFromStateID()==null) ||
             (this.fromStateID!=null &&
              this.fromStateID.equals(other.getFromStateID()))) &&
            ((this.fromStateUUID==null && other.getFromStateUUID()==null) ||
             (this.fromStateUUID!=null &&
              this.fromStateUUID.equals(other.getFromStateUUID()))) &&
            ((this.toState==null && other.getToState()==null) ||
             (this.toState!=null &&
              this.toState.equals(other.getToState()))) &&
            ((this.toStateID==null && other.getToStateID()==null) ||
             (this.toStateID!=null &&
              this.toStateID.equals(other.getToStateID()))) &&
            ((this.toStateUUID==null && other.getToStateUUID()==null) ||
             (this.toStateUUID!=null &&
              this.toStateUUID.equals(other.getToStateUUID()))) &&
            ((this.type==null && other.getType()==null) ||
             (this.type!=null &&
              this.type.equals(other.getType()))) &&
            ((this.fullyQualifiedPostIssueProjectName==null && other.getFullyQualifiedPostIssueProjectName()==null) ||
             (this.fullyQualifiedPostIssueProjectName!=null &&
              this.fullyQualifiedPostIssueProjectName.equals(other.getFullyQualifiedPostIssueProjectName()))) &&
            ((this.transitionAttributes==null && other.getTransitionAttributes()==null) ||
             (this.transitionAttributes!=null &&
              java.util.Arrays.equals(this.transitionAttributes, other.getTransitionAttributes())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTransitionID() != null) {
            _hashCode += getTransitionID().hashCode();
        }
        if (getTransitionUUID() != null) {
            _hashCode += getTransitionUUID().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getFromState() != null) {
            _hashCode += getFromState().hashCode();
        }
        if (getFromStateID() != null) {
            _hashCode += getFromStateID().hashCode();
        }
        if (getFromStateUUID() != null) {
            _hashCode += getFromStateUUID().hashCode();
        }
        if (getToState() != null) {
            _hashCode += getToState().hashCode();
        }
        if (getToStateID() != null) {
            _hashCode += getToStateID().hashCode();
        }
        if (getToStateUUID() != null) {
            _hashCode += getToStateUUID().hashCode();
        }
        if (getType() != null) {
            _hashCode += getType().hashCode();
        }
        if (getFullyQualifiedPostIssueProjectName() != null) {
            _hashCode += getFullyQualifiedPostIssueProjectName().hashCode();
        }
        if (getTransitionAttributes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTransitionAttributes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTransitionAttributes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Transition.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Transition"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transitionID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "transitionID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transitionUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "transitionUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromState");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "fromState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromStateID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "fromStateID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fromStateUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "fromStateUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toState");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "toState"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toStateID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "toStateID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("toStateUUID");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "toStateUUID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("type");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "type"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Transition-Type"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fullyQualifiedPostIssueProjectName");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "fullyQualifiedPostIssueProjectName"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("transitionAttributes");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "transitionAttributes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
