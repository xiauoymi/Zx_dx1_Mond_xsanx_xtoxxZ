
package axis;

public class Value  implements java.io.Serializable {
    private java.lang.String displayValue;

    private java.lang.String internalValue;

    private java.lang.String uuid;

    private axis.ExtraValue[] extraValues;

    public Value() {
    }

    public Value(
           java.lang.String displayValue,
           java.lang.String internalValue,
           java.lang.String uuid,
           axis.ExtraValue[] extraValues) {
           this.displayValue = displayValue;
           this.internalValue = internalValue;
           this.uuid = uuid;
           this.extraValues = extraValues;
    }


    /**
     * Gets the displayValue value for this Value.
     *
     * @return displayValue
     */
    public java.lang.String getDisplayValue() {
        return displayValue;
    }


    /**
     * Sets the displayValue value for this Value.
     *
     * @param displayValue
     */
    public void setDisplayValue(java.lang.String displayValue) {
        this.displayValue = displayValue;
    }


    /**
     * Gets the internalValue value for this Value.
     *
     * @return internalValue
     */
    public java.lang.String getInternalValue() {
        return internalValue;
    }


    /**
     * Sets the internalValue value for this Value.
     *
     * @param internalValue
     */
    public void setInternalValue(java.lang.String internalValue) {
        this.internalValue = internalValue;
    }


    /**
     * Gets the uuid value for this Value.
     *
     * @return uuid
     */
    public java.lang.String getUuid() {
        return uuid;
    }


    /**
     * Sets the uuid value for this Value.
     *
     * @param uuid
     */
    public void setUuid(java.lang.String uuid) {
        this.uuid = uuid;
    }


    /**
     * Gets the extraValues value for this Value.
     *
     * @return extraValues
     */
    public axis.ExtraValue[] getExtraValues() {
        return extraValues;
    }


    /**
     * Sets the extraValues value for this Value.
     *
     * @param extraValues
     */
    public void setExtraValues(axis.ExtraValue[] extraValues) {
        this.extraValues = extraValues;
    }

    public axis.ExtraValue getExtraValues(int i) {
        return this.extraValues[i];
    }

    public void setExtraValues(int i, axis.ExtraValue _value) {
        this.extraValues[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Value)) return false;
        Value other = (Value) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true &&
            ((this.displayValue==null && other.getDisplayValue()==null) ||
             (this.displayValue!=null &&
              this.displayValue.equals(other.getDisplayValue()))) &&
            ((this.internalValue==null && other.getInternalValue()==null) ||
             (this.internalValue!=null &&
              this.internalValue.equals(other.getInternalValue()))) &&
            ((this.uuid==null && other.getUuid()==null) ||
             (this.uuid!=null &&
              this.uuid.equals(other.getUuid()))) &&
            ((this.extraValues==null && other.getExtraValues()==null) ||
             (this.extraValues!=null &&
              java.util.Arrays.equals(this.extraValues, other.getExtraValues())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDisplayValue() != null) {
            _hashCode += getDisplayValue().hashCode();
        }
        if (getInternalValue() != null) {
            _hashCode += getInternalValue().hashCode();
        }
        if (getUuid() != null) {
            _hashCode += getUuid().hashCode();
        }
        if (getExtraValues() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getExtraValues());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getExtraValues(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Value.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "Value"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("displayValue");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "displayValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("internalValue");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "internalValue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("uuid");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "uuid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("extraValues");
        elemField.setXmlName(new javax.xml.namespace.QName("urn:aewebservices71", "extraValues"));
        elemField.setXmlType(new javax.xml.namespace.QName("urn:aewebservices71", "ExtraValue"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType,
           java.lang.Class _javaType,
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
