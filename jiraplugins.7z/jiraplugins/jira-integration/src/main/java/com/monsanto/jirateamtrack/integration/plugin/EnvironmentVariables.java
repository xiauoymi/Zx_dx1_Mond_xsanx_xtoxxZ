package com.monsanto.jirateamtrack.integration.plugin;

/**
 * Created by NREIN1 on 9/16/2014.
 */
public class EnvironmentVariables {


    public static String TEAMTRACK_ECR_NAME;


    //Transition ID's for USIT Change Request
    public static String teamTrackToDevelopmentTransitionId;
    public static String teamTrackToReadyForItDeploymentId;
    public static String teamTrackToTechLeadApprovalId;
    public static String teamTrackToReadyForItId;

    //Transition ID's for EDT Change Request
    public static String teamTrackEDTToDevelopmentTransitionId;
    public static String teamTrackEDTToTechLeadApprovalId;


    ///Field Variables
    //US IT PCR PROD
    public static String USITPCRDeveloperField;
    public static String USITPCRDeveloperHoursField;

    //EDT PCR PROD
    public static String EDTPCRDeveloperField;
    public static String EDTPCRDeveloperHoursField;
    public static String EDTPCRTechLeadField;


    public static void setEnvironmentVariablesTest() {


        TEAMTRACK_ECR_NAME = "US IT Change Request-Work Ticket";


        //Transistion ID's for US IT Workflow
        teamTrackToDevelopmentTransitionId = "1953";
        teamTrackToReadyForItDeploymentId = "2023";
        teamTrackToTechLeadApprovalId = "2019";
        teamTrackToReadyForItId = "2039";


        //Transition ID's for EDT Change Request
        teamTrackEDTToDevelopmentTransitionId = "1822";
        teamTrackEDTToTechLeadApprovalId = "1823";


        ///Field Variables
        //US IT PCR TEST
        USITPCRDeveloperField = "3727";
        USITPCRDeveloperHoursField = "624";

        //EDT PCR TEST
        EDTPCRDeveloperField = "3676";
        EDTPCRDeveloperHoursField = "3695";
        EDTPCRTechLeadField = "3677";

    }

    public static void setEnvironmentVariablesProd() {

        //Space at end of TEAMTRACK_ECR_NAME variable is needed to match teamtrack variable... Yep...*Flips Desk*
        TEAMTRACK_ECR_NAME = "US IT Change Request - Child WF ";

        //Transistion ID's for US IT Workflow
        teamTrackToDevelopmentTransitionId = "1918";
        teamTrackToReadyForItDeploymentId = "1941";
        teamTrackToTechLeadApprovalId = "1937";
        teamTrackToReadyForItId = "1956";

        //Transition ID's for EDT Change Request
        teamTrackEDTToDevelopmentTransitionId = "1778";
        teamTrackEDTToTechLeadApprovalId = "1779";


        ///Field Variables
        //US IT PCR PROD
        //NOT GIVEN
        USITPCRDeveloperField = "3419";
        USITPCRDeveloperHoursField = "624";

        //EDT PCR PROD
        EDTPCRDeveloperField = "3339";
        EDTPCRDeveloperHoursField = "3358";

        //NOT GIVEN
        EDTPCRTechLeadField = "3340";


    }

}