package com.monsanto.jirateamtrack.integration.plugin;

import com.atlassian.jira.component.ComponentAccessor;
import com.atlassian.jira.issue.CustomFieldManager;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.fields.CustomField;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by NREIN1 on 9/10/2014.
 */
public class JiraIssueRetriever {

    private JiraIssueRetriever() {
        super();
    }

    public static JiraIssueRetriever JiraCreateWithEnvironmentAuth() {
        return new JiraIssueRetriever();
    }


    public double findTotalOriginalEstimates(Issue issue) {
        double totalEstimation = 0;

        if (!issue.isSubTask()) {
            if (issue.getOriginalEstimate() != null) {
                totalEstimation = issue.getOriginalEstimate();
            }
            if (!issue.getSubTaskObjects().isEmpty()) {
                List<Issue> subtasks = new ArrayList<Issue>(issue.getSubTaskObjects());
                for (Issue subtask : subtasks) {
                    if (subtask.getOriginalEstimate() != null) {
                        totalEstimation = totalEstimation + subtask.getOriginalEstimate();
                    }
                }
            }
            return totalEstimation;
        } else {
            List<Issue> subtasks = new ArrayList<Issue>(issue.getParentObject().getSubTaskObjects());
            for (Issue subtask : subtasks) {
                if (subtask.getOriginalEstimate() != null) {
                    totalEstimation = subtask.getOriginalEstimate() + totalEstimation;
                }
            }
            if (issue.getParentObject().getOriginalEstimate() != null) {
                totalEstimation = (issue.getParentObject().getOriginalEstimate()) + totalEstimation;
            }
        }
        return totalEstimation;
    }


    public static String findTeamTrackIdCustomField(Issue jiraIssue) {
        CustomFieldManager customFieldManager = ComponentAccessor.getCustomFieldManager();
        CustomField customField = customFieldManager.getCustomFieldObjectByName("TeamTrack Item ID");
        Object teamTrackItemId = jiraIssue.getCustomFieldValue(customField);

        Issue parentIssue = jiraIssue.getParentObject();

        if (teamTrackItemId != null) {
            if (teamTrackItemId.toString().contains(":")) {
                return teamTrackItemId.toString();
            }

        } else if (parentIssue != null) {
            Object parentTeamTrackItemId = parentIssue.getCustomFieldValue(customField);
            if (parentTeamTrackItemId != null) {
                if (parentTeamTrackItemId.toString().contains(":")) {
                    return parentTeamTrackItemId.toString();
                }
            }

        }
        return null;
    }

    public static String convertJiraTimeToTeamtrack(double jiraTime) {
        //jiraTime is logged in seconds
        double secondsInAnHour = 3600;
        double teamTrackTime = jiraTime / secondsInAnHour;
        String originalEstimation = String.valueOf(teamTrackTime);
        return originalEstimation;
    }

}
