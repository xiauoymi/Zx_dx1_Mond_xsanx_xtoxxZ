package com.monsanto.jirateamtrack.integration.plugin;

public interface MyPluginComponent {
    String getName();
}