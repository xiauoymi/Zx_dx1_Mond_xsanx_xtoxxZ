package com.monsanto.jirateamtrack.integration.postfunctions;

import axis.TTItem;
import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.workflow.function.issue.AbstractJiraFunctionProvider;
import com.monsanto.jirateamtrack.integration.plugin.EnvironmentVariables;
import com.monsanto.jirateamtrack.integration.plugin.JiraIssueRetriever;
import com.monsanto.jirateamtrack.integration.teamtrack.TeamTrackItemChanger;
import com.monsanto.jirateamtrack.integration.teamtrack.TeamTrackRetriever;
import com.opensymphony.module.propertyset.PropertySet;

import java.math.BigInteger;
import java.rmi.RemoteException;
import java.util.Map;

/**
 * Created by NREIN1 on 9/29/2014.
 */
public class TeamTrackSetToDevelopment extends AbstractJiraFunctionProvider {

    public void execute(Map transientVars, Map args, PropertySet ps) {
        EnvironmentVariables.setEnvironmentVariablesProd();
        MutableIssue issue = getIssue(transientVars);
        if (!issue.isSubTask()) {
            if (JiraIssueRetriever.findTeamTrackIdCustomField(issue) != null) {
                try {
                    TTItem item = TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem(JiraIssueRetriever.findTeamTrackIdCustomField(issue));
                    if (item.getClassification().equals("US IT Change Request")) {
                        try {
                            String jiraAssignedDeveloper = issue.getAssigneeId();
                            System.out.println(issue.getAssigneeId());
                            BigInteger assignedDeveloper = TeamTrackRetriever.CreateWithEnviromentAuth().findUser(jiraAssignedDeveloper).getId();
                            System.out.println(assignedDeveloper);
                            TeamTrackItemChanger.CreateWithEnvironmentAuth().setDeveloper(JiraIssueRetriever.findTeamTrackIdCustomField(issue), assignedDeveloper, true);
                            TeamTrackItemChanger.CreateWithEnvironmentAuth().changeStatus(JiraIssueRetriever.findTeamTrackIdCustomField(issue), EnvironmentVariables.teamTrackToDevelopmentTransitionId, true);
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                    } else if (item.getClassification().equals("EDT Change Request")) {
                        try {
                            String jiraAssignedDeveloper = issue.getAssigneeId();
                            System.out.println(issue.getAssigneeId());
                            BigInteger assignedDeveloper = TeamTrackRetriever.CreateWithEnviromentAuth().findUser(jiraAssignedDeveloper).getId();
                            System.out.println(assignedDeveloper);
                            TeamTrackItemChanger.CreateWithEnvironmentAuth().setDeveloper(JiraIssueRetriever.findTeamTrackIdCustomField(issue), assignedDeveloper, true);
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                    }
                }catch(RuntimeException e){
                    e.printStackTrace();
                }
            }
        }
    }


}
