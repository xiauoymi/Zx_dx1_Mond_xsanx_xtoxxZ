package com.monsanto.jirateamtrack.integration.postfunctions;

import com.atlassian.jira.issue.MutableIssue;
import com.atlassian.jira.workflow.WorkflowException;
import com.atlassian.jira.workflow.function.issue.AbstractJiraFunctionProvider;
import com.monsanto.jirateamtrack.integration.plugin.EnvironmentVariables;
import com.monsanto.jirateamtrack.integration.plugin.JiraIssueRetriever;
import com.monsanto.jirateamtrack.integration.teamtrack.TeamTrackItemChanger;
import com.opensymphony.module.propertyset.PropertySet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.rmi.RemoteException;
import java.util.Map;

/**
 * Created by NREIN1 on 9/29/2014.
 */
public class TeamTrackUpdateOriginalEstimate extends AbstractJiraFunctionProvider {
    private static final Logger log = LoggerFactory.getLogger(TeamTrackUpdateOriginalEstimate.class);
    public void execute(Map transientVars, Map args, PropertySet ps) throws WorkflowException {
        EnvironmentVariables.setEnvironmentVariablesProd();
        MutableIssue issue = getIssue(transientVars);
        if (JiraIssueRetriever.findTeamTrackIdCustomField(issue) != null) {
            double originalEstimate = JiraIssueRetriever.JiraCreateWithEnvironmentAuth().findTotalOriginalEstimates(issue);
            log.debug("~~~~~~~~~THE UPDATE WAS FOR TIME ESTIMATE! THROW IT TO TEAMTRACK!~~~~~~~~~");
            log.debug("The Original Estimate Is:" + originalEstimate);
            String teamtrackOriginalEstimate = JiraIssueRetriever.convertJiraTimeToTeamtrack(originalEstimate);
            log.debug("Converted Original Estimate: " + teamtrackOriginalEstimate);
            try {
                TeamTrackItemChanger.CreateWithEnvironmentAuth().changeOriginalEstimate(JiraIssueRetriever.findTeamTrackIdCustomField(issue), teamtrackOriginalEstimate, true);
            } catch (RemoteException e) {
                e.printStackTrace();
            }catch(RuntimeException e){
                e.printStackTrace();
            }
        }
    }
}
