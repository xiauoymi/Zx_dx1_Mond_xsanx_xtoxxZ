package com.monsanto.jirateamtrack.integration.teamtrack;


import axis.Aewebservices71PortType;
import axis.Aewebservices71_ServiceLocator;
import axis.Auth;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.xml.rpc.ServiceException;


/**
 * Created by CGSHAF on 8/7/2014.
 */
abstract class TeamTrackCommunicationHandler {
    private static final Logger log = LoggerFactory.getLogger(TeamTrackCommunicationHandler.class);
    private Aewebservices71PortType teamTrackInterface;
    private Auth auth;
    private String username = "NA1000APP-EDT-JIRA";
    private String password = "7habuWRu";

    protected TeamTrackCommunicationHandler() {
        this.teamTrackInterface = getService();
        this.auth = createAuth(username, password);
    }

    protected TeamTrackCommunicationHandler(String username, String password) {
        log.debug("Getting TeamTrack Service");
        this.teamTrackInterface = getService();
        this.auth = createAuth(username, password);
    }

    private Aewebservices71PortType getService() {
        Aewebservices71_ServiceLocator locator = new Aewebservices71_ServiceLocator();
        Aewebservices71PortType port = null;
        try {
            port = locator.getaewebservices71();
        } catch (ServiceException e) {
            e.printStackTrace();
        }
        return port;
    }

    private Auth createAuth(String username, String password) {
        Auth auth = new Auth();
        auth.setUserId(username);
        auth.setPassword(password);

        return auth;
    }

    protected Aewebservices71PortType getTeamTrackInterface() {
        return teamTrackInterface;
    }

    protected Auth getAuth() {
        return auth;
    }

}
