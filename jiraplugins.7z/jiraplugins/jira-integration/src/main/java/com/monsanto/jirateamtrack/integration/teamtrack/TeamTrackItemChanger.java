package com.monsanto.jirateamtrack.integration.teamtrack;

import axis.AEWebservicesFaultFault;
import axis.NameValue;
import axis.TTItem;
import com.monsanto.jirateamtrack.integration.plugin.EnvironmentVariables;
import com.perforce.api.Env;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigInteger;
import java.rmi.RemoteException;


/**
 * Created by CGSHAF on 8/7/2014.
 */
public final class TeamTrackItemChanger extends TeamTrackCommunicationHandler {
    private static final Logger log = LoggerFactory.getLogger(TeamTrackItemChanger.class);


    private TeamTrackItemChanger() {
        super();
    }

    private TeamTrackItemChanger(String username, String password) {
        super(username, password);
    }

    public static TeamTrackItemChanger CreateWithEnvironmentAuth() {
        return new TeamTrackItemChanger();
    }

    public static TeamTrackItemChanger CreateWithCustomAuth(String username, String password) {
        return new TeamTrackItemChanger(username, password);
    }

    public TTItem changeStatus(String itemTableIdItemId, String transitionId, boolean breakLock) throws RemoteException {
        log.info("Change Status CALL to TeamTrack");

        TTItem item = TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem(itemTableIdItemId);

        if (item.getClassification().equals("US IT Change Request")) {
            TTItem findECR = TeamTrackRetriever.CreateWithEnviromentAuth().findECRItemID(itemTableIdItemId);
            if (findECR != null) {
                item = findECR;
            } else
                return null;
        }

        log.debug("Start State: " + item.getState());
        TTItem ttItem = this.getTeamTrackInterface().updateItem(getAuth(), item, new BigInteger(transitionId), "");
        log.debug("End state: " + ttItem.getState().intern());

        return ttItem;

    }

    public TTItem changeOriginalEstimate(String itemTableIdItemId, String originalEstimate, boolean breaklock) throws RemoteException {
        log.debug("Change OriginalEstimate CALL");
        TTItem item = TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem(itemTableIdItemId);
        log.debug("Status: " + item.getState());

        return setEstimatedHoursByClassification(item, originalEstimate);
    }

    public TTItem setDeveloper(String itemTableIdItemId, BigInteger developer, boolean breaklock) throws RemoteException {

        log.debug("Change Status Setting Developer CALL");
        TTItem item = TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem(itemTableIdItemId);
        log.debug("Classification: " + item.getClassification());
        if (item.getClassification().equals("US IT Change Request")) {
            TTItem findECR = TeamTrackRetriever.CreateWithEnviromentAuth().findECRItemID(itemTableIdItemId);
            if (findECR != null) {
                item = findECR;
            } else {

                return null;
            }
        }
        System.out.println(item.getState());
        if (item.getState().equals(""))
        log.debug(itemTableIdItemId);
        log.debug("Item being worked on:" + item.getGenericItem().getItemName());
        String developerString = String.valueOf(developer);
        log.debug("Developer we are setting it too: " + developerString);


        return setDeveloperByClassification(item, developerString);
    }

    public TTItem setTechLead(String itemTableIdItemId, BigInteger techLead, boolean breaklock) throws RemoteException {
        log.debug("Change Status Setting Tech Lead CALL");
        TTItem item = TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem(itemTableIdItemId);
        log.debug(itemTableIdItemId);
        log.debug("Item being working on:" + item.getGenericItem().getItemName());
        String techLeadString = String.valueOf(techLead);
        log.debug("Tech Lead we are setting it too: " + techLeadString);

        try {
            return updateFieldValue(item, EnvironmentVariables.EDTPCRTechLeadField, techLeadString);
        } catch (AEWebservicesFaultFault e) {
            e.printStackTrace();
        }

        return null;
    }

    private TTItem setDeveloperByClassification(TTItem item, String developerString) {
        log.debug("In setDeveloperByClassification() Function");
        log.debug("Classification: " + item.getClassification());
        log.debug("Environment Variable Classification: "+ EnvironmentVariables.TEAMTRACK_ECR_NAME);

        try {
            if (EnvironmentVariables.TEAMTRACK_ECR_NAME.equals(item.getClassification())) {
               log.debug("It is a US IT CHANGE REQUEST");
               return  updateFieldValue(item, EnvironmentVariables.USITPCRDeveloperField, developerString);
            }  else if (item.getClassification().equals("EDT Change Request")){
               log.debug("It is a EDT CHANGE REQUEST");
               return updateFieldValue(item, EnvironmentVariables.EDTPCRDeveloperField, developerString);
            }else{
               log.debug("Skipped the setting developer");
            }
        } catch (AEWebservicesFaultFault e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

      return null;
    }

    private TTItem setEstimatedHoursByClassification(TTItem item, String originalEstimate) {
        try {
            if (item.getClassification().equals("US IT Change Request")) {
                updateFieldValue(item, EnvironmentVariables.USITPCRDeveloperHoursField, originalEstimate);
            } else if (item.getClassification().equals("EDT Change Request")) {
                updateFieldValue(item, EnvironmentVariables.EDTPCRDeveloperHoursField, originalEstimate);
            }
        } catch (AEWebservicesFaultFault e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return null;
    }

    private TTItem updateFieldValue(TTItem item, String fieldId, String fieldValue) throws RemoteException {
        BigInteger field = new BigInteger(fieldId);
        BigInteger update = new BigInteger("0");
        for (NameValue value : item.getExtendedFieldList()) {

            if (value.getValue() != null) {
                if (value.getId().equals(field)) {
                    log.debug("Found the field we are looking for: " + value.getId());
                    value.getValue().setInternalValue(fieldValue);
                    log.debug("Setting Field: " + fieldId + " Value: " + fieldValue);
                    TTItem ttItem = this.getTeamTrackInterface().updateItem(getAuth(), item, update, null);
                    return ttItem;
                }
            }
        }
        return null;
    }
}

