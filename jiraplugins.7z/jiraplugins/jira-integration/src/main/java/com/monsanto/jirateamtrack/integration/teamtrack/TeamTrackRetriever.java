package com.monsanto.jirateamtrack.integration.teamtrack;

import axis.TTItem;
import axis.User;
import com.atlassian.jira.workflow.WorkflowException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigInteger;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by CGSHAF on 8/7/2014.
 */
public final class TeamTrackRetriever extends TeamTrackCommunicationHandler {
    private static final Logger log = LoggerFactory.getLogger(TeamTrackRetriever.class);
    private TeamTrackRetriever() {
        super();
    }

    private TeamTrackRetriever(String username, String password) {
        super(username, password);
    }

    public static TeamTrackRetriever CreateWithEnviromentAuth() {
        return new TeamTrackRetriever();
    }

    public static TeamTrackRetriever CreateWithCustomAuth(String username, String password) {
        return new TeamTrackRetriever(username, password);
    }

    public TTItem retrieveItem(String itemTableIdItemId) {
        TTItem item = null;
        try {
            item = this.getTeamTrackInterface().getItem(this.getAuth(), itemTableIdItemId, null);

        } catch (RemoteException e) {
            e.printStackTrace();
            throw new WorkflowException("TeamTrack Error: "+e.getMessage()+"\n"+"Please check for the correct TeamTrack tableId:ItemId ");
        }
        return item;
    }

    public List<TTItem> findChildrenOfPCR(String pcrItemID) {

        try {
            TTItem[] teamTrackArray = this.getTeamTrackInterface().getItemsByQuery(this.getAuth(), new BigInteger("1004"), "TS_PARENT_PCR='" + pcrItemID + "'", null, new BigInteger("50"), null);
            if(teamTrackArray != null) {
                return Arrays.asList(teamTrackArray);
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return new ArrayList<TTItem>();
    }

    public User findUser(String userDisplayValue) {
        User user = null;
        try {
            user = this.getTeamTrackInterface().getUser(this.getAuth(), userDisplayValue);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        return user;
    }

    public TTItem findECRItemID(String PCRTableIDItemID) {
        TTItem teamTrackGenericItem = TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem(PCRTableIDItemID);
        String PCRName = teamTrackGenericItem.getGenericItem().getItemID();
        log.debug(PCRName);
        String pcrItemID = PCRName.substring(5);
        log.debug("PCR TableID:ItemID" + PCRTableIDItemID + " PCR ItemID:" + pcrItemID);


        TTItem ECRItem = null;
        int numberOfECRs = 0;
        List<TTItem> list = findChildrenOfPCR(pcrItemID);
        for (TTItem ttItem : list) {
            log.debug(ttItem.getGenericItem().getItemName());
            if (ttItem.getGenericItem().getItemName().contains("ECR")) {
                log.debug("There is an ECR here");
                numberOfECRs++;
                log.debug("Number Of ECRS: " + numberOfECRs);
                ECRItem = ttItem;
            }
        }
        if (numberOfECRs >= 2) {
            log.debug("More than 1 ECR was found. Contact your Tech Lead");
            log.debug("Number of ECRS found:" + numberOfECRs);
            return null;
        } else if (numberOfECRs == 0) {
            log.debug("No ECR was found for this PCR");
            return null;
        }
        log.debug(ECRItem.getGenericItem().getItemID());
        return ECRItem;

    }
}
