import axis.*;
import com.atlassian.jira.bc.issue.IssueService;
import com.atlassian.jira.issue.Issue;
import com.atlassian.jira.issue.IssueManager;
import com.monsanto.jirateamtrack.integration.plugin.JiraIssueRetriever;
import com.monsanto.jirateamtrack.integration.teamtrack.TeamTrackRetriever;
import com.monsanto.jirateamtrack.integration.teamtrack.TeamTrackItemChanger;
import com.monsanto.jirateamtrack.integration.plugin.JiraIssueRetriever;
import org.junit.Test;
import static org.junit.Assert.*;

import java.math.BigInteger;
import java.rmi.RemoteException;


/**
 * Created by CGSHAF on 7/17/2014.
 */
public class UT_TestGeneratedService {
    private String username= "NA1000APP-EDT-JIRA";
    private String password= "7habuWRu";
    //Transition ID's
    private static String teamTrackToDevelopmentTransitionId="1953";
    private static String teamTrackToReadyForItDeploymentId="2023";
    private static String teamTrackToTechLeadApprovalId ="2019";
    private static String teamTrackToReadyForItId ="2039";

    @Test
    public void testIsUserSet() {

        assertFalse("".equals(password) || "".equals(username));
    }

    @Test
    public void testGetVersion() {
        System.out.println(TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem("1004:69773").getExtendedFieldList());

        assert true;
    }
    @Test
    public void getCustFieldIds(){
        TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem("1004:69773").getExtendedFieldList(10).toString();


    }

    @Test
    public void testForECRs() {
        TeamTrackRetriever.CreateWithEnviromentAuth().findChildrenOfPCR("1004:69799");
        assert true;
    }
    @Test
    public void findExtendedField(){
       TTItem item = TeamTrackRetriever.CreateWithEnviromentAuth().retrieveItem("1004:69799");

        for(NameValue value: item.getExtendedFieldList()) {

            if (value.getValue() != null) {
                if(value.getId().equals(new BigInteger("624"))) {
                    System.out.println("ID:" + value.getId() + " Name:" + value.getName());
                    Value newValue = value.getValue();
                    newValue.setInternalValue("40");
                    value.setValue(newValue);

                }
            }
        }
    }
    @Test
    public void testUpdateEstimate(){

        try {
            TeamTrackItemChanger.CreateWithEnvironmentAuth().changeOriginalEstimate("1004:69799", "60", true);
        }catch (RemoteException e){
            e.printStackTrace();
        }
        assert true;

    }


@Test
public void setDeveloperField(){
    TTItem ecrItem = TeamTrackRetriever.CreateWithEnviromentAuth().findECRItemID("1004:69843");
    String ecrItemID = ecrItem.getGenericItem().getItemID();
    System.out.println("~~~~~~~~~~~~~~~~");
    System.out.println("Testing Set");
    System.out.println(ecrItemID);
    User user = TeamTrackRetriever.CreateWithEnviromentAuth().findUser("AEGIBBO");
    System.out.println(user.getId());
    BigInteger userID = user.getId();

    if(ecrItem != null) {
                    try {
                        TeamTrackItemChanger.CreateWithEnvironmentAuth().setDeveloper(ecrItemID, userID, true);
                    }catch (RemoteException e){
                        e.printStackTrace();
                    }
        System.out.println("~~~~~~~~~~~~~~~~~~~");
    }else
        System.out.println("No ECR Found To Update Developer For");

}


    @Test
    public void testPushECR(){
        try {
            TeamTrackItemChanger.CreateWithEnvironmentAuth().changeStatus("1004:69799", teamTrackToDevelopmentTransitionId, true);
        }catch (RemoteException e){
            e.printStackTrace();
        }
    assert true;

    }

}




