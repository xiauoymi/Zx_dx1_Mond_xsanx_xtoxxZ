package ut.com.monsanto.jirateamtrack.integration;

import org.junit.Test;
import com.monsanto.jirateamtrack.integration.plugin.MyPluginComponent;
import com.monsanto.jirateamtrack.integration.plugin.MyPluginComponentImpl;

import static org.junit.Assert.assertEquals;

public class MyComponentUnitTest
{
    @Test
    public void testMyName()
    {
        MyPluginComponent component = new MyPluginComponentImpl(null);
        assertEquals("names do not match!", "myComponent",component.getName());
    }
}