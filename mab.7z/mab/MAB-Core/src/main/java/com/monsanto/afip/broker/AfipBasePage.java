package com.monsanto.afip.broker;

import com.google.common.collect.Lists;
import com.monsanto.afip.broker.domain.AfipResponse;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.jsoup.select.Selector;

import java.util.Collection;
import java.util.Collections;
import java.util.Date;

/**
 * * Parses a raw string response in order to get an AfipResponse.
 *
 * @author PPERA
 */
public abstract class AfipBasePage extends Page {

    /**
     * The Jsoup query that when executed finds the elements that hold the errors
     */
    private String errorQuery;

    /**
     * The Jsoup query that when executed finds the validity element
     */
    private String validityQuery;

    /**
     * If the text of the validity element is the same as this, then the response was that the document is valid
     */
    private String successResponseString;


    protected String getErrorQuery() {
        return errorQuery;
    }

    public void setErrorQuery(String errorQuery) {
        this.errorQuery = errorQuery;
    }

    protected String getValidityQuery() {
        return validityQuery;
    }

    public void setValidityQuery(String validityQuery) {
        this.validityQuery = validityQuery;
    }

    protected String getExpectedValidityString() {
        return successResponseString;
    }

    public void setSuccessResponseString(String successResponseString) {
        this.successResponseString = successResponseString;
    }

    /**
     * Extracts the validity truth-value from the rawResponse if the rawResponse has one of the expected formats.
     *
     * @return True if the validation message says its a valid document
     */
    protected boolean isValid(){
        org.jsoup.nodes.Document document = this.getContentDocument();
        Elements validityElements = Selector.select(this.getValidityQuery(), document);

        this.verifyValidityElements(validityElements);

        //node.html() replaces special characters (such as ó) with html entities (&oacute;)
        return !validityElements.isEmpty() && this.getExpectedValidityString().equals(this.getActualValidityString(validityElements));
    }

    protected abstract String getActualValidityString(Elements validityElements);

    protected abstract void verifyValidityElements(Elements validityElements);

    protected Collection<String> getErrors() {
        org.jsoup.nodes.Document document = getContentDocument();
        Elements errorElements = Selector.select(this.getErrorQuery(), document);

        Collection<String> serviceErrors;

        if (errorElements.size() > 0) {
            serviceErrors = Lists.newArrayListWithExpectedSize(errorElements.size());

            for (Element element : errorElements) {
                String text = element.text();

                if (this.isAValidError(element)) {
                    serviceErrors.add(text);
                }
            }
        } else {
            serviceErrors = Collections.emptyList();
        }

        return serviceErrors;
    }

    protected abstract boolean isAValidError(Element element);

    /**
     * Extracts the response from the page
     *
     * @return A response with it's validity value, the errors if they occurred and the date.
     */
    public AfipResponse getResponse(){
        AfipResponse afipResponse = new AfipResponse();

        afipResponse.setValid(this.isValid());
        afipResponse.setErrors(this.getErrors());
        afipResponse.setDateTime(new Date());

        this.verifyAfipResponse(afipResponse);

        return afipResponse;
    }

    protected abstract void verifyAfipResponse(AfipResponse afipResponse);
}
