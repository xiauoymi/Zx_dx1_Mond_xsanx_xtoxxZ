package com.monsanto.afip.broker;

import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.domain.Document;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

import static org.springframework.util.Assert.notNull;

/**
 * A service that accepts a Document for validation, verifies its completeness and connects with AFIP in order to
 * get a validation response. Once AFIP returns its raw response, it is processed so that the important information is extracted in
 * the form of an AfipResponse.
 *
 * @author PPERA
 */
public abstract class AfipBaseService<P extends AfipBasePage> implements AfipService {

    private static final Logger log = Logger.getLogger(AfipBaseService.class);

    @Autowired
    private RestTemplate restTemplate;
    private String url;
    private Map<String, String> urlParams;

    protected RestTemplate getRestTemplate() {
        return restTemplate;
    }

    public void setRestTemplate(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Map<String, String> getUrlParams() {
        return urlParams;
    }

    public void setUrlParams(Map<String, String> urlParams) {
        this.urlParams = urlParams;
    }

    /**
     * Validates the data of a supporting document with Afip
     *
     * @param document data
     * @return Afip's response with the validation information
     * @throws IllegalArgumentException if the document's data is incomplete or formatted incorrectly
     */
    public AfipResponse validate(Document document) {
        notNull(document, "The request should not be null");
        notNull(document.getCuit(), "The cuit should not be null");

        verifyRequest(document);

        P afipPage = this.getPage(document);

        return afipPage.getResponse();
    }

    /**
     * This method throws an exception if the document lacks the necessary data to perform the given validation
     *
     * @param document representation containing data of a supporting document to be validated.
     */
    protected abstract void verifyRequest(Document document);

    /**
     * Double dispatcher
     *
     * @param document data used to validate it.
     * @return a representation of a web page returned by AFIP with the validation results
     */
    protected P getPage(Document document) {
        P page = newPage();

        String content = this.getResponseContent(document);

        page.setContent(content);

        return page;
    }

    /**
     * Create a new instance of the given page
     *
     * @return a representation of the page returned by Afip containing the validation results
     */
    protected abstract P newPage();

    protected String getResponseContent(Document document) {
        MultiValueMap<String, String> pageParameters = this.makeRestRequest(document);

        if ( log.isDebugEnabled() ) {
            log.debug("Porting for page " + this.getUrl() + "with parameters " + pageParameters);
        }
        String pageContent = this.getRestTemplate().postForObject(this.getUrl(), pageParameters, String.class, this.getUrlParams());

        if ( log.isDebugEnabled() ) {
            log.debug( "Receiving response: " + pageContent);
        }
        return pageContent;
    }

    protected abstract MultiValueMap<String, String> makeRestRequest(Document document);
}
