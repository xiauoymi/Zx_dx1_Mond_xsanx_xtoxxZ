package com.monsanto.afip.broker;

import com.google.common.base.Function;
import com.google.common.collect.Collections2;
import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.domain.Document;
import com.monsanto.afip.broker.exceptions.UnexpectedPageFormatException;
import org.springframework.web.client.HttpStatusCodeException;

import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static org.springframework.util.Assert.notNull;

/**
 * This is a facade that implements the business logic of the validation process, I.E:
 * - The order o validation
 * - The generation of a single response
 *
 * @author PPERA
 */
public class AfipBroker {

    public static final int SUCCESS_STATUS = 200;
    public static final int INCOMPLETE_DATA_STATUS = 290;
    private static final int UNEXPECTED_FORMAT_STATUS = 291;
    public static final String ID_SAP_IS_MISSING = "idSap is missing";
    public static final String YEAR_OF_DOCUMENT_IS_MISSING = "yearOfDocument is missing";

    private List<AfipService> services;

    public List<AfipService> getServices() {
        return services;
    }

    public void setServices(List<AfipService> services) {
        this.services = services;
    }

    /**
     * Processes a collection of document data to determine which ones are valid documents. If any of them is not valid
     * it returns a list of errors that might have caused the validation to fail.
     * The steps for validation for each document are:
     * - Request a CAI validation
     * - If the document is valid for Cai then a valid response is added to the response list and the process
     * continues with the next document.
     * - Request a CAE validation
     * - If the document is valid for Cae then a valid response is added to the response list and the process
     * continues with the next document.
     * - Request a CAEA validation
     * - If the document is valid for Caea then a valid response is added to the response list and the process
     * continues with the next document.
     * - If the document resulted invalid for all three codes then an invalid response in generated and all the
     * possible errors lists from the three services are added up in that response. Then the response is added to
     * the response list and the process continues with the next document.
     * <p/>
     * - Exceptions:
     * - If any of the sub-validations throw an exception then it is interpreted and added to the response
     * as an error.
     *
     * @param documents to be validates
     * @return The response from AFIP with the validity information
     */
    public List<AfipResponse> validate(Collection<Document> documents) {
        notNull(documents);

        List<AfipResponse> afipResponses = Lists.newArrayListWithExpectedSize(documents.size());

        for (Document document : documents) {
            AfipResponse response = this.getResponseForDocument(document);
            response.setDateTime(new Date());
            response.setIdSap(document.getIdSap());
            response.setYearOfDocument(document.getYearOfDocument());
            afipResponses.add(response);
        }

        return afipResponses;
    }

    private AfipResponse getResponseForDocument(Document document) {
        if (document.getIdSap() == null) {
            return this.makeMissingIdSapResponse();
        } else if (document.getYearOfDocument() == null) {
            return makeMissingYearOfDocumentResponse();
        }

        List<Integer> errorStatuses = Lists.newArrayList();
        List<AfipResponse> afipResponses = Lists.newArrayList();

        for (AfipService service : this.getServices()) {
            try {
                AfipResponse response = null;

                try {
                    response = service.validate(document);
                } catch (UnexpectedPageFormatException e) {
                    response = this.makeUnexpectedFormatExceptionResponse(e.getMessage());
                    errorStatuses.add(response.getStatus());
                } catch (IllegalArgumentException e) {
                    response = this.makeIllegalArgumentExceptionResponse(e.getMessage());
                    errorStatuses.add(INCOMPLETE_DATA_STATUS);
                }

                if (response.isValid()) {
                    response.setStatus(SUCCESS_STATUS);
                    return response;
                }

                afipResponses.add(response);

            } catch (HttpStatusCodeException e) {
                errorStatuses.add(e.getStatusCode().value());
            }
        }

        return this.consolidateErrorResponse(afipResponses, errorStatuses, document);
    }

    private AfipResponse makeIllegalArgumentExceptionResponse(String message) {
        return new AfipResponse(Lists.newArrayList(message), INCOMPLETE_DATA_STATUS, false);
    }

    private AfipResponse makeUnexpectedFormatExceptionResponse(String message) {
        return new AfipResponse(Lists.newArrayList(message), UNEXPECTED_FORMAT_STATUS, false);
    }

    private AfipResponse makeMissingYearOfDocumentResponse() {
        return new AfipResponse(Lists.newArrayList(YEAR_OF_DOCUMENT_IS_MISSING), INCOMPLETE_DATA_STATUS, false);
    }

    private AfipResponse makeMissingIdSapResponse() {
        return new AfipResponse(Lists.newArrayList(ID_SAP_IS_MISSING), INCOMPLETE_DATA_STATUS, false);
    }

    private AfipResponse consolidateErrorResponse(List<AfipResponse> afipResponses, List<Integer> errorStatuses, Document document) {
        AfipResponse uniqueAfipResponse = new AfipResponse(this.getConsolidatedErrors(afipResponses), this.getUniqueStatus(errorStatuses, SUCCESS_STATUS), false);
        uniqueAfipResponse.setIdSap(document.getIdSap());
        uniqueAfipResponse.setYearOfDocument(document.getYearOfDocument());

        return uniqueAfipResponse;
    }

    private Integer getUniqueStatus(List<Integer> errorStatuses, int defaultStatus) {
        if (errorStatuses.isEmpty()) {
            return defaultStatus;
        }

        return Collections.max(errorStatuses);
    }

    private Collection<String> getConsolidatedErrors(List<AfipResponse> afipResponses) {
        return Lists.newArrayList(Iterables.concat(

                Collections2.transform(afipResponses, new Function<AfipResponse, Collection<String>>() {
                    public Collection<String> apply(AfipResponse afipResponse) {
                        return afipResponse.getErrors();
                    }
                })

        )
        );
    }
}
