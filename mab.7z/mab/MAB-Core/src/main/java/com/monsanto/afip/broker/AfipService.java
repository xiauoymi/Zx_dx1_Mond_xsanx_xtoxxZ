package com.monsanto.afip.broker;

import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.domain.Document;

/**
 * This class validates the data of a supporting document. The results of the validation may be:
 * - The supporting document data is valid for cai.
 * - The supporting document date is invalid for cai. A list of possible reasons is detailed.
 * - The validation process failed because of connection problems (HTTP ERROR 4xx, HTTP ERROR 5xx)
 * - The validation process failed due to data completeness issues (null fields).
 * - The validation process failed due to input data formatting issues (empty strings, invalid dates).
 * - The validation process failed after a time-out occurred.
 * - The validation process failed because the servers responded in an unexpected way.
 * @author PPERA
 */
public interface AfipService {
    AfipResponse validate(Document document);
}
