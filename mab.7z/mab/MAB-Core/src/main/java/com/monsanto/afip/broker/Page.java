package com.monsanto.afip.broker;

import org.jsoup.parser.Parser;

/**
 * Represents a web page that contains information and holds the HTML code of that page in order to
 * obtain the data. How the data is obtained is a responsibility of the implementations.
 *
 * @author PPERA
 */
public abstract class Page {

    private String baseUri;
    private String content;
    private org.jsoup.nodes.Document document;

    public String getBaseUri() {
        return baseUri;
    }

    public void setBaseUri(String baseUri) {
        this.baseUri = baseUri;
    }

    /**
     * Sets the content of this page
     *
     * @param content of the page returned by Afip in the form of a raw HTML String
     */
    public void setContent(String content) {
        this.content = content;
        this.document = null;
    }

    /**
     * Parses a document out of a raw content
     *
     * @return The document made out of the content
     */
    protected org.jsoup.nodes.Document getContentDocument() {
        if (this.document == null) {
            this.document = Parser.parse(this.content, this.getBaseUri());
        }

        return this.document;
    }
}
