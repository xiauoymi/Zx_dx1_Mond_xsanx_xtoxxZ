package com.monsanto.afip.broker.cae;

import com.monsanto.afip.broker.AfipBasePage;
import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.exceptions.UnexpectedPageFormatException;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Represents a web page than can be read in order to obtain the important elements o a response to the CaeService validation
 *
 * @author PPERA
 */
public class CaePage extends AfipBasePage {
    private String failureResponseString;

    public String getFailureResponseString() {
        return failureResponseString;
    }

    public void setFailureResponseString(String failureResponseString) {
        this.failureResponseString = failureResponseString;
    }

    @Override
    protected void verifyValidityElements(Elements validityElements) {
        if (!this.getExpectedValidityString().equals(validityElements.text()) && !this.getFailureResponseString().equals(validityElements.text())) {
            throw new UnexpectedPageFormatException("The validity elements could not be read correctly");
        }
    }

    @Override
    protected String getActualValidityString(Elements validityElements) {
        return validityElements.text();
    }

    @Override
    protected boolean isAValidError(Element element) {
        return true;
    }

    @Override
    protected void verifyAfipResponse(AfipResponse afipResponse) {
        if (!afipResponse.isValid() && afipResponse.getErrors().isEmpty()) {
            throw new UnexpectedPageFormatException("The response should have errors if it is invalid.");
        }
    }
}
