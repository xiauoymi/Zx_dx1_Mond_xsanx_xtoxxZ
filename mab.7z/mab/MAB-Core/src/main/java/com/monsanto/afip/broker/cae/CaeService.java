package com.monsanto.afip.broker.cae;

import com.google.common.collect.Lists;
import com.monsanto.afip.broker.AfipBaseService;
import com.monsanto.afip.broker.domain.Document;
import com.monsanto.afip.broker.domain.SapDocumentType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.text.NumberFormat;
import java.util.Calendar;
import java.util.Map;

import static org.springframework.util.Assert.notNull;

/**
 * This class validates the data of a supporting document. The results of the validation may be:
 * - The supporting document data is valid for cae.
 * - The supporting document date is invalid for cae. A list of possible reasons is detailed.
 * - The validation process failed because of connection problems (HTTP ERROR 4xx, HTTP ERROR 5xx)
 * - The validation process failed due to data completeness issues (null fields).
 * - The validation process failed due to input data formatting issues (empty strings, invalid dates).
 * - The validation process failed after a time-out occurred.
 * - The validation process failed because the servers responded in an unexpected way.
 *
 * @author PPERA
 */
public abstract class CaeService extends AfipBaseService<CaePage> {

    private static final String RECEIVER_DOCUMENT_TYPE_CUIT = "80";
    private Map<SapDocumentType, String> sapDocumentTypeMap;
    public static final String ERROR_UNKNOWN_DOCUMENT_CLASS_OR_TYPE = "Unknown document class or Type";

    public void setSapDocumentTypeMap(Map<SapDocumentType, String> sapDocumentTypeMap) {
        this.sapDocumentTypeMap = sapDocumentTypeMap;
    }

    @Override
    protected void verifyRequest(Document document) {
        notNull(document.getAmount(), "Amount should be provided");
        notNull(document.getCode(), "Code should be provided");
        notNull(document.getCreationDate(), "Creation date should be provided");
        notNull(document.getReceiverIdentificationNumber(), "Receiver Id number should be provided");
        notNull(document.getSalesPointNumber(), "Sales point should be provided");
        notNull(document.getSupportingDocumentNumber(), "Supporting document number should be provided");
        notNull(document.getSupportingDocumentType(), "SupPorting document type should be provided");
    }

    @Override
    protected MultiValueMap<String, String> makeRestRequest(Document document) {
        MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<String, String>();

        DotNetSecuredResponse dotNetSecuredResponse = this.getDotNetPage().getResponse();

        multiValueMap.put("__EVENTVALIDATION", Lists.<String>newArrayList(dotNetSecuredResponse.getEventValidation()));
        multiValueMap.put("__VIEWSTATE", Lists.<String>newArrayList(dotNetSecuredResponse.getViewState()));

        multiValueMap.put("Button", Lists.<String>newArrayList("Consultar"));
        multiValueMap.put("p_CAE", Lists.newArrayList(document.getCode()));
        multiValueMap.put("p_CUIT", Lists.newArrayList(document.getCuit()));

        Calendar cal = Calendar.getInstance();
        cal.setTime(document.getCreationDate());
        multiValueMap.put("p_fch_emision_day", Lists.newArrayList(String.valueOf(cal.get(Calendar.DAY_OF_MONTH))));
        multiValueMap.put("p_fch_emision_month", Lists.newArrayList(String.valueOf(cal.get(Calendar.MONTH) + 1)));
        multiValueMap.put("p_fch_emision_year", Lists.newArrayList(String.valueOf(cal.get(Calendar.YEAR))));

        NumberFormat decimalFormat = NumberFormat.getInstance();
        decimalFormat.setGroupingUsed(false);
        multiValueMap.put("p_importe", Lists.newArrayList(decimalFormat.format(document.getAmount().doubleValue())));

        multiValueMap.put("p_nro_cbte", Lists.newArrayList(document.getSupportingDocumentNumber()));
        multiValueMap.put("p_nro_doc", Lists.newArrayList(document.getReceiverIdentificationNumber()));
        multiValueMap.put("p_pto_vta", Lists.newArrayList(document.getSalesPointNumber()));
        multiValueMap.put("p_tipo_cbte", Lists.newArrayList(this.translateDocumentClassAndType(new SapDocumentType(document.getSupportingDocumentClass(), document.getSupportingDocumentType()))));
        multiValueMap.put("p_tipo_doc", Lists.newArrayList(RECEIVER_DOCUMENT_TYPE_CUIT));

        return multiValueMap;
    }

    private String translateDocumentClassAndType(SapDocumentType sapDocumentType) {
        if(!this.sapDocumentTypeMap.containsKey(sapDocumentType)){
            throw new IllegalArgumentException(ERROR_UNKNOWN_DOCUMENT_CLASS_OR_TYPE);
        }

        return this.sapDocumentTypeMap.get(sapDocumentType);
    }

    private DotNetSecuredPage getDotNetPage() {
        DotNetSecuredPage page = new DotNetSecuredPage();
        page.setBaseUri(this.getUrl());
        String content = this.getDotNetResponseContent();

        page.setContent(content);

        return page;
    }

    private String getDotNetResponseContent() {
        return this.getRestTemplate().postForObject(this.getUrl(), null, String.class, this.getUrlParams());
    }
}
