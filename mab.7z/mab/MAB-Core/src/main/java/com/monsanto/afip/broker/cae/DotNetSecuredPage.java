package com.monsanto.afip.broker.cae;

import com.monsanto.afip.broker.Page;
import com.monsanto.afip.broker.exceptions.UnexpectedPageFormatException;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.jsoup.select.Selector;

/**
 * Represents a page that holds information specific to an ASP secured enviroment.
 * I.E. : ViewState and EventValidation values
 *
 * @author PPERA
 */
public class DotNetSecuredPage extends Page {


    public DotNetSecuredResponse getResponse() {
        Document plainFormDocument = this.getContentDocument();

        Elements eventValidationElements = Selector.select("#__EVENTVALIDATION", plainFormDocument);
        String eventValidation = eventValidationElements.val();
        Elements viewStateElements = Selector.select("#__VIEWSTATE", plainFormDocument);
        String viewState = viewStateElements.val();

        if (eventValidationElements.isEmpty() || viewStateElements.isEmpty()) {
            throw new UnexpectedPageFormatException();
        }

        return  new DotNetSecuredResponse(viewState, eventValidation);
    }
}
