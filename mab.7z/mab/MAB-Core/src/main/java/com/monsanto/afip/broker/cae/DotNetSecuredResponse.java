package com.monsanto.afip.broker.cae;

/**
 * @author PPERA
 */
public class DotNetSecuredResponse {
    private String viewState;
    private String eventValidation;

    public DotNetSecuredResponse(String viewState, String eventValidation) {
        this.viewState = viewState;
        this.eventValidation = eventValidation;
    }

    public String getEventValidation() {
        return eventValidation;
    }

    public String getViewState() {
        return viewState;
    }
}
