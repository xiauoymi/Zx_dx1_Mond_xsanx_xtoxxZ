package com.monsanto.afip.broker.caea;

import com.monsanto.afip.broker.AfipBasePage;
import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.exceptions.UnexpectedPageFormatException;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Represents the page received from AFIP as a response for a CAEA document validation.
 * Allows request the page and simplifies access to page data.
 *
 * @author PPERA
 */
public class CaeaPage extends AfipBasePage {

    @Override
    protected void verifyValidityElements(Elements validityElements) {
        if (validityElements.isEmpty()) {
            throw new UnexpectedPageFormatException("The validity response was not found");
        }
    }

    @Override
    protected String getActualValidityString(Elements validityElements) {
        return validityElements.text();
    }

    @Override
    protected boolean isAValidError(Element element) {
        return !(element.text().equals(this.getExpectedValidityString()));
    }

    @Override
    protected void verifyAfipResponse(AfipResponse afipResponse) {
    }
}
