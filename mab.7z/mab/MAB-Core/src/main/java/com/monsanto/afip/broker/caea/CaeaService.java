package com.monsanto.afip.broker.caea;

import com.google.common.collect.Lists;
import com.monsanto.afip.broker.AfipBaseService;
import com.monsanto.afip.broker.domain.Document;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import static org.springframework.util.Assert.notNull;

/**
 * This class validates the data of a supporting document. The results of the validation may be:
 * - The supporting document data is valid for caea.
 * - The supporting document date is invalid for caea. A list of possible reasons is detailed.
 * - The validation process failed because of connection problems (HTTP ERROR 4xx, HTTP ERROR 5xx)
 * - The validation process failed due to data completeness issues (null fields).
 * - The validation process failed due to input data formatting issues (empty strings, invalid dates).
 * - The validation process failed after a time-out occurred.
 * - The validation process failed because the servers responded in an unexpected way.
 *
 * @author PPERA
 */
public abstract class CaeaService extends AfipBaseService<CaeaPage> {

    @Override
    protected void verifyRequest(Document document) {
        notNull(document.getCode());
    }

    @Override
    protected MultiValueMap<String, String> makeRestRequest(Document document) {
        MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<String, String>();

        multiValueMap.put("fcuit", Lists.<String>newArrayList(document.getCuit()));
        multiValueMap.put("fcaea", Lists.<String>newArrayList(document.getCode()));
        multiValueMap.put("prmCAEA", Lists.<String>newArrayList(document.getCuit() + "|" + document.getCode() + "|"));

        return multiValueMap;
    }
}
