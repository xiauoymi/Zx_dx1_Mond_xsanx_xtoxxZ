package com.monsanto.afip.broker.cai;

import com.monsanto.afip.broker.AfipBasePage;
import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.exceptions.UnexpectedPageFormatException;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * Parses a raw string response in order to get an AfipResponse.
 *
 * @author PPERA
 */
public class CaiPage extends AfipBasePage {

    @Override
    protected void verifyValidityElements(Elements validityElements) {
    }

    @Override
    protected String getActualValidityString(Elements validityElements) {
        return validityElements.html();
    }

    @Override
    protected boolean isAValidError(Element element) {
        return true;
    }

    @Override
    protected void verifyAfipResponse(AfipResponse afipResponse) {
        if (!afipResponse.isValid() && afipResponse.getErrors().isEmpty()) {
            throw new UnexpectedPageFormatException("Unexpected format: The response should have errors if it is invalid. This might be caused by corrupted data (eg: Cuit = notNumbers)");
        }
    }
}
