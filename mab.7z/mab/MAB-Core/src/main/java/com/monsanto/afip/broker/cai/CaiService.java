package com.monsanto.afip.broker.cai;

import com.google.common.collect.Lists;
import com.monsanto.afip.broker.AfipBaseService;
import com.monsanto.afip.broker.domain.Document;
import com.monsanto.afip.broker.domain.SapDocumentType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Calendar;
import java.util.Map;

import static org.springframework.util.Assert.notNull;

/**
 * This class validates the data of a supporting document. The results of the validation may be:
 * - The supporting document data is valid for cai.
 * - The supporting document date is invalid for cai. A list of possible reasons is detailed.
 * - The validation process failed because of connection problems (HTTP ERROR 4xx, HTTP ERROR 5xx)
 * - The validation process failed due to data completeness issues (null fields).
 * - The validation process failed due to input data formatting issues (empty strings, invalid dates).
 * - The validation process failed after a time-out occurred.
 * - The validation process failed because the servers responded in an unexpected way.
 *
 * @author PPERA
 */
public abstract class CaiService extends AfipBaseService<CaiPage> {
    public static final String ERROR_UNKNOWN_DOCUMENT_CLASS_OR_TYPE = "Unknown document class or Type";
    private Map<SapDocumentType, String> sapDocumentTypeMap;

    public void setSapDocumentTypeMap(Map<SapDocumentType, String> sapDocumentTypeMap) {
        this.sapDocumentTypeMap = sapDocumentTypeMap;
    }

    protected void verifyRequest(Document document) {
        notNull(document.getCode(), "The Cai should not be null");
        notNull(document.getCreationDate(), "The creation date should not be null");
        notNull(document.getSalesPointNumber(), "The sales point number should not be null");
        notNull(document.getSupportingDocumentNumber(), "The supporting document number should not be null");
        notNull(document.getSupportingDocumentType(), "The supporting document type should not be null");
    }

    @Override
    protected MultiValueMap<String, String> makeRestRequest(Document document) {
        MultiValueMap<String, String> multiValueMap = new LinkedMultiValueMap<String, String>();

        multiValueMap.put("fcai", Lists.newArrayList(document.getCode()));
        multiValueMap.put("fcuit", Lists.newArrayList(document.getCuit()));

        Calendar cal = Calendar.getInstance();
        cal.setTime(document.getCreationDate());
        multiValueMap.put("fdia", Lists.newArrayList(String.valueOf(cal.get(Calendar.DAY_OF_MONTH))));
        multiValueMap.put("fmes", Lists.newArrayList(String.valueOf(cal.get(Calendar.MONTH) + 1)));
        multiValueMap.put("fanio", Lists.newArrayList(String.valueOf(cal.get(Calendar.YEAR))));

        multiValueMap.put("fnumero", Lists.newArrayList(document.getSupportingDocumentNumber()));
        multiValueMap.put("fpvta", Lists.newArrayList(document.getSalesPointNumber()));
        multiValueMap.put("fnro_comprob", Lists.newArrayList(this.translateDocumentClassAndType(new SapDocumentType(document.getSupportingDocumentClass(), document.getSupportingDocumentType()))));

        return multiValueMap;
    }


    private String translateDocumentClassAndType(SapDocumentType sapDocumentType) {
        if (!this.sapDocumentTypeMap.containsKey(sapDocumentType)) {
            throw new IllegalArgumentException(ERROR_UNKNOWN_DOCUMENT_CLASS_OR_TYPE);
        }
        return this.sapDocumentTypeMap.get(sapDocumentType);
    }
}
