package com.monsanto.afip.broker.domain;

import javax.xml.bind.annotation.*;
import java.util.Collection;
import java.util.Date;

/**
 * The response Page received from an AFIP validation request.
 *
 * @author PPERA
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "afipResponseType", namespace = "http://www.monsanto.com/afipbroker", propOrder = {
        "valid",
        "errors",
        "dateTime",
        "status",
        "idSap",
        "yearOfDocument",
        "extra1",
        "extra2"
})
public class AfipResponse {
    @XmlElement(namespace = "http://www.monsanto.com/afipbroker", required = true)
    private boolean valid = false;

    @XmlElementWrapper(name = "errors", namespace = "http://www.monsanto.com/afipbroker")
    @XmlElement(namespace = "http://www.monsanto.com/afipbroker", required = true, name = "error")
    protected Collection<String> errors;
    @XmlElement(namespace = "http://www.monsanto.com/afipbroker", required = true)
    private Date dateTime;
    @XmlElement(namespace = "http://www.monsanto.com/afipbroker", required = true)
    private int status;
    @XmlElement(namespace = "http://www.monsanto.com/afipbroker", required = true)
    private String idSap;
    @XmlElement(namespace = "http://www.monsanto.com/afipbroker", required = true)
    private Date yearOfDocument;
    @XmlElement(namespace = "http://www.monsanto.com/afipbroker")
    private String extra1;
    @XmlElement(namespace = "http://www.monsanto.com/afipbroker")
    private String extra2;

    public AfipResponse() {
    }

    public AfipResponse(Collection<String> errors, int status, boolean valid) {
        this.errors = errors;
        this.status = status;
        this.valid = valid;
    }

    public boolean isValid() {
        return valid;
    }

    public void setValid(boolean valid) {
        this.valid = valid;
    }

    public Collection<String> getErrors() {
        return errors;
    }

    public void setErrors(Collection<String> errors) {
        this.errors = errors;
    }

    public Date getDateTime() {
        return dateTime;
    }

    public void setDateTime(Date dateTime) {
        this.dateTime = dateTime;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getIdSap() {
        return idSap;
    }

    public void setIdSap(String idSap) {
        this.idSap = idSap;
    }

    public Date getYearOfDocument() {
        return yearOfDocument;
    }

    public void setYearOfDocument(Date yearOfDocument) {
        this.yearOfDocument = yearOfDocument;
    }

    public String getExtra1() {
        return extra1;
    }

    public void setExtra1(String extra1) {
        this.extra1 = extra1;
    }

    public String getExtra2() {
        return extra2;
    }

    public void setExtra2(String extra2) {
        this.extra2 = extra2;
    }

    @Override
    public String toString() {
        return "AfipResponse{" +
                "valid=" + valid +
                ", errors=" + errors +
                ", dateTime=" + dateTime +
                ", status=" + status +
                ", idSap='" + idSap + '\'' +
                ", yearOfDocument=" + yearOfDocument +
                ", extra1='" + extra1 + '\'' +
                ", extra2='" + extra2 + '\'' +
                '}';
    }
}
