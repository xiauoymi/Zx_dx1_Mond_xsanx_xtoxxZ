package com.monsanto.afip.broker.domain;

import javax.xml.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Date;

/**
 * This object contains the necessary data for a Cai validation.
 *
 * @author PPERA
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "documentType", namespace = "http://www.monsanto.com/afipbroker")
public class Document {
    @XmlAttribute(required = true)
    protected BigDecimal amount;
    @XmlAttribute(required = true)
    protected String code;
    @XmlAttribute(required = true)
    @XmlSchemaType(name = "date")
    protected Date creationDate;
    @XmlAttribute(required = true)
    protected String cuit;
    @XmlAttribute(required = true)
    protected String receiverIdentificationNumber;
    @XmlAttribute(required = true)
    protected String salesPointNumber;
    @XmlAttribute(required = true)
    protected String supportingDocumentNumber;
    @XmlAttribute(required = true)
    protected String supportingDocumentClass;
    @XmlAttribute(required = true)
    protected String supportingDocumentType;
    @XmlAttribute(required = true)
    protected String idSap;
    @XmlAttribute(required = true)
    @XmlSchemaType(name = "date")
    protected Date yearOfDocument;
    @XmlAttribute
    protected String extra1;
    @XmlAttribute
    protected String extra2;


    public String getCuit() {
        return cuit;
    }

    public void setCuit(String cuit) {
        this.cuit = cuit;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getSupportingDocumentType() {
        return supportingDocumentType;
    }

    public void setSupportingDocumentType(String supportingDocumentType) {
        this.supportingDocumentType = supportingDocumentType;
    }

    public String getSupportingDocumentClass() {
        return supportingDocumentClass;
    }

    public void setSupportingDocumentClass(String supportingDocumentClass) {
        this.supportingDocumentClass = supportingDocumentClass;
    }

    public String getSalesPointNumber() {
        return salesPointNumber;
    }

    public void setSalesPointNumber(String salesPointNumber) {
        this.salesPointNumber = salesPointNumber;
    }

    public String getSupportingDocumentNumber() {
        return supportingDocumentNumber;
    }

    public void setSupportingDocumentNumber(String supportingDocumentNumber) {
        this.supportingDocumentNumber = supportingDocumentNumber;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getReceiverIdentificationNumber() {
        return receiverIdentificationNumber;
    }

    public void setReceiverIdentificationNumber(String receiverIdentificationNumber) {
        this.receiverIdentificationNumber = receiverIdentificationNumber;
    }

    public String getIdSap() {
        return idSap;
    }

    public void setIdSap(String idSap) {
        this.idSap = idSap;
    }

    public Date getYearOfDocument() {
        return yearOfDocument;
    }

    public void setYearOfDocument(Date yearOfDocument) {
        this.yearOfDocument = yearOfDocument;
    }

    public String getExtra1() {
        return extra1;
    }

    public void setExtra1(String extra1) {
        this.extra1 = extra1;
    }

    public String getExtra2() {
        return extra2;
    }

    public void setExtra2(String extra2) {
        this.extra2 = extra2;
    }

    @Override
    public String toString() {
        return "Document{" +
                "amount=" + amount +
                ", code='" + code + '\'' +
                ", creationDate=" + creationDate +
                ", cuit='" + cuit + '\'' +
                ", receiverIdentificationNumber='" + receiverIdentificationNumber + '\'' +
                ", salesPointNumber='" + salesPointNumber + '\'' +
                ", supportingDocumentNumber='" + supportingDocumentNumber + '\'' +
                ", supportingDocumentClass='" + supportingDocumentClass + '\'' +
                ", supportingDocumentType='" + supportingDocumentType + '\'' +
                ", idSap='" + idSap + '\'' +
                ", yearOfDocument=" + yearOfDocument +
                ", extra1='" + (extra1 != null ? extra1 : "") + '\'' +
                ", extra2='" + (extra2 != null ? extra2 : "") + '\'' +
                '}';
    }
}
