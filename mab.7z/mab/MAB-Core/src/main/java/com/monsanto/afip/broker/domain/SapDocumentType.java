package com.monsanto.afip.broker.domain;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;

/**
 * Represent the entity that Sap uses to identify a document's type
 *
 * @author PPERA
 */
public class SapDocumentType implements InitializingBean {
    private String documentClass;
    private String documentType;

    public SapDocumentType() {
    }

    public void setDocumentClass(String documentClass) {
        this.documentClass = documentClass;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public SapDocumentType(String documentClass, String documentType) {
        Assert.notNull(documentClass);
        Assert.notNull(documentType);

        this.documentClass = documentClass;
        this.documentType = documentType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SapDocumentType that = (SapDocumentType) o;

        return documentClass.equals(that.documentClass) && documentType.equals(that.documentType);
    }

    @Override
    public int hashCode() {
        return 31 * documentClass.hashCode() + documentType.hashCode();
    }

    public void afterPropertiesSet() throws Exception {
        Assert.notNull(documentClass);
        Assert.notNull(documentType);
    }
}
