package com.monsanto.afip.broker.exceptions;

/**
 * Signal the received page has no the format expected.
 * @author PPERA
 */
public class UnexpectedPageFormatException extends RuntimeException {
    public UnexpectedPageFormatException(String string) {
        super(string);
    }

    public UnexpectedPageFormatException() {
        super();
    }
}
