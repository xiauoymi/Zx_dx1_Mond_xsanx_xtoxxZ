package com.monsanto.afip.broker;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.monsanto.afip.broker.cae.CaeService;
import com.monsanto.afip.broker.caea.CaeaService;
import com.monsanto.afip.broker.cai.CaiService;
import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.domain.Document;
import com.monsanto.afip.broker.exceptions.UnexpectedPageFormatException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Matchers;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import javax.annotation.Nullable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Test for AfipBroker
 *
 * @author PPERA
 */
public class AfipBroker_UT {
    private AfipBroker afipBroker;
    private CaiService caiService;
    private CaeService caeService;
    private CaeaService caeaService;
    private Collection<Document> completeDocuments;
    private Document completeDocument1;
    private Document completeDocument2;
    private Document completeDocument3;
    private Document completeDocument4;

    private AfipResponse validResponse;
    private AfipResponse invalidResponse;

    @Before
    public void setUp() {
        afipBroker = new AfipBroker();

        caiService = mock(CaiService.class);
        caeService = mock(CaeService.class);
        caeaService = mock(CaeaService.class);

        ArrayList<AfipService> services = Lists.<AfipService>newArrayList(caiService, caeService, caeaService);
        afipBroker.setServices(services);

        completeDocument1 = makeCompleteDummyDocument();
        completeDocument2 = makeCompleteDummyDocument();
        completeDocument3 = makeCompleteDummyDocument();
        completeDocument4 = makeCompleteDummyDocument();
        completeDocuments = Lists.newArrayList(completeDocument1, completeDocument2, completeDocument3, completeDocument4);

        validResponse = this.makeValidResponse();
        invalidResponse = this.makeInvalidResponse();
    }

    private Document makeCompleteDummyDocument() {
        Document document = new Document();
        document.setAmount(BigDecimal.ONE);
        document.setCode("123456789");
        document.setCreationDate(new Date());
        document.setCuit("1234567890");
        document.setIdSap("1234567890");
        document.setReceiverIdentificationNumber("987654321");
        document.setSalesPointNumber("0009");
        document.setSupportingDocumentNumber("123456789");
        document.setSupportingDocumentType("A");
        document.setSupportingDocumentClass("DQ");
        document.setYearOfDocument(new Date());

        return document;
    }

    @Test
    public void validate_ValidDocumentsForCai() {
        when(caiService.validate(Matchers.<Document>any())).thenReturn(validResponse);
        when(caeService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);
        when(caeaService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);

        Collection<AfipResponse> afipResponses = afipBroker.validate(completeDocuments);
        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);

        assertEquals(4, validResponses.size());
        assertEquals(0, invalidResponses.size());
    }


    private AfipResponse makeValidResponse() {
        AfipResponse afipResponse = new AfipResponse();
        afipResponse.setValid(true);
        afipResponse.setErrors(Collections.<String>emptyList());
        return afipResponse;
    }

    private AfipResponse makeInvalidResponse() {
        AfipResponse afipResponse = new AfipResponse();
        afipResponse.setValid(false);
        afipResponse.setErrors(Lists.newArrayList("Error 0001"));
        return afipResponse;
    }

    @Test
    public void validate_ValidDocumentsForCae() {
        when(caiService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);
        when(caeService.validate(Matchers.<Document>any())).thenReturn(validResponse);
        when(caeaService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);

        Collection<AfipResponse> afipResponses = afipBroker.validate(completeDocuments);
        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);

        assertEquals(4, validResponses.size());
        assertEquals(0, invalidResponses.size());
    }

    @Test
    public void validate_ValidDocumentsForCaea() {
        when(caiService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);
        when(caeService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);
        when(caeaService.validate(Matchers.<Document>any())).thenReturn(validResponse);

        Collection<AfipResponse> afipResponses = afipBroker.validate(completeDocuments);
        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);

        assertEquals(4, validResponses.size());
        assertEquals(0, invalidResponses.size());
    }


    @Test
    public void validate_OneInvalidDocument() {
        when(caiService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);
        when(caeService.validate(completeDocument1)).thenReturn(invalidResponse);
        when(caeService.validate(completeDocument2)).thenReturn(validResponse);
        when(caeService.validate(completeDocument3)).thenReturn(validResponse);
        when(caeService.validate(completeDocument4)).thenReturn(validResponse);
        when(caeaService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);

        Collection<AfipResponse> afipResponses = afipBroker.validate(completeDocuments);
        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);

        assertEquals(3, validResponses.size());
        assertEquals(1, invalidResponses.size());
    }

    @Test
    public void validate_OneConnectionException_OneService_ValidDocuments() {
        when(caiService.validate(Matchers.<Document>any())).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
        when(caeService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);
        when(caeaService.validate(Matchers.<Document>any())).thenReturn(validResponse);

        Collection<AfipResponse> afipResponses = afipBroker.validate(completeDocuments);
        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);
        Collection<AfipResponse> status404Responses = filterStatus404(afipResponses);

        assertEquals(4, validResponses.size());
        assertEquals(0, invalidResponses.size());
        assertEquals(0, status404Responses.size());
    }

    @Test
    public void validate_OneConnectionException404_OneService_InvalidDocuments() {
        when(caiService.validate(Matchers.<Document>any())).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
        when(caeService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);
        when(caeaService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);

        Collection<AfipResponse> afipResponses = afipBroker.validate(completeDocuments);
        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);
        Collection<AfipResponse> status404Responses = filterStatus404(afipResponses);

        assertEquals(0, validResponses.size());
        assertEquals(4, invalidResponses.size());
        assertEquals(4, status404Responses.size());
    }


    @Test
    public void validate_OneConnectionException500_OneService_InvalidDocuments() {
        when(caiService.validate(completeDocument1)).thenThrow(new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR));
        when(caiService.validate(completeDocument2)).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
        when(caiService.validate(completeDocument3)).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
        when(caiService.validate(completeDocument4)).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));

        when(caeService.validate(completeDocument1)).thenThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND));
        when(caeService.validate(completeDocument2)).thenReturn(invalidResponse);
        when(caeService.validate(completeDocument3)).thenReturn(invalidResponse);
        when(caeService.validate(completeDocument4)).thenReturn(invalidResponse);

        when(caeaService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);

        Collection<AfipResponse> afipResponses = afipBroker.validate(completeDocuments);
        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);
        Collection<AfipResponse> status404Responses = filterStatus404(afipResponses);

        Collection<AfipResponse> status500Responses = Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && input.getStatus() == 500;
            }
        });


        assertEquals(0, validResponses.size());
        assertEquals(4, invalidResponses.size());
        assertEquals(3, status404Responses.size());
        assertEquals(1, status500Responses.size());
    }

    @Test
    public void validate_OneIncompleteDocumentData_OneService() {
        when(caiService.validate(Matchers.<Document>any())).thenThrow(new IllegalArgumentException());
        when(caeService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);
        when(caeaService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);

        Collection<AfipResponse> afipResponses = afipBroker.validate(completeDocuments);
        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);
        Collection<AfipResponse> status290Responses = filterStatus290(afipResponses);

        assertEquals(0, validResponses.size());
        assertEquals(4, invalidResponses.size());
        assertEquals(4, status290Responses.size());
    }

    @Test
    public void validate_MissingIdSap() {
        Document documentWithNoIdSap1 = makeDocumentWithNoIdSap();
        Document documentWithNoIdSap2 = makeDocumentWithNoIdSap();
        Document documentWithNoIdSap3 = makeDocumentWithNoIdSap();
        Document documentWithNoIdSap4 = makeDocumentWithNoIdSap();

        Collection<Document> incompleteDocuments = Lists.newArrayList(documentWithNoIdSap1, documentWithNoIdSap2, documentWithNoIdSap3, documentWithNoIdSap4);

        Collection<AfipResponse> afipResponses = afipBroker.validate(incompleteDocuments);

        Collection<AfipResponse> responsesWithIdSapError = Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && input.getIdSap() == null && input.getErrors().size() == 1 && input.getErrors().contains(AfipBroker.ID_SAP_IS_MISSING);
            }
        });

        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);
        Collection<AfipResponse> status290Responses = filterStatus290(afipResponses);

        assertEquals(0, validResponses.size());
        assertEquals(4, invalidResponses.size());
        assertEquals(4, responsesWithIdSapError.size());
        assertEquals(4, status290Responses.size());
    }

    @Test
    public void validate_MissingYearOfDocument() {
        Document documentWithNoIdSap1 = makeDocumentWithNoYearOfDocument();
        Document documentWithNoIdSap2 = makeDocumentWithNoYearOfDocument();
        Document documentWithNoIdSap3 = makeDocumentWithNoYearOfDocument();
        Document documentWithNoIdSap4 = makeDocumentWithNoYearOfDocument();

        Collection<Document> incompleteDocuments = Lists.newArrayList(documentWithNoIdSap1, documentWithNoIdSap2, documentWithNoIdSap3, documentWithNoIdSap4);

        Collection<AfipResponse> afipResponses = afipBroker.validate(incompleteDocuments);

        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);
        Collection<AfipResponse> status290Responses = filterStatus290(afipResponses);

        Collection<AfipResponse> responsesWithYearOfDocumentError = Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && input.getYearOfDocument() == null && input.getErrors().size() == 1 && input.getErrors().contains(AfipBroker.YEAR_OF_DOCUMENT_IS_MISSING);
            }
        });

        assertEquals(0, validResponses.size());
        assertEquals(4, invalidResponses.size());
        assertEquals(4, responsesWithYearOfDocumentError.size());
        assertEquals(4, status290Responses.size());
    }

    @Test
    public void validate_WhenASingleServiceReturnsAResponseWithUnexpectedFormatAllTheDocumentsAreStillProccessedWithTheOtherServicesAndTheErrorIsReturned(){
        String message = "The format was unexpected";
        when(caiService.validate(Matchers.<Document>any())).thenThrow(new UnexpectedPageFormatException(message));
        when(caeService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);
        when(caeaService.validate(Matchers.<Document>any())).thenReturn(invalidResponse);

        Collection<AfipResponse> afipResponses = afipBroker.validate(completeDocuments);
        Collection<AfipResponse> validResponses = filterValidResponses(afipResponses);
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(afipResponses);
        Collection<AfipResponse> status404Responses = filterStatus404(afipResponses);

        Collection<AfipResponse> status291Responses = Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && input.getStatus() == 291;
            }
        });


        assertEquals(0, validResponses.size());
        assertEquals(4, invalidResponses.size());
        assertEquals(4, status291Responses.size());

        for(AfipResponse afipResponse: afipResponses){
            assertTrue(afipResponse.getErrors().contains(message));
        }
    }

    private Document makeDocumentWithNoIdSap() {
        Document documentWithNoIdSap;
        documentWithNoIdSap = this.makeCompleteDummyDocument();
        documentWithNoIdSap.setIdSap(null);

        return documentWithNoIdSap;
    }

    private Document makeDocumentWithNoYearOfDocument() {
        Document documentWithNoYearOfDocument;
        documentWithNoYearOfDocument = this.makeCompleteDummyDocument();
        documentWithNoYearOfDocument.setYearOfDocument(null);

        return documentWithNoYearOfDocument;
    }

    private Collection<AfipResponse> filterValidResponses(Collection<AfipResponse> afipResponses) {
        return Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && (input.isValid() && input.getStatus() == 200);
            }
        });
    }

    private Collection<AfipResponse> filterInvalidResponses(Collection<AfipResponse> afipResponses) {
        return Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && !input.isValid();
            }
        });
    }

    private Collection<AfipResponse> filterStatus404(Collection<AfipResponse> afipResponses) {
        return Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && input.getStatus() == 404;
            }
        });
    }

    private Collection<AfipResponse> filterStatus290(Collection<AfipResponse> afipResponses) {
        return Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && input.getStatus() == AfipBroker.INCOMPLETE_DATA_STATUS;
            }
        });
    }
}
