package com.monsanto.afip.broker.cae;

import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.exceptions.UnexpectedPageFormatException;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;

import static org.junit.Assert.*;
import static org.springframework.util.FileCopyUtils.copyToString;

/**
 * @author PPERA
 */
public class CaePage_UT {
    private AfipResponse caeResponse;
    private CaePage caePage;

    @Before
    public void setUp() {
        caePage = new CaePage();
        caePage.setBaseUri("http://www.afip.gov.ar/genericos/consultacae/");
        caePage.setErrorQuery("#Respuesta_div ul li");
        caePage.setValidityQuery(".respuesta_titulo b");
        caePage.setSuccessResponseString("Autorizado");
        caePage.setFailureResponseString("NO Autorizado");
    }

    @Test
    public void testGetResponse_ValidDocument() {
        caePage.setContent(readContent("CaeValidDocument.html"));
        caeResponse = caePage.getResponse();
        assertTrue(caeResponse.isValid());
        assertTrue(caeResponse.getErrors().isEmpty());
        assertNotNull(caeResponse.getDateTime());
    }

    @Test
    public void testGetResponse_InvalidDocument() {
        caePage.setContent(readContent("CaeInvalidDocument.html"));
        caeResponse = caePage.getResponse();
        assertFalse(caeResponse.isValid());
        assertFalse(caeResponse.getErrors().isEmpty());
        assertNotNull(caeResponse.getDateTime());
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_MissingResponsePageContent() {
        caePage.setContent(readContent("CaeMissingResponsePage.html"));
        caeResponse = caePage.getResponse();
        caeResponse.isValid();
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_MissingErrorsPage() {
        caePage.setContent(readContent("CaeMissingErrorsPage.html"));
        caeResponse = caePage.getResponse();
        caeResponse.isValid();
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_InvalidResponsePage() {
        caePage.setContent(readContent("CaeInvalidResponsePage.html"));
        caeResponse = caePage.getResponse();
        caeResponse.isValid();
    }

    private String readContent(String resourceName) {
        try {
            URL resource = getClass().getResource(resourceName);

            Charset charset = Charset.forName("iso-8859-1");
            return copyToString(new InputStreamReader(resource.openConnection().getInputStream(), charset));
        } catch (IOException e) {
            throw new RuntimeException("Cannot find resource " + resourceName, e);
        }
    }
}
