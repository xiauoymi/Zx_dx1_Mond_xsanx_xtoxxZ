package com.monsanto.afip.broker.cae;

import com.google.common.collect.Maps;
import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.domain.Document;
import com.monsanto.afip.broker.domain.SapDocumentType;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Matchers.argThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.util.FileCopyUtils.copyToString;

/**
 * @author PPERA
 */
public class CaeService_UT {
    private static final String VALID_TEST_CUIT = "11111111";
    private CaeService caeService;
    private Document caeRequestValid;
    private Document caeRequestInvalid;

    @Before
    public void setUp() throws Exception {

        caeService = new CaeService() {
            @Override
            protected CaePage newPage() {
                CaePage caePage = new CaePage();
                caePage.setBaseUri("http://www.afip.gov.ar/genericos/consultacae/");
                caePage.setErrorQuery("#Respuesta_div ul li");
                caePage.setValidityQuery(".respuesta_titulo b");
                caePage.setSuccessResponseString("Autorizado");
                caePage.setFailureResponseString("NO Autorizado");
                return caePage;
            }
        };

        caeRequestValid = makeValidCaeRequest();
        caeRequestInvalid = makeInvalidCaeRequest();

        Collection<String> caeErrorsValid = Collections.emptyList();

        Collection<String> caeErrorsInvalid = mock(Collection.class);
        when(caeErrorsInvalid.isEmpty()).thenReturn(false);

        AfipResponse caeResponseValid = mock(AfipResponse.class);
        when(caeResponseValid.isValid()).thenReturn(true);
        when(caeResponseValid.getErrors()).thenReturn(caeErrorsValid);

        AfipResponse caeResponseInvalid = mock(AfipResponse.class);
        when(caeResponseInvalid.isValid()).thenReturn(false);
        when(caeResponseInvalid.getErrors()).thenReturn(caeErrorsInvalid);

        RestTemplate restTemplate = mock(RestTemplate.class);

        caeService.setRestTemplate(restTemplate);

        Map<SapDocumentType, String> sapDocumentTypeMap = Maps.newHashMap();

        SapDocumentType billA = new SapDocumentType("DQ", "A");
        SapDocumentType creditNoteA = new SapDocumentType("DR", "A");
        SapDocumentType debitNoteA = new SapDocumentType("DG", "A");

        sapDocumentTypeMap.put(billA, "1");
        sapDocumentTypeMap.put(creditNoteA, "2");
        sapDocumentTypeMap.put(debitNoteA, "3");

        caeService.setSapDocumentTypeMap(sapDocumentTypeMap);

        caeService.setUrl("www.internet.domain.com");
        Map<String, String> urlParams = mock(Map.class);
        caeService.setUrlParams(urlParams);

        when(restTemplate.postForObject(caeService.getUrl(), null, String.class, caeService.getUrlParams())).thenReturn(readContent("CaeValidDocument.html"));
        when(restTemplate.postForObject(eq(caeService.getUrl()), argThat(new IsValid()), eq(String.class), eq(caeService.getUrlParams()))).thenReturn(readContent("CaeValidDocument.html"));
        when(restTemplate.postForObject(eq(caeService.getUrl()), argThat(new IsNotValid()), eq(String.class), eq(caeService.getUrlParams()))).thenReturn(readContent("CaeInvalidDocument.html"));


    }

    @Test
    public void validateCaeTest_isValid() {
        AfipResponse response = caeService.validate(caeRequestValid);
        assertTrue(response.isValid());
        assertTrue(response.getErrors().isEmpty());
    }

    @Test
    public void validateCaeTest_isNotValid() {
        AfipResponse caeResponse = caeService.validate(caeRequestInvalid);
        assertFalse(caeResponse.isValid());
        assertFalse(caeResponse.getErrors().isEmpty());
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaeTest_missingCuit() {
        caeRequestValid.setCuit(null);
        caeService.validate(caeRequestValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaeTest_missingCae() {
        caeRequestValid.setCode(null);
        caeService.validate(caeRequestValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaeTest_missingCreationDate() {
        caeRequestValid.setCreationDate(null);
        caeService.validate(caeRequestValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaeTest_missingSupportingDocumentType() {
        caeRequestValid.setSupportingDocumentType(null);
        caeService.validate(caeRequestValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaeTest_missingSalesPointNumber() {
        caeRequestValid.setSalesPointNumber(null);
        caeService.validate(caeRequestValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaeTest_missingSupportingDocumentNumber() {
        caeRequestValid.setSupportingDocumentNumber(null);
        caeService.validate(caeRequestValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaeTest_missingAmount() {
        caeRequestValid.setAmount(null);
        caeService.validate(caeRequestValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaeTest_missingReceiverIdentificationNumber() {
        caeRequestValid.setReceiverIdentificationNumber(null);
        caeService.validate(caeRequestValid);
    }

    @Test
    public void validateCaeTest_unknownDocumentType() {
        // Given
        caeRequestValid.setSupportingDocumentType("Ñ");

        try {
            // When
            caeService.validate(caeRequestValid);
            fail();
        } catch (IllegalArgumentException e) {
            //Then
            assertEquals(CaeService.ERROR_UNKNOWN_DOCUMENT_CLASS_OR_TYPE, e.getMessage());
        }
    }

    @Test
    public void validateCaeTest_unknownDocumentClass() {
        // Given
        caeRequestValid.setSupportingDocumentClass("EAPP5");

        try {
            // When
            caeService.validate(caeRequestValid);
            fail();
        } catch (IllegalArgumentException e) {
            // Then
            assertEquals(CaeService.ERROR_UNKNOWN_DOCUMENT_CLASS_OR_TYPE, e.getMessage());
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaeTest_noRequest() {
        caeService.validate(null);
    }

    private Document makeValidCaeRequest() {
        Document request = new Document();
        request.setAmount(BigDecimal.valueOf(165180, 2));
        request.setCode("111111");
        request.setCreationDate(new Date());
        request.setCuit(VALID_TEST_CUIT);
        request.setReceiverIdentificationNumber("111111111");
        request.setSalesPointNumber("asdsadasdasd123");
        request.setSupportingDocumentNumber("s1addsa5as516");
        request.setSupportingDocumentType("A");
        request.setSupportingDocumentClass("DQ");
        return request;
    }

    private Document makeInvalidCaeRequest() {
        Document request = makeValidCaeRequest();
        request.setCuit("InvalidCuit");
        return request;
    }

    private String readContent(String resourceName) {
        try {
            URL resource = getClass().getResource(resourceName);

            Charset charset = Charset.forName("iso-8859-1");
            return copyToString(new InputStreamReader(resource.openConnection().getInputStream(), charset));
        } catch (IOException e) {
            throw new RuntimeException("Cannot find resource " + resourceName, e);
        }
    }

    private class IsValid extends ArgumentMatcher<MultiValueMap<String, String>> {
        @Override
        public boolean matches(Object argument) {
            if (argument instanceof MultiValueMap) {
                MultiValueMap<String, String> multiValueMap = (MultiValueMap<String, String>) argument;

                return allArgumentsAreSet(multiValueMap) && multiValueMap.get("p_CUIT").get(0).equals(VALID_TEST_CUIT);
            }

            return false;
        }
    }

    private class IsNotValid extends ArgumentMatcher<MultiValueMap<String, String>> {
        @Override
        public boolean matches(Object argument) {
            if (argument instanceof MultiValueMap) {
                MultiValueMap<String, String> multiValueMap = (MultiValueMap<String, String>) argument;

                return allArgumentsAreSet(multiValueMap) && !multiValueMap.get("p_CUIT").get(0).equals(VALID_TEST_CUIT);
            }

            return false;
        }
    }

    private boolean allArgumentsAreSet(MultiValueMap<String, String> multiValueMap) {
        return multiValueMap.get("__EVENTVALIDATION") != null && !multiValueMap.get("__EVENTVALIDATION").isEmpty()
                && multiValueMap.get("__VIEWSTATE") != null && !multiValueMap.get("__VIEWSTATE").isEmpty()
                && multiValueMap.get("Button") != null && !multiValueMap.get("Button").isEmpty()
                && multiValueMap.get("p_CAE") != null && !multiValueMap.get("p_CAE").isEmpty()
                && multiValueMap.get("p_CUIT") != null && !multiValueMap.get("p_CUIT").isEmpty()
                && multiValueMap.get("p_fch_emision_day") != null && !multiValueMap.get("p_fch_emision_day").isEmpty()
                && multiValueMap.get("p_fch_emision_month") != null && !multiValueMap.get("p_fch_emision_month").isEmpty()
                && multiValueMap.get("p_fch_emision_year") != null && !multiValueMap.get("p_fch_emision_year").isEmpty()
                && multiValueMap.get("p_importe") != null && !multiValueMap.get("p_importe").isEmpty()
                && multiValueMap.get("p_nro_cbte") != null && !multiValueMap.get("p_nro_cbte").isEmpty()
                && multiValueMap.get("p_nro_doc") != null && !multiValueMap.get("p_nro_doc").isEmpty()
                && multiValueMap.get("p_pto_vta") != null && !multiValueMap.get("p_pto_vta").isEmpty()
                && multiValueMap.get("p_tipo_cbte") != null && !multiValueMap.get("p_tipo_cbte").isEmpty()
                && multiValueMap.get("p_tipo_doc") != null && !multiValueMap.get("p_tipo_doc").isEmpty();
    }

}
