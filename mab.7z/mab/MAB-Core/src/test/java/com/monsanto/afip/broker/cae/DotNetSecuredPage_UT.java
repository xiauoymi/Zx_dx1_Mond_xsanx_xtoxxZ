package com.monsanto.afip.broker.cae;

import com.monsanto.afip.broker.exceptions.UnexpectedPageFormatException;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;

import static org.junit.Assert.assertNotNull;
import static org.springframework.util.FileCopyUtils.copyToString;

/**
 * @author PPERA
 */
public class DotNetSecuredPage_UT {
    private DotNetSecuredPage dotNetSecuredPage;

    @Before
    public void setUp() {
        dotNetSecuredPage = new DotNetSecuredPage();
        dotNetSecuredPage.setBaseUri("http://www.afip.gov.ar/genericos/consultacae/");

    }

    @Test
    public void testGetResponse_Success() {
        dotNetSecuredPage.setContent(readContent("CaeValidDocument.html"));
        DotNetSecuredResponse response = dotNetSecuredPage.getResponse();

        assertNotNull(response);
        assertNotNull(response.getViewState());
        assertNotNull(response.getEventValidation());
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_CannotFindViewState() {
        dotNetSecuredPage.setContent(readContent("CaeValidDocumentNoViewState.html"));
        DotNetSecuredResponse response = dotNetSecuredPage.getResponse();

        assertNotNull(response);
        assertNotNull(response.getViewState());
        assertNotNull(response.getEventValidation());
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_CannotFindEventValidation() {
        dotNetSecuredPage.setContent(readContent("CaeValidDocumentNoEventValidation.html"));
        DotNetSecuredResponse response = dotNetSecuredPage.getResponse();

        assertNotNull(response);
        assertNotNull(response.getViewState());
        assertNotNull(response.getEventValidation());
    }

    private String readContent(String resourceName) {
        try {
            URL resource = getClass().getResource(resourceName);

            Charset charset = Charset.forName("iso-8859-1");
            return copyToString(new InputStreamReader(resource.openConnection().getInputStream(), charset));
        } catch (IOException e) {
            throw new RuntimeException("Cannot find resource " + resourceName, e);
        }
    }
}
