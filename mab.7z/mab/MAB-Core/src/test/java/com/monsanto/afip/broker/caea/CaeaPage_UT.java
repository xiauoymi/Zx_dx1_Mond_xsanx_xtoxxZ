package com.monsanto.afip.broker.caea;

import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.exceptions.UnexpectedPageFormatException;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;

import static org.junit.Assert.*;
import static org.springframework.util.FileCopyUtils.copyToString;

/**
 * Test the CaeaPage
 *
 * @author PPERA
 */
public class CaeaPage_UT {
    private CaeaPage caeaPage;

    @Before
    public void setUp() {
        caeaPage = new CaeaPage();
        caeaPage.setBaseUri("http://www.afip.gov.ar/genericos/consultaCAEA/");
        caeaPage.setErrorQuery("#formCAEA");
        caeaPage.setValidityQuery("#formCAEA");
        caeaPage.setSuccessResponseString("Consulta CAEA LOS DATOS INGRESADOS (CUIT Y CAEA) COINCIDEN CON LOS QUE AFIP POSEE REGISTRADOS.");
    }


    @Test
    public void testGetResponse_ValidDocument() {
        caeaPage.setContent(readContent("CaeaValidDocument.html"));

        AfipResponse response = caeaPage.getResponse();

        assertNotNull(response);
        assertTrue(response.isValid());
        assertTrue(response.getErrors().isEmpty());
        assertNotNull(response.getDateTime());
    }


    private String readContent(String resourceName) {
        try {
            URL resource = getClass().getResource(resourceName);

            Charset charset = Charset.forName("iso-8859-1");
            return copyToString(new InputStreamReader(resource.openConnection().getInputStream(), charset));
        } catch (IOException e) {
            throw new RuntimeException("Cannot find resource " + resourceName, e);
        }
    }

    @Test
    public void testGetResponse_NotValidDocument() {
        caeaPage.setContent(readContent("CaeaNotValidDocument.html"));

        AfipResponse response = caeaPage.getResponse();

        assertNotNull(response);
        assertFalse(response.isValid());
        assertNotNull(response.getErrors());
        assertEquals(1, response.getErrors().size());
        assertTrue(response.getErrors().contains("Consulta CAEA DATOS INGRESADOS (CUIT Y CAEA) NO COINCIDEN CON LOS QUE AFIP POSEE REGISTRADOS."));

        assertNotNull(response.getDateTime());
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_MissingResponsePageContent() {
        caeaPage.setContent(readContent("CaeaMissingResponsePage.html"));

        caeaPage.getResponse();
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_ErrorsNotFoundPageContent() {
        caeaPage.setContent(readContent("CaeaErrorsNotFoundPage.html"));

        caeaPage.getResponse();
    }

}
