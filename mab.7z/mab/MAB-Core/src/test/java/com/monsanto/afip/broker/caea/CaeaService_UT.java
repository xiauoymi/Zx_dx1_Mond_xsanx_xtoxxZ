package com.monsanto.afip.broker.caea;

import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.domain.Document;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.argThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.util.FileCopyUtils.copyToString;

/**
 * @author PPERA
 */
public class CaeaService_UT {
    private static final String VALID_CUIT = "ValidCuit";
    private CaeaService caeaService;
    private Document caeaRequestValid;
    private Document caeaRequestInvalid;

    @Before
    public void setUp() {
        caeaService = new CaeaService() {
            @Override
            protected CaeaPage newPage() {
                CaeaPage caeaPage = new CaeaPage();
                caeaPage.setBaseUri("http://www.afip.gov.ar/genericos/consultaCAEA/");
                caeaPage.setErrorQuery("#formCAEA");
                caeaPage.setValidityQuery("#formCAEA");
                caeaPage.setSuccessResponseString("Consulta CAEA LOS DATOS INGRESADOS (CUIT Y CAEA) COINCIDEN CON LOS QUE AFIP POSEE REGISTRADOS.");
                return caeaPage;

            }
        };

        RestTemplate restTemplate = mock(RestTemplate.class);

        caeaService.setRestTemplate(restTemplate);

        caeaRequestValid = makeValidRequest();
        caeaRequestInvalid = makeInvalidRequest();

        AfipResponse caeaResponseValid = mock(AfipResponse.class);
        AfipResponse caeaResponseInvalid = mock(AfipResponse.class);

        when(caeaResponseValid.isValid()).thenReturn(true);
        when(caeaResponseInvalid.isValid()).thenReturn(false);

        when(restTemplate.postForObject(eq(caeaService.getUrl()), argThat(new IsValid()), eq(String.class), eq(caeaService.getUrlParams()))).thenReturn(readContent("CaeaValidDocument.html"));
        when(restTemplate.postForObject(eq(caeaService.getUrl()), argThat(new IsNotValid()), eq(String.class), eq(caeaService.getUrlParams()))).thenReturn(readContent("CaeaNotValidDocument.html"));

    }

    private Document makeInvalidRequest() {
        Document request = makeValidRequest();
        request.setCuit("Invalid cuit");
        return request;
    }

    private Document makeValidRequest() {
        Document request = new Document();
        request.setCuit(VALID_CUIT);
        request.setCode("ValidCaea");
        return request;
    }

    @Test
    public void validateCaea_isValid() {
        assertTrue(caeaService.validate(caeaRequestValid).isValid());
    }

    @Test
    public void validateCaea_isNotValid() {
        assertFalse(caeaService.validate(caeaRequestInvalid).isValid());
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaea_missingCuit() {
        caeaRequestValid.setCuit(null);
        caeaService.validate(caeaRequestValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaea_missingCaea() {
        caeaRequestValid.setCode(null);
        caeaService.validate(caeaRequestValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaea_noRequest() {
        caeaService.validate(null);
    }


    private class IsValid extends ArgumentMatcher<MultiValueMap<String, String>> {
        @Override
        public boolean matches(Object argument) {
            if (argument instanceof MultiValueMap) {
                MultiValueMap<String, String> multiValueMap = (MultiValueMap<String, String>) argument;

                return allArgumentsAreSet(multiValueMap) && multiValueMap.get("fcuit").get(0).equals(VALID_CUIT);
            }

            return false;
        }
    }

    private class IsNotValid extends ArgumentMatcher<MultiValueMap<String, String>> {
        @Override
        public boolean matches(Object argument) {
            if (argument instanceof MultiValueMap) {
                MultiValueMap<String, String> multiValueMap = (MultiValueMap<String, String>) argument;

                return allArgumentsAreSet(multiValueMap) && !multiValueMap.get("fcuit").get(0).equals(VALID_CUIT);
            }

            return false;
        }
    }

    private boolean allArgumentsAreSet(MultiValueMap<String, String> multiValueMap) {

        return multiValueMap.get("fcuit") != null && !multiValueMap.get("fcuit").isEmpty()
                && multiValueMap.get("fcaea") != null && !multiValueMap.get("fcaea").isEmpty()
                && multiValueMap.get("prmCAEA") != null && !multiValueMap.get("prmCAEA").isEmpty();
    }

    private String readContent(String resourceName) {
        try {
            URL resource = getClass().getResource(resourceName);

            Charset charset = Charset.forName("iso-8859-1");
            return copyToString(new InputStreamReader(resource.openConnection().getInputStream(), charset));
        } catch (IOException e) {
            throw new RuntimeException("Cannot find resource " + resourceName, e);
        }
    }

}