package com.monsanto.afip.broker.cai;

import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.exceptions.UnexpectedPageFormatException;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;

import static org.junit.Assert.*;
import static org.springframework.util.FileCopyUtils.copyToString;

/**
 * Tests the CaiPage
 *
 * @author PPERA
 */
public class CaiPage_UT {
    private static final String VALID_VALUE_QUERY = "table tr td font b:containsOwn(coinciden)";
    private static final String ERROR_VALUE_QUERY = "ul p";
    private AfipResponse caiResponse;
    private CaiPage caiPage;


    @Before
    public void setUp() {
        caiPage = new CaiPage();
        caiPage.setBaseUri("http://www.afip.gob.ar/genericos/imprentas/facturas.asp");
        caiPage.setValidityQuery(VALID_VALUE_QUERY);
        caiPage.setErrorQuery(ERROR_VALUE_QUERY);
        caiPage.setSuccessResponseString("Los datos ingresados coinciden con una autorizaci&oacute;n otorgada por la AFIP que se encuentra vigente.");
    }

    @Test
    public void testGetResponse_ValidDocument() {
        caiPage.setContent(readContent("CaiValidDocument.html"));
        caiResponse = caiPage.getResponse();
        assertTrue(caiResponse.isValid());
        assertTrue(caiResponse.getErrors().isEmpty());
        assertNotNull(caiResponse.getDateTime());
    }

    @Test
    public void testGetResponse_NotValiddDocument() {
        caiPage.setContent(readContent("CaiNotValidDocument.html"));
        caiResponse = caiPage.getResponse();
        assertFalse(caiResponse.isValid());
        assertFalse(caiResponse.getErrors().isEmpty());
        assertNotNull(caiResponse.getDateTime());
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_MissingResponsePageContent() {
        caiPage.setContent(readContent("CaiMissingResponsePage.html"));
        caiResponse = caiPage.getResponse();
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_MissingErrors() {
        caiPage.setContent(readContent("CaiMissingErrorsPage.html"));
        caiResponse = caiPage.getResponse();
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_MissingDate() {
        caiPage.setContent(readContent("CaiMissingDatePage.html"));
        caiResponse = caiPage.getResponse();
    }

    @Test(expected = UnexpectedPageFormatException.class)
    public void testGetResponse_InvalidDate() {
        caiPage.setContent(readContent("CaiInvalidDatePage.html"));
        caiResponse = caiPage.getResponse();
    }

    private String readContent(String resourceName) {
        try {
            URL resource = getClass().getResource(resourceName);

            Charset charset = Charset.forName("iso-8859-1");
            return copyToString(new InputStreamReader(resource.openConnection().getInputStream(), charset));
        } catch (IOException e) {
            throw new RuntimeException("Cannot find resource " + resourceName, e);
        }
    }
}
