package com.monsanto.afip.broker.cai;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.monsanto.afip.broker.cae.CaeService;
import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.domain.Document;
import com.monsanto.afip.broker.domain.SapDocumentType;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Matchers.argThat;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.util.FileCopyUtils.copyToString;

/**
 * @author PPERA
 */
public class CaiService_UT {
    private static final String VALID_VALUE_QUERY = "table tr td font b:containsOwn(coinciden)";
    private static final String ERROR_VALUE_QUERY = "ul p";
    private static final String VALID_CODE = "321654987";

    private CaiService caiService;
    private Document documentValid;
    private Document documentInvalid;


    @Before
    public void setUp() throws Exception {

        caiService = new CaiService() {
            @Override
            protected CaiPage newPage() {
                CaiPage caiPage = new CaiPage();
                caiPage.setBaseUri("http://www.afip.gob.ar/genericos/imprentas/facturas.asp");
                caiPage.setValidityQuery(VALID_VALUE_QUERY);
                caiPage.setErrorQuery(ERROR_VALUE_QUERY);
                caiPage.setSuccessResponseString("Los datos ingresados coinciden con una autorizaci&oacute;n otorgada por la AFIP que se encuentra vigente.");
                return caiPage;
            }
        };

        RestTemplate restTemplate = mock(RestTemplate.class);

        documentValid = makeValidRequest();
        documentInvalid = makeInvalidRequest();

        caiService.setRestTemplate(restTemplate);


        Map<SapDocumentType, String> sapDocumentTypeMap = Maps.newHashMap();

        SapDocumentType billA = new SapDocumentType("DQ", "A");
        SapDocumentType creditNoteA = new SapDocumentType("DR", "A");
        SapDocumentType debitNoteA = new SapDocumentType("DG", "A");

        sapDocumentTypeMap.put(billA, "1");
        sapDocumentTypeMap.put(creditNoteA, "2");
        sapDocumentTypeMap.put(debitNoteA, "3");

        caiService.setSapDocumentTypeMap(sapDocumentTypeMap);

        AfipResponse caiResponseValid = mock(AfipResponse.class);
        AfipResponse caiResponseInvalid = mock(AfipResponse.class);

        when(caiResponseValid.isValid()).thenReturn(true);
        when(caiResponseInvalid.isValid()).thenReturn(false);

        when(caiResponseValid.getErrors()).thenReturn(Collections.<String>emptyList());
        when(caiResponseInvalid.getErrors()).thenReturn(Lists.newArrayList("Error 001"));

        when(restTemplate.postForObject(eq(caiService.getUrl()), argThat(new IsValid()), eq(String.class), eq(caiService.getUrlParams()))).thenReturn(readContent("CaiValidDocument.html"));
        when(restTemplate.postForObject(eq(caiService.getUrl()), argThat(new IsNotValid()), eq(String.class), eq(caiService.getUrlParams()))).thenReturn(readContent("CaiNotValidDocument.html"));

    }

    @Test
    public void validateCaiTest_SupportingDocumentIsValid() {
        AfipResponse caiResponse = caiService.validate(documentValid);
        assertTrue(caiResponse.isValid());
        assertTrue(caiResponse.getErrors().isEmpty());
    }

    @Test
    public void validateCaiTest_SupportingDocumentIsNotValid() {
        AfipResponse caiResponse = caiService.validate(documentInvalid);
        assertFalse(caiResponse.isValid());
        assertFalse(caiResponse.getErrors().isEmpty());
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaiTest_missingCUIT() {
        documentValid.setCuit(null);
        caiService.validate(documentValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaiTest_missingCAI() {
        documentValid.setCode(null);
        caiService.validate(documentValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaiTest_missingDate() {
        documentValid.setCreationDate(null);
        caiService.validate(documentValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaiTest_missingSupportingDocumentType() {
        documentValid.setSupportingDocumentType(null);
        caiService.validate(documentValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaiTest_missingSalesPointNumber() {
        documentValid.setSalesPointNumber(null);
        caiService.validate(documentValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaiTest_missingSupportingDocumentNumber() {
        documentValid.setSalesPointNumber(null);
        caiService.validate(documentValid);
    }

    @Test(expected = IllegalArgumentException.class)
    public void validateCaiTest_noRequest() {
        caiService.validate(null);
    }

    @Test
    public void validateCaeTest_unknownDocumentType() {
        // Given
        documentValid.setSupportingDocumentType("Ñ");

        try {
            // When
            caiService.validate(documentValid);
            fail();
        } catch (IllegalArgumentException e) {
            //Then
            assertEquals(CaeService.ERROR_UNKNOWN_DOCUMENT_CLASS_OR_TYPE, e.getMessage());
        }
    }

    @Test
    public void validateCaeTest_unknownDocumentClass() {
        // Given
        documentValid.setSupportingDocumentClass("EAPP5");

        try {
            // When
            caiService.validate(documentValid);
            fail();
        } catch (IllegalArgumentException e) {
            // Then
            assertEquals(CaeService.ERROR_UNKNOWN_DOCUMENT_CLASS_OR_TYPE, e.getMessage());
        }
    }

    private Document makeValidRequest() {
        Document caeRequest = new Document();
        caeRequest.setSalesPointNumber("00000000");
        caeRequest.setCreationDate(new Date());
        caeRequest.setCode(VALID_CODE);
        caeRequest.setCuit("321619084163");
        caeRequest.setSupportingDocumentNumber("231619684");
        caeRequest.setSupportingDocumentType("A");
        caeRequest.setSupportingDocumentClass("DQ");
        return caeRequest;
    }

    private Document makeInvalidRequest() {
        Document document = makeValidRequest();
        document.setCode("invalidCai");
        return document;
    }

    private class IsValid extends ArgumentMatcher<MultiValueMap<String, String>> {
        @Override
        public boolean matches(Object argument) {
            if (argument instanceof MultiValueMap) {
                MultiValueMap<String, String> multiValueMap = (MultiValueMap<String, String>) argument;

                return allArgumentsAreSet(multiValueMap) && multiValueMap.get("fcai").get(0).equals(VALID_CODE);
            }

            return false;
        }
    }

    private class IsNotValid extends ArgumentMatcher<MultiValueMap<String, String>> {
        @Override
        public boolean matches(Object argument) {
            if (argument instanceof MultiValueMap) {
                MultiValueMap<String, String> multiValueMap = (MultiValueMap<String, String>) argument;

                return allArgumentsAreSet(multiValueMap) && !multiValueMap.get("fcai").get(0).equals(VALID_CODE);
            }

            return false;
        }
    }

    private boolean allArgumentsAreSet(MultiValueMap<String, String> multiValueMap) {
        return multiValueMap.get("fcai") != null && !multiValueMap.get("fcai").isEmpty()
                && multiValueMap.get("fcuit") != null && !multiValueMap.get("fcuit").isEmpty()
                && multiValueMap.get("fdia") != null && !multiValueMap.get("fdia").isEmpty()
                && multiValueMap.get("fmes") != null && !multiValueMap.get("fmes").isEmpty()
                && multiValueMap.get("fanio") != null && !multiValueMap.get("fanio").isEmpty()
                && multiValueMap.get("fnumero") != null && !multiValueMap.get("fnumero").isEmpty()
                && multiValueMap.get("fpvta") != null && !multiValueMap.get("fpvta").isEmpty()
                && multiValueMap.get("fnro_comprob") != null && !multiValueMap.get("fnro_comprob").isEmpty();
    }

    private String readContent(String resourceName) {
        try {
            URL resource = getClass().getResource(resourceName);

            Charset charset = Charset.forName("iso-8859-1");
            return copyToString(new InputStreamReader(resource.openConnection().getInputStream(), charset));
        } catch (IOException e) {
            throw new RuntimeException("Cannot find resource " + resourceName, e);
        }
    }


}
