package com.monsanto.afip.broker.ws;

import com.monsanto.afip.broker.AfipBroker;
import com.monsanto.afip.broker.ws.echo.EchoRequest;
import com.monsanto.afip.broker.ws.echo.EchoResponse;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ws.server.endpoint.annotation.*;

/**
 * Provides service to the validation requests.
 *
 * @author PPERA
 */

@Endpoint
public class AfipBrokerEndpoint {

    private static final Logger log = Logger.getLogger(AfipBrokerEndpoint.class);

    @Autowired
    private AfipBroker afipBroker;

    @Value("#{mab['project.version']}")
    public String version;

    public AfipBroker getAfipBroker() {
        return afipBroker;
    }

    public void setAfipBroker(AfipBroker afipBroker) {
        this.afipBroker = afipBroker;
    }

    @PayloadRoot(localPart = "validateRequest", namespace = "http://www.monsanto.com/afipbroker")
    @ResponsePayload
    public AfipResponses validate(@RequestPayload Documents validateRequest) {
        log.debug(validateRequest);

        AfipResponses afipResponses = new AfipResponses();
        afipResponses.afipResponse = this.getAfipBroker().validate(validateRequest.getDocument());

        log.debug(afipResponses);

        return afipResponses;
    }

    @PayloadRoot(localPart = "echoRequest", namespace = "http://www.monsanto.com/afipbroker")
    @ResponsePayload
    public EchoResponse version(@RequestPayload EchoRequest echo) {
        EchoResponse echoResponse = new EchoResponse();
        echoResponse.setMessage(version);
        return echoResponse;
    }
}
