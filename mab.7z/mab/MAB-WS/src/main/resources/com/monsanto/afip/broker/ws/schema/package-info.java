@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.monsanto.com/afipbroker", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.monsanto.afip.broker.ws.schema;
