package com.monsanto.afip.broker.ws;

import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.monsanto.afip.broker.AfipBroker;
import com.monsanto.afip.broker.AfipService;
import com.monsanto.afip.broker.cae.CaeService;
import com.monsanto.afip.broker.caea.CaeaService;
import com.monsanto.afip.broker.cai.CaiService;
import com.monsanto.afip.broker.domain.AfipResponse;
import com.monsanto.afip.broker.domain.Document;
import com.monsanto.afip.broker.ws.echo.EchoRequest;
import com.monsanto.afip.broker.ws.echo.EchoResponse;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;

import javax.annotation.Nullable;
import javax.xml.bind.JAXB;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;

import static org.junit.Assert.*;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.util.FileCopyUtils.copyToString;

/**
 * Tests for AfipBrokerEndpoint
 *
 * @author PPERA
 */
public class AfipBrokerEndpoint_UT {
    private AfipBrokerEndpoint afipBrokerEndpoint;
    private Documents documents;
    private CaiService caiService;
    private CaeService caeService;
    private CaeaService caeaService;
    private AfipResponse afipValidResponse;
    private AfipResponse afipInvalidResponse;

    @Before
    public void setUp() {
        AfipBroker afipBroker = new AfipBroker();
        caiService = mock(CaiService.class);
        caeService = mock(CaeService.class);
        caeaService = mock(CaeaService.class);

        afipValidResponse = new AfipResponse();
        afipValidResponse.setValid(true);
        afipValidResponse.setDateTime(new Date());
        afipValidResponse.setErrors(Collections.<String>emptyList());
        afipValidResponse.setStatus(200);
        afipValidResponse.setIdSap("1");
        afipValidResponse.setYearOfDocument(new Date());

        afipInvalidResponse = new AfipResponse();
        afipInvalidResponse.setValid(false);
        afipInvalidResponse.setDateTime(new Date());
        afipInvalidResponse.setErrors(Lists.newArrayList("Error 001", "Error 002", "Error 003", "Error 004", "Error 005"));
        afipInvalidResponse.setStatus(200);
        afipValidResponse.setIdSap("2");
        afipValidResponse.setYearOfDocument(new Date());

        ArrayList<AfipService> services = Lists.<AfipService>newArrayList(caiService, caeService, caeaService);
        afipBroker.setServices(services);
        afipBrokerEndpoint = new AfipBrokerEndpoint();
        afipBrokerEndpoint.setAfipBroker(afipBroker);

        when(caiService.validate(argThat(new IsIncomplete()))).thenThrow(new IllegalArgumentException());
        when(caeService.validate(argThat(new IsIncomplete()))).thenThrow(new IllegalArgumentException());
        when(caeaService.validate(argThat(new IsIncomplete()))).thenThrow(new IllegalArgumentException());
    }

    @Test
    public void testValidate_isValid() {
        when(caiService.validate(argThat(new IsComplete()))).thenReturn(afipValidResponse);
        when(caeService.validate(argThat(new IsComplete()))).thenReturn(afipInvalidResponse);
        when(caeaService.validate(argThat(new IsComplete()))).thenReturn(afipInvalidResponse);

        documents = this.makeCompleteDocuments();

        assertEquals(4, documents.getDocument().size());

        AfipResponses responses = afipBrokerEndpoint.validate(documents);

        Collection<AfipResponse> validResponses = filterValidResponses(responses.getAfipResponse());
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(responses.getAfipResponse());
        Collection<AfipResponse> status290Responses = filterStatus290(responses.getAfipResponse());

        assertEquals(0, invalidResponses.size());
        assertEquals(0, status290Responses.size());
        assertEquals(4, validResponses.size());
        assertTrue(invalidResponses.containsAll(status290Responses));
        assertEquals(documents.getDocument().size(), responses.getAfipResponse().size());

        assertResponsesAreComplete(responses);
    }

    private void assertResponsesAreComplete(AfipResponses responses) {
        for(AfipResponse response: responses.getAfipResponse()){
            assertThat(response, new ResponseIsComplete());
        }
    }

    @Test
    public void testValidate_isNotValid() {
        when(caiService.validate(argThat(new IsComplete()))).thenReturn(afipInvalidResponse);
        when(caeService.validate(argThat(new IsComplete()))).thenReturn(afipInvalidResponse);
        when(caeaService.validate(argThat(new IsComplete()))).thenReturn(afipInvalidResponse);

        documents = this.makeCompleteDocuments();

        assertEquals(4, documents.getDocument().size());

        AfipResponses responses = afipBrokerEndpoint.validate(documents);

        Collection<AfipResponse> validResponses = filterValidResponses(responses.getAfipResponse());
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(responses.getAfipResponse());
        Collection<AfipResponse> status290Responses = filterStatus290(responses.getAfipResponse());

        assertEquals(4, invalidResponses.size());
        assertEquals(0, status290Responses.size());
        assertEquals(0, validResponses.size());
        assertTrue(invalidResponses.containsAll(status290Responses));
        assertEquals(documents.getDocument().size(), responses.getAfipResponse().size());

         assertResponsesAreComplete(responses);
    }

    @Test
    public void testValidate_MissingData() {
        when(caiService.validate(argThat(new IsComplete()))).thenReturn(afipInvalidResponse);
        when(caeService.validate(argThat(new IsComplete()))).thenReturn(afipValidResponse);
        when(caeaService.validate(argThat(new IsComplete()))).thenReturn(afipInvalidResponse);

        documents = this.makeThreeIncompleteDocumentsAndOneComplete();

        assertEquals(4, documents.getDocument().size());

        AfipResponses responses = afipBrokerEndpoint.validate(documents);
        assertEquals(documents.getDocument().size(), responses.getAfipResponse().size());

        Collection<AfipResponse> validResponses = filterValidResponses(responses.getAfipResponse());
        Collection<AfipResponse> invalidResponses = filterInvalidResponses(responses.getAfipResponse());
        Collection<AfipResponse> status290Responses = filterStatus290(responses.getAfipResponse());

        assertEquals(3, invalidResponses.size());
        assertEquals(3, status290Responses.size());
        assertEquals(1, validResponses.size());
        assertTrue(invalidResponses.containsAll(status290Responses));

         assertResponsesAreComplete(responses);
    }

    @Test
    public void testEcho(){
        // @Given a request for echo
        EchoRequest echoRequest = new EchoRequest();
        this.afipBrokerEndpoint.version = "1000.2a";

        // @When the request is processed
        EchoResponse echoResponse = this.afipBrokerEndpoint.version(echoRequest);

        // @Then the version is returned
        assertNotNull(echoResponse.getMessage());
        assertEquals(echoResponse.getMessage(), this.afipBrokerEndpoint.version);
    }

    private Documents makeCompleteDocuments() {
        String inputXml = readContent("/exampleRequestThreeCompleteDocuments.xml");
        return JAXB.unmarshal(new StringReader(inputXml), Documents.class);
    }

    private Documents makeThreeIncompleteDocumentsAndOneComplete() {
        String inputXml = readContent("/exampleRequestThreeIncompleteDocumentsAndOneComplete.xml");
        return JAXB.unmarshal(new StringReader(inputXml), Documents.class);
    }

    private String readContent(String resourceName) {
        try {
            URL resource = getClass().getResource(resourceName);
            Charset charset = Charset.forName("iso-8859-1");
            return copyToString(new InputStreamReader(resource.openConnection().getInputStream(), charset));
        } catch (IOException e) {
            throw new RuntimeException("Cannot find resource " + resourceName, e);
        }
    }

    private class IsIncomplete extends ArgumentMatcher<Document> {
        @Override
        public boolean matches(Object argument) {
            return argument instanceof Document && !AfipBrokerEndpoint_UT.allRequiredFieldsAreSet((Document) argument);
        }
    }

    private class IsComplete extends ArgumentMatcher<Document> {
        @Override
        public boolean matches(Object argument) {
            return argument instanceof Document && AfipBrokerEndpoint_UT.allRequiredFieldsAreSet((Document) argument);
        }
    }

    private class ResponseIsComplete extends ArgumentMatcher<AfipResponse> {
        @Override
        public boolean matches(Object argument) {
            return argument instanceof AfipResponse && AfipBrokerEndpoint_UT.allRequiredFieldsAreSet((AfipResponse) argument);
        }
    }

    private static boolean allRequiredFieldsAreSet(AfipResponse argument) {
        return argument.getStatus() >= 200 &&
                argument.getDateTime() != null &&
                argument.getIdSap() != null &&
                argument.getYearOfDocument() != null &&
                (argument.isValid() || !argument.isValid() && argument.getErrors() != null);
    }

    private static boolean allRequiredFieldsAreSet(Document argument) {
        return argument.getAmount() != null &&
                argument.getCode() != null &&
                argument.getCreationDate() != null &&
                argument.getCuit() != null &&
                argument.getReceiverIdentificationNumber() != null &&
                argument.getSupportingDocumentClass() != null &&
                argument.getSalesPointNumber() != null &&
                argument.getSupportingDocumentNumber() != null &&
                argument.getSupportingDocumentType() != null &&
                argument.getIdSap() != null &&
                argument.getYearOfDocument() != null;
    }

    private Collection<AfipResponse> filterValidResponses(Collection<AfipResponse> afipResponses) {
        return Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && input.isValid();
            }
        });
    }

    private Collection<AfipResponse> filterInvalidResponses(Collection<AfipResponse> afipResponses) {
        return Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && !input.isValid();
            }
        });
    }

    private Collection<AfipResponse> filterStatus290(Collection<AfipResponse> afipResponses) {
        return Collections2.filter(afipResponses, new Predicate<AfipResponse>() {
            public boolean apply(@Nullable AfipResponse input) {
                return input != null && input.getStatus() == AfipBroker.INCOMPLETE_DATA_STATUS;
            }
        });
    }
}
