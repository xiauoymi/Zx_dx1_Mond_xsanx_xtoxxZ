package com.monsanto.enterprise.marketingnvp.model;


import com.monsanto.Util.StringUtils;

import java.util.*;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Jan 28, 2011
 * Time: 4:13:11 PM
 * To change this template use File | Settings | File Templates.
 */
public class ProductProfile {

    private HashMap<String, String> sharePointData = new HashMap<String, String>();
    private String country = DEFAULT_COUNTRY;
    public static final String DEFAULT_COUNTRY = "Monsanto Holland B.V.";
    public static final String HTTP_PROTOCOL_ID = "http://";
    public static final String FORMATTING_STRING = ";#";

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public HashMap<String, String> getSharePointData() {
        return sharePointData;
    }

    public void setSharePointData(HashMap<String, String> sharePointData) {
        this.sharePointData = sharePointData;
    }

    public boolean isRegisteredOrPendingRegistration() {
        String pvpString = getStringValue(SharePointServiceConstants.OWS_PVP);
        if (!StringUtils.isNullOrEmpty(pvpString)) {

            if (pvpString.toLowerCase().indexOf("pending") != -1 || pvpString.toLowerCase().indexOf("registered") != -1) {
                return true;
            }
        }
        return false;
    }

    public String getStringValue(String key) {
        if (sharePointData != null && key != null) {
            return stripOffFormatting(sharePointData.get(key));
        }
        return null;
    }

    public String stripOffFormatting(String val) {
        if (!StringUtils.isNullOrEmpty(val)) {
            if (!val.startsWith(HTTP_PROTOCOL_ID)) {
                int formatStartIndex = val.indexOf(FORMATTING_STRING);
                if (formatStartIndex != -1) {
                    return val.substring(formatStartIndex + 2);
                }
            }
        }
        return val;
    }

    private void setStringValue(String element, String key) {

        if (sharePointData == null)
            sharePointData = new LinkedHashMap<String, String>();

        if (element != null && key != null) {
            sharePointData.put(key, element);
        }
    }

    private String id;


    public List<String> getFeatures() {
        return getPropertyList(SharePointServiceConstants.OWS_FEATURES, ";");
    }

    private List<String> getPropertyList(String key, String fieldSeparator) {
        String f = getStringValue(key);
        List<String> fs = new ArrayList<String>();
        if (f != null) {
            String[] strings = org.apache.commons.lang.StringUtils.split(getStringValue(key), fieldSeparator);
            if (strings != null) {
                for (String s : strings) {
                    fs.add(stripOffFormatting(s));
                }
            }
        }
        return fs;
    }

    private void setPropertyList(List<String> elements, String key, String fieldSeparator) {
        String s = "";

        if (elements != null) {
            for (String element : elements) {
                s += element + fieldSeparator;
            }
        }

        setStringValue(s, key);
    }


    public void setFeatures(List<String> features) {
        setPropertyList(features, SharePointServiceConstants.OWS_FEATURES, ";");
    }

    public List<String> getAdvantages() {
        return getPropertyList(SharePointServiceConstants.OWS_ADVANTAGES, ";");
    }

    public void setAdvantages(List<String> advantages) {
        setPropertyList(advantages, SharePointServiceConstants.OWS_ADVANTAGES, ";");
    }

    public List<String> getBenefits() {
        return getPropertyList(SharePointServiceConstants.OWS_BENEFITS, ";");
    }

    public void setBenefits(List<String> benefits) {
        setPropertyList(benefits, SharePointServiceConstants.OWS_BENEFITS, ";");
    }

    public List<String> getTipsListLeft() {
        List<String> stringList = new ArrayList<String>();
        if (sharePointData.containsKey(SharePointServiceConstants.OWS_ENVIRONMENT)) {
            stringList.add("Environment:");
        }
        if (sharePointData.containsKey(SharePointServiceConstants.OWS_ENVIRONMENTALTIPS)) {
            stringList.add("Environment:");
        }
        if (sharePointData.containsKey(SharePointServiceConstants.OWS_SEASON)) {
            stringList.add("Season:");
        }
        if (sharePointData.containsKey(SharePointServiceConstants.OWS_PLANT_RATE)) {
            stringList.add("Plant rate:");
        }
        if (sharePointData.containsKey(SharePointServiceConstants.OWS_GEOGRAPHICALADAPTION)) {
            stringList.add("Geographic adaptation:");
        }
        return stringList;
    }


    public List<String> getTipsListRight() {
        List<String> stringList = new ArrayList<String>();
        if (sharePointData.containsKey(SharePointServiceConstants.OWS_ENVIRONMENT)) {
            stringList.add(getStringValue(SharePointServiceConstants.OWS_ENVIRONMENT));
        }
        if (sharePointData.containsKey(SharePointServiceConstants.OWS_ENVIRONMENTALTIPS)) {
            stringList.add(getStringValue(SharePointServiceConstants.OWS_ENVIRONMENTALTIPS));
        }
        if (sharePointData.containsKey(SharePointServiceConstants.OWS_SEASON)) {
            stringList.add(getStringValue(SharePointServiceConstants.OWS_SEASON));
        }
        if (sharePointData.containsKey(SharePointServiceConstants.OWS_PLANT_RATE)) {
            stringList.add(getStringValue(SharePointServiceConstants.OWS_PLANT_RATE));
        }
        if (sharePointData.containsKey(SharePointServiceConstants.OWS_GEOGRAPHICALADAPTION)) {
            stringList.add(getStringValue(SharePointServiceConstants.OWS_GEOGRAPHICALADAPTION));
        }
        return stringList;
    }

    public String getHeadline() {
        return getStringValue(SharePointServiceConstants.OWS_TITLE);
    }

    public void setHeadline(String headline) {
        setStringValue(headline, SharePointServiceConstants.OWS_TITLE);
    }

    public String getCropImageURL() {
        return getStringValue(SharePointServiceConstants.OWS_NVPIMAGE1);
    }

    public void setCropImageURL(String cropImageURL) {
        setStringValue(cropImageURL, SharePointServiceConstants.OWS_NVPIMAGE1);
    }

    public String getWeight() {
        return getStringValue(SharePointServiceConstants.OWS_WEIGHT);
    }

    public void setWeight(String weight) {
        this.setStringValue(weight, SharePointServiceConstants.OWS_WEIGHT);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getBrand() {
        return getStringValue(SharePointServiceConstants.OWS_BRAND);
    }

    public void setBrand(String brand) {
        setStringValue(brand, SharePointServiceConstants.OWS_BRAND);
    }

    public String getCrop() {
        return getStringValue(SharePointServiceConstants.OWS_CROP);
    }

    public void setCrop(String crop) {
        setStringValue(crop, SharePointServiceConstants.OWS_CROP);
    }

    public String getMaterialClassification() {
        return getStringValue(SharePointServiceConstants.OWS_MCT);
    }

    public void setMaterialClassification(String materialClassification) {
        setStringValue(materialClassification, SharePointServiceConstants.OWS_MCT);
    }

    public String getSegment() {
        return getStringValue(SharePointServiceConstants.OWS_SEGMENT);
    }

    public void setSegment(String segment) {
        setStringValue(segment, SharePointServiceConstants.OWS_SEGMENT);
    }

    public String getVariety() {
        return getStringValue(SharePointServiceConstants.OWS_VARIETY);
    }

    public void setVariety(String variety) {
        setStringValue(variety, SharePointServiceConstants.OWS_VARIETY);
    }

    public String getDiseaseProfileHR() {
        return getStringValue(SharePointServiceConstants.OWS_HR);
    }

    public void setDiseaseProfileHR(String diseaseProfileHR) {
        setStringValue(diseaseProfileHR, SharePointServiceConstants.OWS_HR);
    }

    public String getDiseaseProfileIR() {
        return getStringValue(SharePointServiceConstants.OWS_IR);
    }

    public void setDiseaseProfileIR(String diseaseProfileIR) {
        setStringValue(diseaseProfileIR, SharePointServiceConstants.OWS_IR);
    }

    public void setCalendarImageURL(String image) {
        setStringValue(image, SharePointServiceConstants.OWS_CALENDARIMAGE);
    }

    public String getCalendarImageURL() {
        return getStringValue(SharePointServiceConstants.OWS_CALENDARIMAGE);
    }

    public void setComparisonImageURL(String image) {
        setStringValue(image, SharePointServiceConstants.OWS_NVPIMAGES);
    }

    public String getTDRFinalApprovalDate(){
        return getStringValue(SharePointServiceConstants.OWS_MODIFIED);
    }

    public String getTrialResultsChartURL(int index) {
        return getIndexedProp(index, SharePointServiceConstants.OWS_NVPTRIALRESULTS);
    }

    public void setComparisonTitleList(String title) {
        setStringValue(title, SharePointServiceConstants.OWS_NVPTRIALRESULTSHEADINGS);
    }

    public String getTrialResultsTitle(int index) {
        return getIndexedProp(index, SharePointServiceConstants.OWS_NVPTRIALRESULTSHEADING);
    }

    public String getCropImageURL(int index) {
        return getIndexedProp(index, SharePointServiceConstants.OWS_NVPIMAGE);
    }

    public void setComparisonDescriptionList(String desc) {
        setStringValue(desc, SharePointServiceConstants.OWS_NVPTRIALRESULTDESCRIPTIONS);
    }

    public String getComparisonDescription(int index) {
        return getIndexedProp(index, SharePointServiceConstants.OWS_NVPTRIALRESULTDESCRIPTIONS);
    }

    public void setComparisonNotesList(String notes) {
        setStringValue(notes, SharePointServiceConstants.OWS_NVPTRIALRESULTSNOTES);
    }

    public String getComparisonNotes(int index) {
        return getIndexedProp(index, SharePointServiceConstants.OWS_NVPTRIALRESULTSNOTES);
    }

    private String getIndexedProp(int index, String key) {
        return this.getStringValue(key + (index + 1));
    }



    @Override
    public String toString() {
        StringBuffer s = new StringBuffer();
        s.append("ProductProfile=\n{").append("\n");
        if (getSharePointData() != null) {
            Iterator<String> iterator = sharePointData.keySet().iterator();
            String key;
            while (iterator.hasNext()) {
                key = iterator.next();
                s.append(key).append("=").append(sharePointData.get(key)).append("\n");
            }
            s.append("}\n");
        }
        return s.toString();
    }

    public int getNumberValuesForProperty(String keyPrefix) {
        int number = 0;
        while (true) {
            if (!getSharePointData().containsKey(keyPrefix + (++number))) {
                break;
            }
        }
        return number - 1;
    }
}
