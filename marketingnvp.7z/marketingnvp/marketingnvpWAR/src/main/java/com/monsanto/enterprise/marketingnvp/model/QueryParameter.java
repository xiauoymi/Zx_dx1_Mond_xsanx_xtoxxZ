package com.monsanto.enterprise.marketingnvp.model;

import javax.xml.bind.annotation.*;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Jan 21, 2011
 * Time: 3:45:43 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "Where"
})
@XmlRootElement(name = "Query", namespace = "http://schemas.microsoft.com/sharepoint/soap/")
public class QueryParameter {
    @XmlElement    
    private String Where = "<Eq><FieldRef Name=\"ID\" /><Value Type=\"Counter\">6</Value></EQ>";

    public String getWhere() {
        return Where;
    }

    public void setWhere(String where) {
        Where = where;
    }
}
