package com.monsanto.enterprise.marketingnvp.model;

public class SharePointServiceConstants {

//    http://appsold.dev.monsanto.com/enterprise/EMEA/_vti_bin/lists.asmx
//    http://apps.test.monsanto.com/enterprise/EMEA/_vti_bin/lists.asmx
//    http://apps.monsanto.com/enterprise/EMEA/_vti_bin/lists.asmx
//

    public static final String OWS_ADVANTAGES = "ows_Advantages";
    public static final String OWS_ATTACHMENTS = "ows_Attachments";
    public static final String OWS_BENEFITS = "ows_Benefits";
    public static final String OWS_BRAND = "ows_Brand";
    public static final String OWS_CONTENTTYPE = "ows_ContentType";
    public static final String OWS_COUNTRY = "ows_Country";
    public static final String OWS_COMMERCIALTEXT = "ows_CommercialText";
    public static final String OWS_CREATED = "ows_Created";
    public static final String OWS_MODIFIED = "ows_Modified";
    public static final String OWS_CREATED_X0020_DATE = "ows_Created_x0020_Date";
    public static final String OWS_CROP = "ows_Crop";
    public static final String OWS_ENVIRONMENT = "ows_Environment";
    public static final String OWS_ENVIRONMENTALTIPS = "ows_EnvironmentalTips";
    public static final String OWS_FSOBJTYPE = "ows_FSObjType";
    public static final String OWS_FAMILY = "ows_Family";
    public static final String OWS_FEATURES = "ows_Features";
    public static final String OWS_FILELEAFREF = "ows_FileLeafRef";
    public static final String OWS_FILEREF = "ows_FileRef";
    public static final String OWS_GEOGRAPHICALADAPTION = "ows_GeographicalAdaption";
    public static final String OWS_HR = "ows_HR";
    public static final String OWS_IR = "ows_IR";
    public static final String OWS_ID = "ows_ID";
    public static final String OWS_LINKTITLE = "ows_LinkTitle";
    public static final String OWS_MCT = "ows_MCT";
    public static final String OWS_MARKET = "ows_Market";
    public static final String OWS_VALUE_PROPOSITION = "ows_ValueProposition";    
    public static final String OWS_NVPCALENDARHEADING1 = "ows_NVPCalendarHeading1";
    public static final String OWS_NVPIMAGE = "ows_NVPImage";
    public static final String OWS_NVPIMAGE1 = "ows_NVPImage1";
    public static final String OWS_NVPIMAGE2 = "ows_NVPImage2";
    public static final String OWS_NVPIMAGE3 = "ows_NVPImage3";
    public static final String OWS_NVPTRIALRESULTSHEADING = "ows_NVPTrialResultsHeading";
    public static final String OWS_NVPTRIALRESULTSHEADING1 = "ows_NVPTrialResultsHeading1";
    public static final String OWS_NVPTRIALRESULTSHEADING2 = "ows_NVPTrialResultsHeading2";
    public static final String OWS_NVPTRIALRESULTSHEADING3 = "ows_NVPTrialResultsHeading3";
    public static final String OWS_NVPTRIALRESULTSHEADING4 = "ows_NVPTrialResultsHeading4";

    public static final String OWS_NVPTRIALRESULTS = "ows_NVPTrialResults";
    public static final String OWS_NVPTRIALRESULTS1 = "ows_NVPTrialResults1";
    public static final String OWS_NVPTRIALRESULTS2 = "ows_NVPTrialResults2";
    public static final String OWS_NVPTRIALRESULTS3 = "ows_NVPTrialResults3";
    public static final String OWS_NVPTRIALRESULTS4 = "ows_NVPTrialResults4";

    public static final String OWS_PMC = "ows_PMC";
    public static final String OWS_PVP = "ows_PVP";
    public static final String OWS_HEADLINES = "ows_Headlines";
    public static final String OWS_PLANT_RATE = "ows_PlantRate";
    public static final String OWS_SPECIFIC_ADVICE = "ows_SpecificAdvice";
    public static final String OWS_PROFILEA = "ows_ProfileA";
    public static final String OWS_PROFILEAPPROVALSTATUS = "ows_ProfileApprovalStatus";
    public static final String OWS_SEASON = "ows_Season";
    public static final String OWS_SEGMENT = "ows_Segment";
    public static final String OWS_TITLE = "ows_Title";
    public static final String OWS_UNIQUEID = "ows_UniqueId";
    public static final String OWS_VARIETY = "ows_Variety";
    public static final String OWS_VARIETYSECONDARYNAME = "ows_VarietySecondaryName";
    public static final String OWS_WEIGHT = "ows_Weight";
    public static final String OWS_LENGTH = "ows_Lenght";
    public static final String OWS__LEVEL = "ows__Level";
    public static final String OWS__MODERATIONSTATUS = "ows__ModerationStatus";
    public static final String OWS_OWSHIDDENVERSION = "ows_owshiddenversion";
    public static final String OWS_StartDateSowing = "ows_StartDateSowing";
    public static final String OWS_EndDateSowing = "ows_EndDateSowing";
    public static final String OWS_StartDateTransplant = "ows_StartDateTransplant";
    public static final String OWS_EndDateTransplant = "ows_EndDateTransplant";
    public static final String OWS_StartDateHarvest = "ows_StartDateHarvest";
    public static final String OWS_EndDateHarvest = "ows_EndDateHarvest";
    public static final String OWS_CommercialPMC = "ows_CommercialPMC";
    public static final String OWS_CALENDARIMAGE = "ows_NVPCalendar1";
    public static final String OWS_NVPIMAGES = "ows_NVPImages";
    public static final String OWS_NVPTRIALRESULTSHEADINGS = "ows_NVPTrialResultsHeadings";
    public static final String OWS_NVPTRIALRESULTDESCRIPTIONS = "ows_NVPTrialResultsDescriptions";
    public static final String OWS_NVPTRIALRESULTSNOTES = "ows_NVPTrialResultsNOTES";
}