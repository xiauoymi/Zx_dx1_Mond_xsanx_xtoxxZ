package com.monsanto.enterprise.marketingnvp.properties;

import javax.xml.bind.annotation.*;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Feb 11, 2011
 * Time: 11:29:54 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlRootElement
public class FontStyle {

    @XmlElement
    public String type;
    @XmlElement
    public int size;
    @XmlElement
    public int style;
    @XmlElement
    public Integer r;
    @XmlElement
    public Integer g;
    @XmlElement
    public Integer b;

//    @XmlAttribute(required = false)
//    private boolean underline;
//
//    @XmlAttribute(required = false)
//    private boolean bold;
//
//    @XmlAttribute(required = false)
//    private boolean italic;
//
//
//    public boolean isUnderline() {
//        return underline;
//    }
//
//    public void setUnderline(boolean underline) {
//        this.underline = underline;
//    }
//
//    public boolean isBold() {
//        return bold;
//    }
//
//    public void setBold(boolean bold) {
//        this.bold = bold;
//    }
//
//    public boolean isItalic() {
//        return italic;
//    }
//
//    public void setItalic(boolean italic) {
//        this.italic = italic;
//    }

    public FontStyle clone() throws CloneNotSupportedException {
        FontStyle font = new FontStyle();
        font.type = type;
        font.size = size;
        font.style = style;
        font.r = r;
        font.g = g;
        font.b = b;
        return font;
    }


    @XmlTransient
    public int getFontStyleValue(){
        return 0;
    }

}
