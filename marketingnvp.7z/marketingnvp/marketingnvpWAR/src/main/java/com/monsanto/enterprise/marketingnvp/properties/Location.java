package com.monsanto.enterprise.marketingnvp.properties;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Jan 30, 2011
 * Time: 12:09:03 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlRootElement
public final class Location {

    @XmlElement
    public int x;
    @XmlElement
    public int y;

    public Location clone() throws CloneNotSupportedException {
        Location location = new Location();
        location.x = x;
        location.y = y;
        return location;
    }
}
