package com.monsanto.enterprise.marketingnvp.properties;

import javax.xml.bind.annotation.*;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Feb 17, 2011
 * Time: 7:05:52 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "fontStyle", "val"
})
@XmlRootElement
(       namespace = "www.marketingnvp.monsanto.com",
        name = "nvpcontent"
       )
public class NVPContent {
    @XmlAttribute(required = true)
    private String id;
    @XmlAttribute(required = true)
    private String type;
    @XmlAttribute(required = true)
    private int x;
    @XmlAttribute(required = true)
    private int y;
    @XmlAttribute(required = false)
    private int width;
    @XmlAttribute(required = false)
    private int height;

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    @XmlElement(required = true)
    private String val;

    @XmlElement(required = false)
    private FontStyle fontStyle;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public FontStyle getFontStyle() {
        return fontStyle;
    }

    public void setFontStyle(FontStyle fontStyle) {
        this.fontStyle = fontStyle;
    }

    @XmlTransient
    public Location getLocation(){
        Location loc = new Location();;
        loc.x = getX();
        loc.y = getY();
        return loc;
    }


    @XmlTransient
    public Rectangle getRectangle(){
        Rectangle r = new Rectangle();
        r.w = getWidth();
        r.h = getHeight();
        return r;
    }

    @XmlTransient
    public Width getWidthBoxed(){
        Width wi = new Width();
        wi.w = getWidth();
        return wi;
    }
}
