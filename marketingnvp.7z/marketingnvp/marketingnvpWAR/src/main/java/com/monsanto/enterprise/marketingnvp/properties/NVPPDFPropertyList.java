package com.monsanto.enterprise.marketingnvp.properties;

import javax.xml.bind.annotation.*;
import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Feb 17, 2011
 * Time: 7:24:43 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
        "contents"
})
@XmlRootElement
(       namespace = "www.marketingnvp.monsanto.com",
        name = "NVPPDFPropertyList"
       )
public class NVPPDFPropertyList {

    @XmlElement
    private List<NVPContent> contents;

    public List<NVPContent> getContents() {
        return contents;
    }

    public void setContents(List<NVPContent> contents) {
        this.contents = contents;
    }
}
