package com.monsanto.enterprise.marketingnvp.properties;

import org.apache.log4j.Logger;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Jan 30, 2011
 * Time: 12:08:10 PM
 * To change this template use File | Settings | File Templates.
 */
public class PDFHelper {
    private static final String RESOURCE_NAME_D = "/com/monsanto/enterprise/marketingnvp/templates/nvpPropertyList_deruiters.xml";
    private static final String RESOURCE_NAME_S = "/com/monsanto/enterprise/marketingnvp/templates/nvpPropertyList_seminis.xml";
    private static final String[] businesses = {"deruiter_seeds_", "seminis_"};
    public static final int BUSINESS_DERUITERS = 0;
    public static final int BUSINESS_SEMINIS = 1;
    private static ConcurrentHashMap<String, NVPContent> nvpContentProperties = new ConcurrentHashMap<String, NVPContent>(117);

    static Logger logger = Logger.getLogger(PDFHelper.class.getName());

    static {
        init(businesses[BUSINESS_DERUITERS], RESOURCE_NAME_D);
        init(businesses[BUSINESS_SEMINIS], RESOURCE_NAME_S);
    }

    protected static void init(String business, String fileName) {
        try {
            JAXBContext jc = JAXBContext.newInstance(NVPPDFPropertyList.class);
            Unmarshaller unmarshaller = jc.createUnmarshaller();
            NVPPDFPropertyList nvppdfPropertyList = (NVPPDFPropertyList) unmarshaller.unmarshal(PDFHelper.class.getResourceAsStream(fileName));
            for (NVPContent p : nvppdfPropertyList.getContents()) {
                nvpContentProperties.put(business+p.getId(), p);
            }
        }
        catch (Exception e) {
            logger.error(e);
            throw new RuntimeException(e.getMessage(), e);
        }
    }

    public static Location getLocation(int business, String name) {
        try {
            NVPContent c = nvpContentProperties.get(businesses[business]+name);
            return c==null?null:c.getLocation();
        }
        catch (Exception e) {
            logger.error(e);
            throw new RuntimeException("Location Tag '" + name + "' not found. Business: " + business);
        }
    }

    public static Rectangle getRectangle(int business, String name) {
        try {
            NVPContent c = nvpContentProperties.get(businesses[business]+name);
            return c==null?null:c.getRectangle();
        }
        catch (Exception e) {
            logger.error(e);
            throw new RuntimeException("Location Tag '" + name + "' not found. Business: " + business);
        }
    }

    public static Width getWidth(int business, String name) {
        try {
            NVPContent c = nvpContentProperties.get(businesses[business]+name);
            return c==null?null:c.getWidthBoxed();
        }
        catch (Exception e) {
            logger.error(e);
            throw new RuntimeException("Width Tag '" + name + "' not found. Business: " + business);
        }
    }

    public static FontStyle getFontStyle(int business, String name) {
        try {
            NVPContent c = nvpContentProperties.get(businesses[business]+name);
            return c==null?null:c.getFontStyle();
        }
        catch (Exception e) {
            logger.error(e);
            throw new RuntimeException("Font Tag '" + name + "' not found. Business: " + business);
        }
    }

   
    public static String getVal(int business, String name) {
        try {
            NVPContent c = nvpContentProperties.get(businesses[business]+name);
            return (c==null||c.getVal()==null)?null:c.getVal().trim();
        }
        catch (Exception e) {
            logger.error(e);
            throw new RuntimeException("Val Tag '" + name + "' not found. Business: " + business);
        }
    }
}
