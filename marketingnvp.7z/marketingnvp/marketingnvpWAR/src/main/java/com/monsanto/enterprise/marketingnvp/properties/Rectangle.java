package com.monsanto.enterprise.marketingnvp.properties;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Jan 30, 2011
 * Time: 12:09:29 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlRootElement
public final class Rectangle {

    @XmlElement
    public Integer h;
    @XmlElement
    public Integer w;

    @XmlElement(required = false)
    public int mh =250;

    @XmlElement(required = false)
    public int mw =200;


    public Rectangle clone() throws CloneNotSupportedException {
        Rectangle rectangle = new Rectangle();
        rectangle.h = h;
        rectangle.w = w;
        return rectangle;
    }
}
