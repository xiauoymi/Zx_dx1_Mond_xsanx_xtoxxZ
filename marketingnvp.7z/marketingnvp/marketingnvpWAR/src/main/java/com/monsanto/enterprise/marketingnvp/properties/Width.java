package com.monsanto.enterprise.marketingnvp.properties;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Jan 30, 2011
 * Time: 12:44:15 PM
 * To change this template use File | Settings | File Templates.
 */
@XmlRootElement
public final class Width {

    @XmlElement
    public int w;

    public Width clone() throws CloneNotSupportedException {
        Width width = new Width();
        width.w = w;
        return width;
    }
}
