package com.monsanto.enterprise.marketingnvp.service;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import com.monsanto.Util.databasepasswordencryption.EncryptorException;
import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 24, 2011
 * Time: 12:08:23 PM
 * To change this template use File | Settings | File Templates.
 */
public class AccountHelper {

    public static final String DEV_ACCOUNT_NAME = "NORTH_AMERICA\\NA1000APP-MKTNVP-DEV";
    public static final String PROD_ACCOUNT_NAME = "NORTH_AMERICA\\NA1000APP-MKTNVPPROD";
    Logger logger = Logger.getLogger(AccountHelper.class.getName());


    public String getAccountName(){
        return "prod".equalsIgnoreCase(System.getProperty("lsi.function"))?PROD_ACCOUNT_NAME:DEV_ACCOUNT_NAME;
    }

    public String getAccountPassword(){
        try {
            return EncryptionUtils.GetDecryptedStringFromExternalStorage("MONCRYPTJV", "marketingnvp", "CipherValue.hex", "Keyvalue.hex");
        } catch (EncryptorException e) {
            logger.fatal(e);
            throw new RuntimeException(e);
        }
    }

    
}
