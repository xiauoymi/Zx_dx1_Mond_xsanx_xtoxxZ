package com.monsanto.enterprise.marketingnvp.service;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Image;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Jan 27, 2011
 * Time: 12:35:25 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssetLoader {
    static Logger logger = Logger.getLogger(AssetLoader.class.getName());

    public Image getImage(String url){
        try {
            return Image.getInstance(new URL(url));
        } catch (BadElementException e) {
            logger.error(e);
        } catch (IOException e) {
            logger.error(e);
        }
        return null;
    }

     public void canLoadImage(String url){
        try {
            URL url1 = new URL(url);
            URLConnection urlConnection = url1.openConnection();
            urlConnection.connect();
            InputStream bodyAsStream = urlConnection.getInputStream();
            byte[] bytes = new byte[1024];
            int readCount =0;
            File f = File.createTempFile("image_1", ".jpg");
            FileOutputStream fo = new FileOutputStream(f);
            while((readCount=bodyAsStream.read(bytes))>0){
                fo.write(bytes, 0, readCount);
            }
            fo.close();
            bodyAsStream.close();
        } catch (IOException e) {
            logger.error(e);
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
