package com.monsanto.enterprise.marketingnvp.service;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.marketingnvp.model.ProductProfile;
import com.monsanto.enterprise.marketingnvp.model.SharePointServiceConstants;
import com.monsanto.enterprise.marketingnvp.properties.FontStyle;
import com.monsanto.enterprise.marketingnvp.properties.Location;
import com.monsanto.enterprise.marketingnvp.properties.PDFHelper;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 26, 2011
 * Time: 5:18:13 PM
 * To change this template use File | Settings | File Templates.
 */
public class BaseNVPBuilder {
    protected ProductProfile productProfile;
    protected int business;
    protected NVPImageResourceLoader NVPImageResourceLoader;
    protected static Logger log = Logger.getLogger(PDFBuilderSeminisImpl.class.getName());
    protected float currentHeight = STARTING_HEIGHT;
    protected float currentY = 830;
    public int MAXIMUM_HEIGHT_OF_PAGE = 842;
    public int MAXIMUM_PAGE_WIDTH = 480;
    public int NEW_PAGE_Y_VALUE = 800;
    public int SECTIONAL_SEPARATOR_HEIGHT = 20;
    protected int LIST_INDENTATION = 10;
    public static final int STARTING_HEIGHT = 178;
    public  final int MAXIMUM_TRIAL_RESULTS_CHART_HEIGHT = 250;
    public  final String TDR_APPROVAL_DATE_DISPLAY_FORMAT = "MMMMM, yyyy";
    public  final String SHARE_POINT_DATE_FORMAT = "yyyy-MM-dd hh:mm:ss";

    public BaseNVPBuilder(ProductProfile productProfile, int business) {
        this.productProfile = productProfile;
        this.NVPImageResourceLoader = new NVPImageResourceLoaderImpl();
        this.business = business;
    }

    public NVPImageResourceLoader getNVPImageResourceLoader() {
        return NVPImageResourceLoader;
    }

    public void setNVPImageResourceLoader(NVPImageResourceLoader NVPImageResourceLoader) {
        this.NVPImageResourceLoader = NVPImageResourceLoader;
    }

    protected Font getFont(String fontStyleName) {
        FontStyle style = PDFHelper.getFontStyle(business, fontStyleName);
        return FontFactory.getFont(style.type, style.size, style.style, new BaseColor(style.r, style.g, style.b));
    }

    protected void forcePageBreak(PdfContentByte contentByte) throws Exception {
        contentByte.getPdfDocument().newPage();
        addPageHeader(contentByte);
        addPageFooter(contentByte);
    }

    protected PdfPTable getTrailResultsTable(int resultNumber, float maximumTableHeight) throws Exception {

        PdfPTable table1 = null;
        String resultsChartURL = productProfile.getTrialResultsChartURL(resultNumber);
        String trialResultsTitle = productProfile.getTrialResultsTitle(resultNumber);
        PdfPCell titleCell;

        if (!StringUtils.isNullOrEmpty(trialResultsTitle) || !StringUtils.isNullOrEmpty(resultsChartURL)) {
            table1 = new PdfPTable(1);
            table1.setTotalWidth(new float[]{MAXIMUM_PAGE_WIDTH});
            table1.setLockedWidth(true);
            if (!StringUtils.isNullOrEmpty(trialResultsTitle)) {
                titleCell = new PdfPCell(new Phrase(trialResultsTitle));
                titleCell.setPaddingTop(10f);
                titleCell.setPaddingBottom(10f);
                titleCell.setBorder(Rectangle.NO_BORDER);
                titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
                titleCell.setVerticalAlignment(Element.ALIGN_LEFT);
                table1.addCell(titleCell);
            }

            if (!StringUtils.isNullOrEmpty(resultsChartURL)) {
                titleCell = new PdfPCell();
                titleCell.setPaddingTop(15f);
                titleCell.setBorder(Rectangle.NO_BORDER);
                titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
                titleCell.setVerticalAlignment(Element.ALIGN_LEFT);
                Image image = getNVPImageResourceLoader().getRemoteImage(resultsChartURL);
                float height = MAXIMUM_TRIAL_RESULTS_CHART_HEIGHT * image.getWidth() / image.getHeight();
                float v = Math.min(height, image.getHeight());
                titleCell.addElement(image);
                titleCell.setFixedHeight(v);
                table1.addCell(titleCell);
            }

        }
        return table1;
    }

    protected void writeContent(PdfPTable table, float x, float y, float offset, PdfContentByte content, boolean useGivenYValue) {
        currentHeight += table.getTotalHeight();
        table.writeSelectedRows(0, -1, x, useGivenYValue ? y + offset : currentY - SECTIONAL_SEPARATOR_HEIGHT, content);
        if (!useGivenYValue) currentY -= (table.getTotalHeight() + SECTIONAL_SEPARATOR_HEIGHT);
    }

    protected PdfPCell getTrialResultsHeaderCell() {
        FontStyle style1 = PDFHelper.getFontStyle(business, "bar 1 label");
        Font font1 = FontFactory.getFont(style1.type, style1.size, style1.style, BaseColor.WHITE);
        PdfPCell cell = new PdfPCell(new Phrase("Monsanto Vegetable Seeds Technical Department Trait Results", font1));
        cell.setBackgroundColor(getSectionalHeadersBackgroundColor());
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        return cell;
    }

    protected FontStyle getFontStyle(String fontStyleName) {
        return PDFHelper.getFontStyle(business, fontStyleName);
    }


    private PdfPTable getHeaderTable() throws Exception {

        PdfPTable pdfPTable = new PdfPTable(2);
        pdfPTable.setTotalWidth(new float[]{180, 300});
        pdfPTable.setLockedWidth(true);

        FontStyle darkGreenStyle = getFontStyle("header underline color");
        Font font = getFont("header label");
        Font dateFont = getFont("date");
        BaseColor darkGreenColor = new BaseColor(darkGreenStyle.r, darkGreenStyle.g, darkGreenStyle.b);


        PdfPTable logoTable = new PdfPTable(1);
        logoTable.setTotalWidth(300);
        logoTable.setLockedWidth(true);


        PdfPCell cell = new PdfPCell();
        cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setBorder(Rectangle.BOTTOM);
        cell.setBorderWidth(1f);
        cell.setBorderColor(darkGreenColor);
        cell.addElement(getBrandLogo());
        pdfPTable.addCell(cell);

        cell = new PdfPCell(new Phrase("New Variety Profile", font));
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.NO_BORDER);
        logoTable.addCell(cell);

        if (business==PDFHelper.BUSINESS_SEMINIS){
            cell = new PdfPCell(new Phrase(getDateSeminis(), dateFont));
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
            cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
            cell.setBorder(Rectangle.NO_BORDER);
            logoTable.addCell(cell);
        }

        cell = new PdfPCell();
        cell.setVerticalAlignment(Element.ALIGN_BOTTOM);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setBorder(Rectangle.BOTTOM);
        cell.setBorderWidth(1f);
        cell.setBorderColor(darkGreenColor);
        cell.addElement(logoTable);
        pdfPTable.addCell(cell);

        pdfPTable.completeRow();

        return pdfPTable;
    }


    protected boolean checkForPageBreak(PdfContentByte contentByte, PdfPTable table) throws Exception {
        if (currentHeight + table.getTotalHeight() > MAXIMUM_HEIGHT_OF_PAGE) {
            contentByte.getPdfDocument().newPage();
            addPageHeader(contentByte);
            addPageFooter(contentByte);
            return true;
        }
        return false;
    }

    protected void addPageFooter(PdfContentByte underContent) throws Exception {
        addCopyRightInformation(underContent);
        addDisclaimer(underContent);
    }

    public void addDisclaimer(PdfContentByte directContentUnder) throws Exception {

        FontStyle style = PDFHelper.getFontStyle(business, "disclaimer information");
        String text = PDFHelper.getVal(business, "disclaimer information");
        Font font = FontFactory.getFont(style.type, style.size, style.style, new BaseColor(style.r, style.g, style.b));

        PdfPCell cell = new PdfPCell();
        cell.setBorder(Rectangle.NO_BORDER);
        cell.addElement(new Phrase(text, font));
        PdfPTable table = new PdfPTable(2);
        table.setTotalWidth(new float[]{420, 80});
        table.setLockedWidth(true);
        table.addCell(cell);

        Image image = getMonsantoLogo();
        image.scaleAbsolute(80, 25);
        cell = new PdfPCell(image);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        cell.setPaddingBottom(5f);
        table.addCell(cell);
        table.completeRow();
        Location loc = PDFHelper.getLocation(business, "disclaimer information");

        writeContent(table, loc.x, loc.y, 0, directContentUnder, true);
    }

    protected String getBrandString(int business) {
        return business == 0 ? "deruiters" : "seminis";
    }

    void addPageHeader(PdfContentByte content) throws Exception {
        Location loc = PDFHelper.getLocation(business, "brand logo");
        PdfPTable pTable = getHeaderTable();
        writeContent(pTable, loc.x, loc.y, 0, content, true);
        currentHeight = STARTING_HEIGHT;
        currentY = NEW_PAGE_Y_VALUE;
    }

    private Image getBrandLogo() throws Exception {
        return NVPImageResourceLoader.getLocalImage("/com/monsanto/enterprise/marketingnvp/templates/" + getBrandString(business) + "/brand_logo.PNG");
    }

    private Image getMonsantoLogo() throws Exception {

        return NVPImageResourceLoader.getLocalImage("/com/monsanto/enterprise/marketingnvp/templates/monsanto_logo.PNG");

    }

    void addCopyRightInformation(PdfContentByte pdfContent) {
        Location location = PDFHelper.getLocation(business, "copyRight");
        FontStyle style = PDFHelper.getFontStyle(business, "copyRight");
        Font font = FontFactory.getFont(style.type, style.size, style.style, new BaseColor(style.r, style.g, style.b));
        Phrase phrase = new Phrase(PDFBuilder.COPYRIGHT_CODE + " " + productProfile.getCountry() + PDFHelper.getVal(business, "copyRight") + " " + getDateSeminis(), font);
        ColumnText.showTextAligned(pdfContent, Element.ALIGN_LEFT, phrase, location.x, location.y, 90);
    }

    protected PdfPTable getCropImageSection(float height1) throws Exception {

        PdfPTable table1 = null;

        PdfPCell cell;

        int trailResults = productProfile.getNumberValuesForProperty(SharePointServiceConstants.OWS_NVPIMAGE);

        if (trailResults > 0) {
            table1 = new PdfPTable(1);
            table1.setTotalWidth(new float[]{230});
            table1.setLockedWidth(true);
            for (int i = 0; i < trailResults; i++) {
                String cropImageURL = productProfile.getCropImageURL(i);
                if (!StringUtils.isNullOrEmpty(cropImageURL)) {
                    cell = new PdfPCell();
                    cell.setPaddingTop(5f);
                    Image image = getNVPImageResourceLoader().getRemoteImage(cropImageURL);
                    float v1 = Math.max(height1, MAXIMUM_TRIAL_RESULTS_CHART_HEIGHT) / trailResults;
                    float v = Math.min(v1, image.getHeight());
                    cell.setFixedHeight(v);
                    cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                    cell.setBorder(Rectangle.NO_BORDER);
                    cell.addElement(image);
                    table1.addCell(cell);
                }
            }
        }
        return table1;

    }

    protected PdfPTable getAgTable() throws Exception {

        FontStyle style = PDFHelper.getFontStyle(business, "ag table");
        Font agListFont = FontFactory.getFont(style.type, style.size, style.style, new BaseColor(style.r, style.g, style.b));
        java.util.List<String> itemsL = productProfile.getTipsListLeft();
        java.util.List<String> itemsR = productProfile.getTipsListRight();


        PdfPCell leftCell;
        PdfPTable table = new PdfPTable(2);
        table.setTotalWidth(new float[]{200, MAXIMUM_TRIAL_RESULTS_CHART_HEIGHT});

        for (int i = 0; i < itemsL.size(); i++) {
            leftCell = new PdfPCell();
            leftCell.addElement(new Chunk("\u2022   " + itemsL.get(i), agListFont));
            leftCell.setBorder(Rectangle.NO_BORDER);
            table.addCell(leftCell);

            leftCell = new PdfPCell(new Phrase(itemsR.get(i), agListFont));
            leftCell.setBorder(Rectangle.NO_BORDER);
            table.addCell(leftCell);
        }
        table.completeRow();

        return table;
    }

    protected PdfPTable getCalendar() throws Exception {

        FontStyle style = PDFHelper.getFontStyle(business, "Calendar Title");
        Font font = FontFactory.getFont(style.type, style.size, style.style, new BaseColor(style.r, style.g, style.b));

        PdfPTable table = new PdfPTable(1);
        table.setTotalWidth(new float[]{MAXIMUM_PAGE_WIDTH});
        table.setLockedWidth(true);

        PdfPCell leftCell = new PdfPCell();
        leftCell.setBorder(Rectangle.NO_BORDER);
        leftCell.setPaddingBottom(20f);
        leftCell.setPaddingLeft(10f);
        leftCell.addElement(new Phrase("\u2022   " + productProfile.getStringValue(SharePointServiceConstants.OWS_NVPCALENDARHEADING1), font));
        table.addCell(leftCell);

        leftCell = new PdfPCell();
        leftCell.setBorder(Rectangle.NO_BORDER);
        Image image = getNVPImageResourceLoader().getRemoteImage(productProfile.getCalendarImageURL());
        float height = MAXIMUM_TRIAL_RESULTS_CHART_HEIGHT * image.getWidth() / image.getHeight();
        float v = Math.min(height, image.getHeight());
        leftCell.addElement(image);
        leftCell.setFixedHeight(v);
        leftCell.setPaddingLeft(20f);
        table.addCell(leftCell);


        table.completeRow();
        return table;

    }

    protected boolean notEmpty(java.util.List<String> list) {
        return !(list == null || list.isEmpty());
    }

    protected Image getPVPImage() throws Exception {
        return NVPImageResourceLoader.getLocalImage("/com/monsanto/enterprise/marketingnvp/templates/" + getBrandString(business) + "/pvp.png");
    }

    protected void buildFeaturesSection(PdfContentByte contentByte) throws Exception {

        PdfPTable table1 = new PdfPTable(2);

        table1.setTotalWidth(new float[]{230, MAXIMUM_TRIAL_RESULTS_CHART_HEIGHT});
        table1.setLockedWidth(true);

        FontStyle style1 = PDFHelper.getFontStyle(business, "bar 1 label");
        Font font1 = FontFactory.getFont(style1.type, style1.size, style1.style, BaseColor.WHITE);
        PdfPCell cell = new PdfPCell(new Phrase("Features, Advantages, Benefits", font1));
        cell.setColspan(2);
        cell.setBackgroundColor(getSectionalHeadersBackgroundColor());
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        table1.addCell(cell);

        cell = new PdfPCell();
        cell.setPaddingTop(15f);
        cell.setBorder(Rectangle.NO_BORDER);
        PdfPTable pTable = createFeaturesList();
        cell.addElement(pTable);
        table1.addCell(cell);

        PdfPTable cropImageSection = getCropImageSection(pTable.getTotalHeight());
        cell = new PdfPCell();
        cell.setPaddingTop(15f);

        if (cropImageSection != null) {
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBorder(Rectangle.NO_BORDER);
            cell.addElement(cropImageSection);
            table1.addCell(cell);
        } else {
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setBorder(Rectangle.NO_BORDER);
            cell.addElement(new Phrase(""));
            table1.addCell(cell);
        }
        Location loc = PDFHelper.getLocation(business, "bar 1 image");

        table1.completeRow();
        writeContent(table1, loc.x, loc.y, 80, contentByte, false);


    }

    PdfPTable createFeaturesList() throws Exception {

        PdfPTable table1 = new PdfPTable(1);
        table1.setTotalWidth(new float[]{230});
        table1.setLockedWidth(true);

        PdfPCell cell = new PdfPCell();
        cell.setBorder(Rectangle.NO_BORDER);

        List outerList = null;
        if (notEmpty(productProfile.getAdvantages())
                && notEmpty(productProfile.getBenefits())
                && notEmpty(productProfile.getFeatures())
                ) {
            outerList = new List(List.UNORDERED);

            FontStyle style1 = PDFHelper.getFontStyle(business, "feature list level 1");
            Font font1 = FontFactory.getFont(style1.type, style1.size, style1.style, new BaseColor(style1.r, style1.g, style1.b));
            outerList.setListSymbol(new Chunk("", font1));
            FontStyle style2 = PDFHelper.getFontStyle(business, "feature list level 2");
            Font font2 = FontFactory.getFont(style1.type, style2.size, style2.style, new BaseColor(style2.r, style2.g, style2.b));


            createInnerList(outerList, productProfile.getFeatures(), "Features", font1, font2);
            createInnerList(outerList, productProfile.getAdvantages(), "Advantages", font1, font2);
            createInnerList(outerList, productProfile.getBenefits(), "Benefits", font1, font2);
        }

        if (outerList != null) {
            cell.addElement(outerList);
            table1.addCell(cell);
            table1.completeRow();
        } else {
            table1 = null;
        }


        return table1;
    }

    private void createInnerList(List outerList, java.util.List<String> list, String listTitle, Font l1Font, Font l2Font) {
        if (notEmpty(list)) {
            List innerList;
            outerList.add(new ListItem(listTitle, l1Font));
            innerList = new List(List.UNORDERED);
            innerList.setIndentationLeft(LIST_INDENTATION);
            innerList.setListSymbol(new Chunk("\u2022", l2Font));
            for (String feature : list) {
                innerList.add(new ListItem(feature, l2Font));
            }
            outerList.add(innerList);
        }
    }

    protected void buildAgronomicSection(PdfContentByte contentByte) throws Exception {

        Location loc = PDFHelper.getLocation(business, "bar 2 image");

        PdfPTable table1 = new PdfPTable(2);
        table1.setTotalWidth(new float[]{240, 240});
        table1.setLockedWidth(true);

        FontStyle style1 = PDFHelper.getFontStyle(business, "bar 1 label");
        Font font1 = FontFactory.getFont(style1.type, style1.size, style1.style, BaseColor.WHITE);
        PdfPCell cell = new PdfPCell(new Phrase("Agronomics & Cropping Tips", font1));
        cell.setColspan(2);
        cell.setBackgroundColor(getSectionalHeadersBackgroundColor());
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        table1.addCell(cell);

        PdfPTable agTable = getAgTable();


        cell = new PdfPCell();
        cell.setColspan(2);
        cell.setPaddingTop(15f);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.addElement(agTable);
        cell.setPaddingBottom(20f);
        table1.addCell(cell);


        table1.completeRow();

        boolean b = checkForPageBreak(contentByte, table1);
        if (b) {
            loc.y = NEW_PAGE_Y_VALUE;
        }
        writeContent(table1, loc.x, loc.y, 10, contentByte, false);

        PdfPTable pTable = getCalendar();
        b = checkForPageBreak(contentByte, pTable);
        if (b) {
            loc.y = NEW_PAGE_Y_VALUE;
        } else {
            loc.y -= (table1.getTotalHeight() - 20);
        }
        writeContent(pTable, loc.x, loc.y, 10, contentByte, false);

    }

    protected BaseColor getSectionalHeadersBackgroundColor() {
        return BaseColor.BLACK;
    }

    private String getDateSeminis() {
        Date date = null;
        Calendar cal = Calendar.getInstance();
        try {
            date = DateUtils.parseDate(productProfile.getTDRFinalApprovalDate(), new String[]{SHARE_POINT_DATE_FORMAT});
        } catch (Exception e) {
            log.error("error retrieving TDR approval date: " + productProfile.getTDRFinalApprovalDate(), e);
            date = cal.getTime();
        } finally {
            SimpleDateFormat f = new SimpleDateFormat(TDR_APPROVAL_DATE_DISPLAY_FORMAT);
            try {
                return f.format(date);
            } catch (Exception e) {
                log.error("error retrieving TDR approval date: ",e);
            }
        }
        return "";
    }
}
