package com.monsanto.enterprise.marketingnvp.service;

import org.apache.log4j.Logger;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 23, 2011
 * Time: 12:39:00 AM
 * To change this template use File | Settings | File Templates.
 */
public class NTLMAuthenticator extends Authenticator {

    public PasswordAuthentication passwordAuthentication;
    private static Logger log = Logger.getLogger(NTLMAuthenticator.class.getName());

    private String accountName;
    private String ps;

    public NTLMAuthenticator(String accountName, String ps) {
        this.accountName = accountName;
        this.ps = ps;
    }

    @Override
    protected PasswordAuthentication getPasswordAuthentication() {
        log.info("using custom authenticator! for account " + accountName);
        if (passwordAuthentication == null) {
            passwordAuthentication = new PasswordAuthentication(accountName, ps.toCharArray());
        }
        return passwordAuthentication;
    }
}
