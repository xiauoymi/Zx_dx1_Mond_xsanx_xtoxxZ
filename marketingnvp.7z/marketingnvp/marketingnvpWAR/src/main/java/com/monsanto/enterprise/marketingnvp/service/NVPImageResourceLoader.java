package com.monsanto.enterprise.marketingnvp.service;

import com.itextpdf.text.Image;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Feb 21, 2011
 * Time: 9:48:57 PM
 * To change this template use File | Settings | File Templates.
 */
public interface NVPImageResourceLoader {
    Image getLocalImage(String resourceURI) throws Exception;

    Image getRemoteImage(String resourceURI) throws Exception;
}
