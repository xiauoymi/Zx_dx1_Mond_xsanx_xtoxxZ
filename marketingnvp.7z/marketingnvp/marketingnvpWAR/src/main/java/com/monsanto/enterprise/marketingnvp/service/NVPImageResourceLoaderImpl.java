package com.monsanto.enterprise.marketingnvp.service;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Image;
import org.apache.log4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLEncoder;

public class NVPImageResourceLoaderImpl implements NVPImageResourceLoader {
    static Logger logger = Logger.getLogger(NVPImageResourceLoaderImpl.class.getName());

    public NVPImageResourceLoaderImpl() {
    }

    public Image getLocalImage(String resourceURI) throws Exception {
        String s = resourceURI.replaceAll(" ", "%20");
        logger.info("URLEncoder encoding " + resourceURI + " to " + s);
        InputStream stream = this.getClass().getResourceAsStream(s);
        return getImageFromStream(stream);

    }

    protected Image getImageFromStream(InputStream stream) throws IOException, BadElementException {
        int i = stream.available();
        byte[] bytes = new byte[i];
        stream.read(bytes);
        return Image.getInstance(bytes);
    }

    public Image getRemoteImage(String resourceURI) throws Exception {
        try {
            String s = resourceURI.replaceAll(" ", "%20");
            logger.info("URLEncoder encoding " + resourceURI + " to " + s);
            return Image.getInstance(new URL(s));
        } catch (Exception e) {
            logger.error("exception while trying to load remote resource (: " + resourceURI + ")", e);
            throw (e);
        }
    }
}