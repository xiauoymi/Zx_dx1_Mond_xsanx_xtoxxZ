package com.monsanto.enterprise.marketingnvp.service;

import java.io.OutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 24, 2011
 * Time: 11:31:37 PM
 * To change this template use File | Settings | File Templates.
 */
public interface PDFBuilder {
    String COPYRIGHT_CODE = "\u00A9";

    NVPImageResourceLoader getNVPImageResourceLoader();

    void setNVPImageResourceLoader(NVPImageResourceLoader NVPImageResourceLoader);

    void generatePDF(OutputStream fileOutputStream) throws Exception;
}
