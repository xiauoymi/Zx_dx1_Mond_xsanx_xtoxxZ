package com.monsanto.enterprise.marketingnvp.service;

import com.itextpdf.text.*;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.*;
import com.monsanto.Util.StringUtils;
import com.monsanto.enterprise.marketingnvp.model.ProductProfile;
import com.monsanto.enterprise.marketingnvp.model.SharePointServiceConstants;
import com.monsanto.enterprise.marketingnvp.properties.*;

import java.io.OutputStream;

public class PDFBuilderSeminisImpl extends BaseNVPBuilder implements PDFBuilder {



    public PDFBuilderSeminisImpl(ProductProfile productProfile, int business) {
         super(productProfile, business);
        NEW_PAGE_Y_VALUE -= 10;
    }


    public void generatePDF(OutputStream fileOutputStream) throws Exception {
        Document doc = new Document();
        PdfWriter writer = PdfWriter.getInstance(doc, fileOutputStream);
        try {
            doc.setPageSize(PageSize.A4);
            doc.open();
            writer.setPageSize(PageSize.A4);
            PdfContentByte content = writer.getDirectContent();
            buildHeaderSection(content);

        } catch (Exception e) {
            log.error(e);
        }
        finally {
            doc.close();
            writer.close();
        }
    }


    private void buildHeaderSection(PdfContentByte contentByte) throws Exception {

        addPageHeader(contentByte);
        addPageFooter(contentByte);
        addClassificationSection(contentByte);
        buildMarketValueSection(contentByte);
        buildDiseaseProfileSection(contentByte);
        buildFeaturesSection(contentByte);
        buildAgronomicSection(contentByte);
        addTrailResults(contentByte);


    }

    private void addClassificationSection(PdfContentByte contentByte) throws Exception {
        PdfPTable table1 = new PdfPTable(3);
        table1.setTotalWidth(new float[]{200, 210, 40});
        table1.setLockedWidth(true);
        PdfPCell cell = new PdfPCell(new Phrase("Crop:", getFont("Crop Description Line label")));
        cell.setPaddingTop(2f);
        cell.setPaddingBottom(2f);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        table1.addCell(cell);
        cell = new PdfPCell(new Phrase(productProfile.getStringValue(SharePointServiceConstants.OWS_CROP),getFont("Crop Description Line")));
        cell.setColspan(2);
        cell.setPaddingTop(2f);
        cell.setPaddingBottom(2f);
        cell.setBorder(Rectangle.BOX);
        cell.setBorderWidth(1f);
        table1.addCell(cell);

        cell = new PdfPCell(new Phrase("Type (Material Classification Type):",getFont("Weight Description Line label")));
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        cell.setBorder(Rectangle.NO_BORDER);
        table1.addCell(cell);
        cell = new PdfPCell(new Phrase(productProfile.getStringValue(SharePointServiceConstants.OWS_MCT),getFont("Weight Description Line")));
        cell.setColspan(2);
        cell.setPaddingTop(2f);
        cell.setPaddingBottom(2f);
        cell.setBorder(Rectangle.TOP + Rectangle.RIGHT + Rectangle.LEFT);
        cell.setBorderWidth(1f);
        table1.addCell(cell);

        cell = new PdfPCell(new Phrase("Segment:",getFont("Segment Description Line label")));
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setPaddingTop(2f);
        cell.setPaddingBottom(2f);
        table1.addCell(cell);
        cell = new PdfPCell(new Phrase(productProfile.getStringValue(SharePointServiceConstants.OWS_SEGMENT),getFont("Segment Description Line label")));
        cell.setColspan(2);
        cell.setPaddingTop(2f);
        cell.setPaddingBottom(2f);
        cell.setBorder(Rectangle.BOX);
        cell.setBorderWidth(1f);
        table1.addCell(cell);

        cell = new PdfPCell(new Phrase("Variety:", getFont("Variety Description Line label")));
        cell.setBorder(Rectangle.NO_BORDER);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        cell.setPaddingTop(2f);
        cell.setPaddingBottom(2f);
        table1.addCell(cell);

        cell = new PdfPCell(new Phrase(productProfile.getStringValue(SharePointServiceConstants.OWS_VARIETY), getFont("Variety Description Line")));
        cell.setBorder(Rectangle.BOX);
        cell.setBorderWidth(1f);
        cell.setPaddingTop(2f);
        cell.setPaddingBottom(2f);

        if (productProfile.isRegisteredOrPendingRegistration()) {
            cell.setBorder(Rectangle.BOTTOM + Rectangle.LEFT);
            table1.addCell(cell);
            cell = new PdfPCell();
            cell.setPaddingTop(2f);
            cell.setPaddingBottom(2f);
            cell.setBorder(Rectangle.BOX);
            cell.setBorderWidth(1f);
            cell.setBorder(Rectangle.BOTTOM + Rectangle.RIGHT);
            cell.addElement(getPVPImage());
        } else {
            cell.setBorder(Rectangle.BOTTOM + Rectangle.RIGHT + Rectangle.LEFT);
            cell.setColspan(2);
        }
        table1.addCell(cell);
        Location loc = PDFHelper.getLocation(business, "classification image");
        table1.completeRow();
        writeContent(table1, loc.x, loc.y, 100, contentByte, false);
    }


    @Override
    protected BaseColor getSectionalHeadersBackgroundColor() {
        FontStyle style = getFontStyle("sectional headers background");
        return new BaseColor(style.r, style.g, style.b);
    }

    private void buildMarketValueSection(PdfContentByte contentByte) throws Exception {

        if (!StringUtils.isNullOrEmpty(productProfile.getStringValue(SharePointServiceConstants.OWS_VALUE_PROPOSITION))){
            PdfPTable table1 = new PdfPTable(1);
            table1.setTotalWidth(new float[]{450});
            table1.setLockedWidth(true);
            PdfPCell cell = new PdfPCell(new Phrase(productProfile.getStringValue(SharePointServiceConstants.OWS_VALUE_PROPOSITION), getFont("header label")));
            cell.setBorder(Rectangle.BOX);
            cell.setBorderColor(BaseColor.GREEN);
            cell.setBorderWidth(2f);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setVerticalAlignment(Element.ALIGN_CENTER);
            cell.setPaddingBottom(10f);
            cell.setPaddingRight(5f);
            cell.setPaddingLeft(5f);
            cell.setPaddingTop(5f);
            table1.addCell(cell);
            Location loc = PDFHelper.getLocation(business, "box image");
            table1.completeRow();
            writeContent(table1, loc.x, loc.y, 120, contentByte, false);
        }


    }


    private void buildDiseaseProfileSection(PdfContentByte contentByte) throws Exception {

        PdfPTable table1 = new PdfPTable(2);

        table1.setTotalWidth(new float[]{30, 220});
        table1.setLockedWidth(true);
        FontStyle style = getFontStyle("disease.profile table");
        PdfPCell cell = new PdfPCell(new Phrase("Disease Profile:", getFont("disease profile")));
        cell.setColspan(2);
        BaseColor bgColor = new BaseColor(style.r, style.g, style.b);
        cell.setBackgroundColor(bgColor);
        cell.setBorder(Rectangle.BOX);
        cell.setPaddingTop(3f);
        cell.setPaddingBottom(3f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        table1.addCell(cell);


        cell = new PdfPCell(new Phrase("HR", getFont("disease.hr label")));
        cell.setBorder(Rectangle.BOX);
        cell.setBackgroundColor(bgColor);
        cell.setPaddingTop(3f);
        cell.setPaddingBottom(3f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        table1.addCell(cell);

        cell = new PdfPCell(new Phrase(productProfile.getStringValue(SharePointServiceConstants.OWS_HR),getFont("disease.hr")));
        cell.setBorder(Rectangle.BOX);
        cell.setPaddingTop(3f);
        cell.setPaddingBottom(3f);
        cell.setBackgroundColor(bgColor);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        table1.addCell(cell);


        cell = new PdfPCell(new Phrase("IR", getFont("disease.ir label")));
        cell.setBorder(Rectangle.BOX);
        cell.setPaddingTop(3f);
        cell.setPaddingBottom(3f);
        cell.setBackgroundColor(bgColor);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        table1.addCell(cell);

        cell = new PdfPCell(new Phrase(productProfile.getStringValue(SharePointServiceConstants.OWS_IR),getFont("disease.ir label")));
        cell.setBackgroundColor(bgColor);
        cell.setBorder(Rectangle.BOX);
        cell.setPaddingTop(3f);
        cell.setPaddingBottom(3f);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setVerticalAlignment(Element.ALIGN_CENTER);
        table1.addCell(cell);

        Location loc = PDFHelper.getLocation(business, "disease image");

        table1.completeRow();
        writeContent(table1, loc.x, loc.y, 100, contentByte, false);
    }


   private void addTrailResults(PdfContentByte content) throws Exception {

        int numberOfTrailResults = productProfile.getNumberValuesForProperty(SharePointServiceConstants.OWS_NVPTRIALRESULTS);
        Location loc = PDFHelper.getLocation(business, "comparison1 image");
        PdfPTable table1 = new PdfPTable(1);
        table1.setTotalWidth(new float[]{480});
        table1.setLockedWidth(true);
        float totalHeightOfContentPrinted = 0;

        PdfPCell resultsHeaderCell = getTrialResultsHeaderCell();

        PdfPTable pTable;
        table1.addCell(resultsHeaderCell);

        if (numberOfTrailResults > 0) {
            for (int i = 0; i < numberOfTrailResults; i++) {
                pTable = getTrailResultsTable(i, (MAXIMUM_HEIGHT_OF_PAGE - currentY - table1.getTotalHeight() - SECTIONAL_SEPARATOR_HEIGHT));
                if (pTable == null) {
                    continue;
                }
                PdfPCell cell = new PdfPCell();
                cell.setBorder(Rectangle.NO_BORDER);
                cell.setPaddingLeft(10f);
                cell.addElement(pTable);
                if (currentHeight + table1.getTotalHeight() + pTable.getTotalHeight() < MAXIMUM_HEIGHT_OF_PAGE) {
                    totalHeightOfContentPrinted = 1;
                    table1.addCell(cell);
                } else {
                    if (totalHeightOfContentPrinted == 1) {
                        totalHeightOfContentPrinted = 0;
                        table1.completeRow();
                        writeContent(table1, loc.x, loc.y == NEW_PAGE_Y_VALUE ? NEW_PAGE_Y_VALUE : loc.y, loc.y == NEW_PAGE_Y_VALUE ? 10 : 50, content, false);
                        table1 = new PdfPTable(1);
                        table1.setTotalWidth(new float[]{480});
                        table1.setLockedWidth(true);
                        table1.addCell(resultsHeaderCell);
                        table1.addCell(cell);

                    } else {
                        forcePageBreak(content);
                        table1.addCell(cell);
                        totalHeightOfContentPrinted = 1;
                        loc.y = NEW_PAGE_Y_VALUE;
                    }
                }
            }
            table1.completeRow();
            if (checkForPageBreak(content, table1)) {
                loc.y = NEW_PAGE_Y_VALUE;
            }
            writeContent(table1, loc.x, loc.y == NEW_PAGE_Y_VALUE ? NEW_PAGE_Y_VALUE : loc.y, loc.y == NEW_PAGE_Y_VALUE ? 10 : 50, content, false);
        }

    }

//    private PdfPTable getTrailResultsTable(int resultNumber) throws Exception {
//
//        PdfPTable table1 = null;
//        String resultsChartURL = productProfile.getTrialResultsChartURL(resultNumber);
//        String trialResultsTitle = productProfile.getTrialResultsTitle(resultNumber);
//        PdfPCell titleCell;
//
//        if (!StringUtils.isNullOrEmpty(trialResultsTitle) || !StringUtils.isNullOrEmpty(resultsChartURL)) {
//            table1 = new PdfPTable(1);
//            table1.setTotalWidth(new float[]{480});
//            table1.setLockedWidth(true);
//            if (!StringUtils.isNullOrEmpty(trialResultsTitle)) {
//                titleCell = new PdfPCell(new Phrase(trialResultsTitle));
//                titleCell.setPaddingTop(10f);
//                titleCell.setPaddingBottom(10f);
//                titleCell.setBorder(Rectangle.NO_BORDER);
//                titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
//                titleCell.setVerticalAlignment(Element.ALIGN_LEFT);
//                table1.addCell(titleCell);
//            }
//
//            if (!StringUtils.isNullOrEmpty(resultsChartURL)) {
//                titleCell = new PdfPCell();
//                titleCell.setPaddingTop(15f);
//                titleCell.setBorder(Rectangle.NO_BORDER);
//                titleCell.setHorizontalAlignment(Element.ALIGN_LEFT);
//                titleCell.setVerticalAlignment(Element.ALIGN_LEFT);
//                Image image = getNVPImageResourceLoader().getRemoteImage(resultsChartURL);
//                float height = 250 * image.getWidth() / image.getHeight();
//                float v = Math.min(height, image.getHeight());
//                titleCell.addElement(image);
//                titleCell.setFixedHeight(v);
//                titleCell.addElement(image);
//                table1.addCell(titleCell);
//            }
//
//        }
//        return table1;
//    }


}