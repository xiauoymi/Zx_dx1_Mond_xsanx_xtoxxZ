package com.monsanto.enterprise.marketingnvp.service;

import com.monsanto.enterprise.marketingnvp.model.ProductProfile;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Feb 17, 2011
 * Time: 3:21:56 PM
 * To change this template use File | Settings | File Templates.
 */
public interface ProductProfileServiceProxy {
    ProductProfile getProductProfile(String productId, String region);
}
