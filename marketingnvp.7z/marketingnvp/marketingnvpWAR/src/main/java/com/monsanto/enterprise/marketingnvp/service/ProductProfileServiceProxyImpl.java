package com.monsanto.enterprise.marketingnvp.service;

import com.monsanto.enterprise.marketingnvp.client.*;
import com.monsanto.enterprise.marketingnvp.model.ProductProfile;
import org.apache.xerces.dom.ElementNSImpl;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import java.net.Authenticator;
import java.util.HashMap;

public class ProductProfileServiceProxyImpl implements ProductProfileServiceProxy {
    public static final String QUERY_PARAMETER_FIELD_NAME = "ID";
    public static final String QUERY_PARAMETER_TYPE = "Counter";
    public static final String PRODUCT_PROFILE_GUID = "{EB5F1785-959A-4264-A482-FAE21D6EE12E}";

    static {
        AccountHelper accountHelper = new AccountHelper();
        Authenticator.setDefault(new NTLMAuthenticator(accountHelper.getAccountName(), accountHelper.getAccountPassword()));
    }

    public ProductProfile getProductProfile(String productId, String region) {
        ProductProfile profile = null;
        ListsSoap listsSoap = SharePointServiceClientFactory.getListsServiceClient(region).getListsSoap();
        QueryType qq = buildServiceQuery(productId);
        GetListItemsResponse.GetListItemsResult listItemsResult = listsSoap.getListItems(
                // the guid or mame of the list that contains the view/data being accessed
                PRODUCT_PROFILE_GUID,
                //guid or name of view being queried ; this is like a database view
                "",
                //query filter.. this is weher the view concept above breaks.. this filter is not applied to view but underlining view tables
                qq,
                //fields to include in the resposne.. this also replaces fields defined on view
                null,
                //limits # of rows returned also overwrites row restriction defined on view
                "1",
                //this is for group bys.. sorting etc
                null, null);
        if (!listItemsResult.getContent().isEmpty()) {
            ElementNSImpl result = (ElementNSImpl) listItemsResult.getContent().get(0);
            Node rs = result.getFirstChild();
            if (rs != null) {
                if (rs.getFirstChild() instanceof ElementNSImpl) {
                    ElementNSImpl child = (ElementNSImpl) rs.getFirstChild();
                    if (child != null) {
                        profile = getProductProfileFromResponseNode(child);
                    }
                }
            }
        }
        return profile;
    }


    private ProductProfile getProductProfileFromResponseNode(ElementNSImpl rowData) {
        NamedNodeMap map = rowData.getAttributes();
        HashMap<String, String> data = new HashMap<String, String>(map.getLength() + 1);
        for (int i = 0; i < map.getLength(); i++) {
            data.put(map.item(i).getNodeName(), map.item(i).getNodeValue());
        }
        ProductProfile productProfile = new ProductProfile();
        productProfile.setSharePointData(data);

        return productProfile;
    }

    QueryType buildServiceQuery(String productId) {

        QueryType qq = new QueryType();
        QueryQueryType queryType = new QueryQueryType();

        QueryQueryType.Where where = new QueryQueryType.Where();
        queryType.setWhere(where);

        qq.setQuery(queryType);
        qq.setQuery(queryType);

        QueryQueryType.Where.Eq e = new QueryQueryType.Where.Eq();
        where.setEq(e);

        QueryQueryType.Where.Eq.FieldRef ref = new QueryQueryType.Where.Eq.FieldRef();
        e.setFieldRef(ref);

        ref.setName(QUERY_PARAMETER_FIELD_NAME);

        QueryQueryType.Where.Eq.Value value = new QueryQueryType.Where.Eq.Value();
        e.setValue(value);

        value.setType(QUERY_PARAMETER_TYPE);
        value.setContent(productId);
        return qq;
    }
}