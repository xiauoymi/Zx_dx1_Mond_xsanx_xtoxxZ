package com.monsanto.enterprise.marketingnvp.service;

import com.monsanto.enterprise.marketingnvp.client.Lists;
import org.apache.log4j.Logger;

import javax.xml.namespace.QName;
import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 23, 2011
 * Time: 2:15:14 AM
 * To change this template use File | Settings | File Templates.
 */
public class SharePointServiceClientFactory {

    public static URL WSDL_LOCATION_FOR_EMEA;
    public static URL WSDL_LOCATION_FOR_AMERICAS;
    public static final QName SERVICE_QNAME = new QName("http://schemas.microsoft.com/sharepoint/soap/", "Lists");
    private static Logger  logger = Logger.getLogger(SharePointServiceClientFactory.class.getName());

    public static Lists getListsServiceClient(String region) {
        logger.info("creating service using wsdl located for region"+region+" @ " + WSDL_LOCATION_FOR_EMEA);
        return new Lists("emea".equalsIgnoreCase(region)?WSDL_LOCATION_FOR_EMEA:WSDL_LOCATION_FOR_AMERICAS, SERVICE_QNAME);
    }

}
