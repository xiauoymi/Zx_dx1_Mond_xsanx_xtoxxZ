package com.monsanto.enterprise.marketingnvp.servlet;

import com.monsanto.enterprise.marketingnvp.service.SharePointServiceClientFactory;
import org.apache.log4j.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.net.MalformedURLException;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 23, 2011
 * Time: 2:30:22 AM
 * To change this template use File | Settings | File Templates.
 */
public class NVPServletContextListener implements ServletContextListener {

    static Logger logger = Logger.getLogger(NVPServletContextListener.class.getName());

    public void contextInitialized(ServletContextEvent servletContextEvent) {
        try {
            SharePointServiceClientFactory.WSDL_LOCATION_FOR_EMEA = servletContextEvent.getServletContext().getResource(getWSDLLocation("emea"));
            SharePointServiceClientFactory.WSDL_LOCATION_FOR_AMERICAS = servletContextEvent.getServletContext().getResource(getWSDLLocation("americas"));
            logger.info("SharePointServiceClientFactory.WSDL_LOCATION = " + SharePointServiceClientFactory.WSDL_LOCATION_FOR_EMEA);
            logger.info("SharePointServiceClientFactory.WSDL_LOCATION_FOR_AMERICAS = " + SharePointServiceClientFactory.WSDL_LOCATION_FOR_AMERICAS);
        } catch (MalformedURLException e) {
            logger.error(e);
        }
    }

    private String getWSDLLocation(String regionalSuffix) {
        String env = System.getProperty("lsi.function");
        if (env!=null){
            env = env.toLowerCase().trim();
        }
        return "/wsdls/lists-"+ regionalSuffix+"-"+env+".xml";
    }

    public void contextDestroyed(ServletContextEvent servletContextEvent) {
    }
}
