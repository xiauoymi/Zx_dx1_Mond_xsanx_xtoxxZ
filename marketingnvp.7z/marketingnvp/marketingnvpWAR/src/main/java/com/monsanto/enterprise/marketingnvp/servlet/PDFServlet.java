package com.monsanto.enterprise.marketingnvp.servlet;

import com.monsanto.enterprise.marketingnvp.model.ProductProfile;
import com.monsanto.enterprise.marketingnvp.service.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Jan 20, 2011
 * Time: 12:07:14 PM
 * To change this template use File | Settings | File Templates.
 */
public class PDFServlet extends HttpServlet {
    private static final String PRODUCT_ID_FORM_PARAMETER_NAME = "product_id";
    private static final String PRODUCT_COUNTRY_FORM_PARAMETER_NAME = "country";
    private static final String GROUP_FORM_PARAMETER_NAME = "group";

    static Logger logger = Logger.getLogger(PDFServlet.class.getName());    

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        logger.info("Request started: " + req.getRequestURL().append(req.getQueryString()).toString());

        String productId = req.getParameter(PRODUCT_ID_FORM_PARAMETER_NAME);
        String productCountry = req.getParameter(PRODUCT_COUNTRY_FORM_PARAMETER_NAME);
        String groupName = req.getParameter(GROUP_FORM_PARAMETER_NAME);
        try {
            logger.info("profile retrieved from SharePoint: "+productId + " group="+groupName+", pCountry="+productCountry);
            ProductProfile profile = getProductProfile(productId, groupName);
            if (profile!=null){
                profile.setCountry(productCountry);
                logger.info("profile retrieved from SharePoint: "+profile.toString());
                resp.setContentType("application/pdf");
                resp.setHeader("Content-Disposition", "attachment; filename=nvp_" + productId + "_nvp.pdf");
                buildPDF(resp.getOutputStream(), profile);
                resp.getOutputStream().flush();
            }else {
                req.setAttribute("errorMessage", "Product Profile with an id of "+productId+ " could not be found!");
            }

        } catch (Exception e) {
            logger.error(e);
            req.setAttribute("nvpException", e);
            req.getRequestDispatcher("/error.jsp").forward(req, resp);
        } finally {
            logger.info("Request finished: " + req.getRequestURL().append(req.getQueryString()).toString());
        }
    }

    private ProductProfile getProductProfile(String productId, String groupName){
        ProductProfileServiceProxy productProfileServiceProxy;
        productProfileServiceProxy = new ProductProfileServiceProxyImpl();
        return productProfileServiceProxy.getProductProfile(productId, groupName);
    }

    public void buildPDF(OutputStream outputStream, ProductProfile profile) throws Exception {
        int business = getBusinessId(profile.getBrand());
        PDFBuilder pdfBuilder = business==1?new PDFBuilderSeminisImpl(profile, business):new PDFBuilderDeruiterImpl(profile, business);
        pdfBuilder.generatePDF(outputStream);
    }

    private int getBusinessId(String companyId) {
        if("De Ruiter Seeds".equalsIgnoreCase(companyId))
            return 0;
        return 1;
    }


}
