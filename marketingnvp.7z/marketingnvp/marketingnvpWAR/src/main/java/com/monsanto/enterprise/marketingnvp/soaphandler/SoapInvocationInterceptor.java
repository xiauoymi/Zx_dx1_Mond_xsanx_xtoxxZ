package com.monsanto.enterprise.marketingnvp.soaphandler;


import javax.xml.namespace.QName;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.handler.soap.SOAPHandler;
import javax.xml.ws.handler.soap.SOAPMessageContext;
import java.util.Collections;
import java.util.Set;

import org.apache.log4j.Logger;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Jan 21, 2011
 * Time: 4:01:05 PM
 * To change this template use File | Settings | File Templates.
 */
public class SoapInvocationInterceptor implements SOAPHandler<SOAPMessageContext> {
    public Set<QName> getHeaders() {
        return Collections.emptySet();
    }

    static Logger logger = Logger.getLogger(SoapInvocationInterceptor.class.getName());

    public boolean handleMessage(SOAPMessageContext context) {
        try {

            context.getMessage().writeTo(System.out);
        } catch (Exception e) {
            logger.error(e);
        }
        return true;
    }

    public boolean handleFault(SOAPMessageContext context) {
        return false;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public void close(MessageContext context) {

    }
}
