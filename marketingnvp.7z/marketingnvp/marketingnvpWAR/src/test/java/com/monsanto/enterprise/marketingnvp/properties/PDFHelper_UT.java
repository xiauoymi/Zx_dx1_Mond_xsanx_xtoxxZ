package com.monsanto.enterprise.marketingnvp.properties;

import org.junit.Test;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;

import junit.framework.Assert;

/**
 * Created by IntelliJ IDEA.
 * User: DRMANS
 * Date: Jan 30, 2011
 * Time: 12:19:39 PM
 * To change this template use File | Settings | File Templates.
 */
public class PDFHelper_UT {

    @Test
    public void testGetLocationProperty() throws Exception {

        String name = "Weight Description Line";
        Location location = PDFHelper.getLocation(0,name);
        Assert.assertNotNull(location);
        Location actualLocation = lookup(name).getLocation();
        Assert.assertEquals(actualLocation.x, location.x);
        Assert.assertEquals(actualLocation.y, location.y);
    }
    @Test
    public void testGetSizeProperty() throws Exception {

        String name = "crop image";
        Rectangle rectangle = PDFHelper.getRectangle(0,name);
        Assert.assertNotNull(rectangle);
        Rectangle actualRectangle = lookup(name).getRectangle();
        Assert.assertEquals(actualRectangle.h, rectangle.h);
        Assert.assertEquals(actualRectangle.w, rectangle.w);
    }
    @Test
    public void testGetWidthProperty() throws Exception {

        String name = "feature table";
        Width width = PDFHelper.getWidth(0,name);
        Assert.assertNotNull(width);
        int actualWidth = lookup(name).getWidth();
        Assert.assertEquals(actualWidth, width.w);
    }

    @Test
    public void testGetFontProperty() throws Exception {

        String name = "Crop desc";
        FontStyle font = PDFHelper.getFontStyle(0,name);
        Assert.assertNotNull(font);
        FontStyle actualFont = lookup(name).getFontStyle();
        Assert.assertEquals(actualFont.type, font.type);
        Assert.assertEquals(actualFont.size, font.size);
        Assert.assertEquals(actualFont.r, font.r);
        Assert.assertEquals(actualFont.g, font.g);
        Assert.assertEquals(actualFont.b, font.b);
    }
    public NVPContent lookup(String name) throws Exception {

        String fileName = "/com/monsanto/enterprise/marketingnvp/templates/nvpPropertyList_deruiters.xml";
        JAXBContext jc = JAXBContext.newInstance(NVPPDFPropertyList.class);
        Unmarshaller unmarshaller = jc.createUnmarshaller();
        NVPPDFPropertyList nvppdfPropertyList = (NVPPDFPropertyList) unmarshaller.unmarshal(PDFHelper.class.getResourceAsStream(fileName));
        for (NVPContent p : nvppdfPropertyList.getContents()) {
            if(name.equals(p.getId()))
                return p;
        }


        return null;
    }
}
