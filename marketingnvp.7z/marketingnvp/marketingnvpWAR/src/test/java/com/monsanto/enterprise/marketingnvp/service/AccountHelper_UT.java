package com.monsanto.enterprise.marketingnvp.service;

import com.monsanto.Util.databasepasswordencryption.EncryptionUtils;
import junit.framework.Assert;
import org.junit.Test;


/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 24, 2011
 * Time: 12:33:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class AccountHelper_UT {

    @Test
    public void getAccountName(){
        AccountHelper accountHelper = new AccountHelper();
        Assert.assertEquals("wrong account!", "NORTH_AMERICA\\NA1000APP-MKTNVP-DEV", accountHelper.getAccountName());
    }


    @Test
    public void getAccountPassword(){
        AccountHelper accountHelper = new AccountHelper();
        Assert.assertEquals("wrong account!", "Abc123", accountHelper.getAccountPassword());
    }

}
