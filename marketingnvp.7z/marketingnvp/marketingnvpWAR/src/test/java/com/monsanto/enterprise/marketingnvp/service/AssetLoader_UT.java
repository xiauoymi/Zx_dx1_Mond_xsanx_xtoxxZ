package com.monsanto.enterprise.marketingnvp.service;

import com.monsanto.enterprise.marketingnvp.service.AssetLoader;
import org.junit.Test;

import java.io.*;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Jan 27, 2011
 * Time: 12:37:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class AssetLoader_UT {

    @Test
    public void loadAsset(){
        AssetLoader assetLoader = new AssetLoader();
        assetLoader.canLoadImage("http://localhost:1000/enterprise/EMEA/PublishedAssets/Melon.jpg");
    }


    @Test
    public void canLoadImage(){                     
        String url = "http://na1000spdev21:1000/enterprise/EMEA/assets/PublishedAssets/Tomato_GRH_CCT_Elejido%20new%20(1).jpg";
        try {
            URL url1 = new URL(url);
            URLConnection urlConnection = url1.openConnection();
            urlConnection.connect();
            InputStream bodyAsStream = urlConnection.getInputStream();
            byte[] bytes = new byte[1024];
            int readCount =0;
            File f = new File("Tomato_GRH_CCT_Elejido%20new%20(1).jpg");
            FileOutputStream fo = new FileOutputStream(f);
            while((readCount=bodyAsStream.read(bytes))>0){
                fo.write(bytes, 0, readCount);
            }
            fo.close();
            bodyAsStream.close();
        } catch (IOException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
