package com.monsanto.enterprise.marketingnvp.service;

import org.junit.Assert;
import org.junit.Test;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 24, 2011
 * Time: 2:54:26 PM
 * To change this template use File | Settings | File Templates.
 */
public class NTLMAuthenticator_UT {

    @Test
    public void returnsCorrectPasswordAuthenticator(){
        NTLMAuthenticator ntlmAuthenticator = new NTLMAuthenticator("acct", "test");
        Assert.assertEquals("invalid user name", "acct", ntlmAuthenticator.getPasswordAuthentication().getUserName());
        Assert.assertEquals("invalid password", "test", new String(ntlmAuthenticator.getPasswordAuthentication().getPassword()));
    }
}
