package com.monsanto.enterprise.marketingnvp.service;

import com.itextpdf.text.Image;
import com.monsanto.enterprise.marketingnvp.model.ProductProfile;
import com.monsanto.enterprise.marketingnvp.model.SharePointServiceConstants;
import com.monsanto.enterprise.marketingnvp.properties.PDFHelper;
import org.junit.Test;
import org.junit.Assert;

import java.io.*;
import java.net.URL;
import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Jan 28, 2011
 * Time: 12:04:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class NVPTemplatePropertyBuilder_UT {
    private PDFBuilder pdfBuilder;

    private ProductProfile getProductProfile(String id) throws Exception{
        ProductProfileServiceProxy productProfileServiceProxy;
        String s = ProductProfileServiceProxyImpl.PRODUCT_PROFILE_GUID;
                SharePointServiceClientFactory.WSDL_LOCATION_FOR_EMEA = new URL("file:c:/svn_projects/marketingnvp/marketingnvpWAR/src/main/webapp/wsdls/lists-emea-it.xml");
        System.out.println(SharePointServiceClientFactory.WSDL_LOCATION_FOR_EMEA);
        productProfileServiceProxy = new ProductProfileServiceProxyImpl();
        return productProfileServiceProxy.getProductProfile(id, "emea");
    }


    @Test
    public void testCanLoadProfile() throws Exception {

        try {
            ProductProfile profile = getProductProfile("58");
            Assert.assertNotNull(profile);
            System.out.println("profile.toString() = " + profile.toString());
        } catch (Exception e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }

    @Test
    public void testGenerateUsingEmptyPageForSeminisWithNoPVP() throws Exception {
        try {
            ProductProfile productProfile = getProductProfile("24");
            pdfBuilder = new PDFBuilderSeminisImpl(productProfile, PDFHelper.BUSINESS_SEMINIS);
            FileOutputStream fileOutputStream = new FileOutputStream("seminis_16_no_pvp.pdf");
            pdfBuilder.generatePDF(fileOutputStream);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void testGenerateUsingEmptyPageForSeminis() {
        ProductProfile productProfile = createProductProfile();
        try {
            pdfBuilder = new PDFBuilderSeminisImpl(productProfile, PDFHelper.BUSINESS_SEMINIS);
            pdfBuilder.setNVPImageResourceLoader(new MockRemoteResourceLoader());
            FileOutputStream fileOutputStream = new FileOutputStream("seminis_16.pdf");
            pdfBuilder.generatePDF(fileOutputStream);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }


    @Test
    public void testGenerateUsingEmptyPageForDeRuiters() {
        ProductProfile productProfile = createProductProfile();
        try {
            PDFBuilder pdfBuilder = new PDFBuilderDeruiterImpl(productProfile, PDFHelper.BUSINESS_DERUITERS);
            pdfBuilder.setNVPImageResourceLoader(new MockRemoteResourceLoader());
            FileOutputStream fileOutputStream = new FileOutputStream("deruiters_16.pdf");
            pdfBuilder.generatePDF(fileOutputStream);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }

    @Test
    public void testGenerateUsingEmptyPageForNonPVPDeRuiters() {
        ProductProfile productProfile = createProductProfile();
        try {
            productProfile.getSharePointData().put(SharePointServiceConstants.OWS_PVP, null);
            PDFBuilder pdfBuilder = new PDFBuilderDeruiterImpl(productProfile, PDFHelper.BUSINESS_DERUITERS);
            pdfBuilder.setNVPImageResourceLoader(new MockRemoteResourceLoader());
            FileOutputStream fileOutputStream = new FileOutputStream("deruiters_no_pvp_16.pdf");
            pdfBuilder.generatePDF(fileOutputStream);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }
    }


    private ProductProfile createProductProfile() {
        ProductProfile productProfile = new ProductProfile();
        HashMap<String, String> sharePointData = new HashMap<String, String>(19);
        productProfile.setSharePointData(sharePointData);
        sharePointData.put("ows_Advantages", "test");
        sharePointData.put("ows_Benefits", "test");
        sharePointData.put("ows_Brand", "1;#De Ruiter Seeds");
        sharePointData.put("ows_Country", "1;#Albania");
        sharePointData.put("ows_Created", "2011-06-21 10:07:39");
        sharePointData.put("ows_Modified", "2011-02-21 10:07:39");
        sharePointData.put("ows_Created_x0020_Date", "18;#2011-02-21 10:07:39");
        sharePointData.put("ows_EndDateHarvest", "2011-01-01 00:00:00");
        sharePointData.put("ows_EndDateSowing", "2011-01-01 00:00:00");
        sharePointData.put("ows_EndDateTransplant", "2011-01-01 00:00:00");
        sharePointData.put("ows_Environment", "1;#Glass house");
        sharePointData.put("ows_FSObjType", "18;#0");
        sharePointData.put("ows_Family", "2;#Cucurbits");
        sharePointData.put("ows_Features", "test;test;test this one wrapped around which is good news for everyone...;test this is a very long text that needs wrapping to occur.. lets sey if it happens... well what is the verdict?;");
        sharePointData.put("ows_FileLeafRef", "18;#18_.000");
        sharePointData.put("ows_EnvironmentalTips", "Environment: Open Field test this one wrapped around which is good news for everyone...;test this is a very long text that needs wrapping to occur..");
        sharePointData.put("ows_FileRef", "18;#enterprise/EMEA/Lists/ProductProfiles/18_.000");
        sharePointData.put("ows_GeographicalAdaption", "test");
        sharePointData.put("ows_HR", "HR");
        sharePointData.put("ows_ID", "18");
        sharePointData.put("ows_IR", "IR");
        sharePointData.put("ows_Length", "123");
        sharePointData.put("ows_LinkTitle", "test code");
        sharePointData.put("ows_MCT", "16;#CAY - Cayenne");
        sharePointData.put("ows_Market", "2;#Fresh Market");
        sharePointData.put("ows_NVPCalendar1", "http://na1000spdev21:1000/enterprise/EMEA/assets/PublishedAssets/Tomato_GRH_CCT_Elejido%20new%20(1).jpg");
        sharePointData.put("ows_NVPCalendarHeading1", "Planing Calendar");
        sharePointData.put("ows_NVPImage1", "http://na1000spdev21:1000/enterprise/EMEA/assets/PublishedAssets/Tomato_GRH_CCT_Elejido%20new%20(1).jpg");
        sharePointData.put("ows_NVPImage2", "http://na1000spdev21:1000/enterprise/EMEA/assets/PublishedAssets/Tomato_GRH_CCT_Elejido%20new%20(1).jpg");
        sharePointData.put("ows_NVPImage3", "http://na1000spdev21:1000/enterprise/EMEA/assets/PublishedAssets/Tomato_GRH_CCT_Elejido%20new%20(1).jpg");
        sharePointData.put("ows_NVPTrialResults1", "http://na1000spdev21:1000/enterprise/EMEA/assets/PublishedAssets/Tomato_GRH_CCT_Elejido%20new%20(1).jpg");
        sharePointData.put("ows_NVPTrialResults2", "http://na1000spdev21:1000/enterprise/EMEA/assets/PublishedAssets/Tomato_GRH_CCT_Elejido%20new%20(1).jpg");
        sharePointData.put("ows_NVPTrialResults3", "http://na1000spdev21:1000/enterprise/EMEA/assets/PublishedAssets/Tomato_GRH_CCT_Elejido%20new%20(1).jpg");
        sharePointData.put("ows_NVPTrialResults4", "http://na1000spdev21:1000/enterprise/EMEA/assets/PublishedAssets/Tomato_GRH_CCT_Elejido%20new%20(1).jpg");
        sharePointData.put("ows_NVPTrialResultsHeading1", "lkjlkj");
        sharePointData.put("ows_NVPTrialResultsHeading2", "lkjlk");
        sharePointData.put("ows_NVPTrialResultsHeading3", "lkjlkj");
        sharePointData.put("ows_NVPTrialResultsHeading4", "lkjlkj");
        sharePointData.put("ows_PVP", "Registered");
        sharePointData.put("ows_PlantRate", "test");
        sharePointData.put("ows_ProfileA", "5");
        sharePointData.put("ows_Season", "test");
        sharePointData.put("ows_Crop", "Test Crop");
        sharePointData.put("ows_Segment", "segment");
        sharePointData.put("ows_SpecificAdvice", "test");
        sharePointData.put("ows_StartDateHarvest", "2011-01-01 00:00:00");
        sharePointData.put("ows_StartDateSowing", "2011-01-01 00:00:00");
        sharePointData.put("ows_StartDateTransplant", "2011-01-01 00:00:00");
        sharePointData.put("ows_Title", "test code");
        sharePointData.put("ows_UniqueId", "18;#{1345A87B-921E-4603-933E-391775319E59}");
        sharePointData.put("ows_ValueProposition", "value");
        sharePointData.put("ows_Variety", "variety");
        sharePointData.put("ows_VarietySecondaryName", "1;#Belgium (Dutch)");
        sharePointData.put("ows_Weight", "12");
        sharePointData.put("ows__Level", "1");
        sharePointData.put("ows__ModerationStatus", "0");
        sharePointData.put("ows_owshiddenversion", "14");
        return productProfile;
    }


    private class MockRemoteResourceLoader extends NVPImageResourceLoaderImpl {

        @Override
        public Image getRemoteImage(String resourceURI) throws Exception {
            System.out.println("resourceURI = " + resourceURI);
            FileInputStream fs = new FileInputStream("test_profile_crop_image_1.jpg");
            return getImageFromStream(fs);
        }
    }
}
