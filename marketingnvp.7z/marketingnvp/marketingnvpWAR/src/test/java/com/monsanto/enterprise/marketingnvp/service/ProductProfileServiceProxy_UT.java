package com.monsanto.enterprise.marketingnvp.service;

import com.monsanto.enterprise.marketingnvp.model.ProductProfile;
import org.junit.Test;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Jan 21, 2011
 * Time: 10:14:34 AM
 * To change this template use File | Settings | File Templates.
 */


public class ProductProfileServiceProxy_UT {

    @Test
    public void canGetProductProfileForEMEA() {
        setWSDLLocation("file:/C:/svn_projects/marketingnvp/marketingnvpWAR/src/main/webapp/wsdls/lists-emea-it.xml");
        ProductProfileServiceProxy productProfileServiceProxy;
        productProfileServiceProxy = new ProductProfileServiceProxyImpl();
        ProductProfile profile = productProfileServiceProxy.getProductProfile("58", "emea");
        System.out.println("profile.toString() = " + profile.toString());

    }

    @Test
    public void canGetProductProfileForAmericas() {
        setWSDLLocation("file:/C:/svn_projects/marketingnvp/marketingnvpWAR/src/main/webapp/wsdls/lists-americas-win.xml");
        ProductProfileServiceProxy productProfileServiceProxy;
        productProfileServiceProxy = new ProductProfileServiceProxyImpl();
        ProductProfile profile = productProfileServiceProxy.getProductProfile("62", "americas");
        System.out.println("profile.toString() = " + profile.toString());

    }

    private void setWSDLLocation(String url) {
        try {
            SharePointServiceClientFactory.WSDL_LOCATION_FOR_EMEA = new URL(null, url);
        } catch (MalformedURLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
    }
}
