package com.monsanto.enterprise.marketingnvp.service;

import com.monsanto.enterprise.marketingnvp.model.ProductProfile;
import com.monsanto.enterprise.marketingnvp.model.SharePointServiceConstants;
import org.junit.Assert;
import org.junit.Test;

import java.util.HashMap;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 25, 2011
 * Time: 1:35:44 AM
 * To change this template use File | Settings | File Templates.
 */
public class ProductProfile_UT {

    @Test
    public void getNumberTrailResultsReturnsZeroWhenDataSetIsEmpty(){
        ProductProfile p = new ProductProfile();
        p.setSharePointData(new HashMap<String, String>());
        int trailResults = p.getNumberValuesForProperty(SharePointServiceConstants.OWS_NVPTRIALRESULTS);

        Assert.assertEquals("", 0, trailResults);
    }

    @Test
    public void getNumberTrailResultsReturnsZeroWhenDataSetIsDoesNotContainsAValueForKey(){
        ProductProfile p = new ProductProfile();
        HashMap<String, String> testData = new HashMap<String, String>();
        testData.put(SharePointServiceConstants.OWS_HR, "test");
        p.setSharePointData(testData);
        int trailResults = p.getNumberValuesForProperty(SharePointServiceConstants.OWS_NVPTRIALRESULTS);

        Assert.assertEquals("", 0, trailResults);
    }

    @Test
    public void getNumberTrailResultsReturns1WhenDataSetIsContainsOnlyOneValueForKey(){
        ProductProfile p = new ProductProfile();
        HashMap<String, String> testData = new HashMap<String, String>();
        testData.put(SharePointServiceConstants.OWS_NVPTRIALRESULTS1, "test");
        p.setSharePointData(testData);
        int trailResults = p.getNumberValuesForProperty(SharePointServiceConstants.OWS_NVPTRIALRESULTS);

        Assert.assertEquals("", 1, trailResults);
    }

    @Test
    public void stripOffFormattingRemovesFormatting(){
        ProductProfile p = new ProductProfile();
        HashMap<String, String> testData = new HashMap<String, String>();
        testData.put("testString", "16;#test");
        p.setSharePointData(testData);
        Assert.assertEquals("formatting not removed!", p.getStringValue("testString"), "test");
    }

     @Test
    public void stripOffFormattingDoesNotRemovesFormattingForStringWithHttp(){
        ProductProfile p = new ProductProfile();
        HashMap<String, String> testData = new HashMap<String, String>();
        testData.put("testString", "http://16;#test");
        p.setSharePointData(testData);
        Assert.assertEquals("formatting not removed!", p.getStringValue("testString"), "http://16;#test");
    }


    @Test
    public void getNumberTrailResultsReturnsCorrectValueForMultipleMatchesForKey(){
        ProductProfile p = new ProductProfile();
        HashMap<String, String> testData = new HashMap<String, String>();
        testData.put(SharePointServiceConstants.OWS_NVPTRIALRESULTS1, "test");
        testData.put(SharePointServiceConstants.OWS_NVPTRIALRESULTS2, "test");
        testData.put(SharePointServiceConstants.OWS_NVPTRIALRESULTS3, "test");
        testData.put(SharePointServiceConstants.OWS_NVPTRIALRESULTS4, "test");
        p.setSharePointData(testData);
        int trailResults = p.getNumberValuesForProperty(SharePointServiceConstants.OWS_NVPTRIALRESULTS);

        Assert.assertEquals("", 4, trailResults);
    }
    
}
