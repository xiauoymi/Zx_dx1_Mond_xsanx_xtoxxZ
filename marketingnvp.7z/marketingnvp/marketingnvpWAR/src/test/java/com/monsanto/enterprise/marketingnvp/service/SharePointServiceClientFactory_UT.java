package com.monsanto.enterprise.marketingnvp.service;

import com.monsanto.enterprise.marketingnvp.client.Lists;
import org.junit.Assert;
import org.junit.Test;

import java.net.URL;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 24, 2011
 * Time: 3:00:17 PM
 * To change this template use File | Settings | File Templates.
 */
public class SharePointServiceClientFactory_UT {

    @Test
    public void createsCorrectSoapService() throws Exception{
        SharePointServiceClientFactory.WSDL_LOCATION_FOR_EMEA = new URL(null, "file:/C:/svn_projects/marketingnvp/marketingnvpWAR/src/main/webapp/wsdls/lists-emea-it.xml");

        Lists listsServiceClient = SharePointServiceClientFactory.getListsServiceClient("emea");
        Assert.assertNotNull("service not created!",listsServiceClient);
    }
}
