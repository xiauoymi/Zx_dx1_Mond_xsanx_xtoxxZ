package com.monsanto.enterprise.marketingnvp.servlet;

import com.monsanto.enterprise.marketingnvp.service.SharePointServiceClientFactory;
import org.junit.Assert;
import org.junit.Test;

import javax.servlet.*;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Set;

/**
 * Created by IntelliJ IDEA.
 * User: TADIAL
 * Date: Feb 24, 2011
 * Time: 3:06:57 PM
 * To change this template use File | Settings | File Templates.
 */
public class NVPServletContextListener_UT {
    private List<String> resourceUris = new ArrayList<String>();

    @Test
    public void setWSDLLocationOnServerStartup(){
       NVPServletContextListener nvpServletContextListener = new NVPServletContextListener();
        MockServletContext context = new MockServletContext();
        nvpServletContextListener.contextInitialized(new MockServletContextEvent(context));
        Assert.assertEquals("wrong resource name", resourceUris.get(0), "/wsdls/lists-emea-test.xml");
        Assert.assertEquals("wrong resource name", resourceUris.get(1), "/wsdls/lists-americas-test.xml");
        Assert.assertEquals("wrong wsdl url", SharePointServiceClientFactory.WSDL_LOCATION_FOR_EMEA.toExternalForm(), "file://test.wsdl");
    }

    private class MockServletContextEvent extends ServletContextEvent {
        public MockServletContextEvent(ServletContext source) {
            super(source);
        }
    }

    private class MockServletContext implements ServletContext {

        public String resourceName;

        public ServletContext getContext(String s) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public int getMajorVersion() {
            return 0;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public int getMinorVersion() {
            return 0;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public String getMimeType(String s) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Set getResourcePaths(String s) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }



        public URL getResource(String s) throws MalformedURLException {
            resourceUris.add(s);
            return new URL("file://test.wsdl");  //To change body of implemented methods use File | Settings | File Templates.
        }

        public InputStream getResourceAsStream(String s) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public RequestDispatcher getRequestDispatcher(String s) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public RequestDispatcher getNamedDispatcher(String s) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Servlet getServlet(String s) throws ServletException {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Enumeration getServlets() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Enumeration getServletNames() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void log(String s) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void log(Exception e, String s) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void log(String s, Throwable throwable) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public String getRealPath(String s) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public String getServerInfo() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public String getInitParameter(String s) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Enumeration getInitParameterNames() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Object getAttribute(String s) {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public Enumeration getAttributeNames() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }

        public void setAttribute(String s, Object o) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public void removeAttribute(String s) {
            //To change body of implemented methods use File | Settings | File Templates.
        }

        public String getServletContextName() {
            return null;  //To change body of implemented methods use File | Settings | File Templates.
        }
    }
}
