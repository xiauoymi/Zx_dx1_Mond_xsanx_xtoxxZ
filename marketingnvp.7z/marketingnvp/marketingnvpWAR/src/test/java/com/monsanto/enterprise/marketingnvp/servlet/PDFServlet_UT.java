package com.monsanto.enterprise.marketingnvp.servlet;

import com.monsanto.enterprise.marketingnvp.model.ProductProfile;
import junit.framework.Assert;
import org.junit.Test;

import java.io.FileOutputStream;

/**
 * Created by IntelliJ IDEA.
 * User: tadial
 * Date: Jan 31, 2011
 * Time: 10:16:30 AM
 * To change this template use File | Settings | File Templates.
 */
public class PDFServlet_UT {

    private PDFServlet pdfServlet;


    @Test
    public void canGeneratePDFForDeruiters(){
        pdfServlet = new PDFServlet();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream("servlet_stamper_deruiters.pdf");
            pdfServlet.buildPDF(fileOutputStream, new ProductProfile());
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }

    }


    @Test
    public void canGeneratePDFForSeminis(){
        pdfServlet = new PDFServlet();
        try {
            FileOutputStream fileOutputStream = new FileOutputStream("servlet_stamper_seminis.pdf");
            pdfServlet.buildPDF(fileOutputStream, new ProductProfile());
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }

    }
}
